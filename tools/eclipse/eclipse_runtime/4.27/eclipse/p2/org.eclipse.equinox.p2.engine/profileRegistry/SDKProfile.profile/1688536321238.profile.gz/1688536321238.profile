<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='SDKProfile' timestamp='1688536321238'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/exton/ies'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_AU'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/exton/ies'/>
  </properties>
</profile>
