
package com.ibm.di.sca;

import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.sca.Ticket;
import common.i.td.td.i.invoke.TDI_Invoke;
import commonj.sdo.DataObject;
import com.ibm.websphere.sca.ServiceManager;
/**
 * This is the implementation class for the Sample Module that invokes
 * the TDI SCA Module
 *
 */

public class SampleCallImpl {
	/**
	 * Default constructor.
	 */
	public SampleCallImpl() {
		super();
	}

	/**
	 * Return a reference to the component service instance for this implementation
	 * class.  This method should be used when passing this service to a partner reference
	 * or if you want to invoke this component service asynchronously.    
	 *
	 * @generated (com.ibm.wbit.java)
	 */
	private Object getMyService() {
		return (Object) ServiceManager.INSTANCE.locateService("self");
	}

	/**
	 * This method is used to locate the service for the reference
	 * named "TDI_InvokePartner".  This will return an instance of
	 * {@link TDI_Invoke}.  If you would like to use this service 
	 * asynchronously then you will need to cast the result
	 * to {@link TDI_InvokeAsync}.
	 *
	 * @generated (com.ibm.wbit.java)
	 *
	 * @return TDI_Invoke
	 */
	public TDI_Invoke locateService_TDI_InvokePartner() {
		return (TDI_Invoke) ServiceManager.INSTANCE
				.locateService("TDI_InvokePartner");
	}

	/**
	 * Method generated to support implemention of operation "getUserInput" defined for WSDL port type 
	 * named "interface.User_Input".
	 * 
	 * The presence of commonj.sdo.DataObject as the return type and/or as a parameter 
	 * type conveys that its a complex type. Please refer to the WSDL Definition for more information 
	 * on the type of input, output and fault(s).
	 * 
	 */
	public DataObject getUserInput(DataObject serverInput) {
		
		DataObject execStatus = null;
		ServiceManager serviceManager = new ServiceManager();

		BOFactory bof = (BOFactory) serviceManager.locateService("com/ibm/websphere/bo/BOFactory");

		try {
			String serverIP = serverInput.getString("serverIP");
			String config = serverInput.getString("configName");
			String assemLine = serverInput.getString("alName");
			//System.out.println(" ServerIP " + serverIP);
			// Invoke the TDISCAModule and start assemblyline
			System.out.println("************ Locate TDI module service *********");
			TDI_Invoke invokeTDI = (TDI_Invoke) locateService_TDI_InvokePartner();
			System.out.println("************ Calling startAL on TDI service *********");
			execStatus =(DataObject) invokeTDI.startAL(serverInput);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return execStatus;	}

	/**
	 * Method generated to support the async implementation using callback
	 * for the operation (@link common.i.td.td.i.invoke.TDI_Invoke#startAL(DataObject aDataObject))
	 * of java interface (@link common.i.td.td.i.invoke.TDI_Invoke)	
	 * @see common.i.td.td.i.invoke.TDI_Invoke#startAL(DataObject aDataObject)	
	 */
	public void onStartALResponse(Ticket __ticket, DataObject returnValue,
			Exception exception) {
		
	}

}