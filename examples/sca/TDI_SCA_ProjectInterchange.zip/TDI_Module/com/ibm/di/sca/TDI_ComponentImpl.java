package com.ibm.di.sca;

import java.rmi.Naming;

import com.ibm.di.api.remote.AssemblyLine;
import com.ibm.di.api.remote.ConfigInstance;
import com.ibm.di.api.remote.Session;
import com.ibm.di.api.remote.SessionFactory;
import com.ibm.websphere.bo.BOFactory;
import com.ibm.websphere.sca.ServiceManager;
import commonj.sdo.DataObject;
/**
 * This class is responsible for invoking the remote TDI server using
 * Server API
 * 
 */
public class TDI_ComponentImpl {
	/**
	 * Default constructor.
	 */
	public TDI_ComponentImpl() {
		super();
	}

	/**
	 * Return a reference to the component service instance for this
	 * implementation class. This method should be used when passing this
	 * service to a partner reference or if you want to invoke this component
	 * service asynchronously.
	 * 
	 * @generated (com.ibm.wbit.java)
	 */
	private Object getMyService() {
		return (Object) ServiceManager.INSTANCE.locateService("self");
	}

	/**
	 * Method generated to support implemention of operation "startAL" defined
	 * for WSDL port type named "interface.TDI_Invoke".
	 * 
	 * The presence of commonj.sdo.DataObject as the return type and/or as a
	 * parameter type conveys that its a complex type. Please refer to the WSDL
	 * Definition for more information on the type of input, output and
	 * fault(s).
	 */
	public DataObject startAL(DataObject serverInfo) {
		DataObject execStatus = null;

		ServiceManager serviceManager = new ServiceManager();

		System.out.println("************ BOFactory created *********");
		BOFactory bof = (BOFactory) serviceManager
				.locateService("com/ibm/websphere/bo/BOFactory");

		execStatus = bof.create("http://TDI_Common", "ExceutionResult");

		System.out.println("************ ExecutionResult object created *********");

		String serverIP = serverInfo.getString("serverIP");
		String configPath = serverInfo.getString("configName");
		String assemLine = serverInfo.getString("alName");

		// Default port no
		String portNo = "1099";
		Session session = null;
		try {
			SessionFactory sf = (SessionFactory) Naming.lookup("rmi://"
					+ serverIP + ":" + portNo + "/SessionFactory");
			System.out.println("created session factory" + sf.toString());
			session = sf.createSession();
		} catch (Exception ex) {
			System.out.println("Error while ceating Session "+ex);
			return null;
		}
		
		System.out.println("Config path is " + configPath);
		String configID = com.ibm.di.api.syslog.LogUtils
				.getCleanConfigId(configPath);
		System.out.println("Config ID:" + configID);
		ConfigInstance configInstance = null;
		AssemblyLine assemblyLine = null;
		try {
			configInstance = session.getConfigInstance(configID);
			if (configInstance == null) { //Handling Solution Name (FN-13 requirement)
				configInstance = session.getConfigInstance(configPath);
			}

			if (configInstance == null) { //Not running
				configInstance = session.startConfigInstance(configPath);
				System.out.println("config instance is being loaded");
				configInstance = session.getConfigInstance(configID);
				if (configInstance == null) { //Handling Solution Name (FN-13 requirement)
					configInstance = session.getConfigInstance(configPath);
				}
			}
		} catch (Exception e) {
			System.out.println("Error while loading ConfigInstance");
			return null;
		}
		try {
			if (configInstance != null) {
				System.out.println("Starting assemblyLine:" + assemLine);
				assemblyLine = configInstance.startAssemblyLine(assemLine);
				System.out.println("AssemblyLine name " + assemLine);
				System.out.println("Assembly Line started");
				execStatus.set("result1", "AssemblyLine Started");

			} else {
				System.out.println("Unable to load/find config");
			}

		} catch (Exception e) {
			System.out.println("Error while starting assembly line");
			return null;
		}
		return execStatus;

	}

}