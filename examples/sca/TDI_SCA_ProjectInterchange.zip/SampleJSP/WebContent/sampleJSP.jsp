<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<HTML>
<HEAD>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>
<META http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<META name="GENERATOR" content="IBM Software Development Platform">
<META http-equiv="Content-Style-Type" content="text/css">
<LINK href="theme/Master.css" rel="stylesheet"
	type="text/css">
<TITLE>sampleJSP.jsp</TITLE>
</HEAD>
<BODY>
<%@ page import="com.ibm.websphere.sca.ServiceManager" %>
<%@ page import="commonj.sdo.DataObject" %>
<%@ page import="com.ibm.websphere.bo.BOFactory" %>
<%@ page import="common.i.td.user.input.User_Input" %>


<FORM action="sampleJSP.jsp" method="get">
<H1>Sample JSP Application to start TDI Assembly Line</H1>

<P>Enter details of Assembly Line to be started </P>
<TABLE border="0" cellpadding="5" cellspacing="0">
	<TBODY>
		<TR>
			<TD>Server Address </TD>
			<TD> <INPUT type="text" name="serverIP" size="20"> </TD>
		</TR>
		
		
		<TR>
			<TD>Config Path</TD>
			<TD> <INPUT type="text" name="configName" size="20"> </TD>
		</TR>
		<TR>
			<TD>Assembly Line </TD>
			<TD> <INPUT type="text" name="assemblyLine" size="20"> </TD>
		</TR>
	</TBODY>
</TABLE>
<P><INPUT type="submit" name="submitTDI" value="Invoke TDI SCA Component"></P></FORM>


<% 
	String serverIP=request.getParameter("serverIP");
	String configName=request.getParameter("configName");
	String alName=request.getParameter("assemblyLine");
	//String portNo=request.getParameter("portNo");
	if(null!=serverIP && null!=configName && null!= alName){
		try {
			
			
			ServiceManager serviceManager = new ServiceManager();
			System.out.println("************ BOFactory created ***************");
			BOFactory bof = (BOFactory)serviceManager.locateService("com/ibm/websphere/bo/BOFactory");		
			DataObject serverInput = bof.create("http://TDI_Common", "ServerInfo");

			serverInput.setString("serverIP", serverIP);
			serverInput.setString("configName", configName);
			serverInput.setString("alName", alName);
			//serverInput.setString("portNo",portNo);

			User_Input userService = (User_Input) serviceManager.locateService("User_InputPartner");
			DataObject executionResult = (DataObject)userService.getUserInput(serverInput);	
			if(executionResult != null){			
				//out.println("************ Execution result : " + executionResult.getString("result1") +"**************** "); 
			%>
			<SCRIPT>alert("AssemblyLine is running .");</SCRIPT>
			<%
			}else{
				//out.println("************ Error while trying to run AssemblyLine" +"**************** "); 
				%>
				<SCRIPT>alert("AssemblyLine could not be started .");</SCRIPT>
				<%
			}
		} catch (Exception e) {
%>
<hr>
<font color="red">
<%
			try {
				out.println(e.toString());
            } catch (Exception e1) {};
%>
</font>
<%
		}
	}	
	
%>


</BODY>
</HTML>
