/**
 * ##[lineageStampBegin]##
 * ##[generatedBy:/TDI_Common/TDI_Invoke.wsdl]##
 * ##[lineageStampEnd]##
 */
package common.i.td.td.i.invoke;

import commonj.sdo.DataObject;

import com.ibm.websphere.sca.ServiceBusinessException;

/**
 * @generated (com.ibm.wbit.java.core)
 * An interface used for enabling a static programming model for the service. 
 * The methods provide synchronous invocations of the service operations.
 */
public interface TDI_Invoke {
	public static final String PORTTYPE_NAME = "{http://TDI_Common/TDI_Invoke}TDI_Invoke";

	/**
	 * @generated (com.ibm.wbit.java.core)
	 * The "startAL" operation on WSDL port "ns1:TDI_Invoke"
	 */
	public DataObject startAL(DataObject serverInfo)
			throws ServiceBusinessException;

}
