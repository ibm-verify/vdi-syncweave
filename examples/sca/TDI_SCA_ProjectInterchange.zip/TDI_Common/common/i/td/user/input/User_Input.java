/**
 * ##[lineageStampBegin]##
 * ##[generatedBy:/TDI_Common/UserInput.wsdl]##
 * ##[lineageStampEnd]##
 */
package common.i.td.user.input;

import commonj.sdo.DataObject;

import com.ibm.websphere.sca.ServiceBusinessException;

/**
 * @generated (com.ibm.wbit.java.core)
 * An interface used for enabling a static programming model for the service. 
 * The methods provide synchronous invocations of the service operations.
 */
public interface User_Input {
	public static final String PORTTYPE_NAME = "{http://TDI_Common/UserInput}User_Input";

	/**
	 * @generated (com.ibm.wbit.java.core)
	 * The "getUserInput" operation on WSDL port "ns1:User_Input"
	 */
	public DataObject getUserInput(DataObject serverInput)
			throws ServiceBusinessException;

}
