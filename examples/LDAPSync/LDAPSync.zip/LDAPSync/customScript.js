// This function returns the object class used to create new Person entries in the target
// Note that the Work Entry is passed in, but not used in this function, although the
// data on the current Person could be used to choose which object class to use.
//
function userObjectClass(workEntry) {
		var oc = system.newAttribute("objectClass")
		var parts = system.splitString(targetUserObjectClass,",")
		
		for (var p in parts)
			oc.addValue(p)
			
		return oc
}

// This function returns the object class used to create new Group entries in the target
// Note that the Work Entry is passed in, but not used in this function, although the
// data on the current Group could be used to choose which object class to use.
//
function groupObjectClass(workEntry) {
		var oc = system.newAttribute("objectClass")
		var parts = system.splitString(targetGroupObjectClass,",")
		
		for (var p in parts)
			oc.addValue(p)
			
		return oc
}