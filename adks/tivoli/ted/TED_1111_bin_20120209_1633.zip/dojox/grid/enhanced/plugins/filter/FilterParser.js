/**
 * @author Oliver
 */
dojo.provide("dojox.grid.enhanced.plugins.filter.FilterParser");
dojo.require("dojox.grid.enhanced.plugins.filter._FilterExpr");

(function(){
	var f_ns = dojox.grid.enhanced.plugins.filter;
	f_ns.parseFilter = /* public _ConditionExpr */function(/* string */str, args){
		// summary:
		//     Translates the string format expression to a _ConditionExpr object.
		//     i.e., the lexical & syntax check is done here, but the symantic check 
		//     is in the _ConditionExpr.applyRow method.
		// str: string  (mandatory)
		//     The string format condition expression
		// returns: _ConditionExpr
		// throws: Error object
		//     simple message for lexical error or syntax error.
		f_ns.parseFilter.args = args || {};
        return parseBrackets(tokenize(str));
    };
	
	//----------------All Private Below--------------------------------
	var 
	_numberRegex = "[-+]?[0-9]+(?:\\.[0-9]*)?",
	_stringRegex = "'(?:\\\\.|[^'\\\\])*'|\"(?:\\\\.|[^\"\\\\])*\"",
	_biOpRegex = "!=|<=|>=|[<>&|~=]",
	_uniOpRegex = "\\$[SsNnDdTt]|[DdTt!]",
	_bracketRegex = "[()]",
	_lexRegex = new RegExp(["^(?:(",
					_numberRegex,")|(",    //$1
					_stringRegex,")|(",    //$2
					_biOpRegex,")|(",      //$3
					_uniOpRegex,")|(",     //$4
					_bracketRegex,"))"     //$5
				].join('')),
	bdr = function(opCls){
		return dojo.partial(function(cls, L, R){
			return new f_ns[cls](L,R);
		},opCls);
	},
	bdr_uni = function(ECls, isCol){
		return dojo.partial(function(cls, E, args){
			return new f_ns[cls](E.getValue(), isCol, args);
		}, ECls);
	},
	//All supported bi-operators
	_biOps = {
		"|": {
			p: 1,
			builder: bdr("LogicOR")
		},
		"&": {
			p: 2,
			builder: bdr("LogicAND")
		},
		"=": {
			p: 3,
			builder: bdr("EqualTo")
		},
		"<": {
			p: 4,
			builder: bdr("LessThan")
		},
		">": {
			p: 4,
			builder: bdr("LargerThan")
		},
		"<=": {
			p: 4,
			builder: bdr("LessThanOrEqualTo")
		},
		">=": {
			p: 4,
			builder: bdr("LargerThanOrEqualTo")
		},
		"!=": {
			p:4,
			builder:function(l,r){
				return new f_ns.LogicNOT(new f_ns.EqualTo(l,r));
			}
		},
		"~": {
			p: 5,
			builder: bdr("Matches")
		}
	},
	//All supported uni-operators
	_uniOps = {
		"!": function(E){
			return new f_ns.LogicNOT(E);
		},
		"d": bdr_uni("DateExpr"),
		"t": bdr_uni("TimeExpr"),
		"$s": bdr_uni("StringExpr",true),
		"$n": bdr_uni("NumberExpr",true),
		"$d": bdr_uni("DateExpr",true),
		"$t": bdr_uni("TimeExpr",true)
	},
	formatString = function(str){
		// summary:
		//     handle the escapers in the string.
		return str.slice(1,str.length-1).replace(/\\(.)/g,"$1");	
	},
	tokenize = function(input_expr){
		var m,tokens = [];
		//white spaces are allowed
		input_expr = dojo.trim(input_expr);
		while(m = input_expr.match(_lexRegex)){//Intentional
			if (m[0] == m[1]) {
				//It's a number
				tokens.push({
					type: "number",
					value: parseFloat(m[0])
				});
			} else if (m[0] == m[2]) {
				//It's a string
				tokens.push({
					type: "string",
					value: formatString(m[0])
				});
			} else {
				//It's an operator or bracket, we should support both lower/upper cases.
				tokens.push(m[0].toLowerCase());
			}
			//white spaces are allowed
			input_expr = dojo.trim(input_expr.substring(m[0].length));
		}
		if(input_expr.length > 0){
			throw new Error("Lexical Error");
		}
		return tokens;
	},
	parseBrackets = function(tokens){
		var start = 0,flag,expr,i;
		while((start = dojo.indexOf(tokens,"(",start))>=0){
			flag = 1;
			for(i = start+1; i < tokens.length; ++i){
				if(tokens[i]=="("){
					++flag;
				}else if(tokens[i]==")"){
					--flag;
				}
				if(flag == 0)break;
			}
			if(flag == 0){
				//console.log("Brackets: ",start,i);
				expr = parseBrackets(tokens.slice(start+1,i));
				tokens.splice(start,i+1-start,expr);
				++start;
			}else{
				throw new Error("Syntax Error: unmatched brackets");
			}
		}
		//No brackets here.
		//console.log("No Brackets: ",tokens);
		return parseBiOps(tokens);
	},
	parseBiOps = function(tokens){
		var i, pos, biOps = [], op;
		for(i=0;i<tokens.length;++i){
			if(dojo.isString(tokens[i])
				&& (op = _biOps[tokens[i]])
				&& (biOps[op.p] == undefined || !op.right_assoc)){
				biOps[op.p] = i;
			}
		}
		for(i=0;i<biOps.length;++i){
			if(biOps[i] != undefined){
				pos = biOps[i];
				//console.log("BiOp found: ",_biOps[tokens[pos]]);
				var left = parseBiOps(tokens.slice(0, pos)),
					right = parseBiOps(tokens.slice(pos+1));
				if(left == null || right == null){
					throw new Error("Syntax Error: missing operand");
				}
				return _biOps[tokens[pos]].builder(left,right);
			}
		}
		//No bi-ops here
		//console.log("No BiOps: ",tokens);
		return parseUniOps(tokens);
	},
	parseUniOps = function(tokens){
		if(tokens.length == 0){
			return null;
		}
		var tk = tokens[0];
		if(tokens.length == 1){
			//console.log("No UniOps: ",tokens);
			if(tk === null || tk instanceof f_ns._ConditionExpr){
				return tk;
			}
			if(tk.type == "string"){
				return new f_ns.StringExpr(tk.value);
			}
			if(tk.type == "number"){
				return new f_ns.NumberExpr(tk.value);
			}
		}else if(dojo.isString(tk) && _uniOps[tk]){
			//console.log("UniOp found:",tk);
			var args, dtp = f_ns.parseFilter.args.dateTimeParser, sliceCount = 1;
			try{
				if((tk == "$d" || tk == "$t" || tk == "d" || tk == "t") && dtp){
					if((tokens[1] && (tokens[1].type == "number" || tokens[1].type == "string")) && 
						(tokens[2] && (tokens[2].type == "number" || tokens[2].type == "string"))){
						args = dtp[tokens[1].value];
						sliceCount = 2;
					}else{
						args = dtp;
					}
				}
			}catch(e){}
			return _uniOps[tk](parseUniOps(tokens.slice(sliceCount)), args);
		}
		throw new Error("Syntax Error: unrecognized token or missing operators between tokens");
	};
})();