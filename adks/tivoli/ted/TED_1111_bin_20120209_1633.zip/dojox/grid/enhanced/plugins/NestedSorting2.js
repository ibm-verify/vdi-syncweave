dojo.provide("dojox.grid.enhanced.plugins.NestedSorting2");

dojo.require("dojox.grid.enhanced._Plugin");

dojo.declare("dojox.grid.enhanced.plugins.NestedSorting2", dojox.grid.enhanced._Plugin, {
	//	summary:
	//		 Provides nested sorting feature
	// example:
	// 		 <div dojoType="dojox.grid.EnhancedGrid" plugins="{nestedSorting: true}" ...></div>
	
	//name: String
	//		Plugin name
	name: "nestedSorting2",
	constructor: function(){
		this._sortDef = [];
		this._sortData = {};
		this._headerNodes = {}; 
		this._currSortIndex = -1;
		this.grid.setSortIndex = function(){};
		var self = this;
		this.grid.getSortProps = dojo.hitch(this, this.getSortProps);
		
		//the grid re-renders at column resizing
		this.connect(this.grid.views, 'render', '_initSort');
	},
	onStartUp: function(){
		//overwrite base Grid functions
		this.inherited(arguments);
		this.connect(this.grid, 'onHeaderCellClick', '_onHeaderCellClick');
	},
	
	getSortProps: function(){
		//summary:
		//		Overwritten, see DataGrid.getSortProps()
		return this._sortDef;
	},
	_initSort: function(){
		console.debug('Initiating sort when grid rendering...');
		// summary:
		//		Initiate sorting
		var g = this.grid;
		this._headerNodes = dojo.query("th", g.viewsHeaderNode);
		this._headerNodes.forEach(this._initHeaderNode, this);
	},
	_initHeaderNode: function(node ){
		//Summary: 
		var singleSort = dojo.create('a', {
			className: 'dojoxGridSingleSort',
			href: 'javascript:void(0);',
			onmousedown: dojo.stopEvent,
			title: 'Single Sort' //Evan TODO - use nls
		}, node.firstChild, 'last');
		
		var nestedSort = dojo.create('a', {
			className: 'dojoxGridNestedSort',
			href: 'javascript:void(0);',
			onmousedown: dojo.stopEvent,
			title: 'Nested Sort' //Evan TODO - nls
		}, node.firstChild, 'last');
		
		this._updateHeaderNodeUI(node);
	},
	
	_getFieldByNode: function(node){
		for(var i = 0; i < this._headerNodes.length; i++){
			if(this._headerNodes[i] == node){
				return this.grid.layout.cells[i].field;
			}
		}
		return null;
	},
	_onHeaderCellClick: function(e){
		console.debug('header cell click: ', e);
		if(dojo.hasClass(e.target, 'dojoxGridSingleSort')
			|| dojo.hasClass(e.target, 'dojoxGridNestedSort')){
			this._onSortBtnClick(e);
		}
	},

	_onSortBtnClick: function(e){
		//	summary:
		//		If the click target is single sort button, do single sort.
		//		Else if the click target is nested sort button, do nest sort.
		//		Otherwise return.
		var field = e.cell.field;
		if(dojo.hasClass(e.target, 'dojoxGridSingleSort')){
			this._prepareSingleSort(field); 
		}else if(dojo.hasClass(e.target, 'dojoxGridNestedSort')){
			this._prepareNestedSort(field); 
		}else{
			return;
		}
		dojo.stopEvent(e);
		this._doSort(field);
		console.debug('sorting definition: ', this._sortDef);
	},
	
	_doSort: function(field){
		if(!this._sortData[field] || !this._sortData[field].order){
			this.setSortData(field, 'order', 'asc');	//no sorting data
		}else if(this.isAsc(field)){
			this.setSortData(field, 'order', 'desc');	//change to 'desc'
		}else if(this.isDesc(field)){
			this.removeSortData(field);					//remove from sorting sequence
			this._currSortIndex --;
		}
		this._updateSortDef();
		this.grid._refresh();
	},
	
	setSortData: function(field, attr, value){
		// summary:
		//		Set sorting data for a column.
		var sd = this._sortData[field];
		if(!sd){
			sd = this._sortData[field] = {};
		}
		sd[attr] = value;
	},
	removeSortData: function(field){
		var d = this._sortData, i = d[field].index;
		delete d[field];
		var arr = [];
		for(var p in d){
			if(d[p].index > i){
				d[p].index--;
			}
		}
	},

	_prepareSingleSort: function(field){
		//	summary:
		//		Prepare the single sort, also called main sort, this will clear any exsting sorting and just sort the grid by current column.
		var d = this._sortData;
		for(var p in d){
			if(p != field)delete d[p];		//clear nested sorting data
		}
		this._currSortIndex = 0;
		this.setSortData(field, 'index', 0);
	},
	
	_prepareNestedSort: function(field){
		//summary
		//	Prepare the nested sorting, this will order the column on existing sorting result.
		var i = this._sortData[field] ? this._sortData[field].index : null;
		if(i === 0 || !!i){ return; }
		this.setSortData(field, 'index', ++this._currSortIndex);
	},
	
	_updateSortDef: function(){
		this._sortDef.length = 0;
		var d = this._sortData;
		for(var p in d){
			this._sortDef[d[p].index] = {
				attribute: p
				,descending: d[p].order == 'desc'
			}
		}
	},

	_updateHeaderNodeUI: function(node){
		// summary:
		//		Update the column header ui on current sorting state.
		//		Show indicator of the sorting order of the column, no order no indicator
		var field = this._getFieldByNode(node);
		var data = this._sortData[field];
		var singleSortBtn = dojo.query('.dojoxGridSingleSort', node)[0];
		var nestedSortBtn = dojo.query('.dojoxGridNestedSort', node)[0];
		if(!data){
			nestedSortBtn.innerHTML = this._currSortIndex + 2;
			return;
		}
		dojo.addClass(this.grid.domNode, 'dojoxGridSorted');

		if(this.isAsc(field)){
			dojo.addClass(node, 'dojoxGridSortAsc');
			dojo.addClass(singleSortBtn, 'dojoxAscButton');
			dojo.addClass(nestedSortBtn, 'dojoxAscNestedButton');
		}else if(this.isDesc(field)){
			dojo.addClass(node, 'dojoxGridSortDesc');
			dojo.addClass(singleSortBtn, 'dojoxDescButton');
			dojo.addClass(nestedSortBtn, 'dojoxDescNestedButton');
		}
		dojo.toggleClass(node, 'dojoxGridMainSorted', data.index === 0);
		if(data.index || (data.index === 0 && this._currSortIndex > 0)){
			dojo.addClass(node, 'dojoxGridNestSorted');
			nestedSortBtn.innerHTML = data.index + 1;
		}
	},
	isAsc: function(field){
		return this._sortData[field].order == 'asc';
	},
	isDesc: function(field){
		return this._sortData[field].order == 'desc';
	},
	
	destroy: function(){
		this._sortDef = this._sortData = this._headerNodes = null;
		this.inherited(arguments);
	}
});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.NestedSorting2);