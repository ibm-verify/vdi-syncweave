dojo.provide("dojox.grid.enhanced.plugins.CellFormatter");

dojo.require("dojox.grid.enhanced._Plugin");
dojo.require("dojo.date.locale");
dojo.require("dojo.currency");

dojo.declare("dojox.grid.enhanced.plugins.CellFormatter",dojox.grid.enhanced._Plugin,{
	// summary:
	//		This plugin defines some useful formatters to easily format the usual data types in the store.
	// description:
	//		The supported formatters are: date, time, number, currency.
	//		To use this plugin, users may define the format patterns in the cell definition of the grid structure(layout).
	//		For example:
	//		var layout = [{
	//			cells: [
	//				//The most typical usage:
	//				{
	//					field: "some field",
	//					cellFormatter: {
	//						selector: "date",	//can be one of: "date","time","number","currency"
	//						parse: {		//an optional dojo.date.locale.__FormatOptions object for the "parse" process,
	//							datePattern: ...  //that is parsing the data in the store.
	//						}				
	//						format: {		//an optional dojo.date.locale.__FormatOptions object for the "format" process,
	//							datePattern: ...  //that is formatting the data to the show in the grid.
	//						}				
	//					}
	//				},
	//				......
	//				//If both "parse" and "format" are omitted....
	//				{
	//					field: "some field",
	//					cellFormatter: {	//If neither "parse" nor "format" is provided, the whole argument is regarded as a "format" argument. 
	//						selector: "time",	
	//						timePattern: "0.00"
	//					}
	//				},
	//				......
	//				//Actually, any function can be used to replace the "parse" or "format" object
	//				{
	//					field: "some field",
	//					cellFormatter: {
	//						selector: "date",
	//						parse: function(datum, args, rowIndex, cell){	//args is just the whole cellFormatter object
	//							......
	//							return anything;
	//						}, 
	//						format: function(returnByParse, args, rowIndex, cell){	//args is just the whole cellFormatter object
	//							......
	//							return "some string";
	//						}
	//					}
	//				},
	//				......
	//				//Note: the currecy formatter can only transfer one currecy format to another, 
	//				//it cannot format pure numbers to currency correctly. This is because we're using 
	//				//dojo.currecy.parse/format here instead of dojo.number.parse/format
	//				{
	//					field: "some field",
	//					cellFormatter: {
	//						selector: "number",		//To format from pure numbers to currency, should explicitly say this.
	//						format: {
	//							selector: "currency",
	//							pattern: "\u00a5 00,000.00"
	//						}
	//					}
	//				}
	//			]
	//		}]
	
	// name: String
	//		Plugin name
	name: "cellFormatter",
	
	constructor: function(grid){
		var oldFunc = grid.layout.addCellDef;
		grid.layout.addCellDef = dojo.hitch(this, function(inRowIndex, inCellIndex, inDef){
			var cell = dojo.hitch(grid.layout, oldFunc)(inRowIndex, inCellIndex, inDef),
				f = cell.cellFormatter;
			if(f && dojo.isObject(f)){
				var formatter = this._getFormatter(f.selector);
				if(formatter){
					var oldGet = cell.get || grid.get;
					cell.get = dojo.hitch(this, function(rowIndex, item){
						var data = oldGet.call(cell, rowIndex, item);
						return formatter.call(this, f, data, rowIndex, cell);
					});	
				}
			}
			return cell;
		});
	},
	_getFormatter: function(formatterStr){
		return this["_" + formatterStr + "CellFormatter"];
	},
	_format: function(formatterArgs, datum, rowIndex, cell, defaultFormat, defaultParse, defaultArg){
		formatterArgs = dojo.mixin({}, defaultArg, formatterArgs);
		var res, 
			fa = formatterArgs.format,
			faIsFunc = fa && dojo.isFunction(fa),
			faIsObj = fa && dojo.isObject(fa),
			f = faIsFunc ? fa : defaultFormat,
			
			pa = formatterArgs.parse,
			paIsFunc = pa && dojo.isFunction(pa),
			paIsObj = pa && dojo.isObject(pa),
			p = paIsFunc ? pa : defaultParse,
			
			getArg = function(fpa, isFunc){
				return isFunc ? defaultArg : (fpa || defaultArg);
			};
		if(faIsObj){
			fa = dojo.mixin({}, defaultArg, fa);
		}
		if(paIsObj){
			pa = dojo.mixin({}, defaultArg, pa);
		}
		if(faIsObj || paIsObj){
			pa = getArg(pa, paIsFunc);
			fa = getArg(fa, faIsFunc);
		}else if(paIsFunc && faIsFunc){
			//both pa and fa are functions, so everything is user defined.
			pa = fa = formatterArgs;
		}else{
			//User's omitted both "parse" and "format"
			pa = defaultArg;
			fa = formatterArgs;
		}
		try{
			res = p(datum, pa, rowIndex, cell);
			if(res){
				res = f(res, fa, rowIndex, cell);
				if(res){return res;}
				return "Error: format failed. Please check format pattern.";
			}
			return "Error: parse failed. Please check parse pattern.";
		}catch(e){
			//console.error("CellFormatter Error:",e);
			return "Error: "+e;
		}
	},
	_dateCellFormatter: function(formatterArgs, datum, rowIndex, cell){
		var ddl = dojo.date.locale;
		return this._format(formatterArgs, datum, rowIndex, cell, ddl.format, ddl.parse, {selector: "date"});
	},
	_timeCellFormatter: function(formatterArgs, datum, rowIndex, cell){
		var ddl = dojo.date.locale;
		return this._format(formatterArgs, datum, rowIndex, cell, ddl.format, ddl.parse, {selector: "time"});
	},
	_numberCellFormatter: function(formatterArgs, datum, rowIndex, cell){
		var dn = dojo.number;
		return this._format(formatterArgs, datum, rowIndex, cell, dn.format, dn.parse, {});
	},
	_currencyCellFormatter: function(formatterArgs, datum, rowIndex, cell){
		var dc = dojo.currency;
		return this._format(formatterArgs, datum, rowIndex, cell, dc.format, dc.parse, {});
	}
});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.CellFormatter/*name:'cellFormatter'*/, {"preInit": true});