/**
 * @author Oliver
 */
dojo.provide("dojox.grid.enhanced.plugins.AdvancedSearch");

dojo.require("dojox.grid.enhanced.plugins.filter.FilterParser");

(function(){
var fns = dojox.grid.enhanced.plugins.filter;
dojo.declare("dojox.grid.enhanced.plugins.AdvancedSearch", null, {
	constructor: function(grid, args){
		this.grid = grid;
		args = dojo.isObject(args) ? args : {};
		this._cacheSize = args.cacheSize || 100;
		this.grid.search = dojo.hitch(this, "search");
	},
	search: function(exprStr, onSearched, args){
		var filter = fns.parseFilter(exprStr, args);
		this._search(filter, 0, onSearched);
	},
	_search: function(filter, start, onSearched){
		var g = this.grid,
			s = g.store,
			_this = this,
			cnt =  this._cacheSize;
		s.fetch({
			"start": start,
			"count": cnt,
			onComplete: function(items){
				if (!dojo.some(items, function(item, i){
					if (filter.applyRow(item, function(item, field){
						return s.getValue(item, field);
					}).getValue()) {
						onSearched(start + i, item);
						return true;
					}
					return false;
				})) {
					if (start + cnt < g.rowCount) {
						_this._search(filter, start + cnt, onSearched);
					}else{
						onSearched(-1, null);
					}
				}
			}
		});
	},
	simpleSearch: function(field, keyword, onSearched){
		keyword = keyword.replace(/'/g, "\\'");
		var exprStr = ["$s'", field, "' ~ '", keyword, "'"].join('');
		this.search(exprStr, onSearched);
	}
});
})();
