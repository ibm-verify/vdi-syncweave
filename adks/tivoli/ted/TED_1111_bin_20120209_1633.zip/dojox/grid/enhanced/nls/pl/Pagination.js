({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "Elementy: ${1} - ${2} z ${0}",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "Elementy: 1 - 1 z 1",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "Elementy: ${0}",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "Elementy: 1",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "Elementy: 0",	//Used when row count is zero
	"firstTip": "Pierwsza strona",
	"lastTip": "Ostatnia strona",
	"nextTip": "Następna strona",
	"prevTip": "Poprzednia strona",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Strona ${0}",
	"pageSizeLabelTemplate": "${0} elementów na stronę",
	"allItemsLabelTemplate": "Wszystkie elementy",
	"gotoButtonTitle": "Idź do określonej strony",
	"dialogTitle": "Idź do strony",
	"dialogIndication": "Podaj numer strony",
	"pageCountIndication": " (${0} stron)",
	"dialogConfirm": "Idź",
	"dialogCancel": "Anuluj",
	"all": "Wszystko"
})
