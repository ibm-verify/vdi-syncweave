({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} / ${0} 項目",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 / 1 項目",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} 項目",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 項目",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 項目",	//Used when row count is zero
	"firstTip": "最初のページ",
	"lastTip": "最後のページ",
	"nextTip": "次のページ",
	"prevTip": "前のページ",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "ページ ${0}",
	"pageSizeLabelTemplate": "ページ当たり ${0} 項目",
	"allItemsLabelTemplate": "すべての項目",
	"gotoButtonTitle": "特定のページに移動",
	"dialogTitle": "ページに移動",
	"dialogIndication": "ページ番号を指定してください",
	"pageCountIndication": " (${0} ページ)",
	"dialogConfirm": "移動",
	"dialogCancel": "キャンセル",
	"all": "すべて"
})
