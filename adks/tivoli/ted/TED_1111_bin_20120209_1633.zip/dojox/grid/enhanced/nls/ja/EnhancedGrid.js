({
	singleSort: "単一ソート",
	nestedSort: "ネスト・ソート",
	ascending: "クリックして昇順にソート",
	descending: "クリックして降順にソート",
	sortingState: "${0} - ${1}",
	unsorted: "この列をソートしない",
	indirectSelectionRadio: "行 ${0}、単一選択、ラジオ・ボックス",
	indirectSelectionCheckBox: "行 ${0}、複数選択、チェック・ボックス",
	selectAll: "すべて選択"
})
