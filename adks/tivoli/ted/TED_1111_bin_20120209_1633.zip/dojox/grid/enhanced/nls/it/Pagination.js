({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} di ${0} elementi",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 di 1 elemento",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} elementi",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 elemento",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 elementi",	//Used when row count is zero
	"firstTip": "Prima pagina",
	"lastTip": "Ultima pagina",
	"nextTip": "Pagina successiva",
	"prevTip": "Pagina precedente",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Pagina ${0}",
	"pageSizeLabelTemplate": "${0} elementi per pagina",
	"allItemsLabelTemplate": "Tutti gli elementi",
	"gotoButtonTitle": "Vai a una pagina specifica",
	"dialogTitle": "Vai alla pagina",
	"dialogIndication": "Specificare il numero di pagina",
	"pageCountIndication": " (${0} pagine)",
	"dialogConfirm": "Vai",
	"dialogCancel": "Annulla",
	"all": "Tutto"
})
