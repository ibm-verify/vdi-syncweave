({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} / ${0} öğe",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 / 1 öğe",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} öğe",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 öğe",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 öğe",	//Used when row count is zero
	"firstTip": "İlk Sayfa",
	"lastTip": "Son Sayfa",
	"nextTip": "Sonraki Sayfa",
	"prevTip": "Önceki Sayfa",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Sayfa ${0}",
	"pageSizeLabelTemplate": "Sayfa başına ${0} öğe",
	"allItemsLabelTemplate": "Tüm öğeler",
	"gotoButtonTitle": "Belirli bir sayfaya git",
	"dialogTitle": "Sayfaya Git",
	"dialogIndication": "Sayfa numarasını belirtin",
	"pageCountIndication": " (${0} sayfa)",
	"dialogConfirm": "Git",
	"dialogCancel": "İptal",
	"all": "Tümü"
})
