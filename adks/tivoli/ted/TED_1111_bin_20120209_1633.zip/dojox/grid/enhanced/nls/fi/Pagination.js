({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} / ${0} nimikettä",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 / 1 nimike",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} nimikettä",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 nimike",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 nimikettä",	//Used when row count is zero
	"firstTip": "Ensimmäinen sivu",
	"lastTip": "Viimeinen sivu",
	"nextTip": "Seuraava sivu",
	"prevTip": "Edellinen sivu",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Sivu ${0}",
	"pageSizeLabelTemplate": "${0} nimikettä sivua kohti",
	"allItemsLabelTemplate": "Kaikki nimikkeet",
	"gotoButtonTitle": "Siirry tietylle sivulle",
	"dialogTitle": "Siirry sivulle",
	"dialogIndication": "Kirjoita sivunumero",
	"pageCountIndication": " (${0} sivua)",
	"dialogConfirm": "Siirry",
	"dialogCancel": "Peruuta",
	"all": "Kaikki"
})
