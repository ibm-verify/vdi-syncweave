({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} из ${0} элемента/элементов",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 из 1 элемента",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "Элементов: ${0}",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 элемент",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 элементов",	//Used when row count is zero
	"firstTip": "Первая страница",
	"lastTip": "Последняя страница",
	"nextTip": "Следующая страница",
	"prevTip": "Предыдущая страница",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Страница ${0}",
	"pageSizeLabelTemplate": "${0} элементов на странице",
	"allItemsLabelTemplate": "Все элементы",
	"gotoButtonTitle": "Перейти на конкретную страницу",
	"dialogTitle": "Перейти на страницу",
	"dialogIndication": "Укажите номер страницы",
	"pageCountIndication": " (${0} страниц)",
	"dialogConfirm": "Перейти",
	"dialogCancel": "Отмена",
	"all": "Все"
})

