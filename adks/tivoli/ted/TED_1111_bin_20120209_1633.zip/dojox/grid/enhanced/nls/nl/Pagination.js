({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} van ${0} items",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 van 1 item",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} items",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 item",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 items",	//Used when row count is zero
	"firstTip": "Eerste pagina",
	"lastTip": "Laatste pagina",
	"nextTip": "Volgende pagina",
	"prevTip": "Vorige pagina",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Pagina ${0}",
	"pageSizeLabelTemplate": "${0} items per pagina",
	"allItemsLabelTemplate": "Alle items",
	"gotoButtonTitle": "Naar een specifieke pagina gaan",
	"dialogTitle": "Naar pagina gaan",
	"dialogIndication": "Geef het paginanummer op:",
	"pageCountIndication": " (${0} pagina's)",
	"dialogConfirm": "Start",
	"dialogCancel": "Annuleren",
	"all": "Alle"
})
