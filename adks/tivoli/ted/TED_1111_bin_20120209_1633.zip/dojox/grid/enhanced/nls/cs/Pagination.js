({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "Položky ${1} - ${2} z celkového počtu: ${0}",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "Položka 1 - 1 z celkového počtu: 1",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "Položek: ${0}",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "Položka: 1 ",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "Položek: 0",	//Used when row count is zero
	"firstTip": "První strana",
	"lastTip": "Poslední strana",
	"nextTip": "Další strana",
	"prevTip": "Předchozí strana",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Stránka ${0}",
	"pageSizeLabelTemplate": "${0} položek na stránce",
	"allItemsLabelTemplate": "Všechny položky",
	"gotoButtonTitle": "Přejít na specifickou stránku",
	"dialogTitle": "Přejít na stránku",
	"dialogIndication": "Uveďte číslo stránky",
	"pageCountIndication": " (${0} stránek)",
	"dialogConfirm": "Přejít",
	"dialogCancel": "Storno",
	"all": "Vše"
})
