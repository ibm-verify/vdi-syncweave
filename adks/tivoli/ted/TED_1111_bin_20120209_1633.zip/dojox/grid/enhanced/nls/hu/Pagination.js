({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2}. elemek. Összesen: ${0}",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1. elem. Összesen: 1",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} elem",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 elem",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 elem",	//Used when row count is zero
	"firstTip": "Első oldal",
	"lastTip": "Utolsó oldal",
	"nextTip": "Következő oldal",
	"prevTip": "Előző oldal",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "${0}. oldal",
	"pageSizeLabelTemplate": "${0} elem oldalanként",
	"allItemsLabelTemplate": "Összes elem",
	"gotoButtonTitle": "Ugrás adott oldalra",
	"dialogTitle": "Ugrás adott oldalra",
	"dialogIndication": "Adja meg az oldalszámot",
	"pageCountIndication": " (${0} oldal)",
	"dialogConfirm": "Mehet",
	"dialogCancel": "Mégse",
	"all": "Mind"
})
