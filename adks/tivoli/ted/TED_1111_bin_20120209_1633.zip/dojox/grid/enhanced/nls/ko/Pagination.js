({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1}페이지 - ${0}개 중 ${2}개 항목",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1페이지 - 1개 중 1개 항목",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0}개 항목",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1개 항목",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0개 항목",	//Used when row count is zero
	"firstTip": "첫 페이지",
	"lastTip": "마지막 페이지",
	"nextTip": "다음 페이지",
	"prevTip": "이전 페이지",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "${0} 페이지",
	"pageSizeLabelTemplate": "페이지당 ${0}개 항목",
	"allItemsLabelTemplate": "모든 항목",
	"gotoButtonTitle": "특정 페이지로 이동",
	"dialogTitle": "페이지 이동",
	"dialogIndication": "페이지 번호 지정",
	"pageCountIndication": " (${0}페이지)",
	"dialogConfirm": "이동",
	"dialogCancel": "취소",
	"all": "모두"
})
