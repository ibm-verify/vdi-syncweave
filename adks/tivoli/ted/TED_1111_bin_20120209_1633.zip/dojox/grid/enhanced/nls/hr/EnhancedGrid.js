({
	singleSort: "Jedan sort",
	nestedSort: "Ugniježđeni sort",
	ascending: "Klik za sort uzlazno",
	descending: "Klik za sort silazno",
	sortingState: "${0} - ${1}",
	unsorted: "Ne sortiraj ovaj stupac",
	indirectSelectionRadio: "Red ${0}, jedan izbor, radio kućica",
	indirectSelectionCheckBox: "Red ${0}, više izbora, kontrolna kućica",
	selectAll: "Izaberi sve"
})

