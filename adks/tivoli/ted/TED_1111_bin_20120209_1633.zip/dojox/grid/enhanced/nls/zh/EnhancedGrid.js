({
	singleSort: "单层排序",
	nestedSort: "嵌套排序",
	ascending: "单击以按“升序”排序",
	descending: "单击以按“降序”排序",
	sortingState: "${0} - ${1}",
	unsorted: "请勿对此列进行排序",
	indirectSelectionRadio: "第 ${0} 行，单选，单选框",
	indirectSelectionCheckBox: "第 ${0} 行，多选，复选框",
	selectAll: "全部选中"
})
