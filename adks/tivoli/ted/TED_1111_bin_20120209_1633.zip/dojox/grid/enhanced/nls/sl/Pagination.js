({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} od ${0} elementov",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 od 1 elementov",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} elementov",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 element",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 elementov",	//Used when row count is zero
	"firstTip": "Prva stran",
	"lastTip": "Zadnja stran",
	"nextTip": "Naslednja stran",
	"prevTip": "Prejšnja stran",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Stran ${0}",
	"pageSizeLabelTemplate": "${0} postavk na stran",
	"allItemsLabelTemplate": "Vse postavke",
	"gotoButtonTitle": "Pojdi na specifično stran",
	"dialogTitle": "Pojdi na stran",
	"dialogIndication": "Podajte številko strani",
	"pageCountIndication": " (${0} strani)",
	"dialogConfirm": "Pojdi",
	"dialogCancel": "Prekliči",
	"all": "Vse"
})

