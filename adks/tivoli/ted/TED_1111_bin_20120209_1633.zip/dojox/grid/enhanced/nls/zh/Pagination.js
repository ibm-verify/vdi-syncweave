({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "第 ${1} 至 ${2} 项，共 ${0} 项",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "第 1 至 1 项，共 1 项",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} 项",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 项",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 项",	//Used when row count is zero
	"firstTip": "第一页",
	"lastTip": "最后一页",
	"nextTip": "下一页",
	"prevTip": "上一页",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "第 ${0} 页",
	"pageSizeLabelTemplate": "每页 ${0} 项",
	"allItemsLabelTemplate": "所有项",
	"gotoButtonTitle": "转到指定页面",
	"dialogTitle": "转到页面",
	"dialogIndication": "指定页数",
	"pageCountIndication": " （${0} 页）",
	"dialogConfirm": "确定",
	"dialogCancel": "取消",
	"all": "所有"
})
