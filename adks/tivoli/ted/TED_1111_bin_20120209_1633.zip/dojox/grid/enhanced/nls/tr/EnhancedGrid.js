({
	singleSort: "Tekli Sıralama",
	nestedSort: "İç İçe Sıralama",
	ascending: "Artan düzende sıralamak için tıklatın",
	descending: "Azalan düzende sıralamak için tıklatın",
	sortingState: "${0} - ${1}",
	unsorted: "Bu sütunu sıralama",
	indirectSelectionRadio: "Satır ${0}, tek seçimli, radyo düğmesi",
	indirectSelectionCheckBox: "Satır ${0}, çok seçimli, radyo düğmesi",
	selectAll: "Tümünü seç"
})
