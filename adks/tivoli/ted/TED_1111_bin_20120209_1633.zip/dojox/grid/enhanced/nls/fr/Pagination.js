({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} sur ${0} éléments",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 sur 1 élément",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} éléments",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 élément",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 élément",	//Used when row count is zero
	"firstTip": "Première page",
	"lastTip": "Dernière page",
	"nextTip": "Page suivante",
	"prevTip": "Page précédente",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Page ${0}",
	"pageSizeLabelTemplate": "${0} éléments par page",
	"allItemsLabelTemplate": "Tous les éléments",
	"gotoButtonTitle": "Aller à une page donnée",
	"dialogTitle": "Aller à la page",
	"dialogIndication": "Indiquer le numéro de page",
	"pageCountIndication": " (${0} pages)",
	"dialogConfirm": "Aller",
	"dialogCancel": "Annuler",
	"all": "Tout"
})
