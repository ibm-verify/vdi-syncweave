({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} von ${0} Elementen",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 von 1 Element",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} Elemente",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 Element",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 Elemente",	//Used when row count is zero
	"firstTip": "Erste Seite",
	"lastTip": "Letzte Seite",
	"nextTip": "Nächste Seite",
	"prevTip": "Vorherige Seite",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Seite ${0}",
	"pageSizeLabelTemplate": "${0} Elemente pro Seite",
	"allItemsLabelTemplate": "Alle Elemente",
	"gotoButtonTitle": "Bestimmte Seite aufrufen",
	"dialogTitle": "Zu Seite",
	"dialogIndication": "Seitennummer angeben",
	"pageCountIndication": " (${0} Seiten)",
	"dialogConfirm": "Los",
	"dialogCancel": "Abbrechen",
	"all": "Alle"
})
