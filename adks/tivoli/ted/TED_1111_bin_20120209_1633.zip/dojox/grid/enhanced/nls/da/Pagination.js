({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} af ${0} elementer",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 af 1 element",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} elementer",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 element",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 elementer",	//Used when row count is zero
	"firstTip": "Første side",
	"lastTip": "Sidste side",
	"nextTip": "Næste side",
	"prevTip": "Forrige side",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Side ${0}",
	"pageSizeLabelTemplate": "${0} elementer pr. side",
	"allItemsLabelTemplate": "Alle elementer",
	"gotoButtonTitle": "Gå til en bestemt side",
	"dialogTitle": "Gå til side",
	"dialogIndication": "Angiv sidenummeret",
	"pageCountIndication": " (${0} sider)",
	"dialogConfirm": "Udfør",
	"dialogCancel": "Annullér",
	"all": "Alle"
})
