({
	singleSort: "Jednotlivé řazení",
	nestedSort: "Vnořené řazení",
	ascending: "Klepnutím seřadit vzestupně",
	descending: "Klepnutím seřadit sestupně",
	sortingState: "${0} - ${1}",
	unsorted: "Neřadit tento sloupec",
	indirectSelectionRadio: "Řádek ${0}, jednotlivý výběr, přepínač",
	indirectSelectionCheckBox: "Řádek ${0}, vícenásobný výběr, zaškrtávací políčko",
	selectAll: "Vybrat vše"
})
