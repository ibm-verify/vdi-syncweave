({
	singleSort: "Enostavno razvrščanje",
	nestedSort: "Ugnezdeno razvrščanje",
	ascending: "Kliknite, če želite zagnati naraščajoče razvrščanje",
	descending: "Kliknite, če želite zagnati padajoče razvrščanje",
	sortingState: "${0} - ${1}",
	unsorted: "Ne razvrščaj tega stolpca",
	indirectSelectionRadio: "Vrstica ${0}, izbira enega elementa, okence z izbirnim gumbom",
	indirectSelectionCheckBox: "Vrstica ${0}, izbira več elementov, okence s potrditvenimi polji",
	selectAll: "Izberi vse"
})

