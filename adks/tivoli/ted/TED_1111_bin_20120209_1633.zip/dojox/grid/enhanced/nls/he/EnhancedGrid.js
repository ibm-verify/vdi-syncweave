({
	singleSort: "מיון יחיד",
	nestedSort: "מיון מקונן",
	ascending: "יש ללחוץ כדי למיין בסדר עולה",
	descending: "יש ללחוץ כדי למיין בסדר יורד",
	sortingState: "${0} - ${1}",
	unsorted: "אין למיין עמודה זו",
	indirectSelectionRadio: "שורה ${0}, בחירה יחידה, תיבת בחירה",
	indirectSelectionCheckBox: "שורה ${0}, בחירה מרובה, תיבת סימון",
	selectAll: "בחירת הכל"
})
