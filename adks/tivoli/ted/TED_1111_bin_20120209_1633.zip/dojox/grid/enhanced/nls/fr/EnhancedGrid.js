({
	singleSort: "Tri simple",
	nestedSort: "Tri imbriqué",
	ascending: "Cliquez pour trier par Ordre croissant",
	descending: "Cliquez pour trier par Ordre décroissant",
	sortingState: "${0} - ${1}",
	unsorted: "Ne pas trier cette colonne",
	indirectSelectionRadio: "Ligne ${0}, sélection unique, bouton radio",
	indirectSelectionCheckBox: "Ligne ${0}, sélection multiple, case à cocher",
	selectAll: "Tout sélectionner"
})
