({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} de ${0} itens",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 de 1 item",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} itens",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 item",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 item",	//Used when row count is zero
	"firstTip": "Primeira Página",
	"lastTip": "Última Página",
	"nextTip": "Próxima Página",
	"prevTip": "Página Anterior",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Página ${0}",
	"pageSizeLabelTemplate": "${0} itens por página",
	"allItemsLabelTemplate": "Todos os itens",
	"gotoButtonTitle": "Ir para uma página específica",
	"dialogTitle": "Ir para a página",
	"dialogIndication": "Especificar o número da página",
	"pageCountIndication": " (${0} páginas)",
	"dialogConfirm": "Ir",
	"dialogCancel": "Cancelar",
	"all": "Tudo"
})
