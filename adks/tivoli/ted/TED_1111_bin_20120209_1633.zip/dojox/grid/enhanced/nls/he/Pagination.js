({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} מתוך ${0} פריטים",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 מתוך פריט אחד",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} פריטים",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "פריט אחד",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 פריטים",	//Used when row count is zero
	"firstTip": "עמוד ראשון",
	"lastTip": "עמוד אחרון",
	"nextTip": "העמוד הבא",
	"prevTip": "העמוד הקודם",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "עמוד ${0}",
	"pageSizeLabelTemplate": "${0} פריטים לעמוד",
	"allItemsLabelTemplate": "כל הפריטים",
	"gotoButtonTitle": "מעבר לעמוד ספציפי",
	"dialogTitle": "מעבר לעמוד",
	"dialogIndication": "ציון מספר העמוד",
	"pageCountIndication": " (${0} עמודים)",
	"dialogConfirm": "ביצוע",
	"dialogCancel": "ביטול",
	"all": "הכל"
})
