({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} av ${0} objekt",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 av 1 objekt",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} objekt",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 objekt",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 objekt",	//Used when row count is zero
	"firstTip": "Första sidan",
	"lastTip": "Sista sidan",
	"nextTip": "Nästa sida",
	"prevTip": "Föregående sida",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Sida ${0}",
	"pageSizeLabelTemplate": "${0} objekt per sida",
	"allItemsLabelTemplate": "Alla objekt",
	"gotoButtonTitle": "Gå till en viss sida",
	"dialogTitle": "Gå till sidan",
	"dialogIndication": "Ange sidnummer",
	"pageCountIndication": " (${0} sidor)",
	"dialogConfirm": "Gå",
	"dialogCancel": "Avbryt",
	"all": "Alla"
})
