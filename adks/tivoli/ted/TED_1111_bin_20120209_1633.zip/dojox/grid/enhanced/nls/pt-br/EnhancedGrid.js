({
	singleSort: "Classificação Única",
	nestedSort: "Classificação Aninhada",
	ascending: "Clique para classificar em ordem crescente",
	descending: "Clique para classificar em ordem decrescente",
	sortingState: "${0} - ${1}",
	unsorted: "Não classificar esta coluna",
	indirectSelectionRadio: "Linha ${0}, seleção única, caixa de opção",
	indirectSelectionCheckBox: "Linha ${0}, seleção múltipla, caixa de seleção",
	selectAll: "Selecionar todos"
})
