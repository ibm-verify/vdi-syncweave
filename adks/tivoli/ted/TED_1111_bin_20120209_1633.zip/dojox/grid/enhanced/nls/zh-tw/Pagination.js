({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${0} 之 ${1} - ${2} 個項目",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 之 1 - 1 個項目",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} 項目",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 項目",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 項目",	//Used when row count is zero
	"firstTip": "首頁",
	"lastTip": "末頁",
	"nextTip": "下一頁",
	"prevTip": "上一頁",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "頁面 ${0}",
	"pageSizeLabelTemplate": "每頁 ${0} 個項目",
	"allItemsLabelTemplate": "所有項目",
	"gotoButtonTitle": "跳至特定的頁面",
	"dialogTitle": "跳至頁面",
	"dialogIndication": "指定頁碼",
	"pageCountIndication": " （${0} 頁）",
	"dialogConfirm": "執行",
	"dialogCancel": "取消",
	"all": "全部"
})
