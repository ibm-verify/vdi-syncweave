({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "بند/بنود ${1} - ${2} من ${0}",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "البند 1 - 1 من 1 ",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} بند/بنود",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "بند 1 ",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "بند 0",	//Used when row count is zero
	"firstTip": "الصفحة الأولى",
	"lastTip": "الصفحة الأخيرة",
	"nextTip": "الصفحة التالية",
	"prevTip": "الصفحة السابقة",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "الصفحة ${0}",
	"pageSizeLabelTemplate": "${0} بند/بنود بكل صفحة",
	"allItemsLabelTemplate": "كل البنود",
	"gotoButtonTitle": "اذهب الى الصفحة المحددة",
	"dialogTitle": "اذهب الى الصفحة",
	"dialogIndication": "حدد رقم الصفحة",
	"pageCountIndication": " (${0} صفحات)",
	"dialogConfirm": "بدء",
	"dialogCancel": "الغاء",
	"all": "كل"
})
