({
	singleSort: "Простая сортировка",
	nestedSort: "Вложенная сортировка",
	ascending: "Щелкните для сортировки по восходящей",
	descending: "Щелкните для сортировки по нисходящей",
	sortingState: "${0} - ${1}",
	unsorted: "Не сортировать этот столбец",
	indirectSelectionRadio: "Строка ${0}, один выбор, радиокнопка",
	indirectSelectionCheckBox: "Строка ${0}, несколько выборов, переключатель",
	selectAll: "Выбрать все"
})

