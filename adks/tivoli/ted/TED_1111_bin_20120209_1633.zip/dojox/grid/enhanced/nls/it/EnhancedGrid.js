({
	singleSort: "Ordine singolo",
	nestedSort: "Ordine nidificato",
	ascending: "Fare clic per ordinare in ordine Ascendente",
	descending: "Fare clic per ordinare in ordine Discendente",
	sortingState: "${0} - ${1}",
	unsorted: "Non ordinare questa colonna",
	indirectSelectionRadio: "Riga ${0}, selezione singola, casella di opzione",
	indirectSelectionCheckBox: "Riga ${0}, selezione multipla, casella di spunta",
	selectAll: "Seleziona tutto"
})
