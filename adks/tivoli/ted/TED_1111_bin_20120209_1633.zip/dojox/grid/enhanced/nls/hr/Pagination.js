({
	// ${0}: number
	//		total number of all items
	// ${1}: number
	//		start item index of current page
	// ${2}: number
	//		end item index of current page
	// example:
	//		the total number is 200, the unit of item is "items"
	//		rows per page is 20, current page is 1, then the description
	//		would be looked as below:
	//	|	1 - 20 of 200 items 
	"descTemplate": "${1} - ${2} od ${0} stavki",	//Used when pagination is enabled and row count is larger than 1
	"descSingleTemplate": "1 - 1 od 1 stavke",	//Used when pagination is enabled and row count is 1
	"descAllTemplate": "${0} stavki",	//Used when pagination is disabled ('all' mode) and row count is larger than 1
	"descSingleAllTemplate": "1 stavka",	//Used when pagination is disabled ('all' mode) and row count is 1
	"descEmptyTemplate": "0 stavki",	//Used when row count is zero
	"firstTip": "Prva stranica",
	"lastTip": "Zadnja stranica",
	"nextTip": "Sljedeća stranica",
	"prevTip": "Prethodna stranica",
//These two are no longer necessary...
//    "itemTitle": "items",
//    "singularItemTitle": "item",
	"pageStepLabelTemplate": "Strana ${0}",
	"pageSizeLabelTemplate": "${0} stavki po stranici",
	"allItemsLabelTemplate": "Sve stavke",
	"gotoButtonTitle": "Idi na određenu stranicu",
	"dialogTitle": "Idi na stranicu",
	"dialogIndication": "Navedite broj stranice",
	"pageCountIndication": " (${0} stranica)",
	"dialogConfirm": "Kreni",
	"dialogCancel": "Opoziv",
	"all": "Sve"
})

