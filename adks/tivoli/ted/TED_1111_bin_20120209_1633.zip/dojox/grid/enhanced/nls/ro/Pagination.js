({
	"descTemplate": "${2} - ${3} din ${1} ${0}",
	"firstTip": "Prima pagină",
	"lastTip": "Ultima pagină",
	"nextTip": "Următoarea pagină",
	"prevTip": "Pagina anterioarp",
	"itemTitle": "articole",
	"pageStepLabelTemplate": "Pagina ${0}",
	"pageSizeLabelTemplate": "${0} articole pe pagină",
	"allItemsLabelTemplate": "Toate articolele",
	"gotoButtonTitle": "Deplasare la o pagină anumită",
	"dialogTitle": "Deplasare la pagină",
	"dialogIndication": "Specificaţi numărul de pagină",
	"pageCountIndication": " (${0} pagini)",
	"dialogConfirm": "Deplasare",
	"dialogCancel": "Anulare",
	"all": "toate"
})

