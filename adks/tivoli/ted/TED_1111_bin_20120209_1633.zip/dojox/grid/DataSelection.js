dojo.provide("dojox.grid.DataSelection");
dojo.require("dojox.grid.Selection");
dojo.require("dojo.DeferredList");
dojo.require("dojox.grid.enhanced.plugins._SelectionPreserver");

dojo.declare("dojox.grid.DataSelection", dojox.grid.Selection, {
	constructor: function(grid){
		if(grid.keepSelection){
			this.preserver = new dojox.grid.enhanced.plugins._SelectionPreserver(this);
		}
	},
	
	destroy: function(){
		if(this.preserver){
			this.preserver.destroy();
		}
	},
	
	getFirstSelected: function(){
		var idx = dojox.grid.Selection.prototype.getFirstSelected.call(this);

		if(idx == -1){ return null; }
		return this.grid.getItem(idx);
	},

	getNextSelected: function(inPrev){
		var old_idx = this.grid.getItemIndex(inPrev);
		var idx = dojox.grid.Selection.prototype.getNextSelected.call(this, old_idx);

		if(idx == -1){ return null; }
		return this.grid.getItem(idx);
	},

	getSelected: function(){
		var result = [];
		for(var i=0, l=this.selected.length; i<l; i++){
			if(this.selected[i]){
				result.push(this.grid.getItem(i));
			}
		}
		return result;
	},
	
	getSelectedItems: function(pageSize){
			// summary:
			//		This function is an asynchronous implementation of getSelected().
			//		Unlike getSelected, we won't get any null values in the result of this function.
			// pageSize: Integer
			//		To load all selected rows, the grid needs to fetch a lot of data. So it is necessary
			//		to break a huge request into several small requests, so as not to hold up the browser
			//		for too long.
			//		This pageSize parameter is used to specifiy how many rows to fetch in one request.
			//		If not provided or equal to zero, grid.rowsPerPage is used.
			//		If less than zero, then there will be no upper limit to the request size.
			//		If client side store is used, it is recommented to provide a negative pageSize such as -1.
			// return: Deferred Object
			//		The Deferred object representing the result item array.
			// example:
			// |	grid.selection.getSelectedItems().then(function(items){
			// |		//We get all the selected items here.
			// |	});
			var res = [], d = new dojo.Deferred(), defs = [],
				start, i, len, item, toFetch = [], 
				grid = this.grid, _this = this, 
				ps = pageSize || grid.rowsPerPage,
				//Prepare the constant options.
				options = {
					query: grid.query,
					sort: grid.getSortProps(),
					queryOptions: grid.queryOptions,
					onError: dojo.hitch(d, d.errback)
				},
				onComplete = function(def, start, items){
					//Save the fetched items to the result array.
					for(var i = 0, len = items.length; i < len; ++i){
						res[toFetch[start] + i] = items[i];
					}
					def.callback();
				};
			for(i = 0, len = this.selected.length; i < len; ++i){
				if(this.selected[i]){
					item = grid._by_idx[i];
					res[i] = item && item.item;
					if(!item){
						toFetch.push(i);
					}
				}
			}
			for(start = 0, len = toFetch.length; start < len; start = i){
				//Find how many items can we get by one fetch.
				for(i = start + 1; 
						i < len &&
						toFetch[i] === toFetch[i - 1] + 1 &&	//Ensure the item indexes are continuous
						ps < 0 || i - start < ps;		//Paging the request, so we can handle huge stores. 
					++i){}
				var def = new dojo.Deferred();
				var req = dojo.mixin({
					start: toFetch[start],
					count: i - start,
					onComplete: dojo.partial(onComplete, def, start)
				}, options);
				defs.push(def);
				//Check whether we are using EDG
				if(grid._storeLayerFetch){
				    grid._storeLayerFetch(req);
				}else{
				    grid.store.fetch(req);
				}
			}
			(new dojo.DeferredList(defs)).then(function(){
				res = dojo.filter(res, function(item){
					return item;
				});
				if(_this.preserver){
					//Since the grid is paged, some previously selected rows may not be loaded after
					//sorting or filtering, etc. So get these rows from selectedById.
					//Note: the row order can not be honored here! 
					var id, dl = [],
						onItem = function(defer, item){
							res.push(item);
							defer.callback();
						},
						selectedIds = dojo.map(res, function(item){
							return grid.store.getIdentity(item);
						});
					for(id in _this.preserver._selectedById){
						if(_this.preserver._selectedById[id] === true && dojo.indexOf(selectedIds, id) < 0){
							var dd = new dojo.Deferred();
							grid.store.fetchItemByIdentity({
								identity: id,
								onItem: dojo.partial(onItem, dd)
							});
							dl.push(dd);
						}
					}
					if(dl.length){
						(new dojo.DeferredList(dl)).then(function(){
							//Get back to the user.
							d.callback(res);
						});
						return;
					}
				}
				//Get back to the user.
				d.callback(res);
			}, dojo.hitch(d, d.errback));
			return d;
		},

	addToSelection: function(inItemOrIndex){
		if(this.mode == 'none'){ return; }
		var idx = null;
		if(typeof inItemOrIndex == "number" || typeof inItemOrIndex == "string"){
			idx = inItemOrIndex;
		}else{
			idx = this.grid.getItemIndex(inItemOrIndex);
		}
		dojox.grid.Selection.prototype.addToSelection.call(this, idx);
	},

	deselect: function(inItemOrIndex){
		if(this.mode == 'none'){ return; }
		var idx = null;
		if(typeof inItemOrIndex == "number" || typeof inItemOrIndex == "string"){
			idx = inItemOrIndex;
		}else{
			idx = this.grid.getItemIndex(inItemOrIndex);
		}
		dojox.grid.Selection.prototype.deselect.call(this, idx);
	},

	deselectAll: function(inItemOrIndex){
		var idx = null;
		if(inItemOrIndex || typeof inItemOrIndex == "number"){
			if(typeof inItemOrIndex == "number" || typeof inItemOrIndex == "string"){
				idx = inItemOrIndex;
			}else{
				idx = this.grid.getItemIndex(inItemOrIndex);
			}
			dojox.grid.Selection.prototype.deselectAll.call(this, idx);
		}else{
			this.inherited(arguments);
		}
	}
});
