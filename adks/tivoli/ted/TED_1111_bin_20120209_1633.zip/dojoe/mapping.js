/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.mapping"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.mapping"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.mapping");

//dojo.provide("ibm.tivoli.table.TivTable");
//dojo.require("dojoe.table.Table");

//dojo.provide("ibm.tivoli.table.plugins.GridFilter");
dojo.provide("dojoe.table.plugins.GridFilter");
dojo.require("dojox.grid.enhanced.plugins.Filter");

//dojo.provide("ibm.tivoli.table.plugins.IndirectSelection");
dojo.provide("dojoe.table.plugins.IndirectSelection");
dojo.require("dojox.grid.enhanced.plugins.IndirectSelection");

//dojo.provide("ibm.tivoli.table.plugins.NestedSorting");
dojo.provide("dojoe.table.plugins.NestedSorting");
dojo.require("dojox.grid.enhanced.plugins.NestedSorting");

//dojo.provide("ibm.tivoli.table.plugins.Menu");
dojo.provide("dojoe.table.plugins.Menu");
dojo.require("dojox.grid.enhanced.plugins.Menu");

//dojo.provide("ibm.tivoli.table.plugins.DnD");
dojo.provide("dojoe.table.plugins.DnD");
dojo.require("dojox.grid.enhanced.plugins.DnD");

//dojo.provide("ibm.tivoli.table.plugins.AutoScroll");
dojo.provide("dojoe.table.plugins.AutoScroll");
dojo.require("dojox.grid.enhanced.plugins.AutoScroll");

//dojo.provide("ibm.tivoli.table.plugins.Selector");
dojo.provide("dojoe.table.plugins.Selector");
dojo.require("dojox.grid.enhanced.plugins.Selector");

//dojo.provide("ibm.tivoli.table.plugins.Cookie");
dojo.provide("dojoe.table.plugins.Cookie");
dojo.require("dojox.grid.enhanced.plugins.Cookie");

//dojo.provide("ibm.tivoli.table.plugins.GridSource");
dojo.provide("dojoe.table.plugins.GridSource");
dojo.require("dojox.grid.enhanced.plugins.GridSource");

//dojo.provide("ibm.tivoli.table.plugins.CellFormatter");
//Latha : 17 Mar 2011 As CellFormatter is removed from ORIA Patch.
//dojo.provide("dojoe.table.plugins.CellFormatter");
//dojo.require("dojox.grid.enhanced.plugins.CellFormatter");

//dojo.provide("ibm.tivoli.table.plugins.Search");
dojo.provide("dojoe.table.plugins.Search");
dojo.require("dojox.grid.enhanced.plugins.Search");

//dojo.provide("ibm.tivoli.table.plugins.filter.FilterParser");
//dojo.require("dojox.grid.enhanced.plugins.filter.FilterParser");
//dojo.provide("ibm.tivoli.table.plugins.AdvancedSearch");
//dojo.require("dojox.grid.enhanced.plugins.AdvancedSearch");

//dojo.provide("ibm.tivoli.table.plugins.exporter.CSVWriter");
dojo.provide("dojoe.table.plugins.exporter.CSVWriter");
dojo.require("dojox.grid.enhanced.plugins.exporter.CSVWriter");

//dojo.provide("ibm.tivoli.table.plugins.Printer");
dojo.provide("dojoe.table.plugins.Printer");
dojo.require("dojox.grid.enhanced.plugins.Printer");

//dojo.provide("ibm.tivoli.table.plugins.Pagination");
dojo.provide("dojoe.table.plugins.Pagination");
dojo.require("dojox.grid.enhanced.plugins.Pagination");

//dojo.provide("ibm.tivoli.treetable.TivTreeTable");
//20605: TED dojoe mapping.js is mistakenly loading TreeTable
//Bobby:25May11, removing TreeTable require
//dojo.require("dojoe.treetable.TreeTable");

// summary:
//	 	Maps an old widget name to a new widget name.
//		Need to dojo.provide the old widget name and dojo.require the new widget name.
//		The old widget need not be physically located in the dojo release, but the new widget must be present at a desired location.
(function(){
	//dojo.setObject("ibm.tivoli.table.plugins.GridFilter", dojox.grid.enhanced.plugins.Filter);
	dojo.setObject("dojoe.table.plugins.GridFilter", dojox.grid.enhanced.plugins.Filter);
	//dojo.setObject("ibm.tivoli.table.plugins.IndirectSelection", dojox.grid.enhanced.plugins.IndirectSelection);
	dojo.setObject("dojoe.table.plugins.IndirectSelection", dojox.grid.enhanced.plugins.IndirectSelection);
	//dojo.setObject("ibm.tivoli.table.plugins.NestedSorting", dojox.grid.enhanced.plugins.NestedSorting);
	dojo.setObject("dojoe.table.plugins.NestedSorting", dojox.grid.enhanced.plugins.NestedSorting);
	//dojo.setObject("ibm.tivoli.table.plugins.Menu", dojox.grid.enhanced.plugins.Menu);
	dojo.setObject("dojoe.table.plugins.Menu", dojox.grid.enhanced.plugins.Menu);

	//dojo.setObject("ibm.tivoli.table.plugins.DnD", dojox.grid.enhanced.plugins.DnD);
	dojo.setObject("dojoe.table.plugins.DnD", dojox.grid.enhanced.plugins.DnD);
	//dojo.setObject("ibm.tivoli.table.plugins.AutoScroll", dojox.grid.enhanced.plugins.AutoScroll);
	dojo.setObject("dojoe.table.plugins.AutoScroll", dojox.grid.enhanced.plugins.AutoScroll);
	//dojo.setObject("ibm.tivoli.table.plugins.Selector", dojox.grid.enhanced.plugins.Selector);
	dojo.setObject("dojoe.table.plugins.Selector", dojox.grid.enhanced.plugins.Selector);
	//dojo.setObject("ibm.tivoli.table.plugins.Cookie", dojox.grid.enhanced.plugins.Cookie);
	dojo.setObject("dojoe.table.plugins.Cookie", dojox.grid.enhanced.plugins.Cookie);

	//dojo.setObject("ibm.tivoli.table.plugins.GridSource", dojox.grid.enhanced.plugins.GridSource);
	dojo.setObject("dojoe.table.plugins.GridSource", dojox.grid.enhanced.plugins.GridSource);

	//dojo.setObject("ibm.tivoli.table.plugins.CellFormatter", dojox.grid.enhanced.plugins.CellFormatter);
	dojo.setObject("dojoe.table.plugins.CellFormatter", dojox.grid.enhanced.plugins.CellFormatter);
	//dojo.setObject("ibm.tivoli.table.plugins.Search", dojox.grid.enhanced.plugins.Search);
	dojo.setObject("dojoe.table.plugins.Search", dojox.grid.enhanced.plugins.Search);
	
	//dojo.setObject("ibm.tivoli.table.plugins.exporter.CSVWriter", dojox.grid.enhanced.plugins.exporter.CSVWriter);
	dojo.setObject("dojoe.table.plugins.exporter.CSVWriter", dojox.grid.enhanced.plugins.exporter.CSVWriter);
	//dojo.setObject("ibm.tivoli.table.plugins.Printer", dojox.grid.enhanced.plugins.Printer);
	dojo.setObject("dojoe.table.plugins.Printer", dojox.grid.enhanced.plugins.Printer);
	//dojo.setObject("ibm.tivoli.table.plugins.Pagination", dojox.grid.enhanced.plugins.Pagination);
	dojo.setObject("dojoe.table.plugins.Pagination", dojox.grid.enhanced.plugins.Pagination);
	
	//dojo.setObject("ibm.tivoli.treetable.TivTreeTable", dojoe.treetable.TreeTable);
    //dojo.setObject("ibm.tivoli.table.TivTable", dojoe.table.Table);	
})();

}
