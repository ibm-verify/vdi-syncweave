/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.wizard.PageContainer"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.wizard.PageContainer"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.wizard.PageContainer");

dojo.require("dijit.layout.BorderContainer");
dojo.require("dijit.layout.StackContainer");
dojo.require("dijit.layout.ContentPane");
dojo.require("dijit.form.Button");
dojo.require("dijit.form._FormMixin");
dojo.require("dojo.i18n");
dojo.requireLocalization("dojoe.wizard", "Wizard", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");

/*
 * Page container use by notebook and wizard widgets.
 *
 * Events:
 *  OnPageSelected: when a page is made active
 *  OnOK: when the Finish/OK button is clicked
 *  OnCancel: when the Cancel button is clicked
 */

dojo.declare("dojoe.wizard.PageContainer", [dijit._Container],
	{
		mode: "",          // "n" for notebook or "w" for wizard (set by subclass)
		layout: "v",       // "vertical" or "horizontal" (actually, anything starting with "v" | "h")
		nested: false,     // contained <form> is used for containerNode (default), if true <div> used instead
		formId: "",        // id of form to submit when container is being nested
		action: ".",       // the action attribute on the contained <form>
		method: "POST",    // the method attribute on the contained <form>
		_pages: null,
		_pageChangeConnections: null,
		_containerSubscriptions: null,
		_origOK: null,
  
		constructor: function () {
			this._origOK = this.OnOK;
			this._pages = [];
			this._pageChangeConnections = {};
			this._containerSubscriptions = [];
		},
		
		postMixInProperties: function() {
			if (this.layout && this.layout.length > 0) {
				this.layout = this.layout.charAt(0).toLowerCase();
			}
			this.inherited(arguments);
		},
		
		buildRendering: function () {
			this.inherited(arguments);
			this._pageContainer.containerNode = this.containerNode;
			this._addFooterButtons();
    
			// if ToC layout is horizontal... 
			if ('h' === this.layout) {
			  // move toc region and update class
			  var child = this._tocArea;
			  this._borderArea.removeChild(child);
			  child.region = "top";
			  child._setClassAttr("tiv-toc-horizontal");
			  this._borderArea.addChild(child, 0);                    
			}
		},
		
		postCreate: function () {
			this.inherited(arguments);
		},
		
		startup: function () {
			if (this._started) { 
				return; 
			}
			this.inherited(arguments);
			this._containerSubscriptions.push(dojo.subscribe(this._pageContainer.id + "-selectChild", this, this._onPageSelected));
			this._containerSubscriptions.push(dojo.subscribe(this._pageContainer.id + "-addChild", this, this._onPageAdded));
			this._containerSubscriptions.push(dojo.subscribe(this._pageContainer.id + "-removeChild", this, this._onPageRemoved));
			// get the pages provided in markup
			this._pages = this._pageContainer.getChildren();
			// save reference to ourselves as an attribute so each page has access
			// must occur before _buildToC
			dojo.forEach(this._pages, this._setContainerType, this);
			// build the initial table of contents from the pages provided in markup
			this._buildToC();
			// Setup each page
			dojo.forEach(this._pages, this._pageContainer._setupChild, this._pageContainer);
			dojo.forEach(this._pages, function (p, i) {
				this._onPageAdded(p, i);
			}, this);
    
			var selectedChild = null;
			dojo.some(this._pages, function (child) {
				if (child.selected) {
					selectedChild = child;
				}
				return child.selected;
			}, this);
			if (!selectedChild && this._pages[0]) {
				selectedChild = this._pages[0];
			}
			if (selectedChild) {
				//The _onPageSelected function wasn't getting called for a selectPage
				//this.selectPage(selectedChild);
				this._onPageSelected(selectedChild);
			}
			this._outerContainer.resize();
		},  
		
		_addFooterButtons: function () {
			// subclass should override
		}, 
		
		_setContainerType: function (page) {
			// subclass should override
		},  
		
		_addToCItemConnections: function (toc_item) {
			// subclass should override
		},
		
		/**
		* submit the contained form
		* wire this function to the OnOK event
		*/
		submit: function (wiz) {
			var _form = (this.nested) ? this.formId : this.id + "_form";
			if ('' === _form) {
				return null;
			}
			// our form is the containerNode
			var f;
			switch (this.method.toLowerCase()) {
				case "get":
				f = dojo.xhrGet;
				break;
				case "post":
				f = dojo.xhrPost;
				break;
				case "put":
				f = dojo.xhrPut;
				break;
				default:
				f = dojo.xhrPost;
			}
			var dfd = f({
				url: this.action,
				preventCache: true,
				form: _form, 
				load: function (response) {
				},
				error: function(response) {
				}
			});
			return dfd;
		},
		
		_buildToC: function () {
			if (this._toc) {    
				while (this._toc.firstChild) {
					this._toc.removeChild(this._toc.firstChild);
				}
				var page_count = this._pages.length;
				dojo.forEach(this._pages, function (p, i) {
					var toc_item = p.buildTOCRendring();
					if (toc_item != null) {
						dojo.place(toc_item, this._toc, "last");
						this._addToCItemConnections(toc_item);
					}
				}, this);    
			}
		},
		
		destroy: function () {
			var alerter;
			while (alerter = this._containerSubscriptions.pop()) {
				dojo.unsubscribe(alerter);
			}
			var p;
			for(p in this._pageChangeConnections) {
				dojo.disconnect(this._pageChangeConnections[p]);
			}
			this.inherited(arguments);
		},
		
		destroyRecursive: function () {
			this.inherited(arguments);
		},
		
		selectPage: function (p) {	//p is a widget
			this._pageContainer.selectChild(p);
		},
		
		addPage: function (p) {	//p is a widget
			this._setContainerType(p);
			this._pageContainer.addChild(p);
			this._pages = this._pageContainer.getChildren();
			this._buildToC();
			this.updateUI();
		}, 
		
		removePage: function (p) {	//p is a widget
			// If removing selected page, StackContainer will select next
			// page by default.
			this._pageContainer.removeChild(p);
			this._pages = this._pageContainer.getChildren();
			this._buildToC();
			this.updateUI();
		}, 
		
		updateUI: function () {
			var curr_page = this._pageContainer.selectedChildWidget;
			if (curr_page!=null) {
				// update the ToC
				if (this._toc) {
					dojo.query("li[pageID]", this._toc).forEach(function (n, i) {
						var pid = dojo.attr(n, "pageID");
						var p = dijit.byId(pid);
						if (p.visited) {
							dojo.query("a",n).forEach(function (a) {
								a.setAttribute("title","visited");
							},this);
						}
						dojo[(p && p.visited) ? "addClass" : "removeClass"](n, "tiv-page-visited");
						dojo[(p && (!p.visited || p.validated)) ? "removeClass" : "addClass"](n, "tiv-page-invalid");
						dojo[(p == curr_page) ? "addClass" : "removeClass"](n, "tiv-page-selected");
					});
				}
				//To make the current page visible
				if (curr_page) {
					dojo.removeClass(curr_page.domNode,"dijitHidden");
					dojo.addClass(curr_page.domNode,"dijitVisible");
				}
			}
		},
		
		_onPageSelected: function (page) {
			this.OnPageSelected(this, page);
			if ("function" == typeof page.OnPageSelected) {
				page.OnPageSelected(this);
			}
			this.updateUI();
			// if the page can handle this function
			if ("function" == typeof page.AfterPageSelected) {
				// let the page get final control
				page.AfterPageSelected(this);
			}
		},
		
		_onPageContentChange: function (page) {
			this.updateUI();
		},
		
		_onPageAdded: function (page, insertIndex) {
			this._pageChangeConnections[page.id] = dojo.connect(page, "OnPageContentChange", this, this._onPageContentChange);
			this.updateUI();
		},
		
		_onPageRemoved: function (page) {
			dojo.disconnect(this._pageChangeConnections[page.id]);
			delete this._pageChangeConnections[page.id];
			this.updateUI();
		},
		
		_onClickFinish: function (evt) {
			this.OnOK(this);
		},
		
		_onClickCancel: function (evt) {
			this.OnCancel(this);
		},
		
		// fired events
		OnPageSelected: function (wiz, page) {
			// override or connect to me
		},
		
		OnOK: function (wiz) {
			// override or connect to me
			// if this is still the same function as it was originally,
			// then nobody has connected to the event. do the default
			if (this._origOK === this.OnOK) {
				// nothing connected, do the default
				this.submit(this);
			}
		},
		
		OnCancel: function (wiz) {
			// override or connect to me
		},
  
		/**
		* Enable (or disable) the Finish/OK button
		*/
		enableFinishButton: function (shouldEnable) {
			this._finishButton.attr("disabled", !shouldEnable);
		},

		/** 
		* Enable (or disable) the Cancel button
		*/
		enableCancelButton: function (shouldEnable) {
			this._cancelButton.attr("disabled", !shouldEnable);
		},

		/**
		* Hide (or show) the Finish/OK button
		*/
		hideFinishButton: function (shouldHide) {
			if (shouldHide) {
				dojo.style(this._finishButton.domNode, "display", "none");
			} else {
				dojo.style(this._finishButton.domNode, "display", "inline-block");
			}
		},

		/**
		* Hide (or show) the Cancel button
		*/
		hideCancelButton: function (shouldHide) {
			if (shouldHide) {
			    dojo.style(this._cancelButton.domNode, "display", "none");
			} else {
				dojo.style(this._cancelButton.domNode, "display", "inline-block");
			}
		},
  
		/**
		* Returns the currently selected page
		*/
		getSelectedPage: function () {
			return this._pageContainer.selectedChildWidget; 
		},
  
		/**
		* Resizes this container according to the new dimensions.
		* @param newSize  the new dimensions with properties w for width 
		*                 and h for height
		*/
		resize: function (newSize) {
			if (newSize != null) {
				if (newSize.w != null) {
					dojo.style(this.domNode, 'width', newSize.w + 'px');
				}
				if (newSize.h != null) {
				    dojo.style(this.domNode, 'height', newSize.h + 'px');
				}
				this._outerContainer.resize(newSize);
			}
		}  
	});

}
