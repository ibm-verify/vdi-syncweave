/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.wizard.Page"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.wizard.Page"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.wizard.Page");
dojo.provide("dojoe.wizard.TivSubstep");

dojo.require("dijit._Widget");
dojo.require("dijit._Templated");
dojo.require("dijit.layout.BorderContainer");
dojo.require("dijit.layout.StackContainer");
dojo.require("dijit.layout.ContentPane");
dojo.require("dijit.form.Button");
dojo.require("dijit.form._FormMixin");
dojo.require("dojo.i18n");
dojo.requireLocalization("dojoe.wizard", "Wizard", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");

/**
 * 
 * A page that may be used in both the notebook and wizard widgets.
 * 
 * For the wizard, it handles substeps.
 * 
 */
dojo.declare("dojoe.wizard.Page", [dijit._Widget, dijit.layout._ContentPaneResizeMixin ,dijit._Templated, dijit.form._FormMixin], 
	{
		widgetsInTemplate: true,
		title: "",			// title is show in the ToC
		visited: false,			// has this page been visited?
		validated: false,		// has this page been validated?
		substeps: null,			// collection of substeps for this main step
		substepsList: null,		// ordered list of the substep list items for this main step
		listItem: null,			// list entry
		connectionLink: null,	// its "connect" link
		disabled: false, 
		required: false,
		loops: false,			// if true, this page and substeps form a loop
		titleOnly: false,		// if true and this main step has substeps, main page is never shown; only its
                         

	/**
	* Render the page itself
	*/
		buildRendering: function () {
			this.inherited(arguments);
			// Page subclasses ContentPane, but adds in _Templated, which ContentPane didn't expect
			// we have to fix some stuff.
			dojo.attr(this.domNode, "region", "center");
			this.containerNode = this.domNode;
			dojo.addClass(this.domNode, "tiv-page");
		},

	/**
	* Render this page's entry in the ToC.  The list item is created once. 
	* For wizard, it is used to jump back to the associated page.
	*/
		buildTOCRendring: function () {
			// if the list entry hasn't been created yet
			if (this.listItem == null) {
				// create it
				if (this.wizard == null) {
				// vertical notebook
					this.listItem = dojo.create("li", {
						innerHTML: "<div class='tiv-page-toc-icon'></div><div class='tiv-page-toc-title'>" + this.title + "</div>",
						pageID: this.id,
						className: this.visited ? "tiv-page-visited" : ""
					});        
				} else {
					// wizard
					if ('v' === this.wizard.layout) {
						// vertical toc
						this.listItem = dojo.create("li", {
							innerHTML: "<span class='tiv-page-toc-icon'></span><span class='tiv-page-required-flag'></span>" + "<span class='tiv-page-toc-title'>" + this.title + "</span>",
							pageID: this.id,
							className: this.visited ? "tiv-page-visited" : ""
						});        
					} else {
						// horizontal toc
						if (this.isMainStep()) {
							if (!this.wizard.renderNoArrows) {
								// onlick function is needed so link is not followed
								// link wraps entire arrow for tabbing
								this.listItem = dojo.create("li", {
									innerHTML: "<a href='#' onclick='return false;'><i></i><span><em></em>" + this.title + "</span><b></b></a>",
									pageID: this.id,
									className: this.visited ? "tiv-page-visited" : ""
								});
							} else {
								// render without arrow graphics like substeps 
								// required flag is applicable
								this.listItem = dojo.create("li", {
									innerHTML: "<a href='#' onclick='return false;'><span class='tiv-page-toc-title'><em></em>" + this.title + "</span></a>",
									pageID: this.id,
									className: this.visited ? "tiv-page-visited" : ""
								});                      
							}              
						} else {
							// substep
							this.listItem = dojo.create("li", {
								innerHTML: "<div class='tiv-page-toc-title'>" + this.title + "</div>",
								pageID: this.id,
								className: this.visited ? "tiv-page-visited" : ""
							});        
						}
					}
					// if this is a disabled page, mark it
					if (this.disabled) {
						this.setDisabled(true);
					} else {
						// connect it to this page
						this.connectionLink = dojo.connect(this.listItem, "onclick", this, this.jumpBack);
					}
					// if this is a required page, mark it
					if (this.required) {
						this.setRequired(true);      
					}
				}        
			}
			return this.listItem;
		},

		/**
		* This is always true; substeps return false.
		*/
		isMainStep: function () {
			return (true);
		},
  
		/**
		* Return true if page has substeps
		*/
		hasSubsteps: function () {
			if (this.substeps != null && this.substeps.length > 0) {
				return (true);
			} else {
				return (false);
			}
		},
  
		/**
		* Return ordered list of substep item entries
		*/
		getSubstepsList: function () {
			return this.substepsList;
		},

		/** 
		* Return true if the page is disabled
		*/
		isDisabled: function () {
			return (this.disabled);
		},

		/** 
		* Enable or disable a page
		*/
		setDisabled: function (aBoolean) {
			this.disabled = aBoolean;
			if (this.disabled) {
				dojo.addClass(this.listItem, "tiv-page-disabled");
			} else {
				dojo.removeClass(this.listItem, "tiv-page-disabled"); 
			}
		},

		/**
		* Turn on or off the "required" flag, which adds or removes a class
		* that controls the display of an icon.
		*/
		setRequired: function (aBoolean) {
			this.required = aBoolean;
			if (this.required) {
				dojo.addClass(this.listItem, "tiv-page-required");
			} else {
				dojo.removeClass(this.listItem, "tiv-page-required");
			}
			// need to update UI to allow for asterisk image
			this.wizard.updateUI();
		},
  
		/**
		* Returns true if step is part of a loop.
		*/
		isPartOfLoop: function () {
			return this.loops;
		},
  
		/**
		* Returns true if this is a main step with substeps and only the
		* title should show in the ToC, i.e. the main page itself is
		* never shown during navigation.
		*/
		showTitleOnly: function () {
			if (this.titleOnly && this.hasSubsteps()) {
				return true;
			} else {
				return false;
			}
		},
  
		/**
		* Indicate that main page should show or not when it contains substeps.
		*/
		setTitleOnly: function (titleOnly) {
			this.titleOnly = titleOnly;
		},

		/**
		* The page may want to validate the data before allowing the user to
		* move back a page.
		* Returning false will block the page container from moving back a page.
		* Putting up a message and moving the focus to the appropriate field
		* is the responsibility of the page.
		*/
		allowBack: function () {
			return (true);
		},

		/**
		* The page may want to validate the data before allowing the user to
		* move to the next page.
		* Returning false will block the page container from moving to the next page.
		* Putting up a message and moving the focus to the appropriate field
		* is the responsibility of the page.
		*/
		allowNext: function () {
			return (true);
		},

		/**
		* The page may want to validate the data before allowing the user to
		* use the "Finish" button.
		* Returning false will block the page container from allowing "Finish"
		* Putting up a message and moving the focus to the appropriate field
		* is the responsibility of the page.
		*/
		allowFinish: function () {
			return (true);
		},

		/**
		* When jumping back to a page, the current page is marked as 
		* visited (or complete).  Override this function and return
		* false to keep the current page as unvisited.
		*/
		allowMarkAsComplete: function () {
			return (true);    
		},
  
		/**
		* Disable jumping back to this page
		*/
		disableJumpBack: function () {
			// if there is a connection link
			if (this.connectionLink != null) {
				// disconnect the handler
				dojo.disconnect(this.connectionLink);
				// set it to null so it won't be used again
				this.connectionLink = null;
			}
			// add the "disabled" class
			dojo.addClass(this.listItem, "tiv-page-disabled");
		},

		/**
		* Enable jump back for the item
		* But not if it is disabled
		*/
		enableJumpBack: function () {
			if (this.disabled == null || this.disabled == false) {
				// if there is no handler set up
				if (this.connectionLink == null) {
					// create the handler
					this.connectionLink = dojo.connect(this.listItem, "onclick", this, this.jumpBack);
					// remove the "disabled" class
					dojo.removeClass(this.listItem, "tiv-page-disabled");
				}
			}
		},

		/**
		* The user wants to jump back to a previously visited page.
		* However, the "onclick" handler is attached when the table of
		* contents list item is created. The cursor will not be the "hand"
		* but the handler will still be called. So a check to see if this
		* page has been visited is made before letting the parent container
		* jump back to this page.
		*/
		jumpBack: function (event) {
			// if this page has been visited
			if (this.visited) {
				// then jump back to it
				this.wizard.jumpBackToPage(this);
			}
		},
  
		/**
		* Add another substep to the collection
		*/
		addSubstep: function (anotherSubstep) {
			if (this.substeps == null) {
				this.substeps = [];
			}
			this.substeps[this.substeps.length] = anotherSubstep;
		},

		/**
		* Returns the substeps for this page
		*/
		getSubsteps: function () {
			return this.substeps;
		},

		/**
		* Hide any substeps that this main step might have
		*/
		hideSubsteps: function () {
			// if there are any substeps
			if (this.substeps != null) {
				// if vertical toc
				if ('v' === this.wizard.layout) {
					// do for all substeps
					var i;
					for (i = 0; i < this.substeps.length; i++) {
						// get the table of contents entry
						var tocEntry = this.substeps[i].buildTOCRendring();
						// and hide it
						dojo.style(tocEntry, "display", "none");
					}
				} else {
					// horizontal mode
					if (this.wizard.tocSubstepsArea.childNodes.length > 0) {
						// remove substeps list
						this.wizard.tocSubstepsArea.removeChild(this.substepsList);
					}
				}
			}
		},
  
		/**
		* Show any substeps that this main step might have
		*/
		showSubsteps: function () {
			// if there are any substeps
			if (this.substeps != null) {
				// if vertical toc
				if (this.wizard == null || 'v' === this.wizard.layout) {
					// do for all substeps
					var i;
					for (i = 0; i < this.substeps.length; i++) {
						// get the table of contents entry
						var tocEntry = this.substeps[i].buildTOCRendring();
						// and make it visible
						dojo.style(tocEntry, "display", "block");
					}
				} else {
					// horizontal mode - add substeps ordered list to substeps area
					this.wizard.tocSubstepsArea.appendChild(this.substepsList);
				}
			}    
		},

		/**
		* Mark everything up to this page as having been visited
		*/
		markPreviousPagesVisited: function () {
			this.wizard.markPreviousPagesVisited(this);
		},

		// dijit.form._FormMixin will walk through all the child widgets checking their validity,
		// if you need to do something else, override
		isValid: function () {
			this.validated = this.inherited(arguments); 
			return this.validated;
		},
		
		// same as isValid, but moves focus to the first invalid child widget
		validate: function () {
			this.validated = this.inherited(arguments);
			return this.validated;
		},

		/**
		* Slightly different because substeps might be involved.
		* When a main step becomes the selected page all of its substeps
		* should be made visible.
		*/
		OnPageSelected: function (wiz) {
			// show substeps if there are any...
			if (this.wizard) {
			    this.showSubsteps();
			}
		},
  
		/**
		* catch OnChange events from my child widgets,
		* then let listeners know something's changed
		*/
		_onPageContentChange: function (evt) {
			this.OnPageContentChange(this);
		},
  
		OnPageContentChange: function (page) {
			// override or connect to me
		}
	});

/**
 * An extension that is a substep
 */
dojo.declare("dojoe.wizard.TivSubstep", [dojoe.wizard.Page], 
	{
		mainPage: null,  // main page for this substep
		
		constructor: function (args) {
		},

		isMainStep: function () {
			return (false);
		},
  
		isPartOfLoop: function () {
			if (this.mainPage.isPartOfLoop()) {
				return (true);
			} else {
				return (false);
			}
		},
  
		/**
		* Nested substeps are not supported
		*/
		hasSubsteps: function () {
			return (false);
		},
  
		getMainPage: function () {
			return (this.mainPage);
		},
  
		/** 
		* These items are created with some minor differences in how they are
		* displayed
		*/
		buildTOCRendring: function () {
			var listItemToAdd = this.listItem;
			// if the list entry hasn't been created yet
			if (this.listItem == null) {
				// create it
				this.inherited(arguments);
				// save main page for this substep
				this.mainPage = this.wizard.getPreviousMainPage(this);
				// if vertical toc
				if ('v' === this.wizard.layout) {
					listItemToAdd = this.listItem;
					// make it invisible
					dojo.style(this.listItem, "display", "none");
					// and indented
					dojo.addClass(this.listItem, "tiv-wiz-toc-substep");
				} else {
					// horizontal mode - add to substep list of main page
					listItemToAdd = null;
					if (this.mainPage != null) {
						if (this.mainPage.substepsList == null) {
							this.mainPage.substepsList = dojo.create("ol", {});
						}
						this.mainPage.substepsList.appendChild(this.listItem);
					}        
				}
			}
			return listItemToAdd;
		}
	});


}
