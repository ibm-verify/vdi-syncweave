/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Hayır","PREVIOUS":"Önceki","CANCEL":"İptal","CANCEL_MSG":"Değişiklikleri iptal edip kapatmak istiyor musunuz?","FINISH":"Son","NEXT":"İleri","BACK":"Geri","CONFIRM_YES":"Evet","FINISH_MSG":"Değişiklikleri uygulayıp kapatmak istiyor musunuz?"})