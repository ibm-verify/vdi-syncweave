/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Não","PREVIOUS":"Anterior","CANCEL":"Cancelar","CANCEL_MSG":"Você deseja cancelar as alterações e fechar?","FINISH":"Concluir","NEXT":"Avançar","BACK":"Voltar","CONFIRM_YES":"Sim","FINISH_MSG":"Você deseja aplicar as alterações e fechar?"})