/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nie","PREVIOUS":"Wstecz","CANCEL":"Anuluj","CANCEL_MSG":"Czy chcesz anulować zmiany i zamknąć?","FINISH":"Zakończ","NEXT":"Dalej","BACK":"Wstecz","CONFIRM_YES":"Tak","FINISH_MSG":"Czy chcesz zastosować zmiany i zamknąć?"})