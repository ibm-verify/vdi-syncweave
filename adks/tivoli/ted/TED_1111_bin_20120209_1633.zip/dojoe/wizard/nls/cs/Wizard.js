/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Ne","PREVIOUS":"Předchozí","CANCEL":"Storno","CANCEL_MSG":"Chcete zrušit změny a provést zavření?","FINISH":"Dokončit","NEXT":"Další","BACK":"Zpět","CONFIRM_YES":"Ano","FINISH_MSG":"Chcete použít změny a provést zavření?"})