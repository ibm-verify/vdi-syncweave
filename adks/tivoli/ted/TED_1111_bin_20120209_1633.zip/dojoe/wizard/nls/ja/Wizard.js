/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"いいえ","PREVIOUS":"前へ","CANCEL":"キャンセル","CANCEL_MSG":"変更を取り消してから閉じますか?","FINISH":"完了","NEXT":"次へ","BACK":"戻る","CONFIRM_YES":"はい","FINISH_MSG":"変更を適用してから閉じますか?"})