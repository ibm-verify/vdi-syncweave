/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Ei","PREVIOUS":"Edellinen","CANCEL":"Peruuta","CANCEL_MSG":"Haluatko peruuttaa muutokset ja sulkea ikkunan?","FINISH":"Lopeta","NEXT":"Seuraava","BACK":"Takaisin","CONFIRM_YES":"Kyllä","FINISH_MSG":"Haluatko ottaa muutokset käyttöön ja sulkea ikkunan?"})