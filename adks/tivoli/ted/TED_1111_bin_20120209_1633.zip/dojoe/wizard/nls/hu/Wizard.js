/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nem","PREVIOUS":"Előző","CANCEL":"Mégse","CANCEL_MSG":"Visszavonja a módosításokat, és bezárja az ablakot?","FINISH":"Befejezés","NEXT":"Tovább","BACK":"Vissza","CONFIRM_YES":"Igen","FINISH_MSG":"Alkalmazza a módosításokat, és bezárja az ablakot?"})