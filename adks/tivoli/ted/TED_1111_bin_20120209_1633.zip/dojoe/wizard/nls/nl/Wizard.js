/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nee","PREVIOUS":"Vorige","CANCEL":"Annuleren","CANCEL_MSG":"Wilt u de wijzigingen annuleren en afsluiten?","FINISH":"Voltooien","NEXT":"Volgende","BACK":"Terug","CONFIRM_YES":"Ja","FINISH_MSG":"Wilt u de wijzigingen toepassen en afsluiten?"})