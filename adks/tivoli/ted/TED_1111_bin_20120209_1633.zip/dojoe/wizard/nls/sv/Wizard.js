/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nej","PREVIOUS":"Föregående","CANCEL":"Avbryt","CANCEL_MSG":"Vill du avbryta ändringarna och stänga? ","FINISH":"Slutför","NEXT":"Nästa","BACK":"Tillbaka","CONFIRM_YES":"Ja","FINISH_MSG":"Vill du tillämpa ändringarna och stänga? "})