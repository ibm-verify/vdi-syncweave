/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"否","PREVIOUS":"上一页","CANCEL":"取消","CANCEL_MSG":"是否要取消更改并关闭？","FINISH":"完成","NEXT":"下一步","BACK":"上一步","CONFIRM_YES":"是","FINISH_MSG":"是否要应用更改并关闭？"})