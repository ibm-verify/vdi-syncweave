/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"아니오","PREVIOUS":"이전","CANCEL":"취소","CANCEL_MSG":"이 변경을 취소하고 닫으시겠습니까?","FINISH":"완료","NEXT":"다음","BACK":"이전","CONFIRM_YES":"예","FINISH_MSG":"이 변경을 적용하고 닫으시겠습니까?"})