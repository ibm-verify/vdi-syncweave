/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nei","PREVIOUS":"Forrige","CANCEL":"Avbryt","CANCEL_MSG":"Vil du lukke uten å ta i bruk endringene?","FINISH":"Fullfør","NEXT":"Neste","BACK":"Tilbake","CONFIRM_YES":"Ja","FINISH_MSG":"Vil du ta i bruk endringene og lukke?"})