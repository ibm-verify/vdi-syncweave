/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"No","PREVIOUS":"Previous","CANCEL":"Cancel","CANCEL_MSG":"Do you want to cancel the changes and close?","FINISH":"Finish","NEXT":"Next","BACK":"Back","CONFIRM_YES":"Yes","FINISH_MSG":"Do you want to apply the changes and close?"})