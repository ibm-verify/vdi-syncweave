/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"لا","PREVIOUS":"سابق","CANCEL":"الغاء","CANCEL_MSG":"هل تريد الغاء التغييرات والاغلاق؟","FINISH":"انتهاء","NEXT":"تالي","BACK":"للخلف","CONFIRM_YES":"نعم","FINISH_MSG":"هل تريد تطبيق التغييرات والاغلاق؟"})