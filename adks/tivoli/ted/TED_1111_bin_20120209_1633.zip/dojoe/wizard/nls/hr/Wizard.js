/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Ne","PREVIOUS":"Prethodno","CANCEL":"Opoziv","CANCEL_MSG":"Želite li opozvati promjene i zatvoriti?","FINISH":"Završetak","NEXT":"Sljedeće","BACK":"Natrag","CONFIRM_YES":"Da","FINISH_MSG":"Želite li primijeniti promjene i zatvoriti?"})