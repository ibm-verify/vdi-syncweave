/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Non","PREVIOUS":"Précédent","CANCEL":"Annuler","CANCEL_MSG":"Voulez-vous annuler les modifications et fermer ?","FINISH":"Terminer","NEXT":"Suivant","BACK":"Précédent","CONFIRM_YES":"Oui","FINISH_MSG":"Voulez-vous appliquer les modifications et fermer ?"})