/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nein","PREVIOUS":"Zurück","CANCEL":"Abbrechen","CANCEL_MSG":"Änderungen abbrechen und Fenster schließen?","FINISH":"Fertigstellen","NEXT":"Weiter","BACK":"Zurück","CONFIRM_YES":"Ja","FINISH_MSG":"Änderungen anwenden und Fenster schließen?"})