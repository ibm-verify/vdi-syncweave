/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nej","PREVIOUS":"Forrige","CANCEL":"Annullér","CANCEL_MSG":"Vil du annullere ændringerne og lukke?","FINISH":"Afslut","NEXT":"Næste","BACK":"Tilbage","CONFIRM_YES":"Ja","FINISH_MSG":"Vil du anvende ændringerne og lukke?"})