/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"No","PREVIOUS":"Precedente","CANCEL":"Annulla","CANCEL_MSG":"Annullare le modifiche e chiudere?","FINISH":"Fine","NEXT":"Avanti","BACK":"Indietro","CONFIRM_YES":"Sì","FINISH_MSG":"Applicare le modifiche e chiudere?"})