/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"לא","PREVIOUS":"הקודם","CANCEL":"ביטול","CANCEL_MSG":"האם ברצונכם לבטל את השינויים ולסגור?","FINISH":"סיום","NEXT":"הבא","BACK":"חזרה","CONFIRM_YES":"כן","FINISH_MSG":"האם ברצונכם להחיל את השינויים ולסגור?"})