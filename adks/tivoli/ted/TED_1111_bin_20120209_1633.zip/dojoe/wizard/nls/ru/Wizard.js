/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Нет","PREVIOUS":"Предыдущее","CANCEL":"Отмена","CANCEL_MSG":"Отменить изменения и закрыть?","FINISH":"Готово","NEXT":"Далее","BACK":"Назад","CONFIRM_YES":"Да","FINISH_MSG":"Применить изменения и закрыть?"})