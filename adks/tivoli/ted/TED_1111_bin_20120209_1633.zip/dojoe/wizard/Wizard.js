/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.wizard.Wizard"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.wizard.Wizard"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.wizard.Wizard");

dojo.require("dijit._Widget");
dojo.require("dijit._Templated");
dojo.require("dojo.i18n");
dojo.requireLocalization("dojoe.wizard", "Wizard", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");
dojo.require("dojoe.wizard.Page");
dojo.require("dojoe.wizard.TivSubstep");
dojo.require("dojoe.messagedialog.MessageDialog");
dojo.require("dijit.layout.BorderContainer");
dojo.require("dijit.layout.StackContainer");
dojo.require("dijit.layout.ContentPane");

/**
 * Inherit from PageContainer which contains the common functions of both
 * the notebook and wizard.
 */
dojo.require("dojoe.wizard.PageContainer");

/**
 * 
 * This class is an extension of PageContainer that handles all the
 * wizard specific functions as specified in the UI guidelines.  The table
 * of contents layout may be vertical or horizontal.  It also includes the 
 * advanced navigation features such as the ability to have sub-steps, 
 * sub-steps that loop and to jump backwards to a previous page by clicking 
 * on an item in the table of contents.
 * 
 * Extra capabilities that have been added include the ability to skip from 
 * whatever page is displayed to the next main step, enable and disable steps
 * and buttons, hide the button area, indicate a step is required and restart 
 * the wizard. 
 * 
 * Creating a Wizard in markup
 * <div id="note" dojoType="dojoe.wizard.Wizard">
 *    <div dojoType="dojoe.wizard.tests.Pages.Welcome"></div>
 *    <div dojoType="dojoe.wizard.tests.Pages.BaseWidget"></div>
 *    <div dojoType="dojoe.wizard.tests.Pages.General"></div>
 *    <div dojoType="dojoe.wizard.tests.Pages.Security"></div>
 *    <div dojoType="dojoe.wizard.tests.Pages.Summary" ></div>
 *  </div> 
 *
 * Events:
 *  OnPageSelected: when a page is made active
 *  OnBack: when the Back button is clicked
 *  OnNext: when the Next button is clicked
 *  OnOK: when the Finish/OK button is clicked
 *  OnCancel: when the Cancel button is clicked
 */
dojo.declare("dojoe.wizard.Wizard", 
            [dijit._Widget, dijit._Templated, dojoe.wizard.PageContainer], 
	{  

	// summary:  The wizard is used in the context when a user performs infrequent or complex tasks that include a precise series of steps that require the entry of large amounts of interdependent information
	// description: Wizard widget uses the dojoe.wizard.PageContainer for its implementation.
	//		Pages can be created by extending dojoe.wizard.Page.
	
	// widgetsInTemplate: [public]Boolean
	//		Set this to true if the widget contains other widgets
		widgetsInTemplate: true,
	
	// templatePath:  [private]String
	//		Path to the template
		templatePath: "",
	
	// mode:  [private]String
	//		creation mode default is w for wizard
		mode: "w",               
	
	// renderNoArrows: [public]boolean
	//		if true render ToC without arrow graphics, only applicable in horizontal layout. default is false.		
		renderNoArrows: false,   
	
	// slider:  [private]Object
	//		for scrolling ToC, only applicable in horizontal layout
		slider: null,        

	// tocStepsArea:  [private]Object
	//		for main steps of ToC, only applicable in horizontal layout
		tocStepsArea: null,     
	
	// tocSubstepsArea:  [private]Object
	//		for sub steps of ToC, only applicable in horizontal layout
		tocSubstepsArea: null,   
	
	// lastPageSelected:  [private]Object
	//		keep track of the last page that was selected
		lastPageSelected: null, 
	
	// backLabel: [public]String
	//		label of back button.
		backLabel: "",
	
	// nextLabel: [public]String
	//		label of next button.
		nextLabel: "",
	
	// finishLabel: [public]String
	//		label of finish button.
		finishLabel: "",
	
	// cancelLabel: [public]String
	//		label of cancel button.
		cancelLabel: "",
		
	
	// showCancelWarning: [public]boolean
	//		if true renders the confirmation message on click of cancel otherwise confirmation message will not be displayed. Default is false.	
		showCancelWarning: false, //This attribute is added on request of TIP to make the confirmation message display as optional on click of cancel button. 
		
		constructor: function () {
			this._resources = dojo.i18n.getLocalization("dojoe.wizard", "Wizard", this.lang);
		},
  
		postMixInProperties: function () {
			// summary:  Creates and initialises the Wizard.
			// tags: private
  
			if (this.nested) {
				this.templateString="<div class=\"tiv-wiz\" role=\"application\">\r\n  <div dojoType=\"dijit.layout.BorderContainer\" design=\"headline\" gutters=\"false\" class=\"tiv-wiz-outer\" dojoAttachPoint=\"_outerContainer\">\r\n    <div dojoType=\"dijit.layout.BorderContainer\" gutters=\"false\" liveSplitters=\"false\" design=\"sidebar\" region=\"center\" style=\"width:100%;height:100%;\" dojoAttachPoint=\"_borderArea\">\r\n      <div dojoType=\"dijit.layout.ContentPane\" region=\"leading\" splitter=\"false\" class=\"tiv-wiz-toc\" dojoAttachPoint=\"_tocArea\">\r\n        <ol dojoAttachPoint=\"_toc\"></ol>\r\n      </div>\r\n      <div dojoType=\"dijit.layout.StackContainer\" region=\"center\" splitter=\"false\" dojoAttachPoint=\"_pageContainer\" class=\"tiv-wiz-work-area\"> \r\n        <div dojoAttachPoint=\"containerNode\"></div>\r\n      </div>\r\n    </div>\r\n    <div dojoType=\"dijit.layout.ContentPane\" region=\"bottom\" splitter=\"false\" class=\"tiv-wiz-footer\" dojoAttachPoint=\"_buttonArea\">\r\n      <div class=\"tiv-wiz-buttons\" dojoAttachPoint=\"_buttons\">\r\n        <button role=\"button\" type=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickBack\" dojoAttachPoint=\"_backButton\">${backLabel}</button>\r\n        <button role=\"button\" type=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickNext\" dojoAttachPoint=\"_nextButton\">${nextLabel}</button>\r\n        <button role=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickFinish\" dojoAttachPoint=\"_finishButton\">${finishLabel}</button>\r\n        <button role=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickCancel\" dojoAttachPoint=\"_cancelButton\">${cancelLabel}</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n";
			} else {
				this.templateString="<div class=\"tiv-wiz\" role=\"application\">\r\n  <div dojoType=\"dijit.layout.BorderContainer\" design=\"headline\" gutters=\"false\" class=\"tiv-wiz-outer\" dojoAttachPoint=\"_outerContainer\">\r\n    <div dojoType=\"dijit.layout.BorderContainer\" gutters=\"false\" liveSplitters=\"false\" design=\"sidebar\" region=\"center\" style=\"width:100%;height:100%;\" dojoAttachPoint=\"_borderArea\">\r\n      <div dojoType=\"dijit.layout.ContentPane\" region=\"leading\" splitter=\"false\" class=\"tiv-wiz-toc\" dojoAttachPoint=\"_tocArea\">\r\n        <ol dojoAttachPoint=\"_toc\"></ol>\r\n      </div>\r\n      <div dojoType=\"dijit.layout.StackContainer\" region=\"center\" splitter=\"false\" dojoAttachPoint=\"_pageContainer\" class=\"tiv-wiz-work-area\">\r\n        <form id=\"${id}_form\" dojoAttachPoint=\"containerNode\" action=\"${action}\" method=\"${method}\"></form>              \r\n      </div>\r\n    </div>\r\n    <div dojoType=\"dijit.layout.ContentPane\" region=\"bottom\" splitter=\"false\" class=\"tiv-wiz-footer\" dojoAttachPoint=\"_buttonArea\">\r\n      <div class=\"tiv-wiz-buttons\" dojoAttachPoint=\"_buttons\">\r\n        <button role=\"button\" type=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickBack\" dojoAttachPoint=\"_backButton\">${backLabel}</button>\r\n        <button role=\"button\" type=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickNext\" dojoAttachPoint=\"_nextButton\">${nextLabel}</button>\r\n        <button role=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickFinish\" dojoAttachPoint=\"_finishButton\">${finishLabel}</button>\r\n        <button role=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickCancel\" dojoAttachPoint=\"_cancelButton\">${cancelLabel}</button>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n";
			}
			this.backLabel = this._resources.BACK;
			this.nextLabel = this._resources.NEXT;
			this.finishLabel = this._resources.FINISH;
			this.cancelLabel = this._resources.CANCEL;
			this.inherited(arguments);
		},
  
		buildRendering: function () {
			// summary:  Builds and renders the container whenever changes occur.
			// tags: private
		
			this.inherited(arguments);
			// if ToC layout is horizontal... 
			if ('h' === this.layout) {
				var child = this._tocArea;
				// add main step area
				this.tocStepsArea = dojo.create("div", {});          
				dojo.place(this.tocStepsArea, child.domNode, 0);
				if (this.renderNoArrows) {
					dojo.addClass(this.tocStepsArea, "steps-area-noarrows");            
					dojo.place(this._toc, this.tocStepsArea, 0);
				} else {
					dojo.addClass(this.tocStepsArea, "steps-area");            
					// create slider components which are hidden until needed
					this.slider = new dojoe.wizard.WizardToCSlider({
						toc: this._toc, 
						tocSteps: this.tocStepsArea, 
						ltr: this.isLeftToRight()
					}, null);
				}
				// add hidden sub-step area
				this.tocSubstepsArea = dojo.create("div", {className: "substeps-area"});
				dojo.place(this.tocSubstepsArea, child.domNode, 1);          
			}    
		},
  
		_setContainerType: function (page) {
			// summary:  Sets the container type for Wizard
			// tags: private
		
			page.attr("wizard", this);
		},
	  
		updateUI: function () {        
			// summary:  updates UI whenever changes occurs.
			// tags: public
			
			// disable the Back/Next buttons if we are on the first/last page
			var curr_page = this._pageContainer.selectedChildWidget;
			var page_count = this._pages.length;
			if (curr_page != null) {
				var isFirst = true, isLast = true;
				if (page_count > 0) {
					isFirst = curr_page === this._pages[0];
					isLast =  curr_page === this._pages[this._pages.length - 1];
				}
				this._backButton.attr("disabled", isFirst);
				this._nextButton.attr("disabled", isLast);
				// disable the Next button if the selected page does not validate
				var isCurrentPageValid = curr_page && curr_page.isValid(); 
				if (!isCurrentPageValid) {
					this._nextButton.attr("disabled", true);    
				}
				// disable the Finish/OK button until all pages are valid
				var allValid = dojo.every(this._pages, function (p) {
					var v = p.isValid();
					v = v && (p.visited || p === curr_page);
					return v;
				}, this);
				this._finishButton.attr("disabled", !allValid);
				this.inherited(arguments);
				if ('h' === this.layout) {     
					// update UI for all substeps
					// substeps may be hidden due to jump back and need to be updated too
					dojo.forEach(this._pages, function (aPage) {
						if (aPage.hasSubsteps()) {
							dojo.query("li[pageID]", aPage.getSubstepsList()).forEach(function (n, i) {
								var pid = dojo.attr(n, "pageID");
								var p = dijit.byId(pid);
								if (p.visited) {
									dojo.query("a",n).forEach(function (a) {
										a.setAttribute("title","visited");
									},this);
								}
								dojo[(p && p.visited) ? "addClass" : "removeClass"](n, "tiv-page-visited");
								dojo[(p && (!p.visited || p.validated)) ? "removeClass" : "addClass"](n, "tiv-page-invalid");
								dojo[(p == curr_page) ? "addClass" : "removeClass"](n, "tiv-page-selected");                    
							}, this);
						}
					}, this);
		  
					// if current page is a substep update main step to look selected
					if (!curr_page.isMainStep()) {
						var mainPage = curr_page.getMainPage();
						dojo.query("li[pageID]", this._toc).every(function (n, i) {
							var pid = dojo.attr(n, "pageID");
							if (pid == mainPage.id) {
								dojo.addClass(n, "tiv-page-selected");
								return false;
							} else {
								return true;
							}
						});              
					}
					// show or hide substeps area
					var newHeight;
					if (curr_page.hasSubsteps() || !curr_page.isMainStep()) {
						newHeight = this.tocStepsArea.offsetHeight + this.tocSubstepsArea.offsetHeight;
					} else {
						newHeight = this.tocStepsArea.offsetHeight;
					}
					if (dojo.style(this._pageContainer.domNode, "top") != newHeight) {
						dojo.style(this._pageContainer.domNode, "top", newHeight + "px");        
						dojo.style(this._tocArea.domNode, "height", newHeight + "px");
					}
					if (this.slider != null) {
						// calculate required width for all step arrows in ToC
						this.slider.recalcToCWidth();
						// update slider
						this.slider.updateSliderUI(null);      
					}
				}
			}
		},

		resize: function (newSize) {
			// summary:  Overrides base function to also resize the slider.  Resizes the Wizard according to the new dimensions.
			//newSize: array	newSize  is the new dimensions with properties w for width and h for height
			// tags: public
			
			if (newSize != null) {
				this.inherited(arguments);
				if (this.slider && newSize.w != null) {
					//Note: for updating the slider, cannot rely on connecting a handler to the resize event for the _tocArea div.  Problems occur in Firefox where the event is not fired often enough so sometimes the slider button will disappear
					this.slider.updateSliderUI(newSize.w); 
				}
			}
		},
	  
		restartWizard: function () {
			// summary:   Restarts the Wizard
			// tags: public
			
			if (this.slider != null) {
				this.slider.reset();
			}
		
			// the bottom button area might have been hidden
			this.showAllButtons(); //Show the buttons (may have been hidden)
			// individual buttons might have been hidden
			this.hideBackButton(false);
			this.hideNextButton(false);
			this.hideCancelButton(false);
			this.hideFinishButton(false);
			// or maybe disabled
			this.enableNextButton(true);
			this.enableCancelButton(true);
			this.enableFinishButton(false);
			// get all of the children
			var theKids = this._pageContainer.getChildren();
			// do for all children
			var i;
			for (i = 0; i < theKids.length; i++) {
				// mark as not visited
				theKids[i].visited = false; //Remove the "visited" flag
				// hide any kids
				theKids[i].hideSubsteps();	//Collapse substeps
				// if the child supports the "reset" method
				if ("function" == typeof theKids[i].reset) {
					// give the kid a chance to reset
					theKids[i].reset();  //Give each page a chance to reset to the original values
				}
			}
			// the TOC might have been disabled
			this.enableJumpBack();  //Enable jumping backwards (may have been disabled)
			// and then select the first page
			this.selectPage(theKids[0]); //Reset to the first page
		},

		resetFinishLabel: function (newName) {
			// summary:   Resets the label for the "Finish" button
			// tags: public
			
			dojo.attr(this._finishButton, "label", newName);
		},

		markPreviousPagesVisited: function (aPage) {
			// summary:   Marks the  pages as having been visited up to the one specified
			// tags: public
			
			// get all of the children
			var theKids = this._pageContainer.getChildren();
			// do for all children
			var foundPage = false;
			var i;
			for (i = 0; !foundPage && i < theKids.length; i++) {
				// if this is not the page specified
				if (aPage != theKids[i]) {
					// if the kid is not disabled
					if (theKids[i].isDisabled() != true) {
						// mark as visited
						theKids[i].visited = true;
					}
					// else this is the end of the line
				} else {
					// mark as found
					foundPage = true;
				}
			}
		},

		disableJumpBack: function (exceptFor) {
			// summary:   Disable jumping back to every page except for the one specified
			// tags: public
		
			// get all of the children
			var theKids = this._pageContainer.getChildren();
			// do for all children
			var i;
			for (i = 0; i < theKids.length; i++) {
				// if this is not the exception)
				if (exceptFor != theKids[i]) {
					// disable it
					theKids[i].disableJumpBack();
				}
			}
		},

		enableJumpBack: function () {
			// summary:   Enable jumping back to every page
			// tags: public
			
			// get all of the children
			var theKids = this._pageContainer.getChildren();
			// do for all children
			var i;
			for (i = 0; i < theKids.length; i++) {
				// enable it
				theKids[i].enableJumpBack();
			}
		},

		_onPageAdded: function (page, insertIndex) {
			// summary:   When a page is being added it might be a substep. If so it needs to be added to the previous main step
			// tags: private
			
			this.inherited(arguments);
			// if this is a substep
			if (page.isMainStep() == false) {
				// get the substep's main page
				var mainPage = page.getMainPage();
				if (mainPage != null) {
					// add as a substep
					mainPage.addSubstep(page);
				} else {
					// message
					console.error("failed to add substep to main page");
				}
			}
		},
	  
		getPreviousMainPage: function (page) {
			// summary:   Gets the previous main page.  If page is a substep, gets the main page for this substep.  Note the page may be disabled.
			// tags: public
		
			// get the previous page
			var previousPage = this._pageContainer._getSiblingOfChild(page, -1);
			// while the previous page is a substep
			while (previousPage.isMainStep() == false) {
				// get the previous page
				previousPage = this._pageContainer._getSiblingOfChild(previousPage, -1);
			}
		   // if the previous page is a main page
			if (previousPage.isMainStep() == false) {
				previousPage = null;
			}
			return previousPage;
		},
	  
		getNextMainPage: function (page) {
			// summary:   Gets the next main page.  Note the page may be disabled.
			// tags: public
			
			// get the next page
			var nextPage = this._pageContainer._getSiblingOfChild(page, 1);
			// while the next page is a substep
			while (nextPage.isMainStep() == false) {
				// get the next page
				nextPage = this._pageContainer._getSiblingOfChild(nextPage, 1);
			}
			// if the next page is a main page
			if (nextPage.isMainStep() == false) {
				nextPage = null;
			}
			return nextPage;    
		},
		
		jumpToNextLoopStep: function () {
			// summary:   Jumps to the next enabled step in the loop which may be a substep or the main step.
			// tags: public

			var nextPage = null;
			// get the current page
			var tempPage = this.lastPageSelected;
			if (tempPage.isMainStep()) {
				// next step must be a substep so return first enabled substep
				if (tempPage.hasSubsteps()) {
					dojo.every(tempPage.getSubsteps(), function (substep) {
						if (!substep.isDisabled()) {
							nextPage = substep;
							return false;
						} else {
							return true;
						}
					}, this);
				}
			} else {
				// current is a substep, get the next substep
				var nextPossible = this._pageContainer._getSiblingOfChild(tempPage, 1);
				// while the next page is a substep and disabled
				while (nextPossible.isMainStep() == false && nextPossible.isDisabled()) {
					// get the next page
					nextPossible = this._pageContainer._getSiblingOfChild(nextPossible, 1);
				}
				// if next page is a substep save it for selection
				if (nextPossible != null && !nextPossible.isMainStep()) {
					nextPage = nextPossible;
				} else {
					// otherwise next page is a main page, make sure we
					// loop around and load the main page in this loop
					nextPage = tempPage.getMainPage();
				}	
			}
			if (nextPage != null) {
				// select the new page
				this.selectPage(nextPage);
			}
		},
	  
		jumpToPreviousLoopStep: function () {
			// summary:   Jumps to the previous enabled step in the loop which may be a substep or the main step.  Note if the current page is the main step, the jump  will not occur.
			// tags: public
			
			// get the current page
			var tempPage = this.lastPageSelected;
			if (!tempPage.isMainStep()) {
				// get the previous page
				var previousPossible = this._pageContainer._getSiblingOfChild(tempPage, -1);
				// while the next page is a substep and disabled
				while (previousPossible.isMainStep() == false && previousPossible.isDisabled()) {
					// get the previous page
					previousPossible = this._pageContainer._getSiblingOfChild(previousPossible, -1);
				}		
				if (previousPossible != null) {
					// select the new page
					this.selectPage(previousPossible);
				}
			}
		},

		skipToNextMainStep: function () {
			// summary:  Using the skip function takes you to the next main page that is enabled. But you still want to hide any substeps if you happen to be in a main  page with substeps, and you want to hide all of the substeps for a main page if you happen to be in a substep. Also if the next main step contains substeps but the main step should not show its page, the first enabled substep page will be selected.
			// tags: public
			
			// get the current page
			var tempPage = this.lastPageSelected;
			// assume it is a main step
			var mainPage = tempPage;
			// while still on a substep
			while (mainPage.isMainStep() == false) {
				// back up another page
				mainPage = this._pageContainer._getSiblingOfChild(mainPage, -1);
			}
			// hide any substeps
			mainPage.hideSubsteps();
			// mark it as visited
			tempPage.visited = true;
			// find the next page
			var whoIsNext = this._pageContainer._getSiblingOfChild(tempPage, 1);
			// while that page is a substep
			while (whoIsNext != null && (whoIsNext.isMainStep() == false || whoIsNext.isDisabled())) {
				// find the next page
				whoIsNext = this._pageContainer._getSiblingOfChild(whoIsNext, 1);
			}
			// select the new page
			if (whoIsNext != null) {
				// check if we need to show substep directly
				if (whoIsNext.showTitleOnly()) {
					this.goToSubstep(whoIsNext);
				} else {
					this.selectPage(whoIsNext);
				}
			}     
		},	
		
		jumpBackToPage: function (aPage) {
			// summary:  The user has clicked on something in the table of contents, so the container needs to display that page.Hide any substeps of the jump off page if the page is not a substep of the jump off page. Let the developer decide when to mark the pages invalid. This also means that the page where the jump originated needs to be marked as visited in order to return to that page.  This can be overridden if allowMarkAsComplete returns false.
			// tags: public
			
			// the jump off point might have substeps or be a substep
			// hide them as long as page to jump to isn't one of those substeps
			var jumpOffMainPage = (this.lastPageSelected.isMainStep()) ? this.lastPageSelected
																   : this.lastPageSelected.getMainPage();
			var jumpToMainPage = (aPage.isMainStep()) ? aPage : aPage.getMainPage();    
			if (jumpOffMainPage != jumpToMainPage) {
				jumpOffMainPage.hideSubsteps();    
			}
			// mark where we were as having been visited
			if (this.lastPageSelected.allowMarkAsComplete()) {
				this.lastPageSelected.visited = true;
			}
			// check if we need to show substep directly
			if (aPage.showTitleOnly()) {
				this.goToSubstep(aPage);
			} else {
				// then let the parent class handle selecting the page
				this.selectPage(aPage);
			}
		
		},
	  
		goToSubstep: function (mainPage) {
			// summary:   Selects the first enabled substep for the given main page.
			// tags: public
			
			mainPage.showSubsteps();
			dojo.every(mainPage.getSubsteps(), function (substep) {
				if (!substep.isDisabled()) {
					this.selectPage(substep);
					return false;
				} else {
					return true;
				}
			}, this);    
		},

		hideAllButtons: function () {
			// summary:   Hide all of the buttons by adding a class
			// tags: public
			
			dojo.addClass(this._buttonArea.domNode, "tiv-wiz-footer-hidden");
			this._outerContainer.resize();
		},

		showAllButtons: function () {
			// summary:  Show all of the buttons by removing a class
			// tags: public
			
			dojo.removeClass(this._buttonArea.domNode, "tiv-wiz-footer-hidden");
			this._outerContainer.resize();
		},

		hideBackButton: function (shouldHide) {
			// summary:   Hide (or show) the "back" button 
			// tags: public
			
			if (shouldHide) {
				dojo.style(this._backButton.domNode, "display", "none");
			} else {
				dojo.style(this._backButton.domNode, "display", "inline-block");
			}
		},

		hideNextButton: function (shouldHide) {
			// summary:   Hide (or show) the "next" button
			// tags: public
			
			if (shouldHide) {
				dojo.style(this._nextButton.domNode, "display", "none");
			} else {
				dojo.style(this._nextButton.domNode, "display", "inline-block");
			}
		},

		enableBackButton: function (shouldEnable) {
			// summary:   Enable (or disable) the "back" button
			// tags: public
			
			this._backButton.attr("disabled", !shouldEnable);
		},

		enableNextButton: function (shouldEnable) {
			// summary:    Enable (or disable) the "next" button
			// tags: public
			
			this._nextButton.attr("disabled", !shouldEnable);
		},

		unmarkVisitedPages: function (aPage) {
			// summary:   If a change is made to a page that was reached by jumping back, that might cause subsequent pages to have information or choices  that are no longer valid. Call this function to invalidate the selected page and all subsequent pages.
			// tags: public
			
			while (aPage != null) {
				aPage.visited = false;
				aPage = this._pageContainer._getSiblingOfChild(aPage, 1);
			}
			this.updateUI();
		},

		_onPageSelected: function (page) {
			// summary:   There are some differences when a page is selected. This is where the last page selected is reset. The selected page should not be marked as having been visited, a change from the parent class.
			// tags: public
			
			// keep track of which page was last selected
			this.lastPageSelected = page;
			// let the parent class handle this
			this.OnPageSelected(this, page);
			// if the page can handle this function
			if ("function" == typeof page.OnPageSelected) {
				// let the page know it has been selected
				page.OnPageSelected(this);
			}
			// update the display
			this.updateUI();
			// if the page can handle this function
			if ("function" == typeof page.AfterPageSelected) {
				// let the page get final control
				page.AfterPageSelected(this);
			}
		},

		_onClickFinish: function (event) {
			// summary:   When "Finish" is clicked any substeps that are open should be  hidden
			// tags: public
			
			// get the page current in view
			var tempPage = this.lastPageSelected;
			// see if the page wants to allow the customer to move on
			var shouldAllow = tempPage.allowFinish();
			// if so
			if (shouldAllow) {
				// while this is a substep
				while (tempPage.isMainStep() == false) {
					// get the page preceding this one
					tempPage = this._pageContainer._getSiblingOfChild(tempPage, -1);
				}
				// then hide any substeps
				tempPage.hideSubsteps();
				// and allow any additional processing to occur
				
				
				this.OnOK(this);
			}
		},
		

		/**
		* This has a number of differences from the parent class.
		* 
		* If a page has substeps, then they should be hidden from view at
		* this time.
		* 
		* If the previous page is really a substep then the page that should
		* be shown is the parent of that substep.
		* 
		* When backing up to the parent of a substep the substeps should be
		* marked as not having been visited.
		* 
		* Disabled pages should be avoided.
		* 
		* Changing behavior:
		* - To completely override the behavior of the Back button, have
		* allowBack() of current page return false and connect customized 
		* handler function to _onClickBack event.
		* - To perform additional processing after previous page has been
		* selected, connect customized handler function to OnBack event.
		*/
		_onClickBack: function (evt) {
			// summary:   Enable jumping back to every page
			// tags: public
				
			// allow any additional processing to occur
			this.OnBack(this);
			// get the current position
			var tempPage = this.lastPageSelected;
			// see if the page wants to allow the customer to move back
			var shouldAllow = tempPage.allowBack();
			// if so
			if (shouldAllow) {
				// get the next page
				var whoIsNext = tempPage;
				whoIsNext = this._pageContainer._getSiblingOfChild(whoIsNext, 1);   
				// if the next page is marked as unvisited (no jump back)
				if (whoIsNext != null && !whoIsNext.visited) {
				// mark current page as unvisited
					tempPage.visited = false;      
				}
				var startingPage = tempPage;
				// if the current page is not a substep
				if (tempPage.isMainStep() == true) {
					// hide any substeps for this page
					tempPage.hideSubsteps();         
				} else {
					// current page is a substep
					var mainPage = tempPage.getMainPage();
					if (whoIsNext != null && !whoIsNext.visited) {
						// mark main step as unvisited as long as no jump back
						mainPage.visited = false;
					}
					if (mainPage.showTitleOnly()) {
						// get the previous enabled page
						var previous = this._pageContainer._getSiblingOfChild(tempPage, -1);
						while (previous != null && previous.isDisabled()) {
							previous = this._pageContainer._getSiblingOfChild(previous, -1);      
						}
					  
					  // if previous page is this substep's main page, then skip it
						if (previous == mainPage) {
							startingPage = previous;
							mainPage.hideSubsteps();
						}
					}
				}
			  
				// get the previous page that is not disabled
				var whoIsPrevious = this._pageContainer._getSiblingOfChild(startingPage, -1);
				  
				// while that page is marked disabled or if page is a substep and its
				// main page is disabled
				while (whoIsPrevious != null && (whoIsPrevious.isDisabled() || 
						!whoIsPrevious.isMainStep() && whoIsPrevious.getMainPage().isDisabled())) {
					// get the previous page
					whoIsPrevious = this._pageContainer._getSiblingOfChild(whoIsPrevious, -1);      
				}
				  
			  // if there is still a page to load
				if (whoIsPrevious != null) {      
				
					// if that page is a substep 
					if (whoIsPrevious.isMainStep() == false) {
						// keep track of substep
						var subStepToSelect = whoIsPrevious;
						// get previous main page
						whoIsPrevious = subStepToSelect.getMainPage();
						// if main page is not part of a loop
						// (otherwise select main page)
						if (!whoIsPrevious.isPartOfLoop()) {
							// make all substeps for this page visible then the substep can be selected
							whoIsPrevious.OnPageSelected(this);
							// reset page to be selected to our substep
							whoIsPrevious = subStepToSelect;
						}        
					}
					// select that page
					this.selectPage(whoIsPrevious);
				}
		  		// mark this page widget as not having been visited if
				// we didn't get here from jumping back
				if (!tempPage.visited) {
					this._pageContainer.selectedChildWidget.visited = false; 
				}
			  
			}
		},

		/** 
		* Moving to the next page is slightly different if there are substeps
		* involved.
		* 
		* Substeps should only be seen when their parent is the last main
		* step to be visited. They need to disappear when the next main step
		* is entered.
		* 
		* Disabled pages should be avoided.
		* 
		* Changing behavior:
		* - To completely override the behavior of the Next button, have
		* allowNext() of current page return false and connect customized 
		* handler function to _onClickNext event.
		* - To perform additional processing after next page has been
		* selected, connect customized handler function to OnNext event.
		*/
		_onClickNext: function (evt) {
			// summary:   Enable jumping next to every page
			// tags: public
			
			// allow any additional processing to occur
			this.OnNext(this);
			// get the page current in view
			var tempPage = this.lastPageSelected;
			// see if the page wants to allow the customer to move on
			var shouldAllow = tempPage.allowNext();
			// if so
			if (shouldAllow) {
				// if current page in view has no substeps, mark the page as 
				// having been visited
				if (!tempPage.hasSubsteps()) {
					tempPage.visited = true;
				}
				// get the next page
				var nextPossible;    
				if (tempPage.isPartOfLoop()) {
					// current page is part of a loop so get next main page
					nextPossible = this.getNextMainPage(tempPage);
				} else {
					nextPossible = this._pageContainer._getSiblingOfChild(tempPage, 1);
				}

				// while that page is marked disabled
				while (nextPossible != null && nextPossible.isDisabled()) {
				// if disabled page has substeps
					if (nextPossible.hasSubsteps()) {
						// get next main page
						nextPossible = this.getNextMainPage(nextPossible);
					} else {
				  		// get the next page
						nextPossible = this._pageContainer._getSiblingOfChild(nextPossible, 1);
					}
				}
				// if there is still a next page to load
				if (nextPossible != null) {
					// if next page is a main page and current page is a substep or main page for loop
					if (nextPossible.isMainStep() && (!tempPage.isMainStep() || tempPage.isPartOfLoop())) {
						// get the current main page
						var currentMainPage;
						if (tempPage.isPartOfLoop()) {
							if (tempPage.isMainStep()) {
								currentMainPage = tempPage;
							} else {
								currentMainPage = tempPage.getMainPage();
							}
							// mark all loop substeps as visited
							dojo.forEach(currentMainPage.getSubsteps(), function (page) {
								page.visited = true;
							}, this);
						} else {
							currentMainPage = tempPage.getMainPage();          
						}
						// hide substeps for that main step
						currentMainPage.hideSubsteps();
					    // mark the main step as having been visited
						currentMainPage.visited = true;
					}       
					// check if we need to show substep directly
					if (nextPossible.showTitleOnly()) {
						this.goToSubstep(nextPossible);
					} else {
						// select that page
						this.selectPage(nextPossible);
					}
				}      
			}        
		},
		
		_onClickCancel: function (event) {
			// summary:   Called on click of cancel button. If showCancelWarning is true displays Confirmation Message otherwise calls the default OnCancel method.
			// tags: private
			
			if(this.showCancelWarning == true) {
				this._showCancelMessage(this);
			} else {
				this.OnCancel(this);
			}
		}, 
	  
		OnBack: function (wiz) {
		},
	  
		OnNext: function (wiz) {
		},
	  
		//methods added by TED team.
		//Latha 5 July 2011 : Basing on the requirement from TIP team , removing the display of Confirmation messages after click on OK button
		OnOK: function (wiz) {
		/*	var dialog = new dojoe.messagedialog.MessageDialog({ message: this._resources.FINISH_MSG,
																messageId: "",	
																type: "Confirm",
																callback:  dojo.hitch(this, this.onOkClick),
																callbackParms: wiz,
																buttons: [this._resources.CONFIRM_YES, this._resources.CONFIRM_NO],
																showCheckbox: false                                         
																});
			dialog.show(); */
		},
		
		/*onOkClick : function (buttonPressedId, messageId, checked, wiz) {
		
			if (buttonPressedId == 0) {
				pages = wiz.getChildren(); 
				dojo.forEach(pages, function (p, i) {
					wiz.removePage(p);
					//p.destroy();
				}, this);
				this.hideAllButtons();
				this._outerContainer.destroy();
			}
		}, */
		
		//Override this method to execute the user defined implementation on click of cancel button in the wizard.
	  
		OnCancel: function (wiz) {
			// override or connect to me
			
		},
		
		_showCancelMessage : function(wiz) {
			// summary:   Displays the Confirmation Message.
			// tags: private
		
			var dialog = new dojoe.messagedialog.MessageDialog({message: this._resources.CANCEL_MSG,
																messageId: "",
																type: "Confirm",
																callback:  dojo.hitch(this, this._onConfirm),
																callbackParms: wiz,
																buttons: [this._resources.CONFIRM_YES, this._resources.CONFIRM_NO],
																showCheckbox: false                                         
																});
			dialog.show();
		},
		
		_onConfirm : function (buttonPressedId, messageId, checked, wiz) {
			// summary:   Call back method for Confirmation Message. Called once the user selects the option on the confirmation messgage dialog.
			// tags: private
		
			if (buttonPressedId == 0) {
				var pages = wiz.getChildren(); 
				dojo.forEach(pages, function (p, i) {
					wiz.removePage(p);
					//p.destroy();
				}, this);
				this.hideAllButtons();
				this._outerContainer.destroy();
				//dijit.byId(wiz).destroy();
			}
		}, 
		getChildren : function () {
			// summary:   To get children of the  wizard
			// tags: public
			
			var page = [];
			page = this.inherited(arguments);
			return page;
		},
	  
		removePage: function (p) { //p is a widget
			// summary:   To remove a page from Wizard
			// tags: public
		
			this.inherited(arguments);
		},
		
		//Latha:06May2011: updating destroy for complete cleanup
		destroy : function () {
			// summary:  Destroys the wizard.
			// tags: public
			try {
				delete this._resources;
				var widgetArr = this.getChildren();
				dojo.forEach(widgetArr, function (child) {
					if(child){
						if(child.destroyRecursive){
							child.destroyRecursive();
						} else if(child.destroy){
							child.destroy();
						}
					}
				});
				this.inherited(arguments);
			} catch (ex) {
				console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
			}
		}
	});

/**
 * Slider support for horizontal navigation
 */
dojo.declare("dojoe.wizard.WizardToCSlider", null, 
	{
		toc: null,        // ordered list for ToC
		tocSteps: null,   // div containing toc main steps
		ltr: true, 
		tocStepsMargin: 10,
		tocMarginLeft: 2,
		oldTocStepsWidth: 0,
		totalWidthToCItems: 0,
		oneButtonWidth: 29,
		visibleButtonWidth: 0,  // width plus margin of visible buttons 
		sliderOuterDiv: null,
		sliderLeft: null,
		sliderRight: null,
		sliderLeftImg: dojo.moduleUrl("dojoe.common", "themes/claro/images/slider_left.png"),
		sliderRightImg: dojo.moduleUrl("dojoe.common", "themes/claro/images/slider_right.png"),
		t: null,
		slideDelay: 2,  // 2 milliseconds
		slidePixel: 2,
		pos: 0,
		slideDirection: "",
		slideRightLabel: "",
		slideLeftLabel: "",
  
		/**
		* Constructor which adds nodes to ToC content pane for the slider, e.g.
		* <div for main steps - passed in>
		*   <img for left slider button />
		*   <div for containing ToC (outer) >
		*     <ol for ToC (inner) - passed in />
		*   </div>
		*   <img for right slider button>
		* </div>
		* 
		* Takes three arguments:
		*   toc       <ol> for ToC
		*   tocSteps  div for main steps
		*   ltr       flag indicating whether container text direction is left-to-right
		*             or not (right-to-left)
		*/
		constructor: function (args) {
			this.toc = args.toc;
			this.tocSteps = args.tocSteps;
			this.ltr = args.ltr;
			// strings for slider buttons
			this.resources = dojo.i18n.getLocalization("dojoe.wizard", "Wizard", this.lang);
			this.slideRightLabel = this.resources.NEXT;
			this.slideLeftLabel = this.resources.PREVIOUS;
			this.sliderOuterDiv = dojo.create("div", { className: "slider-outer" });          
			dojo.place(this.toc, this.sliderOuterDiv, 0);
			dojo.addClass(this.toc, "slider-inner");        
		
			this.sliderLeft = dojo.create("img", {
				src: this.sliderLeftImg.toString(),
				alt: this.slideLeftLabel,
				title: this.slideLeftLabel,
				className: "slider-left"
			});
			this.sliderRight = dojo.create("img", {
				src: this.sliderRightImg.toString(),
				alt: this.slideRightLabel,
				title: this.slideRightLabel,
				className: "slider-right"
			});
			dojo.place(this.sliderLeft, this.tocSteps, 0);
			dojo.place(this.sliderOuterDiv, this.tocSteps, 1);
			dojo.place(this.sliderRight, this.tocSteps, 2);
			// initially hide buttons
			dojo.style(this.sliderLeft, "display", "none");        
			dojo.style(this.sliderRight, "display", "none");        
			// connect button handlers
			var slideLeftListener = dojo.connect(this.sliderLeft, "onclick", this, this.slideLeft);
			var slideRightListener = dojo.connect(this.sliderRight, "onclick", this, this.slideRight);
		},
	  
		/**
		* Re-calculate total width of all ToC items (step arrows).
		*/
		recalcToCWidth: function () {
			// With IE arrow image parts may wrap as the arrow styles change.  
			// To ensure we have the correct total width, we temporarily increase
			// the width of the ToC list to prevent any truncation of parts and 
			// then add up the widths of the arrow parts, i.e. front, middle and 
			// tail.
			dojo.style(this.toc, "width", (this.totalWidthToCItems * 2) + "px");  // should be sufficient   
			this.totalWidthToCItems = 0;
			dojo.query("i", this.toc).forEach(function (n) {
				this.totalWidthToCItems += n.offsetWidth; 
			}, this);
			dojo.query("span", this.toc).forEach(function (n) {
				this.totalWidthToCItems += n.offsetWidth;      
			}, this);
			dojo.query("b", this.toc).forEach(function (n) {
				this.totalWidthToCItems += n.offsetWidth;      
			}, this);
			dojo.style(this.toc, "width", this.totalWidthToCItems + "px");
		},
		
		/**
		* Right slider button is made visible if not all step arrows can
		* be displayed in the pane.  Once user clicks on button and slides
		* the arrows, then the left slider button is added.  Both buttons
		* remain visible unless the pane is resized so that all steps can
		* be displayed.
		*/
		updateSliderUI: function (newWidth) {
			// newWidth will be passed in when toc content pane is being resized;
			// use it instead of scrollWidth since that value may not be updated yet
			var slideWidth = (newWidth != null) ? newWidth : dojo.style(this.tocSteps, "width");
			if (this.totalWidthToCItems >= slideWidth - this.tocStepsMargin) {
				if (this.ltr) {
				// Show right slider button only if no buttons currently showing
					if (this.sliderRight.style.display == "none") {
						dojo.style(this.sliderRight, "display", "inline");
						this.visibleButtonWidth = this.oneButtonWidth;        
					} else {
						this.finishSlide(this.sliderLeft, slideWidth);
					}
				} else {
					// Show left slider button only if no buttons currently showing
					if (this.sliderLeft.style.display == "none") {
						dojo.style(this.sliderLeft, "display", "inline");
						this.visibleButtonWidth = this.oneButtonWidth;        
					} else {
						this.finishSlide(this.sliderRight, slideWidth);
					}
				}
				dojo.style(this.sliderOuterDiv, "width", (slideWidth - this.visibleButtonWidth) + "px");
				this.oldTocStepsWidth = slideWidth;
			} else if (this.visibleButtonWidth > 0) {
				// no need for slider, hide everything
				dojo.style(this.sliderLeft, "display", "none");        
				dojo.style(this.sliderRight, "display", "none");        
				dojo.style(this.sliderOuterDiv, "width", "100%");
				dojo.style(this.toc, "left", "0px");
				this.pos = 0;
				this.slideDirection = "";
				this.visibleButtonWidth = 0;
			}    
		},

		/**
		* Handles case where both slider buttons are visible, toc has been 
		* scrolled so first and last step(s) are no longer visible and window 
		* is being resized.  As the window width is increased, once the last 
		* step is visible the toc needs to be slid so that the first step(s) 
		* become visible too.
		*/
		finishSlide: function (button, slideWidth) {
			var defaultToc = 0;
			if (button.style.display != "none") {
				var tocLeft = dojo.style(this.toc, "left");
				if (this.ltr) {
					// left-to-right direction
					if (tocLeft < 0) {
						var tocWidthShowing = dojo.style(this.toc, "width") + tocLeft;
						if (slideWidth > (tocWidthShowing + this.visibleButtonWidth + this.tocMarginLeft)) {
							this.pos = tocLeft + slideWidth - this.oldTocStepsWidth;
							dojo.style(this.toc, "left", this.pos + "px");
						}                  
					}
				} else {
					// right-to=left direction
					if (tocLeft > 0) {
						var tocWidthShowing1 = defaultToc - (dojo.style(this.toc, "width") - tocLeft);
						if (slideWidth > (tocWidthShowing1 + this.visibleButtonWidth + this.tocMarginLeft)) {
							this.pos = tocLeft - slideWidth + this.oldTocStepsWidth;
							dojo.style(this.toc, "left", this.pos + "px");
						}                            
					}
				}
			}
		},
	  
		/**
		* Called to show the second slider button after first slider button
		* has been clicked.
		*/  
		showSecondButton: function (button, marginStyle, multiplier) {
			this.visibleButtonWidth *= 2;
			this.pos = multiplier * this.oneButtonWidth;
			dojo.style(button, "display", "inline");
			dojo.style(this.toc, "left", this.pos + "px");
			dojo.style(this.sliderOuterDiv, "width", (dojo.style(this.tocSteps, "width") - this.visibleButtonWidth) + "px");
			dojo.style(this.toc, marginStyle, this.tocMarginLeft + "px");    
		},
	  
		/**
		* Returns the number of pixels that have been scrolled due to
		* tabbing.
		*/
		getScrollAmount: function () {
			var scrollAmt = 0;
			if (this.sliderOuterDiv.scrollLeft > 0) { // IE
				scrollAmt = this.sliderOuterDiv.scrollWidth - this.sliderOuterDiv.scrollLeft - this.sliderOuterDiv.offsetWidth;
			} else if (this.sliderOuterDiv.scrollLeft < 0) {  // FF
				scrollAmt = scrollAmt - this.sliderOuterDiv.scrollLeft;
			}
			return scrollAmt;
		},
	  
		/**
		* Invoked when user clicks on right slider button
		*/
		slideRight: function () {
			if (this.slideDirection == "") {
				this.showSecondButton(this.sliderLeft, "marginLeft", -1);
			} else {
				this.slideStop();
			}
			this.slideDirection = "R";
			// determine number of pixels to slide adjusting for any scrolling
			// from tabbing if necessary
			var slideWidth = dojo.style(this.sliderOuterDiv, "width") - this.tocMarginLeft;    
			var leftToSlide;
			if (this.ltr) {
				leftToSlide = this.totalWidthToCItems - slideWidth + this.pos - this.sliderOuterDiv.scrollLeft;
			} else {
				leftToSlide = this.pos + this.getScrollAmount();
			}
			// don't slide too much
			if (leftToSlide > slideWidth) {
				leftToSlide = slideWidth;
			}
			// call recursive function to do actual slide
			if (leftToSlide > 0) {
				this._slideRight(leftToSlide - this.pos);
			}
		},
	  
		_slideRight: function (totalToSlide) {    
			if (this.pos == 0) {
				this.pos = -1;
			}
			this.pos -= this.slidePixel;
			if (this.pos < -totalToSlide) {
				var diff = -this.pos - totalToSlide;
				this.pos += this.slidePixel;
				if (diff < this.slidePixel) {
					this.pos -= diff;  // any last pixels if not multiple of slidePixel number
					dojo.style(this.toc, "left", this.pos + "px");
				}
				return;
			}
			dojo.style(this.toc, "left", this.pos + "px");
			this.t = setTimeout(dojo.hitch(this, this._slideRight, totalToSlide), this.slideDelay);    
		},
	  
		/**
		* Invoked when user clicks on left slider button
		*/
		slideLeft: function () {    
			if (this.slideDirection == "") {
				this.showSecondButton(this.sliderRight, "marginRight", 1);
			} else {
				this.slideStop();
			}
			this.slideDirection = "L";
				
			// determine number of pixels to slide adjusting for any scrolling
			// from tabbing
			var slideWidth = dojo.style(this.sliderOuterDiv, "width") - this.tocMarginLeft;    
			var leftToSlide;
			if (this.ltr) {
				leftToSlide = -this.pos + this.sliderOuterDiv.scrollLeft;
			} else {
				leftToSlide = this.totalWidthToCItems - slideWidth - this.pos - this.getScrollAmount();
			}
			// don't slide too much
			if (leftToSlide > slideWidth) {
				leftToSlide = slideWidth;
			}
			// call recursive function to do actual slide
			if (leftToSlide > 0) {
				this._slideLeft(leftToSlide);
			}
		},
	  
		_slideLeft: function (totalToSlide) {
			if (this.pos == 0) {
				this.pos = 1;
			}
			this.pos += this.slidePixel;
			totalToSlide -= this.slidePixel;
			if (totalToSlide < 0) {
				this.pos -= this.slidePixel;
				if (-totalToSlide < this.slidePixel) {
					this.pos += -totalToSlide;  // any last pixels if not multiple of slidePixel number
					dojo.style(this.toc, "left", this.pos + "px");
				}
				return;
			}
			dojo.style(this.toc, "left", this.pos + "px");
			this.t = setTimeout(dojo.hitch(this, this._slideLeft, totalToSlide), this.slideDelay);    
		},

		/**
		* Cancels the set timer so sliding is stopped
		*/
		slideStop: function () {
			clearTimeout(this.t);
		},
	  
		/**
		* Resets slider so first arrow is visible.
		*/
		reset: function () {
			this.pos = 0;
			dojo.style(this.toc, "left", "0px");
			if (this.ltr) {
				this.sliderOuterDiv.scrollLeft = 0;
			}
		}
	});

}
