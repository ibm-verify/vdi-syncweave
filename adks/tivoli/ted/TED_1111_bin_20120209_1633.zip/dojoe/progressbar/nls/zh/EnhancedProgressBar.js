/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"当前操作已被取消","CLOSE":"关闭","PAUSE":"暂停","CANCEL_MESSAGE":"是否要取消当前操作？","RESUME":"恢复","CONFIRM_OK":"是","CANCEL":"取消","CONFIRM_CANCEL":"否"})