/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"현재 조작이 취소됨","CLOSE":"닫기","PAUSE":"일시정지","CANCEL_MESSAGE":"현재 조작을 취소하시겠습니까?","RESUME":"재개","CONFIRM_OK":"예","CANCEL":"취소","CONFIRM_CANCEL":"아니오"})