/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Gjeldende operasjon avbrutt","CLOSE":"Lukk","PAUSE":"Pause","CANCEL_MESSAGE":"Vil du avbryte den gjeldende operasjonen?","RESUME":"Gjenoppta","CONFIRM_OK":"Ja","CANCEL":"Avbryt","CONFIRM_CANCEL":"Nei"})