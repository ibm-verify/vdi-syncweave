/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Huidige bewerking geannuleerd","CLOSE":"Sluiten","PAUSE":"Pauzeren","CANCEL_MESSAGE":"Wilt u de huidige bewerking annuleren?","RESUME":"Hervatten","CONFIRM_OK":"Ja","CANCEL":"Annuleren","CONFIRM_CANCEL":"Nee"})