/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Den aktuella åtgärden har avbrutits","CLOSE":"Stäng","PAUSE":"Paus","CANCEL_MESSAGE":"Vill du avbryta den aktuella åtgärden? ","RESUME":"Återuppta","CONFIRM_OK":"Ja","CANCEL":"Avbryt","CONFIRM_CANCEL":"Nej"})