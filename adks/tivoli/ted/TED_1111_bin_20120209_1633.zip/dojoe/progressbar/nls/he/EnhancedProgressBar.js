/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"פעולה נוכחית בוטלה","CLOSE":"סגירה","PAUSE":"השהיה","CANCEL_MESSAGE":"האם ברצונכם לבטל את הפעולה הנוכחית?","RESUME":"חידוש","CONFIRM_OK":"כן","CANCEL":"ביטול","CONFIRM_CANCEL":"לא"})