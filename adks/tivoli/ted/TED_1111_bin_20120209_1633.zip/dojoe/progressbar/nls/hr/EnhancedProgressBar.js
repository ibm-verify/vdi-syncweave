/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Trenutna operacija opozvana","CLOSE":"Zatvori","PAUSE":"Pauza","CANCEL_MESSAGE":"Želite li opozvati trenutnu operaciju?","RESUME":"Nastavi","CONFIRM_OK":"Da","CANCEL":"Opoziv","CONFIRM_CANCEL":"Ne"})