/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Toiminto on peruutettu","CLOSE":"Sulje","PAUSE":"Keskeytä","CANCEL_MESSAGE":"Haluatko peruuttaa meneillään olevan toiminnon?","RESUME":"Jatka","CONFIRM_OK":"Kyllä","CANCEL":"Peruuta","CONFIRM_CANCEL":"Ei"})