/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"現行作業已取消","CLOSE":"關閉","PAUSE":"暫停","CANCEL_MESSAGE":"您要取消現行作業嗎？","RESUME":"回復","CONFIRM_OK":"是","CANCEL":"取消","CONFIRM_CANCEL":"否"})