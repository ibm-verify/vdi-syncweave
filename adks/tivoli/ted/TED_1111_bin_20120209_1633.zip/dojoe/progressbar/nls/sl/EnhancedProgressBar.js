/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Trenutna operacija je preklicana","CLOSE":"Zapri","PAUSE":"Začasno ustavi","CANCEL_MESSAGE":"Ali želite preklicati trenutno operacijo?","RESUME":"Nadaljuj","CONFIRM_OK":"Da","CANCEL":"Prekliči","CONFIRM_CANCEL":"Ne"})