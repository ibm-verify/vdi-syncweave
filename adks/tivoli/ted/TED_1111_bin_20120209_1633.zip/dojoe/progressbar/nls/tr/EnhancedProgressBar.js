/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Geçerli işlem iptal edildi","CLOSE":"Kapat","PAUSE":"Duraklat","CANCEL_MESSAGE":"Geçerli işlemi iptal etmek istiyor musunuz?","RESUME":"Sürdür","CONFIRM_OK":"Evet","CANCEL":"İptal","CONFIRM_CANCEL":"Hayır"})