/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Operazione corrente annullata","CLOSE":"Chiudi","PAUSE":"Pausa","CANCEL_MESSAGE":"Annullare l'operazione corrente?","RESUME":"Riprendi","CONFIRM_OK":"Sì","CANCEL":"Annulla","CONFIRM_CANCEL":"No"})