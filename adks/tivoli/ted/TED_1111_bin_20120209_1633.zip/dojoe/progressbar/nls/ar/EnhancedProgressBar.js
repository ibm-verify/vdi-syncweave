/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"تم الغاء العملية الحالية","CLOSE":"اغلاق","PAUSE":"ايقاف مؤقت","CANCEL_MESSAGE":"هل تريد الغاء العملية الحالية؟","RESUME":"استئناف","CONFIRM_OK":"نعم","CANCEL":"الغاء","CONFIRM_CANCEL":"لا"})