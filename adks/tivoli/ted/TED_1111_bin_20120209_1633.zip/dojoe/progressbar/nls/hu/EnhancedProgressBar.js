/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Jelenlegi művelet megszakítva","CLOSE":"Bezárás","PAUSE":"Szünet","CANCEL_MESSAGE":"Megszakítja a jelenlegi műveletet?","RESUME":"Folytatás","CONFIRM_OK":"Igen","CANCEL":"Mégse","CONFIRM_CANCEL":"Nem"})