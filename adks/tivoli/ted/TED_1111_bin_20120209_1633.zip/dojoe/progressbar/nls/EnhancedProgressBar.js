/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Current operation cancelled","CLOSE":"Close","PAUSE":"Pause","CANCEL_MESSAGE":"Do you want to cancel the current operation?","RESUME":"Resume","CONFIRM_OK":"Yes","CANCEL":"Cancel","CONFIRM_CANCEL":"No"})