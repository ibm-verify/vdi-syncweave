/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Aktuelle Operation abgebrochen","CLOSE":"Schließen","PAUSE":"Anhalten","CANCEL_MESSAGE":"Soll die aktuelle Operation abgebrochen werden?","RESUME":"Fortsetzen","CONFIRM_OK":"Ja","CANCEL":"Abbrechen","CONFIRM_CANCEL":"Nein"})