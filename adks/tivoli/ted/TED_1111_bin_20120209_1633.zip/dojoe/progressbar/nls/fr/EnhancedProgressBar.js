/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Opération en cours annulée","CLOSE":"Fermer","PAUSE":"Pause","CANCEL_MESSAGE":"Voulez-vous annuler l'opération en cours ?","RESUME":"Reprendre","CONFIRM_OK":"Oui","CANCEL":"Annuler","CONFIRM_CANCEL":"Non"})