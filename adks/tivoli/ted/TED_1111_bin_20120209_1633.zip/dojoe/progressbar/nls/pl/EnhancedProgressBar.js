/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Bieżąca operacja została anulowana","CLOSE":"Zamknij","PAUSE":"Wstrzymaj","CANCEL_MESSAGE":"Czy chcesz anulować bieżącą operację?","RESUME":"Wznów","CONFIRM_OK":"Tak","CANCEL":"Anuluj","CONFIRM_CANCEL":"Nie"})