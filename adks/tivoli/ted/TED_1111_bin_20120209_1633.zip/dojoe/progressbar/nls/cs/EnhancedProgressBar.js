/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Aktuální operace byla zrušena","CLOSE":"Zavřít","PAUSE":"Pozastavit","CANCEL_MESSAGE":"Chcete zrušit aktuální operaci?","RESUME":"Pokračovat","CONFIRM_OK":"Ano","CANCEL":"Storno","CONFIRM_CANCEL":"Ne"})