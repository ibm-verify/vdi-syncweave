/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"現在の操作は取り消されました","CLOSE":"クローズ","PAUSE":"   一時停止   ","CANCEL_MESSAGE":"現在の操作を取り消しますか?","RESUME":"再開","CONFIRM_OK":"はい","CANCEL":"キャンセル","CONFIRM_CANCEL":"いいえ"})