/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"A operação atual foi cancelada","CLOSE":"Fechar","PAUSE":"Pausar","CANCEL_MESSAGE":"Você deseja cancelar a operação atual?","RESUME":"Continuar","CONFIRM_OK":"Sim","CANCEL":"Cancelar","CONFIRM_CANCEL":"Não"})