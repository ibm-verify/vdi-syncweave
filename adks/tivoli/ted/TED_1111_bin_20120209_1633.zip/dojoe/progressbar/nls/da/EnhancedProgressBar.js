/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SUCCESSFULCANCEL_MESSAGE":"Aktuel funktion annulleret","CLOSE":"Luk","PAUSE":"Pause","CANCEL_MESSAGE":"Vil du annullere den aktuelle funktion?","RESUME":"Genoptag","CONFIRM_OK":"Ja","CANCEL":"Annullér","CONFIRM_CANCEL":"Nej"})