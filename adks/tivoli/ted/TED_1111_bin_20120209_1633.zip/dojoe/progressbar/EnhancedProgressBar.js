/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.progressbar.EnhancedProgressBar"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.progressbar.EnhancedProgressBar"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.progressbar.EnhancedProgressBar" );

dojo.require("dijit._Widget");
dojo.require("dijit._Templated");
dojo.require("dijit.ProgressBar"); 
dojo.require("dijit.form.Button");
dojo.require("dijit.Dialog");
dojo.require("dojo.parser");
dojo.require("dojoe.messagedialog.MessageDialog");
dojo.require("dojo.i18n");

/******************************************************************************
* Busy Pane that blocks all user input and shows progress message.
******************************************************************************/
//Localization of resource bundles
dojo.requireLocalization("dojoe.progressbar", "EnhancedProgressBar", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");

dojo.declare("dojoe.progressbar.EnhancedProgressBar", [dijit._Widget, dijit._Templated],
{
	// summary:  EnhancedProgressBar is a widget to show progress in determinate or indeterminate way . 
	// description: EnhancedProgressBar widget uses the dijit.ProgressBar for its implementation.
	//		  EnhancedProgressBar has also been customised with multiple default actions .
	
	//	processingImageSrc:String
	//  Path to the processing image
	processingImageSrc: dojo.moduleUrl("dojoe.common","themes/images/progress32.gif"), 
  
	// _resources:  Object
	//	Reference to the resources
    resources_:null,
	//  progressBar:Object
	//  refrence to the progressbar  
	progressBar: null,
	
	// cancellable: Boolean
	//Set this to true if cancel button is needed in progressbar	
	cancellable:false,	
	
	//pauseable: Boolean
	//Set this to true if pause/resume toggle button is needed in progressbar	
	pauseable:false,
	
	//closeable: Boolean
	//Set this to true if close button is needed in progressbar	
	closeable:false,  
	
	//  progressIndicatorType:number
	//  indicates the type of progressbar.It can be set to  0:indeterminate or 1:determinant  
	progressIndicatorType : 0,
	
	//showmessagetext:Boolean
	//Set this to true to enable message from the user	
	showmessagetext:true,
	
	//processingLabel:String
	//Label to be shown when progress starts
	processingLabel:'Processing',
	
	//hidden:boolean
	//Set to true if the progressbar needs to be hidden once progress completes
	hidden:false,
	
	//maximumValue:number
	// maximum progress value
	maximumValue : 100,
	
	//progress:number
	//Holds the progress set by the user operation
	progress  : 0,
	
	//width: number
	//Holds the width of the progressbar set by user. It can be set in px,percentage or em like '150px','150%' or '150em'.
	width : "150px",
	
	//height: number
	//Holds the height of the progressbar set by user. It can be set in px,percentage or em like '150px','150%' or '150em'.
	height : "50px",
	
	//size:String
	//Holds the size of the processing image,it can be set to small,medium,large,huge
	size:"large",
	
	//id:  String
	// id of the widget
	id:null,
	
	//contentIsolation:  Boolean
	// Flag to indicate if sample is isolated
	contentIsolation:false,
	

	//namespace:  String
	// namespace for messageDialog in case of content isolation
	namespace:null,
	
	//templateString:  String
	// Path to the template
	templateString:dojo.cache("dojoe.progressbar", "templates/EnhancedProgressBar.html", "<div  class=\"enhanced t\" dojoAttachPoint='rootDiv' style=\"overflow:auto;\" ><div class=\"b\" style=\"overflow:auto;\"><div class=\"l\" style=\"overflow:auto;\"><div class=\"r\"><div class=\"bl\"><div class=\"br\"><div class=\"tl\" style=\"overflow:auto;\"><div class=\"tr\" style=\"overflow:auto;\">   \r\n   \r\n\t<table  dojoAttachPoint='progressBarTable' cellspacing='0' cellpadding='0' border='0' style=\"width:100%;overflow:auto;\" role=\"region\">\r\n\t         \r\n\t\t\t\t  <tr class='EnhancedProgressBarProcessing' style=\"overflow:auto;\" >\r\n\t\t\t\t    \r\n\t\t\t\t\t   <td class='process-anim'  width='10%'> \r\n\t\t\t\t\t   <img src='${processingImageSrc}'role=\"img\" alt='${processingLabel}' title='${processingLabel}'/></td> \r\n\t\t\t\t\t   <td width=\"x-small;overflow:auto;\"> \r\n\t\t\t\t\t      \r\n\t\t\t\t\t\t\t <table width=\"100%\" height=\"70%\" role=\"presentation\">\r\n\t\t\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t\t\t<td width=\"40%\" class='process-message' dojoAttachPoint='messageArea'>\r\n\t\t\t\t\t\t\t\t       <div dojoAttachPoint='msgareaDiv' role=\"log\">${processingLabel}</div>\r\n\t\t\t\t\t\t\t\t    </td> \r\n\t\t\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t\t\t<td width=\"x-small\"  >\r\n\t\t\t\t\t\t\t    \t<div dojoAttachPoint='progressBarNode' role=\"progressbar\"></div>\r\n\t\t\t\t\t\t\t\t\t</td> \r\n\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t<td width=\"10%\"> \r\n\t\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t\t\t\t<tr> \r\n\t\t\t\t\t\t\t\t\t<td width=\"100%\" colspan=\"2\"> \r\n\t\t\t\t\t\t\t\t\t<table>\r\n\t\t\t\t\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t\t\t\t\t<td>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div dojoAttachPoint='progressBarPause' style=\"overflow:auto;\" role=\"button\"> </div>\r\n\t\t\t\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<div dojoAttachPoint='progressBarCancel' style=\"overflow:auto;\" role=\"button\"> </div>\t\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t\t\t\t\t<td> \r\n\t\t\t\t\t\t\t\t\t\t\t<div dojoAttachPoint='progressBarClose' style=\"overflow:auto;\" role=\"button\"> </div>\r\n\t\t\t\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t\t\t\t\t</table>\r\n\t\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t\t</tr>\t \r\n\t\t\t\t\t\t\t </table>\r\n\t\t\t\t\t\t\t\r\n\t\t\t\t\t\t</td> \r\n\t\t\t\t\t\t\r\n\t\t\t\t\t</tr>\r\n\t\t\t  \r\n\t\t</table>\r\n\t\t\r\n\t\t\r\n\t</div></div></div></div></div></div></div></div>  \t  \t\r\n\t\r\n"),
  
  preamble: function(){  //Called before Constructor
 
  			if(arguments[0].size=="small")
				this.processingImageSrc=dojo.moduleUrl("dojoe.common","themes/images/progress16.gif");
			else if(arguments[0].size=="medium")
				this.processingImageSrc= dojo.moduleUrl("dojoe.common","themes/images/progress22.gif");
			else if(arguments[0].size=="large")
				this.processingImageSrc= dojo.moduleUrl("dojoe.common","themes/images/progress32.gif");
			else if(arguments[0].size=="huge")
				this.processingImageSrc= dojo.moduleUrl("dojoe.common","themes/images/progress48.gif");
 
			if(arguments[0].cancellable !==null && arguments[0].cancellable== true){
				this.cancelButton=true;	
			}				
			else
				this.cancelButton=false;	
				
			if(arguments[0].closeable !==null && arguments[0].closeable== true)
			{
				
				this.closeButton=true;
			}
			else
				this.closeButton=false;	
				
			if(arguments[0].pauseable !==null && arguments[0].pauseable== true)
			{
				
				this.pauseButton=true;
			}
			else
				this.pauseButton=false;	
			
	},
  
  constructor: function () {
		// resources_:  Object
		//Reference to the resources
		this.resources_ = dojo.i18n.getLocalization("dojoe.progressbar", "EnhancedProgressBar",this.lang); 
  },
  
  postCreate: function()
  {
	// summary:  Creates and initialises the progressbar with actions like close,cancel,pause/resume.
		// tags: public

    this.inherited( arguments );
	var size = dijit.getViewport();
	this._allProgressBarButtons = [];
		var height = this.height;
		var sizeType = this.height.substring(this.height.length-1, this.height.length);
		if(sizeType == "%") {
			//convert to px
			var height = size.h * ((parseInt(this.height.slice(0, -1))) / 100);
			height = height + "px";
		}
		if(this.progressIndicatorType==1) {	
	
	  this.progressBar = new dijit.ProgressBar({id:this.id+"progressBar",
												width:this.width ,
												height:this.height, 	
												report:function(percent){	
												return '';
																		}},this.progressBarNode);
		}
	  
      if(this.cancelButton ==true) {	
		
		this.cancelButton = new dijit.form.Button({
						id: this.id+"Cancel",
						showLabel: true,						
						label: this.resources_.CANCEL
					},this.progressBarCancel);
	  
	   this.cancelButton.onClick = dojo.hitch (this, "_onCancelClick");
	 this._allProgressBarButtons.push( this.cancelButton );
		
		 
	 }
	  if(this.closeButton ==true) {	 
		this.closeButton = new dijit.form.Button({
						id: this.id+"Close",
						showLabel: true,						
						label: this.resources_.CLOSE
					},this.progressBarClose);
	   
	this.closeButton.onClick = dojo.hitch (this, "_onCloseClick");		
	  this._allProgressBarButtons.push( this.closeButton );
	 }
	  if(this.pauseButton ==true) {
		if(this.progress !== this.maximumValue){
			this.pauseButton=new dijit.form.ToggleButton({
			id: this.id+"Toggle",
			ShowLabel: true,
			checked: false,
			label: this.resources_.PAUSE
			},this.progressBarPause);
			this.pauseButton.onChange = dojo.hitch (this, "_onToggleClick");		
		  this._allProgressBarButtons.push( this.pauseButton );
		}
	 }
	
	this.calculateMsgWidth();
	
	this.hide();
  },
   _onToggleClick: function(/* Event */e){  
					
	// summary:  indicates pause/resume state of the progressbar and calls appropriate functions.
	  //Also published events onPauseClick and onResumeClick.
		// tags: private			
					if(e==true)
					{
                        this.pauseButton.set('label', this.resources_.RESUME);	
						
						dojo.publish(this.id +"#onPauseClick", ["Paused"]);
						this.progressPaused=true;
					}
					else
					{
						this.pauseButton.set('label', this.resources_.PAUSE);	

						dojo.publish(this.id +"#onResumeClick", ["Resumed"]);
						this.progressPaused=false;
					}
	  
	},
	 _onCloseClick: function(/* Event */e){  
		// summary:  indicates closed state of the progressbar and publish event onCloseClick.
		// tags: private	
		this.closed=true;
		dojo.publish(this.id +"#onCloseClick", ["Closed"]);
	 	this.hide();
		 setTimeout( dojo.hitch( this, "destroy" ), 500 );	
	},
	
	 
		calculateMsgWidth :function() {
		// summary:  calculate the width of the message set by the user.
		// tags: public
		var strWidth = this.width.substring(0,this.width.length-2); // get numeric width 
		var totalWidth = parseInt(strWidth);
		var animwidth = .1 * totalWidth;
		var animwidth =animwidth+5;
		var	msgWidthtemp = totalWidth-(animwidth+20);
		this.msgWidth=msgWidthtemp+"px";
		 
  },
   
   doProgress : function(progress,message) {
	  //summary: Trigger for start displaying the progress
	  //tags :public
   if( this.closed!=true){
    this.show();	
	this.getProgress(progress,message);
	 }
	 
	
 },	
    
  getProgress :function (progress,message) {
	//summary: Trigger for start displaying the progress.
	  //tags :public
	this.progressCallBack(progress,message);
	
	},
	
	progressCallBack : function  (progress,message){
		//summary: Method which shows progress
		  //tags :public
		
		 if( progress < this.maximumValue ) {  //  Progress% is less than 100 and progress is not cancelled
		  
			
			var y = parseInt(progress);
		   	if (!isNaN(y)) {
		   		this.progress = y;
		   		if(this.progressIndicatorType==1 && this.progressCancelled!=true && this.progressPaused!=true ) {			      
		   		this.progressBar.update({ maximum:this.maximumValue, progress: this.progress });  //Update the progressbar
				if(this.showmessagetext==true)
				this.setMessage(message);
		   		else
				this.setMessage("");
		   		
		   		}else if(this.progressCancelled==true){
				
					this.hide();
					this.cancelButton.disabled=true;
					this.pauseButton.disabled=true;
				}
		   	}
		   
		 
		 
		 }
		 else if(progress=this.maximumValue) { 
			 // Progress Process is completed
			if(	this.progressIndicatorType==1){	 
			 this.progressBar.update({ maximum:this.maximumValue, progress: this.progress });		
			
			if(this.showmessagetext==true)
			{
			this.setMessage(message);
			}
			else
			{
				this.setMessage("");
			}}
			 var callback = dojo.hitch(this, this.afterCompletion);
			 
			   	setTimeout(callback,1000);
			 }
			
		
 },
 
 afterCompletion : function () {
	//summary: Called after the progress completes,hides the progressbar,if hidden enabled,disables the cancel and pause/resume button.
	  //tags :public
		if(this.hidden==true){
		this.hide();
		}
		//Reset Progress Data	 
		
		this.cancelButton.disabled=true;
		this.pauseButton.disabled=true;
		
		setTimeout( dojo.hitch( this, "destroyRecursive" ), 5000 );
	    
  },
 	  
  updateProgress : function(progressParam)
  {
	//summary: updates the progress of determinate progressbar
	  //tags :public
	
    if(this.progressIndicatorType==1) { //Updates Progress Only If type is Determinate otherwise ignore	
		this.progress=progressParam;		
		this.progressBar.update({ maximum:this.maximumValue, progress: this.progress });
	
			
		
	}
  },
  
 
 onCancelClick: function(/* Event */e){
	//summary: Cancels the operation once Ok is clicked in the confirmation dialog ,also publishes onCancelClick.
	  //tags :public
	  if(e==0){
			if(this.cancellable==true ) {	
	    	
	    	 var callback = dojo.hitch(this, this.afterCompletion);
			 if(this.contentIsolation==true){
	    	 this.successfulDialog = new dojoe.messagedialog.MessageDialog(
	 				{message: this.resources_.SUCCESSFULCANCEL_MESSAGE,
	 				 messageId: "Success",
	 				 type: "Info",	
	 				 namespace	:  this.namespace,
	 				 showCheckbox: false,
					 contentIsolation:true});
			}else{
			 this.successfulDialog = new dojoe.messagedialog.MessageDialog(
	 				{message: this.resources_.SUCCESSFULCANCEL_MESSAGE,
	 				 messageId: "Success",
	 				 type: "Info",					 
	 				 showCheckbox: false});
			}
			this.successfulDialog.show();	
			
			dojo.publish(this.id +"#onCancelClick", ["Cancelled"]);
			this.progressCancelled=true;			
	    	setTimeout(callback,1000);
			
	    }   
	  }
 },
 
 
 
  _onCancelClick: function(/* Event */e){
	//summary: Pops up the confirmation dialog once cancel button is clicked,also publishes onCancelClick.
	  //tags :private 

	  if(this.contentIsolation==true){
	 this.msgDlg = new dojoe.messagedialog.MessageDialog(
		{
			message: this.resources_.CANCEL_MESSAGE,
			messageId: "Confirmation",
			type: "Confirm",
			 namespace	:  this.namespace,
			callback:  dojo.hitch(this, this.onCancelClick) ,
			buttons: [this.resources_.CONFIRM_OK, this.resources_.CONFIRM_CANCEL],
			showCheckbox: false,
		 contentIsolation:true
		 });
		
	}else{
	 this.msgDlg = new dojoe.messagedialog.MessageDialog(
		{
			message: this.resources_.CANCEL_MESSAGE,
			messageId: "Confirmation",
			type: "Confirm",			 
			callback:  dojo.hitch(this, this.onCancelClick) ,
			buttons: [this.resources_.CONFIRM_OK, this.resources_.CONFIRM_CANCEL],
			showCheckbox: false
		 
		 });
		
	
	}
	
	 this.msgDlg.show();
	
   },
  
  
   setMessage:function(msg){
	 //summary: Sets the message generated by user operation.
		  //tags :public
	  this.messageArea.innerHTML=msg;
  },	  
  getProgressIndicatorType : function()
  {
	  //summary:Retuns the type of progressIndicator 0 if indeterminate 1 if determinant
	  //tags:public
    return this.progressIndicatorType;
  },
 /*  setProgressIndicatorType : function(type)
  {
    this.progressIndicatorType=type;
  },*/
  getWidth : function()
  {
	  //summary:returns the width of the progressbar.
	  //tags:public
    return this.width;
  },
   setWidth : function(widthParam)
  {
	  //summary:sets the width of the progressbar
	  //tags:public
    this.width=widthParam;
	this.stylePage();
  },
  getHeight  : function()
  {
	  //summary:returns the height of the progressbar
	  //tags:public
    return this.height;
  },
   setHeight : function(heightParam)
  {
	  //summary:sets the height of the progressbar
	  //tags:public
    this.height=heightParam;
	this.stylePage();
  },
  stylePage: function () {
	  //summary:styles the progressbar by setting height,width,message width
	  //tags:public
		if(this.domNode){
			dojo.style (this.domNode, "top", "0");
			dojo.style (this.domNode, "align", "center");
			//dojo.style (this.progressBarTable, "width", this.width);
			dojo.style (this.progressBarTable, "height", this.height);  
			dojo.style (this.rootDiv, "width", this.width);
			var msgWidth = this.calculateMsgWidth();
			//dojo.style (this.msgareaDiv, "width", this.msgWidth); 
		}
 },
  show: function(  )
  {
	 //summary:display the progressbar
	  //tags:public
	this.stylePage();
	if(this.domNode){
		this.domNode.style.display="";
	}
	//this.rootDiv.style.display="";
  },
 	  
  hide: function() {
	  //summary:hides the progressbar
	  //tags:public
	  if(this.domNode){
			this.domNode.style.display="none";
	  }
	//this.rootDiv.style.display="none";
  },
  //Satanik:03May2011: updating destroy for complete cleanup
  destroy: function(){
			console.info("EPB destroy called.....");
  
			// summary:  Destroys the toolbar.
			// tags: public	
			//memory leak issue: custom destroy method to take care of removing all widgets					
			try{
				//this.domNode was not getting cleanedup completely by the destroy so hiding the dom node.
				this.domNode.style.display = "none";
				delete this.resources_;
				//this is for destroying child templated widgets 
				//this should happen by itself but need to figure out why dijit._Templated is not taking care of it...
				if(this.domNode){
					
					var widgets = dijit.findWidgets(this.domNode);
					dojo.forEach(widgets, function(w) {
						if(w){
							if(w.destroyRecursive){
								w.destroyRecursive();
							} else if(w.destroy){
								w.destroy();
							}
						}
					});
					// this is for widgets added as child to this widget and their children..
					//not present in template
					var widgetArr = this.getChildren();
					dojo.forEach(widgetArr, function (child) {
						if(child){
							if(child.destroyRecursive){
								child.destroyRecursive();
							} else if(child.destroy){
								child.destroy();
							}
						}
					});
					this.inherited(arguments);
					//console.log(this.domNode);
					if(this.domNode) this.domNode.destroy();
				
				}
			}catch(ex){
				console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
			}
		},
  onview:function(){                                   
	  //summary:parses the template
	  //tags:public				
	  dojo.parser.parse(this.progressBarTable);			
  }
}); 



}
