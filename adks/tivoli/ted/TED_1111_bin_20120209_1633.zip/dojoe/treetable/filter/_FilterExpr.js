/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.treetable.filter._FilterExpr"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.treetable.filter._FilterExpr"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/**
 * @author shakeel
 */
//This is the main file that should be 'required' if filter expression facility is necessary.
dojo.provide("dojoe.treetable.filter._FilterExpr");

dojo.require("dojoe.treetable.filter._DataExprs");
dojo.require("dojo.date");

(function(){
	var f_ns = dojoe.treetable.filter;
	/* Logic Operations */
	dojo.declare("dojoe.treetable.filter.LogicAND", f_ns._BiOpExpr, {
		// summary:
		//		A logic AND condition expression.
		_calculate: function(/* _ConditionExpr */left_operand,/* _ConditionExpr */right_operand,
							/* data item*/datarow,/* function(row,colIdx) */getter){
			// summary:
			//		Override from _BiOpExpr
			var res = left_operand.applyRow(datarow, getter).getValue() 
					&& right_operand.applyRow(datarow, getter).getValue();
			return new f_ns.BooleanExpr(res);	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "and";	//string
		}
	});
	dojo.declare("dojoe.treetable.filter.LogicOR", f_ns._BiOpExpr, {
		// summary:
		//		A logic OR condition expression.
		_calculate: function(/* _ConditionExpr */left_operand,/* _ConditionExpr */right_operand,
							/* data item*/datarow,/* function(row,colIdx) */getter){
			// summary:
			//		Override from _BiOpExpr
			var res = left_operand.applyRow(datarow, getter).getValue()
					|| right_operand.applyRow(datarow, getter).getValue();
			return new f_ns.BooleanExpr(res);	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "or";	//string
		}
	});
	dojo.declare("dojoe.treetable.filter.LogicXOR", f_ns._BiOpExpr, {
		// summary:
		//		A logic XOR condition expression.
		_calculate: function(/* _ConditionExpr */left_operand,/* _ConditionExpr */right_operand,
							/* data item*/datarow,/* function(row,colIdx) */getter){
			// summary:
			//		Override from _BiOpExpr
			var left_res = left_operand.applyRow(datarow, getter).getValue();
			var right_res = right_operand.applyRow(datarow, getter).getValue();
			return new f_ns.BooleanExpr((!!left_res) != (!!right_res));	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "xor";	//String
		}
	});
	dojo.declare("dojoe.treetable.filter.LogicNOT", f_ns._UniOpExpr, {
		// summary:
		//		A logic NOT condition expression.
		_calculate: function(/* _ConditionExpr */operand,/* data item*/datarow,/* function(row,colIdx) */getter){
			// summary:
			//		Override from _UniOpExpr
			return new f_ns.BooleanExpr(!operand.applyRow(datarow, getter).getValue());	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "not";	//String
		}
	});
	dojo.declare("dojoe.treetable.filter.LogicALL", f_ns._OperatorExpr, {
		// summary:
		//		A logic ALL condition expression, equals a sequence of logic ANDs
		applyRow: function(/* data item */datarow,/* function(row,colIdx) */ getter){
			// summary:
			//		Override from _ConditionExpr
			for(var i=0,res=true;
				res && (this._operands[i] instanceof f_ns._ConditionExpr);
				(res = this._operands[i].applyRow(datarow,getter).getValue()), ++i);
			return new f_ns.BooleanExpr(res);	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "all";	//String
		}
	});
	dojo.declare("dojoe.treetable.filter.LogicANY", f_ns._OperatorExpr, {
		// summary:
		//		A logic ANY condition expression, equals a sequence of logic ORs
		applyRow: function(/* data item */datarow,/* function(row,colIdx) */ getter){
			for(var i=0,res=false;
				!res && (this._operands[i] instanceof f_ns._ConditionExpr);
				(res = this._operands[i].applyRow(datarow,getter).getValue()), ++i);
			return new f_ns.BooleanExpr(res);	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "any";	//string
		}
	});
	
	/* Comparison Operations */
	function compareFunc(left,right,row,getter){
		var left = left.applyRow(row, getter);
		var right = right.applyRow(row, getter);
		var left_res = left.getValue();
		var right_res = right.getValue();
		if(left instanceof f_ns.TimeExpr){
			return dojo.date.compare(left_res,right_res,"time");
		}else if(left instanceof f_ns.DateExpr){
			return dojo.date.compare(left_res,right_res,"date");
		}else{
			return left_res == right_res ? 0 : (left_res < right_res ? -1 : 1);
		}
	}
	dojo.declare("dojoe.treetable.filter.EqualTo", f_ns._BiOpExpr, {
		// summary:
		//		An "equal to" condition expression.
		_calculate: function(/* _ConditionExpr */left_operand,/* _ConditionExpr */right_operand,
							/* data item*/datarow,/* function(row,colIdx) */getter){
			// summary:
			//		Override from _BiOpExpr
			var res = compareFunc(left_operand,right_operand,datarow,getter);
			return new f_ns.BooleanExpr(res == 0);	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "equal";	//string
		}
	});
	dojo.declare("dojoe.treetable.filter.LessThan", f_ns._BiOpExpr, {
		// summary:
		//		A "less than" condition expression.		
		_calculate: function(/* _ConditionExpr */left_operand,/* _ConditionExpr */right_operand,
							/* data item*/datarow,/* function(row,colIdx) */getter){
			// summary:
			//		Override from _BiOpExpr
			var res = compareFunc(left_operand,right_operand,datarow,getter);
			return new f_ns.BooleanExpr(res < 0);	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "less";	//string
		}
	});
	dojo.declare("dojoe.treetable.filter.LessThanOrEqualTo", f_ns._BiOpExpr, {
		// summary:
		//		A "less than or equal to" condition expression.	
		_calculate: function(/* _ConditionExpr */left_operand,/* _ConditionExpr */right_operand,
							/* data item*/datarow,/* function(row,colIdx) */getter){
			// summary:
			//		Override from _BiOpExpr
			var res = compareFunc(left_operand,right_operand,datarow,getter);
			return new f_ns.BooleanExpr(res <= 0);	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "lessEqual";	//string
		}
	});
	dojo.declare("dojoe.treetable.filter.LargerThan", f_ns._BiOpExpr, {
		// summary:
		//		A "larger than" condition expression.	
		_calculate: function(/* _ConditionExpr */left_operand,/* _ConditionExpr */right_operand,
							/* data item*/datarow,/* function(row,colIdx) */getter){
			// summary:
			//		Override from _BiOpExpr
			var res = compareFunc(left_operand,right_operand,datarow,getter);
			return new f_ns.BooleanExpr(res > 0);	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "larger";	//string
		}
	});
	dojo.declare("dojoe.treetable.filter.LargerThanOrEqualTo", f_ns._BiOpExpr, {
		// summary:
		//		A "larger than or equal to" condition expression.	
		_calculate: function(/* _ConditionExpr */left_operand,/* _ConditionExpr */right_operand,
							/* data item*/datarow,/* function(row,colIdx) */getter){
			// summary:
			//		Override from _BiOpExpr
			var res = compareFunc(left_operand,right_operand,datarow,getter);
			return new f_ns.BooleanExpr(res >= 0);	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "largerEqual";	//string
		}
	});
	
	/* String Operations */
	dojo.declare("dojoe.treetable.filter.Contains", f_ns._BiOpExpr, {
		// summary:
		//		A "contains" condition expression.
		_calculate: function(/* _ConditionExpr */left_operand,/* _ConditionExpr */right_operand,
							/* data item*/datarow,/* function(row,colIdx) */getter){
			// summary:
			//		Override from _BiOpExpr
			var left_res = String(left_operand.applyRow(datarow, getter).getValue());
			var right_res = String(right_operand.applyRow(datarow, getter).getValue());
			return new f_ns.BooleanExpr(left_res.indexOf(right_res) >= 0);	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "contains";	//string
		}
	});
	dojo.declare("dojoe.treetable.filter.ContainsIgnoreCase", f_ns._BiOpExpr, {
		// summary:
		//		A "contains" condition expression.
		fields : [],
		_calculate: function(/* _ConditionExpr */left_operand,/* _ConditionExpr */right_operand,
				/* data item*/datarow,/* function(row,colIdx) */getter){
		// summary:
		//		Override from _BiOpExpr
		var left_res = String(left_operand.applyRow(datarow, getter).getValue()).toLowerCase();
		var right_res = String(right_operand.applyRow(datarow, getter).getValue()).toLowerCase();
		var result = new f_ns.BooleanExpr(left_res.indexOf(right_res) >= 0);	//_ConditionExpr
		if(!result._value && left_operand._colArg.parentCell) {
			//might need to traverse the children if any
			var field = left_operand._colArg.parentCell.field;
			//traverse more if the field does not match the datarow children column 
			if(datarow[field] === undefined && left_operand._colArg.parentCell.children) {
				this.fields = [];
				//this.fields is also populated
				field = this._getDatarowField(left_operand._colArg.parentCell.children, datarow);
			}

			//working on the last child 
			if(dojo.isArray(this.fields) && this.fields.length > 0) {
				for(var i=0; i<this.fields.length; i++) {
					var field = this.fields[i];
					if(datarow[field].length == 1) {
						result = new f_ns.BooleanExpr(datarow[field][0].toString().indexOf(right_res) >= 0);	//_ConditionExpr
						if(result._value) {
							datarow.itemFound = true;
							return result;
						}
					}
				}
			}
			
			//console.log("field :", field);
			var datarowChildren = datarow[field];
			var tempArray = [];
			for(var i in datarowChildren) {
				result = this._calculate(left_operand,right_operand,datarowChildren[i],getter);
				if(datarowChildren[i].itemFound) {
					datarow.itemFound = true;
				}
				if(result._value ) {
                    tempArray.push(datarowChildren[i]);
					datarow[field] = tempArray;
				    datarow.itemFound = true;
				}				
			}
		}
		else {
			if(result._value) {
				//Bobby:25Mar2011, removing console out
				//console.log("--------------------result found : ", left_res ," ", right_res);				
			}
		}
		return result;
		},
		_getDatarowField: function(children, datarow) {
			if(children === undefined) {
				//no more children
				return;
			}
			
			for ( var chld=0; chld<children.length; chld++ ) {				
				var field = children[chld].field;
				if(field !== "label") {
					if(datarow[field] === undefined) {
						field = this._getDatarowField(children[chld].children, datarow);
					}
					if(field != null) {
						this.fields.push(field);
					}					
				}
			}
			return field;
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "containsignorecase";	//string
		}
	});
	dojo.declare("dojoe.treetable.filter.StartsWith", f_ns._BiOpExpr, {
		// summary:
		//		A "starts with" condition expression.
		_calculate: function(/* _ConditionExpr */left_operand,/* _ConditionExpr */right_operand,
							/* data item*/datarow,/* function(row,colIdx) */getter){
			// summary:
			//		Override from _BiOpExpr
			var left_res = String(left_operand.applyRow(datarow, getter).getValue());
			var right_res = String(right_operand.applyRow(datarow, getter).getValue());
			return new f_ns.BooleanExpr(left_res.substring(0, right_res.length) == right_res);	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "startsWith";	//string
		}
	});
	dojo.declare("dojoe.treetable.filter.EndsWith", f_ns._BiOpExpr, {
		// summary:
		//		An "ends with" condition expression.
		_calculate: function(/* _ConditionExpr */left_operand,/* _ConditionExpr */right_operand,
							/* data item*/datarow,/* function(row,colIdx) */getter){
			// summary:
			//		Override from _BiOpExpr
			var left_res = String(left_operand.applyRow(datarow, getter).getValue());
			var right_res = String(right_operand.applyRow(datarow, getter).getValue());
			return new f_ns.BooleanExpr(left_res.substring(left_res.length - right_res.length) == right_res);	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "endsWith";	//string
		}
	});
	dojo.declare("dojoe.treetable.filter.Matches", f_ns._BiOpExpr, {
		// summary:
		//		A "regular expression match" condition expression.
		//		The second operand's value will be regarded as an regular expression string.
		_calculate: function(/* _ConditionExpr */left_operand,/* _ConditionExpr */right_operand,
							/* data item*/datarow,/* function(row,colIdx) */getter){
			// summary:
			//		Override from _BiOpExpr
			var left_res = String(left_operand.applyRow(datarow, getter).getValue());
			var right_res = new RegExp(right_operand.applyRow(datarow, getter).getValue());
			return new f_ns.BooleanExpr(left_res.search(right_res) >=0 );	//_ConditionExpr
		},
		getName: function(){
			// summary:
			//		override from _ConditionExpr
			return "matches";	//string
		}
	});
})();

}
