/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.treetable.TreeTable"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.treetable.TreeTable"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.treetable.TreeTable");
dojo.require("dijit._Widget");
dojo.require("dijit._Templated");
dojo.require("dojox.grid.LazyTreeGrid");
dojo.require("dojo.i18n");
dojo.require('dojo.string');
dojo.require("dojox.grid.cells.dijit");
dojo.require("dojoe.treetable._Toolbar");
dojo.require("dojoe.treetable._IndirectSelection");
dojo.require("dojoe.treetable._QuickSearchFilter");


//NLS
dojo.requireLocalization("dojoe.treetable", "TreeTable", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");

dojo.declare("dojoe.treetable.TreeTable",[ dijit._Widget, dijit._Templated ], {
	//summary: TreeTable is a widget to render data in a tabular tree format. 
	//description: TreeTable widget uses the dojox.grid.LazyTreeGrid for its lazy loading implementation
	// It also has a customizable toolbar with multiple default actions and icons.
	
	//summary: Path to the template
	//tags: private
	templateString : dojo.cache("dojoe.treetable", "templates/TreeTable.html", "\r\n<div class=\"tivTreeTable\" tabIndex=0 aria-label=\"tree table\" role=\"application\">\r\n\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  width=\"100%\" height=\"100%\" style=\"width:100%;height:100%;\"  role=\"presentation\">\t\t\r\n\t\t<tr valign=\"center\"><td width=\"100%\" role=\"toolbar\">\r\n\t\t\t<div dojoAttachPoint=\"toolbarNode\"></div></td></tr>\r\n\t\t<tr valign=\"center\"><td width=\"100%\" role=\"treegrid\">\r\n\t\t\t<div dojoAttachPoint=\"treeGridNode\"></div>\t</td></tr>\t\t\r\n\t</table>\r\n</div>\t\r\n"),

	//summary: Set this to true if your widget contains other widgets
	//tags: private
	widgetsInTemplate : true,
	
	//summary: Keeps all the parameter passed to the grid by the user.
	gridParams:null,
	
	//summary: Reference to the lazy tree grid used
	grid:null,
	
	//summary: control the _toolbar show/hode
	toolbarVisible:true,
	
	//summary: keeps the width of the grid set by user
	width:'',
	
	//summary: keeps the height of the grid set by user
	height:'',
	
	//summary: Keeps all the toolbar icons visibility information passed by the user.
	toolbarOptions:null,
	
	//summary: keeps track of the menu event object which provides the context value when right clicked
	onContextMenuEvtObj: null,
	
	//summary: To resize the table on a particular event, connect the event to table's resize() function
	//description: enableResize: true, to enable the table resize when the window resizes
	//enableResize: false, to disable table resize on window resize event.
	//default true, set false to disable table resize on window resize event	
	enableResize:true,			
	
	//summary: Reference to the toolbar
	//tags: private
	_toolbar:null,
	
	//summary: Set the table with the default height
	_defaultHeight: '80%',
	
	//sum	mary: Set the table with the default width
	_defaultWidth: '80%',
	
	//Summary: Set table with basic Selection, if set to true enables Indirect selection Single and multiple grid selection modes
	indirectSelection: false,
	
	enableColumnReorder:true,
	
	state: null,
	
	_loadIndSelection: null,
	
	constructor: function(args){
		//this.inherited( args );
		//console.info("constructor called");
		this.resources_ = dojo.i18n.getLocalization("dojoe.treetable", "TreeTable",this.lang);
		this.gridParams = {};
		this.actionList = {};
		//dojo.mixin( this, { style: "height: 100%; width: 100%;" } );
	},
	
	postCreate: function(){
	//summary: creates and initialize the treetable 
	//tags: public
	    //if no width is given default is set
        if(this.width ===''&& !this.gridParams.autoWidth){
			this.width = this._defaultWidth;
		}
		//if no height is given default is set
		if(this.height ===''){
			this.height = this._defaultHeight;
		}
		
        var size = dijit.getViewport();
		var heightPx = this.height;
		var sizeType = this.height.substring(this.height.length-1, this.height.length);
		//if the height is given in % then translate it to pixel
		if(sizeType == "%") {
			//convert to px
			heightPx = size.h * ((parseInt(this.height.slice(0, -1))) / 100);
			heightPx = heightPx + "px";
		}
		if( !this.gridParams.autoWidth){
			dojo.style(this.domNode, "width", this.width);
		}
		dojo.style(this.domNode, "height", heightPx);
		//Bobby:17Mar2011
		//Disable column reordering and provide this via Configure Options
		this.gridParams.columnReordering = false;

		//Satanik:30Mar2011: selection is remembered by rowId instead of index if keepSelection = true		
		//Satanik:10Jun2011: as per ILMT request this is configurable now and i moved it under makeGrid method		
		//23907: Treetable - unexpected selection change on collapse/expand
		//Bobby:30Jun11, this should be set before creating grid, so adding the check here itself!
		if(this.gridParams.keepSelection == undefined){
			this.gridParams.keepSelection = true;
		}
		
		//According to BJ Tivoli doesn't need rowSelector. rowSelector is useless with indirectSelection
		if (!this.gridParams.rowSelector || this.gridParams.indirectSelection) this.gridParams.rowSelector = false;
		//Satanik:13Jun2011: added check for the structure is null or not.
		if(this.gridParams.structure === null){
			this.gridParams.structure=[{}];
		}
		this._makeGrid();
		
		/*Satanik:14Mar11 Not able to disable sorting in TreeGrid and is causing more problems
		this.grid.canSort = function(col){
			if(this.indirectSelection){
				if(Math.abs(col) == 2) { 
					return true; 
				} else { 
					return false; 
				}
			}else{
				if(Math.abs(col) == 1) { 
					return true; 
				} else { 
					return false; 
				}			
			}				
		}
		*/
		//console.dir(dojox.grid._TreeGridContentBuilder.prototype);
		//17606: TreeTable: quickfilter actions showing only 1st tree level, quicfilter disabling results in error
		//Bobby:22Apr2011 Adding option to show hierarchy if someone wants to implement on serverside
		if(this.gridParams.filter && this.gridParams.filter.showHierarchy){		
		}else{		
			this.grid.treeModel.mayHaveChildren = dojo.hitch(this.grid,function(/*dojo.data.Item*/ item){
				var children = null;
				//console.dir(this.cache);
				//console.debug('filter??????'+this.filterApplied);
				if(this.filterApplied) {
					return false;			
				}
				/*Adding one more condition 'dojo.isArray(children)' to support CustomQueryReadStore*/
				/*this should be also present in customTreeGridModel so that when this part of code is removed after filter hierarchy impl
				CustomQueryStore support is not broken*/
				return dojo.some(this.treeModel.childrenAttrs, function(attr){
					children = this.treeModel.store.getValue(item, attr);
					if(dojo.isString(children)){
						return parseInt(children, 10) > 0 || children.toLowerCase() === "true" ? true : false;
					}else if(typeof children == "number"){
						return children > 0;
					}else if(typeof children == "boolean"){
						return children;
					}else if(this.store.isItem(children)){
						children = this.treeModel.store.getValues(item, attr);
						return dojo.isArray(children) ? children.length > 0 : false;
					}else if(dojo.isArray(children) ){
						return children.length > 0;
					}else{
							return false;
						}
				}, this);
			});
		}
		
		if(this.menu !== null){
			dojo.connect(this.grid, "onRowContextMenu", dojo.hitch(this, "showRowContextMenu"));
		}
		if(this.toolbarVisible ){
			this._toolbar = new dojoe.treetable._Toolbar({treeTable:this,filterOptions:this.gridParams.filter}, this.toolbarNode);
		}
		
		/* #8414 - height issue - call resize regardless of 'enableResize' is true/false 
			if 'enableResize' is true then connect resize to window resize */
		this.resize();
		if(this.enableResize === true) {
	     	this.connect(window, "onresize", dojo.hitch(this, "resize"));			
		}
		//connecting to the header node click event
		//dojo.connect(dojo.byId('selectDiv'), 'onclick', dojo.hitch(this,"selectHeaderRow"));
		//Bobby:15Mar11, above doesn't work!
		//dojo.connect(this.grid, 'onHeaderCellClick', dojo.hitch(this,"selectHeaderRow"));//selectAll/deselectAll
		//Disabling above event as sort cannot be disabled in LazyTreeGrid as of now.
		
		//dojo.connect(this.grid, 'onMoveColumn', dojo.hitch(this,"_disableColumnMove"));//need to fix first two columns
		
		//Satanik: 13Apr2011: adding listener function for the notification of action list open event.
		//Bobby,14Apr2011: Adding check for toolbar and actionListWidget
		if(this._toolbar && this._toolbar.actionListWidget){	
			//dojo.connect(this._toolbar.actionListWidget, 'onClick', dojo.hitch(this,"onActionListOpen"));
			//dojo.connect(this._toolbar.actionListWidget, 'onKeyDown', dojo.hitch(this,"onActionListOpen")); 
			//Bobby,13Apr2011: adding listener functions for the notification of action list open/close.	
			this.connect(this._toolbar.actionListWidget, 'openDropDown', dojo.hitch(this,"onActionListOpen")); 			
			this.connect(this._toolbar.actionListWidget, 'closeDropDown', dojo.hitch(this,"onActionListClose")); 
		}
		
		if(this.grid.defaultState && this.grid.defaultState.filter){
			// TODO: restore custom state
			//console.info("Restoring filter:"+this.grid.defaultState.filter);
			this.setFilter(this.grid.defaultState.filter);
		}		
		//Satanik:08Jun2011: adding the _preFilter for enable filter on rendering
		if(this.gridParams.preFilter){
			dojo.connect(this, 'onTreeTableLoad', dojo.hitch(this,"_preFilter"));
		}
		
		//Bobby: 04Mar11
		//Event generated on completion of TreeTable load
		setTimeout(dojo.hitch(this, "onTreeTableLoad", this), 1000);
		//this.onTreeTableLoad(this);		
	},
	
	//Connect to this to monitor TreeTable load complete.
	onTreeTableLoad: function(treetable){
		console.info("TreeTable load complete....."+treetable.id);
	},
	//Satanik:08Jun2011: adding the _preFilter for enable filter on rendering
	_preFilter : function(){
		if (this.gridParams.preFilter) {
				if(this.gridParams.preFilter[0].column==='any'){
					//is.grid._cleanup(); 
					//this.grid._clearData();
					if(this.gridParams.preFilter[0].value){
						this.setFilter(this.gridParams.preFilter[0].value);
					}
				}
		}
	},
	
	//Connect to this to monitor Opening of actionList
	onActionListOpen : function(){
		//console.info("actionListOpen.....");
	},
	
	//Connect to this to monitor Closing of actionList
	onActionListClose : function(){
		//console.info("actionListClosed.....");
	},
	
	_disableColumnMove: function(event){
		console.info("_disableColumnMove.....");
		//console.dir(event);
		if(event){
			try{
				event.cancelBubble = true;
				dojo.stopEvent(event);
			}catch(e){
				console.error(e);
			}
		}
	},	
	
	setFilter : function (filterText){
		if(this._toolbar){
			if(this._toolbar.quickFilter){
				this._toolbar.quickFilter._setFilter(filterText);
			}
		}
	},
		
	getFilter : function(){
		if(this._toolbar){
			if(this._toolbar.quickFilter){
				return this._toolbar.quickFilter._getFilter();
			}
		}
	},	
	
	//Bobby:01Jun11. New API to retrieve and restore TreeTable state
	//Bobby:07Jun11. setState is not fully supported by LazyTreeGrid, use defaultState param while instantiating instead
	_setState : function (stateObj){
		console.info("setState -> state:");
		console.log(stateObj);
		if(stateObj){
			//this.gridParams.cachedItems = stateObj.grid;
			this.gridParams.defaultState = stateObj;
		}
	},
		
	getState : function(){
		/*state = new Object();
		state.grid = this.grid.cache.getCurrentCachedItems();*/
		state = this.grid.getState();
		console.info("getState -> state:");
		console.log(state);
		//return state;
		return dojo.mixin({filter: this.getFilter()}, state);
	},	
	
	//method to handle the header row click for select/deselect all
	selectHeaderRow : function(event){	
			//console.dir(event);
			//console.log("event.cell.field:"+event.cell.field);
			if(event.cell.field != 'selector'){
				return;
			}
			//event.cancelBubble = true;
			var headerdiv=dojo.byId("selectDiv");
			//Bobby:15Mar2011, why is this reqd?
			//this.deSelectAllRows();
			if(dojo.hasClass(headerdiv,"treeTableToggleButtonChecked")){
				dojo.removeClass(headerdiv, ["treeTableToggleButtonChecked"]);
				dojo.addClass(headerdiv, ["treeTableCheckBox"]);
				this.deSelectAllRows();
			} else{
				dojo.removeClass(headerdiv, ["treeTableCheckBox"]);
				//dojo.addClass(headerdiv, ["treeTableToggleButtonChecked"]);
				this.selectAllRows();
				dojo.addClass(headerdiv, ["treeTableToggleButtonChecked"]);
			}
		if(event){
			try{
				event.cancelBubble = true;
				dojo.stopEvent(event);
			}catch(e){
				console.error(e);
			}
		}
	},

	_makeGrid: function(){
		//creates the lazy tree grid instance and initialize it
		//tags: private
		if(this.gridParams.indirectSelection){
			this.indirectSelection=this.gridParams.indirectSelection;
		}	
		//Satanik:25May2011: changes made to address ILMT requiremnt 19890
		if(this.gridParams.enableColumnReorder === false){
			this.enableColumnReorder=this.gridParams.enableColumnReorder;
		}
		
		//Bobby:01Jun11, Currently state can be set only before initializing grid!
		if(this.state) this._setState(this.state);	
		
		this.grid=new dojox.grid.LazyTreeGrid(this.gridParams,this.treeGridNode);
		//to display the default when grid is empty or filter result is none
		if(!this.gridParams.noDataMessage){
			this.grid.noDataMessage=this.resources_.NO_DATA;
		}
		else{
			this.grid.noDataMessage=this.gridParams.noDataMessage;
		}
		//startup and resize has problems when grid is added to a custom widget _widget
		//so set appropriate height and width to grid domNode, update and parse the domNode after resize
		//dojo.connect(this.grid,"_resize",this,"parseGrid");
		//this.resize();
		
		//#8414: table height is not proper with px/em  
		//do not resize grid before building the toolbar since toolbar height is not fixed anymore
			
		//if(this.enableResize === true) {
		//     dojo.connect(window, "onresize", this, "resize");
		//}
		
		
		//Satanik:09Jun2011: enabling the selection as default in treetable
		if(this.gridParams.selectable !== undefined){
			this.grid.selectable = this.gridParams.selectable;
		} else{
			this.grid.selectable = true;
		}
		
		//23907: Treetable - unexpected selection change on collapse/expand
		//Bobby:30Jun11, this should be set before creating grid		
		//Satanik:10Jun2011: keepSelection can be configured by setting the grid param.
		/*if(this.gridParams.keepSelection !== undefined){
			this.grid.keepSelection = this.gridParams.keepSelection;
		} else{
			//Bobby:30Jun11, this should be grid and not gridParams	
			this.gridParams.keepSelection = true;
		}*/		
			
		this.grid.startup();	

		//Indirect selection is a new class now, create if indirect selection is enabled for treetable
		//this feature is supported on top of LazyTreeGrid. Once dojo incorporates indirect selection plugin, this can be removed 
		if(this.indirectSelection){
			//enabled
			this._loadIndSelection = new dojoe.treetable._IndirectSelection(this.grid);
		}	
	},
		
	showRowContextMenu: function(e){
	//summary: Allows the context menu hooking up with the treetable and also returns the contextEvent Object
	//tags: public
		if(this.menu){
			this.menu._openMyself({
				target: e.target,
				coords: "pageX" in e ? {
					x: e.pageX,
					y: e.pageY
				} : null
			});
		}
		return e;
		// you could also just return e.cell/e.cellNode/e.cellIndex/e.rowNode/e.rowIndex/...
		// in order to stop the oncontextmenu event, below is the example
		// var rowNode = e.rowNode;
		// dojo.stopEvent(e);
		// return rowNode;
	},	
	
	addToActionList: function(item) {
	//summary: To add a new item to the toolbar action menu
	//tags: public
		if(this._toolbar) {
			if(this._toolbar.actionMenu) {
				this._toolbar.actionListWidget.dropDown.addChild(item,0);
			}
		}
	},
	
	addContextMenuToTreeTable: function(position, customMenu){
		//summary: Allows adding a context menu to the TreeTable
		//tags: public
		if(position == "rowMenu") {
			customMenu.bindDomNode(this.grid.domNode);
			this.grid.onRowContextMenu = function(e){				
				if(!this.menu){
					this.menu = customMenu;
				}
			};
		}
	},
		
	//20470: Tivtable: Same Issue with  TreeTable load takes significant amount of time to load
	//Satanik:25May11, adding noResize to control Table resize
	//resize is very costly in iWidgets
	addToToolbar : function (item, position, row, noResize) {
			// summary:  Add an item to the toolbar
			// tags: public
			// item:  object   The item that needs to be added
			// position:  number The position of the item in number
			// row:  number The row number to which the item needs to be added
			// noResize: boolean To control whether a table resize should be done or not
			if (this._toolbar) {
				if (row && row == 2) {
					this._toolbar._addToToolbarSecondRow(item, position);
				} else {
					this._toolbar._addToToolbarFirstRow(item, position);
				}
				/* #8414: height issue - call resize on this widget whenever toolbar layout is modified, 
				this way new toolbar height can be calculated and grid can be resized accordingly*/
				//20May2011: Bobby
				//performance issue when multiple items are added to toolbar (Sunset/Analytics)
				if(noResize == false){}
				else this.resize();						
			}
	}, 
		
	//20470: Tivtable: Same Issue with TreeTable load takes significant amount of time to load
	//Satanik:25May11, new API to add multiple toolbar items together		
	addItemsToToolbar : function (items, position, row, noResize) {
			// summary:  Add an item to the toolbar
			// tags: public
			// items:  array   The items that needs to be added
			// position:  number The position of the item in number
			// row:  number The row number to which the item needs to be added
			// noResize: boolean To control whether a table resize should be done or not
			if (this._toolbar) {
				for (var i = 0; i < items.length; i++) {		
					if (row && row == 2) {
						this._toolbar._addToToolbarSecondRow(items[i], position + i);
					} else {
						this._toolbar._addToToolbarFirstRow(items[i], position + i);
					}
				}
				/* #8414: height issue - call resize on this widget whenever toolbar layout is modified, 
				this way new toolbar height can be calculated and grid can be resized accordingly*/
				//20May2011: Bobby
				//performance issue when multiple items are added to toolbar (Sunset/Analytics)
				if(noResize == false){}
				else this.resize();				
			}
	}, 		
	
	
	getItem: function(/*Integer */rowId){
		//summary: Returns the rowItem when rowId is supplied
		//tags: public
		//summary: Gets a rowItem
		//return: the rowItem if rowId is passed		
		return this.grid.getItem(rowId);
	},
	
	getRowCount : function(){
		//summary: Gets a rowCount of the table
		//tags: public
		//return: the rowCount		
		return this.grid.rowCount;
	},
	
	getSelectedRowCount : function(){
		//summary: Gets a selected rowCount of the table
		//tags: public
		//return: the selected rowCount
		return this.grid.selection.getSelectedCount();
	},
	
	getSelectedRows : function(){
		// summary:   Returns the selected rows from the grid.
		// tags: public
		// returns: selected rows.
		return this.grid.selection.getSelected();
	},	
	
	removeSelectedRows : function(){
		//summary: deletes selected rows from the treetable
		//tags: public
		this.grid.removeSelectedRows();
	},
	
	isRowSelected: function(rowId){
		//summary: Return true if a given row is selected when its id is supplied
		//tags: public
		return this.grid.selection.isSelected(rowId);
	},
	
	disableMenuItem : function(menuid){
		//summary: Disable a menu item of the context menu attached to the treetable.
		//tags: public
		var menuitem= dijit.byId(menuid);
		if(menuitem) {
			menuitem.setDisabled(true);
		}
	},
	
	enableMenuItem : function(menuid){
		//summary: Enable a menu item of the context menu attached to the treetable.
		//tags: public
		var menuitem= dijit.byId(menuid);
		if(menuitem) {
			menuitem.setDisabled(false);
		}
	},
	
     refresh: function(forceRefresh) {
    	//summary: Refreshes the grid with updated values
    	//tags: public
    	//Satanik: 5Apr2011: added for CURI store notification of refresh in progress
    	
		if (this.grid.store.CURIRefresh) {
			this.grid.store.CURIRefresh();
			/*LA - 09/01/2012 - TWL - 16212- TreeTable CURI refresh not clearing cache*/
			//cleanup the grid cache to reload the data from the CURI store..
			this.grid._cleanup();
		}
		//setting forceRefresh true clears the LTG cache so that data from stores is reloaded...
		if(forceRefresh){
			this.grid._cleanup();
		}
		var scrollpos = this.grid.scrollTop;
		this.grid._refresh(true);
		this.grid.setScrollTop(scrollpos);
    },
    
	removeMenuItem : function (menuid){
		//summary: Removes menu item from the context menu
		//tags: public
		var menuitem= dijit.byId(menuid);
		if(menuitem) {
			menuitem.destroyRecursive();
		}
	},
	
	deleteRow: function(item){
		//summary: deletes a item from store attached to the tree table
		//tags: public
		//item: Row element of the table
		this.grid.store.deleteItem(item);
	},
	
	removeItemFromToolbar: function(itemId){
		//summary: to remove an item from the toolbar
		//tags: public
		//itemId: String
		if(this._toolbar) {
			this._toolbar._removeItem(itemId);
		}			
	},
	
	removeFromActionList: function (menuItemId){
		//summary: Removes an action menuItem from ActionList
		//tags: public
		//menuItemId : String
		//				Id of the menuItem to be removed.
		if(this._toolbar) {
			this._toolbar._removeFromActionList(menuItemId);
		}
	},
	
	addRow: function(item,parent) {
		//summary: Allows adding a new row to the treetable
		//tags: public
		//description: If now row is selected then the new row will be added at the end of the table.
		//If the row is selected to be as a parent then the new row will be added as a child to that row.
		if(this._toolbar){
			if(this._toolbar.quickFilter && this._toolbar.quickFilter.filterText !== null){
				this._toolbar.quickFilter._clearFilter();
			}
			this._toolbar._clearSort();
		}
		//summary: add a row to the table and scroll to it
		//item: Row element of the table
		if(!parent){
			if(this.grid){
				var selectedItem = this.grid.store.newItem(item);
				var rowIndex = this.grid.getItemIndex(selectedItem);
				this.grid.scrollToRow(rowIndex);
			}
		}else{
			var s = this.grid.store;
			s.fetchItemByIdentity({identity: parent, onItem: function(item){
				parent = item;
			}});
			if(parent){
				s.newItem(item, {parent: parent, attribute: "children"});
			}				
		}
	},
	//Satanik:25May2011:syncing the resize with table resize	
	resize : function (event) {
		// summary:  Resizes the table with the specified width and height
		// tags:  public
		
		//17074: Javascript error in resize( ) sometimes on IE8
		//if we have set up everything except the DOM, we cannot resize
		//if (!this.domNode.parentNode || this.domNode.parentNode.nodeType != 1) {
		if (!this.grid || !this.domNode || !this.domNode.parentNode || this.domNode.parentNode.nodeType != 1) {
			return;
		}
		/*supporting autoWidth feature of grid*/
		if (!this.grid.autoWidth) {
			dojo.style(this.domNode, "width", this.width);
			
		} else {
			dojo.style(this.domNode, "width", dojo.marginBox(this.grid.domNode).w + 'px');
		}
		var resizeEvent = false;
		if(event && event.currentTarget){
			resizeEvent = true;
		}
		var size = dijit.getViewport();
		if(event && event.h) {
			size = event;
		}

		/*LS - 6 Jan 2012 - added this to keep in sync with table*/
		if(this._previousSize && this._previousSize.h == size.h && this._previousSize.w == size.w && resizeEvent == true){
				//console.warn(this.id+":Not resizing since there is no change in viewport size, wrong resize event!!!");
				return;				
			}else{
				//console.info(this.id+":resizing...");
				this._previousSize =  size;
			}		
		
		var heightPx = this.height;
		
		if (!(this.domNode.parentNode.style && this.domNode.parentNode.style.height)) {
			var sizeType = this.height.substring(this.height.length - 1, this.height.length);
			//if the height is given in % then translate it to pixel
			if (sizeType == "%") {
				//convert to px
				heightPx = size.h * ((parseInt(this.height.slice(0, -1))) / 100);
				heightPx = heightPx + "px";
			}
		}
		
		dojo.style(this.domNode, "height", heightPx);
		/*LS-29/09/2011 - #22273,#22274,#27221 - resize issues*/
		setTimeout(dojo.hitch(this, function(){this._delayResize(event);}), 100);
	},
	
	_delayResize: function (event) {
		// summary:  invoked with dealy for grid resize.
		///*LS-29/09/2011 - #22273,#22274,#27221 - resize issues*/
		// tags: private
		
		/*using marginBox to include margins/borders of the domNode*/
		var tableSize = dojo.marginBox(this.domNode);
		/*grid height is total grid height - margins/padding calculating actual grid height for resize*/
		var gridPadBorder = this.grid._getPadBorder().h;
		
		/* #12836 - commenting the below fix as there were few resizing issues....*/			
		/* # 8414: height issue - check for height type and if in '%' just call resize on grid, grid will automatically fit into the layout */
		//var sizeType = this.height.substring(this.height.length-1, this.height.length);
		//if(sizeType !== "%") {
		if (this._toolbar) {
			/*calculating toolbarsize including margins and borders as they contibute to some height*/
			var toolbarSize = dojo.marginBox(this._toolbar.domNode);
			//removing grid padding height which will be later added when pagination bar is placed and grid view node is resized.
			tableSize.h = tableSize.h - toolbarSize.h - (2 * gridPadBorder);				
		}
		/*LS - 06 Jan 2012 - 14602 - Resize issue with tables in multiple tabs, 
				15999 - TED table should not attempt to resize when hidden 
				also applicable for tree table..*/
		if((tableSize.h <= 0 || tableSize.w <= 0 )){
			return;
		}
		/*LS - 18 Aug 2011 - 22072: Table resize issue*/
		//Applying this change as it exists for Tree table also
		//IWidget resize issue- grid was not getting proper width on window resize so on resizEvent(window resize) setting table width explicitly to grid
		if(event && event.currentTarget){
			this.grid.resize({
				h : tableSize.h,
				w : tableSize.w
			});
		}else{
			this.grid.resize({
				h : tableSize.h
			});
		}
	},
		
	destroy: function(){
		// summary:  Destroys the toolbar.
		// tags: public	
		//memory leak issue: custom destroy method to take care of removing all widgets					
		try{
			//21064: In Treetable, Clear filter does not work after "Destroy and Restore Treetable" action.
			//Bobby:04Jul11, the filter layer needs to be destroyed too
			if(this._toolbar && this._toolbar.quickFilter){
				this._toolbar.quickFilter.unWrapStore();
			}		
			
			if(this.menu){
				this.menu.destroyRecursive();
			}
			delete this.resources_;			
			if(this._loadIndSelection) this._loadIndSelection.destroy(); 
			//this is for destroying child templated widgets 
			//this should happen by itself but need to figure out why dijit._Templated is not taking care of it...
			var widgets = dijit.findWidgets(this.domNode);
			dojo.forEach(widgets, function(w) {
				if(w){
					if(w.destroyRecursive){
						w.destroyRecursive();
					} else if(w.destroy){
						w.destroy();
					}
				}
			});
			// this is for widgets added as child to this widget and their children..
			//not present in template
			var widgetArr = this.getChildren();
			dojo.forEach(widgetArr, function (child) {
				if(child){
					if(child.destroyRecursive){
						child.destroyRecursive();
					} else if(child.destroy){
						child.destroy();
					}
				}
			});
			this.inherited(arguments);
		}catch(ex){
			console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
		}
	}	
});


String.prototype.startWith = function(str){
	if(str==null||str==""||this.length==0||str.length>this.length){return false;}
	if(this.substring(0,str.length)==str){
		return true;
	}else{
		return false;
	}		
}

}
