/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*
	This is an optimized version of Dojo, built for deployment and not for
	development. To get sources and documentation, please visit:

		http://dojotoolkit.org
*/

if(!dojo._hasResource["dijit._base.manager"]){
dojo._hasResource["dijit._base.manager"]=true;
dojo.provide("dijit._base.manager");
dojo.declare("dijit.WidgetSet",null,{constructor:function(){
this._hash={};
this.length=0;
},add:function(_1){
if(this._hash[_1.id]){
throw new Error("Tried to register widget with id=="+_1.id+" but that id is already registered");
}
this._hash[_1.id]=_1;
this.length++;
},remove:function(id){
if(this._hash[id]){
delete this._hash[id];
this.length--;
}
},forEach:function(_2,_3){
_3=_3||dojo.global;
var i=0,id;
for(id in this._hash){
_2.call(_3,this._hash[id],i++,this._hash);
}
return this;
},filter:function(_4,_5){
_5=_5||dojo.global;
var _6=new dijit.WidgetSet(),i=0,id;
for(id in this._hash){
var w=this._hash[id];
if(_4.call(_5,w,i++,this._hash)){
_6.add(w);
}
}
return _6;
},byId:function(id){
return this._hash[id];
},byClass:function(_7){
var _8=new dijit.WidgetSet(),id,_9;
for(id in this._hash){
_9=this._hash[id];
if(_9.declaredClass==_7){
_8.add(_9);
}
}
return _8;
},toArray:function(){
var ar=[];
for(var id in this._hash){
ar.push(this._hash[id]);
}
return ar;
},map:function(_a,_b){
return dojo.map(this.toArray(),_a,_b);
},every:function(_c,_d){
_d=_d||dojo.global;
var x=0,i;
for(i in this._hash){
if(!_c.call(_d,this._hash[i],x++,this._hash)){
return false;
}
}
return true;
},some:function(_e,_f){
_f=_f||dojo.global;
var x=0,i;
for(i in this._hash){
if(_e.call(_f,this._hash[i],x++,this._hash)){
return true;
}
}
return false;
}});
(function(){
dijit.registry=new dijit.WidgetSet();
var _10=dijit.registry._hash,_11=dojo.attr,_12=dojo.hasAttr,_13=dojo.style;
dijit.byId=function(id){
return typeof id=="string"?_10[id]:id;
};
var _14={};
dijit.getUniqueId=function(_15){
var id;
do{
id=_15+"_"+(_15 in _14?++_14[_15]:_14[_15]=0);
}while(_10[id]);
return dijit._scopeName=="dijit"?id:dijit._scopeName+"_"+id;
};
dijit.findWidgets=function(_16){
var _17=[];
function _18(_19){
for(var _1a=_19.firstChild;_1a;_1a=_1a.nextSibling){
if(_1a.nodeType==1){
var _1b=_1a.getAttribute("widgetId");
if(_1b){
var _1c=_10[_1b];
if(_1c){
_17.push(_1c);
}
}else{
_18(_1a);
}
}
}
};
_18(_16);
return _17;
};
dijit._destroyAll=function(){
dijit._curFocus=null;
dijit._prevFocus=null;
dijit._activeStack=[];
dojo.forEach(dijit.findWidgets(dojo.body()),function(_1d){
if(!_1d._destroyed){
if(_1d.destroyRecursive){
_1d.destroyRecursive();
}else{
if(_1d.destroy){
_1d.destroy();
}
}
}
});
};
if(dojo.isIE){
dojo.addOnWindowUnload(function(){
dijit._destroyAll();
});
}
dijit.byNode=function(_1e){
return _10[_1e.getAttribute("widgetId")];
};
dijit.getEnclosingWidget=function(_1f){
while(_1f){
var id=_1f.getAttribute&&_1f.getAttribute("widgetId");
if(id){
return _10[id];
}
_1f=_1f.parentNode;
}
return null;
};
var _20=(dijit._isElementShown=function(_21){
var s=_13(_21);
return (s.visibility!="hidden")&&(s.visibility!="collapsed")&&(s.display!="none")&&(_11(_21,"type")!="hidden");
});
dijit.hasDefaultTabStop=function(_22){
switch(_22.nodeName.toLowerCase()){
case "a":
return _12(_22,"href");
case "area":
case "button":
case "input":
case "object":
case "select":
case "textarea":
return true;
case "iframe":
var _23;
try{
var _24=_22.contentDocument;
if("designMode" in _24&&_24.designMode=="on"){
return true;
}
_23=_24.body;
}
catch(e1){
try{
_23=_22.contentWindow.document.body;
}
catch(e2){
return false;
}
}
return _23.contentEditable=="true"||(_23.firstChild&&_23.firstChild.contentEditable=="true");
default:
return _22.contentEditable=="true";
}
};
var _25=(dijit.isTabNavigable=function(_26){
if(_11(_26,"disabled")){
return false;
}else{
if(_12(_26,"tabIndex")){
return _11(_26,"tabIndex")>=0;
}else{
return dijit.hasDefaultTabStop(_26);
}
}
});
dijit._getTabNavigable=function(_27){
var _28,_29,_2a,_2b,_2c,_2d,_2e={};
function _2f(_30){
return _30&&_30.tagName.toLowerCase()=="input"&&_30.type&&_30.type.toLowerCase()=="radio"&&_30.name&&_30.name.toLowerCase();
};
var _31=function(_32){
dojo.query("> *",_32).forEach(function(_33){
if((dojo.isIE&&_33.scopeName!=="HTML")||!_20(_33)){
return;
}
if(_25(_33)){
var _34=_11(_33,"tabIndex");
if(!_12(_33,"tabIndex")||_34==0){
if(!_28){
_28=_33;
}
_29=_33;
}else{
if(_34>0){
if(!_2a||_34<_2b){
_2b=_34;
_2a=_33;
}
if(!_2c||_34>=_2d){
_2d=_34;
_2c=_33;
}
}
}
var rn=_2f(_33);
if(dojo.attr(_33,"checked")&&rn){
_2e[rn]=_33;
}
}
if(_33.nodeName.toUpperCase()!="SELECT"){
_31(_33);
}
});
};
if(_20(_27)){
_31(_27);
}
function rs(_35){
return _2e[_2f(_35)]||_35;
};
return {first:rs(_28),last:rs(_29),lowest:rs(_2a),highest:rs(_2c)};
};
dijit.getFirstInTabbingOrder=function(_36){
var _37=dijit._getTabNavigable(dojo.byId(_36));
return _37.lowest?_37.lowest:_37.first;
};
dijit.getLastInTabbingOrder=function(_38){
var _39=dijit._getTabNavigable(dojo.byId(_38));
return _39.last?_39.last:_39.highest;
};
dijit.defaultDuration=dojo.config["defaultDuration"]||200;
})();
}
if(!dojo._hasResource["dojo.Stateful"]){
dojo._hasResource["dojo.Stateful"]=true;
dojo.provide("dojo.Stateful");
dojo.declare("dojo.Stateful",null,{postscript:function(_3a){
if(_3a){
dojo.mixin(this,_3a);
}
},get:function(_3b){
return this[_3b];
},set:function(_3c,_3d){
if(typeof _3c==="object"){
for(var x in _3c){
this.set(x,_3c[x]);
}
return this;
}
var _3e=this[_3c];
this[_3c]=_3d;
if(this._watchCallbacks){
this._watchCallbacks(_3c,_3e,_3d);
}
return this;
},watch:function(_3f,_40){
var _41=this._watchCallbacks;
if(!_41){
var _42=this;
_41=this._watchCallbacks=function(_43,_44,_45,_46){
var _47=function(_48){
if(_48){
_48=_48.slice();
for(var i=0,l=_48.length;i<l;i++){
try{
_48[i].call(_42,_43,_44,_45);
}
catch(e){
console.error(e);
}
}
}
};
_47(_41["_"+_43]);
if(!_46){
_47(_41["*"]);
}
};
}
if(!_40&&typeof _3f==="function"){
_40=_3f;
_3f="*";
}else{
_3f="_"+_3f;
}
var _49=_41[_3f];
if(typeof _49!=="object"){
_49=_41[_3f]=[];
}
_49.push(_40);
return {unwatch:function(){
_49.splice(dojo.indexOf(_49,_40),1);
}};
}});
}
if(!dojo._hasResource["dijit._WidgetBase"]){
dojo._hasResource["dijit._WidgetBase"]=true;
dojo.provide("dijit._WidgetBase");
(function(){
dojo.declare("dijit._WidgetBase",dojo.Stateful,{id:"",lang:"",dir:"","class":"",style:"",title:"",tooltip:"",baseClass:"",srcNodeRef:null,domNode:null,containerNode:null,attributeMap:{id:"",dir:"",lang:"","class":"",style:"",title:""},_blankGif:(dojo.config.blankGif||dojo.moduleUrl("dojo","resources/blank.gif")).toString(),postscript:function(_4a,_4b){
this.create(_4a,_4b);
},create:function(_4c,_4d){
this.srcNodeRef=dojo.byId(_4d);
this._connects=[];
this._subscribes=[];
if(this.srcNodeRef&&(typeof this.srcNodeRef.id=="string")){
this.id=this.srcNodeRef.id;
}
if(_4c){
this.params=_4c;
dojo._mixin(this,_4c);
}
this.postMixInProperties();
if(!this.id){
this.id=dijit.getUniqueId(this.declaredClass.replace(/\./g,"_"));
}
dijit.registry.add(this);
this.buildRendering();
if(this.domNode){
this._applyAttributes();
var _4e=this.srcNodeRef;
if(_4e&&_4e.parentNode&&this.domNode!==_4e){
_4e.parentNode.replaceChild(this.domNode,_4e);
}
}
if(this.domNode){
this.domNode.setAttribute("widgetId",this.id);
}
this.postCreate();
if(this.srcNodeRef&&!this.srcNodeRef.parentNode){
delete this.srcNodeRef;
}
this._created=true;
},_applyAttributes:function(){
var _4f=function(_50,_51){
if((_51.params&&_50 in _51.params)||_51[_50]){
_51.set(_50,_51[_50]);
}
};
for(var _52 in this.attributeMap){
_4f(_52,this);
}
dojo.forEach(this._getSetterAttributes(),function(a){
if(!(a in this.attributeMap)){
_4f(a,this);
}
},this);
},_getSetterAttributes:function(){
var _53=this.constructor;
if(!_53._setterAttrs){
var r=(_53._setterAttrs=[]),_54,_55=_53.prototype;
for(var _56 in _55){
if(dojo.isFunction(_55[_56])&&(_54=_56.match(/^_set([a-zA-Z]*)Attr$/))&&_54[1]){
r.push(_54[1].charAt(0).toLowerCase()+_54[1].substr(1));
}
}
}
return _53._setterAttrs;
},postMixInProperties:function(){
},buildRendering:function(){
if(!this.domNode){
this.domNode=this.srcNodeRef||dojo.create("div");
}
if(this.baseClass){
var _57=this.baseClass.split(" ");
if(!this.isLeftToRight()){
_57=_57.concat(dojo.map(_57,function(_58){
return _58+"Rtl";
}));
}
dojo.addClass(this.domNode,_57);
}
},postCreate:function(){
},startup:function(){
this._started=true;
},destroyRecursive:function(_59){
this._beingDestroyed=true;
this.destroyDescendants(_59);
this.destroy(_59);
},destroy:function(_5a){
this._beingDestroyed=true;
this.uninitialize();
var d=dojo,dfe=d.forEach,dun=d.unsubscribe;
dfe(this._connects,function(_5b){
dfe(_5b,d.disconnect);
});
dfe(this._subscribes,function(_5c){
dun(_5c);
});
dfe(this._supportingWidgets||[],function(w){
if(w.destroyRecursive){
w.destroyRecursive();
}else{
if(w.destroy){
w.destroy();
}
}
});
this.destroyRendering(_5a);
dijit.registry.remove(this.id);
this._destroyed=true;
},destroyRendering:function(_5d){
if(this.bgIframe){
this.bgIframe.destroy(_5d);
delete this.bgIframe;
}
if(this.domNode){
if(_5d){
dojo.removeAttr(this.domNode,"widgetId");
}else{
dojo.destroy(this.domNode);
}
delete this.domNode;
}
if(this.srcNodeRef){
if(!_5d){
dojo.destroy(this.srcNodeRef);
}
delete this.srcNodeRef;
}
},destroyDescendants:function(_5e){
dojo.forEach(this.getChildren(),function(_5f){
if(_5f.destroyRecursive){
_5f.destroyRecursive(_5e);
}
});
},uninitialize:function(){
return false;
},_setClassAttr:function(_60){
var _61=this[this.attributeMap["class"]||"domNode"];
dojo.replaceClass(_61,_60,this["class"]);
this._set("class",_60);
},_setStyleAttr:function(_62){
var _63=this[this.attributeMap.style||"domNode"];
if(dojo.isObject(_62)){
dojo.style(_63,_62);
}else{
if(_63.style.cssText){
_63.style.cssText+="; "+_62;
}else{
_63.style.cssText=_62;
}
}
this._set("style",_62);
},_attrToDom:function(_64,_65){
var _66=this.attributeMap[_64];
dojo.forEach(dojo.isArray(_66)?_66:[_66],function(_67){
var _68=this[_67.node||_67||"domNode"];
var _69=_67.type||"attribute";
switch(_69){
case "attribute":
if(dojo.isFunction(_65)){
_65=dojo.hitch(this,_65);
}
var _6a=_67.attribute?_67.attribute:(/^on[A-Z][a-zA-Z]*$/.test(_64)?_64.toLowerCase():_64);
dojo.attr(_68,_6a,_65);
break;
case "innerText":
_68.innerHTML="";
_68.appendChild(dojo.doc.createTextNode(_65));
break;
case "innerHTML":
_68.innerHTML=_65;
break;
case "class":
dojo.replaceClass(_68,_65,this[_64]);
break;
}
},this);
},get:function(_6b){
var _6c=this._getAttrNames(_6b);
return this[_6c.g]?this[_6c.g]():this[_6b];
},set:function(_6d,_6e){
if(typeof _6d==="object"){
for(var x in _6d){
this.set(x,_6d[x]);
}
return this;
}
var _6f=this._getAttrNames(_6d);
if(this[_6f.s]){
var _70=this[_6f.s].apply(this,Array.prototype.slice.call(arguments,1));
}else{
if(_6d in this.attributeMap){
this._attrToDom(_6d,_6e);
}
this._set(_6d,_6e);
}
return _70||this;
},_attrPairNames:{},_getAttrNames:function(_71){
var apn=this._attrPairNames;
if(apn[_71]){
return apn[_71];
}
var uc=_71.charAt(0).toUpperCase()+_71.substr(1);
return (apn[_71]={n:_71+"Node",s:"_set"+uc+"Attr",g:"_get"+uc+"Attr"});
},_set:function(_72,_73){
var _74=this[_72];
this[_72]=_73;
if(this._watchCallbacks&&this._created&&_73!==_74){
this._watchCallbacks(_72,_74,_73);
}
},toString:function(){
return "[Widget "+this.declaredClass+", "+(this.id||"NO ID")+"]";
},getDescendants:function(){
return this.containerNode?dojo.query("[widgetId]",this.containerNode).map(dijit.byNode):[];
},getChildren:function(){
return this.containerNode?dijit.findWidgets(this.containerNode):[];
},connect:function(obj,_75,_76){
var _77=[dojo._connect(obj,_75,this,_76)];
this._connects.push(_77);
return _77;
},disconnect:function(_78){
for(var i=0;i<this._connects.length;i++){
if(this._connects[i]==_78){
dojo.forEach(_78,dojo.disconnect);
this._connects.splice(i,1);
return;
}
}
},subscribe:function(_79,_7a){
var _7b=dojo.subscribe(_79,this,_7a);
this._subscribes.push(_7b);
return _7b;
},unsubscribe:function(_7c){
for(var i=0;i<this._subscribes.length;i++){
if(this._subscribes[i]==_7c){
dojo.unsubscribe(_7c);
this._subscribes.splice(i,1);
return;
}
}
},isLeftToRight:function(){
return this.dir?(this.dir=="ltr"):dojo._isBodyLtr();
},placeAt:function(_7d,_7e){
if(_7d.declaredClass&&_7d.addChild){
_7d.addChild(this,_7e);
}else{
dojo.place(this.domNode,_7d,_7e);
}
return this;
}});
})();
}
if(!dojo._hasResource["dojo.window"]){
dojo._hasResource["dojo.window"]=true;
dojo.provide("dojo.window");
dojo.getObject("window",true,dojo);
dojo.window.getBox=function(){
var _7f=(dojo.doc.compatMode=="BackCompat")?dojo.body():dojo.doc.documentElement;
var _80=dojo._docScroll();
return {w:_7f.clientWidth,h:_7f.clientHeight,l:_80.x,t:_80.y};
};
dojo.window.get=function(doc){
if(dojo.isIE&&window!==document.parentWindow){
doc.parentWindow.execScript("document._parentWindow = window;","Javascript");
var win=doc._parentWindow;
doc._parentWindow=null;
return win;
}
return doc.parentWindow||doc.defaultView;
};
dojo.window.scrollIntoView=function(_81,pos){
try{
_81=dojo.byId(_81);
var doc=_81.ownerDocument||dojo.doc,_82=doc.body||dojo.body(),_83=doc.documentElement||_82.parentNode,_84=dojo.isIE,_85=dojo.isWebKit;
if((!(dojo.isMoz||_84||_85||dojo.isOpera)||_81==_82||_81==_83)&&(typeof _81.scrollIntoView!="undefined")){
_81.scrollIntoView(false);
return;
}
var _86=doc.compatMode=="BackCompat",_87=(_84>=9&&_81.ownerDocument.parentWindow.frameElement)?((_83.clientHeight>0&&_83.clientWidth>0&&(_82.clientHeight==0||_82.clientWidth==0||_82.clientHeight>_83.clientHeight||_82.clientWidth>_83.clientWidth))?_83:_82):(_86?_82:_83),_88=_85?_82:_87,_89=_87.clientWidth,_8a=_87.clientHeight,rtl=!dojo._isBodyLtr(),_8b=pos||dojo.position(_81),el=_81.parentNode,_8c=function(el){
return ((_84<=6||(_84&&_86))?false:(dojo.style(el,"position").toLowerCase()=="fixed"));
};
if(_8c(_81)){
return;
}
while(el){
if(el==_82){
el=_88;
}
var _8d=dojo.position(el),_8e=_8c(el);
if(el==_88){
_8d.w=_89;
_8d.h=_8a;
if(_88==_83&&_84&&rtl){
_8d.x+=_88.offsetWidth-_8d.w;
}
if(_8d.x<0||!_84){
_8d.x=0;
}
if(_8d.y<0||!_84){
_8d.y=0;
}
}else{
var pb=dojo._getPadBorderExtents(el);
_8d.w-=pb.w;
_8d.h-=pb.h;
_8d.x+=pb.l;
_8d.y+=pb.t;
var _8f=el.clientWidth,_90=_8d.w-_8f;
if(_8f>0&&_90>0){
_8d.w=_8f;
_8d.x+=(rtl&&(_84||el.clientLeft>pb.l))?_90:0;
}
_8f=el.clientHeight;
_90=_8d.h-_8f;
if(_8f>0&&_90>0){
_8d.h=_8f;
}
}
if(_8e){
if(_8d.y<0){
_8d.h+=_8d.y;
_8d.y=0;
}
if(_8d.x<0){
_8d.w+=_8d.x;
_8d.x=0;
}
if(_8d.y+_8d.h>_8a){
_8d.h=_8a-_8d.y;
}
if(_8d.x+_8d.w>_89){
_8d.w=_89-_8d.x;
}
}
var l=_8b.x-_8d.x,t=_8b.y-Math.max(_8d.y,0),r=l+_8b.w-_8d.w,bot=t+_8b.h-_8d.h;
if(r*l>0){
var s=Math[l<0?"max":"min"](l,r);
if(rtl&&((_84==8&&!_86)||_84>=9)){
s=-s;
}
_8b.x+=el.scrollLeft;
el.scrollLeft+=s;
_8b.x-=el.scrollLeft;
}
if(bot*t>0){
_8b.y+=el.scrollTop;
el.scrollTop+=Math[t<0?"max":"min"](t,bot);
_8b.y-=el.scrollTop;
}
el=(el!=_88)&&!_8e&&el.parentNode;
}
}
catch(error){
console.error("scrollIntoView: "+error);
_81.scrollIntoView(false);
}
};
}
if(!dojo._hasResource["dijit._base.focus"]){
dojo._hasResource["dijit._base.focus"]=true;
dojo.provide("dijit._base.focus");
dojo.mixin(dijit,{_curFocus:null,_prevFocus:null,isCollapsed:function(){
return dijit.getBookmark().isCollapsed;
},getBookmark:function(){
var bm,rg,tg,sel=dojo.doc.selection,cf=dijit._curFocus;
if(dojo.global.getSelection){
sel=dojo.global.getSelection();
if(sel){
if(sel.isCollapsed){
tg=cf?cf.tagName:"";
if(tg){
tg=tg.toLowerCase();
if(tg=="textarea"||(tg=="input"&&(!cf.type||cf.type.toLowerCase()=="text"))){
sel={start:cf.selectionStart,end:cf.selectionEnd,node:cf,pRange:true};
return {isCollapsed:(sel.end<=sel.start),mark:sel};
}
}
bm={isCollapsed:true};
if(sel.rangeCount){
bm.mark=sel.getRangeAt(0).cloneRange();
}
}else{
rg=sel.getRangeAt(0);
bm={isCollapsed:false,mark:rg.cloneRange()};
}
}
}else{
if(sel){
tg=cf?cf.tagName:"";
tg=tg.toLowerCase();
if(cf&&tg&&(tg=="button"||tg=="textarea"||tg=="input")){
if(sel.type&&sel.type.toLowerCase()=="none"){
return {isCollapsed:true,mark:null};
}else{
rg=sel.createRange();
return {isCollapsed:rg.text&&rg.text.length?false:true,mark:{range:rg,pRange:true}};
}
}
bm={};
try{
rg=sel.createRange();
bm.isCollapsed=!(sel.type=="Text"?rg.htmlText.length:rg.length);
}
catch(e){
bm.isCollapsed=true;
return bm;
}
if(sel.type.toUpperCase()=="CONTROL"){
if(rg.length){
bm.mark=[];
var i=0,len=rg.length;
while(i<len){
bm.mark.push(rg.item(i++));
}
}else{
bm.isCollapsed=true;
bm.mark=null;
}
}else{
bm.mark=rg.getBookmark();
}
}else{
console.warn("No idea how to store the current selection for this browser!");
}
}
return bm;
},moveToBookmark:function(_91){
var _92=dojo.doc,_93=_91.mark;
if(_93){
if(dojo.global.getSelection){
var sel=dojo.global.getSelection();
if(sel&&sel.removeAllRanges){
if(_93.pRange){
var r=_93;
var n=r.node;
n.selectionStart=r.start;
n.selectionEnd=r.end;
}else{
sel.removeAllRanges();
sel.addRange(_93);
}
}else{
console.warn("No idea how to restore selection for this browser!");
}
}else{
if(_92.selection&&_93){
var rg;
if(_93.pRange){
rg=_93.range;
}else{
if(dojo.isArray(_93)){
rg=_92.body.createControlRange();
dojo.forEach(_93,function(n){
rg.addElement(n);
});
}else{
rg=_92.body.createTextRange();
rg.moveToBookmark(_93);
}
}
rg.select();
}
}
}
},getFocus:function(_94,_95){
var _96=!dijit._curFocus||(_94&&dojo.isDescendant(dijit._curFocus,_94.domNode))?dijit._prevFocus:dijit._curFocus;
return {node:_96,bookmark:(_96==dijit._curFocus)&&dojo.withGlobal(_95||dojo.global,dijit.getBookmark),openedForWindow:_95};
},focus:function(_97){
if(!_97){
return;
}
var _98="node" in _97?_97.node:_97,_99=_97.bookmark,_9a=_97.openedForWindow,_9b=_99?_99.isCollapsed:false;
if(_98){
var _9c=(_98.tagName.toLowerCase()=="iframe")?_98.contentWindow:_98;
if(_9c&&_9c.focus){
try{
_9c.focus();
}
catch(e){
}
}
dijit._onFocusNode(_98);
}
if(_99&&dojo.withGlobal(_9a||dojo.global,dijit.isCollapsed)&&!_9b){
if(_9a){
_9a.focus();
}
try{
dojo.withGlobal(_9a||dojo.global,dijit.moveToBookmark,null,[_99]);
}
catch(e2){
}
}
},_activeStack:[],registerIframe:function(_9d){
return dijit.registerWin(_9d.contentWindow,_9d);
},unregisterIframe:function(_9e){
dijit.unregisterWin(_9e);
},registerWin:function(_9f,_a0){
var _a1=function(evt){
dijit._justMouseDowned=true;
setTimeout(function(){
dijit._justMouseDowned=false;
},0);
if(dojo.isIE&&evt&&evt.srcElement&&evt.srcElement.parentNode==null){
return;
}
dijit._onTouchNode(_a0||evt.target||evt.srcElement,"mouse");
};
var doc=dojo.isIE?_9f.document.documentElement:_9f.document;
if(doc){
if(dojo.isIE){
_9f.document.body.attachEvent("onmousedown",_a1);
var _a2=function(evt){
if(evt.srcElement.tagName.toLowerCase()!="#document"&&dijit.isTabNavigable(evt.srcElement)){
dijit._onFocusNode(_a0||evt.srcElement);
}else{
dijit._onTouchNode(_a0||evt.srcElement);
}
};
doc.attachEvent("onactivate",_a2);
var _a3=function(evt){
dijit._onBlurNode(_a0||evt.srcElement);
};
doc.attachEvent("ondeactivate",_a3);
return function(){
_9f.document.detachEvent("onmousedown",_a1);
doc.detachEvent("onactivate",_a2);
doc.detachEvent("ondeactivate",_a3);
doc=null;
};
}else{
doc.body.addEventListener("mousedown",_a1,true);
var _a4=function(evt){
dijit._onFocusNode(_a0||evt.target);
};
doc.addEventListener("focus",_a4,true);
var _a5=function(evt){
dijit._onBlurNode(_a0||evt.target);
};
doc.addEventListener("blur",_a5,true);
return function(){
doc.body.removeEventListener("mousedown",_a1,true);
doc.removeEventListener("focus",_a4,true);
doc.removeEventListener("blur",_a5,true);
doc=null;
};
}
}
},unregisterWin:function(_a6){
_a6&&_a6();
},_onBlurNode:function(_a7){
dijit._prevFocus=dijit._curFocus;
dijit._curFocus=null;
if(dijit._justMouseDowned){
return;
}
if(dijit._clearActiveWidgetsTimer){
clearTimeout(dijit._clearActiveWidgetsTimer);
}
dijit._clearActiveWidgetsTimer=setTimeout(function(){
delete dijit._clearActiveWidgetsTimer;
dijit._setStack([]);
dijit._prevFocus=null;
},100);
},_onTouchNode:function(_a8,by){
if(dijit._clearActiveWidgetsTimer){
clearTimeout(dijit._clearActiveWidgetsTimer);
delete dijit._clearActiveWidgetsTimer;
}
var _a9=[];
try{
while(_a8){
var _aa=dojo.attr(_a8,"dijitPopupParent");
if(_aa){
_a8=dijit.byId(_aa).domNode;
}else{
if(_a8.tagName&&_a8.tagName.toLowerCase()=="body"){
if(_a8===dojo.body()){
break;
}
_a8=dojo.window.get(_a8.ownerDocument).frameElement;
}else{
var id=_a8.getAttribute&&_a8.getAttribute("widgetId"),_ab=id&&dijit.byId(id);
if(_ab&&!(by=="mouse"&&_ab.get("disabled"))){
_a9.unshift(id);
}
_a8=_a8.parentNode;
}
}
}
}
catch(e){
}
dijit._setStack(_a9,by);
},_onFocusNode:function(_ac){
if(!_ac){
return;
}
if(_ac.nodeType==9){
return;
}
dijit._onTouchNode(_ac);
if(_ac==dijit._curFocus){
return;
}
if(dijit._curFocus){
dijit._prevFocus=dijit._curFocus;
}
dijit._curFocus=_ac;
dojo.publish("focusNode",[_ac]);
},_setStack:function(_ad,by){
var _ae=dijit._activeStack;
dijit._activeStack=_ad;
for(var _af=0;_af<Math.min(_ae.length,_ad.length);_af++){
if(_ae[_af]!=_ad[_af]){
break;
}
}
var _b0;
for(var i=_ae.length-1;i>=_af;i--){
_b0=dijit.byId(_ae[i]);
if(_b0){
_b0._focused=false;
_b0.set("focused",false);
_b0._hasBeenBlurred=true;
if(_b0._onBlur){
_b0._onBlur(by);
}
dojo.publish("widgetBlur",[_b0,by]);
}
}
for(i=_af;i<_ad.length;i++){
_b0=dijit.byId(_ad[i]);
if(_b0){
_b0._focused=true;
_b0.set("focused",true);
if(_b0._onFocus){
_b0._onFocus(by);
}
dojo.publish("widgetFocus",[_b0,by]);
}
}
}});
dojo.addOnLoad(function(){
var _b1=dijit.registerWin(window);
if(dojo.isIE){
dojo.addOnWindowUnload(function(){
dijit.unregisterWin(_b1);
_b1=null;
});
}
});
}
if(!dojo._hasResource["dojo.AdapterRegistry"]){
dojo._hasResource["dojo.AdapterRegistry"]=true;
dojo.provide("dojo.AdapterRegistry");
dojo.AdapterRegistry=function(_b2){
this.pairs=[];
this.returnWrappers=_b2||false;
};
dojo.extend(dojo.AdapterRegistry,{register:function(_b3,_b4,_b5,_b6,_b7){
this.pairs[((_b7)?"unshift":"push")]([_b3,_b4,_b5,_b6]);
},match:function(){
for(var i=0;i<this.pairs.length;i++){
var _b8=this.pairs[i];
if(_b8[1].apply(this,arguments)){
if((_b8[3])||(this.returnWrappers)){
return _b8[2];
}else{
return _b8[2].apply(this,arguments);
}
}
}
throw new Error("No match found");
},unregister:function(_b9){
for(var i=0;i<this.pairs.length;i++){
var _ba=this.pairs[i];
if(_ba[0]==_b9){
this.pairs.splice(i,1);
return true;
}
}
return false;
}});
}
if(!dojo._hasResource["dijit._base.place"]){
dojo._hasResource["dijit._base.place"]=true;
dojo.provide("dijit._base.place");
dijit.getViewport=function(){
return dojo.window.getBox();
};
dijit.placeOnScreen=function(_bb,pos,_bc,_bd){
var _be=dojo.map(_bc,function(_bf){
var c={corner:_bf,pos:{x:pos.x,y:pos.y}};
if(_bd){
c.pos.x+=_bf.charAt(1)=="L"?_bd.x:-_bd.x;
c.pos.y+=_bf.charAt(0)=="T"?_bd.y:-_bd.y;
}
return c;
});
return dijit._place(_bb,_be);
};
dijit._place=function(_c0,_c1,_c2,_c3){
var _c4=dojo.window.getBox();
if(!_c0.parentNode||String(_c0.parentNode.tagName).toLowerCase()!="body"){
dojo.body().appendChild(_c0);
}
var _c5=null;
dojo.some(_c1,function(_c6){
var _c7=_c6.corner;
var pos=_c6.pos;
var _c8=0;
var _c9={w:_c7.charAt(1)=="L"?(_c4.l+_c4.w)-pos.x:pos.x-_c4.l,h:_c7.charAt(1)=="T"?(_c4.t+_c4.h)-pos.y:pos.y-_c4.t};
if(_c2){
var res=_c2(_c0,_c6.aroundCorner,_c7,_c9,_c3);
_c8=typeof res=="undefined"?0:res;
}
var _ca=_c0.style;
var _cb=_ca.display;
var _cc=_ca.visibility;
_ca.visibility="hidden";
_ca.display="";
var mb=dojo.marginBox(_c0);
_ca.display=_cb;
_ca.visibility=_cc;
var _cd=Math.max(_c4.l,_c7.charAt(1)=="L"?pos.x:(pos.x-mb.w)),_ce=Math.max(_c4.t,_c7.charAt(0)=="T"?pos.y:(pos.y-mb.h)),_cf=Math.min(_c4.l+_c4.w,_c7.charAt(1)=="L"?(_cd+mb.w):pos.x),_d0=Math.min(_c4.t+_c4.h,_c7.charAt(0)=="T"?(_ce+mb.h):pos.y),_d1=_cf-_cd,_d2=_d0-_ce;
_c8+=(mb.w-_d1)+(mb.h-_d2);
if(_c5==null||_c8<_c5.overflow){
_c5={corner:_c7,aroundCorner:_c6.aroundCorner,x:_cd,y:_ce,w:_d1,h:_d2,overflow:_c8,spaceAvailable:_c9};
}
return !_c8;
});
if(_c5.overflow&&_c2){
_c2(_c0,_c5.aroundCorner,_c5.corner,_c5.spaceAvailable,_c3);
}
var l=dojo._isBodyLtr(),s=_c0.style;
s.top=_c5.y+"px";
s[l?"left":"right"]=(l?_c5.x:_c4.w-_c5.x-_c5.w)+"px";
return _c5;
};
dijit.placeOnScreenAroundNode=function(_d3,_d4,_d5,_d6){
_d4=dojo.byId(_d4);
var _d7=dojo.position(_d4,true);
return dijit._placeOnScreenAroundRect(_d3,_d7.x,_d7.y,_d7.w,_d7.h,_d5,_d6);
};
dijit.placeOnScreenAroundRectangle=function(_d8,_d9,_da,_db){
return dijit._placeOnScreenAroundRect(_d8,_d9.x,_d9.y,_d9.width,_d9.height,_da,_db);
};
dijit._placeOnScreenAroundRect=function(_dc,x,y,_dd,_de,_df,_e0){
var _e1=[];
for(var _e2 in _df){
_e1.push({aroundCorner:_e2,corner:_df[_e2],pos:{x:x+(_e2.charAt(1)=="L"?0:_dd),y:y+(_e2.charAt(0)=="T"?0:_de)}});
}
return dijit._place(_dc,_e1,_e0,{w:_dd,h:_de});
};
dijit.placementRegistry=new dojo.AdapterRegistry();
dijit.placementRegistry.register("node",function(n,x){
return typeof x=="object"&&typeof x.offsetWidth!="undefined"&&typeof x.offsetHeight!="undefined";
},dijit.placeOnScreenAroundNode);
dijit.placementRegistry.register("rect",function(n,x){
return typeof x=="object"&&"x" in x&&"y" in x&&"width" in x&&"height" in x;
},dijit.placeOnScreenAroundRectangle);
dijit.placeOnScreenAroundElement=function(_e3,_e4,_e5,_e6){
return dijit.placementRegistry.match.apply(dijit.placementRegistry,arguments);
};
dijit.getPopupAroundAlignment=function(_e7,_e8){
var _e9={};
dojo.forEach(_e7,function(pos){
switch(pos){
case "after":
_e9[_e8?"BR":"BL"]=_e8?"BL":"BR";
break;
case "before":
_e9[_e8?"BL":"BR"]=_e8?"BR":"BL";
break;
case "below-alt":
_e8=!_e8;
case "below":
_e9[_e8?"BL":"BR"]=_e8?"TL":"TR";
_e9[_e8?"BR":"BL"]=_e8?"TR":"TL";
break;
case "above-alt":
_e8=!_e8;
case "above":
default:
_e9[_e8?"TL":"TR"]=_e8?"BL":"BR";
_e9[_e8?"TR":"TL"]=_e8?"BR":"BL";
break;
}
});
return _e9;
};
}
if(!dojo._hasResource["dijit._base.window"]){
dojo._hasResource["dijit._base.window"]=true;
dojo.provide("dijit._base.window");
dijit.getDocumentWindow=function(doc){
return dojo.window.get(doc);
};
}
if(!dojo._hasResource["dijit._base.popup"]){
dojo._hasResource["dijit._base.popup"]=true;
dojo.provide("dijit._base.popup");
dijit.popup={_stack:[],_beginZIndex:1000,_idGen:1,_createWrapper:function(_ea){
var _eb=_ea.domNode||_ea,_ec=_ea.declaredClass?_ea._popupWrapper:_eb.parentNode&&dojo.hasClass(_eb.parentNode,"dijitPopup")?_eb.parentNode:null;
if(!_ec){
_ec=dojo.create("div",{"class":"dijitPopup",style:{display:"none"},role:"presentation"},dojo.body());
_ec.appendChild(_eb);
var s=_eb.style;
s.display="";
s.visibility="";
s.position="";
s.top="0px";
if(_ea.declaredClass){
_ea._popupWrapper=_ec;
dojo.connect(_ea,"destroy",function(){
dojo.destroy(_ec);
delete _ea._popupWrapper;
});
}
}
return _ec;
},moveOffScreen:function(_ed){
var _ee=this._createWrapper(_ed);
dojo.style(_ee,{visibility:"hidden",top:"-9999px",display:""});
},hide:function(_ef){
var _f0=this._createWrapper(_ef);
dojo.style(_f0,"display","none");
},getTopPopup:function(){
var _f1=this._stack;
for(var pi=_f1.length-1;pi>0&&_f1[pi].parent===_f1[pi-1].widget;pi--){
}
return _f1[pi];
},open:function(_f2){
var _f3=this._stack,_f4=_f2.popup,_f5=_f2.orient||((_f2.parent?_f2.parent.isLeftToRight():dojo._isBodyLtr())?{"BL":"TL","BR":"TR","TL":"BL","TR":"BR"}:{"BR":"TR","BL":"TL","TR":"BR","TL":"BL"}),_f6=_f2.around,id=(_f2.around&&_f2.around.id)?(_f2.around.id+"_dropdown"):("popup_"+this._idGen++);
while(_f3.length&&(!_f2.parent||!dojo.isDescendant(_f2.parent.domNode,_f3[_f3.length-1].widget.domNode))){
dijit.popup.close(_f3[_f3.length-1].widget);
}
var _f7=this._createWrapper(_f4);
dojo.attr(_f7,{id:id,style:{zIndex:this._beginZIndex+_f3.length},"class":"dijitPopup "+(_f4.baseClass||_f4["class"]||"").split(" ")[0]+"Popup",dijitPopupParent:_f2.parent?_f2.parent.id:""});
if(dojo.isIE||dojo.isMoz){
if(!_f4.bgIframe){
_f4.bgIframe=new dijit.BackgroundIframe(_f7);
}
}
var _f8=_f6?dijit.placeOnScreenAroundElement(_f7,_f6,_f5,_f4.orient?dojo.hitch(_f4,"orient"):null):dijit.placeOnScreen(_f7,_f2,_f5=="R"?["TR","BR","TL","BL"]:["TL","BL","TR","BR"],_f2.padding);
_f7.style.display="";
_f7.style.visibility="visible";
_f4.domNode.style.visibility="visible";
var _f9=[];
_f9.push(dojo.connect(_f7,"onkeypress",this,function(evt){
if(evt.charOrCode==dojo.keys.ESCAPE&&_f2.onCancel){
dojo.stopEvent(evt);
_f2.onCancel();
}else{
if(evt.charOrCode===dojo.keys.TAB){
dojo.stopEvent(evt);
var _fa=this.getTopPopup();
if(_fa&&_fa.onCancel){
_fa.onCancel();
}
}
}
}));
if(_f4.onCancel){
_f9.push(dojo.connect(_f4,"onCancel",_f2.onCancel));
}
_f9.push(dojo.connect(_f4,_f4.onExecute?"onExecute":"onChange",this,function(){
var _fb=this.getTopPopup();
if(_fb&&_fb.onExecute){
_fb.onExecute();
}
}));
_f3.push({widget:_f4,parent:_f2.parent,onExecute:_f2.onExecute,onCancel:_f2.onCancel,onClose:_f2.onClose,handlers:_f9});
if(_f4.onOpen){
_f4.onOpen(_f8);
}
return _f8;
},close:function(_fc){
var _fd=this._stack;
while((_fc&&dojo.some(_fd,function(_fe){
return _fe.widget==_fc;
}))||(!_fc&&_fd.length)){
var top=_fd.pop(),_ff=top.widget,_100=top.onClose;
if(_ff.onClose){
_ff.onClose();
}
dojo.forEach(top.handlers,dojo.disconnect);
if(_ff&&_ff.domNode){
this.hide(_ff);
}
if(_100){
_100();
}
}
}};
dijit._frames=new function(){
var _101=[];
this.pop=function(){
var _102;
if(_101.length){
_102=_101.pop();
_102.style.display="";
}else{
if(dojo.isIE<9){
var burl=dojo.config["dojoBlankHtmlUrl"]||(dojo.moduleUrl("dojo","resources/blank.html")+"")||"javascript:\"\"";
var html="<iframe src='"+burl+"'"+" style='position: absolute; left: 0px; top: 0px;"+"z-index: -1; filter:Alpha(Opacity=\"0\");'>";
_102=dojo.doc.createElement(html);
}else{
_102=dojo.create("iframe");
_102.src="javascript:\"\"";
_102.className="dijitBackgroundIframe";
dojo.style(_102,"opacity",0.1);
}
_102.tabIndex=-1;
dijit.setWaiRole(_102,"presentation");
}
return _102;
};
this.push=function(_103){
_103.style.display="none";
_101.push(_103);
};
}();
dijit.BackgroundIframe=function(node){
if(!node.id){
throw new Error("no id");
}
if(dojo.isIE||dojo.isMoz){
var _104=(this.iframe=dijit._frames.pop());
node.appendChild(_104);
if(dojo.isIE<7||dojo.isQuirks){
this.resize(node);
this._conn=dojo.connect(node,"onresize",this,function(){
this.resize(node);
});
}else{
dojo.style(_104,{width:"100%",height:"100%"});
}
}
};
dojo.extend(dijit.BackgroundIframe,{resize:function(node){
if(this.iframe){
dojo.style(this.iframe,{width:node.offsetWidth+"px",height:node.offsetHeight+"px"});
}
},destroy:function(){
if(this._conn){
dojo.disconnect(this._conn);
this._conn=null;
}
if(this.iframe){
dijit._frames.push(this.iframe);
delete this.iframe;
}
}});
}
if(!dojo._hasResource["dijit._base.scroll"]){
dojo._hasResource["dijit._base.scroll"]=true;
dojo.provide("dijit._base.scroll");
dijit.scrollIntoView=function(node,pos){
dojo.window.scrollIntoView(node,pos);
};
}
if(!dojo._hasResource["dojo.uacss"]){
dojo._hasResource["dojo.uacss"]=true;
dojo.provide("dojo.uacss");
(function(){
var d=dojo,html=d.doc.documentElement,ie=d.isIE,_105=d.isOpera,maj=Math.floor,ff=d.isFF,_106=d.boxModel.replace(/-/,""),_107={dj_ie:ie,dj_ie6:maj(ie)==6,dj_ie7:maj(ie)==7,dj_ie8:maj(ie)==8,dj_ie9:maj(ie)==9,dj_quirks:d.isQuirks,dj_iequirks:ie&&d.isQuirks,dj_opera:_105,dj_khtml:d.isKhtml,dj_webkit:d.isWebKit,dj_safari:d.isSafari,dj_chrome:d.isChrome,dj_gecko:d.isMozilla,dj_ff3:maj(ff)==3};
_107["dj_"+_106]=true;
var _108="";
for(var clz in _107){
if(_107[clz]){
_108+=clz+" ";
}
}
html.className=d.trim(html.className+" "+_108);
dojo._loaders.unshift(function(){
if(!dojo._isBodyLtr()){
var _109="dj_rtl dijitRtl "+_108.replace(/ /g,"-rtl ");
html.className=d.trim(html.className+" "+_109);
}
});
})();
}
if(!dojo._hasResource["dijit._base.sniff"]){
dojo._hasResource["dijit._base.sniff"]=true;
dojo.provide("dijit._base.sniff");
}
if(!dojo._hasResource["dijit._base.typematic"]){
dojo._hasResource["dijit._base.typematic"]=true;
dojo.provide("dijit._base.typematic");
dijit.typematic={_fireEventAndReload:function(){
this._timer=null;
this._callback(++this._count,this._node,this._evt);
this._currentTimeout=Math.max(this._currentTimeout<0?this._initialDelay:(this._subsequentDelay>1?this._subsequentDelay:Math.round(this._currentTimeout*this._subsequentDelay)),this._minDelay);
this._timer=setTimeout(dojo.hitch(this,"_fireEventAndReload"),this._currentTimeout);
},trigger:function(evt,_10a,node,_10b,obj,_10c,_10d,_10e){
if(obj!=this._obj){
this.stop();
this._initialDelay=_10d||500;
this._subsequentDelay=_10c||0.9;
this._minDelay=_10e||10;
this._obj=obj;
this._evt=evt;
this._node=node;
this._currentTimeout=-1;
this._count=-1;
this._callback=dojo.hitch(_10a,_10b);
this._fireEventAndReload();
this._evt=dojo.mixin({faux:true},evt);
}
},stop:function(){
if(this._timer){
clearTimeout(this._timer);
this._timer=null;
}
if(this._obj){
this._callback(-1,this._node,this._evt);
this._obj=null;
}
},addKeyListener:function(node,_10f,_110,_111,_112,_113,_114){
if(_10f.keyCode){
_10f.charOrCode=_10f.keyCode;
dojo.deprecated("keyCode attribute parameter for dijit.typematic.addKeyListener is deprecated. Use charOrCode instead.","","2.0");
}else{
if(_10f.charCode){
_10f.charOrCode=String.fromCharCode(_10f.charCode);
dojo.deprecated("charCode attribute parameter for dijit.typematic.addKeyListener is deprecated. Use charOrCode instead.","","2.0");
}
}
return [dojo.connect(node,"onkeypress",this,function(evt){
if(evt.charOrCode==_10f.charOrCode&&(_10f.ctrlKey===undefined||_10f.ctrlKey==evt.ctrlKey)&&(_10f.altKey===undefined||_10f.altKey==evt.altKey)&&(_10f.metaKey===undefined||_10f.metaKey==(evt.metaKey||false))&&(_10f.shiftKey===undefined||_10f.shiftKey==evt.shiftKey)){
dojo.stopEvent(evt);
dijit.typematic.trigger(evt,_110,node,_111,_10f,_112,_113,_114);
}else{
if(dijit.typematic._obj==_10f){
dijit.typematic.stop();
}
}
}),dojo.connect(node,"onkeyup",this,function(evt){
if(dijit.typematic._obj==_10f){
dijit.typematic.stop();
}
})];
},addMouseListener:function(node,_115,_116,_117,_118,_119){
var dc=dojo.connect;
return [dc(node,"mousedown",this,function(evt){
dojo.stopEvent(evt);
dijit.typematic.trigger(evt,_115,node,_116,node,_117,_118,_119);
}),dc(node,"mouseup",this,function(evt){
dojo.stopEvent(evt);
dijit.typematic.stop();
}),dc(node,"mouseout",this,function(evt){
dojo.stopEvent(evt);
dijit.typematic.stop();
}),dc(node,"mousemove",this,function(evt){
evt.preventDefault();
}),dc(node,"dblclick",this,function(evt){
dojo.stopEvent(evt);
if(dojo.isIE){
dijit.typematic.trigger(evt,_115,node,_116,node,_117,_118,_119);
setTimeout(dojo.hitch(this,dijit.typematic.stop),50);
}
})];
},addListener:function(_11a,_11b,_11c,_11d,_11e,_11f,_120,_121){
return this.addKeyListener(_11b,_11c,_11d,_11e,_11f,_120,_121).concat(this.addMouseListener(_11a,_11d,_11e,_11f,_120,_121));
}};
}
if(!dojo._hasResource["dijit._base.wai"]){
dojo._hasResource["dijit._base.wai"]=true;
dojo.provide("dijit._base.wai");
dijit.wai={onload:function(){
var div=dojo.create("div",{id:"a11yTestNode",style:{cssText:"border: 1px solid;"+"border-color:red green;"+"position: absolute;"+"height: 5px;"+"top: -999px;"+"background-image: url(\""+(dojo.config.blankGif||dojo.moduleUrl("dojo","resources/blank.gif"))+"\");"}},dojo.body());
var cs=dojo.getComputedStyle(div);
if(cs){
var _122=cs.backgroundImage;
var _123=(cs.borderTopColor==cs.borderRightColor)||(_122!=null&&(_122=="none"||_122=="url(invalid-url:)"));
dojo[_123?"addClass":"removeClass"](dojo.body(),"dijit_a11y");
if(dojo.isIE){
div.outerHTML="";
}else{
dojo.body().removeChild(div);
}
}
}};
if(dojo.isIE||dojo.isMoz){
dojo._loaders.unshift(dijit.wai.onload);
}
dojo.mixin(dijit,{hasWaiRole:function(elem,role){
var _124=this.getWaiRole(elem);
return role?(_124.indexOf(role)>-1):(_124.length>0);
},getWaiRole:function(elem){
return dojo.trim((dojo.attr(elem,"role")||"").replace("wairole:",""));
},setWaiRole:function(elem,role){
dojo.attr(elem,"role",role);
},removeWaiRole:function(elem,role){
var _125=dojo.attr(elem,"role");
if(!_125){
return;
}
if(role){
var t=dojo.trim((" "+_125+" ").replace(" "+role+" "," "));
dojo.attr(elem,"role",t);
}else{
elem.removeAttribute("role");
}
},hasWaiState:function(elem,_126){
return elem.hasAttribute?elem.hasAttribute("aria-"+_126):!!elem.getAttribute("aria-"+_126);
},getWaiState:function(elem,_127){
return elem.getAttribute("aria-"+_127)||"";
},setWaiState:function(elem,_128,_129){
elem.setAttribute("aria-"+_128,_129);
},removeWaiState:function(elem,_12a){
elem.removeAttribute("aria-"+_12a);
}});
}
if(!dojo._hasResource["dijit._base"]){
dojo._hasResource["dijit._base"]=true;
dojo.provide("dijit._base");
}
if(!dojo._hasResource["dijit._Widget"]){
dojo._hasResource["dijit._Widget"]=true;
dojo.provide("dijit._Widget");
dojo.connect(dojo,"_connect",function(_12b,_12c){
if(_12b&&dojo.isFunction(_12b._onConnect)){
_12b._onConnect(_12c);
}
});
dijit._connectOnUseEventHandler=function(_12d){
};
dijit._lastKeyDownNode=null;
if(dojo.isIE){
(function(){
var _12e=function(evt){
dijit._lastKeyDownNode=evt.srcElement;
};
dojo.doc.attachEvent("onkeydown",_12e);
dojo.addOnWindowUnload(function(){
dojo.doc.detachEvent("onkeydown",_12e);
});
})();
}else{
dojo.doc.addEventListener("keydown",function(evt){
dijit._lastKeyDownNode=evt.target;
},true);
}
(function(){
dojo.declare("dijit._Widget",dijit._WidgetBase,{_deferredConnects:{onClick:"",onDblClick:"",onKeyDown:"",onKeyPress:"",onKeyUp:"",onMouseMove:"",onMouseDown:"",onMouseOut:"",onMouseOver:"",onMouseLeave:"",onMouseEnter:"",onMouseUp:""},onClick:dijit._connectOnUseEventHandler,onDblClick:dijit._connectOnUseEventHandler,onKeyDown:dijit._connectOnUseEventHandler,onKeyPress:dijit._connectOnUseEventHandler,onKeyUp:dijit._connectOnUseEventHandler,onMouseDown:dijit._connectOnUseEventHandler,onMouseMove:dijit._connectOnUseEventHandler,onMouseOut:dijit._connectOnUseEventHandler,onMouseOver:dijit._connectOnUseEventHandler,onMouseLeave:dijit._connectOnUseEventHandler,onMouseEnter:dijit._connectOnUseEventHandler,onMouseUp:dijit._connectOnUseEventHandler,create:function(_12f,_130){
this._deferredConnects=dojo.clone(this._deferredConnects);
for(var attr in this.attributeMap){
delete this._deferredConnects[attr];
}
for(attr in this._deferredConnects){
if(this[attr]!==dijit._connectOnUseEventHandler){
delete this._deferredConnects[attr];
}
}
this.inherited(arguments);
if(this.domNode){
for(attr in this.params){
this._onConnect(attr);
}
}
},_onConnect:function(_131){
if(_131 in this._deferredConnects){
var _132=this[this._deferredConnects[_131]||"domNode"];
this.connect(_132,_131.toLowerCase(),_131);
delete this._deferredConnects[_131];
}
},focused:false,isFocusable:function(){
return this.focus&&(dojo.style(this.domNode,"display")!="none");
},onFocus:function(){
},onBlur:function(){
},_onFocus:function(e){
this.onFocus();
},_onBlur:function(){
this.onBlur();
},setAttribute:function(attr,_133){
dojo.deprecated(this.declaredClass+"::setAttribute(attr, value) is deprecated. Use set() instead.","","2.0");
this.set(attr,_133);
},attr:function(name,_134){
if(dojo.config.isDebug){
var _135=arguments.callee._ach||(arguments.callee._ach={}),_136=(arguments.callee.caller||"unknown caller").toString();
if(!_135[_136]){
dojo.deprecated(this.declaredClass+"::attr() is deprecated. Use get() or set() instead, called from "+_136,"","2.0");
_135[_136]=true;
}
}
var args=arguments.length;
if(args>=2||typeof name==="object"){
return this.set.apply(this,arguments);
}else{
return this.get(name);
}
},nodesWithKeyClick:["input","button"],connect:function(obj,_137,_138){
var d=dojo,dc=d._connect,_139=this.inherited(arguments,[obj,_137=="ondijitclick"?"onclick":_137,_138]);
if(_137=="ondijitclick"){
if(d.indexOf(this.nodesWithKeyClick,obj.nodeName.toLowerCase())==-1){
var m=d.hitch(this,_138);
_139.push(dc(obj,"onkeydown",this,function(e){
if((e.keyCode==d.keys.ENTER||e.keyCode==d.keys.SPACE)&&!e.ctrlKey&&!e.shiftKey&&!e.altKey&&!e.metaKey){
dijit._lastKeyDownNode=e.target;
if(!("openDropDown" in this&&obj==this._buttonNode)){
e.preventDefault();
}
}
}),dc(obj,"onkeyup",this,function(e){
if((e.keyCode==d.keys.ENTER||e.keyCode==d.keys.SPACE)&&e.target==dijit._lastKeyDownNode&&!e.ctrlKey&&!e.shiftKey&&!e.altKey&&!e.metaKey){
dijit._lastKeyDownNode=null;
return m(e);
}
}));
}
}
return _139;
},_onShow:function(){
this.onShow();
},onShow:function(){
},onHide:function(){
},onClose:function(){
return true;
}});
})();
}
if(!dojo._hasResource["dojo.string"]){
dojo._hasResource["dojo.string"]=true;
dojo.provide("dojo.string");
dojo.getObject("string",true,dojo);
dojo.string.rep=function(str,num){
if(num<=0||!str){
return "";
}
var buf=[];
for(;;){
if(num&1){
buf.push(str);
}
if(!(num>>=1)){
break;
}
str+=str;
}
return buf.join("");
};
dojo.string.pad=function(text,size,ch,end){
if(!ch){
ch="0";
}
var out=String(text),pad=dojo.string.rep(ch,Math.ceil((size-out.length)/ch.length));
return end?out+pad:pad+out;
};
dojo.string.substitute=function(_13a,map,_13b,_13c){
_13c=_13c||dojo.global;
_13b=_13b?dojo.hitch(_13c,_13b):function(v){
return v;
};
return _13a.replace(/\$\{([^\s\:\}]+)(?:\:([^\s\:\}]+))?\}/g,function(_13d,key,_13e){
var _13f=dojo.getObject(key,false,map);
if(_13e){
_13f=dojo.getObject(_13e,false,_13c).call(_13c,_13f,key);
}
return _13b(_13f,key).toString();
});
};
dojo.string.trim=String.prototype.trim?dojo.trim:function(str){
str=str.replace(/^\s+/,"");
for(var i=str.length-1;i>=0;i--){
if(/\S/.test(str.charAt(i))){
str=str.substring(0,i+1);
break;
}
}
return str;
};
}
if(!dojo._hasResource["dojo.date.stamp"]){
dojo._hasResource["dojo.date.stamp"]=true;
dojo.provide("dojo.date.stamp");
dojo.getObject("date.stamp",true,dojo);
dojo.date.stamp.fromISOString=function(_140,_141){
if(!dojo.date.stamp._isoRegExp){
dojo.date.stamp._isoRegExp=/^(?:(\d{4})(?:-(\d{2})(?:-(\d{2}))?)?)?(?:T(\d{2}):(\d{2})(?::(\d{2})(.\d+)?)?((?:[+-](\d{2}):(\d{2}))|Z)?)?$/;
}
var _142=dojo.date.stamp._isoRegExp.exec(_140),_143=null;
if(_142){
_142.shift();
if(_142[1]){
_142[1]--;
}
if(_142[6]){
_142[6]*=1000;
}
if(_141){
_141=new Date(_141);
dojo.forEach(dojo.map(["FullYear","Month","Date","Hours","Minutes","Seconds","Milliseconds"],function(prop){
return _141["get"+prop]();
}),function(_144,_145){
_142[_145]=_142[_145]||_144;
});
}
_143=new Date(_142[0]||1970,_142[1]||0,_142[2]||1,_142[3]||0,_142[4]||0,_142[5]||0,_142[6]||0);
if(_142[0]<100){
_143.setFullYear(_142[0]||1970);
}
var _146=0,_147=_142[7]&&_142[7].charAt(0);
if(_147!="Z"){
_146=((_142[8]||0)*60)+(Number(_142[9])||0);
if(_147!="-"){
_146*=-1;
}
}
if(_147){
_146-=_143.getTimezoneOffset();
}
if(_146){
_143.setTime(_143.getTime()+_146*60000);
}
}
return _143;
};
dojo.date.stamp.toISOString=function(_148,_149){
var _14a=function(n){
return (n<10)?"0"+n:n;
};
_149=_149||{};
var _14b=[],_14c=_149.zulu?"getUTC":"get",date="";
if(_149.selector!="time"){
var year=_148[_14c+"FullYear"]();
date=["0000".substr((year+"").length)+year,_14a(_148[_14c+"Month"]()+1),_14a(_148[_14c+"Date"]())].join("-");
}
_14b.push(date);
if(_149.selector!="date"){
var time=[_14a(_148[_14c+"Hours"]()),_14a(_148[_14c+"Minutes"]()),_14a(_148[_14c+"Seconds"]())].join(":");
var _14d=_148[_14c+"Milliseconds"]();
if(_149.milliseconds){
time+="."+(_14d<100?"0":"")+_14a(_14d);
}
if(_149.zulu){
time+="Z";
}else{
if(_149.selector!="time"){
var _14e=_148.getTimezoneOffset();
var _14f=Math.abs(_14e);
time+=(_14e>0?"-":"+")+_14a(Math.floor(_14f/60))+":"+_14a(_14f%60);
}
}
_14b.push(time);
}
return _14b.join("T");
};
}
if(!dojo._hasResource["dojo.parser"]){
dojo._hasResource["dojo.parser"]=true;
dojo.provide("dojo.parser");
new Date("X");
dojo.parser=new function(){
var d=dojo;
function _150(_151){
if(d.isString(_151)){
return "string";
}
if(typeof _151=="number"){
return "number";
}
if(typeof _151=="boolean"){
return "boolean";
}
if(d.isFunction(_151)){
return "function";
}
if(d.isArray(_151)){
return "array";
}
if(_151 instanceof Date){
return "date";
}
if(_151 instanceof d._Url){
return "url";
}
return "object";
};
function _152(_153,type){
switch(type){
case "string":
return _153;
case "number":
return _153.length?Number(_153):NaN;
case "boolean":
return typeof _153=="boolean"?_153:!(_153.toLowerCase()=="false");
case "function":
if(d.isFunction(_153)){
_153=_153.toString();
_153=d.trim(_153.substring(_153.indexOf("{")+1,_153.length-1));
}
try{
if(_153===""||_153.search(/[^\w\.]+/i)!=-1){
return new Function(_153);
}else{
return d.getObject(_153,false)||new Function(_153);
}
}
catch(e){
return new Function();
}
case "array":
return _153?_153.split(/\s*,\s*/):[];
case "date":
switch(_153){
case "":
return new Date("");
case "now":
return new Date();
default:
return d.date.stamp.fromISOString(_153);
}
case "url":
return d.baseUrl+_153;
default:
return d.fromJson(_153);
}
};
var _154={},_155={};
d.connect(d,"extend",function(){
_155={};
});
function _156(cls,_157){
for(var name in cls){
if(name.charAt(0)=="_"){
continue;
}
if(name in _154){
continue;
}
_157[name]=_150(cls[name]);
}
return _157;
};
function _158(_159,_15a){
var c=_155[_159];
if(!c){
var cls=d.getObject(_159),_15b=null;
if(!cls){
return null;
}
if(!_15a){
_15b=_156(cls.prototype,{});
}
c={cls:cls,params:_15b};
}else{
if(!_15a&&!c.params){
c.params=_156(c.cls.prototype,{});
}
}
return c;
};
this._functionFromScript=function(_15c,_15d){
var _15e="";
var _15f="";
var _160=(_15c.getAttribute(_15d+"args")||_15c.getAttribute("args"));
if(_160){
d.forEach(_160.split(/\s*,\s*/),function(part,idx){
_15e+="var "+part+" = arguments["+idx+"]; ";
});
}
var _161=_15c.getAttribute("with");
if(_161&&_161.length){
d.forEach(_161.split(/\s*,\s*/),function(part){
_15e+="with("+part+"){";
_15f+="}";
});
}
return new Function(_15e+_15c.innerHTML+_15f);
};
this.instantiate=function(_162,_163,args){
var _164=[],_163=_163||{};
args=args||{};
var _165=(args.scope||d._scopeName)+"Type",_166="data-"+(args.scope||d._scopeName)+"-";
d.forEach(_162,function(obj){
if(!obj){
return;
}
var node,type,_167,_168,_169,_16a;
if(obj.node){
node=obj.node;
type=obj.type;
_16a=obj.fastpath;
_167=obj.clsInfo||(type&&_158(type,_16a));
_168=_167&&_167.cls;
_169=obj.scripts;
}else{
node=obj;
type=_165 in _163?_163[_165]:node.getAttribute(_165);
_167=type&&_158(type);
_168=_167&&_167.cls;
_169=(_168&&(_168._noScript||_168.prototype._noScript)?[]:d.query("> script[type^='dojo/']",node));
}
if(!_167){
throw new Error("Could not load class '"+type);
}
var _16b={};
if(args.defaults){
d._mixin(_16b,args.defaults);
}
if(obj.inherited){
d._mixin(_16b,obj.inherited);
}
if(_16a){
var _16c=node.getAttribute(_166+"props");
if(_16c&&_16c.length){
try{
_16c=d.fromJson.call(args.propsThis,"{"+_16c+"}");
d._mixin(_16b,_16c);
}
catch(e){
throw new Error(e.toString()+" in data-dojo-props='"+_16c+"'");
}
}
var _16d=node.getAttribute(_166+"attach-point");
if(_16d){
_16b.dojoAttachPoint=_16d;
}
var _16e=node.getAttribute(_166+"attach-event");
if(_16e){
_16b.dojoAttachEvent=_16e;
}
dojo.mixin(_16b,_163);
}else{
var _16f=node.attributes;
for(var name in _167.params){
var item=name in _163?{value:_163[name],specified:true}:_16f.getNamedItem(name);
if(!item||(!item.specified&&(!dojo.isIE||name.toLowerCase()!="value"))){
continue;
}
var _170=item.value;
switch(name){
case "class":
_170="className" in _163?_163.className:node.className;
break;
case "style":
_170="style" in _163?_163.style:(node.style&&node.style.cssText);
}
var _171=_167.params[name];
if(typeof _170=="string"){
_16b[name]=_152(_170,_171);
}else{
_16b[name]=_170;
}
}
}
var _172=[],_173=[];
d.forEach(_169,function(_174){
node.removeChild(_174);
var _175=(_174.getAttribute(_166+"event")||_174.getAttribute("event")),type=_174.getAttribute("type"),nf=d.parser._functionFromScript(_174,_166);
if(_175){
if(type=="dojo/connect"){
_172.push({event:_175,func:nf});
}else{
_16b[_175]=nf;
}
}else{
_173.push(nf);
}
});
var _176=_168.markupFactory||_168.prototype&&_168.prototype.markupFactory;
var _177=_176?_176(_16b,node,_168):new _168(_16b,node);
_164.push(_177);
var _178=(node.getAttribute(_166+"id")||node.getAttribute("jsId"));
if(_178){
d.setObject(_178,_177);
}
d.forEach(_172,function(_179){
d.connect(_177,_179.event,null,_179.func);
});
d.forEach(_173,function(func){
func.call(_177);
});
});
if(!_163._started){
d.forEach(_164,function(_17a){
if(!args.noStart&&_17a&&dojo.isFunction(_17a.startup)&&!_17a._started&&(!_17a.getParent||!_17a.getParent())){
_17a.startup();
}
});
}
return _164;
};
this.parse=function(_17b,args){
var root;
if(!args&&_17b&&_17b.rootNode){
args=_17b;
root=args.rootNode;
}else{
root=_17b;
}
root=root?dojo.byId(root):dojo.body();
args=args||{};
var _17c=(args.scope||d._scopeName)+"Type",_17d="data-"+(args.scope||d._scopeName)+"-";
function scan(_17e,list){
var _17f=dojo.clone(_17e.inherited);
dojo.forEach(["dir","lang"],function(name){
var val=_17e.node.getAttribute(name);
if(val){
_17f[name]=val;
}
});
var _180=_17e.clsInfo&&!_17e.clsInfo.cls.prototype._noScript?_17e.scripts:null;
var _181=(!_17e.clsInfo||!_17e.clsInfo.cls.prototype.stopParser)||(args&&args.template);
for(var _182=_17e.node.firstChild;_182;_182=_182.nextSibling){
if(_182.nodeType==1){
var type,_183=_181&&_182.getAttribute(_17d+"type");
if(_183){
type=_183;
}else{
type=_181&&_182.getAttribute(_17c);
}
var _184=_183==type;
if(type){
var _185={"type":type,fastpath:_184,clsInfo:_158(type,_184),node:_182,scripts:[],inherited:_17f};
list.push(_185);
scan(_185,list);
}else{
if(_180&&_182.nodeName.toLowerCase()=="script"){
type=_182.getAttribute("type");
if(type&&/^dojo\/\w/i.test(type)){
_180.push(_182);
}
}else{
if(_181){
scan({node:_182,inherited:_17f},list);
}
}
}
}
}
};
var _186={};
if(args&&args.inherited){
for(var key in args.inherited){
if(args.inherited[key]){
_186[key]=args.inherited[key];
}
}
}
var list=[];
scan({node:root,inherited:_186},list);
var _187=args&&args.template?{template:true}:null;
return this.instantiate(list,_187,args);
};
}();
(function(){
var _188=function(){
if(dojo.config.parseOnLoad){
dojo.parser.parse();
}
};
if(dojo.getObject("dijit.wai.onload")===dojo._loaders[0]){
dojo._loaders.splice(1,0,_188);
}else{
dojo._loaders.unshift(_188);
}
})();
}
if(!dojo._hasResource["dojo.cache"]){
dojo._hasResource["dojo.cache"]=true;
dojo.provide("dojo.cache");
var cache={};
dojo.cache=function(_189,url,_18a){
if(typeof _189=="string"){
var _18b=dojo.moduleUrl(_189,url);
}else{
_18b=_189;
_18a=url;
}
var key=_18b.toString();
var val=_18a;
if(_18a!=undefined&&!dojo.isString(_18a)){
val=("value" in _18a?_18a.value:undefined);
}
var _18c=_18a&&_18a.sanitize?true:false;
if(typeof val=="string"){
val=cache[key]=_18c?dojo.cache._sanitize(val):val;
}else{
if(val===null){
delete cache[key];
}else{
if(!(key in cache)){
val=dojo._getText(key);
cache[key]=_18c?dojo.cache._sanitize(val):val;
}
val=cache[key];
}
}
return val;
};
dojo.cache._sanitize=function(val){
if(val){
val=val.replace(/^\s*<\?xml(\s)+version=[\'\"](\d)*.(\d)*[\'\"](\s)*\?>/im,"");
var _18d=val.match(/<body[^>]*>\s*([\s\S]+)\s*<\/body>/im);
if(_18d){
val=_18d[1];
}
}else{
val="";
}
return val;
};
}
if(!dojo._hasResource["dijit._Templated"]){
dojo._hasResource["dijit._Templated"]=true;
dojo.provide("dijit._Templated");
dojo.declare("dijit._Templated",null,{templateString:null,templatePath:null,widgetsInTemplate:false,_skipNodeCache:false,_earlyTemplatedStartup:false,constructor:function(){
this._attachPoints=[];
this._attachEvents=[];
},_stringRepl:function(tmpl){
var _18e=this.declaredClass,_18f=this;
return dojo.string.substitute(tmpl,this,function(_190,key){
if(key.charAt(0)=="!"){
_190=dojo.getObject(key.substr(1),false,_18f);
}
if(typeof _190=="undefined"){
throw new Error(_18e+" template:"+key);
}
if(_190==null){
return "";
}
return key.charAt(0)=="!"?_190:_190.toString().replace(/"/g,"&quot;");
},this);
},buildRendering:function(){
var _191=dijit._Templated.getCachedTemplate(this.templatePath,this.templateString,this._skipNodeCache);
var node;
if(dojo.isString(_191)){
node=dojo._toDom(this._stringRepl(_191));
if(node.nodeType!=1){
throw new Error("Invalid template: "+_191);
}
}else{
node=_191.cloneNode(true);
}
this.domNode=node;
this.inherited(arguments);
this._attachTemplateNodes(node);
if(this.widgetsInTemplate){
var cw=(this._startupWidgets=dojo.parser.parse(node,{noStart:!this._earlyTemplatedStartup,template:true,inherited:{dir:this.dir,lang:this.lang},propsThis:this,scope:"dojo"}));
this._supportingWidgets=dijit.findWidgets(node);
this._attachTemplateNodes(cw,function(n,p){
return n[p];
});
}
this._fillContent(this.srcNodeRef);
},_fillContent:function(_192){
var dest=this.containerNode;
if(_192&&dest){
while(_192.hasChildNodes()){
dest.appendChild(_192.firstChild);
}
}
},_attachTemplateNodes:function(_193,_194){
_194=_194||function(n,p){
return n.getAttribute(p);
};
var _195=dojo.isArray(_193)?_193:(_193.all||_193.getElementsByTagName("*"));
var x=dojo.isArray(_193)?0:-1;
for(;x<_195.length;x++){
var _196=(x==-1)?_193:_195[x];
if(this.widgetsInTemplate&&(_194(_196,"dojoType")||_194(_196,"data-dojo-type"))){
continue;
}
var _197=_194(_196,"dojoAttachPoint")||_194(_196,"data-dojo-attach-point");
if(_197){
var _198,_199=_197.split(/\s*,\s*/);
while((_198=_199.shift())){
if(dojo.isArray(this[_198])){
this[_198].push(_196);
}else{
this[_198]=_196;
}
this._attachPoints.push(_198);
}
}
var _19a=_194(_196,"dojoAttachEvent")||_194(_196,"data-dojo-attach-event");
if(_19a){
var _19b,_19c=_19a.split(/\s*,\s*/);
var trim=dojo.trim;
while((_19b=_19c.shift())){
if(_19b){
var _19d=null;
if(_19b.indexOf(":")!=-1){
var _19e=_19b.split(":");
_19b=trim(_19e[0]);
_19d=trim(_19e[1]);
}else{
_19b=trim(_19b);
}
if(!_19d){
_19d=_19b;
}
this._attachEvents.push(this.connect(_196,_19b,_19d));
}
}
}
var role=_194(_196,"waiRole");
if(role){
dijit.setWaiRole(_196,role);
}
var _19f=_194(_196,"waiState");
if(_19f){
dojo.forEach(_19f.split(/\s*,\s*/),function(_1a0){
if(_1a0.indexOf("-")!=-1){
var pair=_1a0.split("-");
dijit.setWaiState(_196,pair[0],pair[1]);
}
});
}
}
},startup:function(){
dojo.forEach(this._startupWidgets,function(w){
if(w&&!w._started&&w.startup){
w.startup();
}
});
this.inherited(arguments);
},destroyRendering:function(){
dojo.forEach(this._attachPoints,function(_1a1){
delete this[_1a1];
},this);
this._attachPoints=[];
dojo.forEach(this._attachEvents,this.disconnect,this);
this._attachEvents=[];
this.inherited(arguments);
}});
dijit._Templated._templateCache={};
dijit._Templated.getCachedTemplate=function(_1a2,_1a3,_1a4){
var _1a5=dijit._Templated._templateCache;
var key=_1a3||_1a2;
var _1a6=_1a5[key];
if(_1a6){
try{
if(!_1a6.ownerDocument||_1a6.ownerDocument==dojo.doc){
return _1a6;
}
}
catch(e){
}
dojo.destroy(_1a6);
}
if(!_1a3){
_1a3=dojo.cache(_1a2,{sanitize:true});
}
_1a3=dojo.string.trim(_1a3);
if(_1a4||_1a3.match(/\$\{([^\}]+)\}/g)){
return (_1a5[key]=_1a3);
}else{
var node=dojo._toDom(_1a3);
if(node.nodeType!=1){
throw new Error("Invalid template: "+_1a3);
}
return (_1a5[key]=node);
}
};
if(dojo.isIE){
dojo.addOnWindowUnload(function(){
var _1a7=dijit._Templated._templateCache;
for(var key in _1a7){
var _1a8=_1a7[key];
if(typeof _1a8=="object"){
dojo.destroy(_1a8);
}
delete _1a7[key];
}
});
}
dojo.extend(dijit._Widget,{dojoAttachEvent:"",dojoAttachPoint:"",waiRole:"",waiState:""});
}
if(!dojo._hasResource["dojoe.treetable.filter._ConditionExpr"]){
dojo._hasResource["dojoe.treetable.filter._ConditionExpr"]=true;
dojo.provide("dojoe.treetable.filter._ConditionExpr");
(function(){
var f_ns=dojoe.treetable.filter;
dojo.declare("dojoe.treetable.filter._ConditionExpr",null,{applyRow:function(_1a9,_1aa){
throw new Error("_ConditionExpr.applyRow: unimplemented interface");
},toObject:function(){
return {};
},getName:function(){
return "expr";
}});
dojo.declare("dojoe.treetable.filter._DataExpr",f_ns._ConditionExpr,{constructor:function(_1ab,_1ac,_1ad){
try{
this._convertArgs=_1ad||{};
if(dojo.isFunction(this._convertArgs.convert)){
this._convertData=dojo.hitch(this._convertArgs.scope,this._convertArgs.convert);
}
if(_1ac){
this._colArg=_1ab;
}else{
this._value=this._convertData(_1ab,this._convertArgs);
}
}
catch(ex){
}
},getValue:function(){
return this._value;
},applyRow:function(_1ae,_1af){
return typeof this._colArg=="undefined"?this:new (dojo.getObject(this.declaredClass))(this._convertData(_1af(_1ae,this._colArg),this._convertArgs));
},_convertData:function(_1b0){
return _1b0;
},toObject:function(){
return {op:this.getName(),data:this._colArg===undefined?this._value:this._colArg,isCol:this._colArg!==undefined};
},getName:function(){
return "data";
}});
dojo.declare("dojoe.treetable.filter._OperatorExpr",f_ns._ConditionExpr,{constructor:function(){
if(dojo.isArray(arguments[0])){
this._operands=arguments[0];
}else{
this._operands=[];
for(var i=0;i<arguments.length;++i){
this._operands.push(arguments[i]);
}
}
},toObject:function(){
return {op:this.getName(),data:dojo.map(this._operands,function(_1b1){
return _1b1.toObject();
})};
},getName:function(){
return "operator";
}});
dojo.declare("dojoe.treetable.filter._UniOpExpr",f_ns._OperatorExpr,{applyRow:function(_1b2,_1b3){
if(!(this._operands[0] instanceof f_ns._ConditionExpr)){
throw new Error("_UniOpExpr: operand is not expression.");
}
return this._calculate(this._operands[0],_1b2,_1b3);
},_calculate:function(_1b4,_1b5,_1b6){
throw new Error("_UniOpExpr._calculate: unimplemented interface");
},getName:function(){
return "uniOperator";
}});
dojo.declare("dojoe.treetable.filter._BiOpExpr",f_ns._OperatorExpr,{applyRow:function(_1b7,_1b8){
if(!(this._operands[0] instanceof f_ns._ConditionExpr)){
throw new Error("_BiOpExpr: left operand is not expression.");
}else{
if(!(this._operands[1] instanceof f_ns._ConditionExpr)){
throw new Error("_BiOpExpr: right operand is not expression.");
}
}
return this._calculate(this._operands[0],this._operands[1],_1b7,_1b8);
},_calculate:function(_1b9,_1ba,_1bb,_1bc){
throw new Error("_BiOpExpr._calculate: unimplemented interface");
},getName:function(){
return "biOperator";
}});
})();
}
if(!dojo._hasResource["dojo.date"]){
dojo._hasResource["dojo.date"]=true;
dojo.provide("dojo.date");
dojo.getObject("date",true,dojo);
dojo.date.getDaysInMonth=function(_1bd){
var _1be=_1bd.getMonth();
var days=[31,28,31,30,31,30,31,31,30,31,30,31];
if(_1be==1&&dojo.date.isLeapYear(_1bd)){
return 29;
}
return days[_1be];
};
dojo.date.isLeapYear=function(_1bf){
var year=_1bf.getFullYear();
return !(year%400)||(!(year%4)&&!!(year%100));
};
dojo.date.getTimezoneName=function(_1c0){
var str=_1c0.toString();
var tz="";
var _1c1;
var pos=str.indexOf("(");
if(pos>-1){
tz=str.substring(++pos,str.indexOf(")"));
}else{
var pat=/([A-Z\/]+) \d{4}$/;
if((_1c1=str.match(pat))){
tz=_1c1[1];
}else{
str=_1c0.toLocaleString();
pat=/ ([A-Z\/]+)$/;
if((_1c1=str.match(pat))){
tz=_1c1[1];
}
}
}
return (tz=="AM"||tz=="PM")?"":tz;
};
dojo.date.compare=function(_1c2,_1c3,_1c4){
_1c2=new Date(+_1c2);
_1c3=new Date(+(_1c3||new Date()));
if(_1c4=="date"){
_1c2.setHours(0,0,0,0);
_1c3.setHours(0,0,0,0);
}else{
if(_1c4=="time"){
_1c2.setFullYear(0,0,0);
_1c3.setFullYear(0,0,0);
}
}
if(_1c2>_1c3){
return 1;
}
if(_1c2<_1c3){
return -1;
}
return 0;
};
dojo.date.add=function(date,_1c5,_1c6){
var sum=new Date(+date);
var _1c7=false;
var _1c8="Date";
switch(_1c5){
case "day":
break;
case "weekday":
var days,_1c9;
var mod=_1c6%5;
if(!mod){
days=(_1c6>0)?5:-5;
_1c9=(_1c6>0)?((_1c6-5)/5):((_1c6+5)/5);
}else{
days=mod;
_1c9=parseInt(_1c6/5);
}
var strt=date.getDay();
var adj=0;
if(strt==6&&_1c6>0){
adj=1;
}else{
if(strt==0&&_1c6<0){
adj=-1;
}
}
var trgt=strt+days;
if(trgt==0||trgt==6){
adj=(_1c6>0)?2:-2;
}
_1c6=(7*_1c9)+days+adj;
break;
case "year":
_1c8="FullYear";
_1c7=true;
break;
case "week":
_1c6*=7;
break;
case "quarter":
_1c6*=3;
case "month":
_1c7=true;
_1c8="Month";
break;
default:
_1c8="UTC"+_1c5.charAt(0).toUpperCase()+_1c5.substring(1)+"s";
}
if(_1c8){
sum["set"+_1c8](sum["get"+_1c8]()+_1c6);
}
if(_1c7&&(sum.getDate()<date.getDate())){
sum.setDate(0);
}
return sum;
};
dojo.date.difference=function(_1ca,_1cb,_1cc){
_1cb=_1cb||new Date();
_1cc=_1cc||"day";
var _1cd=_1cb.getFullYear()-_1ca.getFullYear();
var _1ce=1;
switch(_1cc){
case "quarter":
var m1=_1ca.getMonth();
var m2=_1cb.getMonth();
var q1=Math.floor(m1/3)+1;
var q2=Math.floor(m2/3)+1;
q2+=(_1cd*4);
_1ce=q2-q1;
break;
case "weekday":
var days=Math.round(dojo.date.difference(_1ca,_1cb,"day"));
var _1cf=parseInt(dojo.date.difference(_1ca,_1cb,"week"));
var mod=days%7;
if(mod==0){
days=_1cf*5;
}else{
var adj=0;
var aDay=_1ca.getDay();
var bDay=_1cb.getDay();
_1cf=parseInt(days/7);
mod=days%7;
var _1d0=new Date(_1ca);
_1d0.setDate(_1d0.getDate()+(_1cf*7));
var _1d1=_1d0.getDay();
if(days>0){
switch(true){
case aDay==6:
adj=-1;
break;
case aDay==0:
adj=0;
break;
case bDay==6:
adj=-1;
break;
case bDay==0:
adj=-2;
break;
case (_1d1+mod)>5:
adj=-2;
}
}else{
if(days<0){
switch(true){
case aDay==6:
adj=0;
break;
case aDay==0:
adj=1;
break;
case bDay==6:
adj=2;
break;
case bDay==0:
adj=1;
break;
case (_1d1+mod)<0:
adj=2;
}
}
}
days+=adj;
days-=(_1cf*2);
}
_1ce=days;
break;
case "year":
_1ce=_1cd;
break;
case "month":
_1ce=(_1cb.getMonth()-_1ca.getMonth())+(_1cd*12);
break;
case "week":
_1ce=parseInt(dojo.date.difference(_1ca,_1cb,"day")/7);
break;
case "day":
_1ce/=24;
case "hour":
_1ce/=60;
case "minute":
_1ce/=60;
case "second":
_1ce/=1000;
case "millisecond":
_1ce*=_1cb.getTime()-_1ca.getTime();
}
return Math.round(_1ce);
};
}
if(!dojo._hasResource["dojo.i18n"]){
dojo._hasResource["dojo.i18n"]=true;
dojo.provide("dojo.i18n");
dojo.getObject("i18n",true,dojo);
dojo.i18n.getLocalization=dojo.i18n.getLocalization||function(_1d2,_1d3,_1d4){
_1d4=dojo.i18n.normalizeLocale(_1d4);
var _1d5=_1d4.split("-");
var _1d6=[_1d2,"nls",_1d3].join(".");
var _1d7=dojo._loadedModules[_1d6];
if(_1d7){
var _1d8;
for(var i=_1d5.length;i>0;i--){
var loc=_1d5.slice(0,i).join("_");
if(_1d7[loc]){
_1d8=_1d7[loc];
break;
}
}
if(!_1d8){
_1d8=_1d7.ROOT;
}
if(_1d8){
var _1d9=function(){
};
_1d9.prototype=_1d8;
return new _1d9();
}
}
throw new Error("Bundle not found: "+_1d3+" in "+_1d2+" , locale="+_1d4);
};
dojo.i18n.normalizeLocale=function(_1da){
var _1db=_1da?_1da.toLowerCase():dojo.locale;
if(_1db=="root"){
_1db="ROOT";
}
return _1db;
};
dojo.i18n._requireLocalization=function(_1dc,_1dd,_1de,_1df){
var _1e0=dojo.i18n.normalizeLocale(_1de);
var _1e1=[_1dc,"nls",_1dd].join(".");
var _1e2="";
if(_1df){
var _1e3=_1df.split(",");
for(var i=0;i<_1e3.length;i++){
if(_1e0["indexOf"](_1e3[i])==0){
if(_1e3[i].length>_1e2.length){
_1e2=_1e3[i];
}
}
}
if(!_1e2){
_1e2="ROOT";
}
}
var _1e4=_1df?_1e2:_1e0;
var _1e5=dojo._loadedModules[_1e1];
var _1e6=null;
if(_1e5){
if(dojo.config.localizationComplete&&_1e5._built){
return;
}
var _1e7=_1e4.replace(/-/g,"_");
var _1e8=_1e1+"."+_1e7;
_1e6=dojo._loadedModules[_1e8];
}
if(!_1e6){
_1e5=dojo["provide"](_1e1);
var syms=dojo._getModuleSymbols(_1dc);
var _1e9=syms.concat("nls").join("/");
var _1ea;
dojo.i18n._searchLocalePath(_1e4,_1df,function(loc){
var _1eb=loc.replace(/-/g,"_");
var _1ec=_1e1+"."+_1eb;
var _1ed=false;
if(!dojo._loadedModules[_1ec]){
dojo["provide"](_1ec);
var _1ee=[_1e9];
if(loc!="ROOT"){
_1ee.push(loc);
}
_1ee.push(_1dd);
var _1ef=_1ee.join("/")+".js";
_1ed=dojo._loadPath(_1ef,null,function(hash){
hash=hash.root||hash;
var _1f0=function(){
};
_1f0.prototype=_1ea;
_1e5[_1eb]=new _1f0();
for(var j in hash){
_1e5[_1eb][j]=hash[j];
}
});
}else{
_1ed=true;
}
if(_1ed&&_1e5[_1eb]){
_1ea=_1e5[_1eb];
}else{
_1e5[_1eb]=_1ea;
}
if(_1df){
return true;
}
});
}
if(_1df&&_1e0!=_1e2){
_1e5[_1e0.replace(/-/g,"_")]=_1e5[_1e2.replace(/-/g,"_")];
}
};
(function(){
var _1f1=dojo.config.extraLocale;
if(_1f1){
if(!_1f1 instanceof Array){
_1f1=[_1f1];
}
var req=dojo.i18n._requireLocalization;
dojo.i18n._requireLocalization=function(m,b,_1f2,_1f3){
req(m,b,_1f2,_1f3);
if(_1f2){
return;
}
for(var i=0;i<_1f1.length;i++){
req(m,b,_1f1[i],_1f3);
}
};
}
})();
dojo.i18n._searchLocalePath=function(_1f4,down,_1f5){
_1f4=dojo.i18n.normalizeLocale(_1f4);
var _1f6=_1f4.split("-");
var _1f7=[];
for(var i=_1f6.length;i>0;i--){
_1f7.push(_1f6.slice(0,i).join("-"));
}
_1f7.push(false);
if(down){
_1f7.reverse();
}
for(var j=_1f7.length-1;j>=0;j--){
var loc=_1f7[j]||"ROOT";
var stop=_1f5(loc);
if(stop){
break;
}
}
};
dojo.i18n._preloadLocalizations=function(_1f8,_1f9){
function _1fa(_1fb){
_1fb=dojo.i18n.normalizeLocale(_1fb);
dojo.i18n._searchLocalePath(_1fb,true,function(loc){
for(var i=0;i<_1f9.length;i++){
if(_1f9[i]==loc){
dojo["require"](_1f8+"_"+loc);
return true;
}
}
return false;
});
};
_1fa();
var _1fc=dojo.config.extraLocale||[];
for(var i=0;i<_1fc.length;i++){
_1fa(_1fc[i]);
}
};
}
if(!dojo._hasResource["dojo.cldr.supplemental"]){
dojo._hasResource["dojo.cldr.supplemental"]=true;
dojo.provide("dojo.cldr.supplemental");
dojo.getObject("cldr.supplemental",true,dojo);
dojo.cldr.supplemental.getFirstDayOfWeek=function(_1fd){
var _1fe={mv:5,ae:6,af:6,bh:6,dj:6,dz:6,eg:6,er:6,et:6,iq:6,ir:6,jo:6,ke:6,kw:6,ly:6,ma:6,om:6,qa:6,sa:6,sd:6,so:6,sy:6,tn:6,ye:6,ar:0,as:0,az:0,bw:0,ca:0,cn:0,fo:0,ge:0,gl:0,gu:0,hk:0,il:0,"in":0,jm:0,jp:0,kg:0,kr:0,la:0,mh:0,mn:0,mo:0,mp:0,mt:0,nz:0,ph:0,pk:0,sg:0,th:0,tt:0,tw:0,um:0,us:0,uz:0,vi:0,zw:0};
var _1ff=dojo.cldr.supplemental._region(_1fd);
var dow=_1fe[_1ff];
return (dow===undefined)?1:dow;
};
dojo.cldr.supplemental._region=function(_200){
_200=dojo.i18n.normalizeLocale(_200);
var tags=_200.split("-");
var _201=tags[1];
if(!_201){
_201={de:"de",en:"us",es:"es",fi:"fi",fr:"fr",he:"il",hu:"hu",it:"it",ja:"jp",ko:"kr",nl:"nl",pt:"br",sv:"se",zh:"cn"}[tags[0]];
}else{
if(_201.length==4){
_201=tags[2];
}
}
return _201;
};
dojo.cldr.supplemental.getWeekend=function(_202){
var _203={"in":0,af:4,dz:4,ir:4,om:4,sa:4,ye:4,ae:5,bh:5,eg:5,il:5,iq:5,jo:5,kw:5,ly:5,ma:5,qa:5,sd:5,sy:5,tn:5};
var _204={af:5,dz:5,ir:5,om:5,sa:5,ye:5,ae:6,bh:5,eg:6,il:6,iq:6,jo:6,kw:6,ly:6,ma:6,qa:6,sd:6,sy:6,tn:6};
var _205=dojo.cldr.supplemental._region(_202);
var _206=_203[_205];
var end=_204[_205];
if(_206===undefined){
_206=6;
}
if(end===undefined){
end=0;
}
return {start:_206,end:end};
};
}
if(!dojo._hasResource["dojo.regexp"]){
dojo._hasResource["dojo.regexp"]=true;
dojo.provide("dojo.regexp");
dojo.getObject("regexp",true,dojo);
dojo.regexp.escapeString=function(str,_207){
return str.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g,function(ch){
if(_207&&_207.indexOf(ch)!=-1){
return ch;
}
return "\\"+ch;
});
};
dojo.regexp.buildGroupRE=function(arr,re,_208){
if(!(arr instanceof Array)){
return re(arr);
}
var b=[];
for(var i=0;i<arr.length;i++){
b.push(re(arr[i]));
}
return dojo.regexp.group(b.join("|"),_208);
};
dojo.regexp.group=function(_209,_20a){
return "("+(_20a?"?:":"")+_209+")";
};
}
if(!dojo._hasResource["dojo.date.locale"]){
dojo._hasResource["dojo.date.locale"]=true;
dojo.provide("dojo.date.locale");
dojo.getObject("date.locale",true,dojo);
(function(){
function _20b(_20c,_20d,_20e,_20f){
return _20f.replace(/([a-z])\1*/ig,function(_210){
var s,pad,c=_210.charAt(0),l=_210.length,_211=["abbr","wide","narrow"];
switch(c){
case "G":
s=_20d[(l<4)?"eraAbbr":"eraNames"][_20c.getFullYear()<0?0:1];
break;
case "y":
s=_20c.getFullYear();
switch(l){
case 1:
break;
case 2:
if(!_20e.fullYear){
s=String(s);
s=s.substr(s.length-2);
break;
}
default:
pad=true;
}
break;
case "Q":
case "q":
s=Math.ceil((_20c.getMonth()+1)/3);
pad=true;
break;
case "M":
var m=_20c.getMonth();
if(l<3){
s=m+1;
pad=true;
}else{
var _212=["months","format",_211[l-3]].join("-");
s=_20d[_212][m];
}
break;
case "w":
var _213=0;
s=dojo.date.locale._getWeekOfYear(_20c,_213);
pad=true;
break;
case "d":
s=_20c.getDate();
pad=true;
break;
case "D":
s=dojo.date.locale._getDayOfYear(_20c);
pad=true;
break;
case "E":
var d=_20c.getDay();
if(l<3){
s=d+1;
pad=true;
}else{
var _214=["days","format",_211[l-3]].join("-");
s=_20d[_214][d];
}
break;
case "a":
var _215=(_20c.getHours()<12)?"am":"pm";
s=_20e[_215]||_20d["dayPeriods-format-wide-"+_215];
break;
case "h":
case "H":
case "K":
case "k":
var h=_20c.getHours();
switch(c){
case "h":
s=(h%12)||12;
break;
case "H":
s=h;
break;
case "K":
s=(h%12);
break;
case "k":
s=h||24;
break;
}
pad=true;
break;
case "m":
s=_20c.getMinutes();
pad=true;
break;
case "s":
s=_20c.getSeconds();
pad=true;
break;
case "S":
s=Math.round(_20c.getMilliseconds()*Math.pow(10,l-3));
pad=true;
break;
case "v":
case "z":
s=dojo.date.locale._getZone(_20c,true,_20e);
if(s){
break;
}
l=4;
case "Z":
var _216=dojo.date.locale._getZone(_20c,false,_20e);
var tz=[(_216<=0?"+":"-"),dojo.string.pad(Math.floor(Math.abs(_216)/60),2),dojo.string.pad(Math.abs(_216)%60,2)];
if(l==4){
tz.splice(0,0,"GMT");
tz.splice(3,0,":");
}
s=tz.join("");
break;
default:
throw new Error("dojo.date.locale.format: invalid pattern char: "+_20f);
}
if(pad){
s=dojo.string.pad(s,l);
}
return s;
});
};
dojo.date.locale._getZone=function(_217,_218,_219){
if(_218){
return dojo.date.getTimezoneName(_217);
}else{
return _217.getTimezoneOffset();
}
};
dojo.date.locale.format=function(_21a,_21b){
_21b=_21b||{};
var _21c=dojo.i18n.normalizeLocale(_21b.locale),_21d=_21b.formatLength||"short",_21e=dojo.date.locale._getGregorianBundle(_21c),str=[],_21f=dojo.hitch(this,_20b,_21a,_21e,_21b);
if(_21b.selector=="year"){
return _220(_21e["dateFormatItem-yyyy"]||"yyyy",_21f);
}
var _221;
if(_21b.selector!="date"){
_221=_21b.timePattern||_21e["timeFormat-"+_21d];
if(_221){
str.push(_220(_221,_21f));
}
}
if(_21b.selector!="time"){
_221=_21b.datePattern||_21e["dateFormat-"+_21d];
if(_221){
str.push(_220(_221,_21f));
}
}
return str.length==1?str[0]:_21e["dateTimeFormat-"+_21d].replace(/\{(\d+)\}/g,function(_222,key){
return str[key];
});
};
dojo.date.locale.regexp=function(_223){
return dojo.date.locale._parseInfo(_223).regexp;
};
dojo.date.locale._parseInfo=function(_224){
_224=_224||{};
var _225=dojo.i18n.normalizeLocale(_224.locale),_226=dojo.date.locale._getGregorianBundle(_225),_227=_224.formatLength||"short",_228=_224.datePattern||_226["dateFormat-"+_227],_229=_224.timePattern||_226["timeFormat-"+_227],_22a;
if(_224.selector=="date"){
_22a=_228;
}else{
if(_224.selector=="time"){
_22a=_229;
}else{
_22a=_226["dateTimeFormat-"+_227].replace(/\{(\d+)\}/g,function(_22b,key){
return [_229,_228][key];
});
}
}
var _22c=[],re=_220(_22a,dojo.hitch(this,_22d,_22c,_226,_224));
return {regexp:re,tokens:_22c,bundle:_226};
};
dojo.date.locale.parse=function(_22e,_22f){
var _230=/[\u200E\u200F\u202A\u202E]/g,info=dojo.date.locale._parseInfo(_22f),_231=info.tokens,_232=info.bundle,re=new RegExp("^"+info.regexp.replace(_230,"")+"$",info.strict?"":"i"),_233=re.exec(_22e&&_22e.replace(_230,""));
if(!_233){
return null;
}
var _234=["abbr","wide","narrow"],_235=[1970,0,1,0,0,0,0],amPm="",_236=dojo.every(_233,function(v,i){
if(!i){
return true;
}
var _237=_231[i-1];
var l=_237.length;
switch(_237.charAt(0)){
case "y":
if(l!=2&&_22f.strict){
_235[0]=v;
}else{
if(v<100){
v=Number(v);
var year=""+new Date().getFullYear(),_238=year.substring(0,2)*100,_239=Math.min(Number(year.substring(2,4))+20,99),num=(v<_239)?_238+v:_238-100+v;
_235[0]=num;
}else{
if(_22f.strict){
return false;
}
_235[0]=v;
}
}
break;
case "M":
if(l>2){
var _23a=_232["months-format-"+_234[l-3]].concat();
if(!_22f.strict){
v=v.replace(".","").toLowerCase();
_23a=dojo.map(_23a,function(s){
return s.replace(".","").toLowerCase();
});
}
v=dojo.indexOf(_23a,v);
if(v==-1){
return false;
}
}else{
v--;
}
_235[1]=v;
break;
case "E":
case "e":
var days=_232["days-format-"+_234[l-3]].concat();
if(!_22f.strict){
v=v.toLowerCase();
days=dojo.map(days,function(d){
return d.toLowerCase();
});
}
v=dojo.indexOf(days,v);
if(v==-1){
return false;
}
break;
case "D":
_235[1]=0;
case "d":
_235[2]=v;
break;
case "a":
var am=_22f.am||_232["dayPeriods-format-wide-am"],pm=_22f.pm||_232["dayPeriods-format-wide-pm"];
if(!_22f.strict){
var _23b=/\./g;
v=v.replace(_23b,"").toLowerCase();
am=am.replace(_23b,"").toLowerCase();
pm=pm.replace(_23b,"").toLowerCase();
}
if(_22f.strict&&v!=am&&v!=pm){
return false;
}
amPm=(v==pm)?"p":(v==am)?"a":"";
break;
case "K":
if(v==24){
v=0;
}
case "h":
case "H":
case "k":
if(v>23){
return false;
}
_235[3]=v;
break;
case "m":
_235[4]=v;
break;
case "s":
_235[5]=v;
break;
case "S":
_235[6]=v;
}
return true;
});
var _23c=+_235[3];
if(amPm==="p"&&_23c<12){
_235[3]=_23c+12;
}else{
if(amPm==="a"&&_23c==12){
_235[3]=0;
}
}
var _23d=new Date(_235[0],_235[1],_235[2],_235[3],_235[4],_235[5],_235[6]);
if(_22f.strict){
_23d.setFullYear(_235[0]);
}
var _23e=_231.join(""),_23f=_23e.indexOf("d")!=-1,_240=_23e.indexOf("M")!=-1;
if(!_236||(_240&&_23d.getMonth()>_235[1])||(_23f&&_23d.getDate()>_235[2])){
return null;
}
if((_240&&_23d.getMonth()<_235[1])||(_23f&&_23d.getDate()<_235[2])){
_23d=dojo.date.add(_23d,"hour",1);
}
return _23d;
};
function _220(_241,_242,_243,_244){
var _245=function(x){
return x;
};
_242=_242||_245;
_243=_243||_245;
_244=_244||_245;
var _246=_241.match(/(''|[^'])+/g),_247=_241.charAt(0)=="'";
dojo.forEach(_246,function(_248,i){
if(!_248){
_246[i]="";
}else{
_246[i]=(_247?_243:_242)(_248.replace(/''/g,"'"));
_247=!_247;
}
});
return _244(_246.join(""));
};
function _22d(_249,_24a,_24b,_24c){
_24c=dojo.regexp.escapeString(_24c);
if(!_24b.strict){
_24c=_24c.replace(" a"," ?a");
}
return _24c.replace(/([a-z])\1*/ig,function(_24d){
var s,c=_24d.charAt(0),l=_24d.length,p2="",p3="";
if(_24b.strict){
if(l>1){
p2="0"+"{"+(l-1)+"}";
}
if(l>2){
p3="0"+"{"+(l-2)+"}";
}
}else{
p2="0?";
p3="0{0,2}";
}
switch(c){
case "y":
s="\\d{2,4}";
break;
case "M":
s=(l>2)?"\\S+?":"1[0-2]|"+p2+"[1-9]";
break;
case "D":
s="[12][0-9][0-9]|3[0-5][0-9]|36[0-6]|"+p3+"[1-9][0-9]|"+p2+"[1-9]";
break;
case "d":
s="3[01]|[12]\\d|"+p2+"[1-9]";
break;
case "w":
s="[1-4][0-9]|5[0-3]|"+p2+"[1-9]";
break;
case "E":
s="\\S+";
break;
case "h":
s="1[0-2]|"+p2+"[1-9]";
break;
case "k":
s="1[01]|"+p2+"\\d";
break;
case "H":
s="1\\d|2[0-3]|"+p2+"\\d";
break;
case "K":
s="1\\d|2[0-4]|"+p2+"[1-9]";
break;
case "m":
case "s":
s="[0-5]\\d";
break;
case "S":
s="\\d{"+l+"}";
break;
case "a":
var am=_24b.am||_24a["dayPeriods-format-wide-am"],pm=_24b.pm||_24a["dayPeriods-format-wide-pm"];
s=am+"|"+pm;
if(!_24b.strict){
if(am!=am.toLowerCase()){
s+="|"+am.toLowerCase();
}
if(pm!=pm.toLowerCase()){
s+="|"+pm.toLowerCase();
}
if(s.indexOf(".")!=-1){
s+="|"+s.replace(/\./g,"");
}
}
s=s.replace(/\./g,"\\.");
break;
default:
s=".*";
}
if(_249){
_249.push(_24d);
}
return "("+s+")";
}).replace(/[\xa0 ]/g,"[\\s\\xa0]");
};
})();
(function(){
var _24e=[];
dojo.date.locale.addCustomFormats=function(_24f,_250){
_24e.push({pkg:_24f,name:_250});
};
dojo.date.locale._getGregorianBundle=function(_251){
var _252={};
dojo.forEach(_24e,function(desc){
var _253=dojo.i18n.getLocalization(desc.pkg,desc.name,_251);
_252=dojo.mixin(_252,_253);
},this);
return _252;
};
})();
dojo.date.locale.addCustomFormats("dojo.cldr","gregorian");
dojo.date.locale.getNames=function(item,type,_254,_255){
var _256,_257=dojo.date.locale._getGregorianBundle(_255),_258=[item,_254,type];
if(_254=="standAlone"){
var key=_258.join("-");
_256=_257[key];
if(_256[0]==1){
_256=undefined;
}
}
_258[1]="format";
return (_256||_257[_258.join("-")]).concat();
};
dojo.date.locale.isWeekend=function(_259,_25a){
var _25b=dojo.cldr.supplemental.getWeekend(_25a),day=(_259||new Date()).getDay();
if(_25b.end<_25b.start){
_25b.end+=7;
if(day<_25b.start){
day+=7;
}
}
return day>=_25b.start&&day<=_25b.end;
};
dojo.date.locale._getDayOfYear=function(_25c){
return dojo.date.difference(new Date(_25c.getFullYear(),0,1,_25c.getHours()),_25c)+1;
};
dojo.date.locale._getWeekOfYear=function(_25d,_25e){
if(arguments.length==1){
_25e=0;
}
var _25f=new Date(_25d.getFullYear(),0,1).getDay(),adj=(_25f-_25e+7)%7,week=Math.floor((dojo.date.locale._getDayOfYear(_25d)+adj-1)/7);
if(_25f==_25e){
week++;
}
return week;
};
}
if(!dojo._hasResource["dojoe.treetable.filter._DataExprs"]){
dojo._hasResource["dojoe.treetable.filter._DataExprs"]=true;
dojo.provide("dojoe.treetable.filter._DataExprs");
(function(){
var f_ns=dojoe.treetable.filter;
dojo.declare("dojoe.treetable.filter.BooleanExpr",f_ns._DataExpr,{_convertData:function(_260){
return !!_260;
},getName:function(){
return "bool";
}});
dojo.declare("dojoe.treetable.filter.StringExpr",f_ns._DataExpr,{_convertData:function(_261){
return String(_261);
},getName:function(){
return "string";
}});
dojo.declare("dojoe.treetable.filter.NumberExpr",f_ns._DataExpr,{_convertDataToExpr:function(_262){
return parseFloat(_262);
},getName:function(){
return "number";
}});
dojo.declare("dojoe.treetable.filter.DateExpr",f_ns._DataExpr,{_selector:"date",_convertData:function(_263){
if(_263 instanceof Date){
return _263;
}else{
if(typeof _263=="number"){
return new Date(_263);
}else{
var res=dojo.date.locale.parse(String(_263),dojo.mixin({selector:this._selector},this._convertArgs));
if(!res){
throw new Error("Datetime parse failed: "+_263);
}
return res;
}
}
},toObject:function(){
if(this._value instanceof Date){
var tmp=this._value;
this._value=this._value.valueOf();
var res=this.inherited(arguments);
this._value=tmp;
return res;
}else{
return this.inherited(arguments);
}
},getName:function(){
return this._selector;
}});
dojo.declare("dojoe.treetable.filter.TimeExpr",f_ns.DateExpr,{_selector:"time"});
})();
}
if(!dojo._hasResource["dojoe.treetable.filter._FilterExpr"]){
dojo._hasResource["dojoe.treetable.filter._FilterExpr"]=true;
dojo.provide("dojoe.treetable.filter._FilterExpr");
(function(){
var f_ns=dojoe.treetable.filter;
dojo.declare("dojoe.treetable.filter.LogicAND",f_ns._BiOpExpr,{_calculate:function(_264,_265,_266,_267){
var res=_264.applyRow(_266,_267).getValue()&&_265.applyRow(_266,_267).getValue();
return new f_ns.BooleanExpr(res);
},getName:function(){
return "and";
}});
dojo.declare("dojoe.treetable.filter.LogicOR",f_ns._BiOpExpr,{_calculate:function(_268,_269,_26a,_26b){
var res=_268.applyRow(_26a,_26b).getValue()||_269.applyRow(_26a,_26b).getValue();
return new f_ns.BooleanExpr(res);
},getName:function(){
return "or";
}});
dojo.declare("dojoe.treetable.filter.LogicXOR",f_ns._BiOpExpr,{_calculate:function(_26c,_26d,_26e,_26f){
var _270=_26c.applyRow(_26e,_26f).getValue();
var _271=_26d.applyRow(_26e,_26f).getValue();
return new f_ns.BooleanExpr((!!_270)!=(!!_271));
},getName:function(){
return "xor";
}});
dojo.declare("dojoe.treetable.filter.LogicNOT",f_ns._UniOpExpr,{_calculate:function(_272,_273,_274){
return new f_ns.BooleanExpr(!_272.applyRow(_273,_274).getValue());
},getName:function(){
return "not";
}});
dojo.declare("dojoe.treetable.filter.LogicALL",f_ns._OperatorExpr,{applyRow:function(_275,_276){
for(var i=0,res=true;res&&(this._operands[i] instanceof f_ns._ConditionExpr);(res=this._operands[i].applyRow(_275,_276).getValue()),++i){
}
return new f_ns.BooleanExpr(res);
},getName:function(){
return "all";
}});
dojo.declare("dojoe.treetable.filter.LogicANY",f_ns._OperatorExpr,{applyRow:function(_277,_278){
for(var i=0,res=false;!res&&(this._operands[i] instanceof f_ns._ConditionExpr);(res=this._operands[i].applyRow(_277,_278).getValue()),++i){
}
return new f_ns.BooleanExpr(res);
},getName:function(){
return "any";
}});
function _279(left,_27a,row,_27b){
var left=left.applyRow(row,_27b);
var _27a=_27a.applyRow(row,_27b);
var _27c=left.getValue();
var _27d=_27a.getValue();
if(left instanceof f_ns.TimeExpr){
return dojo.date.compare(_27c,_27d,"time");
}else{
if(left instanceof f_ns.DateExpr){
return dojo.date.compare(_27c,_27d,"date");
}else{
return _27c==_27d?0:(_27c<_27d?-1:1);
}
}
};
dojo.declare("dojoe.treetable.filter.EqualTo",f_ns._BiOpExpr,{_calculate:function(_27e,_27f,_280,_281){
var res=_279(_27e,_27f,_280,_281);
return new f_ns.BooleanExpr(res==0);
},getName:function(){
return "equal";
}});
dojo.declare("dojoe.treetable.filter.LessThan",f_ns._BiOpExpr,{_calculate:function(_282,_283,_284,_285){
var res=_279(_282,_283,_284,_285);
return new f_ns.BooleanExpr(res<0);
},getName:function(){
return "less";
}});
dojo.declare("dojoe.treetable.filter.LessThanOrEqualTo",f_ns._BiOpExpr,{_calculate:function(_286,_287,_288,_289){
var res=_279(_286,_287,_288,_289);
return new f_ns.BooleanExpr(res<=0);
},getName:function(){
return "lessEqual";
}});
dojo.declare("dojoe.treetable.filter.LargerThan",f_ns._BiOpExpr,{_calculate:function(_28a,_28b,_28c,_28d){
var res=_279(_28a,_28b,_28c,_28d);
return new f_ns.BooleanExpr(res>0);
},getName:function(){
return "larger";
}});
dojo.declare("dojoe.treetable.filter.LargerThanOrEqualTo",f_ns._BiOpExpr,{_calculate:function(_28e,_28f,_290,_291){
var res=_279(_28e,_28f,_290,_291);
return new f_ns.BooleanExpr(res>=0);
},getName:function(){
return "largerEqual";
}});
dojo.declare("dojoe.treetable.filter.Contains",f_ns._BiOpExpr,{_calculate:function(_292,_293,_294,_295){
var _296=String(_292.applyRow(_294,_295).getValue());
var _297=String(_293.applyRow(_294,_295).getValue());
return new f_ns.BooleanExpr(_296.indexOf(_297)>=0);
},getName:function(){
return "contains";
}});
dojo.declare("dojoe.treetable.filter.ContainsIgnoreCase",f_ns._BiOpExpr,{fields:[],_calculate:function(_298,_299,_29a,_29b){
var _29c=String(_298.applyRow(_29a,_29b).getValue()).toLowerCase();
var _29d=String(_299.applyRow(_29a,_29b).getValue()).toLowerCase();
var _29e=new f_ns.BooleanExpr(_29c.indexOf(_29d)>=0);
if(!_29e._value&&_298._colArg.parentCell){
var _29f=_298._colArg.parentCell.field;
if(_29a[_29f]===undefined&&_298._colArg.parentCell.children){
this.fields=[];
_29f=this._getDatarowField(_298._colArg.parentCell.children,_29a);
}
if(dojo.isArray(this.fields)&&this.fields.length>0){
for(var i=0;i<this.fields.length;i++){
var _29f=this.fields[i];
if(_29a[_29f].length==1){
_29e=new f_ns.BooleanExpr(_29a[_29f][0].toString().indexOf(_29d)>=0);
if(_29e._value){
_29a.itemFound=true;
return _29e;
}
}
}
}
var _2a0=_29a[_29f];
var _2a1=[];
for(var i in _2a0){
_29e=this._calculate(_298,_299,_2a0[i],_29b);
if(_2a0[i].itemFound){
_29a.itemFound=true;
}
if(_29e._value){
_2a1.push(_2a0[i]);
_29a[_29f]=_2a1;
_29a.itemFound=true;
}
}
}else{
if(_29e._value){
}
}
return _29e;
},_getDatarowField:function(_2a2,_2a3){
if(_2a2===undefined){
return;
}
for(var chld=0;chld<_2a2.length;chld++){
var _2a4=_2a2[chld].field;
if(_2a4!=="label"){
if(_2a3[_2a4]===undefined){
_2a4=this._getDatarowField(_2a2[chld].children,_2a3);
}
if(_2a4!=null){
this.fields.push(_2a4);
}
}
}
return _2a4;
},getName:function(){
return "containsignorecase";
}});
dojo.declare("dojoe.treetable.filter.StartsWith",f_ns._BiOpExpr,{_calculate:function(_2a5,_2a6,_2a7,_2a8){
var _2a9=String(_2a5.applyRow(_2a7,_2a8).getValue());
var _2aa=String(_2a6.applyRow(_2a7,_2a8).getValue());
return new f_ns.BooleanExpr(_2a9.substring(0,_2aa.length)==_2aa);
},getName:function(){
return "startsWith";
}});
dojo.declare("dojoe.treetable.filter.EndsWith",f_ns._BiOpExpr,{_calculate:function(_2ab,_2ac,_2ad,_2ae){
var _2af=String(_2ab.applyRow(_2ad,_2ae).getValue());
var _2b0=String(_2ac.applyRow(_2ad,_2ae).getValue());
return new f_ns.BooleanExpr(_2af.substring(_2af.length-_2b0.length)==_2b0);
},getName:function(){
return "endsWith";
}});
dojo.declare("dojoe.treetable.filter.Matches",f_ns._BiOpExpr,{_calculate:function(_2b1,_2b2,_2b3,_2b4){
var _2b5=String(_2b1.applyRow(_2b3,_2b4).getValue());
var _2b6=new RegExp(_2b2.applyRow(_2b3,_2b4).getValue());
return new f_ns.BooleanExpr(_2b5.search(_2b6)>=0);
},getName:function(){
return "matches";
}});
})();
}
if(!dojo._hasResource["dojoe.treetable.filter.StoreLayer"]){
dojo._hasResource["dojoe.treetable.filter.StoreLayer"]=true;
dojo.provide("dojoe.treetable.filter.StoreLayer");
(function(){
var ns=dojoe.treetable.filter,_2b7=function(tags){
var _2b8=["reorder","sizeChange","normal","presentation"];
var idx=_2b8.length;
for(var i=tags.length-1;i>=0;--i){
var p=dojo.indexOf(_2b8,tags[i]);
if(p>=0&&p<=idx){
idx=p;
}
}
if(idx<_2b8.length-1){
return _2b8.slice(0,idx+1);
}else{
return _2b8;
}
},_2b9=function(_2ba){
var i,_2bb=this._layers,len=_2bb.length;
if(_2ba){
for(i=len-1;i>=0;--i){
if(_2bb[i].name()==_2ba){
_2bb[i]._unwrap(_2bb[i+1]);
break;
}
}
_2bb.splice(i,1);
}else{
for(i=len-1;i>=0;--i){
_2bb[i]._unwrap();
}
}
if(!_2bb.length){
delete this._layers;
delete this.layer;
delete this.unwrap;
delete this.forEachLayer;
}
return this;
},_2bc=function(_2bd){
var i,_2be=this._layers;
if(typeof _2bd=="undefined"){
return _2be.length;
}
if(typeof _2bd=="number"){
return _2be[_2bd];
}
for(i=_2be.length-1;i>=0;--i){
if(_2be[i].name()==_2bd){
return _2be[i];
}
}
return null;
},_2bf=function(_2c0,_2c1){
var len=this._layers.length,_2c2,end,dir;
if(_2c1){
_2c2=0;
end=len;
dir=1;
}else{
_2c2=len-1;
end=-1;
dir=-1;
}
for(var i=_2c2;i!=end;i+=dir){
if(_2c0(this._layers[i],i)===false){
return i;
}
}
return end;
};
ns.wrap=function(_2c3,_2c4,_2c5,_2c6){
if(!_2c3._layers){
_2c3._layers=[];
_2c3.layer=dojo.hitch(_2c3,_2bc);
_2c3.unwrap=dojo.hitch(_2c3,_2b9);
_2c3.forEachLayer=dojo.hitch(_2c3,_2bf);
}
var _2c7=_2b7(_2c5.tags);
if(!dojo.some(_2c3._layers,function(lyr,i){
if(dojo.some(lyr.tags,function(tag){
return dojo.indexOf(_2c7,tag)>=0;
})){
return false;
}else{
_2c3._layers.splice(i,0,_2c5);
_2c5._wrap(_2c3,_2c4,_2c6,lyr);
return true;
}
})){
_2c3._layers.push(_2c5);
_2c5._wrap(_2c3,_2c4,_2c6);
}
return _2c3;
};
dojo.declare("dojoe.treetable.filter._StoreLayer",null,{tags:["normal"],layerFuncName:"_fetch",constructor:function(){
this._store=null;
this._originFetch=null;
this.__enabled=true;
},initialize:function(_2c8){
},uninitialize:function(_2c9){
},invalidate:function(){
},_wrap:function(_2ca,_2cb,_2cc,_2cd){
this._store=_2ca;
this._funcName=_2cb;
var _2ce=dojo.hitch(this,function(){
return (this.enabled()?this[_2cc||this.layerFuncName]:this.originFetch).apply(this,arguments);
});
if(_2cd){
this._originFetch=_2cd._originFetch;
_2cd._originFetch=_2ce;
}else{
this._originFetch=_2ca[_2cb]||function(){
};
_2ca[_2cb]=_2ce;
}
this.initialize(_2ca);
},_unwrap:function(_2cf){
this.uninitialize(this._store);
if(_2cf){
_2cf._originFetch=this._originFetch;
}else{
this._store[this._funcName]=this._originFetch;
}
this._originFetch=null;
this._store=null;
},enabled:function(_2d0){
if(typeof _2d0!="undefined"){
this.__enabled=!!_2d0;
}
return this.__enabled;
},name:function(){
if(!this.__name){
var m=this.declaredClass.match(/(?:\.([^\.]+)Layer$)|(?:\.([^\.]+)$)/i);
this.__name=m?(m[1]||m[2]).toLowerCase():this.declaredClass;
}
return this.__name;
},originFetch:function(){
return (dojo.hitch(this._store,this._originFetch)).apply(this,arguments);
}});
dojo.declare("dojoe.treetable.filter._ServerSideLayer",ns._StoreLayer,{constructor:function(args){
args=args||{};
this._url=args.url||"";
this._isStateful=!!args.isStateful;
this._onUserCommandLoad=args.onCommandLoad||function(){
};
this.__cmds={cmdlayer:this.name(),enable:true};
this.useCommands(this._isStateful);
},enabled:function(_2d1){
var res=this.inherited(arguments);
this.__cmds.enable=this.__enabled;
return res;
},useCommands:function(_2d2){
if(typeof _2d2!="undefined"){
this.__cmds.cmdlayer=(_2d2&&this._isStateful)?this.name():null;
}
return !!(this.__cmds.cmdlayer);
},_fetch:function(_2d3){
if(this.__cmds.cmdlayer){
dojo.xhrPost({url:this._url||this._store.url,content:this.__cmds,load:dojo.hitch(this,function(_2d4){
this.onCommandLoad(_2d4,_2d3);
this.originFetch(_2d3);
}),error:dojo.hitch(this,this.onCommandError)});
}else{
this.onCommandLoad("",_2d3);
this.originFetch(_2d3);
}
return _2d3;
},command:function(_2d5,_2d6){
var cmds=this.__cmds;
if(_2d6===null){
delete cmds[_2d5];
}else{
if(typeof _2d6!=="undefined"){
cmds[_2d5]=_2d6;
}
}
return cmds[_2d5];
},onCommandLoad:function(_2d7,_2d8){
this._onUserCommandLoad(this.__cmds,_2d8,_2d7);
},onCommandError:function(_2d9){
throw _2d9;
}});
})();
}
if(!dojo._hasResource["dojoe.treetable.filter.FilterLayer"]){
dojo._hasResource["dojoe.treetable.filter.FilterLayer"]=true;
dojo.provide("dojoe.treetable.filter.FilterLayer");
(function(){
var ns=dojoe.treetable,_2da="filter",_2db="clear",_2dc=function(_2dd,func){
return func?dojo.hitch(_2dd||dojo.global,func):function(){
};
},_2de=function(obj){
var res={};
if(obj&&dojo.isObject(obj)){
for(var name in obj){
res[name]=obj[name];
}
}
return res;
},_2df=function(_2e0,_2e1){
var res=[],_2e2=[],_2e3=0,len=1,i;
for(i=1;i<_2e0.length;++i){
if(_2e0[i]==_2e0[i-1]+1){
++len;
}else{
res[_2e3]=len;
_2e3=i;
len=1;
}
}
res[_2e3]=len;
for(i=1;i<res.length;++i){
if(res[i]!=undefined){
_2e2.push({idx:i+_2e1,cnt:res[i]});
}
}
_2e2.sort(function(a,b){
return b.cnt-a.cnt;
});
return _2e2;
};
dojo.declare("dojoe.treetable.filter._FilterLayerMixin",null,{name:function(){
return "filter";
},onFilterDefined:function(_2e4){
},onFiltered:function(_2e5,_2e6){
}});
dojo.declare("dojoe.treetable.filter.ServerSideFilterLayer",[dojoe.treetable.filter._ServerSideLayer,ns.filter._FilterLayerMixin],{_filterText:null,constructor:function(args){
this._onUserCommandLoad=args.setupFilterQuery||this._onUserCommandLoad;
this.filterDef(null);
},setFilterText:function(_2e7){
this._filterText=_2e7;
},filterDef:function(_2e8){
if(_2e8){
this._filter=_2e8;
var obj=_2e8.toObject();
this.command(_2da,obj);
this.onFilterDefined(_2e8);
}else{
if(_2e8===null){
this._filter=null;
this.command(_2da,null);
this.onFilterDefined(null);
}
}
return this._filter;
},onCommandLoad:function(_2e9,_2ea){
this.inherited(arguments);
var _2eb=_2ea.onBegin;
if(this._isStateful){
var _2ec;
if(_2e9){
this.command(_2da,null);
this.command(_2db,null);
this.useCommands(false);
var _2ed=_2e9.split(",");
if(_2ed.length>=2){
_2ec=this._filteredSize=parseInt(_2ed[0]);
this.onFiltered(_2ec,parseInt(_2ed[1]));
}else{
return;
}
}else{
_2ec=this._filteredSize;
}
if(this.enabled()){
_2ea.onBegin=function(size,req){
_2dc(_2ea.scope,_2eb)(_2ec,req);
};
}
}else{
var _2ee=this;
_2ea.onBegin=function(size,req){
if(!_2ee._filter){
_2ee._storeSize=size;
}
_2ee.onFiltered(size,_2ee._storeSize||size);
req.onBegin=_2eb;
_2dc(_2ea.scope,_2eb)(size,req);
};
}
},_translate:function(_2ef,data,op,_2f0){
if(dojo.isArray(data)){
var _2f1=data.length;
if(_2f1>1){
_2ef.expression+="(";
}
for(var _2f2=0;_2f2<_2f1;++_2f2){
if(!this._translate(_2ef,data[_2f2].data,data[_2f2].op,op)){
if(data[_2f2].isCol){
_2ef.ids[data[_2f2].data]=true;
_2ef.expression+=data[_2f2].data;
_2ef.expression+=" ";
_2ef.expression+=this._translateOperator(op,_2f0);
}else{
if(data[_2f2].op=="string"){
_2ef.expression+=" '"+data[_2f2].data.replace(/'/g,"''")+"'";
}else{
_2ef.expression+=" "+data[_2f2].data;
}
}
}else{
if(_2f2+1<_2f1){
_2ef.expression+=" "+(op==="any"?"or":"and")+" ";
}
}
}
if(_2f1>1){
_2ef.expression+=")";
}
return true;
}else{
return false;
}
},_translateOperator:function(op1,op2){
var _2f3="";
switch(op1){
case "equal":
_2f3=(op2==="not"?"!=":"=");
break;
case "less":
_2f3=(op2==="not"?">=":"<");
break;
case "lessEqual":
_2f3=(op2==="not"?">":"<=");
break;
case "larger":
_2f3=(op2==="not"?"<=":">");
break;
case "largerEqual":
_2f3=(op2==="not"?"<":">=");
break;
case "contains":
case "containsignorecase":
_2f3=(op2==="not"?"!contains":"contains");
break;
case "startsWith":
_2f3=(op2==="not"?"!starts":"starts");
break;
case "endsWith":
_2f3=(op2==="not"?"!ends":"ends");
break;
default:
alert("unrecognized operator="+op1);
}
return _2f3;
}});
dojo.declare("dojoe.treetable.filter.ClientSideFilterLayer",[dojoe.treetable.filter._StoreLayer,ns.filter._FilterLayerMixin],{_storeSize:-1,_cacheSize:-1,_fetchAll:true,_grid:null,_filterText:null,children:null,constructor:function(args){
this.filterDef(null);
args=dojo.isObject(args)?args:{};
this.filterCacheSize(args.cacheSize);
this.fetchAllOnFirstFilter(args.fetchAll);
this._grid=args.grid;
this._getter=dojo.isFunction(args.getter)?args.getter:function(_2f4,_2f5,_2f6,_2f7){
return _2f7.getValue(_2f4,_2f5);
};
},filterDef:function(_2f8){
if(_2f8===undefined){
this._restore();
return this._filter;
}else{
if(!_2f8){
this._restore();
return this._filter;
}else{
if(_2f8=="clear"){
this._filter=null;
this._restore();
return this._filter;
}else{
this._filter=_2f8;
this._restore();
}
}
}
},setFilterText:function(_2f9){
this._filterText=_2f9;
},setGetter:function(_2fa){
if(dojo.isFunction(_2fa)){
this._getter=_2fa;
}
},filterCacheSize:function(size){
if(size===undefined){
return this._cacheSize;
}
this._cacheSize=size>0?size:-1;
},fetchAllOnFirstFilter:function(_2fb){
if(_2fb===undefined){
return this._fetchAll;
}
this._fetchAll=!!_2fb;
},invalidate:function(){
this._restore();
},_restore:function(){
this._items=[];
this._nextUnfetchedIdx=0;
this._result=[];
this._indexMap=[];
this._cacheHoles=[];
this._cachedItemCount=0;
this._resultStartIdx=0;
},_fetch:function(_2fc,_2fd){
if(this._filter==null){
var _2fe=_2fc.onBegin,_2ff=this;
_2fc.onBegin=function(size,r){
_2dc(_2fc.scope,_2fe)(size,r);
_2ff.onFiltered(size,size);
};
dojo.hitch(this._store,this._originFetch)(_2fc);
return _2fc;
}
try{
var _300=_2fd?_2fd._nextResultItemIdx:_2fc.start;
_300=_300||0;
this._grid.filterApplied=true;
if(!_2fd){
this._result=[];
this._resultStartIdx=_300;
var _301;
if(dojo.isArray(_2fc.sort)&&_2fc.sort.length>0&&(_301=dojo.toJson(_2fc.sort))!=this._lastSortInfo){
this._restore();
this._lastSortInfo=_301;
}
}
var end=typeof _2fc.count=="number"?_300+_2fc.count-this._result.length:this._items.length;
if(this._result.length){
this._result=this._result.concat(this._items.slice(_300,end));
}else{
this._result=this._items.slice(_2fc.start,typeof _2fc.count=="number"?_2fc.start+_2fc.count:this._items.length);
}
if(this._result.length>=_2fc.count||this._hasReachedStoreEnd()){
this._completeQuery(_2fc);
}else{
if(!_2fd){
_2fd=_2de(_2fc);
_2fd.onBegin=dojo.hitch(this,this._onFetchBegin);
_2fd.onComplete=dojo.hitch(this,function(_302,req){
this._nextUnfetchedIdx+=_302.length;
this._doFilter(_302,req.start,_2fc);
this._fetch(_2fc,req);
});
}
_2fd.start=this._nextUnfetchedIdx;
if(this._fetchAll){
delete _2fd.count;
}
_2fd._nextResultItemIdx=end<this._items.length?end:this._items.length;
_2fd.query=null;
this.originFetch(_2fd);
}
}
catch(e){
if(_2fc.onError){
_2dc(_2fc.scope,_2fc.onError)(e,_2fc);
}else{
throw e;
}
}
return _2fc;
},_hasReachedStoreEnd:function(){
return this._storeSize>=0&&this._nextUnfetchedIdx>=this._storeSize;
},_applyFilter:function(_303,_304){
var g=this._getter,s=this._store;
try{
return !!(this._filter.applyRow(_303,function(item,arg){
return g(item,arg,_304,s);
}).getValue());
}
catch(e){
return false;
}
},_doFilter:function(_305,_306,_307){
for(var i=0,cnt=0;i<_305.length;++i){
var _308={};
_308.start=0;
_308.count=20;
var _309=this._applyFilter(_305[i],_306+i);
if(_309){
_2dc(_307.scope,_307.onItem)(_305[i],_307);
cnt+=this._addCachedItems(_305[i],this._items.length);
this._indexMap.push(_306+i);
}
}
},_setChildren:function(_30a,_30b,size){
this.children=_30a;
},_onFetchBegin:function(size,req){
this._storeSize=size;
},_completeQuery:function(_30c){
var size=this._items.length;
if(this._nextUnfetchedIdx<this._storeSize){
size++;
}
_2dc(_30c.scope,_30c.onBegin)(size,_30c);
this._fillUncachedResult(_30c,0);
},_fillUncachedResult:function(_30d,_30e){
var i,_30f,j,m;
if(this._cacheSize>=0){
for(i=_30e;i<this._result.length;++i){
if(!this._result[i]){
_30f=i+this._resultStartIdx;
if(this._result[i]=this._items[_30f]){
continue;
}
for(j=0;j<this._cacheHoles.length;++j){
m=this._cacheHoles[j];
if(_30f>=m.idx&&_30f<m.idx+m.cnt){
dojo.hitch(this._store,this._originFetch)({start:this._indexMap[m.idx],count:m.cnt,_filterIdx:m.idx,_resultIdx:i,_holeObjIdx:j,onComplete:dojo.hitch(this,function(_310,req){
if(_310.length!=req.count){
throw new Error("_fillUncachedResult: fatal error");
}
this._addCachedItems(_310,req._filterIdx);
this._cacheHoles.splice(req._holeObjIdx,1);
this._fillUncachedResult(_30d,req._resultIdx);
})});
return;
}
}
}
}
}
this._checkCacheSize(_30d);
this.onFiltered(this._items.length,this._storeSize);
_2dc(_30d.scope,_30d.onComplete)(this._result,_30d);
},_checkCacheSize:function(_311){
if(this._cacheSize<0){
return;
}
var dif,_312=0,_313=_311.start||0,end=_313;
if(_311.count){
end+=_311.count;
}
if((dif=this._cachedItemCount-this._cacheSize)>0){
var func=dojo.hitch(this,function(cnt,_314,_315){
var arr=_315?this._indexMap.slice(_314,_315):this._indexMap.slice(_314);
var q=_2df(arr,_314);
while(cnt<dif&&(m=q.shift())){
cnt+=this._delCachedItems(m.idx,m.cnt);
this._cacheHoles.push(m);
}
return cnt;
});
if(_311.start>0){
_312=func(0,0,_313);
}
if(_312<dif&&end<this._indexMap.length){
_312=func(_312,end);
}
}
},_addCachedItems:function(_316,_317){
if(!dojo.isArray(_316)){
_316=[_316];
}
for(var k=0;k<_316.length;++k){
this._items[_317+k]=_316[k];
}
this._cachedItemCount+=_316.length;
return _316.length;
},_delCachedItems:function(_318,_319){
for(var k=_318,end=_318+_319;k<end&&k<this._items.length;++k){
delete this._items[k];
}
this._cachedItemCount-=_319;
return _319;
},onRowMappingChange:function(_31a){
if(this._filter!=null){
var m=dojo.clone(_31a),_31b={};
for(var r in m){
r=parseInt(r,10);
_31a[this._indexMap[r]]=this._indexMap[m[r]];
if(!_31b[this._indexMap[r]]){
_31b[this._indexMap[r]]=true;
}
if(!_31b[r]){
_31b[r]=true;
delete _31a[r];
}
}
}
}});
})();
}
if(!dojo._hasResource["dojoe.treetable._QuickSearchFilter"]){
dojo._hasResource["dojoe.treetable._QuickSearchFilter"]=true;
dojo.provide("dojoe.treetable._QuickSearchFilter");
dojo.declare("dojoe.treetable._QuickSearchFilter",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dojoe.treetable","templates/QuickSearchFilter.html","<div class=\"dijitReset  dijitTextBox quickFilter\" dojoAttachEvent='onmouseover:_onHover,mouseleave:_onUnHover,onblur:_onBlur,onclick: _onClick'>\r\n\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" role=\"presentation\">\r\n\t\t<tbody>\r\n\t\t\t<tr valign=\"center\">\r\n\t\t\t\t<td width=\"98%\" height=\"100%\">\r\n\t\t\t\t\t<div class=\"dijitReset  dijitInputContainer\">\t\t    \r\n\t\t\t\t\t\t<input dojoAttachPoint=\"searchField\" title=\"${resources_.QUICK_FILTER}\" class=\"dijitInputInner qf-textfield\" type=\"text\" \r\n\t\t\t\t\t\t\tvalue=\"${resources_.QF_DEFAULT_TEXT}\" valign=\"middle\" tabindex=\"0\"\r\n\t\t\t\t\t\t\tdojoAttachEvent='onfocus:_onFocus,onclick:_onClick,onkeyup:_onKeyUp,onpaste:_onKeyUp,oncut:_onKeyUp,onKeyPress:_onKeyUp' role=\"textbox\"/>\t\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</td>\t\r\n\t\t\t\t<td width=\"2%\" height=\"100%\">\r\n\t\t\t\t\t<div class=\"dijitReset  dijitArrowButtonContainer \">\r\n\t\t\t\t\t\t<button title=\"${resources_.CLEAR_FILTER}\" class=\"dijitReset quickFilterClearInner\" type=\"button\" tabindex=\"0\" \r\n\t\t\t\t\t\t\tvalign=\"middle\"  dojoAttachPoint='clearFilterNode' dojoAttachEvent='onclick:_onCancel,onkeypress:_onCancel' role=\"button\"></button>\t\t\t\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t</tbody>\t\t\r\n\t</table>\r\n</div>\r\n"),widgetsInTemplate:false,grid:null,handle:null,filterText:null,filterLayer:null,filterOptions:null,_quickFilterButton:false,_quickFilterDelay:700,constructor:function(){
this.resources_=dojo.i18n.getLocalization("dojoe.treetable","TreeTable",this.lang);
},postCreate:function(){
if(this.filterOptions){
if(this.filterOptions.showQuickFilterButton!==undefined){
this._quickFilterButton=this.filterOptions.showQuickFilterButton;
}
if(this.filterOptions.quickFilterDelay){
this._quickFilterDelay=this.filterOptions.quickFilterDelay;
}
}
if(this.filterText!==null&&this.filterText!==""){
dojo.style(this.clearFilterNode,"display","block");
}else{
dojo.style(this.clearFilterNode,"display","none");
}
},postMixInProperties:function(){
},_parseDecimal:function(v){
return parseInt(v,10);
},_onFocus:function(){
if(this.grid._loading){
return;
}
dojo.addClass(this.domNode,"dijitTextBoxFocused");
if(this.searchField.value==this.resources_.QF_DEFAULT_TEXT){
this.searchField.style.color="#000000";
this.searchField.value="";
}
},_onClick:function(){
if(this.grid._loading){
return;
}
dojo.addClass(this.domNode,"dijitTextBoxFocused");
this.searchField.focus();
this.searchField.style.color="#000000";
if(this.searchField.value==this.resources_.QF_DEFAULT_TEXT){
this.searchField.value="";
}
},_onBlur:function(){
dojo.removeClass(this.domNode,"dijitTextBoxFocused");
dojo.removeClass(this.domNode,"dijitTextBoxHover");
if(!this.searchField.value){
this.searchField.style.color="#999999";
this.searchField.value=this.resources_.QF_DEFAULT_TEXT;
}
},_onHover:function(){
if(this.grid._loading){
return;
}
dojo.addClass(this.domNode,"dijitTextBoxHover");
},_onUnHover:function(){
dojo.removeClass(this.domNode,"dijitTextBoxHover");
},_onKeyUp:function(_31c){
if(this.grid._loading){
return;
}
this.filterText=this.searchField.value;
if(_31c){
if(_31c.keyCode==9||_31c.keyCode==16){
return;
}else{
if(this._quickFilterButton&&_31c.keyCode!==13){
return;
}
}
if(_31c.keyCode==13){
dojo.stopEvent(_31c);
this._setFilter();
return;
}
}
this.onChangeFilterText();
},_onCancel:function(_31d){
if(_31d.keyCode==9||_31d.keyCode==16){
return;
}else{
this._clearFilter();
}
},wrapStore:function(){
this._store=this.grid.store;
this._doFilter();
this.connect(this.grid,"setStore",function(_31e){
if(_31e!==this._store){
this._doFilter();
this._store=_31e;
}
});
},_clearFilter:function(){
this.searchField.value="";
this.grid.filterApplied=false;
if(this.filterOptions.isServerSide){
if(this.filterLayer){
this.filterLayer.filterDef(null);
if(this.grid.query){
this.grid.setQuery(dojo.mixin(this.grid.query,{origins:true,"filterText":null}));
}else{
this.grid.setQuery({origins:true});
}
this.grid._cleanup();
this.grid._refresh();
}
}else{
if(this.filterLayer){
this.filterLayer.filterDef("clear");
this.grid._cleanup();
this.grid._refresh();
}
}
this.filterText=null;
this._disableQuickFilter();
this.connect(this.filterLayer,"onFiltered",dojo.hitch(this,"_enableQuickFilter"));
this.fetchEnableFilterHandler=this.connect(this.grid,"_onFetchComplete",dojo.hitch(this,"_enableQuickFilter"));
},_setFilter:function(_31f){
if(_31f!==undefined&&_31f!==""){
this.filterText=_31f;
this.searchField.value=_31f;
}
this.wrapStore();
},_getFilter:function(){
return this.filterText;
},_doFilter:function(){
if(this.filterOptions&&this.filterOptions.retainSelection!==true){
this.grid.selection.clear();
}
var args=this.filterOptions;
var fns=dojoe.treetable.filter;
var _320=this.filterText;
if(_320===null||_320===undefined){
return;
}
if(_320===""){
this._clearFilter();
return;
}
var _321=this.grid.layout.cells;
var expr=new fns.LogicANY(dojo.map(_321,function(cell){
return new fns.ContainsIgnoreCase(new fns.StringExpr(cell,true),new fns.StringExpr(_320,false));
}));
if(!this.filterLayer){
if(args.isServerSide){
this.filterLayer=new fns.ServerSideFilterLayer(args);
fns.wrap(this.grid.store,"fetch",this.filterLayer);
}else{
this.filterLayer=new fns.ClientSideFilterLayer({fetchAll:true,grid:this.grid,getter:dojo.hitch(this.grid?this.grid:this,function(_322,cell,_323){
try{
return cell.get(_323,_322);
}
catch(ex){
}
})});
fns.wrap(this.grid.store,"fetch",this.filterLayer);
}
}
if(args.isServerSide){
this.grid.setQuery({filterText:_320});
}
this.filterLayer.filterDef(expr);
this.grid.filterApplied=true;
this._disableQuickFilter();
this.connect(this.filterLayer,"onFiltered",dojo.hitch(this,"_enableQuickFilter"));
this.fetchEnableFilterHandler=this.connect(this.grid,"_onFetchComplete",dojo.hitch(this,"_enableQuickFilter"));
this.grid._cleanup();
this.grid._refresh(true);
},_enableQuickFilter:function(_324,_325){
if(this.clearFilterNode&&this.clearFilterNode.style.display=="none"&&(this.filterText&&this.filterText!==""&&this.searchField.value!=this.resources_.QF_DEFAULT_TEXT)){
dojo.style(this.clearFilterNode,"display","block");
}
if(this.searchField&&this.searchField.disabled==true){
this.searchField.disabled=false;
if(this.filterText&&this.filterText!==""&&this.searchField.value!=this.resources_.QF_DEFAULT_TEXT){
this.searchField.focus();
this.searchField.style.color="#000000";
}else{
if(!this.searchField.value||this.searchField.value==this.resources_.QF_DEFAULT_TEXT){
this.searchField.style.color="#999999";
this.searchField.value=this.resources_.QF_DEFAULT_TEXT;
}
}
}
this.disconnect(this.fetchEnableFilterHandler);
},_disableQuickFilter:function(){
if(this.clearFilterNode&&this.clearFilterNode.style.display=="block"){
dojo.style(this.clearFilterNode,"display","none");
}
if(this.searchField&&this.searchField.disabled==false){
this.searchField.disabled=true;
this._onBlur();
this.searchField.style.color="#999999";
}
},unWrapStore:function(){
this._store=this.grid.store;
try{
this._store.unwrap("filter");
}
catch(ex){
}
},onChangeFilterText:function(){
if(this.handle){
clearTimeout(this.handle);
this.handle=null;
}
var fnc=dojo.hitch(this,this._setFilter,this.filterText);
this.handle=setTimeout(fnc,this._quickFilterDelay);
},destroy:function(){
try{
delete this.resources_;
var _326=dijit.findWidgets(this.domNode);
dojo.forEach(_326,function(w){
if(w){
if(w.destroyRecursive){
w.destroyRecursive();
}else{
if(w.destroy){
w.destroy();
}
}
}
});
var _327=this.getChildren();
dojo.forEach(_327,function(_328){
if(_328){
if(_328.destroyRecursive){
_328.destroyRecursive();
}else{
if(_328.destroy){
_328.destroy();
}
}
}
});
this.inherited(arguments);
}
catch(ex){
console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
}
}});
}
if(!dojo._hasResource["dojo.dnd.common"]){
dojo._hasResource["dojo.dnd.common"]=true;
dojo.provide("dojo.dnd.common");
dojo.getObject("dnd",true,dojo);
dojo.dnd.getCopyKeyState=dojo.isCopyKey;
dojo.dnd._uniqueId=0;
dojo.dnd.getUniqueId=function(){
var id;
do{
id=dojo._scopeName+"Unique"+(++dojo.dnd._uniqueId);
}while(dojo.byId(id));
return id;
};
dojo.dnd._empty={};
dojo.dnd.isFormElement=function(e){
var t=e.target;
if(t.nodeType==3){
t=t.parentNode;
}
return " button textarea input select option ".indexOf(" "+t.tagName.toLowerCase()+" ")>=0;
};
}
if(!dojo._hasResource["dojo.dnd.autoscroll"]){
dojo._hasResource["dojo.dnd.autoscroll"]=true;
dojo.provide("dojo.dnd.autoscroll");
dojo.getObject("dnd",true,dojo);
dojo.dnd.getViewport=dojo.window.getBox;
dojo.dnd.V_TRIGGER_AUTOSCROLL=32;
dojo.dnd.H_TRIGGER_AUTOSCROLL=32;
dojo.dnd.V_AUTOSCROLL_VALUE=16;
dojo.dnd.H_AUTOSCROLL_VALUE=16;
dojo.dnd.autoScroll=function(e){
var v=dojo.window.getBox(),dx=0,dy=0;
if(e.clientX<dojo.dnd.H_TRIGGER_AUTOSCROLL){
dx=-dojo.dnd.H_AUTOSCROLL_VALUE;
}else{
if(e.clientX>v.w-dojo.dnd.H_TRIGGER_AUTOSCROLL){
dx=dojo.dnd.H_AUTOSCROLL_VALUE;
}
}
if(e.clientY<dojo.dnd.V_TRIGGER_AUTOSCROLL){
dy=-dojo.dnd.V_AUTOSCROLL_VALUE;
}else{
if(e.clientY>v.h-dojo.dnd.V_TRIGGER_AUTOSCROLL){
dy=dojo.dnd.V_AUTOSCROLL_VALUE;
}
}
window.scrollBy(dx,dy);
};
dojo.dnd._validNodes={"div":1,"p":1,"td":1};
dojo.dnd._validOverflow={"auto":1,"scroll":1};
dojo.dnd.autoScrollNodes=function(e){
for(var n=e.target;n;){
if(n.nodeType==1&&(n.tagName.toLowerCase() in dojo.dnd._validNodes)){
var s=dojo.getComputedStyle(n);
if(s.overflow.toLowerCase() in dojo.dnd._validOverflow){
var b=dojo._getContentBox(n,s),t=dojo.position(n,true);
var w=Math.min(dojo.dnd.H_TRIGGER_AUTOSCROLL,b.w/2),h=Math.min(dojo.dnd.V_TRIGGER_AUTOSCROLL,b.h/2),rx=e.pageX-t.x,ry=e.pageY-t.y,dx=0,dy=0;
if(dojo.isWebKit||dojo.isOpera){
rx+=dojo.body().scrollLeft;
ry+=dojo.body().scrollTop;
}
if(rx>0&&rx<b.w){
if(rx<w){
dx=-w;
}else{
if(rx>b.w-w){
dx=w;
}
}
}
if(ry>0&&ry<b.h){
if(ry<h){
dy=-h;
}else{
if(ry>b.h-h){
dy=h;
}
}
}
var _329=n.scrollLeft,_32a=n.scrollTop;
n.scrollLeft=n.scrollLeft+dx;
n.scrollTop=n.scrollTop+dy;
if(_329!=n.scrollLeft||_32a!=n.scrollTop){
return;
}
}
}
try{
n=n.parentNode;
}
catch(x){
n=null;
}
}
dojo.dnd.autoScroll(e);
};
}
if(!dojo._hasResource["dojo.dnd.Mover"]){
dojo._hasResource["dojo.dnd.Mover"]=true;
dojo.provide("dojo.dnd.Mover");
dojo.declare("dojo.dnd.Mover",null,{constructor:function(node,e,host){
this.node=dojo.byId(node);
var pos=e.touches?e.touches[0]:e;
this.marginBox={l:pos.pageX,t:pos.pageY};
this.mouseButton=e.button;
var h=(this.host=host),d=node.ownerDocument;
this.events=[dojo.connect(d,"onmousemove",this,"onFirstMove"),dojo.connect(d,"ontouchmove",this,"onFirstMove"),dojo.connect(d,"onmousemove",this,"onMouseMove"),dojo.connect(d,"ontouchmove",this,"onMouseMove"),dojo.connect(d,"onmouseup",this,"onMouseUp"),dojo.connect(d,"ontouchend",this,"onMouseUp"),dojo.connect(d,"ondragstart",dojo.stopEvent),dojo.connect(d.body,"onselectstart",dojo.stopEvent)];
if(h&&h.onMoveStart){
h.onMoveStart(this);
}
},onMouseMove:function(e){
dojo.dnd.autoScroll(e);
var m=this.marginBox,pos=e.touches?e.touches[0]:e;
this.host.onMove(this,{l:m.l+pos.pageX,t:m.t+pos.pageY},e);
dojo.stopEvent(e);
},onMouseUp:function(e){
if(dojo.isWebKit&&dojo.isMac&&this.mouseButton==2?e.button==0:this.mouseButton==e.button){
this.destroy();
}
dojo.stopEvent(e);
},onFirstMove:function(e){
var s=this.node.style,l,t,h=this.host;
switch(s.position){
case "relative":
case "absolute":
l=Math.round(parseFloat(s.left))||0;
t=Math.round(parseFloat(s.top))||0;
break;
default:
s.position="absolute";
var m=dojo.marginBox(this.node);
var b=dojo.doc.body;
var bs=dojo.getComputedStyle(b);
var bm=dojo._getMarginBox(b,bs);
var bc=dojo._getContentBox(b,bs);
l=m.l-(bc.l-bm.l);
t=m.t-(bc.t-bm.t);
break;
}
this.marginBox.l=l-this.marginBox.l;
this.marginBox.t=t-this.marginBox.t;
if(h&&h.onFirstMove){
h.onFirstMove(this,e);
}
dojo.disconnect(this.events.shift());
dojo.disconnect(this.events.shift());
},destroy:function(){
dojo.forEach(this.events,dojo.disconnect);
var h=this.host;
if(h&&h.onMoveStop){
h.onMoveStop(this);
}
this.events=this.node=this.host=null;
}});
}
if(!dojo._hasResource["dojo.dnd.Moveable"]){
dojo._hasResource["dojo.dnd.Moveable"]=true;
dojo.provide("dojo.dnd.Moveable");
dojo.declare("dojo.dnd.Moveable",null,{handle:"",delay:0,skip:false,constructor:function(node,_32b){
this.node=dojo.byId(node);
if(!_32b){
_32b={};
}
this.handle=_32b.handle?dojo.byId(_32b.handle):null;
if(!this.handle){
this.handle=this.node;
}
this.delay=_32b.delay>0?_32b.delay:0;
this.skip=_32b.skip;
this.mover=_32b.mover?_32b.mover:dojo.dnd.Mover;
this.events=[dojo.connect(this.handle,"onmousedown",this,"onMouseDown"),dojo.connect(this.handle,"ontouchstart",this,"onMouseDown"),dojo.connect(this.handle,"ondragstart",this,"onSelectStart"),dojo.connect(this.handle,"onselectstart",this,"onSelectStart")];
},markupFactory:function(_32c,node){
return new dojo.dnd.Moveable(node,_32c);
},destroy:function(){
dojo.forEach(this.events,dojo.disconnect);
this.events=this.node=this.handle=null;
},onMouseDown:function(e){
if(this.skip&&dojo.dnd.isFormElement(e)){
return;
}
if(this.delay){
this.events.push(dojo.connect(this.handle,"onmousemove",this,"onMouseMove"),dojo.connect(this.handle,"ontouchmove",this,"onMouseMove"),dojo.connect(this.handle,"onmouseup",this,"onMouseUp"),dojo.connect(this.handle,"ontouchend",this,"onMouseUp"));
var pos=e.touches?e.touches[0]:e;
this._lastX=pos.pageX;
this._lastY=pos.pageY;
}else{
this.onDragDetected(e);
}
dojo.stopEvent(e);
},onMouseMove:function(e){
var pos=e.touches?e.touches[0]:e;
if(Math.abs(pos.pageX-this._lastX)>this.delay||Math.abs(pos.pageY-this._lastY)>this.delay){
this.onMouseUp(e);
this.onDragDetected(e);
}
dojo.stopEvent(e);
},onMouseUp:function(e){
for(var i=0;i<2;++i){
dojo.disconnect(this.events.pop());
}
dojo.stopEvent(e);
},onSelectStart:function(e){
if(!this.skip||!dojo.dnd.isFormElement(e)){
dojo.stopEvent(e);
}
},onDragDetected:function(e){
new this.mover(this.node,e,this);
},onMoveStart:function(_32d){
dojo.publish("/dnd/move/start",[_32d]);
dojo.addClass(dojo.body(),"dojoMove");
dojo.addClass(this.node,"dojoMoveItem");
},onMoveStop:function(_32e){
dojo.publish("/dnd/move/stop",[_32e]);
dojo.removeClass(dojo.body(),"dojoMove");
dojo.removeClass(this.node,"dojoMoveItem");
},onFirstMove:function(_32f,e){
},onMove:function(_330,_331,e){
this.onMoving(_330,_331);
var s=_330.node.style;
s.left=_331.l+"px";
s.top=_331.t+"px";
this.onMoved(_330,_331);
},onMoving:function(_332,_333){
},onMoved:function(_334,_335){
}});
}
if(!dojo._hasResource["dojo.dnd.move"]){
dojo._hasResource["dojo.dnd.move"]=true;
dojo.provide("dojo.dnd.move");
dojo.declare("dojo.dnd.move.constrainedMoveable",dojo.dnd.Moveable,{constraints:function(){
},within:false,markupFactory:function(_336,node){
return new dojo.dnd.move.constrainedMoveable(node,_336);
},constructor:function(node,_337){
if(!_337){
_337={};
}
this.constraints=_337.constraints;
this.within=_337.within;
},onFirstMove:function(_338){
var c=this.constraintBox=this.constraints.call(this,_338);
c.r=c.l+c.w;
c.b=c.t+c.h;
if(this.within){
var mb=dojo._getMarginSize(_338.node);
c.r-=mb.w;
c.b-=mb.h;
}
},onMove:function(_339,_33a){
var c=this.constraintBox,s=_339.node.style;
this.onMoving(_339,_33a);
_33a.l=_33a.l<c.l?c.l:c.r<_33a.l?c.r:_33a.l;
_33a.t=_33a.t<c.t?c.t:c.b<_33a.t?c.b:_33a.t;
s.left=_33a.l+"px";
s.top=_33a.t+"px";
this.onMoved(_339,_33a);
}});
dojo.declare("dojo.dnd.move.boxConstrainedMoveable",dojo.dnd.move.constrainedMoveable,{box:{},markupFactory:function(_33b,node){
return new dojo.dnd.move.boxConstrainedMoveable(node,_33b);
},constructor:function(node,_33c){
var box=_33c&&_33c.box;
this.constraints=function(){
return box;
};
}});
dojo.declare("dojo.dnd.move.parentConstrainedMoveable",dojo.dnd.move.constrainedMoveable,{area:"content",markupFactory:function(_33d,node){
return new dojo.dnd.move.parentConstrainedMoveable(node,_33d);
},constructor:function(node,_33e){
var area=_33e&&_33e.area;
this.constraints=function(){
var n=this.node.parentNode,s=dojo.getComputedStyle(n),mb=dojo._getMarginBox(n,s);
if(area=="margin"){
return mb;
}
var t=dojo._getMarginExtents(n,s);
mb.l+=t.l,mb.t+=t.t,mb.w-=t.w,mb.h-=t.h;
if(area=="border"){
return mb;
}
t=dojo._getBorderExtents(n,s);
mb.l+=t.l,mb.t+=t.t,mb.w-=t.w,mb.h-=t.h;
if(area=="padding"){
return mb;
}
t=dojo._getPadExtents(n,s);
mb.l+=t.l,mb.t+=t.t,mb.w-=t.w,mb.h-=t.h;
return mb;
};
}});
dojo.dnd.constrainedMover=dojo.dnd.move.constrainedMover;
dojo.dnd.boxConstrainedMover=dojo.dnd.move.boxConstrainedMover;
dojo.dnd.parentConstrainedMover=dojo.dnd.move.parentConstrainedMover;
}
if(!dojo._hasResource["dojo.dnd.TimedMoveable"]){
dojo._hasResource["dojo.dnd.TimedMoveable"]=true;
dojo.provide("dojo.dnd.TimedMoveable");
(function(){
var _33f=dojo.dnd.Moveable.prototype.onMove;
dojo.declare("dojo.dnd.TimedMoveable",dojo.dnd.Moveable,{timeout:40,constructor:function(node,_340){
if(!_340){
_340={};
}
if(_340.timeout&&typeof _340.timeout=="number"&&_340.timeout>=0){
this.timeout=_340.timeout;
}
},markupFactory:function(_341,node){
return new dojo.dnd.TimedMoveable(node,_341);
},onMoveStop:function(_342){
if(_342._timer){
clearTimeout(_342._timer);
_33f.call(this,_342,_342._leftTop);
}
dojo.dnd.Moveable.prototype.onMoveStop.apply(this,arguments);
},onMove:function(_343,_344){
_343._leftTop=_344;
if(!_343._timer){
var _345=this;
_343._timer=setTimeout(function(){
_343._timer=null;
_33f.call(_345,_343,_343._leftTop);
},this.timeout);
}
}});
})();
}
if(!dojo._hasResource["dojo.fx.Toggler"]){
dojo._hasResource["dojo.fx.Toggler"]=true;
dojo.provide("dojo.fx.Toggler");
dojo.declare("dojo.fx.Toggler",null,{node:null,showFunc:dojo.fadeIn,hideFunc:dojo.fadeOut,showDuration:200,hideDuration:200,constructor:function(args){
var _346=this;
dojo.mixin(_346,args);
_346.node=args.node;
_346._showArgs=dojo.mixin({},args);
_346._showArgs.node=_346.node;
_346._showArgs.duration=_346.showDuration;
_346.showAnim=_346.showFunc(_346._showArgs);
_346._hideArgs=dojo.mixin({},args);
_346._hideArgs.node=_346.node;
_346._hideArgs.duration=_346.hideDuration;
_346.hideAnim=_346.hideFunc(_346._hideArgs);
dojo.connect(_346.showAnim,"beforeBegin",dojo.hitch(_346.hideAnim,"stop",true));
dojo.connect(_346.hideAnim,"beforeBegin",dojo.hitch(_346.showAnim,"stop",true));
},show:function(_347){
return this.showAnim.play(_347||0);
},hide:function(_348){
return this.hideAnim.play(_348||0);
}});
}
if(!dojo._hasResource["dojo.fx"]){
dojo._hasResource["dojo.fx"]=true;
dojo.provide("dojo.fx");
(function(){
var d=dojo,_349={_fire:function(evt,args){
if(this[evt]){
this[evt].apply(this,args||[]);
}
return this;
}};
var _34a=function(_34b){
this._index=-1;
this._animations=_34b||[];
this._current=this._onAnimateCtx=this._onEndCtx=null;
this.duration=0;
d.forEach(this._animations,function(a){
this.duration+=a.duration;
if(a.delay){
this.duration+=a.delay;
}
},this);
};
d.extend(_34a,{_onAnimate:function(){
this._fire("onAnimate",arguments);
},_onEnd:function(){
d.disconnect(this._onAnimateCtx);
d.disconnect(this._onEndCtx);
this._onAnimateCtx=this._onEndCtx=null;
if(this._index+1==this._animations.length){
this._fire("onEnd");
}else{
this._current=this._animations[++this._index];
this._onAnimateCtx=d.connect(this._current,"onAnimate",this,"_onAnimate");
this._onEndCtx=d.connect(this._current,"onEnd",this,"_onEnd");
this._current.play(0,true);
}
},play:function(_34c,_34d){
if(!this._current){
this._current=this._animations[this._index=0];
}
if(!_34d&&this._current.status()=="playing"){
return this;
}
var _34e=d.connect(this._current,"beforeBegin",this,function(){
this._fire("beforeBegin");
}),_34f=d.connect(this._current,"onBegin",this,function(arg){
this._fire("onBegin",arguments);
}),_350=d.connect(this._current,"onPlay",this,function(arg){
this._fire("onPlay",arguments);
d.disconnect(_34e);
d.disconnect(_34f);
d.disconnect(_350);
});
if(this._onAnimateCtx){
d.disconnect(this._onAnimateCtx);
}
this._onAnimateCtx=d.connect(this._current,"onAnimate",this,"_onAnimate");
if(this._onEndCtx){
d.disconnect(this._onEndCtx);
}
this._onEndCtx=d.connect(this._current,"onEnd",this,"_onEnd");
this._current.play.apply(this._current,arguments);
return this;
},pause:function(){
if(this._current){
var e=d.connect(this._current,"onPause",this,function(arg){
this._fire("onPause",arguments);
d.disconnect(e);
});
this._current.pause();
}
return this;
},gotoPercent:function(_351,_352){
this.pause();
var _353=this.duration*_351;
this._current=null;
d.some(this._animations,function(a){
if(a.duration<=_353){
this._current=a;
return true;
}
_353-=a.duration;
return false;
});
if(this._current){
this._current.gotoPercent(_353/this._current.duration,_352);
}
return this;
},stop:function(_354){
if(this._current){
if(_354){
for(;this._index+1<this._animations.length;++this._index){
this._animations[this._index].stop(true);
}
this._current=this._animations[this._index];
}
var e=d.connect(this._current,"onStop",this,function(arg){
this._fire("onStop",arguments);
d.disconnect(e);
});
this._current.stop();
}
return this;
},status:function(){
return this._current?this._current.status():"stopped";
},destroy:function(){
if(this._onAnimateCtx){
d.disconnect(this._onAnimateCtx);
}
if(this._onEndCtx){
d.disconnect(this._onEndCtx);
}
}});
d.extend(_34a,_349);
dojo.fx.chain=function(_355){
return new _34a(_355);
};
var _356=function(_357){
this._animations=_357||[];
this._connects=[];
this._finished=0;
this.duration=0;
d.forEach(_357,function(a){
var _358=a.duration;
if(a.delay){
_358+=a.delay;
}
if(this.duration<_358){
this.duration=_358;
}
this._connects.push(d.connect(a,"onEnd",this,"_onEnd"));
},this);
this._pseudoAnimation=new d.Animation({curve:[0,1],duration:this.duration});
var self=this;
d.forEach(["beforeBegin","onBegin","onPlay","onAnimate","onPause","onStop","onEnd"],function(evt){
self._connects.push(d.connect(self._pseudoAnimation,evt,function(){
self._fire(evt,arguments);
}));
});
};
d.extend(_356,{_doAction:function(_359,args){
d.forEach(this._animations,function(a){
a[_359].apply(a,args);
});
return this;
},_onEnd:function(){
if(++this._finished>this._animations.length){
this._fire("onEnd");
}
},_call:function(_35a,args){
var t=this._pseudoAnimation;
t[_35a].apply(t,args);
},play:function(_35b,_35c){
this._finished=0;
this._doAction("play",arguments);
this._call("play",arguments);
return this;
},pause:function(){
this._doAction("pause",arguments);
this._call("pause",arguments);
return this;
},gotoPercent:function(_35d,_35e){
var ms=this.duration*_35d;
d.forEach(this._animations,function(a){
a.gotoPercent(a.duration<ms?1:(ms/a.duration),_35e);
});
this._call("gotoPercent",arguments);
return this;
},stop:function(_35f){
this._doAction("stop",arguments);
this._call("stop",arguments);
return this;
},status:function(){
return this._pseudoAnimation.status();
},destroy:function(){
d.forEach(this._connects,dojo.disconnect);
}});
d.extend(_356,_349);
dojo.fx.combine=function(_360){
return new _356(_360);
};
dojo.fx.wipeIn=function(args){
var node=args.node=d.byId(args.node),s=node.style,o;
var anim=d.animateProperty(d.mixin({properties:{height:{start:function(){
o=s.overflow;
s.overflow="hidden";
if(s.visibility=="hidden"||s.display=="none"){
s.height="1px";
s.display="";
s.visibility="";
return 1;
}else{
var _361=d.style(node,"height");
return Math.max(_361,1);
}
},end:function(){
return node.scrollHeight;
}}}},args));
d.connect(anim,"onEnd",function(){
s.height="auto";
s.overflow=o;
});
return anim;
};
dojo.fx.wipeOut=function(args){
var node=args.node=d.byId(args.node),s=node.style,o;
var anim=d.animateProperty(d.mixin({properties:{height:{end:1}}},args));
d.connect(anim,"beforeBegin",function(){
o=s.overflow;
s.overflow="hidden";
s.display="";
});
d.connect(anim,"onEnd",function(){
s.overflow=o;
s.height="auto";
s.display="none";
});
return anim;
};
dojo.fx.slideTo=function(args){
var node=args.node=d.byId(args.node),top=null,left=null;
var init=(function(n){
return function(){
var cs=d.getComputedStyle(n);
var pos=cs.position;
top=(pos=="absolute"?n.offsetTop:parseInt(cs.top)||0);
left=(pos=="absolute"?n.offsetLeft:parseInt(cs.left)||0);
if(pos!="absolute"&&pos!="relative"){
var ret=d.position(n,true);
top=ret.y;
left=ret.x;
n.style.position="absolute";
n.style.top=top+"px";
n.style.left=left+"px";
}
};
})(node);
init();
var anim=d.animateProperty(d.mixin({properties:{top:args.top||0,left:args.left||0}},args));
d.connect(anim,"beforeBegin",anim,init);
return anim;
};
})();
}
if(!dojo._hasResource["dijit._CssStateMixin"]){
dojo._hasResource["dijit._CssStateMixin"]=true;
dojo.provide("dijit._CssStateMixin");
dojo.declare("dijit._CssStateMixin",[],{cssStateNodes:{},hovering:false,active:false,_applyAttributes:function(){
this.inherited(arguments);
dojo.forEach(["onmouseenter","onmouseleave","onmousedown"],function(e){
this.connect(this.domNode,e,"_cssMouseEvent");
},this);
dojo.forEach(["disabled","readOnly","checked","selected","focused","state","hovering","active"],function(attr){
this.watch(attr,dojo.hitch(this,"_setStateClass"));
},this);
for(var ap in this.cssStateNodes){
this._trackMouseState(this[ap],this.cssStateNodes[ap]);
}
this._setStateClass();
},_cssMouseEvent:function(_362){
if(!this.disabled){
switch(_362.type){
case "mouseenter":
case "mouseover":
this._set("hovering",true);
this._set("active",this._mouseDown);
break;
case "mouseleave":
case "mouseout":
this._set("hovering",false);
this._set("active",false);
break;
case "mousedown":
this._set("active",true);
this._mouseDown=true;
var _363=this.connect(dojo.body(),"onmouseup",function(){
this._mouseDown=false;
this._set("active",false);
this.disconnect(_363);
});
break;
}
}
},_setStateClass:function(){
var _364=this.baseClass.split(" ");
function _365(_366){
_364=_364.concat(dojo.map(_364,function(c){
return c+_366;
}),"dijit"+_366);
};
if(!this.isLeftToRight()){
_365("Rtl");
}
if(this.checked){
_365("Checked");
}
if(this.state){
_365(this.state);
}
if(this.selected){
_365("Selected");
}
if(this.disabled){
_365("Disabled");
}else{
if(this.readOnly){
_365("ReadOnly");
}else{
if(this.active){
_365("Active");
}else{
if(this.hovering){
_365("Hover");
}
}
}
}
if(this._focused){
_365("Focused");
}
var tn=this.stateNode||this.domNode,_367={};
dojo.forEach(tn.className.split(" "),function(c){
_367[c]=true;
});
if("_stateClasses" in this){
dojo.forEach(this._stateClasses,function(c){
delete _367[c];
});
}
dojo.forEach(_364,function(c){
_367[c]=true;
});
var _368=[];
for(var c in _367){
_368.push(c);
}
tn.className=_368.join(" ");
this._stateClasses=_364;
},_trackMouseState:function(node,_369){
var _36a=false,_36b=false,_36c=false;
var self=this,cn=dojo.hitch(this,"connect",node);
function _36d(){
var _36e=("disabled" in self&&self.disabled)||("readonly" in self&&self.readonly);
dojo.toggleClass(node,_369+"Hover",_36a&&!_36b&&!_36e);
dojo.toggleClass(node,_369+"Active",_36b&&!_36e);
dojo.toggleClass(node,_369+"Focused",_36c&&!_36e);
};
cn("onmouseenter",function(){
_36a=true;
_36d();
});
cn("onmouseleave",function(){
_36a=false;
_36b=false;
_36d();
});
cn("onmousedown",function(){
_36b=true;
_36d();
});
cn("onmouseup",function(){
_36b=false;
_36d();
});
cn("onfocus",function(){
_36c=true;
_36d();
});
cn("onblur",function(){
_36c=false;
_36d();
});
this.watch("disabled",_36d);
this.watch("readOnly",_36d);
}});
}
if(!dojo._hasResource["dijit.form._FormMixin"]){
dojo._hasResource["dijit.form._FormMixin"]=true;
dojo.provide("dijit.form._FormMixin");
dojo.declare("dijit.form._FormMixin",null,{state:"",reset:function(){
dojo.forEach(this.getDescendants(),function(_36f){
if(_36f.reset){
_36f.reset();
}
});
},validate:function(){
var _370=false;
return dojo.every(dojo.map(this.getDescendants(),function(_371){
_371._hasBeenBlurred=true;
var _372=_371.disabled||!_371.validate||_371.validate();
if(!_372&&!_370){
dojo.window.scrollIntoView(_371.containerNode||_371.domNode);
_371.focus();
_370=true;
}
return _372;
}),function(item){
return item;
});
},setValues:function(val){
dojo.deprecated(this.declaredClass+"::setValues() is deprecated. Use set('value', val) instead.","","2.0");
return this.set("value",val);
},_setValueAttr:function(obj){
var map={};
dojo.forEach(this.getDescendants(),function(_373){
if(!_373.name){
return;
}
var _374=map[_373.name]||(map[_373.name]=[]);
_374.push(_373);
});
for(var name in map){
if(!map.hasOwnProperty(name)){
continue;
}
var _375=map[name],_376=dojo.getObject(name,false,obj);
if(_376===undefined){
continue;
}
if(!dojo.isArray(_376)){
_376=[_376];
}
if(typeof _375[0].checked=="boolean"){
dojo.forEach(_375,function(w,i){
w.set("value",dojo.indexOf(_376,w.value)!=-1);
});
}else{
if(_375[0].multiple){
_375[0].set("value",_376);
}else{
dojo.forEach(_375,function(w,i){
w.set("value",_376[i]);
});
}
}
}
},getValues:function(){
dojo.deprecated(this.declaredClass+"::getValues() is deprecated. Use get('value') instead.","","2.0");
return this.get("value");
},_getValueAttr:function(){
var obj={};
dojo.forEach(this.getDescendants(),function(_377){
var name=_377.name;
if(!name||_377.disabled){
return;
}
var _378=_377.get("value");
if(typeof _377.checked=="boolean"){
if(/Radio/.test(_377.declaredClass)){
if(_378!==false){
dojo.setObject(name,_378,obj);
}else{
_378=dojo.getObject(name,false,obj);
if(_378===undefined){
dojo.setObject(name,null,obj);
}
}
}else{
var ary=dojo.getObject(name,false,obj);
if(!ary){
ary=[];
dojo.setObject(name,ary,obj);
}
if(_378!==false){
ary.push(_378);
}
}
}else{
var prev=dojo.getObject(name,false,obj);
if(typeof prev!="undefined"){
if(dojo.isArray(prev)){
prev.push(_378);
}else{
dojo.setObject(name,[prev,_378],obj);
}
}else{
dojo.setObject(name,_378,obj);
}
}
});
return obj;
},isValid:function(){
return this.state=="";
},onValidStateChange:function(_379){
},_getState:function(){
var _37a=dojo.map(this._descendants,function(w){
return w.get("state")||"";
});
return dojo.indexOf(_37a,"Error")>=0?"Error":dojo.indexOf(_37a,"Incomplete")>=0?"Incomplete":"";
},disconnectChildren:function(){
dojo.forEach(this._childConnections||[],dojo.hitch(this,"disconnect"));
dojo.forEach(this._childWatches||[],function(w){
w.unwatch();
});
},connectChildren:function(_37b){
var _37c=this;
this.disconnectChildren();
this._descendants=this.getDescendants();
var set=_37b?function(name,val){
_37c[name]=val;
}:dojo.hitch(this,"_set");
set("value",this.get("value"));
set("state",this._getState());
var _37d=(this._childConnections=[]),_37e=(this._childWatches=[]);
dojo.forEach(dojo.filter(this._descendants,function(item){
return item.validate;
}),function(_37f){
dojo.forEach(["state","disabled"],function(attr){
_37e.push(_37f.watch(attr,function(attr,_380,_381){
_37c.set("state",_37c._getState());
}));
});
});
var _382=function(){
if(_37c._onChangeDelayTimer){
clearTimeout(_37c._onChangeDelayTimer);
}
_37c._onChangeDelayTimer=setTimeout(function(){
delete _37c._onChangeDelayTimer;
_37c._set("value",_37c.get("value"));
},10);
};
dojo.forEach(dojo.filter(this._descendants,function(item){
return item.onChange;
}),function(_383){
_37d.push(_37c.connect(_383,"onChange",_382));
_37e.push(_383.watch("disabled",_382));
});
},startup:function(){
this.inherited(arguments);
this.connectChildren(true);
this.watch("state",function(attr,_384,_385){
this.onValidStateChange(_385=="");
});
},destroy:function(){
this.disconnectChildren();
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit._DialogMixin"]){
dojo._hasResource["dijit._DialogMixin"]=true;
dojo.provide("dijit._DialogMixin");
dojo.declare("dijit._DialogMixin",null,{attributeMap:dijit._Widget.prototype.attributeMap,execute:function(_386){
},onCancel:function(){
},onExecute:function(){
},_onSubmit:function(){
this.onExecute();
this.execute(this.get("value"));
},_getFocusItems:function(){
var _387=dijit._getTabNavigable(this.containerNode);
this._firstFocusItem=_387.lowest||_387.first||this.closeButtonNode||this.domNode;
this._lastFocusItem=_387.last||_387.highest||this._firstFocusItem;
}});
}
if(!dojo._hasResource["dijit.DialogUnderlay"]){
dojo._hasResource["dijit.DialogUnderlay"]=true;
dojo.provide("dijit.DialogUnderlay");
dojo.declare("dijit.DialogUnderlay",[dijit._Widget,dijit._Templated],{templateString:"<div class='dijitDialogUnderlayWrapper'><div class='dijitDialogUnderlay' dojoAttachPoint='node'></div></div>",dialogId:"","class":"",attributeMap:{id:"domNode"},_setDialogIdAttr:function(id){
dojo.attr(this.node,"id",id+"_underlay");
this._set("dialogId",id);
},_setClassAttr:function(_388){
this.node.className="dijitDialogUnderlay "+_388;
this._set("class",_388);
},postCreate:function(){
dojo.body().appendChild(this.domNode);
},layout:function(){
var is=this.node.style,os=this.domNode.style;
os.display="none";
var _389=dojo.window.getBox();
os.top=_389.t+"px";
os.left=_389.l+"px";
is.width=_389.w+"px";
is.height=_389.h+"px";
os.display="block";
},show:function(){
this.domNode.style.display="block";
this.layout();
this.bgIframe=new dijit.BackgroundIframe(this.domNode);
},hide:function(){
this.bgIframe.destroy();
delete this.bgIframe;
this.domNode.style.display="none";
}});
}
if(!dojo._hasResource["dijit._Contained"]){
dojo._hasResource["dijit._Contained"]=true;
dojo.provide("dijit._Contained");
dojo.declare("dijit._Contained",null,{getParent:function(){
var _38a=dijit.getEnclosingWidget(this.domNode.parentNode);
return _38a&&_38a.isContainer?_38a:null;
},_getSibling:function(_38b){
var node=this.domNode;
do{
node=node[_38b+"Sibling"];
}while(node&&node.nodeType!=1);
return node&&dijit.byNode(node);
},getPreviousSibling:function(){
return this._getSibling("previous");
},getNextSibling:function(){
return this._getSibling("next");
},getIndexInParent:function(){
var p=this.getParent();
if(!p||!p.getIndexOfChild){
return -1;
}
return p.getIndexOfChild(this);
}});
}
if(!dojo._hasResource["dijit._Container"]){
dojo._hasResource["dijit._Container"]=true;
dojo.provide("dijit._Container");
dojo.declare("dijit._Container",null,{isContainer:true,buildRendering:function(){
this.inherited(arguments);
if(!this.containerNode){
this.containerNode=this.domNode;
}
},addChild:function(_38c,_38d){
var _38e=this.containerNode;
if(_38d&&typeof _38d=="number"){
var _38f=this.getChildren();
if(_38f&&_38f.length>=_38d){
_38e=_38f[_38d-1].domNode;
_38d="after";
}
}
dojo.place(_38c.domNode,_38e,_38d);
if(this._started&&!_38c._started){
_38c.startup();
}
},removeChild:function(_390){
if(typeof _390=="number"){
_390=this.getChildren()[_390];
}
if(_390){
var node=_390.domNode;
if(node&&node.parentNode){
node.parentNode.removeChild(node);
}
}
},hasChildren:function(){
return this.getChildren().length>0;
},destroyDescendants:function(_391){
dojo.forEach(this.getChildren(),function(_392){
_392.destroyRecursive(_391);
});
},_getSiblingOfChild:function(_393,dir){
var node=_393.domNode,_394=(dir>0?"nextSibling":"previousSibling");
do{
node=node[_394];
}while(node&&(node.nodeType!=1||!dijit.byNode(node)));
return node&&dijit.byNode(node);
},getIndexOfChild:function(_395){
return dojo.indexOf(this.getChildren(),_395);
},startup:function(){
if(this._started){
return;
}
dojo.forEach(this.getChildren(),function(_396){
_396.startup();
});
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.layout._LayoutWidget"]){
dojo._hasResource["dijit.layout._LayoutWidget"]=true;
dojo.provide("dijit.layout._LayoutWidget");
dojo.declare("dijit.layout._LayoutWidget",[dijit._Widget,dijit._Container,dijit._Contained],{baseClass:"dijitLayoutContainer",isLayoutContainer:true,buildRendering:function(){
this.inherited(arguments);
dojo.addClass(this.domNode,"dijitContainer");
},startup:function(){
if(this._started){
return;
}
this.inherited(arguments);
var _397=this.getParent&&this.getParent();
if(!(_397&&_397.isLayoutContainer)){
this.resize();
this.connect(dojo.isIE?this.domNode:dojo.global,"onresize",function(){
this.resize();
});
}
},resize:function(_398,_399){
var node=this.domNode;
if(_398){
dojo.marginBox(node,_398);
if(_398.t){
node.style.top=_398.t+"px";
}
if(_398.l){
node.style.left=_398.l+"px";
}
}
var mb=_399||{};
dojo.mixin(mb,_398||{});
if(!("h" in mb)||!("w" in mb)){
mb=dojo.mixin(dojo.marginBox(node),mb);
}
var cs=dojo.getComputedStyle(node);
var me=dojo._getMarginExtents(node,cs);
var be=dojo._getBorderExtents(node,cs);
var bb=(this._borderBox={w:mb.w-(me.w+be.w),h:mb.h-(me.h+be.h)});
var pe=dojo._getPadExtents(node,cs);
this._contentBox={l:dojo._toPixelValue(node,cs.paddingLeft),t:dojo._toPixelValue(node,cs.paddingTop),w:bb.w-pe.w,h:bb.h-pe.h};
this.layout();
},layout:function(){
},_setupChild:function(_39a){
var cls=this.baseClass+"-child "+(_39a.baseClass?this.baseClass+"-"+_39a.baseClass:"");
dojo.addClass(_39a.domNode,cls);
},addChild:function(_39b,_39c){
this.inherited(arguments);
if(this._started){
this._setupChild(_39b);
}
},removeChild:function(_39d){
var cls=this.baseClass+"-child"+(_39d.baseClass?" "+this.baseClass+"-"+_39d.baseClass:"");
dojo.removeClass(_39d.domNode,cls);
this.inherited(arguments);
}});
dijit.layout.marginBox2contentBox=function(node,mb){
var cs=dojo.getComputedStyle(node);
var me=dojo._getMarginExtents(node,cs);
var pb=dojo._getPadBorderExtents(node,cs);
return {l:dojo._toPixelValue(node,cs.paddingLeft),t:dojo._toPixelValue(node,cs.paddingTop),w:mb.w-(me.w+pb.w),h:mb.h-(me.h+pb.h)};
};
(function(){
var _39e=function(word){
return word.substring(0,1).toUpperCase()+word.substring(1);
};
var size=function(_39f,dim){
var _3a0=_39f.resize?_39f.resize(dim):dojo.marginBox(_39f.domNode,dim);
if(_3a0){
dojo.mixin(_39f,_3a0);
}else{
dojo.mixin(_39f,dojo.marginBox(_39f.domNode));
dojo.mixin(_39f,dim);
}
};
dijit.layout.layoutChildren=function(_3a1,dim,_3a2,_3a3,_3a4){
dim=dojo.mixin({},dim);
dojo.addClass(_3a1,"dijitLayoutContainer");
_3a2=dojo.filter(_3a2,function(item){
return item.region!="center"&&item.layoutAlign!="client";
}).concat(dojo.filter(_3a2,function(item){
return item.region=="center"||item.layoutAlign=="client";
}));
dojo.forEach(_3a2,function(_3a5){
var elm=_3a5.domNode,pos=(_3a5.region||_3a5.layoutAlign);
var _3a6=elm.style;
_3a6.left=dim.l+"px";
_3a6.top=dim.t+"px";
_3a6.position="absolute";
dojo.addClass(elm,"dijitAlign"+_39e(pos));
var _3a7={};
if(_3a3&&_3a3==_3a5.id){
_3a7[_3a5.region=="top"||_3a5.region=="bottom"?"h":"w"]=_3a4;
}
if(pos=="top"||pos=="bottom"){
_3a7.w=dim.w;
size(_3a5,_3a7);
dim.h-=_3a5.h;
if(pos=="top"){
dim.t+=_3a5.h;
}else{
_3a6.top=dim.t+dim.h+"px";
}
}else{
if(pos=="left"||pos=="right"){
_3a7.h=dim.h;
size(_3a5,_3a7);
dim.w-=_3a5.w;
if(pos=="left"){
dim.l+=_3a5.w;
}else{
_3a6.left=dim.l+dim.w+"px";
}
}else{
if(pos=="client"||pos=="center"){
size(_3a5,dim);
}
}
}
});
};
})();
}
if(!dojo._hasResource["dijit.layout._ContentPaneResizeMixin"]){
dojo._hasResource["dijit.layout._ContentPaneResizeMixin"]=true;
dojo.provide("dijit.layout._ContentPaneResizeMixin");
dojo.declare("dijit.layout._ContentPaneResizeMixin",null,{doLayout:true,isContainer:true,isLayoutContainer:true,_startChildren:function(){
dojo.forEach(this.getChildren(),function(_3a8){
_3a8.startup();
_3a8._started=true;
});
},startup:function(){
if(this._started){
return;
}
var _3a9=dijit._Contained.prototype.getParent.call(this);
this._childOfLayoutWidget=_3a9&&_3a9.isLayoutContainer;
this._needLayout=!this._childOfLayoutWidget;
this.inherited(arguments);
this._startChildren();
if(this._isShown()){
this._onShow();
}
if(!this._childOfLayoutWidget){
this.connect(dojo.isIE?this.domNode:dojo.global,"onresize",function(){
this._needLayout=!this._childOfLayoutWidget;
this.resize();
});
}
},_checkIfSingleChild:function(){
var _3aa=dojo.query("> *",this.containerNode).filter(function(node){
return node.tagName!=="SCRIPT";
}),_3ab=_3aa.filter(function(node){
return dojo.hasAttr(node,"data-dojo-type")||dojo.hasAttr(node,"dojoType")||dojo.hasAttr(node,"widgetId");
}),_3ac=dojo.filter(_3ab.map(dijit.byNode),function(_3ad){
return _3ad&&_3ad.domNode&&_3ad.resize;
});
if(_3aa.length==_3ab.length&&_3ac.length==1){
this._singleChild=_3ac[0];
}else{
delete this._singleChild;
}
dojo.toggleClass(this.containerNode,this.baseClass+"SingleChild",!!this._singleChild);
},resize:function(_3ae,_3af){
if(!this._wasShown&&this.open!==false){
this._onShow();
}
this._resizeCalled=true;
this._scheduleLayout(_3ae,_3af);
},_scheduleLayout:function(_3b0,_3b1){
if(this._isShown()){
this._layout(_3b0,_3b1);
}else{
this._needLayout=true;
this._changeSize=_3b0;
this._resultSize=_3b1;
}
},_layout:function(_3b2,_3b3){
if(_3b2){
dojo.marginBox(this.domNode,_3b2);
}
var cn=this.containerNode;
if(cn===this.domNode){
var mb=_3b3||{};
dojo.mixin(mb,_3b2||{});
if(!("h" in mb)||!("w" in mb)){
mb=dojo.mixin(dojo.marginBox(cn),mb);
}
this._contentBox=dijit.layout.marginBox2contentBox(cn,mb);
}else{
this._contentBox=dojo.contentBox(cn);
}
this._layoutChildren();
delete this._needLayout;
},_layoutChildren:function(){
if(this.doLayout){
this._checkIfSingleChild();
}
if(this._singleChild&&this._singleChild.resize){
var cb=this._contentBox||dojo.contentBox(this.containerNode);
this._singleChild.resize({w:cb.w,h:cb.h});
}else{
dojo.forEach(this.getChildren(),function(_3b4){
if(_3b4.resize){
_3b4.resize();
}
});
}
},_isShown:function(){
if(this._childOfLayoutWidget){
if(this._resizeCalled&&"open" in this){
return this.open;
}
return this._resizeCalled;
}else{
if("open" in this){
return this.open;
}else{
var node=this.domNode,_3b5=this.domNode.parentNode;
return (node.style.display!="none")&&(node.style.visibility!="hidden")&&!dojo.hasClass(node,"dijitHidden")&&_3b5&&_3b5.style&&(_3b5.style.display!="none");
}
}
},_onShow:function(){
if(this._needLayout){
this._layout(this._changeSize,this._resultSize);
}
this.inherited(arguments);
this._wasShown=true;
}});
}
if(!dojo._hasResource["dojo.html"]){
dojo._hasResource["dojo.html"]=true;
dojo.provide("dojo.html");
dojo.getObject("html",true,dojo);
(function(){
var _3b6=0,d=dojo;
dojo.html._secureForInnerHtml=function(cont){
return cont.replace(/(?:\s*<!DOCTYPE\s[^>]+>|<title[^>]*>[\s\S]*?<\/title>)/ig,"");
};
dojo.html._emptyNode=dojo.empty;
dojo.html._setNodeContent=function(node,cont){
d.empty(node);
if(cont){
if(typeof cont=="string"){
cont=d._toDom(cont,node.ownerDocument);
}
if(!cont.nodeType&&d.isArrayLike(cont)){
for(var _3b7=cont.length,i=0;i<cont.length;i=_3b7==cont.length?i+1:0){
d.place(cont[i],node,"last");
}
}else{
d.place(cont,node,"last");
}
}
return node;
};
dojo.declare("dojo.html._ContentSetter",null,{node:"",content:"",id:"",cleanContent:false,extractContent:false,parseContent:false,parserScope:dojo._scopeName,startup:true,constructor:function(_3b8,node){
dojo.mixin(this,_3b8||{});
node=this.node=dojo.byId(this.node||node);
if(!this.id){
this.id=["Setter",(node)?node.id||node.tagName:"",_3b6++].join("_");
}
},set:function(cont,_3b9){
if(undefined!==cont){
this.content=cont;
}
if(_3b9){
this._mixin(_3b9);
}
this.onBegin();
this.setContent();
this.onEnd();
return this.node;
},setContent:function(){
var node=this.node;
if(!node){
throw new Error(this.declaredClass+": setContent given no node");
}
try{
node=dojo.html._setNodeContent(node,this.content);
}
catch(e){
var _3ba=this.onContentError(e);
try{
node.innerHTML=_3ba;
}
catch(e){
console.error("Fatal "+this.declaredClass+".setContent could not change content due to "+e.message,e);
}
}
this.node=node;
},empty:function(){
if(this.parseResults&&this.parseResults.length){
dojo.forEach(this.parseResults,function(w){
if(w.destroy){
w.destroy();
}
});
delete this.parseResults;
}
dojo.html._emptyNode(this.node);
},onBegin:function(){
var cont=this.content;
if(dojo.isString(cont)){
if(this.cleanContent){
cont=dojo.html._secureForInnerHtml(cont);
}
if(this.extractContent){
var _3bb=cont.match(/<body[^>]*>\s*([\s\S]+)\s*<\/body>/im);
if(_3bb){
cont=_3bb[1];
}
}
}
this.empty();
this.content=cont;
return this.node;
},onEnd:function(){
if(this.parseContent){
this._parse();
}
return this.node;
},tearDown:function(){
delete this.parseResults;
delete this.node;
delete this.content;
},onContentError:function(err){
return "Error occured setting content: "+err;
},_mixin:function(_3bc){
var _3bd={},key;
for(key in _3bc){
if(key in _3bd){
continue;
}
this[key]=_3bc[key];
}
},_parse:function(){
var _3be=this.node;
try{
var _3bf={};
dojo.forEach(["dir","lang","textDir"],function(name){
if(this[name]){
_3bf[name]=this[name];
}
},this);
this.parseResults=dojo.parser.parse({rootNode:_3be,noStart:!this.startup,inherited:_3bf,scope:this.parserScope});
}
catch(e){
this._onError("Content",e,"Error parsing in _ContentSetter#"+this.id);
}
},_onError:function(type,err,_3c0){
var _3c1=this["on"+type+"Error"].call(this,err);
if(_3c0){
console.error(_3c0,err);
}else{
if(_3c1){
dojo.html._setNodeContent(this.node,_3c1,true);
}
}
}});
dojo.html.set=function(node,cont,_3c2){
if(undefined==cont){
console.warn("dojo.html.set: no cont argument provided, using empty string");
cont="";
}
if(!_3c2){
return dojo.html._setNodeContent(node,cont,true);
}else{
var op=new dojo.html._ContentSetter(dojo.mixin(_3c2,{content:cont,node:node}));
return op.set();
}
};
})();
}
if(!dojo._hasResource["dijit.layout.ContentPane"]){
dojo._hasResource["dijit.layout.ContentPane"]=true;
dojo.provide("dijit.layout.ContentPane");
dojo.declare("dijit.layout.ContentPane",[dijit._Widget,dijit.layout._ContentPaneResizeMixin],{href:"",extractContent:false,parseOnLoad:true,parserScope:dojo._scopeName,preventCache:false,preload:false,refreshOnShow:false,loadingMessage:"<span class='dijitContentPaneLoading'>${loadingState}</span>",errorMessage:"<span class='dijitContentPaneError'>${errorState}</span>",isLoaded:false,baseClass:"dijitContentPane",ioArgs:{},onLoadDeferred:null,attributeMap:dojo.delegate(dijit._Widget.prototype.attributeMap,{title:[]}),stopParser:true,template:false,create:function(_3c3,_3c4){
if((!_3c3||!_3c3.template)&&_3c4&&!("href" in _3c3)&&!("content" in _3c3)){
var df=dojo.doc.createDocumentFragment();
_3c4=dojo.byId(_3c4);
while(_3c4.firstChild){
df.appendChild(_3c4.firstChild);
}
_3c3=dojo.delegate(_3c3,{content:df});
}
this.inherited(arguments,[_3c3,_3c4]);
},postMixInProperties:function(){
this.inherited(arguments);
var _3c5=dojo.i18n.getLocalization("dijit","loading",this.lang);
this.loadingMessage=dojo.string.substitute(this.loadingMessage,_3c5);
this.errorMessage=dojo.string.substitute(this.errorMessage,_3c5);
},buildRendering:function(){
this.inherited(arguments);
if(!this.containerNode){
this.containerNode=this.domNode;
}
this.domNode.title="";
if(!dojo.attr(this.domNode,"role")){
dijit.setWaiRole(this.domNode,"group");
}
},_startChildren:function(){
this.inherited(arguments);
if(this._contentSetter){
dojo.forEach(this._contentSetter.parseResults,function(obj){
if(!obj._started&&!obj._destroyed&&dojo.isFunction(obj.startup)){
obj.startup();
obj._started=true;
}
},this);
}
},setHref:function(href){
dojo.deprecated("dijit.layout.ContentPane.setHref() is deprecated. Use set('href', ...) instead.","","2.0");
return this.set("href",href);
},_setHrefAttr:function(href){
this.cancel();
this.onLoadDeferred=new dojo.Deferred(dojo.hitch(this,"cancel"));
this.onLoadDeferred.addCallback(dojo.hitch(this,"onLoad"));
this._set("href",href);
if(this.preload||(this._created&&this._isShown())){
this._load();
}else{
this._hrefChanged=true;
}
return this.onLoadDeferred;
},setContent:function(data){
dojo.deprecated("dijit.layout.ContentPane.setContent() is deprecated.  Use set('content', ...) instead.","","2.0");
this.set("content",data);
},_setContentAttr:function(data){
this._set("href","");
this.cancel();
this.onLoadDeferred=new dojo.Deferred(dojo.hitch(this,"cancel"));
if(this._created){
this.onLoadDeferred.addCallback(dojo.hitch(this,"onLoad"));
}
this._setContent(data||"");
this._isDownloaded=false;
return this.onLoadDeferred;
},_getContentAttr:function(){
return this.containerNode.innerHTML;
},cancel:function(){
if(this._xhrDfd&&(this._xhrDfd.fired==-1)){
this._xhrDfd.cancel();
}
delete this._xhrDfd;
this.onLoadDeferred=null;
},uninitialize:function(){
if(this._beingDestroyed){
this.cancel();
}
this.inherited(arguments);
},destroyRecursive:function(_3c6){
if(this._beingDestroyed){
return;
}
this.inherited(arguments);
},_onShow:function(){
this.inherited(arguments);
if(this.href){
if(!this._xhrDfd&&(!this.isLoaded||this._hrefChanged||this.refreshOnShow)){
return this.refresh();
}
}
},refresh:function(){
this.cancel();
this.onLoadDeferred=new dojo.Deferred(dojo.hitch(this,"cancel"));
this.onLoadDeferred.addCallback(dojo.hitch(this,"onLoad"));
this._load();
return this.onLoadDeferred;
},_load:function(){
this._setContent(this.onDownloadStart(),true);
var self=this;
var _3c7={preventCache:(this.preventCache||this.refreshOnShow),url:this.href,handleAs:"text"};
if(dojo.isObject(this.ioArgs)){
dojo.mixin(_3c7,this.ioArgs);
}
var hand=(this._xhrDfd=(this.ioMethod||dojo.xhrGet)(_3c7));
hand.addCallback(function(html){
try{
self._isDownloaded=true;
self._setContent(html,false);
self.onDownloadEnd();
}
catch(err){
self._onError("Content",err);
}
delete self._xhrDfd;
return html;
});
hand.addErrback(function(err){
if(!hand.canceled){
self._onError("Download",err);
}
delete self._xhrDfd;
return err;
});
delete this._hrefChanged;
},_onLoadHandler:function(data){
this._set("isLoaded",true);
try{
this.onLoadDeferred.callback(data);
}
catch(e){
console.error("Error "+this.widgetId+" running custom onLoad code: "+e.message);
}
},_onUnloadHandler:function(){
this._set("isLoaded",false);
try{
this.onUnload();
}
catch(e){
console.error("Error "+this.widgetId+" running custom onUnload code: "+e.message);
}
},destroyDescendants:function(){
if(this.isLoaded){
this._onUnloadHandler();
}
var _3c8=this._contentSetter;
dojo.forEach(this.getChildren(),function(_3c9){
if(_3c9.destroyRecursive){
_3c9.destroyRecursive();
}
});
if(_3c8){
dojo.forEach(_3c8.parseResults,function(_3ca){
if(_3ca.destroyRecursive&&_3ca.domNode&&_3ca.domNode.parentNode==dojo.body()){
_3ca.destroyRecursive();
}
});
delete _3c8.parseResults;
}
dojo.html._emptyNode(this.containerNode);
delete this._singleChild;
},_setContent:function(cont,_3cb){
this.destroyDescendants();
var _3cc=this._contentSetter;
if(!(_3cc&&_3cc instanceof dojo.html._ContentSetter)){
_3cc=this._contentSetter=new dojo.html._ContentSetter({node:this.containerNode,_onError:dojo.hitch(this,this._onError),onContentError:dojo.hitch(this,function(e){
var _3cd=this.onContentError(e);
try{
this.containerNode.innerHTML=_3cd;
}
catch(e){
console.error("Fatal "+this.id+" could not change content due to "+e.message,e);
}
})});
}
var _3ce=dojo.mixin({cleanContent:this.cleanContent,extractContent:this.extractContent,parseContent:this.parseOnLoad,parserScope:this.parserScope,startup:false,dir:this.dir,lang:this.lang},this._contentSetterParams||{});
_3cc.set((dojo.isObject(cont)&&cont.domNode)?cont.domNode:cont,_3ce);
delete this._contentSetterParams;
if(this.doLayout){
this._checkIfSingleChild();
}
if(!_3cb){
if(this._started){
this._startChildren();
this._scheduleLayout();
}
this._onLoadHandler(cont);
}
},_onError:function(type,err,_3cf){
this.onLoadDeferred.errback(err);
var _3d0=this["on"+type+"Error"].call(this,err);
if(_3cf){
console.error(_3cf,err);
}else{
if(_3d0){
this._setContent(_3d0,true);
}
}
},onLoad:function(data){
},onUnload:function(){
},onDownloadStart:function(){
return this.loadingMessage;
},onContentError:function(_3d1){
},onDownloadError:function(_3d2){
return this.errorMessage;
},onDownloadEnd:function(){
}});
}
if(!dojo._hasResource["dijit.TooltipDialog"]){
dojo._hasResource["dijit.TooltipDialog"]=true;
dojo.provide("dijit.TooltipDialog");
dojo.declare("dijit.TooltipDialog",[dijit.layout.ContentPane,dijit._Templated,dijit.form._FormMixin,dijit._DialogMixin],{title:"",doLayout:false,autofocus:true,baseClass:"dijitTooltipDialog",_firstFocusItem:null,_lastFocusItem:null,templateString:dojo.cache("dijit","templates/TooltipDialog.html","<div role=\"presentation\" tabIndex=\"-1\">\r\n\t<div class=\"dijitTooltipContainer\" role=\"presentation\">\r\n\t\t<div class =\"dijitTooltipContents dijitTooltipFocusNode\" dojoAttachPoint=\"containerNode\" role=\"dialog\"></div>\r\n\t</div>\r\n\t<div class=\"dijitTooltipConnector\" role=\"presentation\"></div>\r\n</div>\r\n"),_setTitleAttr:function(_3d3){
this.containerNode.title=_3d3;
this._set("title",_3d3);
},postCreate:function(){
this.inherited(arguments);
this.connect(this.containerNode,"onkeypress","_onKey");
},orient:function(node,_3d4,_3d5){
var newC="dijitTooltipAB"+(_3d5.charAt(1)=="L"?"Left":"Right")+" dijitTooltip"+(_3d5.charAt(0)=="T"?"Below":"Above");
dojo.replaceClass(this.domNode,newC,this._currentOrientClass||"");
this._currentOrientClass=newC;
},focus:function(){
this._getFocusItems(this.containerNode);
dijit.focus(this._firstFocusItem);
},onOpen:function(pos){
this.orient(this.domNode,pos.aroundCorner,pos.corner);
this._onShow();
},onClose:function(){
this.onHide();
},_onKey:function(evt){
var node=evt.target;
var dk=dojo.keys;
if(evt.charOrCode===dk.TAB){
this._getFocusItems(this.containerNode);
}
var _3d6=(this._firstFocusItem==this._lastFocusItem);
if(evt.charOrCode==dk.ESCAPE){
setTimeout(dojo.hitch(this,"onCancel"),0);
dojo.stopEvent(evt);
}else{
if(node==this._firstFocusItem&&evt.shiftKey&&evt.charOrCode===dk.TAB){
if(!_3d6){
dijit.focus(this._lastFocusItem);
}
dojo.stopEvent(evt);
}else{
if(node==this._lastFocusItem&&evt.charOrCode===dk.TAB&&!evt.shiftKey){
if(!_3d6){
dijit.focus(this._firstFocusItem);
}
dojo.stopEvent(evt);
}else{
if(evt.charOrCode===dk.TAB){
evt.stopPropagation();
}
}
}
}
}});
}
if(!dojo._hasResource["dijit.Dialog"]){
dojo._hasResource["dijit.Dialog"]=true;
dojo.provide("dijit.Dialog");
dojo.declare("dijit._DialogBase",[dijit._Templated,dijit.form._FormMixin,dijit._DialogMixin,dijit._CssStateMixin],{templateString:dojo.cache("dijit","templates/Dialog.html","<div class=\"dijitDialog\" role=\"dialog\" aria-labelledby=\"${id}_title\">\r\n\t<div dojoAttachPoint=\"titleBar\" class=\"dijitDialogTitleBar\">\r\n\t<span dojoAttachPoint=\"titleNode\" class=\"dijitDialogTitle\" id=\"${id}_title\"></span>\r\n\t<span dojoAttachPoint=\"closeButtonNode\" class=\"dijitDialogCloseIcon\" dojoAttachEvent=\"ondijitclick: onCancel\" title=\"${buttonCancel}\" role=\"button\" tabIndex=\"-1\">\r\n\t\t<span dojoAttachPoint=\"closeText\" class=\"closeText\" title=\"${buttonCancel}\">x</span>\r\n\t</span>\r\n\t</div>\r\n\t\t<div dojoAttachPoint=\"containerNode\" class=\"dijitDialogPaneContent\"></div>\r\n</div>\r\n"),baseClass:"dijitDialog",cssStateNodes:{closeButtonNode:"dijitDialogCloseIcon"},attributeMap:dojo.delegate(dijit._Widget.prototype.attributeMap,{title:[{node:"titleNode",type:"innerHTML"},{node:"titleBar",type:"attribute"}],"aria-describedby":""}),open:false,duration:dijit.defaultDuration,refocus:true,autofocus:true,_firstFocusItem:null,_lastFocusItem:null,doLayout:false,draggable:true,"aria-describedby":"",postMixInProperties:function(){
var _3d7=dojo.i18n.getLocalization("dijit","common");
dojo.mixin(this,_3d7);
this.inherited(arguments);
},postCreate:function(){
dojo.style(this.domNode,{display:"none",position:"absolute"});
dojo.body().appendChild(this.domNode);
this.inherited(arguments);
this.connect(this,"onExecute","hide");
this.connect(this,"onCancel","hide");
this._modalconnects=[];
},onLoad:function(){
this._position();
if(this.autofocus&&dijit._DialogLevelManager.isTop(this)){
this._getFocusItems(this.domNode);
dijit.focus(this._firstFocusItem);
}
this.inherited(arguments);
},_endDrag:function(){
var _3d8=dojo.position(this.domNode),_3d9=dojo.window.getBox();
_3d8.y=Math.min(Math.max(_3d8.y,0),(_3d9.h-_3d8.h));
_3d8.x=Math.min(Math.max(_3d8.x,0),(_3d9.w-_3d8.w));
this._relativePosition=_3d8;
this._position();
},_setup:function(){
var node=this.domNode;
if(this.titleBar&&this.draggable){
this._moveable=(dojo.isIE==6)?new dojo.dnd.TimedMoveable(node,{handle:this.titleBar}):new dojo.dnd.Moveable(node,{handle:this.titleBar,timeout:0});
this.connect(this._moveable,"onMoveStop","_endDrag");
}else{
dojo.addClass(node,"dijitDialogFixed");
}
this.underlayAttrs={dialogId:this.id,"class":dojo.map(this["class"].split(/\s/),function(s){
return s+"_underlay";
}).join(" ")};
},_size:function(){
this._checkIfSingleChild();
if(this._singleChild){
if(this._singleChildOriginalStyle){
this._singleChild.domNode.style.cssText=this._singleChildOriginalStyle;
}
delete this._singleChildOriginalStyle;
}else{
dojo.style(this.containerNode,{width:"auto",height:"auto"});
}
var mb=dojo._getMarginSize(this.domNode);
var _3da=dojo.window.getBox();
if(mb.w>=_3da.w||mb.h>=_3da.h){
var w=Math.min(mb.w,Math.floor(_3da.w*0.75)),h=Math.min(mb.h,Math.floor(_3da.h*0.75));
if(this._singleChild&&this._singleChild.resize){
this._singleChildOriginalStyle=this._singleChild.domNode.style.cssText;
this._singleChild.resize({w:w,h:h});
}else{
dojo.style(this.containerNode,{width:w+"px",height:h+"px",overflow:"auto",position:"relative"});
}
}else{
if(this._singleChild&&this._singleChild.resize){
this._singleChild.resize();
}
}
},_position:function(){
if(!dojo.hasClass(dojo.body(),"dojoMove")){
var node=this.domNode,_3db=dojo.window.getBox(),p=this._relativePosition,bb=p?null:dojo._getBorderBox(node),l=Math.floor(_3db.l+(p?p.x:(_3db.w-bb.w)/2)),t=Math.floor(_3db.t+(p?p.y:(_3db.h-bb.h)/2));
dojo.style(node,{left:l+"px",top:t+"px"});
}
},_onKey:function(evt){
if(evt.charOrCode){
var dk=dojo.keys;
var node=evt.target;
if(evt.charOrCode===dk.TAB){
this._getFocusItems(this.domNode);
}
var _3dc=(this._firstFocusItem==this._lastFocusItem);
if(node==this._firstFocusItem&&evt.shiftKey&&evt.charOrCode===dk.TAB){
if(!_3dc){
dijit.focus(this._lastFocusItem);
}
dojo.stopEvent(evt);
}else{
if(node==this._lastFocusItem&&evt.charOrCode===dk.TAB&&!evt.shiftKey){
if(!_3dc){
dijit.focus(this._firstFocusItem);
}
dojo.stopEvent(evt);
}else{
while(node){
if(node==this.domNode||dojo.hasClass(node,"dijitPopup")){
if(evt.charOrCode==dk.ESCAPE){
this.onCancel();
}else{
return;
}
}
node=node.parentNode;
}
if(evt.charOrCode!==dk.TAB){
dojo.stopEvent(evt);
}else{
if(!dojo.isOpera){
try{
this._firstFocusItem.focus();
}
catch(e){
}
}
}
}
}
}
},show:function(){
if(this.open){
return;
}
if(!this._started){
this.startup();
}
if(!this._alreadyInitialized){
this._setup();
this._alreadyInitialized=true;
}
if(this._fadeOutDeferred){
this._fadeOutDeferred.cancel();
}
this._modalconnects.push(dojo.connect(window,"onscroll",this,"layout"));
this._modalconnects.push(dojo.connect(window,"onresize",this,function(){
var _3dd=dojo.window.getBox();
if(!this._oldViewport||_3dd.h!=this._oldViewport.h||_3dd.w!=this._oldViewport.w){
this.layout();
this._oldViewport=_3dd;
}
}));
this._modalconnects.push(dojo.connect(this.domNode,"onkeypress",this,"_onKey"));
dojo.style(this.domNode,{opacity:0,display:""});
this._set("open",true);
this._onShow();
this._size();
this._position();
var _3de;
this._fadeInDeferred=new dojo.Deferred(dojo.hitch(this,function(){
_3de.stop();
delete this._fadeInDeferred;
}));
_3de=dojo.fadeIn({node:this.domNode,duration:this.duration,beforeBegin:dojo.hitch(this,function(){
dijit._DialogLevelManager.show(this,this.underlayAttrs);
}),onEnd:dojo.hitch(this,function(){
if(this.autofocus&&dijit._DialogLevelManager.isTop(this)){
this._getFocusItems(this.domNode);
dijit.focus(this._firstFocusItem);
}
this._fadeInDeferred.callback(true);
delete this._fadeInDeferred;
})}).play();
return this._fadeInDeferred;
},hide:function(){
if(!this._alreadyInitialized){
return;
}
if(this._fadeInDeferred){
this._fadeInDeferred.cancel();
}
var _3df;
this._fadeOutDeferred=new dojo.Deferred(dojo.hitch(this,function(){
_3df.stop();
delete this._fadeOutDeferred;
}));
_3df=dojo.fadeOut({node:this.domNode,duration:this.duration,onEnd:dojo.hitch(this,function(){
this.domNode.style.display="none";
dijit._DialogLevelManager.hide(this);
this.onHide();
this._fadeOutDeferred.callback(true);
delete this._fadeOutDeferred;
})}).play();
if(this._scrollConnected){
this._scrollConnected=false;
}
dojo.forEach(this._modalconnects,dojo.disconnect);
this._modalconnects=[];
if(this._relativePosition){
delete this._relativePosition;
}
this._set("open",false);
return this._fadeOutDeferred;
},layout:function(){
if(this.domNode.style.display!="none"){
if(dijit._underlay){
dijit._underlay.layout();
}
this._position();
}
},destroy:function(){
if(this._fadeInDeferred){
this._fadeInDeferred.cancel();
}
if(this._fadeOutDeferred){
this._fadeOutDeferred.cancel();
}
if(this._moveable){
this._moveable.destroy();
}
dojo.forEach(this._modalconnects,dojo.disconnect);
dijit._DialogLevelManager.hide(this);
this.inherited(arguments);
}});
dojo.declare("dijit.Dialog",[dijit.layout.ContentPane,dijit._DialogBase],{});
dijit._DialogLevelManager={show:function(_3e0,_3e1){
var ds=dijit._dialogStack;
ds[ds.length-1].focus=dijit.getFocus(_3e0);
var _3e2=dijit._underlay;
if(!_3e2||_3e2._destroyed){
_3e2=dijit._underlay=new dijit.DialogUnderlay(_3e1);
}else{
_3e2.set(_3e0.underlayAttrs);
}
var _3e3=ds[ds.length-1].dialog?ds[ds.length-1].zIndex+2:950;
if(ds.length==1){
_3e2.show();
}
dojo.style(dijit._underlay.domNode,"zIndex",_3e3-1);
dojo.style(_3e0.domNode,"zIndex",_3e3);
ds.push({dialog:_3e0,underlayAttrs:_3e1,zIndex:_3e3});
},hide:function(_3e4){
var ds=dijit._dialogStack;
if(ds[ds.length-1].dialog==_3e4){
ds.pop();
var pd=ds[ds.length-1];
if(ds.length==1){
if(!dijit._underlay._destroyed){
dijit._underlay.hide();
}
}else{
dojo.style(dijit._underlay.domNode,"zIndex",pd.zIndex-1);
dijit._underlay.set(pd.underlayAttrs);
}
if(_3e4.refocus){
var _3e5=pd.focus;
if(!_3e5||(pd.dialog&&!dojo.isDescendant(_3e5.node,pd.dialog.domNode))){
pd.dialog._getFocusItems(pd.dialog.domNode);
_3e5=pd.dialog._firstFocusItem;
}
try{
dijit.focus(_3e5);
}
catch(e){
}
}
}else{
var idx=dojo.indexOf(dojo.map(ds,function(elem){
return elem.dialog;
}),_3e4);
if(idx!=-1){
ds.splice(idx,1);
}
}
},isTop:function(_3e6){
var ds=dijit._dialogStack;
return ds[ds.length-1].dialog==_3e6;
}};
dijit._dialogStack=[{dialog:null,focus:null,underlayAttrs:null}];
}
if(!dojo._hasResource["dijit._KeyNavContainer"]){
dojo._hasResource["dijit._KeyNavContainer"]=true;
dojo.provide("dijit._KeyNavContainer");
dojo.declare("dijit._KeyNavContainer",dijit._Container,{tabIndex:"0",_keyNavCodes:{},connectKeyNavHandlers:function(_3e7,_3e8){
var _3e9=(this._keyNavCodes={});
var prev=dojo.hitch(this,this.focusPrev);
var next=dojo.hitch(this,this.focusNext);
dojo.forEach(_3e7,function(code){
_3e9[code]=prev;
});
dojo.forEach(_3e8,function(code){
_3e9[code]=next;
});
_3e9[dojo.keys.HOME]=dojo.hitch(this,"focusFirstChild");
_3e9[dojo.keys.END]=dojo.hitch(this,"focusLastChild");
this.connect(this.domNode,"onkeypress","_onContainerKeypress");
this.connect(this.domNode,"onfocus","_onContainerFocus");
},startupKeyNavChildren:function(){
dojo.forEach(this.getChildren(),dojo.hitch(this,"_startupChild"));
},addChild:function(_3ea,_3eb){
dijit._KeyNavContainer.superclass.addChild.apply(this,arguments);
this._startupChild(_3ea);
},focus:function(){
this.focusFirstChild();
},focusFirstChild:function(){
var _3ec=this._getFirstFocusableChild();
if(_3ec){
this.focusChild(_3ec);
}
},focusLastChild:function(){
var _3ed=this._getLastFocusableChild();
if(_3ed){
this.focusChild(_3ed);
}
},focusNext:function(){
var _3ee=this._getNextFocusableChild(this.focusedChild,1);
this.focusChild(_3ee);
},focusPrev:function(){
var _3ef=this._getNextFocusableChild(this.focusedChild,-1);
this.focusChild(_3ef,true);
},focusChild:function(_3f0,last){
if(this.focusedChild&&_3f0!==this.focusedChild){
this._onChildBlur(this.focusedChild);
}
_3f0.set("tabIndex",this.tabIndex);
_3f0.focus(last?"end":"start");
this._set("focusedChild",_3f0);
},_startupChild:function(_3f1){
_3f1.set("tabIndex","-1");
this.connect(_3f1,"_onFocus",function(){
_3f1.set("tabIndex",this.tabIndex);
});
this.connect(_3f1,"_onBlur",function(){
_3f1.set("tabIndex","-1");
});
},_onContainerFocus:function(evt){
if(evt.target!==this.domNode){
return;
}
this.focusFirstChild();
dojo.attr(this.domNode,"tabIndex","-1");
},_onBlur:function(evt){
if(this.tabIndex){
dojo.attr(this.domNode,"tabIndex",this.tabIndex);
}
this.inherited(arguments);
},_onContainerKeypress:function(evt){
if(evt.ctrlKey||evt.altKey){
return;
}
var func=this._keyNavCodes[evt.charOrCode];
if(func){
func();
dojo.stopEvent(evt);
}
},_onChildBlur:function(_3f2){
},_getFirstFocusableChild:function(){
return this._getNextFocusableChild(null,1);
},_getLastFocusableChild:function(){
return this._getNextFocusableChild(null,-1);
},_getNextFocusableChild:function(_3f3,dir){
if(_3f3){
_3f3=this._getSiblingOfChild(_3f3,dir);
}
var _3f4=this.getChildren();
for(var i=0;i<_3f4.length;i++){
if(!_3f3){
_3f3=_3f4[(dir>0)?0:(_3f4.length-1)];
}
if(_3f3.isFocusable()){
return _3f3;
}
_3f3=this._getSiblingOfChild(_3f3,dir);
}
return null;
}});
}
if(!dojo._hasResource["dijit.ToolbarSeparator"]){
dojo._hasResource["dijit.ToolbarSeparator"]=true;
dojo.provide("dijit.ToolbarSeparator");
dojo.declare("dijit.ToolbarSeparator",[dijit._Widget,dijit._Templated],{templateString:"<div class=\"dijitToolbarSeparator dijitInline\" role=\"presentation\"></div>",buildRendering:function(){
this.inherited(arguments);
dojo.setSelectable(this.domNode,false);
},isFocusable:function(){
return false;
}});
}
if(!dojo._hasResource["dijit.Toolbar"]){
dojo._hasResource["dijit.Toolbar"]=true;
dojo.provide("dijit.Toolbar");
dojo.declare("dijit.Toolbar",[dijit._Widget,dijit._Templated,dijit._KeyNavContainer],{templateString:"<div class=\"dijit\" role=\"toolbar\" tabIndex=\"${tabIndex}\" dojoAttachPoint=\"containerNode\">"+"</div>",baseClass:"dijitToolbar",postCreate:function(){
this.inherited(arguments);
this.connectKeyNavHandlers(this.isLeftToRight()?[dojo.keys.LEFT_ARROW]:[dojo.keys.RIGHT_ARROW],this.isLeftToRight()?[dojo.keys.RIGHT_ARROW]:[dojo.keys.LEFT_ARROW]);
},startup:function(){
if(this._started){
return;
}
this.startupKeyNavChildren();
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.form.Form"]){
dojo._hasResource["dijit.form.Form"]=true;
dojo.provide("dijit.form.Form");
dojo.declare("dijit.form.Form",[dijit._Widget,dijit._Templated,dijit.form._FormMixin,dijit.layout._ContentPaneResizeMixin],{name:"",action:"",method:"",encType:"","accept-charset":"",accept:"",target:"",templateString:"<form dojoAttachPoint='containerNode' dojoAttachEvent='onreset:_onReset,onsubmit:_onSubmit' ${!nameAttrSetting}></form>",attributeMap:dojo.delegate(dijit._Widget.prototype.attributeMap,{action:"",method:"",encType:"","accept-charset":"",accept:"",target:""}),postMixInProperties:function(){
this.nameAttrSetting=this.name?("name='"+this.name+"'"):"";
this.inherited(arguments);
},execute:function(_3f5){
},onExecute:function(){
},_setEncTypeAttr:function(_3f6){
this.encType=_3f6;
dojo.attr(this.domNode,"encType",_3f6);
if(dojo.isIE){
this.domNode.encoding=_3f6;
}
},postCreate:function(){
if(dojo.isIE&&this.srcNodeRef&&this.srcNodeRef.attributes){
var item=this.srcNodeRef.attributes.getNamedItem("encType");
if(item&&!item.specified&&(typeof item.value=="string")){
this.set("encType",item.value);
}
}
this.inherited(arguments);
},reset:function(e){
var faux={returnValue:true,preventDefault:function(){
this.returnValue=false;
},stopPropagation:function(){
},currentTarget:e?e.target:this.domNode,target:e?e.target:this.domNode};
if(!(this.onReset(faux)===false)&&faux.returnValue){
this.inherited(arguments,[]);
}
},onReset:function(e){
return true;
},_onReset:function(e){
this.reset(e);
dojo.stopEvent(e);
return false;
},_onSubmit:function(e){
var fp=dijit.form.Form.prototype;
if(this.execute!=fp.execute||this.onExecute!=fp.onExecute){
dojo.deprecated("dijit.form.Form:execute()/onExecute() are deprecated. Use onSubmit() instead.","","2.0");
this.onExecute();
this.execute(this.getValues());
}
if(this.onSubmit(e)===false){
dojo.stopEvent(e);
}
},onSubmit:function(e){
return this.isValid();
},submit:function(){
if(!(this.onSubmit()===false)){
this.containerNode.submit();
}
}});
}
if(!dojo._hasResource["dijit.form._FormWidget"]){
dojo._hasResource["dijit.form._FormWidget"]=true;
dojo.provide("dijit.form._FormWidget");
dojo.declare("dijit.form._FormWidget",[dijit._Widget,dijit._Templated,dijit._CssStateMixin],{name:"",alt:"",value:"",type:"text",tabIndex:"0",disabled:false,intermediateChanges:false,scrollOnFocus:true,attributeMap:dojo.delegate(dijit._Widget.prototype.attributeMap,{value:"focusNode",id:"focusNode",tabIndex:"focusNode",alt:"focusNode",title:"focusNode"}),postMixInProperties:function(){
this.nameAttrSetting=this.name?("name=\""+this.name.replace(/'/g,"&quot;")+"\""):"";
this.inherited(arguments);
},postCreate:function(){
this.inherited(arguments);
this.connect(this.domNode,"onmousedown","_onMouseDown");
},_setDisabledAttr:function(_3f7){
this._set("disabled",_3f7);
dojo.attr(this.focusNode,"disabled",_3f7);
if(this.valueNode){
dojo.attr(this.valueNode,"disabled",_3f7);
}
dijit.setWaiState(this.focusNode,"disabled",_3f7);
if(_3f7){
this._set("hovering",false);
this._set("active",false);
var _3f8="tabIndex" in this.attributeMap?this.attributeMap.tabIndex:"focusNode";
dojo.forEach(dojo.isArray(_3f8)?_3f8:[_3f8],function(_3f9){
var node=this[_3f9];
if(dojo.isWebKit||dijit.hasDefaultTabStop(node)){
node.setAttribute("tabIndex","-1");
}else{
node.removeAttribute("tabIndex");
}
},this);
}else{
if(this.tabIndex!=""){
this.focusNode.setAttribute("tabIndex",this.tabIndex);
}
}
},setDisabled:function(_3fa){
dojo.deprecated("setDisabled("+_3fa+") is deprecated. Use set('disabled',"+_3fa+") instead.","","2.0");
this.set("disabled",_3fa);
},_onFocus:function(e){
if(this.scrollOnFocus){
dojo.window.scrollIntoView(this.domNode);
}
this.inherited(arguments);
},isFocusable:function(){
return !this.disabled&&this.focusNode&&(dojo.style(this.domNode,"display")!="none");
},focus:function(){
if(!this.disabled){
dijit.focus(this.focusNode);
}
},compare:function(val1,val2){
if(typeof val1=="number"&&typeof val2=="number"){
return (isNaN(val1)&&isNaN(val2))?0:val1-val2;
}else{
if(val1>val2){
return 1;
}else{
if(val1<val2){
return -1;
}else{
return 0;
}
}
}
},onChange:function(_3fb){
},_onChangeActive:false,_handleOnChange:function(_3fc,_3fd){
if(this._lastValueReported==undefined&&(_3fd===null||!this._onChangeActive)){
this._resetValue=this._lastValueReported=_3fc;
}
this._pendingOnChange=this._pendingOnChange||(typeof _3fc!=typeof this._lastValueReported)||(this.compare(_3fc,this._lastValueReported)!=0);
if((this.intermediateChanges||_3fd||_3fd===undefined)&&this._pendingOnChange){
this._lastValueReported=_3fc;
this._pendingOnChange=false;
if(this._onChangeActive){
if(this._onChangeHandle){
clearTimeout(this._onChangeHandle);
}
this._onChangeHandle=setTimeout(dojo.hitch(this,function(){
this._onChangeHandle=null;
this.onChange(_3fc);
}),0);
}
}
},create:function(){
this.inherited(arguments);
this._onChangeActive=true;
},destroy:function(){
if(this._onChangeHandle){
clearTimeout(this._onChangeHandle);
this.onChange(this._lastValueReported);
}
this.inherited(arguments);
},setValue:function(_3fe){
dojo.deprecated("dijit.form._FormWidget:setValue("+_3fe+") is deprecated.  Use set('value',"+_3fe+") instead.","","2.0");
this.set("value",_3fe);
},getValue:function(){
dojo.deprecated(this.declaredClass+"::getValue() is deprecated. Use get('value') instead.","","2.0");
return this.get("value");
},_onMouseDown:function(e){
if(!e.ctrlKey&&dojo.mouseButtons.isLeft(e)&&this.isFocusable()){
var _3ff=this.connect(dojo.body(),"onmouseup",function(){
if(this.isFocusable()){
this.focus();
}
this.disconnect(_3ff);
});
}
}});
dojo.declare("dijit.form._FormValueWidget",dijit.form._FormWidget,{readOnly:false,attributeMap:dojo.delegate(dijit.form._FormWidget.prototype.attributeMap,{value:"",readOnly:"focusNode"}),_setReadOnlyAttr:function(_400){
dojo.attr(this.focusNode,"readOnly",_400);
dijit.setWaiState(this.focusNode,"readonly",_400);
this._set("readOnly",_400);
},postCreate:function(){
this.inherited(arguments);
if(dojo.isIE<9||(dojo.isIE&&dojo.isQuirks)){
this.connect(this.focusNode||this.domNode,"onkeydown",this._onKeyDown);
}
if(this._resetValue===undefined){
this._lastValueReported=this._resetValue=this.value;
}
},_setValueAttr:function(_401,_402){
this._handleOnChange(_401,_402);
},_handleOnChange:function(_403,_404){
this._set("value",_403);
this.inherited(arguments);
},undo:function(){
this._setValueAttr(this._lastValueReported,false);
},reset:function(){
this._hasBeenBlurred=false;
this._setValueAttr(this._resetValue,true);
},_onKeyDown:function(e){
if(e.keyCode==dojo.keys.ESCAPE&&!(e.ctrlKey||e.altKey||e.metaKey)){
var te;
if(dojo.isIE){
e.preventDefault();
te=document.createEventObject();
te.keyCode=dojo.keys.ESCAPE;
te.shiftKey=e.shiftKey;
e.srcElement.fireEvent("onkeypress",te);
}
}
},_layoutHackIE7:function(){
if(dojo.isIE==7){
var _405=this.domNode;
var _406=_405.parentNode;
var _407=_405.firstChild||_405;
var _408=_407.style.filter;
var _409=this;
while(_406&&_406.clientHeight==0){
(function ping(){
var _40a=_409.connect(_406,"onscroll",function(e){
_409.disconnect(_40a);
_407.style.filter=(new Date()).getMilliseconds();
setTimeout(function(){
_407.style.filter=_408;
},0);
});
})();
_406=_406.parentNode;
}
}
}});
}
if(!dojo._hasResource["dijit._HasDropDown"]){
dojo._hasResource["dijit._HasDropDown"]=true;
dojo.provide("dijit._HasDropDown");
dojo.declare("dijit._HasDropDown",null,{_buttonNode:null,_arrowWrapperNode:null,_popupStateNode:null,_aroundNode:null,dropDown:null,autoWidth:true,forceWidth:false,maxHeight:0,dropDownPosition:["below","above"],_stopClickEvents:true,_onDropDownMouseDown:function(e){
if(this.disabled||this.readOnly){
return;
}
dojo.stopEvent(e);
this._docHandler=this.connect(dojo.doc,"onmouseup","_onDropDownMouseUp");
this.toggleDropDown();
},_onDropDownMouseUp:function(e){
if(e&&this._docHandler){
this.disconnect(this._docHandler);
}
var _40b=this.dropDown,_40c=false;
if(e&&this._opened){
var c=dojo.position(this._buttonNode,true);
if(!(e.pageX>=c.x&&e.pageX<=c.x+c.w)||!(e.pageY>=c.y&&e.pageY<=c.y+c.h)){
var t=e.target;
while(t&&!_40c){
if(dojo.hasClass(t,"dijitPopup")){
_40c=true;
}else{
t=t.parentNode;
}
}
if(_40c){
t=e.target;
if(_40b.onItemClick){
var _40d;
while(t&&!(_40d=dijit.byNode(t))){
t=t.parentNode;
}
if(_40d&&_40d.onClick&&_40d.getParent){
_40d.getParent().onItemClick(_40d,e);
}
}
return;
}
}
}
if(this._opened&&_40b.focus&&_40b.autoFocus!==false){
window.setTimeout(dojo.hitch(_40b,"focus"),1);
}
},_onDropDownClick:function(e){
if(this._stopClickEvents){
dojo.stopEvent(e);
}
},buildRendering:function(){
this.inherited(arguments);
this._buttonNode=this._buttonNode||this.focusNode||this.domNode;
this._popupStateNode=this._popupStateNode||this.focusNode||this._buttonNode;
var _40e={"after":this.isLeftToRight()?"Right":"Left","before":this.isLeftToRight()?"Left":"Right","above":"Up","below":"Down","left":"Left","right":"Right"}[this.dropDownPosition[0]]||this.dropDownPosition[0]||"Down";
dojo.addClass(this._arrowWrapperNode||this._buttonNode,"dijit"+_40e+"ArrowButton");
},postCreate:function(){
this.inherited(arguments);
this.connect(this._buttonNode,"onmousedown","_onDropDownMouseDown");
this.connect(this._buttonNode,"onclick","_onDropDownClick");
this.connect(this.focusNode,"onkeypress","_onKey");
this.connect(this.focusNode,"onkeyup","_onKeyUp");
},destroy:function(){
if(this.dropDown){
if(!this.dropDown._destroyed){
this.dropDown.destroyRecursive();
}
delete this.dropDown;
}
this.inherited(arguments);
},_onKey:function(e){
if(this.disabled||this.readOnly){
return;
}
var d=this.dropDown,_40f=e.target;
if(d&&this._opened&&d.handleKey){
if(d.handleKey(e)===false){
dojo.stopEvent(e);
return;
}
}
if(d&&this._opened&&e.charOrCode==dojo.keys.ESCAPE){
this.closeDropDown();
dojo.stopEvent(e);
}else{
if(!this._opened&&(e.charOrCode==dojo.keys.DOWN_ARROW||((e.charOrCode==dojo.keys.ENTER||e.charOrCode==" ")&&((_40f.tagName||"").toLowerCase()!=="input"||(_40f.type&&_40f.type.toLowerCase()!=="text"))))){
this._toggleOnKeyUp=true;
dojo.stopEvent(e);
}
}
},_onKeyUp:function(){
if(this._toggleOnKeyUp){
delete this._toggleOnKeyUp;
this.toggleDropDown();
var d=this.dropDown;
if(d&&d.focus){
setTimeout(dojo.hitch(d,"focus"),1);
}
}
},_onBlur:function(){
var _410=dijit._curFocus&&this.dropDown&&dojo.isDescendant(dijit._curFocus,this.dropDown.domNode);
this.closeDropDown(_410);
this.inherited(arguments);
},isLoaded:function(){
return true;
},loadDropDown:function(_411){
_411();
},toggleDropDown:function(){
if(this.disabled||this.readOnly){
return;
}
if(!this._opened){
if(!this.isLoaded()){
this.loadDropDown(dojo.hitch(this,"openDropDown"));
return;
}else{
this.openDropDown();
}
}else{
this.closeDropDown();
}
},openDropDown:function(){
var _412=this.dropDown,_413=_412.domNode,_414=this._aroundNode||this.domNode,self=this;
if(!this._preparedNode){
this._preparedNode=true;
if(_413.style.width){
this._explicitDDWidth=true;
}
if(_413.style.height){
this._explicitDDHeight=true;
}
}
if(this.maxHeight||this.forceWidth||this.autoWidth){
var _415={display:"",visibility:"hidden"};
if(!this._explicitDDWidth){
_415.width="";
}
if(!this._explicitDDHeight){
_415.height="";
}
dojo.style(_413,_415);
var _416=this.maxHeight;
if(_416==-1){
var _417=dojo.window.getBox(),_418=dojo.position(_414,false);
_416=Math.floor(Math.max(_418.y,_417.h-(_418.y+_418.h)));
}
if(_412.startup&&!_412._started){
_412.startup();
}
dijit.popup.moveOffScreen(_412);
var mb=dojo._getMarginSize(_413);
var _419=(_416&&mb.h>_416);
dojo.style(_413,{overflowX:"hidden",overflowY:_419?"auto":"hidden"});
if(_419){
mb.h=_416;
if("w" in mb){
mb.w+=16;
}
}else{
delete mb.h;
}
if(this.forceWidth){
mb.w=_414.offsetWidth;
}else{
if(this.autoWidth){
mb.w=Math.max(mb.w,_414.offsetWidth);
}else{
delete mb.w;
}
}
if(dojo.isFunction(_412.resize)){
_412.resize(mb);
}else{
dojo.marginBox(_413,mb);
}
}
var _41a=dijit.popup.open({parent:this,popup:_412,around:_414,orient:dijit.getPopupAroundAlignment((this.dropDownPosition&&this.dropDownPosition.length)?this.dropDownPosition:["below"],this.isLeftToRight()),onExecute:function(){
self.closeDropDown(true);
},onCancel:function(){
self.closeDropDown(true);
},onClose:function(){
dojo.attr(self._popupStateNode,"popupActive",false);
dojo.removeClass(self._popupStateNode,"dijitHasDropDownOpen");
self._opened=false;
}});
dojo.attr(this._popupStateNode,"popupActive","true");
dojo.addClass(self._popupStateNode,"dijitHasDropDownOpen");
this._opened=true;
return _41a;
},closeDropDown:function(_41b){
if(this._opened){
if(_41b){
this.focus();
}
dijit.popup.close(this.dropDown);
this._opened=false;
}
}});
}
if(!dojo._hasResource["dijit.form.Button"]){
dojo._hasResource["dijit.form.Button"]=true;
dojo.provide("dijit.form.Button");
dojo.declare("dijit.form.Button",dijit.form._FormWidget,{label:"",showLabel:true,iconClass:"",type:"button",baseClass:"dijitButton",templateString:dojo.cache("dijit.form","templates/Button.html","<span class=\"dijit dijitReset dijitInline\"\r\n\t><span class=\"dijitReset dijitInline dijitButtonNode\"\r\n\t\tdojoAttachEvent=\"ondijitclick:_onButtonClick\"\r\n\t\t><span class=\"dijitReset dijitStretch dijitButtonContents\"\r\n\t\t\tdojoAttachPoint=\"titleNode,focusNode\"\r\n\t\t\trole=\"button\" aria-labelledby=\"${id}_label\"\r\n\t\t\t><span class=\"dijitReset dijitInline dijitIcon\" dojoAttachPoint=\"iconNode\"></span\r\n\t\t\t><span class=\"dijitReset dijitToggleButtonIconChar\">&#x25CF;</span\r\n\t\t\t><span class=\"dijitReset dijitInline dijitButtonText\"\r\n\t\t\t\tid=\"${id}_label\"\r\n\t\t\t\tdojoAttachPoint=\"containerNode\"\r\n\t\t\t></span\r\n\t\t></span\r\n\t></span\r\n\t><input ${!nameAttrSetting} type=\"${type}\" value=\"${value}\" class=\"dijitOffScreen\" tabIndex=\"-1\"\r\n\t\tdojoAttachPoint=\"valueNode\"\r\n/></span>\r\n"),attributeMap:dojo.delegate(dijit.form._FormWidget.prototype.attributeMap,{value:"valueNode"}),_onClick:function(e){
if(this.disabled){
return false;
}
this._clicked();
return this.onClick(e);
},_onButtonClick:function(e){
if(this._onClick(e)===false){
e.preventDefault();
}else{
if(this.type=="submit"&&!(this.valueNode||this.focusNode).form){
for(var node=this.domNode;node.parentNode;node=node.parentNode){
var _41c=dijit.byNode(node);
if(_41c&&typeof _41c._onSubmit=="function"){
_41c._onSubmit(e);
break;
}
}
}else{
if(this.valueNode){
this.valueNode.click();
e.preventDefault();
}
}
}
},buildRendering:function(){
this.inherited(arguments);
dojo.setSelectable(this.focusNode,false);
},_fillContent:function(_41d){
if(_41d&&(!this.params||!("label" in this.params))){
this.set("label",_41d.innerHTML);
}
},_setShowLabelAttr:function(val){
if(this.containerNode){
dojo.toggleClass(this.containerNode,"dijitDisplayNone",!val);
}
this._set("showLabel",val);
},onClick:function(e){
return true;
},_clicked:function(e){
},setLabel:function(_41e){
dojo.deprecated("dijit.form.Button.setLabel() is deprecated.  Use set('label', ...) instead.","","2.0");
this.set("label",_41e);
},_setLabelAttr:function(_41f){
this._set("label",_41f);
this.containerNode.innerHTML=_41f;
if(this.showLabel==false&&!this.params.title){
this.titleNode.title=dojo.trim(this.containerNode.innerText||this.containerNode.textContent||"");
}
},_setIconClassAttr:function(val){
var _420=this.iconClass||"dijitNoIcon",_421=val||"dijitNoIcon";
dojo.replaceClass(this.iconNode,_421,_420);
this._set("iconClass",val);
}});
dojo.declare("dijit.form.DropDownButton",[dijit.form.Button,dijit._Container,dijit._HasDropDown],{baseClass:"dijitDropDownButton",templateString:dojo.cache("dijit.form","templates/DropDownButton.html","<span class=\"dijit dijitReset dijitInline\"\r\n\t><span class='dijitReset dijitInline dijitButtonNode'\r\n\t\tdojoAttachEvent=\"ondijitclick:_onButtonClick\" dojoAttachPoint=\"_buttonNode\"\r\n\t\t><span class=\"dijitReset dijitStretch dijitButtonContents\"\r\n\t\t\tdojoAttachPoint=\"focusNode,titleNode,_arrowWrapperNode\"\r\n\t\t\trole=\"button\" aria-haspopup=\"true\" aria-labelledby=\"${id}_label\"\r\n\t\t\t><span class=\"dijitReset dijitInline dijitIcon\"\r\n\t\t\t\tdojoAttachPoint=\"iconNode\"\r\n\t\t\t></span\r\n\t\t\t><span class=\"dijitReset dijitInline dijitButtonText\"\r\n\t\t\t\tdojoAttachPoint=\"containerNode,_popupStateNode\"\r\n\t\t\t\tid=\"${id}_label\"\r\n\t\t\t></span\r\n\t\t\t><span class=\"dijitReset dijitInline dijitArrowButtonInner\"></span\r\n\t\t\t><span class=\"dijitReset dijitInline dijitArrowButtonChar\">&#9660;</span\r\n\t\t></span\r\n\t></span\r\n\t><input ${!nameAttrSetting} type=\"${type}\" value=\"${value}\" class=\"dijitOffScreen\" tabIndex=\"-1\"\r\n\t\tdojoAttachPoint=\"valueNode\"\r\n/></span>\r\n"),_fillContent:function(){
if(this.srcNodeRef){
var _422=dojo.query("*",this.srcNodeRef);
dijit.form.DropDownButton.superclass._fillContent.call(this,_422[0]);
this.dropDownContainer=this.srcNodeRef;
}
},startup:function(){
if(this._started){
return;
}
if(!this.dropDown&&this.dropDownContainer){
var _423=dojo.query("[widgetId]",this.dropDownContainer)[0];
this.dropDown=dijit.byNode(_423);
delete this.dropDownContainer;
}
if(this.dropDown){
dijit.popup.hide(this.dropDown);
}
this.inherited(arguments);
},isLoaded:function(){
var _424=this.dropDown;
return (!!_424&&(!_424.href||_424.isLoaded));
},loadDropDown:function(){
var _425=this.dropDown;
if(!_425){
return;
}
if(!this.isLoaded()){
var _426=dojo.connect(_425,"onLoad",this,function(){
dojo.disconnect(_426);
this.openDropDown();
});
_425.refresh();
}else{
this.openDropDown();
}
},isFocusable:function(){
return this.inherited(arguments)&&!this._mouseDown;
},_onDropDownMouseUp:function(e){
if(this.dynamic&&this._onItemClickHandler){
dojo.disconnect(this._onItemClickHandler);
dojo.disconnect(this._buttonClickHandler);
dojo.disconnect(this._onMouseOverHandler);
}
this.inherited(arguments);
},_onDropDownClick:function(e){
if(this.dynamic){
this._onItemClickHandler=dojo.connect(this.dropDown,"onItemClick",this,"_onDropDownMenuChange");
this._onMouseOverHandler=dojo.connect(this.dropDown,"onMouseOver",this,"_onDropDownMouseOver");
}
this.inherited(arguments);
},_onDropDownMouseOver:function(evt){
var t=evt.target;
var _427;
while(t&&!(_427=dijit.byNode(t))){
t=t.parentNode;
}
if(_427.popup){
this._onItemClickHandler=dojo.connect(_427.popup,"onItemClick",this,"_onDropDownMenuChange");
}
},_onDropDownMenuChange:function(item,evt){
if(!item.popup&&!item.disabled){
if(this.showLabel){
this.set("label",item.label);
}
this.set("iconClass",item.iconClass);
this._buttonClickHandler=dojo.connect(this,"onClick",item,"onClick");
}
}});
dojo.declare("dijit.form.ComboButton",dijit.form.DropDownButton,{templateString:dojo.cache("dijit.form","templates/ComboButton.html","<table class=\"dijit dijitReset dijitInline dijitLeft\"\r\n\tcellspacing='0' cellpadding='0' role=\"presentation\"\r\n\t><tbody role=\"presentation\"><tr role=\"presentation\"\r\n\t\t><td class=\"dijitReset dijitStretch dijitButtonNode\" dojoAttachPoint=\"buttonNode\" dojoAttachEvent=\"ondijitclick:_onButtonClick,onkeypress:_onButtonKeyPress\"\r\n\t\t><div id=\"${id}_button\" class=\"dijitReset dijitButtonContents\"\r\n\t\t\tdojoAttachPoint=\"titleNode\"\r\n\t\t\trole=\"button\" aria-labelledby=\"${id}_label\"\r\n\t\t\t><div class=\"dijitReset dijitInline dijitIcon\" dojoAttachPoint=\"iconNode\" role=\"presentation\"></div\r\n\t\t\t><div class=\"dijitReset dijitInline dijitButtonText\" id=\"${id}_label\" dojoAttachPoint=\"containerNode\" role=\"presentation\"></div\r\n\t\t></div\r\n\t\t></td\r\n\t\t><td id=\"${id}_arrow\" class='dijitReset dijitRight dijitButtonNode dijitArrowButton'\r\n\t\t\tdojoAttachPoint=\"_popupStateNode,focusNode,_buttonNode\"\r\n\t\t\tdojoAttachEvent=\"onkeypress:_onArrowKeyPress\"\r\n\t\t\ttitle=\"${optionsTitle}\"\r\n\t\t\trole=\"button\" aria-haspopup=\"true\"\r\n\t\t\t><div class=\"dijitReset dijitArrowButtonInner\" role=\"presentation\"></div\r\n\t\t\t><div class=\"dijitReset dijitArrowButtonChar\" role=\"presentation\">&#9660;</div\r\n\t\t></td\r\n\t\t><td style=\"display:none !important;\"\r\n\t\t\t><input ${!nameAttrSetting} type=\"${type}\" value=\"${value}\" dojoAttachPoint=\"valueNode\"\r\n\t\t/></td></tr></tbody\r\n></table>\r\n"),attributeMap:dojo.mixin(dojo.clone(dijit.form.Button.prototype.attributeMap),{id:"",tabIndex:["focusNode","titleNode"],title:"titleNode"}),optionsTitle:"",baseClass:"dijitComboButton",cssStateNodes:{"buttonNode":"dijitButtonNode","titleNode":"dijitButtonContents","_popupStateNode":"dijitDownArrowButton"},_focusedNode:null,dynamic:false,_onButtonKeyPress:function(evt){
if(evt.charOrCode==dojo.keys[this.isLeftToRight()?"RIGHT_ARROW":"LEFT_ARROW"]){
dijit.focus(this._popupStateNode);
dojo.stopEvent(evt);
}
},_onArrowKeyPress:function(evt){
if(evt.charOrCode==dojo.keys[this.isLeftToRight()?"LEFT_ARROW":"RIGHT_ARROW"]){
dijit.focus(this.titleNode);
dojo.stopEvent(evt);
}
},focus:function(_428){
if(!this.disabled){
dijit.focus(_428=="start"?this.titleNode:this._popupStateNode);
}
}});
dojo.declare("dijit.form.ToggleButton",dijit.form.Button,{baseClass:"dijitToggleButton",checked:false,attributeMap:dojo.mixin(dojo.clone(dijit.form.Button.prototype.attributeMap),{checked:"focusNode"}),_clicked:function(evt){
this.set("checked",!this.checked);
},_setCheckedAttr:function(_429,_42a){
this._set("checked",_429);
dojo.attr(this.focusNode||this.domNode,"checked",_429);
dijit.setWaiState(this.focusNode||this.domNode,"pressed",_429);
this._handleOnChange(_429,_42a);
},setChecked:function(_42b){
dojo.deprecated("setChecked("+_42b+") is deprecated. Use set('checked',"+_42b+") instead.","","2.0");
this.set("checked",_42b);
},reset:function(){
this._hasBeenBlurred=false;
this.set("checked",this.params.checked||false);
}});
}
if(!dojo._hasResource["dijit.form.ToggleButton"]){
dojo._hasResource["dijit.form.ToggleButton"]=true;
dojo.provide("dijit.form.ToggleButton");
}
if(!dojo._hasResource["dijit.form.CheckBox"]){
dojo._hasResource["dijit.form.CheckBox"]=true;
dojo.provide("dijit.form.CheckBox");
dojo.declare("dijit.form.CheckBox",dijit.form.ToggleButton,{templateString:dojo.cache("dijit.form","templates/CheckBox.html","<div class=\"dijit dijitReset dijitInline\" role=\"presentation\"\r\n\t><input\r\n\t \t${!nameAttrSetting} type=\"${type}\" ${checkedAttrSetting}\r\n\t\tclass=\"dijitReset dijitCheckBoxInput\"\r\n\t\tdojoAttachPoint=\"focusNode\"\r\n\t \tdojoAttachEvent=\"onclick:_onClick\"\r\n/></div>\r\n"),baseClass:"dijitCheckBox",type:"checkbox",value:"on",readOnly:false,attributeMap:dojo.delegate(dijit.form._FormWidget.prototype.attributeMap,{readOnly:"focusNode"}),_setReadOnlyAttr:function(_42c){
this._set("readOnly",_42c);
dojo.attr(this.focusNode,"readOnly",_42c);
dijit.setWaiState(this.focusNode,"readonly",_42c);
},_setValueAttr:function(_42d,_42e){
if(typeof _42d=="string"){
this._set("value",_42d);
dojo.attr(this.focusNode,"value",_42d);
_42d=true;
}
if(this._created){
this.set("checked",_42d,_42e);
}
},_getValueAttr:function(){
return (this.checked?this.value:false);
},_setLabelAttr:undefined,postMixInProperties:function(){
if(this.value==""){
this.value="on";
}
this.checkedAttrSetting=this.checked?"checked":"";
this.inherited(arguments);
},_fillContent:function(_42f){
},reset:function(){
this._hasBeenBlurred=false;
this.set("checked",this.params.checked||false);
this._set("value",this.params.value||"on");
dojo.attr(this.focusNode,"value",this.value);
},_onFocus:function(){
if(this.id){
dojo.query("label[for='"+this.id+"']").addClass("dijitFocusedLabel");
}
this.inherited(arguments);
},_onBlur:function(){
if(this.id){
dojo.query("label[for='"+this.id+"']").removeClass("dijitFocusedLabel");
}
this.inherited(arguments);
},_onClick:function(e){
if(this.readOnly){
dojo.stopEvent(e);
return false;
}
return this.inherited(arguments);
}});
dojo.declare("dijit.form.RadioButton",dijit.form.CheckBox,{type:"radio",baseClass:"dijitRadio",_setCheckedAttr:function(_430){
this.inherited(arguments);
if(!this._created){
return;
}
if(_430){
var _431=this;
dojo.query("INPUT[type=radio]",this.focusNode.form||dojo.doc).forEach(function(_432){
if(_432.name==_431.name&&_432!=_431.focusNode&&_432.form==_431.focusNode.form){
var _433=dijit.getEnclosingWidget(_432);
if(_433&&_433.checked){
_433.set("checked",false);
}
}
});
}
},_clicked:function(e){
if(!this.checked){
this.set("checked",true);
}
}});
}
if(!dojo._hasResource["dojo.cookie"]){
dojo._hasResource["dojo.cookie"]=true;
dojo.provide("dojo.cookie");
dojo.cookie=function(name,_434,_435){
var c=document.cookie;
if(arguments.length==1){
var _436=c.match(new RegExp("(?:^|; )"+dojo.regexp.escapeString(name)+"=([^;]*)"));
return _436?decodeURIComponent(_436[1]):undefined;
}else{
_435=_435||{};
var exp=_435.expires;
if(typeof exp=="number"){
var d=new Date();
d.setTime(d.getTime()+exp*24*60*60*1000);
exp=_435.expires=d;
}
if(exp&&exp.toUTCString){
_435.expires=exp.toUTCString();
}
_434=encodeURIComponent(_434);
var _437=name+"="+_434,_438;
for(_438 in _435){
_437+="; "+_438;
var _439=_435[_438];
if(_439!==true){
_437+="="+_439;
}
}
document.cookie=_437;
}
};
dojo.cookie.isSupported=function(){
if(!("cookieEnabled" in navigator)){
this("__djCookieTest__","CookiesAllowed");
navigator.cookieEnabled=this("__djCookieTest__")=="CookiesAllowed";
if(navigator.cookieEnabled){
this("__djCookieTest__","",{expires:-1});
}
}
return navigator.cookieEnabled;
};
}
if(!dojo._hasResource["dijit.layout.StackController"]){
dojo._hasResource["dijit.layout.StackController"]=true;
dojo.provide("dijit.layout.StackController");
dojo.declare("dijit.layout.StackController",[dijit._Widget,dijit._Templated,dijit._Container],{templateString:"<span role='tablist' dojoAttachEvent='onkeypress' class='dijitStackController'></span>",containerId:"",buttonWidget:"dijit.layout._StackButton",constructor:function(){
this.pane2button={};
this.pane2connects={};
this.pane2watches={};
},buildRendering:function(){
this.inherited(arguments);
dijit.setWaiRole(this.domNode,"tablist");
},postCreate:function(){
this.inherited(arguments);
this.subscribe(this.containerId+"-startup","onStartup");
this.subscribe(this.containerId+"-addChild","onAddChild");
this.subscribe(this.containerId+"-removeChild","onRemoveChild");
this.subscribe(this.containerId+"-selectChild","onSelectChild");
this.subscribe(this.containerId+"-containerKeyPress","onContainerKeyPress");
},onStartup:function(info){
dojo.forEach(info.children,this.onAddChild,this);
if(info.selected){
this.onSelectChild(info.selected);
}
},destroy:function(){
for(var pane in this.pane2button){
this.onRemoveChild(dijit.byId(pane));
}
this.inherited(arguments);
},onAddChild:function(page,_43a){
var cls=dojo.getObject(this.buttonWidget);
var _43b=new cls({id:this.id+"_"+page.id,label:page.title,dir:page.dir,lang:page.lang,showLabel:page.showTitle,iconClass:page.iconClass,closeButton:page.closable,title:page.tooltip});
dijit.setWaiState(_43b.focusNode,"selected","false");
var _43c=["title","showTitle","iconClass","closable","tooltip"],_43d=["label","showLabel","iconClass","closeButton","title"];
this.pane2watches[page.id]=dojo.map(_43c,function(_43e,idx){
return page.watch(_43e,function(name,_43f,_440){
_43b.set(_43d[idx],_440);
});
});
this.pane2connects[page.id]=[this.connect(_43b,"onClick",dojo.hitch(this,"onButtonClick",page)),this.connect(_43b,"onClickCloseButton",dojo.hitch(this,"onCloseButtonClick",page))];
this.addChild(_43b,_43a);
this.pane2button[page.id]=_43b;
page.controlButton=_43b;
if(!this._currentChild){
_43b.focusNode.setAttribute("tabIndex","0");
dijit.setWaiState(_43b.focusNode,"selected","true");
this._currentChild=page;
}
if(!this.isLeftToRight()&&dojo.isIE&&this._rectifyRtlTabList){
this._rectifyRtlTabList();
}
},onRemoveChild:function(page){
if(this._currentChild===page){
this._currentChild=null;
}
dojo.forEach(this.pane2connects[page.id],dojo.hitch(this,"disconnect"));
delete this.pane2connects[page.id];
dojo.forEach(this.pane2watches[page.id],function(w){
w.unwatch();
});
delete this.pane2watches[page.id];
var _441=this.pane2button[page.id];
if(_441){
this.removeChild(_441);
delete this.pane2button[page.id];
_441.destroy();
}
delete page.controlButton;
},onSelectChild:function(page){
if(!page){
return;
}
if(this._currentChild){
var _442=this.pane2button[this._currentChild.id];
_442.set("checked",false);
dijit.setWaiState(_442.focusNode,"selected","false");
_442.focusNode.setAttribute("tabIndex","-1");
}
var _443=this.pane2button[page.id];
_443.set("checked",true);
dijit.setWaiState(_443.focusNode,"selected","true");
this._currentChild=page;
_443.focusNode.setAttribute("tabIndex","0");
var _444=dijit.byId(this.containerId);
dijit.setWaiState(_444.containerNode,"labelledby",_443.id);
},onButtonClick:function(page){
var _445=dijit.byId(this.containerId);
_445.selectChild(page);
},onCloseButtonClick:function(page){
var _446=dijit.byId(this.containerId);
_446.closeChild(page);
if(this._currentChild){
var b=this.pane2button[this._currentChild.id];
if(b){
dijit.focus(b.focusNode||b.domNode);
}
}
},adjacent:function(_447){
if(!this.isLeftToRight()&&(!this.tabPosition||/top|bottom/.test(this.tabPosition))){
_447=!_447;
}
var _448=this.getChildren();
var _449=dojo.indexOf(_448,this.pane2button[this._currentChild.id]);
var _44a=_447?1:_448.length-1;
return _448[(_449+_44a)%_448.length];
},onkeypress:function(e){
if(this.disabled||e.altKey){
return;
}
var _44b=null;
if(e.ctrlKey||!e._djpage){
var k=dojo.keys;
switch(e.charOrCode){
case k.LEFT_ARROW:
case k.UP_ARROW:
if(!e._djpage){
_44b=false;
}
break;
case k.PAGE_UP:
if(e.ctrlKey){
_44b=false;
}
break;
case k.RIGHT_ARROW:
case k.DOWN_ARROW:
if(!e._djpage){
_44b=true;
}
break;
case k.PAGE_DOWN:
if(e.ctrlKey){
_44b=true;
}
break;
case k.HOME:
case k.END:
var _44c=this.getChildren();
if(_44c&&_44c.length){
_44c[e.charOrCode==k.HOME?0:_44c.length-1].onClick();
}
dojo.stopEvent(e);
break;
case k.DELETE:
if(this._currentChild.closable){
this.onCloseButtonClick(this._currentChild);
}
dojo.stopEvent(e);
break;
default:
if(e.ctrlKey){
if(e.charOrCode===k.TAB){
this.adjacent(!e.shiftKey).onClick();
dojo.stopEvent(e);
}else{
if(e.charOrCode=="w"){
if(this._currentChild.closable){
this.onCloseButtonClick(this._currentChild);
}
dojo.stopEvent(e);
}
}
}
}
if(_44b!==null){
this.adjacent(_44b).onClick();
dojo.stopEvent(e);
}
}
},onContainerKeyPress:function(info){
info.e._djpage=info.page;
this.onkeypress(info.e);
}});
dojo.declare("dijit.layout._StackButton",dijit.form.ToggleButton,{tabIndex:"-1",buildRendering:function(evt){
this.inherited(arguments);
dijit.setWaiRole((this.focusNode||this.domNode),"tab");
},onClick:function(evt){
dijit.focus(this.focusNode);
},onClickCloseButton:function(evt){
evt.stopPropagation();
}});
}
if(!dojo._hasResource["dijit.layout.StackContainer"]){
dojo._hasResource["dijit.layout.StackContainer"]=true;
dojo.provide("dijit.layout.StackContainer");
dojo.declare("dijit.layout.StackContainer",dijit.layout._LayoutWidget,{doLayout:true,persist:false,baseClass:"dijitStackContainer",buildRendering:function(){
this.inherited(arguments);
dojo.addClass(this.domNode,"dijitLayoutContainer");
dijit.setWaiRole(this.containerNode,"tabpanel");
},postCreate:function(){
this.inherited(arguments);
this.connect(this.domNode,"onkeypress",this._onKeyPress);
},startup:function(){
if(this._started){
return;
}
var _44d=this.getChildren();
dojo.forEach(_44d,this._setupChild,this);
if(this.persist){
this.selectedChildWidget=dijit.byId(dojo.cookie(this.id+"_selectedChild"));
}else{
dojo.some(_44d,function(_44e){
if(_44e.selected){
this.selectedChildWidget=_44e;
}
return _44e.selected;
},this);
}
var _44f=this.selectedChildWidget;
if(!_44f&&_44d[0]){
_44f=this.selectedChildWidget=_44d[0];
_44f.selected=true;
}
dojo.publish(this.id+"-startup",[{children:_44d,selected:_44f}]);
this.inherited(arguments);
},resize:function(){
if(!this._hasBeenShown){
this._hasBeenShown=true;
var _450=this.selectedChildWidget;
if(_450){
this._showChild(_450);
}
}
this.inherited(arguments);
},_setupChild:function(_451){
this.inherited(arguments);
dojo.replaceClass(_451.domNode,"dijitHidden","dijitVisible");
_451.domNode.title="";
},addChild:function(_452,_453){
this.inherited(arguments);
if(this._started){
dojo.publish(this.id+"-addChild",[_452,_453]);
this.layout();
if(!this.selectedChildWidget){
this.selectChild(_452);
}
}
},removeChild:function(page){
this.inherited(arguments);
if(this._started){
dojo.publish(this.id+"-removeChild",[page]);
}
if(this._beingDestroyed){
return;
}
if(this.selectedChildWidget===page){
this.selectedChildWidget=undefined;
if(this._started){
var _454=this.getChildren();
if(_454.length){
this.selectChild(_454[0]);
}
}
}
if(this._started){
this.layout();
}
},selectChild:function(page,_455){
page=dijit.byId(page);
if(this.selectedChildWidget!=page){
var d=this._transition(page,this.selectedChildWidget,_455);
this._set("selectedChildWidget",page);
dojo.publish(this.id+"-selectChild",[page]);
if(this.persist){
dojo.cookie(this.id+"_selectedChild",this.selectedChildWidget.id);
}
}
return d;
},_transition:function(_456,_457,_458){
if(_457){
this._hideChild(_457);
}
var d=this._showChild(_456);
if(_456.resize){
if(this.doLayout){
_456.resize(this._containerContentBox||this._contentBox);
}else{
_456.resize();
}
}
return d;
},_adjacent:function(_459){
var _45a=this.getChildren();
var _45b=dojo.indexOf(_45a,this.selectedChildWidget);
_45b+=_459?1:_45a.length-1;
return _45a[_45b%_45a.length];
},forward:function(){
return this.selectChild(this._adjacent(true),true);
},back:function(){
return this.selectChild(this._adjacent(false),true);
},_onKeyPress:function(e){
dojo.publish(this.id+"-containerKeyPress",[{e:e,page:this}]);
},layout:function(){
if(this.doLayout&&this.selectedChildWidget&&this.selectedChildWidget.resize){
this.selectedChildWidget.resize(this._containerContentBox||this._contentBox);
}
},_showChild:function(page){
var _45c=this.getChildren();
page.isFirstChild=(page==_45c[0]);
page.isLastChild=(page==_45c[_45c.length-1]);
page._set("selected",true);
dojo.replaceClass(page.domNode,"dijitVisible","dijitHidden");
return page._onShow()||true;
},_hideChild:function(page){
page._set("selected",false);
dojo.replaceClass(page.domNode,"dijitHidden","dijitVisible");
page.onHide();
},closeChild:function(page){
var _45d=page.onClose(this,page);
if(_45d){
this.removeChild(page);
page.destroyRecursive();
}
},destroyDescendants:function(_45e){
dojo.forEach(this.getChildren(),function(_45f){
this.removeChild(_45f);
_45f.destroyRecursive(_45e);
},this);
}});
dojo.extend(dijit._Widget,{selected:false,closable:false,iconClass:"",showTitle:true});
}
if(!dojo._hasResource["dijit.layout._TabContainerBase"]){
dojo._hasResource["dijit.layout._TabContainerBase"]=true;
dojo.provide("dijit.layout._TabContainerBase");
dojo.declare("dijit.layout._TabContainerBase",[dijit.layout.StackContainer,dijit._Templated],{tabPosition:"top",baseClass:"dijitTabContainer",tabStrip:false,nested:false,templateString:dojo.cache("dijit.layout","templates/TabContainer.html","<div class=\"dijitTabContainer\">\r\n\t<div class=\"dijitTabListWrapper\" dojoAttachPoint=\"tablistNode\"></div>\r\n\t<div dojoAttachPoint=\"tablistSpacer\" class=\"dijitTabSpacer ${baseClass}-spacer\"></div>\r\n\t<div class=\"dijitTabPaneWrapper ${baseClass}-container\" dojoAttachPoint=\"containerNode\"></div>\r\n</div>\r\n"),postMixInProperties:function(){
this.baseClass+=this.tabPosition.charAt(0).toUpperCase()+this.tabPosition.substr(1).replace(/-.*/,"");
this.srcNodeRef&&dojo.style(this.srcNodeRef,"visibility","hidden");
this.inherited(arguments);
},buildRendering:function(){
this.inherited(arguments);
this.tablist=this._makeController(this.tablistNode);
if(!this.doLayout){
dojo.addClass(this.domNode,"dijitTabContainerNoLayout");
}
if(this.nested){
dojo.addClass(this.domNode,"dijitTabContainerNested");
dojo.addClass(this.tablist.containerNode,"dijitTabContainerTabListNested");
dojo.addClass(this.tablistSpacer,"dijitTabContainerSpacerNested");
dojo.addClass(this.containerNode,"dijitTabPaneWrapperNested");
}else{
dojo.addClass(this.domNode,"tabStrip-"+(this.tabStrip?"enabled":"disabled"));
}
},_setupChild:function(tab){
dojo.addClass(tab.domNode,"dijitTabPane");
this.inherited(arguments);
},startup:function(){
if(this._started){
return;
}
this.tablist.startup();
this.inherited(arguments);
},layout:function(){
if(!this._contentBox||typeof (this._contentBox.l)=="undefined"){
return;
}
var sc=this.selectedChildWidget;
if(this.doLayout){
var _460=this.tabPosition.replace(/-h/,"");
this.tablist.layoutAlign=_460;
var _461=[this.tablist,{domNode:this.tablistSpacer,layoutAlign:_460},{domNode:this.containerNode,layoutAlign:"client"}];
dijit.layout.layoutChildren(this.domNode,this._contentBox,_461);
this._containerContentBox=dijit.layout.marginBox2contentBox(this.containerNode,_461[2]);
if(sc&&sc.resize){
sc.resize(this._containerContentBox);
}
}else{
if(this.tablist.resize){
var s=this.tablist.domNode.style;
s.width="0";
var _462=dojo.contentBox(this.domNode).w;
s.width="";
this.tablist.resize({w:_462});
}
if(sc&&sc.resize){
sc.resize();
}
}
},destroy:function(){
if(this.tablist){
this.tablist.destroy();
}
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.MenuItem"]){
dojo._hasResource["dijit.MenuItem"]=true;
dojo.provide("dijit.MenuItem");
dojo.declare("dijit.MenuItem",[dijit._Widget,dijit._Templated,dijit._Contained,dijit._CssStateMixin],{templateString:dojo.cache("dijit","templates/MenuItem.html","<tr class=\"dijitReset dijitMenuItem\" dojoAttachPoint=\"focusNode\" role=\"menuitem\" tabIndex=\"-1\"\r\n\t\tdojoAttachEvent=\"onmouseenter:_onHover,onmouseleave:_onUnhover,ondijitclick:_onClick\">\r\n\t<td class=\"dijitReset dijitMenuItemIconCell\" role=\"presentation\">\r\n\t\t<img src=\"${_blankGif}\" alt=\"\" class=\"dijitIcon dijitMenuItemIcon\" dojoAttachPoint=\"iconNode\"/>\r\n\t</td>\r\n\t<td class=\"dijitReset dijitMenuItemLabel\" colspan=\"2\" dojoAttachPoint=\"containerNode\"></td>\r\n\t<td class=\"dijitReset dijitMenuItemAccelKey\" style=\"display: none\" dojoAttachPoint=\"accelKeyNode\"></td>\r\n\t<td class=\"dijitReset dijitMenuArrowCell\" role=\"presentation\">\r\n\t\t<div dojoAttachPoint=\"arrowWrapper\" style=\"visibility: hidden\">\r\n\t\t\t<img src=\"${_blankGif}\" alt=\"\" class=\"dijitMenuExpand\"/>\r\n\t\t\t<span class=\"dijitMenuExpandA11y\">+</span>\r\n\t\t</div>\r\n\t</td>\r\n</tr>\r\n"),attributeMap:dojo.delegate(dijit._Widget.prototype.attributeMap,{label:{node:"containerNode",type:"innerHTML"},iconClass:{node:"iconNode",type:"class"}}),baseClass:"dijitMenuItem",label:"",iconClass:"",accelKey:"",disabled:false,_fillContent:function(_463){
if(_463&&!("label" in this.params)){
this.set("label",_463.innerHTML);
}
},buildRendering:function(){
this.inherited(arguments);
var _464=this.id+"_text";
dojo.attr(this.containerNode,"id",_464);
if(this.accelKeyNode){
dojo.attr(this.accelKeyNode,"id",this.id+"_accel");
_464+=" "+this.id+"_accel";
}
dijit.setWaiState(this.domNode,"labelledby",_464);
dojo.setSelectable(this.domNode,false);
},_onHover:function(){
this.getParent().onItemHover(this);
},_onUnhover:function(){
this.getParent().onItemUnhover(this);
this._set("hovering",false);
},_onClick:function(evt){
this.getParent().onItemClick(this,evt);
dojo.stopEvent(evt);
},onClick:function(evt){
},focus:function(){
try{
if(dojo.isIE==8){
this.containerNode.focus();
}
dijit.focus(this.focusNode);
}
catch(e){
}
},_onFocus:function(){
this._setSelected(true);
this.getParent()._onItemFocus(this);
this.inherited(arguments);
},_setSelected:function(_465){
dojo.toggleClass(this.domNode,"dijitMenuItemSelected",_465);
},setLabel:function(_466){
dojo.deprecated("dijit.MenuItem.setLabel() is deprecated.  Use set('label', ...) instead.","","2.0");
this.set("label",_466);
},setDisabled:function(_467){
dojo.deprecated("dijit.Menu.setDisabled() is deprecated.  Use set('disabled', bool) instead.","","2.0");
this.set("disabled",_467);
},_setDisabledAttr:function(_468){
dijit.setWaiState(this.focusNode,"disabled",_468?"true":"false");
this._set("disabled",_468);
},_setAccelKeyAttr:function(_469){
this.accelKeyNode.style.display=_469?"":"none";
this.accelKeyNode.innerHTML=_469;
dojo.attr(this.containerNode,"colSpan",_469?"1":"2");
this._set("accelKey",_469);
}});
}
if(!dojo._hasResource["dijit.PopupMenuItem"]){
dojo._hasResource["dijit.PopupMenuItem"]=true;
dojo.provide("dijit.PopupMenuItem");
dojo.declare("dijit.PopupMenuItem",dijit.MenuItem,{_fillContent:function(){
if(this.srcNodeRef){
var _46a=dojo.query("*",this.srcNodeRef);
dijit.PopupMenuItem.superclass._fillContent.call(this,_46a[0]);
this.dropDownContainer=this.srcNodeRef;
}
},startup:function(){
if(this._started){
return;
}
this.inherited(arguments);
if(!this.popup){
var node=dojo.query("[widgetId]",this.dropDownContainer)[0];
this.popup=dijit.byNode(node);
}
dojo.body().appendChild(this.popup.domNode);
this.popup.startup();
this.popup.domNode.style.display="none";
if(this.arrowWrapper){
dojo.style(this.arrowWrapper,"visibility","");
}
dijit.setWaiState(this.focusNode,"haspopup","true");
},destroyDescendants:function(){
if(this.popup){
if(!this.popup._destroyed){
this.popup.destroyRecursive();
}
delete this.popup;
}
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.CheckedMenuItem"]){
dojo._hasResource["dijit.CheckedMenuItem"]=true;
dojo.provide("dijit.CheckedMenuItem");
dojo.declare("dijit.CheckedMenuItem",dijit.MenuItem,{templateString:dojo.cache("dijit","templates/CheckedMenuItem.html","<tr class=\"dijitReset dijitMenuItem\" dojoAttachPoint=\"focusNode\" role=\"menuitemcheckbox\" tabIndex=\"-1\"\r\n\t\tdojoAttachEvent=\"onmouseenter:_onHover,onmouseleave:_onUnhover,ondijitclick:_onClick\">\r\n\t<td class=\"dijitReset dijitMenuItemIconCell\" role=\"presentation\">\r\n\t\t<img src=\"${_blankGif}\" alt=\"\" class=\"dijitMenuItemIcon dijitCheckedMenuItemIcon\" dojoAttachPoint=\"iconNode\"/>\r\n\t\t<span class=\"dijitCheckedMenuItemIconChar\">&#10003;</span>\r\n\t</td>\r\n\t<td class=\"dijitReset dijitMenuItemLabel\" colspan=\"2\" dojoAttachPoint=\"containerNode,labelNode\"></td>\r\n\t<td class=\"dijitReset dijitMenuItemAccelKey\" style=\"display: none\" dojoAttachPoint=\"accelKeyNode\"></td>\r\n\t<td class=\"dijitReset dijitMenuArrowCell\" role=\"presentation\">&nbsp;</td>\r\n</tr>\r\n"),checked:false,_setCheckedAttr:function(_46b){
dojo.toggleClass(this.domNode,"dijitCheckedMenuItemChecked",_46b);
dijit.setWaiState(this.domNode,"checked",_46b);
this._set("checked",_46b);
},onChange:function(_46c){
},_onClick:function(e){
if(!this.disabled){
this.set("checked",!this.checked);
this.onChange(this.checked);
}
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.MenuSeparator"]){
dojo._hasResource["dijit.MenuSeparator"]=true;
dojo.provide("dijit.MenuSeparator");
dojo.declare("dijit.MenuSeparator",[dijit._Widget,dijit._Templated,dijit._Contained],{templateString:dojo.cache("dijit","templates/MenuSeparator.html","<tr class=\"dijitMenuSeparator\">\r\n\t<td class=\"dijitMenuSeparatorIconCell\">\r\n\t\t<div class=\"dijitMenuSeparatorTop\"></div>\r\n\t\t<div class=\"dijitMenuSeparatorBottom\"></div>\r\n\t</td>\r\n\t<td colspan=\"3\" class=\"dijitMenuSeparatorLabelCell\">\r\n\t\t<div class=\"dijitMenuSeparatorTop dijitMenuSeparatorLabel\"></div>\r\n\t\t<div class=\"dijitMenuSeparatorBottom\"></div>\r\n\t</td>\r\n</tr>\r\n"),buildRendering:function(){
this.inherited(arguments);
dojo.setSelectable(this.domNode,false);
},isFocusable:function(){
return false;
}});
}
if(!dojo._hasResource["dijit.Menu"]){
dojo._hasResource["dijit.Menu"]=true;
dojo.provide("dijit.Menu");
dojo.declare("dijit._MenuBase",[dijit._Widget,dijit._Templated,dijit._KeyNavContainer],{parentMenu:null,popupDelay:500,startup:function(){
if(this._started){
return;
}
dojo.forEach(this.getChildren(),function(_46d){
_46d.startup();
});
this.startupKeyNavChildren();
this.inherited(arguments);
},onExecute:function(){
},onCancel:function(_46e){
},_moveToPopup:function(evt){
if(this.focusedChild&&this.focusedChild.popup&&!this.focusedChild.disabled){
this.focusedChild._onClick(evt);
}else{
var _46f=this._getTopMenu();
if(_46f&&_46f._isMenuBar){
_46f.focusNext();
}
}
},_onPopupHover:function(evt){
if(this.currentPopup&&this.currentPopup._pendingClose_timer){
var _470=this.currentPopup.parentMenu;
if(_470.focusedChild){
_470.focusedChild._setSelected(false);
}
_470.focusedChild=this.currentPopup.from_item;
_470.focusedChild._setSelected(true);
this._stopPendingCloseTimer(this.currentPopup);
}
},onItemHover:function(item){
if(this.isActive){
this.focusChild(item);
if(this.focusedChild.popup&&!this.focusedChild.disabled&&!this.hover_timer){
this.hover_timer=setTimeout(dojo.hitch(this,"_openPopup"),this.popupDelay);
}
}
if(this.focusedChild){
this.focusChild(item);
}
this._hoveredChild=item;
},_onChildBlur:function(item){
this._stopPopupTimer();
item._setSelected(false);
var _471=item.popup;
if(_471){
this._stopPendingCloseTimer(_471);
_471._pendingClose_timer=setTimeout(function(){
_471._pendingClose_timer=null;
if(_471.parentMenu){
_471.parentMenu.currentPopup=null;
}
dijit.popup.close(_471);
},this.popupDelay);
}
},onItemUnhover:function(item){
if(this.isActive){
this._stopPopupTimer();
}
if(this._hoveredChild==item){
this._hoveredChild=null;
}
},_stopPopupTimer:function(){
if(this.hover_timer){
clearTimeout(this.hover_timer);
this.hover_timer=null;
}
},_stopPendingCloseTimer:function(_472){
if(_472._pendingClose_timer){
clearTimeout(_472._pendingClose_timer);
_472._pendingClose_timer=null;
}
},_stopFocusTimer:function(){
if(this._focus_timer){
clearTimeout(this._focus_timer);
this._focus_timer=null;
}
},_getTopMenu:function(){
for(var top=this;top.parentMenu;top=top.parentMenu){
}
return top;
},onItemClick:function(item,evt){
if(typeof this.isShowingNow=="undefined"){
this._markActive();
}
this.focusChild(item);
if(item.disabled){
return false;
}
if(item.popup){
this._openPopup();
}else{
this.onExecute();
item.onClick(evt);
}
},_openPopup:function(){
this._stopPopupTimer();
var _473=this.focusedChild;
if(!_473){
return;
}
var _474=_473.popup;
if(_474.isShowingNow){
return;
}
if(this.currentPopup){
this._stopPendingCloseTimer(this.currentPopup);
dijit.popup.close(this.currentPopup);
}
_474.parentMenu=this;
_474.from_item=_473;
var self=this;
dijit.popup.open({parent:this,popup:_474,around:_473.domNode,orient:this._orient||(this.isLeftToRight()?{"TR":"TL","TL":"TR","BR":"BL","BL":"BR"}:{"TL":"TR","TR":"TL","BL":"BR","BR":"BL"}),onCancel:function(){
self.focusChild(_473);
self._cleanUp();
_473._setSelected(true);
self.focusedChild=_473;
},onExecute:dojo.hitch(this,"_cleanUp")});
this.currentPopup=_474;
_474.connect(_474.domNode,"onmouseenter",dojo.hitch(self,"_onPopupHover"));
if(_474.focus){
_474._focus_timer=setTimeout(dojo.hitch(_474,function(){
this._focus_timer=null;
this.focus();
}),0);
}
},_markActive:function(){
this.isActive=true;
dojo.replaceClass(this.domNode,"dijitMenuActive","dijitMenuPassive");
},onOpen:function(e){
this.isShowingNow=true;
this._markActive();
},_markInactive:function(){
this.isActive=false;
dojo.replaceClass(this.domNode,"dijitMenuPassive","dijitMenuActive");
},onClose:function(){
this._stopFocusTimer();
this._markInactive();
this.isShowingNow=false;
this.parentMenu=null;
},_closeChild:function(){
this._stopPopupTimer();
var _475=this.focusedChild&&this.focusedChild.from_item;
if(this.currentPopup){
if(dijit._curFocus&&dojo.isDescendant(dijit._curFocus,this.currentPopup.domNode)){
this.focusedChild.focusNode.focus();
}
dijit.popup.close(this.currentPopup);
this.currentPopup=null;
}
if(this.focusedChild){
this.focusedChild._setSelected(false);
this.focusedChild._onUnhover();
this.focusedChild=null;
}
},_onItemFocus:function(item){
if(this._hoveredChild&&this._hoveredChild!=item){
this._hoveredChild._onUnhover();
}
},_onBlur:function(){
this._cleanUp();
this.inherited(arguments);
},_cleanUp:function(){
this._closeChild();
if(typeof this.isShowingNow=="undefined"){
this._markInactive();
}
}});
dojo.declare("dijit.Menu",dijit._MenuBase,{constructor:function(){
this._bindings=[];
},templateString:dojo.cache("dijit","templates/Menu.html","<table class=\"dijit dijitMenu dijitMenuPassive dijitReset dijitMenuTable\" role=\"menu\" tabIndex=\"${tabIndex}\" dojoAttachEvent=\"onkeypress:_onKeyPress\" cellspacing=\"0\">\r\n\t<tbody class=\"dijitReset\" dojoAttachPoint=\"containerNode\"></tbody>\r\n</table>\r\n"),baseClass:"dijitMenu",targetNodeIds:[],contextMenuForWindow:false,leftClickToOpen:false,refocus:true,postCreate:function(){
if(this.contextMenuForWindow){
this.bindDomNode(dojo.body());
}else{
dojo.forEach(this.targetNodeIds,this.bindDomNode,this);
}
var k=dojo.keys,l=this.isLeftToRight();
this._openSubMenuKey=l?k.RIGHT_ARROW:k.LEFT_ARROW;
this._closeSubMenuKey=l?k.LEFT_ARROW:k.RIGHT_ARROW;
this.connectKeyNavHandlers([k.UP_ARROW],[k.DOWN_ARROW]);
},_onKeyPress:function(evt){
if(evt.ctrlKey||evt.altKey){
return;
}
switch(evt.charOrCode){
case this._openSubMenuKey:
this._moveToPopup(evt);
dojo.stopEvent(evt);
break;
case this._closeSubMenuKey:
if(this.parentMenu){
if(this.parentMenu._isMenuBar){
this.parentMenu.focusPrev();
}else{
this.onCancel(false);
}
}else{
dojo.stopEvent(evt);
}
break;
}
},_iframeContentWindow:function(_476){
var win=dojo.window.get(this._iframeContentDocument(_476))||this._iframeContentDocument(_476)["__parent__"]||(_476.name&&dojo.doc.frames[_476.name])||null;
return win;
},_iframeContentDocument:function(_477){
var doc=_477.contentDocument||(_477.contentWindow&&_477.contentWindow.document)||(_477.name&&dojo.doc.frames[_477.name]&&dojo.doc.frames[_477.name].document)||null;
return doc;
},bindDomNode:function(node){
node=dojo.byId(node);
var cn;
if(node.tagName.toLowerCase()=="iframe"){
var _478=node,win=this._iframeContentWindow(_478);
cn=dojo.withGlobal(win,dojo.body);
}else{
cn=(node==dojo.body()?dojo.doc.documentElement:node);
}
var _479={node:node,iframe:_478};
dojo.attr(node,"_dijitMenu"+this.id,this._bindings.push(_479));
var _47a=dojo.hitch(this,function(cn){
return [dojo.connect(cn,this.leftClickToOpen?"onclick":"oncontextmenu",this,function(evt){
dojo.stopEvent(evt);
this._scheduleOpen(evt.target,_478,{x:evt.pageX,y:evt.pageY});
}),dojo.connect(cn,"onkeydown",this,function(evt){
if(evt.shiftKey&&evt.keyCode==dojo.keys.F10){
dojo.stopEvent(evt);
this._scheduleOpen(evt.target,_478);
}
})];
});
_479.connects=cn?_47a(cn):[];
if(_478){
_479.onloadHandler=dojo.hitch(this,function(){
var win=this._iframeContentWindow(_478);
cn=dojo.withGlobal(win,dojo.body);
_479.connects=_47a(cn);
});
if(_478.addEventListener){
_478.addEventListener("load",_479.onloadHandler,false);
}else{
_478.attachEvent("onload",_479.onloadHandler);
}
}
},unBindDomNode:function(_47b){
var node;
try{
node=dojo.byId(_47b);
}
catch(e){
return;
}
var _47c="_dijitMenu"+this.id;
if(node&&dojo.hasAttr(node,_47c)){
var bid=dojo.attr(node,_47c)-1,b=this._bindings[bid];
dojo.forEach(b.connects,dojo.disconnect);
var _47d=b.iframe;
if(_47d){
if(_47d.removeEventListener){
_47d.removeEventListener("load",b.onloadHandler,false);
}else{
_47d.detachEvent("onload",b.onloadHandler);
}
}
dojo.removeAttr(node,_47c);
delete this._bindings[bid];
}
},_scheduleOpen:function(_47e,_47f,_480){
if(!this._openTimer){
this._openTimer=setTimeout(dojo.hitch(this,function(){
delete this._openTimer;
this._openMyself({target:_47e,iframe:_47f,coords:_480});
}),1);
}
},_openMyself:function(args){
var _481=args.target,_482=args.iframe,_483=args.coords;
if(_483){
if(_482){
var od=_481.ownerDocument,ifc=dojo.position(_482,true),win=this._iframeContentWindow(_482),_484=dojo.withGlobal(win,"_docScroll",dojo);
var cs=dojo.getComputedStyle(_482),tp=dojo._toPixelValue,left=(dojo.isIE&&dojo.isQuirks?0:tp(_482,cs.paddingLeft))+(dojo.isIE&&dojo.isQuirks?tp(_482,cs.borderLeftWidth):0),top=(dojo.isIE&&dojo.isQuirks?0:tp(_482,cs.paddingTop))+(dojo.isIE&&dojo.isQuirks?tp(_482,cs.borderTopWidth):0);
_483.x+=ifc.x+left-_484.x;
_483.y+=ifc.y+top-_484.y;
}
}else{
_483=dojo.position(_481,true);
_483.x+=10;
_483.y+=10;
}
var self=this;
var _485=dijit.getFocus(this);
function _486(){
if(self.refocus){
dijit.focus(_485);
}
dijit.popup.close(self);
};
dijit.popup.open({popup:this,x:_483.x,y:_483.y,onExecute:_486,onCancel:_486,orient:this.isLeftToRight()?"L":"R"});
this.focus();
this._onBlur=function(){
this.inherited("_onBlur",arguments);
dijit.popup.close(this);
};
},uninitialize:function(){
dojo.forEach(this._bindings,function(b){
if(b){
this.unBindDomNode(b.node);
}
},this);
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.layout.TabController"]){
dojo._hasResource["dijit.layout.TabController"]=true;
dojo.provide("dijit.layout.TabController");
dojo.declare("dijit.layout.TabController",dijit.layout.StackController,{templateString:"<div role='tablist' dojoAttachEvent='onkeypress:onkeypress'></div>",tabPosition:"top",buttonWidget:"dijit.layout._TabButton",_rectifyRtlTabList:function(){
if(0>=this.tabPosition.indexOf("-h")){
return;
}
if(!this.pane2button){
return;
}
var _487=0;
for(var pane in this.pane2button){
var ow=this.pane2button[pane].innerDiv.scrollWidth;
_487=Math.max(_487,ow);
}
for(pane in this.pane2button){
this.pane2button[pane].innerDiv.style.width=_487+"px";
}
}});
dojo.declare("dijit.layout._TabButton",dijit.layout._StackButton,{baseClass:"dijitTab",cssStateNodes:{closeNode:"dijitTabCloseButton"},templateString:dojo.cache("dijit.layout","templates/_TabButton.html","<div role=\"presentation\" dojoAttachPoint=\"titleNode\" dojoAttachEvent='onclick:onClick'>\r\n    <div role=\"presentation\" class='dijitTabInnerDiv' dojoAttachPoint='innerDiv'>\r\n        <div role=\"presentation\" class='dijitTabContent' dojoAttachPoint='tabContent'>\r\n        \t<div role=\"presentation\" dojoAttachPoint='focusNode'>\r\n\t\t        <img src=\"${_blankGif}\" alt=\"\" class=\"dijitIcon dijitTabButtonIcon\" dojoAttachPoint='iconNode' />\r\n\t\t        <span dojoAttachPoint='containerNode' class='tabLabel'></span>\r\n\t\t        <span class=\"dijitInline dijitTabCloseButton dijitTabCloseIcon\" dojoAttachPoint='closeNode'\r\n\t\t        \t\tdojoAttachEvent='onclick: onClickCloseButton' role=\"presentation\">\r\n\t\t            <span dojoAttachPoint='closeText' class='dijitTabCloseText'>[x]</span\r\n\t\t        ></span>\r\n\t\t\t</div>\r\n        </div>\r\n    </div>\r\n</div>\r\n"),scrollOnFocus:false,buildRendering:function(){
this.inherited(arguments);
dojo.setSelectable(this.containerNode,false);
},startup:function(){
this.inherited(arguments);
var n=this.domNode;
setTimeout(function(){
n.className=n.className;
},1);
},_setCloseButtonAttr:function(disp){
this._set("closeButton",disp);
dojo.toggleClass(this.innerDiv,"dijitClosable",disp);
this.closeNode.style.display=disp?"":"none";
if(disp){
var _488=dojo.i18n.getLocalization("dijit","common");
if(this.closeNode){
dojo.attr(this.closeNode,"title",_488.itemClose);
}
var _488=dojo.i18n.getLocalization("dijit","common");
this._closeMenu=new dijit.Menu({id:this.id+"_Menu",dir:this.dir,lang:this.lang,targetNodeIds:[this.domNode]});
this._closeMenu.addChild(new dijit.MenuItem({label:_488.itemClose,dir:this.dir,lang:this.lang,onClick:dojo.hitch(this,"onClickCloseButton")}));
}else{
if(this._closeMenu){
this._closeMenu.destroyRecursive();
delete this._closeMenu;
}
}
},_setLabelAttr:function(_489){
this.inherited(arguments);
if(this.showLabel==false&&!this.params.title){
this.iconNode.alt=dojo.trim(this.containerNode.innerText||this.containerNode.textContent||"");
}
},destroy:function(){
if(this._closeMenu){
this._closeMenu.destroyRecursive();
delete this._closeMenu;
}
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.layout.ScrollingTabController"]){
dojo._hasResource["dijit.layout.ScrollingTabController"]=true;
dojo.provide("dijit.layout.ScrollingTabController");
dojo.declare("dijit.layout.ScrollingTabController",dijit.layout.TabController,{templateString:dojo.cache("dijit.layout","templates/ScrollingTabController.html","<div class=\"dijitTabListContainer-${tabPosition}\" style=\"visibility:hidden\">\r\n\t<div dojoType=\"dijit.layout._ScrollingTabControllerMenuButton\"\r\n\t\t\tclass=\"tabStripButton-${tabPosition}\"\r\n\t\t\tid=\"${id}_menuBtn\" containerId=\"${containerId}\" iconClass=\"dijitTabStripMenuIcon\"\r\n\t\t\tdropDownPosition=\"below-alt, above-alt\"\r\n\t\t\tdojoAttachPoint=\"_menuBtn\" showLabel=\"false\">&#9660;</div>\r\n\t<div dojoType=\"dijit.layout._ScrollingTabControllerButton\"\r\n\t\t\tclass=\"tabStripButton-${tabPosition}\"\r\n\t\t\tid=\"${id}_leftBtn\" iconClass=\"dijitTabStripSlideLeftIcon\"\r\n\t\t\tdojoAttachPoint=\"_leftBtn\" dojoAttachEvent=\"onClick: doSlideLeft\" showLabel=\"false\">&#9664;</div>\r\n\t<div dojoType=\"dijit.layout._ScrollingTabControllerButton\"\r\n\t\t\tclass=\"tabStripButton-${tabPosition}\"\r\n\t\t\tid=\"${id}_rightBtn\" iconClass=\"dijitTabStripSlideRightIcon\"\r\n\t\t\tdojoAttachPoint=\"_rightBtn\" dojoAttachEvent=\"onClick: doSlideRight\" showLabel=\"false\">&#9654;</div>\r\n\t<div class='dijitTabListWrapper' dojoAttachPoint='tablistWrapper'>\r\n\t\t<div role='tablist' dojoAttachEvent='onkeypress:onkeypress'\r\n\t\t\t\tdojoAttachPoint='containerNode' class='nowrapTabStrip'></div>\r\n\t</div>\r\n</div>\r\n"),useMenu:true,useSlider:true,tabStripClass:"",widgetsInTemplate:true,_minScroll:5,attributeMap:dojo.delegate(dijit._Widget.prototype.attributeMap,{"class":"containerNode"}),buildRendering:function(){
this.inherited(arguments);
var n=this.domNode;
this.scrollNode=this.tablistWrapper;
this._initButtons();
if(!this.tabStripClass){
this.tabStripClass="dijitTabContainer"+this.tabPosition.charAt(0).toUpperCase()+this.tabPosition.substr(1).replace(/-.*/,"")+"None";
dojo.addClass(n,"tabStrip-disabled");
}
dojo.addClass(this.tablistWrapper,this.tabStripClass);
},onStartup:function(){
this.inherited(arguments);
dojo.style(this.domNode,"visibility","visible");
this._postStartup=true;
},onAddChild:function(page,_48a){
this.inherited(arguments);
dojo.forEach(["label","iconClass"],function(attr){
this.pane2watches[page.id].push(this.pane2button[page.id].watch(attr,dojo.hitch(this,function(name,_48b,_48c){
if(this._postStartup&&this._dim){
this.resize(this._dim);
}
})));
},this);
dojo.style(this.containerNode,"width",(dojo.style(this.containerNode,"width")+200)+"px");
},onRemoveChild:function(page,_48d){
var _48e=this.pane2button[page.id];
if(this._selectedTab===_48e.domNode){
this._selectedTab=null;
}
this.inherited(arguments);
},_initButtons:function(){
this._btnWidth=0;
this._buttons=dojo.query("> .tabStripButton",this.domNode).filter(function(btn){
if((this.useMenu&&btn==this._menuBtn.domNode)||(this.useSlider&&(btn==this._rightBtn.domNode||btn==this._leftBtn.domNode))){
this._btnWidth+=dojo._getMarginSize(btn).w;
return true;
}else{
dojo.style(btn,"display","none");
return false;
}
},this);
},_getTabsWidth:function(){
var _48f=this.getChildren();
if(_48f.length){
var _490=_48f[this.isLeftToRight()?0:_48f.length-1].domNode,_491=_48f[this.isLeftToRight()?_48f.length-1:0].domNode;
return _491.offsetLeft+dojo.style(_491,"width")-_490.offsetLeft;
}else{
return 0;
}
},_enableBtn:function(_492){
var _493=this._getTabsWidth();
_492=_492||dojo.style(this.scrollNode,"width");
return _493>0&&_492<_493;
},resize:function(dim){
if(this.domNode.offsetWidth==0){
return;
}
this._dim=dim;
this.scrollNode.style.height="auto";
this._contentBox=dijit.layout.marginBox2contentBox(this.domNode,{h:0,w:dim.w});
this._contentBox.h=this.scrollNode.offsetHeight;
dojo.contentBox(this.domNode,this._contentBox);
var _494=this._enableBtn(this._contentBox.w);
this._buttons.style("display",_494?"":"none");
this._leftBtn.layoutAlign="left";
this._rightBtn.layoutAlign="right";
this._menuBtn.layoutAlign=this.isLeftToRight()?"right":"left";
dijit.layout.layoutChildren(this.domNode,this._contentBox,[this._menuBtn,this._leftBtn,this._rightBtn,{domNode:this.scrollNode,layoutAlign:"client"}]);
if(this._selectedTab){
if(this._anim&&this._anim.status()=="playing"){
this._anim.stop();
}
var w=this.scrollNode,sl=this._convertToScrollLeft(this._getScrollForSelectedTab());
w.scrollLeft=sl;
}
this._setButtonClass(this._getScroll());
this._postResize=true;
return {h:this._contentBox.h,w:dim.w};
},_getScroll:function(){
var sl=(this.isLeftToRight()||dojo.isIE<8||(dojo.isIE&&dojo.isQuirks)||dojo.isWebKit)?this.scrollNode.scrollLeft:dojo.style(this.containerNode,"width")-dojo.style(this.scrollNode,"width")+(dojo.isIE==8?-1:1)*this.scrollNode.scrollLeft;
return sl;
},_convertToScrollLeft:function(val){
if(this.isLeftToRight()||dojo.isIE<8||(dojo.isIE&&dojo.isQuirks)||dojo.isWebKit){
return val;
}else{
var _495=dojo.style(this.containerNode,"width")-dojo.style(this.scrollNode,"width");
return (dojo.isIE==8?-1:1)*(val-_495);
}
},onSelectChild:function(page){
var tab=this.pane2button[page.id];
if(!tab||!page){
return;
}
var node=tab.domNode;
if(this._postResize&&node!=this._selectedTab){
this._selectedTab=node;
var sl=this._getScroll();
if(sl>node.offsetLeft||sl+dojo.style(this.scrollNode,"width")<node.offsetLeft+dojo.style(node,"width")){
this.createSmoothScroll().play();
}
}
this.inherited(arguments);
},_getScrollBounds:function(){
var _496=this.getChildren(),_497=dojo.style(this.scrollNode,"width"),_498=dojo.style(this.containerNode,"width"),_499=_498-_497,_49a=this._getTabsWidth();
if(_496.length&&_49a>_497){
return {min:this.isLeftToRight()?0:_496[_496.length-1].domNode.offsetLeft,max:this.isLeftToRight()?(_496[_496.length-1].domNode.offsetLeft+dojo.style(_496[_496.length-1].domNode,"width"))-_497:_499};
}else{
var _49b=this.isLeftToRight()?0:_499;
return {min:_49b,max:_49b};
}
},_getScrollForSelectedTab:function(){
var w=this.scrollNode,n=this._selectedTab,_49c=dojo.style(this.scrollNode,"width"),_49d=this._getScrollBounds();
var pos=(n.offsetLeft+dojo.style(n,"width")/2)-_49c/2;
pos=Math.min(Math.max(pos,_49d.min),_49d.max);
return pos;
},createSmoothScroll:function(x){
if(arguments.length>0){
var _49e=this._getScrollBounds();
x=Math.min(Math.max(x,_49e.min),_49e.max);
}else{
x=this._getScrollForSelectedTab();
}
if(this._anim&&this._anim.status()=="playing"){
this._anim.stop();
}
var self=this,w=this.scrollNode,anim=new dojo._Animation({beforeBegin:function(){
if(this.curve){
delete this.curve;
}
var oldS=w.scrollLeft,newS=self._convertToScrollLeft(x);
anim.curve=new dojo._Line(oldS,newS);
},onAnimate:function(val){
w.scrollLeft=val;
}});
this._anim=anim;
this._setButtonClass(x);
return anim;
},_getBtnNode:function(e){
var n=e.target;
while(n&&!dojo.hasClass(n,"tabStripButton")){
n=n.parentNode;
}
return n;
},doSlideRight:function(e){
this.doSlide(1,this._getBtnNode(e));
},doSlideLeft:function(e){
this.doSlide(-1,this._getBtnNode(e));
},doSlide:function(_49f,node){
if(node&&dojo.hasClass(node,"dijitTabDisabled")){
return;
}
var _4a0=dojo.style(this.scrollNode,"width");
var d=(_4a0*0.75)*_49f;
var to=this._getScroll()+d;
this._setButtonClass(to);
this.createSmoothScroll(to).play();
},_setButtonClass:function(_4a1){
var _4a2=this._getScrollBounds();
this._leftBtn.set("disabled",_4a1<=_4a2.min);
this._rightBtn.set("disabled",_4a1>=_4a2.max);
}});
dojo.declare("dijit.layout._ScrollingTabControllerButtonMixin",null,{baseClass:"dijitTab tabStripButton",templateString:dojo.cache("dijit.layout","templates/_ScrollingTabControllerButton.html","<div dojoAttachEvent=\"onclick:_onButtonClick\">\r\n\t<div role=\"presentation\" class=\"dijitTabInnerDiv\" dojoattachpoint=\"innerDiv,focusNode\">\r\n\t\t<div role=\"presentation\" class=\"dijitTabContent dijitButtonContents\" dojoattachpoint=\"tabContent\">\r\n\t\t\t<img role=\"presentation\" alt=\"\" src=\"${_blankGif}\" class=\"dijitTabStripIcon\" dojoAttachPoint=\"iconNode\"/>\r\n\t\t\t<span dojoAttachPoint=\"containerNode,titleNode\" class=\"dijitButtonText\"></span>\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n"),tabIndex:"",isFocusable:function(){
return false;
}});
dojo.declare("dijit.layout._ScrollingTabControllerButton",[dijit.form.Button,dijit.layout._ScrollingTabControllerButtonMixin]);
dojo.declare("dijit.layout._ScrollingTabControllerMenuButton",[dijit.form.Button,dijit._HasDropDown,dijit.layout._ScrollingTabControllerButtonMixin],{containerId:"",tabIndex:"-1",isLoaded:function(){
return false;
},loadDropDown:function(_4a3){
this.dropDown=new dijit.Menu({id:this.containerId+"_menu",dir:this.dir,lang:this.lang});
var _4a4=dijit.byId(this.containerId);
dojo.forEach(_4a4.getChildren(),function(page){
var _4a5=new dijit.MenuItem({id:page.id+"_stcMi",label:page.title,iconClass:page.iconClass,dir:page.dir,lang:page.lang,onClick:function(){
_4a4.selectChild(page);
}});
this.dropDown.addChild(_4a5);
},this);
_4a3();
},closeDropDown:function(_4a6){
this.inherited(arguments);
if(this.dropDown){
this.dropDown.destroyRecursive();
delete this.dropDown;
}
}});
}
if(!dojo._hasResource["dijit.layout.TabContainer"]){
dojo._hasResource["dijit.layout.TabContainer"]=true;
dojo.provide("dijit.layout.TabContainer");
dojo.declare("dijit.layout.TabContainer",dijit.layout._TabContainerBase,{useMenu:true,useSlider:true,controllerWidget:"",_makeController:function(_4a7){
var cls=this.baseClass+"-tabs"+(this.doLayout?"":" dijitTabNoLayout"),_4a8=dojo.getObject(this.controllerWidget);
return new _4a8({id:this.id+"_tablist",dir:this.dir,lang:this.lang,tabPosition:this.tabPosition,doLayout:this.doLayout,containerId:this.id,"class":cls,nested:this.nested,useMenu:this.useMenu,useSlider:this.useSlider,tabStripClass:this.tabStrip?this.baseClass+(this.tabStrip?"":"No")+"Strip":null},_4a7);
},postMixInProperties:function(){
this.inherited(arguments);
if(!this.controllerWidget){
this.controllerWidget=(this.tabPosition=="top"||this.tabPosition=="bottom")&&!this.nested?"dijit.layout.ScrollingTabController":"dijit.layout.TabController";
}
}});
}
if(!dojo._hasResource["dijit.layout.BorderContainer"]){
dojo._hasResource["dijit.layout.BorderContainer"]=true;
dojo.provide("dijit.layout.BorderContainer");
dojo.declare("dijit.layout.BorderContainer",dijit.layout._LayoutWidget,{design:"headline",gutters:true,liveSplitters:true,persist:false,baseClass:"dijitBorderContainer",_splitterClass:"dijit.layout._Splitter",postMixInProperties:function(){
if(!this.gutters){
this.baseClass+="NoGutter";
}
this.inherited(arguments);
},startup:function(){
if(this._started){
return;
}
dojo.forEach(this.getChildren(),this._setupChild,this);
this.inherited(arguments);
},_setupChild:function(_4a9){
var _4aa=_4a9.region;
if(_4aa){
this.inherited(arguments);
dojo.addClass(_4a9.domNode,this.baseClass+"Pane");
var ltr=this.isLeftToRight();
if(_4aa=="leading"){
_4aa=ltr?"left":"right";
}
if(_4aa=="trailing"){
_4aa=ltr?"right":"left";
}
if(_4aa!="center"&&(_4a9.splitter||this.gutters)&&!_4a9._splitterWidget){
var _4ab=dojo.getObject(_4a9.splitter?this._splitterClass:"dijit.layout._Gutter");
var _4ac=new _4ab({id:_4a9.id+"_splitter",container:this,child:_4a9,region:_4aa,live:this.liveSplitters});
_4ac.isSplitter=true;
_4a9._splitterWidget=_4ac;
dojo.place(_4ac.domNode,_4a9.domNode,"after");
_4ac.startup();
}
_4a9.region=_4aa;
}
},layout:function(){
this._layoutChildren();
},addChild:function(_4ad,_4ae){
this.inherited(arguments);
if(this._started){
this.layout();
}
},removeChild:function(_4af){
var _4b0=_4af.region;
var _4b1=_4af._splitterWidget;
if(_4b1){
_4b1.destroy();
delete _4af._splitterWidget;
}
this.inherited(arguments);
if(this._started){
this._layoutChildren();
}
dojo.removeClass(_4af.domNode,this.baseClass+"Pane");
dojo.style(_4af.domNode,{top:"auto",bottom:"auto",left:"auto",right:"auto",position:"static"});
dojo.style(_4af.domNode,_4b0=="top"||_4b0=="bottom"?"width":"height","auto");
},getChildren:function(){
return dojo.filter(this.inherited(arguments),function(_4b2){
return !_4b2.isSplitter;
});
},getSplitter:function(_4b3){
return dojo.filter(this.getChildren(),function(_4b4){
return _4b4.region==_4b3;
})[0]._splitterWidget;
},resize:function(_4b5,_4b6){
if(!this.cs||!this.pe){
var node=this.domNode;
this.cs=dojo.getComputedStyle(node);
this.pe=dojo._getPadExtents(node,this.cs);
this.pe.r=dojo._toPixelValue(node,this.cs.paddingRight);
this.pe.b=dojo._toPixelValue(node,this.cs.paddingBottom);
dojo.style(node,"padding","0px");
}
this.inherited(arguments);
},_layoutChildren:function(_4b7,_4b8){
if(!this._borderBox||!this._borderBox.h){
return;
}
var _4b9=dojo.map(this.getChildren(),function(_4ba,idx){
return {pane:_4ba,weight:[_4ba.region=="center"?Infinity:0,_4ba.layoutPriority,(this.design=="sidebar"?1:-1)*(/top|bottom/.test(_4ba.region)?1:-1),idx]};
},this);
_4b9.sort(function(a,b){
var aw=a.weight,bw=b.weight;
for(var i=0;i<aw.length;i++){
if(aw[i]!=bw[i]){
return aw[i]-bw[i];
}
}
return 0;
});
var _4bb=[];
dojo.forEach(_4b9,function(_4bc){
var pane=_4bc.pane;
_4bb.push(pane);
if(pane._splitterWidget){
_4bb.push(pane._splitterWidget);
}
});
var dim={l:this.pe.l,t:this.pe.t,w:this._borderBox.w-this.pe.w,h:this._borderBox.h-this.pe.h};
dijit.layout.layoutChildren(this.domNode,dim,_4bb,_4b7,_4b8);
},destroyRecursive:function(){
dojo.forEach(this.getChildren(),function(_4bd){
var _4be=_4bd._splitterWidget;
if(_4be){
_4be.destroy();
}
delete _4bd._splitterWidget;
});
this.inherited(arguments);
}});
dojo.extend(dijit._Widget,{region:"",layoutPriority:0,splitter:false,minSize:0,maxSize:Infinity});
dojo.declare("dijit.layout._Splitter",[dijit._Widget,dijit._Templated],{live:true,templateString:"<div class=\"dijitSplitter\" dojoAttachEvent=\"onkeypress:_onKeyPress,onmousedown:_startDrag,onmouseenter:_onMouse,onmouseleave:_onMouse\" tabIndex=\"0\" role=\"separator\"><div class=\"dijitSplitterThumb\"></div></div>",postMixInProperties:function(){
this.inherited(arguments);
this.horizontal=/top|bottom/.test(this.region);
this._factor=/top|left/.test(this.region)?1:-1;
this._cookieName=this.container.id+"_"+this.region;
},buildRendering:function(){
this.inherited(arguments);
dojo.addClass(this.domNode,"dijitSplitter"+(this.horizontal?"H":"V"));
if(this.container.persist){
var _4bf=dojo.cookie(this._cookieName);
if(_4bf){
this.child.domNode.style[this.horizontal?"height":"width"]=_4bf;
}
}
},_computeMaxSize:function(){
var dim=this.horizontal?"h":"w",_4c0=dojo.marginBox(this.child.domNode)[dim],_4c1=dojo.filter(this.container.getChildren(),function(_4c2){
return _4c2.region=="center";
})[0],_4c3=dojo.marginBox(_4c1.domNode)[dim];
return Math.min(this.child.maxSize,_4c0+_4c3);
},_startDrag:function(e){
if(!this.cover){
this.cover=dojo.doc.createElement("div");
dojo.addClass(this.cover,"dijitSplitterCover");
dojo.place(this.cover,this.child.domNode,"after");
}
dojo.addClass(this.cover,"dijitSplitterCoverActive");
if(this.fake){
dojo.destroy(this.fake);
}
if(!(this._resize=this.live)){
(this.fake=this.domNode.cloneNode(true)).removeAttribute("id");
dojo.addClass(this.domNode,"dijitSplitterShadow");
dojo.place(this.fake,this.domNode,"after");
}
dojo.addClass(this.domNode,"dijitSplitterActive dijitSplitter"+(this.horizontal?"H":"V")+"Active");
if(this.fake){
dojo.removeClass(this.fake,"dijitSplitterHover dijitSplitter"+(this.horizontal?"H":"V")+"Hover");
}
var _4c4=this._factor,_4c5=this.horizontal,axis=_4c5?"pageY":"pageX",_4c6=e[axis],_4c7=this.domNode.style,dim=_4c5?"h":"w",_4c8=dojo.marginBox(this.child.domNode)[dim],max=this._computeMaxSize(),min=this.child.minSize||20,_4c9=this.region,_4ca=_4c9=="top"||_4c9=="bottom"?"top":"left",_4cb=parseInt(_4c7[_4ca],10),_4cc=this._resize,_4cd=dojo.hitch(this.container,"_layoutChildren",this.child.id),de=dojo.doc;
this._handlers=(this._handlers||[]).concat([dojo.connect(de,"onmousemove",this._drag=function(e,_4ce){
var _4cf=e[axis]-_4c6,_4d0=_4c4*_4cf+_4c8,_4d1=Math.max(Math.min(_4d0,max),min);
if(_4cc||_4ce){
_4cd(_4d1);
}
_4c7[_4ca]=_4cf+_4cb+_4c4*(_4d1-_4d0)+"px";
}),dojo.connect(de,"ondragstart",dojo.stopEvent),dojo.connect(dojo.body(),"onselectstart",dojo.stopEvent),dojo.connect(de,"onmouseup",this,"_stopDrag")]);
dojo.stopEvent(e);
},_onMouse:function(e){
var o=(e.type=="mouseover"||e.type=="mouseenter");
dojo.toggleClass(this.domNode,"dijitSplitterHover",o);
dojo.toggleClass(this.domNode,"dijitSplitter"+(this.horizontal?"H":"V")+"Hover",o);
},_stopDrag:function(e){
try{
if(this.cover){
dojo.removeClass(this.cover,"dijitSplitterCoverActive");
}
if(this.fake){
dojo.destroy(this.fake);
}
dojo.removeClass(this.domNode,"dijitSplitterActive dijitSplitter"+(this.horizontal?"H":"V")+"Active dijitSplitterShadow");
this._drag(e);
this._drag(e,true);
}
finally{
this._cleanupHandlers();
delete this._drag;
}
if(this.container.persist){
dojo.cookie(this._cookieName,this.child.domNode.style[this.horizontal?"height":"width"],{expires:365});
}
},_cleanupHandlers:function(){
dojo.forEach(this._handlers,dojo.disconnect);
delete this._handlers;
},_onKeyPress:function(e){
this._resize=true;
var _4d2=this.horizontal;
var tick=1;
var dk=dojo.keys;
switch(e.charOrCode){
case _4d2?dk.UP_ARROW:dk.LEFT_ARROW:
tick*=-1;
case _4d2?dk.DOWN_ARROW:dk.RIGHT_ARROW:
break;
default:
return;
}
var _4d3=dojo._getMarginSize(this.child.domNode)[_4d2?"h":"w"]+this._factor*tick;
this.container._layoutChildren(this.child.id,Math.max(Math.min(_4d3,this._computeMaxSize()),this.child.minSize));
dojo.stopEvent(e);
},destroy:function(){
this._cleanupHandlers();
delete this.child;
delete this.container;
delete this.cover;
delete this.fake;
this.inherited(arguments);
}});
dojo.declare("dijit.layout._Gutter",[dijit._Widget,dijit._Templated],{templateString:"<div class=\"dijitGutter\" role=\"presentation\"></div>",postMixInProperties:function(){
this.inherited(arguments);
this.horizontal=/top|bottom/.test(this.region);
},buildRendering:function(){
this.inherited(arguments);
dojo.addClass(this.domNode,"dijitGutter"+(this.horizontal?"H":"V"));
}});
}
if(!dojo._hasResource["dojo.data.util.filter"]){
dojo._hasResource["dojo.data.util.filter"]=true;
dojo.provide("dojo.data.util.filter");
dojo.getObject("data.util.filter",true,dojo);
dojo.data.util.filter.patternToRegExp=function(_4d4,_4d5){
var rxp="^";
var c=null;
for(var i=0;i<_4d4.length;i++){
c=_4d4.charAt(i);
switch(c){
case "\\":
rxp+=c;
i++;
rxp+=_4d4.charAt(i);
break;
case "*":
rxp+=".*";
break;
case "?":
rxp+=".";
break;
case "$":
case "^":
case "/":
case "+":
case ".":
case "|":
case "(":
case ")":
case "{":
case "}":
case "[":
case "]":
rxp+="\\";
default:
rxp+=c;
}
}
rxp+="$";
if(_4d5){
return new RegExp(rxp,"mi");
}else{
return new RegExp(rxp,"m");
}
};
}
if(!dojo._hasResource["dojo.data.util.sorter"]){
dojo._hasResource["dojo.data.util.sorter"]=true;
dojo.provide("dojo.data.util.sorter");
dojo.getObject("data.util.sorter",true,dojo);
dojo.data.util.sorter.basicComparator=function(a,b){
var r=-1;
if(a===null){
a=undefined;
}
if(b===null){
b=undefined;
}
if(a==b){
r=0;
}else{
if(a>b||a==null){
r=1;
}
}
return r;
};
dojo.data.util.sorter.createSortFunction=function(_4d6,_4d7){
var _4d8=[];
function _4d9(attr,dir,comp,s){
return function(_4da,_4db){
var a=s.getValue(_4da,attr);
var b=s.getValue(_4db,attr);
return dir*comp(a,b);
};
};
var _4dc;
var map=_4d7.comparatorMap;
var bc=dojo.data.util.sorter.basicComparator;
for(var i=0;i<_4d6.length;i++){
_4dc=_4d6[i];
var attr=_4dc.attribute;
if(attr){
var dir=(_4dc.descending)?-1:1;
var comp=bc;
if(map){
if(typeof attr!=="string"&&("toString" in attr)){
attr=attr.toString();
}
comp=map[attr]||bc;
}
_4d8.push(_4d9(attr,dir,comp,_4d7));
}
}
return function(rowA,rowB){
var i=0;
while(i<_4d8.length){
var ret=_4d8[i++](rowA,rowB);
if(ret!==0){
return ret;
}
}
return 0;
};
};
}
if(!dojo._hasResource["dojo.data.util.simpleFetch"]){
dojo._hasResource["dojo.data.util.simpleFetch"]=true;
dojo.provide("dojo.data.util.simpleFetch");
dojo.getObject("data.util.simpleFetch",true,dojo);
dojo.data.util.simpleFetch.fetch=function(_4dd){
_4dd=_4dd||{};
if(!_4dd.store){
_4dd.store=this;
}
var self=this;
var _4de=function(_4df,_4e0){
if(_4e0.onError){
var _4e1=_4e0.scope||dojo.global;
_4e0.onError.call(_4e1,_4df,_4e0);
}
};
var _4e2=function(_4e3,_4e4){
var _4e5=_4e4.abort||null;
var _4e6=false;
var _4e7=_4e4.start?_4e4.start:0;
var _4e8=(_4e4.count&&(_4e4.count!==Infinity))?(_4e7+_4e4.count):_4e3.length;
_4e4.abort=function(){
_4e6=true;
if(_4e5){
_4e5.call(_4e4);
}
};
var _4e9=_4e4.scope||dojo.global;
if(!_4e4.store){
_4e4.store=self;
}
if(_4e4.onBegin){
_4e4.onBegin.call(_4e9,_4e3.length,_4e4);
}
if(_4e4.sort){
_4e3.sort(dojo.data.util.sorter.createSortFunction(_4e4.sort,self));
}
if(_4e4.onItem){
for(var i=_4e7;(i<_4e3.length)&&(i<_4e8);++i){
var item=_4e3[i];
if(!_4e6){
_4e4.onItem.call(_4e9,item,_4e4);
}
}
}
if(_4e4.onComplete&&!_4e6){
var _4ea=null;
if(!_4e4.onItem){
_4ea=_4e3.slice(_4e7,_4e8);
}
_4e4.onComplete.call(_4e9,_4ea,_4e4);
}
};
this._fetchItems(_4dd,_4e2,_4de);
return _4dd;
};
}
if(!dojo._hasResource["dojo.data.ItemFileReadStore"]){
dojo._hasResource["dojo.data.ItemFileReadStore"]=true;
dojo.provide("dojo.data.ItemFileReadStore");
dojo.declare("dojo.data.ItemFileReadStore",null,{constructor:function(_4eb){
this._arrayOfAllItems=[];
this._arrayOfTopLevelItems=[];
this._loadFinished=false;
this._jsonFileUrl=_4eb.url;
this._ccUrl=_4eb.url;
this.url=_4eb.url;
this._jsonData=_4eb.data;
this.data=null;
this._datatypeMap=_4eb.typeMap||{};
if(!this._datatypeMap["Date"]){
this._datatypeMap["Date"]={type:Date,deserialize:function(_4ec){
return dojo.date.stamp.fromISOString(_4ec);
}};
}
this._features={"dojo.data.api.Read":true,"dojo.data.api.Identity":true};
this._itemsByIdentity=null;
this._storeRefPropName="_S";
this._itemNumPropName="_0";
this._rootItemPropName="_RI";
this._reverseRefMap="_RRM";
this._loadInProgress=false;
this._queuedFetches=[];
if(_4eb.urlPreventCache!==undefined){
this.urlPreventCache=_4eb.urlPreventCache?true:false;
}
if(_4eb.hierarchical!==undefined){
this.hierarchical=_4eb.hierarchical?true:false;
}
if(_4eb.clearOnClose){
this.clearOnClose=true;
}
if("failOk" in _4eb){
this.failOk=_4eb.failOk?true:false;
}
},url:"",_ccUrl:"",data:null,typeMap:null,clearOnClose:false,urlPreventCache:false,failOk:false,hierarchical:true,_assertIsItem:function(item){
if(!this.isItem(item)){
throw new Error("dojo.data.ItemFileReadStore: Invalid item argument.");
}
},_assertIsAttribute:function(_4ed){
if(typeof _4ed!=="string"){
throw new Error("dojo.data.ItemFileReadStore: Invalid attribute argument.");
}
},getValue:function(item,_4ee,_4ef){
var _4f0=this.getValues(item,_4ee);
return (_4f0.length>0)?_4f0[0]:_4ef;
},getValues:function(item,_4f1){
this._assertIsItem(item);
this._assertIsAttribute(_4f1);
return (item[_4f1]||[]).slice(0);
},getAttributes:function(item){
this._assertIsItem(item);
var _4f2=[];
for(var key in item){
if((key!==this._storeRefPropName)&&(key!==this._itemNumPropName)&&(key!==this._rootItemPropName)&&(key!==this._reverseRefMap)){
_4f2.push(key);
}
}
return _4f2;
},hasAttribute:function(item,_4f3){
this._assertIsItem(item);
this._assertIsAttribute(_4f3);
return (_4f3 in item);
},containsValue:function(item,_4f4,_4f5){
var _4f6=undefined;
if(typeof _4f5==="string"){
_4f6=dojo.data.util.filter.patternToRegExp(_4f5,false);
}
return this._containsValue(item,_4f4,_4f5,_4f6);
},_containsValue:function(item,_4f7,_4f8,_4f9){
return dojo.some(this.getValues(item,_4f7),function(_4fa){
if(_4fa!==null&&!dojo.isObject(_4fa)&&_4f9){
if(_4fa.toString().match(_4f9)){
return true;
}
}else{
if(_4f8===_4fa){
return true;
}
}
});
},isItem:function(_4fb){
if(_4fb&&_4fb[this._storeRefPropName]===this){
if(this._arrayOfAllItems[_4fb[this._itemNumPropName]]===_4fb){
return true;
}
}
return false;
},isItemLoaded:function(_4fc){
return this.isItem(_4fc);
},loadItem:function(_4fd){
this._assertIsItem(_4fd.item);
},getFeatures:function(){
return this._features;
},getLabel:function(item){
if(this._labelAttr&&this.isItem(item)){
return this.getValue(item,this._labelAttr);
}
return undefined;
},getLabelAttributes:function(item){
if(this._labelAttr){
return [this._labelAttr];
}
return null;
},_fetchItems:function(_4fe,_4ff,_500){
var self=this,_501=function(_502,_503){
var _504=[],i,key;
if(_502.query){
var _505,_506=_502.queryOptions?_502.queryOptions.ignoreCase:false;
var _507={};
for(key in _502.query){
_505=_502.query[key];
if(typeof _505==="string"){
_507[key]=dojo.data.util.filter.patternToRegExp(_505,_506);
}else{
if(_505 instanceof RegExp){
_507[key]=_505;
}
}
}
for(i=0;i<_503.length;++i){
var _508=true;
var _509=_503[i];
if(_509===null){
_508=false;
}else{
for(key in _502.query){
_505=_502.query[key];
if(!self._containsValue(_509,key,_505,_507[key])){
_508=false;
}
}
}
if(_508){
_504.push(_509);
}
}
_4ff(_504,_502);
}else{
for(i=0;i<_503.length;++i){
var item=_503[i];
if(item!==null){
_504.push(item);
}
}
_4ff(_504,_502);
}
};
if(this._loadFinished){
_501(_4fe,this._getItemsArray(_4fe.queryOptions));
}else{
if(this._jsonFileUrl!==this._ccUrl){
dojo.deprecated("dojo.data.ItemFileReadStore: ","To change the url, set the url property of the store,"+" not _jsonFileUrl.  _jsonFileUrl support will be removed in 2.0");
this._ccUrl=this._jsonFileUrl;
this.url=this._jsonFileUrl;
}else{
if(this.url!==this._ccUrl){
this._jsonFileUrl=this.url;
this._ccUrl=this.url;
}
}
if(this.data!=null){
this._jsonData=this.data;
this.data=null;
}
if(this._jsonFileUrl){
if(this._loadInProgress){
this._queuedFetches.push({args:_4fe,filter:_501});
}else{
this._loadInProgress=true;
var _50a={url:self._jsonFileUrl,handleAs:"json-comment-optional",preventCache:this.urlPreventCache,failOk:this.failOk};
var _50b=dojo.xhrGet(_50a);
_50b.addCallback(function(data){
try{
self._getItemsFromLoadedData(data);
self._loadFinished=true;
self._loadInProgress=false;
_501(_4fe,self._getItemsArray(_4fe.queryOptions));
self._handleQueuedFetches();
}
catch(e){
self._loadFinished=true;
self._loadInProgress=false;
_500(e,_4fe);
}
});
_50b.addErrback(function(_50c){
self._loadInProgress=false;
_500(_50c,_4fe);
});
var _50d=null;
if(_4fe.abort){
_50d=_4fe.abort;
}
_4fe.abort=function(){
var df=_50b;
if(df&&df.fired===-1){
df.cancel();
df=null;
}
if(_50d){
_50d.call(_4fe);
}
};
}
}else{
if(this._jsonData){
try{
this._loadFinished=true;
this._getItemsFromLoadedData(this._jsonData);
this._jsonData=null;
_501(_4fe,this._getItemsArray(_4fe.queryOptions));
}
catch(e){
_500(e,_4fe);
}
}else{
_500(new Error("dojo.data.ItemFileReadStore: No JSON source data was provided as either URL or a nested Javascript object."),_4fe);
}
}
}
},_handleQueuedFetches:function(){
if(this._queuedFetches.length>0){
for(var i=0;i<this._queuedFetches.length;i++){
var _50e=this._queuedFetches[i],_50f=_50e.args,_510=_50e.filter;
if(_510){
_510(_50f,this._getItemsArray(_50f.queryOptions));
}else{
this.fetchItemByIdentity(_50f);
}
}
this._queuedFetches=[];
}
},_getItemsArray:function(_511){
if(_511&&_511.deep){
return this._arrayOfAllItems;
}
return this._arrayOfTopLevelItems;
},close:function(_512){
if(this.clearOnClose&&this._loadFinished&&!this._loadInProgress){
if(((this._jsonFileUrl==""||this._jsonFileUrl==null)&&(this.url==""||this.url==null))&&this.data==null){
}
this._arrayOfAllItems=[];
this._arrayOfTopLevelItems=[];
this._loadFinished=false;
this._itemsByIdentity=null;
this._loadInProgress=false;
this._queuedFetches=[];
}
},_getItemsFromLoadedData:function(_513){
var _514=false,self=this;
function _515(_516){
var _517=((_516!==null)&&(typeof _516==="object")&&(!dojo.isArray(_516)||_514)&&(!dojo.isFunction(_516))&&(_516.constructor==Object||dojo.isArray(_516))&&(typeof _516._reference==="undefined")&&(typeof _516._type==="undefined")&&(typeof _516._value==="undefined")&&self.hierarchical);
return _517;
};
function _518(_519){
self._arrayOfAllItems.push(_519);
for(var _51a in _519){
var _51b=_519[_51a];
if(_51b){
if(dojo.isArray(_51b)){
var _51c=_51b;
for(var k=0;k<_51c.length;++k){
var _51d=_51c[k];
if(_515(_51d)){
_518(_51d);
}
}
}else{
if(_515(_51b)){
_518(_51b);
}
}
}
}
};
this._labelAttr=_513.label;
var i,item;
this._arrayOfAllItems=[];
this._arrayOfTopLevelItems=_513.items;
for(i=0;i<this._arrayOfTopLevelItems.length;++i){
item=this._arrayOfTopLevelItems[i];
if(dojo.isArray(item)){
_514=true;
}
_518(item);
item[this._rootItemPropName]=true;
}
var _51e={},key;
for(i=0;i<this._arrayOfAllItems.length;++i){
item=this._arrayOfAllItems[i];
for(key in item){
if(key!==this._rootItemPropName){
var _51f=item[key];
if(_51f!==null){
if(!dojo.isArray(_51f)){
item[key]=[_51f];
}
}else{
item[key]=[null];
}
}
_51e[key]=key;
}
}
while(_51e[this._storeRefPropName]){
this._storeRefPropName+="_";
}
while(_51e[this._itemNumPropName]){
this._itemNumPropName+="_";
}
while(_51e[this._reverseRefMap]){
this._reverseRefMap+="_";
}
var _520;
var _521=_513.identifier;
if(_521){
this._itemsByIdentity={};
this._features["dojo.data.api.Identity"]=_521;
for(i=0;i<this._arrayOfAllItems.length;++i){
item=this._arrayOfAllItems[i];
_520=item[_521];
var _522=_520[0];
if(!Object.hasOwnProperty.call(this._itemsByIdentity,_522)){
this._itemsByIdentity[_522]=item;
}else{
if(this._jsonFileUrl){
throw new Error("dojo.data.ItemFileReadStore:  The json data as specified by: ["+this._jsonFileUrl+"] is malformed.  Items within the list have identifier: ["+_521+"].  Value collided: ["+_522+"]");
}else{
if(this._jsonData){
throw new Error("dojo.data.ItemFileReadStore:  The json data provided by the creation arguments is malformed.  Items within the list have identifier: ["+_521+"].  Value collided: ["+_522+"]");
}
}
}
}
}else{
this._features["dojo.data.api.Identity"]=Number;
}
for(i=0;i<this._arrayOfAllItems.length;++i){
item=this._arrayOfAllItems[i];
item[this._storeRefPropName]=this;
item[this._itemNumPropName]=i;
}
for(i=0;i<this._arrayOfAllItems.length;++i){
item=this._arrayOfAllItems[i];
for(key in item){
_520=item[key];
for(var j=0;j<_520.length;++j){
_51f=_520[j];
if(_51f!==null&&typeof _51f=="object"){
if(("_type" in _51f)&&("_value" in _51f)){
var type=_51f._type;
var _523=this._datatypeMap[type];
if(!_523){
throw new Error("dojo.data.ItemFileReadStore: in the typeMap constructor arg, no object class was specified for the datatype '"+type+"'");
}else{
if(dojo.isFunction(_523)){
_520[j]=new _523(_51f._value);
}else{
if(dojo.isFunction(_523.deserialize)){
_520[j]=_523.deserialize(_51f._value);
}else{
throw new Error("dojo.data.ItemFileReadStore: Value provided in typeMap was neither a constructor, nor a an object with a deserialize function");
}
}
}
}
if(_51f._reference){
var _524=_51f._reference;
if(!dojo.isObject(_524)){
_520[j]=this._getItemByIdentity(_524);
}else{
for(var k=0;k<this._arrayOfAllItems.length;++k){
var _525=this._arrayOfAllItems[k],_526=true;
for(var _527 in _524){
if(_525[_527]!=_524[_527]){
_526=false;
}
}
if(_526){
_520[j]=_525;
}
}
}
if(this.referenceIntegrity){
var _528=_520[j];
if(this.isItem(_528)){
this._addReferenceToMap(_528,item,key);
}
}
}else{
if(this.isItem(_51f)){
if(this.referenceIntegrity){
this._addReferenceToMap(_51f,item,key);
}
}
}
}
}
}
}
},_addReferenceToMap:function(_529,_52a,_52b){
},getIdentity:function(item){
var _52c=this._features["dojo.data.api.Identity"];
if(_52c===Number){
return item[this._itemNumPropName];
}else{
var _52d=item[_52c];
if(_52d){
return _52d[0];
}
}
return null;
},fetchItemByIdentity:function(_52e){
var item,_52f;
if(!this._loadFinished){
var self=this;
if(this._jsonFileUrl!==this._ccUrl){
dojo.deprecated("dojo.data.ItemFileReadStore: ","To change the url, set the url property of the store,"+" not _jsonFileUrl.  _jsonFileUrl support will be removed in 2.0");
this._ccUrl=this._jsonFileUrl;
this.url=this._jsonFileUrl;
}else{
if(this.url!==this._ccUrl){
this._jsonFileUrl=this.url;
this._ccUrl=this.url;
}
}
if(this.data!=null&&this._jsonData==null){
this._jsonData=this.data;
this.data=null;
}
if(this._jsonFileUrl){
if(this._loadInProgress){
this._queuedFetches.push({args:_52e});
}else{
this._loadInProgress=true;
var _530={url:self._jsonFileUrl,handleAs:"json-comment-optional",preventCache:this.urlPreventCache,failOk:this.failOk};
var _531=dojo.xhrGet(_530);
_531.addCallback(function(data){
var _532=_52e.scope?_52e.scope:dojo.global;
try{
self._getItemsFromLoadedData(data);
self._loadFinished=true;
self._loadInProgress=false;
item=self._getItemByIdentity(_52e.identity);
if(_52e.onItem){
_52e.onItem.call(_532,item);
}
self._handleQueuedFetches();
}
catch(error){
self._loadInProgress=false;
if(_52e.onError){
_52e.onError.call(_532,error);
}
}
});
_531.addErrback(function(_533){
self._loadInProgress=false;
if(_52e.onError){
var _534=_52e.scope?_52e.scope:dojo.global;
_52e.onError.call(_534,_533);
}
});
}
}else{
if(this._jsonData){
self._getItemsFromLoadedData(self._jsonData);
self._jsonData=null;
self._loadFinished=true;
item=self._getItemByIdentity(_52e.identity);
if(_52e.onItem){
_52f=_52e.scope?_52e.scope:dojo.global;
_52e.onItem.call(_52f,item);
}
}
}
}else{
item=this._getItemByIdentity(_52e.identity);
if(_52e.onItem){
_52f=_52e.scope?_52e.scope:dojo.global;
_52e.onItem.call(_52f,item);
}
}
},_getItemByIdentity:function(_535){
var item=null;
if(this._itemsByIdentity&&Object.hasOwnProperty.call(this._itemsByIdentity,_535)){
item=this._itemsByIdentity[_535];
}else{
if(Object.hasOwnProperty.call(this._arrayOfAllItems,_535)){
item=this._arrayOfAllItems[_535];
}
}
if(item===undefined){
item=null;
}
return item;
},getIdentityAttributes:function(item){
var _536=this._features["dojo.data.api.Identity"];
if(_536===Number){
return null;
}else{
return [_536];
}
},_forceLoad:function(){
var self=this;
if(this._jsonFileUrl!==this._ccUrl){
dojo.deprecated("dojo.data.ItemFileReadStore: ","To change the url, set the url property of the store,"+" not _jsonFileUrl.  _jsonFileUrl support will be removed in 2.0");
this._ccUrl=this._jsonFileUrl;
this.url=this._jsonFileUrl;
}else{
if(this.url!==this._ccUrl){
this._jsonFileUrl=this.url;
this._ccUrl=this.url;
}
}
if(this.data!=null){
this._jsonData=this.data;
this.data=null;
}
if(this._jsonFileUrl){
var _537={url:this._jsonFileUrl,handleAs:"json-comment-optional",preventCache:this.urlPreventCache,failOk:this.failOk,sync:true};
var _538=dojo.xhrGet(_537);
_538.addCallback(function(data){
try{
if(self._loadInProgress!==true&&!self._loadFinished){
self._getItemsFromLoadedData(data);
self._loadFinished=true;
}else{
if(self._loadInProgress){
throw new Error("dojo.data.ItemFileReadStore:  Unable to perform a synchronous load, an async load is in progress.");
}
}
}
catch(e){
throw e;
}
});
_538.addErrback(function(_539){
throw _539;
});
}else{
if(this._jsonData){
self._getItemsFromLoadedData(self._jsonData);
self._jsonData=null;
self._loadFinished=true;
}
}
}});
dojo.extend(dojo.data.ItemFileReadStore,dojo.data.util.simpleFetch);
}
if(!dojo._hasResource["dojo.data.ItemFileWriteStore"]){
dojo._hasResource["dojo.data.ItemFileWriteStore"]=true;
dojo.provide("dojo.data.ItemFileWriteStore");
dojo.declare("dojo.data.ItemFileWriteStore",dojo.data.ItemFileReadStore,{constructor:function(_53a){
this._features["dojo.data.api.Write"]=true;
this._features["dojo.data.api.Notification"]=true;
this._pending={_newItems:{},_modifiedItems:{},_deletedItems:{}};
if(!this._datatypeMap["Date"].serialize){
this._datatypeMap["Date"].serialize=function(obj){
return dojo.date.stamp.toISOString(obj,{zulu:true});
};
}
if(_53a&&(_53a.referenceIntegrity===false)){
this.referenceIntegrity=false;
}
this._saveInProgress=false;
},referenceIntegrity:true,_assert:function(_53b){
if(!_53b){
throw new Error("assertion failed in ItemFileWriteStore");
}
},_getIdentifierAttribute:function(){
var _53c=this.getFeatures()["dojo.data.api.Identity"];
return _53c;
},newItem:function(_53d,_53e){
this._assert(!this._saveInProgress);
if(!this._loadFinished){
this._forceLoad();
}
if(typeof _53d!="object"&&typeof _53d!="undefined"){
throw new Error("newItem() was passed something other than an object");
}
var _53f=null;
var _540=this._getIdentifierAttribute();
if(_540===Number){
_53f=this._arrayOfAllItems.length;
}else{
_53f=_53d[_540];
if(typeof _53f==="undefined"){
throw new Error("newItem() was not passed an identity for the new item");
}
if(dojo.isArray(_53f)){
throw new Error("newItem() was not passed an single-valued identity");
}
}
if(this._itemsByIdentity){
this._assert(typeof this._itemsByIdentity[_53f]==="undefined");
}
this._assert(typeof this._pending._newItems[_53f]==="undefined");
this._assert(typeof this._pending._deletedItems[_53f]==="undefined");
var _541={};
_541[this._storeRefPropName]=this;
_541[this._itemNumPropName]=this._arrayOfAllItems.length;
if(this._itemsByIdentity){
this._itemsByIdentity[_53f]=_541;
_541[_540]=[_53f];
}
this._arrayOfAllItems.push(_541);
var _542=null;
if(_53e&&_53e.parent&&_53e.attribute){
_542={item:_53e.parent,attribute:_53e.attribute,oldValue:undefined};
var _543=this.getValues(_53e.parent,_53e.attribute);
if(_543&&_543.length>0){
var _544=_543.slice(0,_543.length);
if(_543.length===1){
_542.oldValue=_543[0];
}else{
_542.oldValue=_543.slice(0,_543.length);
}
_544.push(_541);
this._setValueOrValues(_53e.parent,_53e.attribute,_544,false);
_542.newValue=this.getValues(_53e.parent,_53e.attribute);
}else{
this._setValueOrValues(_53e.parent,_53e.attribute,_541,false);
_542.newValue=_541;
}
}else{
_541[this._rootItemPropName]=true;
this._arrayOfTopLevelItems.push(_541);
}
this._pending._newItems[_53f]=_541;
for(var key in _53d){
if(key===this._storeRefPropName||key===this._itemNumPropName){
throw new Error("encountered bug in ItemFileWriteStore.newItem");
}
var _545=_53d[key];
if(!dojo.isArray(_545)){
_545=[_545];
}
_541[key]=_545;
if(this.referenceIntegrity){
for(var i=0;i<_545.length;i++){
var val=_545[i];
if(this.isItem(val)){
this._addReferenceToMap(val,_541,key);
}
}
}
}
this.onNew(_541,_542);
return _541;
},_removeArrayElement:function(_546,_547){
var _548=dojo.indexOf(_546,_547);
if(_548!=-1){
_546.splice(_548,1);
return true;
}
return false;
},deleteItem:function(item){
this._assert(!this._saveInProgress);
this._assertIsItem(item);
var _549=item[this._itemNumPropName];
var _54a=this.getIdentity(item);
if(this.referenceIntegrity){
var _54b=this.getAttributes(item);
if(item[this._reverseRefMap]){
item["backup_"+this._reverseRefMap]=dojo.clone(item[this._reverseRefMap]);
}
dojo.forEach(_54b,function(_54c){
dojo.forEach(this.getValues(item,_54c),function(_54d){
if(this.isItem(_54d)){
if(!item["backupRefs_"+this._reverseRefMap]){
item["backupRefs_"+this._reverseRefMap]=[];
}
item["backupRefs_"+this._reverseRefMap].push({id:this.getIdentity(_54d),attr:_54c});
this._removeReferenceFromMap(_54d,item,_54c);
}
},this);
},this);
var _54e=item[this._reverseRefMap];
if(_54e){
for(var _54f in _54e){
var _550=null;
if(this._itemsByIdentity){
_550=this._itemsByIdentity[_54f];
}else{
_550=this._arrayOfAllItems[_54f];
}
if(_550){
for(var _551 in _54e[_54f]){
var _552=this.getValues(_550,_551)||[];
var _553=dojo.filter(_552,function(_554){
return !(this.isItem(_554)&&this.getIdentity(_554)==_54a);
},this);
this._removeReferenceFromMap(item,_550,_551);
if(_553.length<_552.length){
this._setValueOrValues(_550,_551,_553,true);
}
}
}
}
}
}
this._arrayOfAllItems[_549]=null;
item[this._storeRefPropName]=null;
if(this._itemsByIdentity){
delete this._itemsByIdentity[_54a];
}
this._pending._deletedItems[_54a]=item;
if(item[this._rootItemPropName]){
this._removeArrayElement(this._arrayOfTopLevelItems,item);
}
this.onDelete(item);
return true;
},setValue:function(item,_555,_556){
return this._setValueOrValues(item,_555,_556,true);
},setValues:function(item,_557,_558){
return this._setValueOrValues(item,_557,_558,true);
},unsetAttribute:function(item,_559){
return this._setValueOrValues(item,_559,[],true);
},_setValueOrValues:function(item,_55a,_55b,_55c){
this._assert(!this._saveInProgress);
this._assertIsItem(item);
this._assert(dojo.isString(_55a));
this._assert(typeof _55b!=="undefined");
var _55d=this._getIdentifierAttribute();
if(_55a==_55d){
throw new Error("ItemFileWriteStore does not have support for changing the value of an item's identifier.");
}
var _55e=this._getValueOrValues(item,_55a);
var _55f=this.getIdentity(item);
if(!this._pending._modifiedItems[_55f]){
var _560={};
for(var key in item){
if((key===this._storeRefPropName)||(key===this._itemNumPropName)||(key===this._rootItemPropName)){
_560[key]=item[key];
}else{
if(key===this._reverseRefMap){
_560[key]=dojo.clone(item[key]);
}else{
_560[key]=item[key].slice(0,item[key].length);
}
}
}
this._pending._modifiedItems[_55f]=_560;
}
var _561=false;
if(dojo.isArray(_55b)&&_55b.length===0){
_561=delete item[_55a];
_55b=undefined;
if(this.referenceIntegrity&&_55e){
var _562=_55e;
if(!dojo.isArray(_562)){
_562=[_562];
}
for(var i=0;i<_562.length;i++){
var _563=_562[i];
if(this.isItem(_563)){
this._removeReferenceFromMap(_563,item,_55a);
}
}
}
}else{
var _564;
if(dojo.isArray(_55b)){
var _565=_55b;
_564=_55b.slice(0,_55b.length);
}else{
_564=[_55b];
}
if(this.referenceIntegrity){
if(_55e){
var _562=_55e;
if(!dojo.isArray(_562)){
_562=[_562];
}
var map={};
dojo.forEach(_562,function(_566){
if(this.isItem(_566)){
var id=this.getIdentity(_566);
map[id.toString()]=true;
}
},this);
dojo.forEach(_564,function(_567){
if(this.isItem(_567)){
var id=this.getIdentity(_567);
if(map[id.toString()]){
delete map[id.toString()];
}else{
this._addReferenceToMap(_567,item,_55a);
}
}
},this);
for(var rId in map){
var _568;
if(this._itemsByIdentity){
_568=this._itemsByIdentity[rId];
}else{
_568=this._arrayOfAllItems[rId];
}
this._removeReferenceFromMap(_568,item,_55a);
}
}else{
for(var i=0;i<_564.length;i++){
var _563=_564[i];
if(this.isItem(_563)){
this._addReferenceToMap(_563,item,_55a);
}
}
}
}
item[_55a]=_564;
_561=true;
}
if(_55c){
this.onSet(item,_55a,_55e,_55b);
}
return _561;
},_addReferenceToMap:function(_569,_56a,_56b){
var _56c=this.getIdentity(_56a);
var _56d=_569[this._reverseRefMap];
if(!_56d){
_56d=_569[this._reverseRefMap]={};
}
var _56e=_56d[_56c];
if(!_56e){
_56e=_56d[_56c]={};
}
_56e[_56b]=true;
},_removeReferenceFromMap:function(_56f,_570,_571){
var _572=this.getIdentity(_570);
var _573=_56f[this._reverseRefMap];
var _574;
if(_573){
for(_574 in _573){
if(_574==_572){
delete _573[_574][_571];
if(this._isEmpty(_573[_574])){
delete _573[_574];
}
}
}
if(this._isEmpty(_573)){
delete _56f[this._reverseRefMap];
}
}
},_dumpReferenceMap:function(){
var i;
for(i=0;i<this._arrayOfAllItems.length;i++){
var item=this._arrayOfAllItems[i];
if(item&&item[this._reverseRefMap]){
}
}
},_getValueOrValues:function(item,_575){
var _576=undefined;
if(this.hasAttribute(item,_575)){
var _577=this.getValues(item,_575);
if(_577.length==1){
_576=_577[0];
}else{
_576=_577;
}
}
return _576;
},_flatten:function(_578){
if(this.isItem(_578)){
var item=_578;
var _579=this.getIdentity(item);
var _57a={_reference:_579};
return _57a;
}else{
if(typeof _578==="object"){
for(var type in this._datatypeMap){
var _57b=this._datatypeMap[type];
if(dojo.isObject(_57b)&&!dojo.isFunction(_57b)){
if(_578 instanceof _57b.type){
if(!_57b.serialize){
throw new Error("ItemFileWriteStore:  No serializer defined for type mapping: ["+type+"]");
}
return {_type:type,_value:_57b.serialize(_578)};
}
}else{
if(_578 instanceof _57b){
return {_type:type,_value:_578.toString()};
}
}
}
}
return _578;
}
},_getNewFileContentString:function(){
var _57c={};
var _57d=this._getIdentifierAttribute();
if(_57d!==Number){
_57c.identifier=_57d;
}
if(this._labelAttr){
_57c.label=this._labelAttr;
}
_57c.items=[];
for(var i=0;i<this._arrayOfAllItems.length;++i){
var item=this._arrayOfAllItems[i];
if(item!==null){
var _57e={};
for(var key in item){
if(key!==this._storeRefPropName&&key!==this._itemNumPropName&&key!==this._reverseRefMap&&key!==this._rootItemPropName){
var _57f=key;
var _580=this.getValues(item,_57f);
if(_580.length==1){
_57e[_57f]=this._flatten(_580[0]);
}else{
var _581=[];
for(var j=0;j<_580.length;++j){
_581.push(this._flatten(_580[j]));
_57e[_57f]=_581;
}
}
}
}
_57c.items.push(_57e);
}
}
var _582=true;
return dojo.toJson(_57c,_582);
},_isEmpty:function(_583){
var _584=true;
if(dojo.isObject(_583)){
var i;
for(i in _583){
_584=false;
break;
}
}else{
if(dojo.isArray(_583)){
if(_583.length>0){
_584=false;
}
}
}
return _584;
},save:function(_585){
this._assert(!this._saveInProgress);
this._saveInProgress=true;
var self=this;
var _586=function(){
self._pending={_newItems:{},_modifiedItems:{},_deletedItems:{}};
self._saveInProgress=false;
if(_585&&_585.onComplete){
var _587=_585.scope||dojo.global;
_585.onComplete.call(_587);
}
};
var _588=function(err){
self._saveInProgress=false;
if(_585&&_585.onError){
var _589=_585.scope||dojo.global;
_585.onError.call(_589,err);
}
};
if(this._saveEverything){
var _58a=this._getNewFileContentString();
this._saveEverything(_586,_588,_58a);
}
if(this._saveCustom){
this._saveCustom(_586,_588);
}
if(!this._saveEverything&&!this._saveCustom){
_586();
}
},revert:function(){
this._assert(!this._saveInProgress);
var _58b;
for(_58b in this._pending._modifiedItems){
var _58c=this._pending._modifiedItems[_58b];
var _58d=null;
if(this._itemsByIdentity){
_58d=this._itemsByIdentity[_58b];
}else{
_58d=this._arrayOfAllItems[_58b];
}
_58c[this._storeRefPropName]=this;
for(key in _58d){
delete _58d[key];
}
dojo.mixin(_58d,_58c);
}
var _58e;
for(_58b in this._pending._deletedItems){
_58e=this._pending._deletedItems[_58b];
_58e[this._storeRefPropName]=this;
var _58f=_58e[this._itemNumPropName];
if(_58e["backup_"+this._reverseRefMap]){
_58e[this._reverseRefMap]=_58e["backup_"+this._reverseRefMap];
delete _58e["backup_"+this._reverseRefMap];
}
this._arrayOfAllItems[_58f]=_58e;
if(this._itemsByIdentity){
this._itemsByIdentity[_58b]=_58e;
}
if(_58e[this._rootItemPropName]){
this._arrayOfTopLevelItems.push(_58e);
}
}
for(_58b in this._pending._deletedItems){
_58e=this._pending._deletedItems[_58b];
if(_58e["backupRefs_"+this._reverseRefMap]){
dojo.forEach(_58e["backupRefs_"+this._reverseRefMap],function(_590){
var _591;
if(this._itemsByIdentity){
_591=this._itemsByIdentity[_590.id];
}else{
_591=this._arrayOfAllItems[_590.id];
}
this._addReferenceToMap(_591,_58e,_590.attr);
},this);
delete _58e["backupRefs_"+this._reverseRefMap];
}
}
for(_58b in this._pending._newItems){
var _592=this._pending._newItems[_58b];
_592[this._storeRefPropName]=null;
this._arrayOfAllItems[_592[this._itemNumPropName]]=null;
if(_592[this._rootItemPropName]){
this._removeArrayElement(this._arrayOfTopLevelItems,_592);
}
if(this._itemsByIdentity){
delete this._itemsByIdentity[_58b];
}
}
this._pending={_newItems:{},_modifiedItems:{},_deletedItems:{}};
return true;
},isDirty:function(item){
if(item){
var _593=this.getIdentity(item);
return new Boolean(this._pending._newItems[_593]||this._pending._modifiedItems[_593]||this._pending._deletedItems[_593]).valueOf();
}else{
if(!this._isEmpty(this._pending._newItems)||!this._isEmpty(this._pending._modifiedItems)||!this._isEmpty(this._pending._deletedItems)){
return true;
}
return false;
}
},onSet:function(item,_594,_595,_596){
},onNew:function(_597,_598){
},onDelete:function(_599){
},close:function(_59a){
if(this.clearOnClose){
if(!this.isDirty()){
this.inherited(arguments);
}else{
throw new Error("dojo.data.ItemFileWriteStore: There are unsaved changes present in the store.  Please save or revert the changes before invoking close.");
}
}
}});
}
if(!dojo._hasResource["dijit.dijit"]){
dojo._hasResource["dijit.dijit"]=true;
dojo.provide("dijit.dijit");
}
if(!dojo._hasResource["dojox.html.metrics"]){
dojo._hasResource["dojox.html.metrics"]=true;
dojo.provide("dojox.html.metrics");
(function(){
var dhm=dojox.html.metrics;
dhm.getFontMeasurements=function(){
var _59b={"1em":0,"1ex":0,"100%":0,"12pt":0,"16px":0,"xx-small":0,"x-small":0,"small":0,"medium":0,"large":0,"x-large":0,"xx-large":0};
if(dojo.isIE){
dojo.doc.documentElement.style.fontSize="100%";
}
var div=dojo.doc.createElement("div");
var ds=div.style;
ds.position="absolute";
ds.left="-100px";
ds.top="0";
ds.width="30px";
ds.height="1000em";
ds.borderWidth="0";
ds.margin="0";
ds.padding="0";
ds.outline="0";
ds.lineHeight="1";
ds.overflow="hidden";
dojo.body().appendChild(div);
for(var p in _59b){
ds.fontSize=p;
_59b[p]=Math.round(div.offsetHeight*12/16)*16/12/1000;
}
dojo.body().removeChild(div);
div=null;
return _59b;
};
var _59c=null;
dhm.getCachedFontMeasurements=function(_59d){
if(_59d||!_59c){
_59c=dhm.getFontMeasurements();
}
return _59c;
};
var _59e=null,_59f={};
dhm.getTextBox=function(text,_5a0,_5a1){
var m,s;
if(!_59e){
m=_59e=dojo.doc.createElement("div");
var c=dojo.doc.createElement("div");
c.appendChild(m);
s=c.style;
s.overflow="scroll";
s.position="absolute";
s.left="0px";
s.top="-10000px";
s.width="1px";
s.height="1px";
s.visibility="hidden";
s.borderWidth="0";
s.margin="0";
s.padding="0";
s.outline="0";
dojo.body().appendChild(c);
}else{
m=_59e;
}
m.className="";
s=m.style;
s.borderWidth="0";
s.margin="0";
s.padding="0";
s.outline="0";
if(arguments.length>1&&_5a0){
for(var i in _5a0){
if(i in _59f){
continue;
}
s[i]=_5a0[i];
}
}
if(arguments.length>2&&_5a1){
m.className=_5a1;
}
m.innerHTML=text;
var box=dojo.position(m);
box.w=m.parentNode.scrollWidth;
return box;
};
var _5a2={w:16,h:16};
dhm.getScrollbar=function(){
return {w:_5a2.w,h:_5a2.h};
};
dhm._fontResizeNode=null;
dhm.initOnFontResize=function(_5a3){
var f=dhm._fontResizeNode=dojo.doc.createElement("iframe");
var fs=f.style;
fs.position="absolute";
fs.width="5em";
fs.height="10em";
fs.top="-10000px";
if(dojo.isIE){
f.onreadystatechange=function(){
if(f.contentWindow.document.readyState=="complete"){
f.onresize=f.contentWindow.parent[dojox._scopeName].html.metrics._fontresize;
}
};
}else{
f.onload=function(){
f.contentWindow.onresize=f.contentWindow.parent[dojox._scopeName].html.metrics._fontresize;
};
}
f.setAttribute("src","javascript:'<html><head><script>if(\"loadFirebugConsole\" in window){window.loadFirebugConsole();}</script></head><body></body></html>'");
dojo.body().appendChild(f);
dhm.initOnFontResize=function(){
};
};
dhm.onFontResize=function(){
};
dhm._fontresize=function(){
dhm.onFontResize();
};
dojo.addOnUnload(function(){
var f=dhm._fontResizeNode;
if(f){
if(dojo.isIE&&f.onresize){
f.onresize=null;
}else{
if(f.contentWindow&&f.contentWindow.onresize){
f.contentWindow.onresize=null;
}
}
dhm._fontResizeNode=null;
}
});
dojo.addOnLoad(function(){
try{
var n=dojo.doc.createElement("div");
n.style.cssText="top:0;left:0;width:100px;height:100px;overflow:scroll;position:absolute;visibility:hidden;";
dojo.body().appendChild(n);
_5a2.w=n.offsetWidth-n.clientWidth;
_5a2.h=n.offsetHeight-n.clientHeight;
dojo.body().removeChild(n);
delete n;
}
catch(e){
}
if("fontSizeWatch" in dojo.config&&!!dojo.config.fontSizeWatch){
dhm.initOnFontResize();
}
});
})();
}
if(!dojo._hasResource["dojox.grid.util"]){
dojo._hasResource["dojox.grid.util"]=true;
dojo.provide("dojox.grid.util");
(function(){
var dgu=dojox.grid.util;
dgu.na="...";
dgu.rowIndexTag="gridRowIndex";
dgu.gridViewTag="gridView";
dgu.fire=function(ob,ev,args){
var fn=ob&&ev&&ob[ev];
return fn&&(args?fn.apply(ob,args):ob[ev]());
};
dgu.setStyleHeightPx=function(_5a4,_5a5){
if(_5a5>=0){
var s=_5a4.style;
var v=_5a5+"px";
if(_5a4&&s["height"]!=v){
s["height"]=v;
}
}
};
dgu.mouseEvents=["mouseover","mouseout","mousedown","mouseup","click","dblclick","contextmenu"];
dgu.keyEvents=["keyup","keydown","keypress"];
dgu.funnelEvents=function(_5a6,_5a7,_5a8,_5a9){
var evts=(_5a9?_5a9:dgu.mouseEvents.concat(dgu.keyEvents));
for(var i=0,l=evts.length;i<l;i++){
_5a7.connect(_5a6,"on"+evts[i],_5a8);
}
};
dgu.removeNode=function(_5aa){
_5aa=dojo.byId(_5aa);
_5aa&&_5aa.parentNode&&_5aa.parentNode.removeChild(_5aa);
return _5aa;
};
dgu.arrayCompare=function(inA,inB){
for(var i=0,l=inA.length;i<l;i++){
if(inA[i]!=inB[i]){
return false;
}
}
return (inA.length==inB.length);
};
dgu.arrayInsert=function(_5ab,_5ac,_5ad){
if(_5ab.length<=_5ac){
_5ab[_5ac]=_5ad;
}else{
_5ab.splice(_5ac,0,_5ad);
}
};
dgu.arrayRemove=function(_5ae,_5af){
_5ae.splice(_5af,1);
};
dgu.arraySwap=function(_5b0,inI,inJ){
var _5b1=_5b0[inI];
_5b0[inI]=_5b0[inJ];
_5b0[inJ]=_5b1;
};
dgu.fixIEEmptyCell=function(_5b2){
if((dojo.isIE<8||(dojo.isIE&&dojo.isQuirks))&&(_5b2===null||_5b2===""||/^\s+$/.test(_5b2))){
return "&nbsp;";
}else{
return _5b2;
}
};
})();
}
if(!dojo._hasResource["dojox.grid._Scroller"]){
dojo._hasResource["dojox.grid._Scroller"]=true;
dojo.provide("dojox.grid._Scroller");
(function(){
var _5b3=function(_5b4){
var i=0,n,p=_5b4.parentNode;
while((n=p.childNodes[i++])){
if(n==_5b4){
return i-1;
}
}
return -1;
};
var _5b5=function(_5b6){
if(!_5b6){
return;
}
var _5b7=function(inW){
return inW.domNode&&dojo.isDescendant(inW.domNode,_5b6,true);
};
var ws=dijit.registry.filter(_5b7);
ws.forEach(function(w){
w.destroy();
});
delete ws;
};
var _5b8=function(_5b9){
var node=dojo.byId(_5b9);
return (node&&node.tagName?node.tagName.toLowerCase():"");
};
var _5ba=function(_5bb,_5bc){
var _5bd=[];
var i=0,n;
while((n=_5bb.childNodes[i])){
i++;
if(_5b8(n)==_5bc){
_5bd.push(n);
}
}
return _5bd;
};
var _5be=function(_5bf){
return _5ba(_5bf,"div");
};
dojo.declare("dojox.grid._Scroller",null,{constructor:function(_5c0){
this.setContentNodes(_5c0);
this.pageHeights=[];
this.pageNodes=[];
this.stack=[];
},rowCount:0,defaultRowHeight:32,keepRows:100,contentNode:null,scrollboxNode:null,defaultPageHeight:0,keepPages:10,pageCount:0,windowHeight:0,firstVisibleRow:0,lastVisibleRow:0,averageRowHeight:0,page:0,pageTop:0,init:function(_5c1,_5c2,_5c3){
switch(arguments.length){
case 3:
this.rowsPerPage=_5c3;
case 2:
this.keepRows=_5c2;
case 1:
this.rowCount=_5c1;
default:
break;
}
this.defaultPageHeight=this.defaultRowHeight*this.rowsPerPage;
this.pageCount=this._getPageCount(this.rowCount,this.rowsPerPage);
this.setKeepInfo(this.keepRows);
this.invalidate();
if(this.scrollboxNode){
this.scrollboxNode.scrollTop=0;
this.scroll(0);
this.scrollboxNode.onscroll=dojo.hitch(this,"onscroll");
}
},_getPageCount:function(_5c4,_5c5){
return _5c4?(Math.ceil(_5c4/_5c5)||1):0;
},destroy:function(){
this.invalidateNodes();
delete this.contentNodes;
delete this.contentNode;
delete this.scrollboxNode;
},setKeepInfo:function(_5c6){
this.keepRows=_5c6;
this.keepPages=!this.keepRows?this.keepPages:Math.max(Math.ceil(this.keepRows/this.rowsPerPage),2);
},setContentNodes:function(_5c7){
this.contentNodes=_5c7;
this.colCount=(this.contentNodes?this.contentNodes.length:0);
this.pageNodes=[];
for(var i=0;i<this.colCount;i++){
this.pageNodes[i]=[];
}
},getDefaultNodes:function(){
return this.pageNodes[0]||[];
},invalidate:function(){
this._invalidating=true;
this.invalidateNodes();
this.pageHeights=[];
this.height=(this.pageCount?(this.pageCount-1)*this.defaultPageHeight+this.calcLastPageHeight():0);
this.resize();
this._invalidating=false;
},updateRowCount:function(_5c8){
this.invalidateNodes();
this.rowCount=_5c8;
var _5c9=this.pageCount;
if(_5c9===0){
this.height=1;
}
this.pageCount=this._getPageCount(this.rowCount,this.rowsPerPage);
if(this.pageCount<_5c9){
for(var i=_5c9-1;i>=this.pageCount;i--){
this.height-=this.getPageHeight(i);
delete this.pageHeights[i];
}
}else{
if(this.pageCount>_5c9){
this.height+=this.defaultPageHeight*(this.pageCount-_5c9-1)+this.calcLastPageHeight();
}
}
this.resize();
},pageExists:function(_5ca){
return Boolean(this.getDefaultPageNode(_5ca));
},measurePage:function(_5cb){
if(this.grid.rowHeight){
var _5cc=this.grid.rowHeight+1;
return ((_5cb+1)*this.rowsPerPage>this.rowCount?this.rowCount-_5cb*this.rowsPerPage:this.rowsPerPage)*_5cc;
}
var n=this.getDefaultPageNode(_5cb);
return (n&&n.innerHTML)?n.offsetHeight:undefined;
},positionPage:function(_5cd,_5ce){
for(var i=0;i<this.colCount;i++){
this.pageNodes[i][_5cd].style.top=_5ce+"px";
}
},repositionPages:function(_5cf){
var _5d0=this.getDefaultNodes();
var last=0;
for(var i=0;i<this.stack.length;i++){
last=Math.max(this.stack[i],last);
}
var n=_5d0[_5cf];
var y=(n?this.getPageNodePosition(n)+this.getPageHeight(_5cf):0);
for(var p=_5cf+1;p<=last;p++){
n=_5d0[p];
if(n){
if(this.getPageNodePosition(n)==y){
return;
}
this.positionPage(p,y);
}
y+=this.getPageHeight(p);
}
},installPage:function(_5d1){
for(var i=0;i<this.colCount;i++){
this.contentNodes[i].appendChild(this.pageNodes[i][_5d1]);
}
},preparePage:function(_5d2,_5d3){
var p=(_5d3?this.popPage():null);
for(var i=0;i<this.colCount;i++){
var _5d4=this.pageNodes[i];
var _5d5=(p===null?this.createPageNode():this.invalidatePageNode(p,_5d4));
_5d5.pageIndex=_5d2;
_5d4[_5d2]=_5d5;
}
},renderPage:function(_5d6){
var _5d7=[];
var i,j;
for(i=0;i<this.colCount;i++){
_5d7[i]=this.pageNodes[i][_5d6];
}
for(i=0,j=_5d6*this.rowsPerPage;(i<this.rowsPerPage)&&(j<this.rowCount);i++,j++){
this.renderRow(j,_5d7);
}
},removePage:function(_5d8){
for(var i=0,j=_5d8*this.rowsPerPage;i<this.rowsPerPage;i++,j++){
this.removeRow(j);
}
},destroyPage:function(_5d9){
for(var i=0;i<this.colCount;i++){
var n=this.invalidatePageNode(_5d9,this.pageNodes[i]);
if(n){
dojo.destroy(n);
}
}
},pacify:function(_5da){
},pacifying:false,pacifyTicks:200,setPacifying:function(_5db){
if(this.pacifying!=_5db){
this.pacifying=_5db;
this.pacify(this.pacifying);
}
},startPacify:function(){
this.startPacifyTicks=new Date().getTime();
},doPacify:function(){
var _5dc=(new Date().getTime()-this.startPacifyTicks)>this.pacifyTicks;
this.setPacifying(true);
this.startPacify();
return _5dc;
},endPacify:function(){
this.setPacifying(false);
},resize:function(){
if(this.scrollboxNode){
this.windowHeight=this.scrollboxNode.clientHeight;
}
for(var i=0;i<this.colCount;i++){
dojox.grid.util.setStyleHeightPx(this.contentNodes[i],Math.max(1,this.height));
}
var _5dd=(!this._invalidating);
if(!_5dd){
var ah=this.grid.get("autoHeight");
if(typeof ah=="number"&&ah<=Math.min(this.rowsPerPage,this.rowCount)){
_5dd=true;
}
}
if(_5dd){
this.needPage(this.page,this.pageTop);
}
var _5de=(this.page<this.pageCount-1)?this.rowsPerPage:((this.rowCount%this.rowsPerPage)||this.rowsPerPage);
var _5df=this.getPageHeight(this.page);
this.averageRowHeight=(_5df>0&&_5de>0)?(_5df/_5de):0;
},calcLastPageHeight:function(){
if(!this.pageCount){
return 0;
}
var _5e0=this.pageCount-1;
var _5e1=((this.rowCount%this.rowsPerPage)||(this.rowsPerPage))*this.defaultRowHeight;
this.pageHeights[_5e0]=_5e1;
return _5e1;
},updateContentHeight:function(inDh){
this.height+=inDh;
this.resize();
},updatePageHeight:function(_5e2,_5e3,_5e4){
if(this.pageExists(_5e2)){
var oh=this.getPageHeight(_5e2);
var h=(this.measurePage(_5e2));
if(h===undefined){
h=oh;
}
this.pageHeights[_5e2]=h;
if(oh!=h){
this.updateContentHeight(h-oh);
var ah=this.grid.get("autoHeight");
if((typeof ah=="number"&&ah>this.rowCount)||(ah===true&&!_5e3)){
if(!_5e4){
this.grid.sizeChange();
}else{
var ns=this.grid.viewsNode.style;
ns.height=parseInt(ns.height)+h-oh+"px";
this.repositionPages(_5e2);
}
}else{
this.repositionPages(_5e2);
}
}
return h;
}
return 0;
},rowHeightChanged:function(_5e5,_5e6){
this.updatePageHeight(Math.floor(_5e5/this.rowsPerPage),false,_5e6);
},invalidateNodes:function(){
while(this.stack.length){
this.destroyPage(this.popPage());
}
},createPageNode:function(){
var p=document.createElement("div");
dojo.attr(p,"role","presentation");
p.style.position="absolute";
p.style[dojo._isBodyLtr()?"left":"right"]="0";
return p;
},getPageHeight:function(_5e7){
var ph=this.pageHeights[_5e7];
return (ph!==undefined?ph:this.defaultPageHeight);
},pushPage:function(_5e8){
return this.stack.push(_5e8);
},popPage:function(){
return this.stack.shift();
},findPage:function(_5e9){
var i=0,h=0;
for(var ph=0;i<this.pageCount;i++,h+=ph){
ph=this.getPageHeight(i);
if(h+ph>=_5e9){
break;
}
}
this.page=i;
this.pageTop=h;
},buildPage:function(_5ea,_5eb,_5ec){
this.preparePage(_5ea,_5eb);
this.positionPage(_5ea,_5ec);
this.installPage(_5ea);
this.renderPage(_5ea);
this.pushPage(_5ea);
},needPage:function(_5ed,_5ee){
var h=this.getPageHeight(_5ed),oh=h;
if(!this.pageExists(_5ed)){
this.buildPage(_5ed,(!this.grid._autoHeight&&this.keepPages&&(this.stack.length>=this.keepPages)),_5ee);
h=this.updatePageHeight(_5ed,true);
}else{
this.positionPage(_5ed,_5ee);
}
return h;
},onscroll:function(){
this.scroll(this.scrollboxNode.scrollTop);
},scroll:function(_5ef){
this.grid.scrollTop=_5ef;
if(this.colCount){
this.startPacify();
this.findPage(_5ef);
var h=this.height;
var b=this.getScrollBottom(_5ef);
for(var p=this.page,y=this.pageTop;(p<this.pageCount)&&((b<0)||(y<b));p++){
y+=this.needPage(p,y);
}
this.firstVisibleRow=this.getFirstVisibleRow(this.page,this.pageTop,_5ef);
this.lastVisibleRow=this.getLastVisibleRow(p-1,y,b);
if(h!=this.height){
this.repositionPages(p-1);
}
this.endPacify();
}
},getScrollBottom:function(_5f0){
return (this.windowHeight>=0?_5f0+this.windowHeight:-1);
},processNodeEvent:function(e,_5f1){
var t=e.target;
while(t&&(t!=_5f1)&&t.parentNode&&(t.parentNode.parentNode!=_5f1)){
t=t.parentNode;
}
if(!t||!t.parentNode||(t.parentNode.parentNode!=_5f1)){
return false;
}
var page=t.parentNode;
e.topRowIndex=page.pageIndex*this.rowsPerPage;
e.rowIndex=e.topRowIndex+_5b3(t);
e.rowTarget=t;
return true;
},processEvent:function(e){
return this.processNodeEvent(e,this.contentNode);
},renderRow:function(_5f2,_5f3){
},removeRow:function(_5f4){
},getDefaultPageNode:function(_5f5){
return this.getDefaultNodes()[_5f5];
},positionPageNode:function(_5f6,_5f7){
},getPageNodePosition:function(_5f8){
return _5f8.offsetTop;
},invalidatePageNode:function(_5f9,_5fa){
var p=_5fa[_5f9];
if(p){
delete _5fa[_5f9];
this.removePage(_5f9,p);
_5b5(p);
p.innerHTML="";
}
return p;
},getPageRow:function(_5fb){
return _5fb*this.rowsPerPage;
},getLastPageRow:function(_5fc){
return Math.min(this.rowCount,this.getPageRow(_5fc+1))-1;
},getFirstVisibleRow:function(_5fd,_5fe,_5ff){
if(!this.pageExists(_5fd)){
return 0;
}
var row=this.getPageRow(_5fd);
var _600=this.getDefaultNodes();
var rows=_5be(_600[_5fd]);
for(var i=0,l=rows.length;i<l&&_5fe<_5ff;i++,row++){
_5fe+=rows[i].offsetHeight;
}
return (row?row-1:row);
},getLastVisibleRow:function(_601,_602,_603){
if(!this.pageExists(_601)){
return 0;
}
var _604=this.getDefaultNodes();
var row=this.getLastPageRow(_601);
var rows=_5be(_604[_601]);
for(var i=rows.length-1;i>=0&&_602>_603;i--,row--){
_602-=rows[i].offsetHeight;
}
return row+1;
},findTopRow:function(_605){
var _606=this.getDefaultNodes();
var rows=_5be(_606[this.page]);
for(var i=0,l=rows.length,t=this.pageTop,h;i<l;i++){
h=rows[i].offsetHeight;
t+=h;
if(t>=_605){
this.offset=h-(t-_605);
return i+this.page*this.rowsPerPage;
}
}
return -1;
},findScrollTop:function(_607){
var _608=Math.floor(_607/this.rowsPerPage);
var t=0;
var i,l;
for(i=0;i<_608;i++){
t+=this.getPageHeight(i);
}
this.pageTop=t;
this.page=_608;
this.needPage(_608,this.pageTop);
var _609=this.getDefaultNodes();
var rows=_5be(_609[_608]);
var r=_607-this.rowsPerPage*_608;
for(i=0,l=rows.length;i<l&&i<r;i++){
t+=rows[i].offsetHeight;
}
return t;
},dummy:0});
})();
}
if(!dojo._hasResource["dojox.grid.cells._base"]){
dojo._hasResource["dojox.grid.cells._base"]=true;
dojo.provide("dojox.grid.cells._base");
dojo.declare("dojox.grid._DeferredTextWidget",dijit._Widget,{deferred:null,_destroyOnRemove:true,postCreate:function(){
if(this.deferred){
this.deferred.addBoth(dojo.hitch(this,function(text){
if(this.domNode){
this.domNode.innerHTML=text;
}
}));
}
}});
(function(){
var _60a=function(_60b){
try{
dojox.grid.util.fire(_60b,"focus");
dojox.grid.util.fire(_60b,"select");
}
catch(e){
}
};
var _60c=function(){
setTimeout(dojo.hitch.apply(dojo,arguments),0);
};
var dgc=dojox.grid.cells;
dojo.declare("dojox.grid.cells._Base",null,{styles:"",classes:"",editable:false,alwaysEditing:false,formatter:null,defaultValue:"...",value:null,hidden:false,noresize:false,draggable:true,_valueProp:"value",_formatPending:false,constructor:function(_60d){
this._props=_60d||{};
dojo.mixin(this,_60d);
if(this.draggable===undefined){
this.draggable=true;
}
},_defaultFormat:function(_60e,_60f){
var s=this.grid.formatterScope||this;
var f=this.formatter;
if(f&&s&&typeof f=="string"){
f=this.formatter=s[f];
}
var v=(_60e!=this.defaultValue&&f)?f.apply(s,_60f):_60e;
if(typeof v=="undefined"){
return this.defaultValue;
}
if(v&&v.addBoth){
v=new dojox.grid._DeferredTextWidget({deferred:v},dojo.create("span",{innerHTML:this.defaultValue}));
}
if(v&&v.declaredClass&&v.startup){
return "<div class='dojoxGridStubNode' linkWidget='"+v.id+"' cellIdx='"+this.index+"'>"+this.defaultValue+"</div>";
}
return v;
},format:function(_610,_611){
var f,i=this.grid.edit.info,d=this.get?this.get(_610,_611):(this.value||this.defaultValue);
d=(d&&d.replace&&this.grid.escapeHTMLInData)?d.replace(/&/g,"&amp;").replace(/</g,"&lt;"):d;
if(this.editable&&(this.alwaysEditing||(i.rowIndex==_610&&i.cell==this))){
return this.formatEditing(d,_610);
}else{
return this._defaultFormat(d,[d,_610,this]);
}
},formatEditing:function(_612,_613){
},getNode:function(_614){
return this.view.getCellNode(_614,this.index);
},getHeaderNode:function(){
return this.view.getHeaderCellNode(this.index);
},getEditNode:function(_615){
return (this.getNode(_615)||0).firstChild||0;
},canResize:function(){
var uw=this.unitWidth;
return uw&&(uw!=="auto");
},isFlex:function(){
var uw=this.unitWidth;
return uw&&dojo.isString(uw)&&(uw=="auto"||uw.slice(-1)=="%");
},applyEdit:function(_616,_617){
this.grid.edit.applyCellEdit(_616,this,_617);
},cancelEdit:function(_618){
this.grid.doCancelEdit(_618);
},_onEditBlur:function(_619){
if(this.grid.edit.isEditCell(_619,this.index)){
this.grid.edit.apply();
}
},registerOnBlur:function(_61a,_61b){
if(this.commitOnBlur){
dojo.connect(_61a,"onblur",function(e){
setTimeout(dojo.hitch(this,"_onEditBlur",_61b),250);
});
}
},needFormatNode:function(_61c,_61d){
this._formatPending=true;
_60c(this,"_formatNode",_61c,_61d);
},cancelFormatNode:function(){
this._formatPending=false;
},_formatNode:function(_61e,_61f){
if(this._formatPending){
this._formatPending=false;
if(!dojo.isIE){
dojo.setSelectable(this.grid.domNode,true);
}
this.formatNode(this.getEditNode(_61f),_61e,_61f);
}
},formatNode:function(_620,_621,_622){
if(dojo.isIE){
_60c(this,"focus",_622,_620);
}else{
this.focus(_622,_620);
}
},dispatchEvent:function(m,e){
if(m in this){
return this[m](e);
}
},getValue:function(_623){
return this.getEditNode(_623)[this._valueProp];
},setValue:function(_624,_625){
var n=this.getEditNode(_624);
if(n){
n[this._valueProp]=_625;
}
},focus:function(_626,_627){
_60a(_627||this.getEditNode(_626));
},save:function(_628){
this.value=this.value||this.getValue(_628);
},restore:function(_629){
this.setValue(_629,this.value);
},_finish:function(_62a){
dojo.setSelectable(this.grid.domNode,false);
this.cancelFormatNode();
},apply:function(_62b){
this.applyEdit(this.getValue(_62b),_62b);
this._finish(_62b);
},cancel:function(_62c){
this.cancelEdit(_62c);
this._finish(_62c);
}});
dgc._Base.markupFactory=function(node,_62d){
var d=dojo;
var _62e=d.trim(d.attr(node,"formatter")||"");
if(_62e){
_62d.formatter=dojo.getObject(_62e)||_62e;
}
var get=d.trim(d.attr(node,"get")||"");
if(get){
_62d.get=dojo.getObject(get);
}
var _62f=function(attr,cell,_630){
var _631=d.trim(d.attr(node,attr)||"");
if(_631){
cell[_630||attr]=!(_631.toLowerCase()=="false");
}
};
_62f("sortDesc",_62d);
_62f("editable",_62d);
_62f("alwaysEditing",_62d);
_62f("noresize",_62d);
_62f("draggable",_62d);
var _632=d.trim(d.attr(node,"loadingText")||d.attr(node,"defaultValue")||"");
if(_632){
_62d.defaultValue=_632;
}
var _633=function(attr,cell,_634){
var _635=d.trim(d.attr(node,attr)||"")||undefined;
if(_635){
cell[_634||attr]=_635;
}
};
_633("styles",_62d);
_633("headerStyles",_62d);
_633("cellStyles",_62d);
_633("classes",_62d);
_633("headerClasses",_62d);
_633("cellClasses",_62d);
};
dojo.declare("dojox.grid.cells.Cell",dgc._Base,{constructor:function(){
this.keyFilter=this.keyFilter;
},keyFilter:null,formatEditing:function(_636,_637){
this.needFormatNode(_636,_637);
return "<input class=\"dojoxGridInput\" type=\"text\" value=\""+_636+"\">";
},formatNode:function(_638,_639,_63a){
this.inherited(arguments);
this.registerOnBlur(_638,_63a);
},doKey:function(e){
if(this.keyFilter){
var key=String.fromCharCode(e.charCode);
if(key.search(this.keyFilter)==-1){
dojo.stopEvent(e);
}
}
},_finish:function(_63b){
this.inherited(arguments);
var n=this.getEditNode(_63b);
try{
dojox.grid.util.fire(n,"blur");
}
catch(e){
}
}});
dgc.Cell.markupFactory=function(node,_63c){
dgc._Base.markupFactory(node,_63c);
var d=dojo;
var _63d=d.trim(d.attr(node,"keyFilter")||"");
if(_63d){
_63c.keyFilter=new RegExp(_63d);
}
};
dojo.declare("dojox.grid.cells.RowIndex",dgc.Cell,{name:"Row",postscript:function(){
this.editable=false;
},get:function(_63e){
return _63e+1;
}});
dgc.RowIndex.markupFactory=function(node,_63f){
dgc.Cell.markupFactory(node,_63f);
};
dojo.declare("dojox.grid.cells.Select",dgc.Cell,{options:null,values:null,returnIndex:-1,constructor:function(_640){
this.values=this.values||this.options;
},formatEditing:function(_641,_642){
this.needFormatNode(_641,_642);
var h=["<select class=\"dojoxGridSelect\">"];
for(var i=0,o,v;((o=this.options[i])!==undefined)&&((v=this.values[i])!==undefined);i++){
h.push("<option",(_641==v?" selected":"")," value=\""+v+"\"",">",o,"</option>");
}
h.push("</select>");
return h.join("");
},getValue:function(_643){
var n=this.getEditNode(_643);
if(n){
var i=n.selectedIndex,o=n.options[i];
return this.returnIndex>-1?i:o.value||o.innerHTML;
}
}});
dgc.Select.markupFactory=function(node,cell){
dgc.Cell.markupFactory(node,cell);
var d=dojo;
var _644=d.trim(d.attr(node,"options")||"");
if(_644){
var o=_644.split(",");
if(o[0]!=_644){
cell.options=o;
}
}
var _645=d.trim(d.attr(node,"values")||"");
if(_645){
var v=_645.split(",");
if(v[0]!=_645){
cell.values=v;
}
}
};
dojo.declare("dojox.grid.cells.AlwaysEdit",dgc.Cell,{alwaysEditing:true,_formatNode:function(_646,_647){
this.formatNode(this.getEditNode(_647),_646,_647);
},applyStaticValue:function(_648){
var e=this.grid.edit;
e.applyCellEdit(this.getValue(_648),this,_648);
e.start(this,_648,true);
}});
dgc.AlwaysEdit.markupFactory=function(node,cell){
dgc.Cell.markupFactory(node,cell);
};
dojo.declare("dojox.grid.cells.Bool",dgc.AlwaysEdit,{_valueProp:"checked",formatEditing:function(_649,_64a){
return "<input class=\"dojoxGridInput\" type=\"checkbox\""+(_649?" checked=\"checked\"":"")+" style=\"width: auto\" />";
},doclick:function(e){
if(e.target.tagName=="INPUT"){
this.applyStaticValue(e.rowIndex);
}
}});
dgc.Bool.markupFactory=function(node,cell){
dgc.AlwaysEdit.markupFactory(node,cell);
};
})();
}
if(!dojo._hasResource["dojox.grid.cells"]){
dojo._hasResource["dojox.grid.cells"]=true;
dojo.provide("dojox.grid.cells");
}
if(!dojo._hasResource["dojox.grid._Builder"]){
dojo._hasResource["dojox.grid._Builder"]=true;
dojo.provide("dojox.grid._Builder");
(function(){
var dg=dojox.grid;
var _64b=function(td){
return td.cellIndex>=0?td.cellIndex:dojo.indexOf(td.parentNode.cells,td);
};
var _64c=function(tr){
return tr.rowIndex>=0?tr.rowIndex:dojo.indexOf(tr.parentNode.childNodes,tr);
};
var _64d=function(_64e,_64f){
return _64e&&((_64e.rows||0)[_64f]||_64e.childNodes[_64f]);
};
var _650=function(node){
for(var n=node;n&&n.tagName!="TABLE";n=n.parentNode){
}
return n;
};
var _651=function(_652,_653){
for(var n=_652;n&&_653(n);n=n.parentNode){
}
return n;
};
var _654=function(_655){
var name=_655.toUpperCase();
return function(node){
return node.tagName!=name;
};
};
var _656=dojox.grid.util.rowIndexTag;
var _657=dojox.grid.util.gridViewTag;
dg._Builder=dojo.extend(function(view){
if(view){
this.view=view;
this.grid=view.grid;
}
},{view:null,_table:"<table class=\"dojoxGridRowTable\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" role=\"presentation\"",getTableArray:function(){
var html=[this._table];
if(this.view.viewWidth){
html.push([" style=\"width:",this.view.viewWidth,";\""].join(""));
}
html.push(">");
return html;
},generateCellMarkup:function(_658,_659,_65a,_65b){
var _65c=[],html;
if(_65b){
var _65d=_658.index!=_658.grid.getSortIndex()?"":_658.grid.sortInfo>0?"aria-sort=\"ascending\"":"aria-sort=\"descending\"";
if(!_658.id){
_658.id=this.grid.id+"Hdr"+_658.index;
}
html=["<th tabIndex=\"-1\" aria-readonly=\"true\" role=\"columnheader\"",_65d,"id=\"",_658.id,"\""];
}else{
var _65e=this.grid.editable&&!_658.editable?"aria-readonly=\"true\"":"";
html=["<td tabIndex=\"-1\" role=\"gridcell\" ",_65e," aria-describedby=\"",this.grid.id,"Hdr",_658.index,"\""];
}
if(_658.colSpan){
html.push(" colspan=\"",_658.colSpan,"\"");
}
if(_658.rowSpan){
html.push(" rowspan=\"",_658.rowSpan,"\"");
}
html.push(" class=\"dojoxGridCell ");
if(_658.classes){
html.push(_658.classes," ");
}
if(_65a){
html.push(_65a," ");
}
_65c.push(html.join(""));
_65c.push("");
html=["\" idx=\"",_658.index,"\" style=\""];
if(_659&&_659[_659.length-1]!=";"){
_659+=";";
}
html.push(_658.styles,_659||"",_658.hidden?"display:none;":"");
if(_658.unitWidth){
html.push("width:",_658.unitWidth,";");
}
_65c.push(html.join(""));
_65c.push("");
html=["\""];
if(_658.attrs){
html.push(" ",_658.attrs);
}
html.push(">");
_65c.push(html.join(""));
_65c.push("");
_65c.push(_65b?"</th>":"</td>");
return _65c;
},isCellNode:function(_65f){
return Boolean(_65f&&_65f!=dojo.doc&&dojo.attr(_65f,"idx"));
},getCellNodeIndex:function(_660){
return _660?Number(dojo.attr(_660,"idx")):-1;
},getCellNode:function(_661,_662){
for(var i=0,row;((row=_64d(_661.firstChild,i))&&row.cells);i++){
for(var j=0,cell;(cell=row.cells[j]);j++){
if(this.getCellNodeIndex(cell)==_662){
return cell;
}
}
}
return null;
},findCellTarget:function(_663,_664){
var n=_663;
while(n&&(!this.isCellNode(n)||(n.offsetParent&&_657 in n.offsetParent.parentNode&&n.offsetParent.parentNode[_657]!=this.view.id))&&(n!=_664)){
n=n.parentNode;
}
return n!=_664?n:null;
},baseDecorateEvent:function(e){
e.dispatch="do"+e.type;
e.grid=this.grid;
e.sourceView=this.view;
e.cellNode=this.findCellTarget(e.target,e.rowNode);
e.cellIndex=this.getCellNodeIndex(e.cellNode);
e.cell=(e.cellIndex>=0?this.grid.getCell(e.cellIndex):null);
},findTarget:function(_665,_666){
var n=_665;
while(n&&(n!=this.domNode)&&(!(_666 in n)||(_657 in n&&n[_657]!=this.view.id))){
n=n.parentNode;
}
return (n!=this.domNode)?n:null;
},findRowTarget:function(_667){
return this.findTarget(_667,_656);
},isIntraNodeEvent:function(e){
try{
return (e.cellNode&&e.relatedTarget&&dojo.isDescendant(e.relatedTarget,e.cellNode));
}
catch(x){
return false;
}
},isIntraRowEvent:function(e){
try{
var row=e.relatedTarget&&this.findRowTarget(e.relatedTarget);
return !row&&(e.rowIndex==-1)||row&&(e.rowIndex==row.gridRowIndex);
}
catch(x){
return false;
}
},dispatchEvent:function(e){
if(e.dispatch in this){
return this[e.dispatch](e);
}
return false;
},domouseover:function(e){
if(e.cellNode&&(e.cellNode!=this.lastOverCellNode)){
this.lastOverCellNode=e.cellNode;
this.grid.onMouseOver(e);
}
this.grid.onMouseOverRow(e);
},domouseout:function(e){
if(e.cellNode&&(e.cellNode==this.lastOverCellNode)&&!this.isIntraNodeEvent(e,this.lastOverCellNode)){
this.lastOverCellNode=null;
this.grid.onMouseOut(e);
if(!this.isIntraRowEvent(e)){
this.grid.onMouseOutRow(e);
}
}
},domousedown:function(e){
if(e.cellNode){
this.grid.onMouseDown(e);
}
this.grid.onMouseDownRow(e);
}});
dg._ContentBuilder=dojo.extend(function(view){
dg._Builder.call(this,view);
},dg._Builder.prototype,{update:function(){
this.prepareHtml();
},prepareHtml:function(){
var _668=this.grid.get,_669=this.view.structure.cells;
for(var j=0,row;(row=_669[j]);j++){
for(var i=0,cell;(cell=row[i]);i++){
cell.get=cell.get||(cell.value==undefined)&&_668;
cell.markup=this.generateCellMarkup(cell,cell.cellStyles,cell.cellClasses,false);
if(!this.grid.editable&&cell.editable){
this.grid.editable=true;
}
}
}
},generateHtml:function(_66a,_66b){
var html=this.getTableArray(),v=this.view,_66c=v.structure.cells,item=this.grid.getItem(_66b);
dojox.grid.util.fire(this.view,"onBeforeRow",[_66b,_66c]);
for(var j=0,row;(row=_66c[j]);j++){
if(row.hidden||row.header){
continue;
}
html.push(!row.invisible?"<tr>":"<tr class=\"dojoxGridInvisible\">");
for(var i=0,cell,m,cc,cs;(cell=row[i]);i++){
m=cell.markup;
cc=cell.customClasses=[];
cs=cell.customStyles=[];
m[5]=cell.format(_66b,item);
m[5]=dojox.grid.util.fixIEEmptyCell(m[5]);
m[1]=cc.join(" ");
m[3]=cs.join(";");
html.push.apply(html,m);
}
html.push("</tr>");
}
html.push("</table>");
return html.join("");
},decorateEvent:function(e,_66d){
e.rowNode=_66d||this.findRowTarget(e.target);
if(!e.rowNode){
return false;
}
e.rowIndex=e.rowNode[_656];
this.baseDecorateEvent(e);
e.cell=this.grid.getCell(e.cellIndex);
return true;
}});
dg._HeaderBuilder=dojo.extend(function(view){
this.moveable=null;
dg._Builder.call(this,view);
},dg._Builder.prototype,{_skipBogusClicks:false,overResizeWidth:4,minColWidth:1,update:function(){
if(this.tableMap){
this.tableMap.mapRows(this.view.structure.cells);
}else{
this.tableMap=new dg._TableMap(this.view.structure.cells);
}
},generateHtml:function(_66e,_66f){
var html=this.getTableArray(),_670=this.view.structure.cells;
dojox.grid.util.fire(this.view,"onBeforeRow",[-1,_670]);
for(var j=0,row;(row=_670[j]);j++){
if(row.hidden){
continue;
}
html.push(!row.invisible?"<tr>":"<tr class=\"dojoxGridInvisible\">");
for(var i=0,cell,_671;(cell=row[i]);i++){
cell.customClasses=[];
cell.customStyles=[];
if(this.view.simpleStructure){
if(cell.draggable){
if(cell.headerClasses){
if(cell.headerClasses.indexOf("dojoDndItem")==-1){
cell.headerClasses+=" dojoDndItem";
}
}else{
cell.headerClasses="dojoDndItem";
}
}
if(cell.attrs){
if(cell.attrs.indexOf("dndType='gridColumn_")==-1){
cell.attrs+=" dndType='gridColumn_"+this.grid.id+"'";
}
}else{
cell.attrs="dndType='gridColumn_"+this.grid.id+"'";
}
}
_671=this.generateCellMarkup(cell,cell.headerStyles,cell.headerClasses,true);
_671[5]=(_66f!=undefined?_66f:_66e(cell));
_671[3]=cell.customStyles.join(";");
_671[1]=cell.customClasses.join(" ");
html.push(_671.join(""));
}
html.push("</tr>");
}
html.push("</table>");
return html.join("");
},getCellX:function(e){
var n,x=e.layerX;
if(dojo.isMoz||dojo.isIE>=9){
n=_651(e.target,_654("th"));
x-=(n&&n.offsetLeft)||0;
var t=e.sourceView.getScrollbarWidth();
if(!dojo._isBodyLtr()){
table=_651(n,_654("table"));
x-=(table&&table.offsetLeft)||0;
}
}
n=_651(e.target,function(){
if(!n||n==e.cellNode){
return false;
}
x+=(n.offsetLeft<0?0:n.offsetLeft);
return true;
});
return x;
},decorateEvent:function(e){
this.baseDecorateEvent(e);
e.rowIndex=-1;
e.cellX=this.getCellX(e);
return true;
},prepareResize:function(e,mod){
do{
var i=e.cellIndex;
e.cellNode=(i?e.cellNode.parentNode.cells[i+mod]:null);
e.cellIndex=(e.cellNode?this.getCellNodeIndex(e.cellNode):-1);
}while(e.cellNode&&e.cellNode.style.display=="none");
return Boolean(e.cellNode);
},canResize:function(e){
if(!e.cellNode||e.cellNode.colSpan>1){
return false;
}
var cell=this.grid.getCell(e.cellIndex);
return !cell.noresize&&cell.canResize();
},overLeftResizeArea:function(e){
if(dojo.hasClass(dojo.body(),"dojoDndMove")){
return false;
}
if(dojo.isIE){
var tN=e.target;
if(dojo.hasClass(tN,"dojoxGridArrowButtonNode")||dojo.hasClass(tN,"dojoxGridArrowButtonChar")){
return false;
}
}
if(dojo._isBodyLtr()){
return (e.cellIndex>0)&&(e.cellX>0&&e.cellX<this.overResizeWidth)&&this.prepareResize(e,-1);
}
var t=e.cellNode&&(e.cellX>0&&e.cellX<this.overResizeWidth);
return t;
},overRightResizeArea:function(e){
if(dojo.hasClass(dojo.body(),"dojoDndMove")){
return false;
}
if(dojo.isIE){
var tN=e.target;
if(dojo.hasClass(tN,"dojoxGridArrowButtonNode")||dojo.hasClass(tN,"dojoxGridArrowButtonChar")){
return false;
}
}
if(dojo._isBodyLtr()){
return e.cellNode&&(e.cellX>=e.cellNode.offsetWidth-this.overResizeWidth);
}
return (e.cellIndex>0)&&(e.cellX>=e.cellNode.offsetWidth-this.overResizeWidth)&&this.prepareResize(e,-1);
},domousemove:function(e){
if(!this.moveable){
var c=(this.overRightResizeArea(e)?"dojoxGridColResize":(this.overLeftResizeArea(e)?"dojoxGridColResize":""));
if(c&&!this.canResize(e)){
c="dojoxGridColNoResize";
}
dojo.toggleClass(e.sourceView.headerNode,"dojoxGridColNoResize",(c=="dojoxGridColNoResize"));
dojo.toggleClass(e.sourceView.headerNode,"dojoxGridColResize",(c=="dojoxGridColResize"));
if(dojo.isIE){
var t=e.sourceView.headerNode.scrollLeft;
e.sourceView.headerNode.scrollLeft=t;
}
if(c){
dojo.stopEvent(e);
}
}
},domousedown:function(e){
if(!this.moveable){
if((this.overRightResizeArea(e)||this.overLeftResizeArea(e))&&this.canResize(e)){
this.beginColumnResize(e);
}else{
this.grid.onMouseDown(e);
this.grid.onMouseOverRow(e);
}
}
},doclick:function(e){
if(this._skipBogusClicks){
dojo.stopEvent(e);
return true;
}
return false;
},colResizeSetup:function(e,_672){
var _673=dojo.contentBox(e.sourceView.headerNode);
if(_672){
this.lineDiv=document.createElement("div");
var vw=(dojo.position||dojo._abs)(e.sourceView.headerNode,true);
var _674=dojo.contentBox(e.sourceView.domNode);
var l=e.pageX;
if(!dojo._isBodyLtr()&&dojo.isIE<8){
l-=dojox.html.metrics.getScrollbar().w;
}
dojo.style(this.lineDiv,{top:vw.y+"px",left:l+"px",height:(_674.h+_673.h)+"px"});
dojo.addClass(this.lineDiv,"dojoxGridResizeColLine");
this.lineDiv._origLeft=l;
dojo.body().appendChild(this.lineDiv);
}
var _675=[],_676=this.tableMap.findOverlappingNodes(e.cellNode);
for(var i=0,cell;(cell=_676[i]);i++){
_675.push({node:cell,index:this.getCellNodeIndex(cell),width:dojo.contentBox(cell).w});
}
var view=e.sourceView;
var adj=dojo._isBodyLtr()?1:-1;
var _677=e.grid.views.views;
var _678=[];
for(var j=view.idx+adj,_679;(_679=_677[j]);j=j+adj){
_678.push({node:_679.headerNode,left:window.parseInt(_679.headerNode.style.left)});
}
var _67a=view.headerContentNode.firstChild;
var drag={scrollLeft:e.sourceView.headerNode.scrollLeft,view:view,node:e.cellNode,index:e.cellIndex,w:dojo.contentBox(e.cellNode).w,vw:_673.w,table:_67a,tw:dojo.contentBox(_67a).w,spanners:_675,followers:_678};
return drag;
},beginColumnResize:function(e){
this.moverDiv=document.createElement("div");
dojo.style(this.moverDiv,{position:"absolute",left:0});
dojo.body().appendChild(this.moverDiv);
dojo.addClass(this.grid.domNode,"dojoxGridColumnResizing");
var m=(this.moveable=new dojo.dnd.Moveable(this.moverDiv));
var drag=this.colResizeSetup(e,true);
m.onMove=dojo.hitch(this,"doResizeColumn",drag);
dojo.connect(m,"onMoveStop",dojo.hitch(this,function(){
this.endResizeColumn(drag);
if(drag.node.releaseCapture){
drag.node.releaseCapture();
}
this.moveable.destroy();
delete this.moveable;
this.moveable=null;
dojo.removeClass(this.grid.domNode,"dojoxGridColumnResizing");
}));
if(e.cellNode.setCapture){
e.cellNode.setCapture();
}
m.onMouseDown(e);
},doResizeColumn:function(_67b,_67c,_67d){
var _67e=_67d.l;
var data={deltaX:_67e,w:_67b.w+(dojo._isBodyLtr()?_67e:-_67e),vw:_67b.vw+_67e,tw:_67b.tw+_67e};
this.dragRecord={inDrag:_67b,mover:_67c,leftTop:_67d};
if(data.w>=this.minColWidth){
if(!_67c){
this.doResizeNow(_67b,data);
}else{
dojo.style(this.lineDiv,"left",(this.lineDiv._origLeft+data.deltaX)+"px");
}
}
},endResizeColumn:function(_67f){
if(this.dragRecord){
var _680=this.dragRecord.leftTop;
var _681=dojo._isBodyLtr()?_680.l:-_680.l;
_681+=Math.max(_67f.w+_681,this.minColWidth)-(_67f.w+_681);
if(dojo.isWebKit&&_67f.spanners.length){
_681+=dojo._getPadBorderExtents(_67f.spanners[0].node).w;
}
var data={deltaX:_681,w:_67f.w+_681,vw:_67f.vw+_681,tw:_67f.tw+_681};
this.doResizeNow(_67f,data);
delete this.dragRecord;
}
dojo.destroy(this.lineDiv);
dojo.destroy(this.moverDiv);
dojo.destroy(this.moverDiv);
delete this.moverDiv;
this._skipBogusClicks=true;
_67f.view.update();
this._skipBogusClicks=false;
this.grid.onResizeColumn(_67f.index);
},doResizeNow:function(_682,data){
_682.view.convertColPctToFixed();
if(_682.view.flexCells&&!_682.view.testFlexCells()){
var t=_650(_682.node);
if(t){
(t.style.width="");
}
}
var i,s,sw,f,fl;
for(i=0;(s=_682.spanners[i]);i++){
sw=s.width+data.deltaX;
if(sw>0){
s.node.style.width=sw+"px";
_682.view.setColWidth(s.index,sw);
}
}
if(dojo._isBodyLtr()||!dojo.isIE){
for(i=0;(f=_682.followers[i]);i++){
fl=f.left+data.deltaX;
f.node.style.left=fl+"px";
}
}
_682.node.style.width=data.w+"px";
_682.view.setColWidth(_682.index,data.w);
_682.view.headerNode.style.width=data.vw+"px";
_682.view.setColumnsWidth(data.tw);
if(!dojo._isBodyLtr()){
_682.view.headerNode.scrollLeft=_682.scrollLeft+data.deltaX;
}
}});
dg._TableMap=dojo.extend(function(rows){
this.mapRows(rows);
},{map:null,mapRows:function(_683){
var _684=_683.length;
if(!_684){
return;
}
this.map=[];
var row;
for(var k=0;(row=_683[k]);k++){
this.map[k]=[];
}
for(var j=0;(row=_683[j]);j++){
for(var i=0,x=0,cell,_685,_686;(cell=row[i]);i++){
while(this.map[j][x]){
x++;
}
this.map[j][x]={c:i,r:j};
_686=cell.rowSpan||1;
_685=cell.colSpan||1;
for(var y=0;y<_686;y++){
for(var s=0;s<_685;s++){
this.map[j+y][x+s]=this.map[j][x];
}
}
x+=_685;
}
}
},dumpMap:function(){
for(var j=0,row,h="";(row=this.map[j]);j++,h=""){
for(var i=0,cell;(cell=row[i]);i++){
h+=cell.r+","+cell.c+"   ";
}
}
},getMapCoords:function(_687,_688){
for(var j=0,row;(row=this.map[j]);j++){
for(var i=0,cell;(cell=row[i]);i++){
if(cell.c==_688&&cell.r==_687){
return {j:j,i:i};
}
}
}
return {j:-1,i:-1};
},getNode:function(_689,_68a,_68b){
var row=_689&&_689.rows[_68a];
return row&&row.cells[_68b];
},_findOverlappingNodes:function(_68c,_68d,_68e){
var _68f=[];
var m=this.getMapCoords(_68d,_68e);
for(var j=0,row;(row=this.map[j]);j++){
if(j==m.j){
continue;
}
var rw=row[m.i];
var n=(rw?this.getNode(_68c,rw.r,rw.c):null);
if(n){
_68f.push(n);
}
}
return _68f;
},findOverlappingNodes:function(_690){
return this._findOverlappingNodes(_650(_690),_64c(_690.parentNode),_64b(_690));
}});
})();
}
if(!dojo._hasResource["dojo.dnd.Container"]){
dojo._hasResource["dojo.dnd.Container"]=true;
dojo.provide("dojo.dnd.Container");
dojo.declare("dojo.dnd.Container",null,{skipForm:false,constructor:function(node,_691){
this.node=dojo.byId(node);
if(!_691){
_691={};
}
this.creator=_691.creator||null;
this.skipForm=_691.skipForm;
this.parent=_691.dropParent&&dojo.byId(_691.dropParent);
this.map={};
this.current=null;
this.containerState="";
dojo.addClass(this.node,"dojoDndContainer");
if(!(_691&&_691._skipStartup)){
this.startup();
}
this.events=[dojo.connect(this.node,"onmouseover",this,"onMouseOver"),dojo.connect(this.node,"onmouseout",this,"onMouseOut"),dojo.connect(this.node,"ondragstart",this,"onSelectStart"),dojo.connect(this.node,"onselectstart",this,"onSelectStart")];
},creator:function(){
},getItem:function(key){
return this.map[key];
},setItem:function(key,data){
this.map[key]=data;
},delItem:function(key){
delete this.map[key];
},forInItems:function(f,o){
o=o||dojo.global;
var m=this.map,e=dojo.dnd._empty;
for(var i in m){
if(i in e){
continue;
}
f.call(o,m[i],i,this);
}
return o;
},clearItems:function(){
this.map={};
},getAllNodes:function(){
return dojo.query("> .dojoDndItem",this.parent);
},sync:function(){
var map={};
this.getAllNodes().forEach(function(node){
if(node.id){
var item=this.getItem(node.id);
if(item){
map[node.id]=item;
return;
}
}else{
node.id=dojo.dnd.getUniqueId();
}
var type=node.getAttribute("dndType"),data=node.getAttribute("dndData");
map[node.id]={data:data||node.innerHTML,type:type?type.split(/\s*,\s*/):["text"]};
},this);
this.map=map;
return this;
},insertNodes:function(data,_692,_693){
if(!this.parent.firstChild){
_693=null;
}else{
if(_692){
if(!_693){
_693=this.parent.firstChild;
}
}else{
if(_693){
_693=_693.nextSibling;
}
}
}
if(_693){
for(var i=0;i<data.length;++i){
var t=this._normalizedCreator(data[i]);
this.setItem(t.node.id,{data:t.data,type:t.type});
this.parent.insertBefore(t.node,_693);
}
}else{
for(var i=0;i<data.length;++i){
var t=this._normalizedCreator(data[i]);
this.setItem(t.node.id,{data:t.data,type:t.type});
this.parent.appendChild(t.node);
}
}
return this;
},destroy:function(){
dojo.forEach(this.events,dojo.disconnect);
this.clearItems();
this.node=this.parent=this.current=null;
},markupFactory:function(_694,node){
_694._skipStartup=true;
return new dojo.dnd.Container(node,_694);
},startup:function(){
if(!this.parent){
this.parent=this.node;
if(this.parent.tagName.toLowerCase()=="table"){
var c=this.parent.getElementsByTagName("tbody");
if(c&&c.length){
this.parent=c[0];
}
}
}
this.defaultCreator=dojo.dnd._defaultCreator(this.parent);
this.sync();
},onMouseOver:function(e){
var n=e.relatedTarget;
while(n){
if(n==this.node){
break;
}
try{
n=n.parentNode;
}
catch(x){
n=null;
}
}
if(!n){
this._changeState("Container","Over");
this.onOverEvent();
}
n=this._getChildByEvent(e);
if(this.current==n){
return;
}
if(this.current){
this._removeItemClass(this.current,"Over");
}
if(n){
this._addItemClass(n,"Over");
}
this.current=n;
},onMouseOut:function(e){
for(var n=e.relatedTarget;n;){
if(n==this.node){
return;
}
try{
n=n.parentNode;
}
catch(x){
n=null;
}
}
if(this.current){
this._removeItemClass(this.current,"Over");
this.current=null;
}
this._changeState("Container","");
this.onOutEvent();
},onSelectStart:function(e){
if(!this.skipForm||!dojo.dnd.isFormElement(e)){
dojo.stopEvent(e);
}
},onOverEvent:function(){
},onOutEvent:function(){
},_changeState:function(type,_695){
var _696="dojoDnd"+type;
var _697=type.toLowerCase()+"State";
dojo.replaceClass(this.node,_696+_695,_696+this[_697]);
this[_697]=_695;
},_addItemClass:function(node,type){
dojo.addClass(node,"dojoDndItem"+type);
},_removeItemClass:function(node,type){
dojo.removeClass(node,"dojoDndItem"+type);
},_getChildByEvent:function(e){
var node=e.target;
if(node){
for(var _698=node.parentNode;_698;node=_698,_698=node.parentNode){
if(_698==this.parent&&dojo.hasClass(node,"dojoDndItem")){
return node;
}
}
}
return null;
},_normalizedCreator:function(item,hint){
var t=(this.creator||this.defaultCreator).call(this,item,hint);
if(!dojo.isArray(t.type)){
t.type=["text"];
}
if(!t.node.id){
t.node.id=dojo.dnd.getUniqueId();
}
dojo.addClass(t.node,"dojoDndItem");
return t;
}});
dojo.dnd._createNode=function(tag){
if(!tag){
return dojo.dnd._createSpan;
}
return function(text){
return dojo.create(tag,{innerHTML:text});
};
};
dojo.dnd._createTrTd=function(text){
var tr=dojo.create("tr");
dojo.create("td",{innerHTML:text},tr);
return tr;
};
dojo.dnd._createSpan=function(text){
return dojo.create("span",{innerHTML:text});
};
dojo.dnd._defaultCreatorNodes={ul:"li",ol:"li",div:"div",p:"div"};
dojo.dnd._defaultCreator=function(node){
var tag=node.tagName.toLowerCase();
var c=tag=="tbody"||tag=="thead"?dojo.dnd._createTrTd:dojo.dnd._createNode(dojo.dnd._defaultCreatorNodes[tag]);
return function(item,hint){
var _699=item&&dojo.isObject(item),data,type,n;
if(_699&&item.tagName&&item.nodeType&&item.getAttribute){
data=item.getAttribute("dndData")||item.innerHTML;
type=item.getAttribute("dndType");
type=type?type.split(/\s*,\s*/):["text"];
n=item;
}else{
data=(_699&&item.data)?item.data:item;
type=(_699&&item.type)?item.type:["text"];
n=(hint=="avatar"?dojo.dnd._createSpan:c)(String(data));
}
if(!n.id){
n.id=dojo.dnd.getUniqueId();
}
return {node:n,data:data,type:type};
};
};
}
if(!dojo._hasResource["dojo.dnd.Selector"]){
dojo._hasResource["dojo.dnd.Selector"]=true;
dojo.provide("dojo.dnd.Selector");
dojo.declare("dojo.dnd.Selector",dojo.dnd.Container,{constructor:function(node,_69a){
if(!_69a){
_69a={};
}
this.singular=_69a.singular;
this.autoSync=_69a.autoSync;
this.selection={};
this.anchor=null;
this.simpleSelection=false;
this.events.push(dojo.connect(this.node,"onmousedown",this,"onMouseDown"),dojo.connect(this.node,"onmouseup",this,"onMouseUp"));
},singular:false,getSelectedNodes:function(){
var t=new dojo.NodeList();
var e=dojo.dnd._empty;
for(var i in this.selection){
if(i in e){
continue;
}
t.push(dojo.byId(i));
}
return t;
},selectNone:function(){
return this._removeSelection()._removeAnchor();
},selectAll:function(){
this.forInItems(function(data,id){
this._addItemClass(dojo.byId(id),"Selected");
this.selection[id]=1;
},this);
return this._removeAnchor();
},deleteSelectedNodes:function(){
var e=dojo.dnd._empty;
for(var i in this.selection){
if(i in e){
continue;
}
var n=dojo.byId(i);
this.delItem(i);
dojo.destroy(n);
}
this.anchor=null;
this.selection={};
return this;
},forInSelectedItems:function(f,o){
o=o||dojo.global;
var s=this.selection,e=dojo.dnd._empty;
for(var i in s){
if(i in e){
continue;
}
f.call(o,this.getItem(i),i,this);
}
},sync:function(){
dojo.dnd.Selector.superclass.sync.call(this);
if(this.anchor){
if(!this.getItem(this.anchor.id)){
this.anchor=null;
}
}
var t=[],e=dojo.dnd._empty;
for(var i in this.selection){
if(i in e){
continue;
}
if(!this.getItem(i)){
t.push(i);
}
}
dojo.forEach(t,function(i){
delete this.selection[i];
},this);
return this;
},insertNodes:function(_69b,data,_69c,_69d){
var _69e=this._normalizedCreator;
this._normalizedCreator=function(item,hint){
var t=_69e.call(this,item,hint);
if(_69b){
if(!this.anchor){
this.anchor=t.node;
this._removeItemClass(t.node,"Selected");
this._addItemClass(this.anchor,"Anchor");
}else{
if(this.anchor!=t.node){
this._removeItemClass(t.node,"Anchor");
this._addItemClass(t.node,"Selected");
}
}
this.selection[t.node.id]=1;
}else{
this._removeItemClass(t.node,"Selected");
this._removeItemClass(t.node,"Anchor");
}
return t;
};
dojo.dnd.Selector.superclass.insertNodes.call(this,data,_69c,_69d);
this._normalizedCreator=_69e;
return this;
},destroy:function(){
dojo.dnd.Selector.superclass.destroy.call(this);
this.selection=this.anchor=null;
},markupFactory:function(_69f,node){
_69f._skipStartup=true;
return new dojo.dnd.Selector(node,_69f);
},onMouseDown:function(e){
if(this.autoSync){
this.sync();
}
if(!this.current){
return;
}
if(!this.singular&&!dojo.isCopyKey(e)&&!e.shiftKey&&(this.current.id in this.selection)){
this.simpleSelection=true;
if(e.button===dojo.mouseButtons.LEFT){
dojo.stopEvent(e);
}
return;
}
if(!this.singular&&e.shiftKey){
if(!dojo.isCopyKey(e)){
this._removeSelection();
}
var c=this.getAllNodes();
if(c.length){
if(!this.anchor){
this.anchor=c[0];
this._addItemClass(this.anchor,"Anchor");
}
this.selection[this.anchor.id]=1;
if(this.anchor!=this.current){
var i=0;
for(;i<c.length;++i){
var node=c[i];
if(node==this.anchor||node==this.current){
break;
}
}
for(++i;i<c.length;++i){
var node=c[i];
if(node==this.anchor||node==this.current){
break;
}
this._addItemClass(node,"Selected");
this.selection[node.id]=1;
}
this._addItemClass(this.current,"Selected");
this.selection[this.current.id]=1;
}
}
}else{
if(this.singular){
if(this.anchor==this.current){
if(dojo.isCopyKey(e)){
this.selectNone();
}
}else{
this.selectNone();
this.anchor=this.current;
this._addItemClass(this.anchor,"Anchor");
this.selection[this.current.id]=1;
}
}else{
if(dojo.isCopyKey(e)){
if(this.anchor==this.current){
delete this.selection[this.anchor.id];
this._removeAnchor();
}else{
if(this.current.id in this.selection){
this._removeItemClass(this.current,"Selected");
delete this.selection[this.current.id];
}else{
if(this.anchor){
this._removeItemClass(this.anchor,"Anchor");
this._addItemClass(this.anchor,"Selected");
}
this.anchor=this.current;
this._addItemClass(this.current,"Anchor");
this.selection[this.current.id]=1;
}
}
}else{
if(!(this.current.id in this.selection)){
this.selectNone();
this.anchor=this.current;
this._addItemClass(this.current,"Anchor");
this.selection[this.current.id]=1;
}
}
}
}
dojo.stopEvent(e);
},onMouseUp:function(e){
if(!this.simpleSelection){
return;
}
this.simpleSelection=false;
this.selectNone();
if(this.current){
this.anchor=this.current;
this._addItemClass(this.anchor,"Anchor");
this.selection[this.current.id]=1;
}
},onMouseMove:function(e){
this.simpleSelection=false;
},onOverEvent:function(){
this.onmousemoveEvent=dojo.connect(this.node,"onmousemove",this,"onMouseMove");
},onOutEvent:function(){
dojo.disconnect(this.onmousemoveEvent);
delete this.onmousemoveEvent;
},_removeSelection:function(){
var e=dojo.dnd._empty;
for(var i in this.selection){
if(i in e){
continue;
}
var node=dojo.byId(i);
if(node){
this._removeItemClass(node,"Selected");
}
}
this.selection={};
return this;
},_removeAnchor:function(){
if(this.anchor){
this._removeItemClass(this.anchor,"Anchor");
this.anchor=null;
}
return this;
}});
}
if(!dojo._hasResource["dojo.dnd.Avatar"]){
dojo._hasResource["dojo.dnd.Avatar"]=true;
dojo.provide("dojo.dnd.Avatar");
dojo.declare("dojo.dnd.Avatar",null,{constructor:function(_6a0){
this.manager=_6a0;
this.construct();
},construct:function(){
this.isA11y=dojo.hasClass(dojo.body(),"dijit_a11y");
var a=dojo.create("table",{"class":"dojoDndAvatar",style:{position:"absolute",zIndex:"1999",margin:"0px"}}),_6a1=this.manager.source,node,b=dojo.create("tbody",null,a),tr=dojo.create("tr",null,b),td=dojo.create("td",null,tr),icon=this.isA11y?dojo.create("span",{id:"a11yIcon",innerHTML:this.manager.copy?"+":"<"},td):null,span=dojo.create("span",{innerHTML:_6a1.generateText?this._generateText():""},td),k=Math.min(5,this.manager.nodes.length),i=0;
dojo.attr(tr,{"class":"dojoDndAvatarHeader",style:{opacity:0.9}});
for(;i<k;++i){
if(_6a1.creator){
node=_6a1._normalizedCreator(_6a1.getItem(this.manager.nodes[i].id).data,"avatar").node;
}else{
node=this.manager.nodes[i].cloneNode(true);
if(node.tagName.toLowerCase()=="tr"){
var _6a2=dojo.create("table"),_6a3=dojo.create("tbody",null,_6a2);
_6a3.appendChild(node);
node=_6a2;
}
}
node.id="";
tr=dojo.create("tr",null,b);
td=dojo.create("td",null,tr);
td.appendChild(node);
dojo.attr(tr,{"class":"dojoDndAvatarItem",style:{opacity:(9-i)/10}});
}
this.node=a;
},destroy:function(){
dojo.destroy(this.node);
this.node=false;
},update:function(){
dojo[(this.manager.canDropFlag?"add":"remove")+"Class"](this.node,"dojoDndAvatarCanDrop");
if(this.isA11y){
var icon=dojo.byId("a11yIcon");
var text="+";
if(this.manager.canDropFlag&&!this.manager.copy){
text="< ";
}else{
if(!this.manager.canDropFlag&&!this.manager.copy){
text="o";
}else{
if(!this.manager.canDropFlag){
text="x";
}
}
}
icon.innerHTML=text;
}
dojo.query(("tr.dojoDndAvatarHeader td span"+(this.isA11y?" span":"")),this.node).forEach(function(node){
node.innerHTML=this._generateText();
},this);
},_generateText:function(){
return this.manager.nodes.length.toString();
}});
}
if(!dojo._hasResource["dojo.dnd.Manager"]){
dojo._hasResource["dojo.dnd.Manager"]=true;
dojo.provide("dojo.dnd.Manager");
dojo.declare("dojo.dnd.Manager",null,{constructor:function(){
this.avatar=null;
this.source=null;
this.nodes=[];
this.copy=true;
this.target=null;
this.canDropFlag=false;
this.events=[];
},OFFSET_X:16,OFFSET_Y:16,overSource:function(_6a4){
if(this.avatar){
this.target=(_6a4&&_6a4.targetState!="Disabled")?_6a4:null;
this.canDropFlag=Boolean(this.target);
this.avatar.update();
}
dojo.publish("/dnd/source/over",[_6a4]);
},outSource:function(_6a5){
if(this.avatar){
if(this.target==_6a5){
this.target=null;
this.canDropFlag=false;
this.avatar.update();
dojo.publish("/dnd/source/over",[null]);
}
}else{
dojo.publish("/dnd/source/over",[null]);
}
},startDrag:function(_6a6,_6a7,copy){
this.source=_6a6;
this.nodes=_6a7;
this.copy=Boolean(copy);
this.avatar=this.makeAvatar();
dojo.body().appendChild(this.avatar.node);
dojo.publish("/dnd/start",[_6a6,_6a7,this.copy]);
this.events=[dojo.connect(dojo.doc,"onmousemove",this,"onMouseMove"),dojo.connect(dojo.doc,"onmouseup",this,"onMouseUp"),dojo.connect(dojo.doc,"onkeydown",this,"onKeyDown"),dojo.connect(dojo.doc,"onkeyup",this,"onKeyUp"),dojo.connect(dojo.doc,"ondragstart",dojo.stopEvent),dojo.connect(dojo.body(),"onselectstart",dojo.stopEvent)];
var c="dojoDnd"+(copy?"Copy":"Move");
dojo.addClass(dojo.body(),c);
},canDrop:function(flag){
var _6a8=Boolean(this.target&&flag);
if(this.canDropFlag!=_6a8){
this.canDropFlag=_6a8;
this.avatar.update();
}
},stopDrag:function(){
dojo.removeClass(dojo.body(),["dojoDndCopy","dojoDndMove"]);
dojo.forEach(this.events,dojo.disconnect);
this.events=[];
this.avatar.destroy();
this.avatar=null;
this.source=this.target=null;
this.nodes=[];
},makeAvatar:function(){
return new dojo.dnd.Avatar(this);
},updateAvatar:function(){
this.avatar.update();
},onMouseMove:function(e){
var a=this.avatar;
if(a){
dojo.dnd.autoScrollNodes(e);
var s=a.node.style;
s.left=(e.pageX+this.OFFSET_X)+"px";
s.top=(e.pageY+this.OFFSET_Y)+"px";
var copy=Boolean(this.source.copyState(dojo.isCopyKey(e)));
if(this.copy!=copy){
this._setCopyStatus(copy);
}
}
},onMouseUp:function(e){
if(this.avatar){
if(this.target&&this.canDropFlag){
var copy=Boolean(this.source.copyState(dojo.isCopyKey(e))),_6a9=[this.source,this.nodes,copy,this.target,e];
dojo.publish("/dnd/drop/before",_6a9);
dojo.publish("/dnd/drop",_6a9);
}else{
dojo.publish("/dnd/cancel");
}
this.stopDrag();
}
},onKeyDown:function(e){
if(this.avatar){
switch(e.keyCode){
case dojo.keys.CTRL:
var copy=Boolean(this.source.copyState(true));
if(this.copy!=copy){
this._setCopyStatus(copy);
}
break;
case dojo.keys.ESCAPE:
dojo.publish("/dnd/cancel");
this.stopDrag();
break;
}
}
},onKeyUp:function(e){
if(this.avatar&&e.keyCode==dojo.keys.CTRL){
var copy=Boolean(this.source.copyState(false));
if(this.copy!=copy){
this._setCopyStatus(copy);
}
}
},_setCopyStatus:function(copy){
this.copy=copy;
this.source._markDndStatus(this.copy);
this.updateAvatar();
dojo.replaceClass(dojo.body(),"dojoDnd"+(this.copy?"Copy":"Move"),"dojoDnd"+(this.copy?"Move":"Copy"));
}});
dojo.dnd._manager=null;
dojo.dnd.manager=function(){
if(!dojo.dnd._manager){
dojo.dnd._manager=new dojo.dnd.Manager();
}
return dojo.dnd._manager;
};
}
if(!dojo._hasResource["dojo.dnd.Source"]){
dojo._hasResource["dojo.dnd.Source"]=true;
dojo.provide("dojo.dnd.Source");
dojo.declare("dojo.dnd.Source",dojo.dnd.Selector,{isSource:true,horizontal:false,copyOnly:false,selfCopy:false,selfAccept:true,skipForm:false,withHandles:false,autoSync:false,delay:0,accept:["text"],generateText:true,constructor:function(node,_6aa){
dojo.mixin(this,dojo.mixin({},_6aa));
var type=this.accept;
if(type.length){
this.accept={};
for(var i=0;i<type.length;++i){
this.accept[type[i]]=1;
}
}
this.isDragging=false;
this.mouseDown=false;
this.targetAnchor=null;
this.targetBox=null;
this.before=true;
this._lastX=0;
this._lastY=0;
this.sourceState="";
if(this.isSource){
dojo.addClass(this.node,"dojoDndSource");
}
this.targetState="";
if(this.accept){
dojo.addClass(this.node,"dojoDndTarget");
}
if(this.horizontal){
dojo.addClass(this.node,"dojoDndHorizontal");
}
this.topics=[dojo.subscribe("/dnd/source/over",this,"onDndSourceOver"),dojo.subscribe("/dnd/start",this,"onDndStart"),dojo.subscribe("/dnd/drop",this,"onDndDrop"),dojo.subscribe("/dnd/cancel",this,"onDndCancel")];
},checkAcceptance:function(_6ab,_6ac){
if(this==_6ab){
return !this.copyOnly||this.selfAccept;
}
for(var i=0;i<_6ac.length;++i){
var type=_6ab.getItem(_6ac[i].id).type;
var flag=false;
for(var j=0;j<type.length;++j){
if(type[j] in this.accept){
flag=true;
break;
}
}
if(!flag){
return false;
}
}
return true;
},copyState:function(_6ad,self){
if(_6ad){
return true;
}
if(arguments.length<2){
self=this==dojo.dnd.manager().target;
}
if(self){
if(this.copyOnly){
return this.selfCopy;
}
}else{
return this.copyOnly;
}
return false;
},destroy:function(){
dojo.dnd.Source.superclass.destroy.call(this);
dojo.forEach(this.topics,dojo.unsubscribe);
this.targetAnchor=null;
},markupFactory:function(_6ae,node){
_6ae._skipStartup=true;
return new dojo.dnd.Source(node,_6ae);
},onMouseMove:function(e){
if(this.isDragging&&this.targetState=="Disabled"){
return;
}
dojo.dnd.Source.superclass.onMouseMove.call(this,e);
var m=dojo.dnd.manager();
if(!this.isDragging){
if(this.mouseDown&&this.isSource&&(Math.abs(e.pageX-this._lastX)>this.delay||Math.abs(e.pageY-this._lastY)>this.delay)){
var _6af=this.getSelectedNodes();
if(_6af.length){
m.startDrag(this,_6af,this.copyState(dojo.isCopyKey(e),true));
}
}
}
if(this.isDragging){
var _6b0=false;
if(this.current){
if(!this.targetBox||this.targetAnchor!=this.current){
this.targetBox=dojo.position(this.current,true);
}
if(this.horizontal){
_6b0=(e.pageX-this.targetBox.x)<(this.targetBox.w/2);
}else{
_6b0=(e.pageY-this.targetBox.y)<(this.targetBox.h/2);
}
}
if(this.current!=this.targetAnchor||_6b0!=this.before){
this._markTargetAnchor(_6b0);
m.canDrop(!this.current||m.source!=this||!(this.current.id in this.selection));
}
}
},onMouseDown:function(e){
if(!this.mouseDown&&this._legalMouseDown(e)&&(!this.skipForm||!dojo.dnd.isFormElement(e))){
this.mouseDown=true;
this._lastX=e.pageX;
this._lastY=e.pageY;
dojo.dnd.Source.superclass.onMouseDown.call(this,e);
}
},onMouseUp:function(e){
if(this.mouseDown){
this.mouseDown=false;
dojo.dnd.Source.superclass.onMouseUp.call(this,e);
}
},onDndSourceOver:function(_6b1){
if(this!=_6b1){
this.mouseDown=false;
if(this.targetAnchor){
this._unmarkTargetAnchor();
}
}else{
if(this.isDragging){
var m=dojo.dnd.manager();
m.canDrop(this.targetState!="Disabled"&&(!this.current||m.source!=this||!(this.current.id in this.selection)));
}
}
},onDndStart:function(_6b2,_6b3,copy){
if(this.autoSync){
this.sync();
}
if(this.isSource){
this._changeState("Source",this==_6b2?(copy?"Copied":"Moved"):"");
}
var _6b4=this.accept&&this.checkAcceptance(_6b2,_6b3);
this._changeState("Target",_6b4?"":"Disabled");
if(this==_6b2){
dojo.dnd.manager().overSource(this);
}
this.isDragging=true;
},onDndDrop:function(_6b5,_6b6,copy,_6b7){
if(this==_6b7){
this.onDrop(_6b5,_6b6,copy);
}
this.onDndCancel();
},onDndCancel:function(){
if(this.targetAnchor){
this._unmarkTargetAnchor();
this.targetAnchor=null;
}
this.before=true;
this.isDragging=false;
this.mouseDown=false;
this._changeState("Source","");
this._changeState("Target","");
},onDrop:function(_6b8,_6b9,copy){
if(this!=_6b8){
this.onDropExternal(_6b8,_6b9,copy);
}else{
this.onDropInternal(_6b9,copy);
}
},onDropExternal:function(_6ba,_6bb,copy){
var _6bc=this._normalizedCreator;
if(this.creator){
this._normalizedCreator=function(node,hint){
return _6bc.call(this,_6ba.getItem(node.id).data,hint);
};
}else{
if(copy){
this._normalizedCreator=function(node,hint){
var t=_6ba.getItem(node.id);
var n=node.cloneNode(true);
n.id=dojo.dnd.getUniqueId();
return {node:n,data:t.data,type:t.type};
};
}else{
this._normalizedCreator=function(node,hint){
var t=_6ba.getItem(node.id);
_6ba.delItem(node.id);
return {node:node,data:t.data,type:t.type};
};
}
}
this.selectNone();
if(!copy&&!this.creator){
_6ba.selectNone();
}
this.insertNodes(true,_6bb,this.before,this.current);
if(!copy&&this.creator){
_6ba.deleteSelectedNodes();
}
this._normalizedCreator=_6bc;
},onDropInternal:function(_6bd,copy){
var _6be=this._normalizedCreator;
if(this.current&&this.current.id in this.selection){
return;
}
if(copy){
if(this.creator){
this._normalizedCreator=function(node,hint){
return _6be.call(this,this.getItem(node.id).data,hint);
};
}else{
this._normalizedCreator=function(node,hint){
var t=this.getItem(node.id);
var n=node.cloneNode(true);
n.id=dojo.dnd.getUniqueId();
return {node:n,data:t.data,type:t.type};
};
}
}else{
if(!this.current){
return;
}
this._normalizedCreator=function(node,hint){
var t=this.getItem(node.id);
return {node:node,data:t.data,type:t.type};
};
}
this._removeSelection();
this.insertNodes(true,_6bd,this.before,this.current);
this._normalizedCreator=_6be;
},onDraggingOver:function(){
},onDraggingOut:function(){
},onOverEvent:function(){
dojo.dnd.Source.superclass.onOverEvent.call(this);
dojo.dnd.manager().overSource(this);
if(this.isDragging&&this.targetState!="Disabled"){
this.onDraggingOver();
}
},onOutEvent:function(){
dojo.dnd.Source.superclass.onOutEvent.call(this);
dojo.dnd.manager().outSource(this);
if(this.isDragging&&this.targetState!="Disabled"){
this.onDraggingOut();
}
},_markTargetAnchor:function(_6bf){
if(this.current==this.targetAnchor&&this.before==_6bf){
return;
}
if(this.targetAnchor){
this._removeItemClass(this.targetAnchor,this.before?"Before":"After");
}
this.targetAnchor=this.current;
this.targetBox=null;
this.before=_6bf;
if(this.targetAnchor){
this._addItemClass(this.targetAnchor,this.before?"Before":"After");
}
},_unmarkTargetAnchor:function(){
if(!this.targetAnchor){
return;
}
this._removeItemClass(this.targetAnchor,this.before?"Before":"After");
this.targetAnchor=null;
this.targetBox=null;
this.before=true;
},_markDndStatus:function(copy){
this._changeState("Source",copy?"Copied":"Moved");
},_legalMouseDown:function(e){
if(!dojo.mouseButtons.isLeft(e)){
return false;
}
if(!this.withHandles){
return true;
}
for(var node=e.target;node&&node!==this.node;node=node.parentNode){
if(dojo.hasClass(node,"dojoDndHandle")){
return true;
}
if(dojo.hasClass(node,"dojoDndItem")||dojo.hasClass(node,"dojoDndIgnore")){
break;
}
}
return false;
}});
dojo.declare("dojo.dnd.Target",dojo.dnd.Source,{constructor:function(node,_6c0){
this.isSource=false;
dojo.removeClass(this.node,"dojoDndSource");
},markupFactory:function(_6c1,node){
_6c1._skipStartup=true;
return new dojo.dnd.Target(node,_6c1);
}});
dojo.declare("dojo.dnd.AutoSource",dojo.dnd.Source,{constructor:function(node,_6c2){
this.autoSync=true;
},markupFactory:function(_6c3,node){
_6c3._skipStartup=true;
return new dojo.dnd.AutoSource(node,_6c3);
}});
}
if(!dojo._hasResource["dojox.grid._View"]){
dojo._hasResource["dojox.grid._View"]=true;
dojo.provide("dojox.grid._View");
(function(){
var _6c4=function(_6c5,_6c6){
return _6c5.style.cssText==undefined?_6c5.getAttribute("style"):_6c5.style.cssText;
};
dojo.declare("dojox.grid._View",[dijit._Widget,dijit._Templated],{defaultWidth:"18em",viewWidth:"",templateString:"<div class=\"dojoxGridView\" role=\"presentation\">\r\n\t<div class=\"dojoxGridHeader\" dojoAttachPoint=\"headerNode\" role=\"presentation\">\r\n\t\t<div dojoAttachPoint=\"headerNodeContainer\" style=\"width:9000em\" role=\"presentation\">\r\n\t\t\t<div dojoAttachPoint=\"headerContentNode\" role=\"row\"></div>\r\n\t\t</div>\r\n\t</div>\r\n\t<input type=\"checkbox\" class=\"dojoxGridHiddenFocus\" dojoAttachPoint=\"hiddenFocusNode\" role=\"presentation\" />\r\n\t<input type=\"checkbox\" class=\"dojoxGridHiddenFocus\" role=\"presentation\" />\r\n\t<div class=\"dojoxGridScrollbox\" dojoAttachPoint=\"scrollboxNode\" role=\"presentation\">\r\n\t\t<div class=\"dojoxGridContent\" dojoAttachPoint=\"contentNode\" hidefocus=\"hidefocus\" role=\"presentation\"></div>\r\n\t</div>\r\n</div>\r\n",themeable:false,classTag:"dojoxGrid",marginBottom:0,rowPad:2,_togglingColumn:-1,_headerBuilderClass:dojox.grid._HeaderBuilder,_contentBuilderClass:dojox.grid._ContentBuilder,postMixInProperties:function(){
this.rowNodes={};
},postCreate:function(){
this.connect(this.scrollboxNode,"onscroll","doscroll");
dojox.grid.util.funnelEvents(this.contentNode,this,"doContentEvent",["mouseover","mouseout","click","dblclick","contextmenu","mousedown"]);
dojox.grid.util.funnelEvents(this.headerNode,this,"doHeaderEvent",["dblclick","mouseover","mouseout","mousemove","mousedown","click","contextmenu"]);
this.content=new this._contentBuilderClass(this);
this.header=new this._headerBuilderClass(this);
if(!dojo._isBodyLtr()){
this.headerNodeContainer.style.width="";
}
},destroy:function(){
dojo.destroy(this.headerNode);
delete this.headerNode;
for(var i in this.rowNodes){
this._cleanupRowWidgets(this.rowNodes[i]);
dojo.destroy(this.rowNodes[i]);
}
this.rowNodes={};
if(this.source){
this.source.destroy();
}
this.inherited(arguments);
},focus:function(){
if(dojo.isIE||dojo.isWebKit||dojo.isOpera){
this.hiddenFocusNode.focus();
}else{
this.scrollboxNode.focus();
}
},setStructure:function(_6c7){
var vs=(this.structure=_6c7);
if(vs.width&&!isNaN(vs.width)){
this.viewWidth=vs.width+"em";
}else{
this.viewWidth=vs.width||(vs.noscroll?"":this.viewWidth);
}
this._onBeforeRow=vs.onBeforeRow||function(){
};
this._onAfterRow=vs.onAfterRow||function(){
};
this.noscroll=vs.noscroll;
if(this.noscroll){
this.scrollboxNode.style.overflow="hidden";
}
this.simpleStructure=Boolean(vs.cells.length==1);
this.testFlexCells();
this.updateStructure();
},_cleanupRowWidgets:function(_6c8){
if(_6c8){
dojo.forEach(dojo.query("[widgetId]",_6c8).map(dijit.byNode),function(w){
if(w._destroyOnRemove){
w.destroy();
delete w;
}else{
if(w.domNode&&w.domNode.parentNode){
w.domNode.parentNode.removeChild(w.domNode);
}
}
});
}
},onBeforeRow:function(_6c9,_6ca){
this._onBeforeRow(_6c9,_6ca);
if(_6c9>=0){
this._cleanupRowWidgets(this.getRowNode(_6c9));
}
},onAfterRow:function(_6cb,_6cc,_6cd){
this._onAfterRow(_6cb,_6cc,_6cd);
var g=this.grid;
dojo.forEach(dojo.query(".dojoxGridStubNode",_6cd),function(n){
if(n&&n.parentNode){
var lw=n.getAttribute("linkWidget");
var _6ce=window.parseInt(dojo.attr(n,"cellIdx"),10);
var _6cf=g.getCell(_6ce);
var w=dijit.byId(lw);
if(w){
n.parentNode.replaceChild(w.domNode,n);
if(!w._started){
w.startup();
}
dojo.destroy(n);
}else{
n.innerHTML="";
}
}
},this);
},testFlexCells:function(){
this.flexCells=false;
for(var j=0,row;(row=this.structure.cells[j]);j++){
for(var i=0,cell;(cell=row[i]);i++){
cell.view=this;
this.flexCells=this.flexCells||cell.isFlex();
}
}
return this.flexCells;
},updateStructure:function(){
this.header.update();
this.content.update();
},getScrollbarWidth:function(){
var _6d0=this.hasVScrollbar();
var _6d1=dojo.style(this.scrollboxNode,"overflow");
if(this.noscroll||!_6d1||_6d1=="hidden"){
_6d0=false;
}else{
if(_6d1=="scroll"){
_6d0=true;
}
}
return (_6d0?dojox.html.metrics.getScrollbar().w:0);
},getColumnsWidth:function(){
var h=this.headerContentNode;
return h&&h.firstChild?h.firstChild.offsetWidth:0;
},setColumnsWidth:function(_6d2){
this.headerContentNode.firstChild.style.width=_6d2+"px";
if(this.viewWidth){
this.viewWidth=_6d2+"px";
}
},getWidth:function(){
return this.viewWidth||(this.getColumnsWidth()+this.getScrollbarWidth())+"px";
},getContentWidth:function(){
return Math.max(0,dojo._getContentBox(this.domNode).w-this.getScrollbarWidth())+"px";
},render:function(){
this.scrollboxNode.style.height="";
this.renderHeader();
if(this._togglingColumn>=0){
this.setColumnsWidth(this.getColumnsWidth()-this._togglingColumn);
this._togglingColumn=-1;
}
var _6d3=this.grid.layout.cells;
var _6d4=dojo.hitch(this,function(node,_6d5){
!dojo._isBodyLtr()&&(_6d5=!_6d5);
var inc=_6d5?-1:1;
var idx=this.header.getCellNodeIndex(node)+inc;
var cell=_6d3[idx];
while(cell&&cell.getHeaderNode()&&cell.getHeaderNode().style.display=="none"){
idx+=inc;
cell=_6d3[idx];
}
if(cell){
return cell.getHeaderNode();
}
return null;
});
if(this.grid.columnReordering&&this.simpleStructure){
if(this.source){
this.source.destroy();
}
var _6d6="dojoxGrid_bottomMarker";
var _6d7="dojoxGrid_topMarker";
if(this.bottomMarker){
dojo.destroy(this.bottomMarker);
}
this.bottomMarker=dojo.byId(_6d6);
if(this.topMarker){
dojo.destroy(this.topMarker);
}
this.topMarker=dojo.byId(_6d7);
if(!this.bottomMarker){
this.bottomMarker=dojo.create("div",{"id":_6d6,"class":"dojoxGridColPlaceBottom"},dojo.body());
this._hide(this.bottomMarker);
this.topMarker=dojo.create("div",{"id":_6d7,"class":"dojoxGridColPlaceTop"},dojo.body());
this._hide(this.topMarker);
}
this.arrowDim=dojo.contentBox(this.bottomMarker);
var _6d8=dojo.contentBox(this.headerContentNode.firstChild.rows[0]).h;
this.source=new dojo.dnd.Source(this.headerContentNode.firstChild.rows[0],{horizontal:true,accept:["gridColumn_"+this.grid.id],viewIndex:this.index,generateText:false,onMouseDown:dojo.hitch(this,function(e){
this.header.decorateEvent(e);
if((this.header.overRightResizeArea(e)||this.header.overLeftResizeArea(e))&&this.header.canResize(e)&&!this.header.moveable){
this.header.beginColumnResize(e);
}else{
if(this.grid.headerMenu){
this.grid.headerMenu.onCancel(true);
}
if(e.button===(dojo.isIE?1:0)){
dojo.dnd.Source.prototype.onMouseDown.call(this.source,e);
}
}
}),onMouseOver:dojo.hitch(this,function(e){
var src=this.source;
if(src._getChildByEvent(e)){
dojo.dnd.Source.prototype.onMouseOver.apply(src,arguments);
}
}),_markTargetAnchor:dojo.hitch(this,function(_6d9){
var src=this.source;
if(src.current==src.targetAnchor&&src.before==_6d9){
return;
}
if(src.targetAnchor&&_6d4(src.targetAnchor,src.before)){
src._removeItemClass(_6d4(src.targetAnchor,src.before),src.before?"After":"Before");
}
dojo.dnd.Source.prototype._markTargetAnchor.call(src,_6d9);
var _6da=_6d9?src.targetAnchor:_6d4(src.targetAnchor,src.before);
var _6db=0;
if(!_6da){
_6da=src.targetAnchor;
_6db=dojo.contentBox(_6da).w+this.arrowDim.w/2+2;
}
var pos=(dojo.position||dojo._abs)(_6da,true);
var left=Math.floor(pos.x-this.arrowDim.w/2+_6db);
dojo.style(this.bottomMarker,"visibility","visible");
dojo.style(this.topMarker,"visibility","visible");
dojo.style(this.bottomMarker,{"left":left+"px","top":(_6d8+pos.y)+"px"});
dojo.style(this.topMarker,{"left":left+"px","top":(pos.y-this.arrowDim.h)+"px"});
if(src.targetAnchor&&_6d4(src.targetAnchor,src.before)){
src._addItemClass(_6d4(src.targetAnchor,src.before),src.before?"After":"Before");
}
}),_unmarkTargetAnchor:dojo.hitch(this,function(){
var src=this.source;
if(!src.targetAnchor){
return;
}
if(src.targetAnchor&&_6d4(src.targetAnchor,src.before)){
src._removeItemClass(_6d4(src.targetAnchor,src.before),src.before?"After":"Before");
}
this._hide(this.bottomMarker);
this._hide(this.topMarker);
dojo.dnd.Source.prototype._unmarkTargetAnchor.call(src);
}),destroy:dojo.hitch(this,function(){
dojo.disconnect(this._source_conn);
dojo.unsubscribe(this._source_sub);
dojo.dnd.Source.prototype.destroy.call(this.source);
if(this.bottomMarker){
dojo.destroy(this.bottomMarker);
delete this.bottomMarker;
}
if(this.topMarker){
dojo.destroy(this.topMarker);
delete this.topMarker;
}
}),onDndCancel:dojo.hitch(this,function(){
dojo.dnd.Source.prototype.onDndCancel.call(this.source);
this._hide(this.bottomMarker);
this._hide(this.topMarker);
})});
this._source_conn=dojo.connect(this.source,"onDndDrop",this,"_onDndDrop");
this._source_sub=dojo.subscribe("/dnd/drop/before",this,"_onDndDropBefore");
this.source.startup();
}
},_hide:function(node){
dojo.style(node,{left:"-10000px",top:"-10000px","visibility":"hidden"});
},_onDndDropBefore:function(_6dc,_6dd,copy){
if(dojo.dnd.manager().target!==this.source){
return;
}
this.source._targetNode=this.source.targetAnchor;
this.source._beforeTarget=this.source.before;
var _6de=this.grid.views.views;
var _6df=_6de[_6dc.viewIndex];
var _6e0=_6de[this.index];
if(_6e0!=_6df){
_6df.convertColPctToFixed();
_6e0.convertColPctToFixed();
}
},_onDndDrop:function(_6e1,_6e2,copy){
if(dojo.dnd.manager().target!==this.source){
if(dojo.dnd.manager().source===this.source){
this._removingColumn=true;
}
return;
}
this._hide(this.bottomMarker);
this._hide(this.topMarker);
var _6e3=function(n){
return n?dojo.attr(n,"idx"):null;
};
var w=dojo.marginBox(_6e2[0]).w;
if(_6e1.viewIndex!==this.index){
var _6e4=this.grid.views.views;
var _6e5=_6e4[_6e1.viewIndex];
var _6e6=_6e4[this.index];
if(_6e5.viewWidth&&_6e5.viewWidth!="auto"){
_6e5.setColumnsWidth(_6e5.getColumnsWidth()-w);
}
if(_6e6.viewWidth&&_6e6.viewWidth!="auto"){
_6e6.setColumnsWidth(_6e6.getColumnsWidth());
}
}
var stn=this.source._targetNode;
var stb=this.source._beforeTarget;
!dojo._isBodyLtr()&&(stb=!stb);
var _6e7=this.grid.layout;
var idx=this.index;
delete this.source._targetNode;
delete this.source._beforeTarget;
_6e7.moveColumn(_6e1.viewIndex,idx,_6e3(_6e2[0]),_6e3(stn),stb);
},renderHeader:function(){
this.headerContentNode.innerHTML=this.header.generateHtml(this._getHeaderContent);
if(this.flexCells){
this.contentWidth=this.getContentWidth();
this.headerContentNode.firstChild.style.width=this.contentWidth;
}
dojox.grid.util.fire(this,"onAfterRow",[-1,this.structure.cells,this.headerContentNode]);
},_getHeaderContent:function(_6e8){
var n=_6e8.name||_6e8.grid.getCellName(_6e8);
if(/^\s+$/.test(n)){
n="&nbsp;";
}
var ret=["<div class=\"dojoxGridSortNode"];
if(_6e8.index!=_6e8.grid.getSortIndex()){
ret.push("\">");
}else{
ret=ret.concat([" ",_6e8.grid.sortInfo>0?"dojoxGridSortUp":"dojoxGridSortDown","\"><div class=\"dojoxGridArrowButtonChar\">",_6e8.grid.sortInfo>0?"&#9650;":"&#9660;","</div><div class=\"dojoxGridArrowButtonNode\" role=\"presentation\"></div>","<div class=\"dojoxGridColCaption\">"]);
}
ret=ret.concat([n,"</div></div>"]);
return ret.join("");
},resize:function(){
this.adaptHeight();
this.adaptWidth();
},hasHScrollbar:function(_6e9){
var _6ea=this._hasHScroll||false;
if(this._hasHScroll==undefined||_6e9){
if(this.noscroll){
this._hasHScroll=false;
}else{
var _6eb=dojo.style(this.scrollboxNode,"overflow");
if(_6eb=="hidden"){
this._hasHScroll=false;
}else{
if(_6eb=="scroll"){
this._hasHScroll=true;
}else{
this._hasHScroll=(this.scrollboxNode.offsetWidth-this.getScrollbarWidth()<this.contentNode.offsetWidth);
}
}
}
}
if(_6ea!==this._hasHScroll){
this.grid.update();
}
return this._hasHScroll;
},hasVScrollbar:function(_6ec){
var _6ed=this._hasVScroll||false;
if(this._hasVScroll==undefined||_6ec){
if(this.noscroll){
this._hasVScroll=false;
}else{
var _6ee=dojo.style(this.scrollboxNode,"overflow");
if(_6ee=="hidden"){
this._hasVScroll=false;
}else{
if(_6ee=="scroll"){
this._hasVScroll=true;
}else{
this._hasVScroll=(this.scrollboxNode.scrollHeight>this.scrollboxNode.clientHeight);
}
}
}
}
if(_6ed!==this._hasVScroll){
this.grid.update();
}
return this._hasVScroll;
},convertColPctToFixed:function(){
var _6ef=false;
this.grid.initialWidth="";
var _6f0=dojo.query("th",this.headerContentNode);
var _6f1=dojo.map(_6f0,function(c,vIdx){
var w=c.style.width;
dojo.attr(c,"vIdx",vIdx);
if(w&&w.slice(-1)=="%"){
_6ef=true;
}else{
if(w&&w.slice(-2)=="px"){
return window.parseInt(w,10);
}
}
return dojo.contentBox(c).w;
});
if(_6ef){
dojo.forEach(this.grid.layout.cells,function(cell,idx){
if(cell.view==this){
var _6f2=cell.view.getHeaderCellNode(cell.index);
if(_6f2&&dojo.hasAttr(_6f2,"vIdx")){
var vIdx=window.parseInt(dojo.attr(_6f2,"vIdx"));
this.setColWidth(idx,_6f1[vIdx]);
dojo.removeAttr(_6f2,"vIdx");
}
}
},this);
return true;
}
return false;
},adaptHeight:function(_6f3){
if(!this.grid._autoHeight){
var h=(this.domNode.style.height&&parseInt(this.domNode.style.height.replace(/px/,""),10))||this.domNode.clientHeight;
var self=this;
var _6f4=function(){
var v;
for(var i in self.grid.views.views){
v=self.grid.views.views[i];
if(v!==self&&v.hasHScrollbar()){
return true;
}
}
return false;
};
if(_6f3||(this.noscroll&&_6f4())){
h-=dojox.html.metrics.getScrollbar().h;
}
dojox.grid.util.setStyleHeightPx(this.scrollboxNode,h);
}
this.hasVScrollbar(true);
},adaptWidth:function(){
if(this.flexCells){
this.contentWidth=this.getContentWidth();
this.headerContentNode.firstChild.style.width=this.contentWidth;
}
var w=this.scrollboxNode.offsetWidth-this.getScrollbarWidth();
if(!this._removingColumn){
w=Math.max(w,this.getColumnsWidth())+"px";
}else{
w=Math.min(w,this.getColumnsWidth())+"px";
this._removingColumn=false;
}
var cn=this.contentNode;
cn.style.width=w;
this.hasHScrollbar(true);
},setSize:function(w,h){
var ds=this.domNode.style;
var hs=this.headerNode.style;
if(w){
ds.width=w;
hs.width=w;
}
ds.height=(h>=0?h+"px":"");
},renderRow:function(_6f5){
var _6f6=this.createRowNode(_6f5);
this.buildRow(_6f5,_6f6);
return _6f6;
},createRowNode:function(_6f7){
var node=document.createElement("div");
node.className=this.classTag+"Row";
if(this instanceof dojox.grid._RowSelector){
dojo.attr(node,"role","presentation");
}else{
dojo.attr(node,"role","row");
if(this.grid.selectionMode!="none"){
node.setAttribute("aria-selected","false");
}
}
node[dojox.grid.util.gridViewTag]=this.id;
node[dojox.grid.util.rowIndexTag]=_6f7;
this.rowNodes[_6f7]=node;
return node;
},buildRow:function(_6f8,_6f9){
this.buildRowContent(_6f8,_6f9);
this.styleRow(_6f8,_6f9);
},buildRowContent:function(_6fa,_6fb){
_6fb.innerHTML=this.content.generateHtml(_6fa,_6fa);
if(this.flexCells&&this.contentWidth){
_6fb.firstChild.style.width=this.contentWidth;
}
dojox.grid.util.fire(this,"onAfterRow",[_6fa,this.structure.cells,_6fb]);
},rowRemoved:function(_6fc){
if(_6fc>=0){
this._cleanupRowWidgets(this.getRowNode(_6fc));
}
this.grid.edit.save(this,_6fc);
delete this.rowNodes[_6fc];
},getRowNode:function(_6fd){
return this.rowNodes[_6fd];
},getCellNode:function(_6fe,_6ff){
var row=this.getRowNode(_6fe);
if(row){
return this.content.getCellNode(row,_6ff);
}
},getHeaderCellNode:function(_700){
if(this.headerContentNode){
return this.header.getCellNode(this.headerContentNode,_700);
}
},styleRow:function(_701,_702){
_702._style=_6c4(_702);
this.styleRowNode(_701,_702);
},styleRowNode:function(_703,_704){
if(_704){
this.doStyleRowNode(_703,_704);
}
},doStyleRowNode:function(_705,_706){
this.grid.styleRowNode(_705,_706);
},updateRow:function(_707){
var _708=this.getRowNode(_707);
if(_708){
_708.style.height="";
this.buildRow(_707,_708);
}
return _708;
},updateRowStyles:function(_709){
this.styleRowNode(_709,this.getRowNode(_709));
},lastTop:0,firstScroll:0,doscroll:function(_70a){
var _70b=dojo._isBodyLtr();
if(this.firstScroll<2){
if((!_70b&&this.firstScroll==1)||(_70b&&this.firstScroll===0)){
var s=dojo.marginBox(this.headerNodeContainer);
if(dojo.isIE){
this.headerNodeContainer.style.width=s.w+this.getScrollbarWidth()+"px";
}else{
if(dojo.isMoz){
this.headerNodeContainer.style.width=s.w-this.getScrollbarWidth()+"px";
this.scrollboxNode.scrollLeft=_70b?this.scrollboxNode.clientWidth-this.scrollboxNode.scrollWidth:this.scrollboxNode.scrollWidth-this.scrollboxNode.clientWidth;
}
}
}
this.firstScroll++;
}
this.headerNode.scrollLeft=this.scrollboxNode.scrollLeft;
var top=this.scrollboxNode.scrollTop;
if(top!==this.lastTop){
this.grid.scrollTo(top);
}
},setScrollTop:function(_70c){
this.lastTop=_70c;
this.scrollboxNode.scrollTop=_70c;
return this.scrollboxNode.scrollTop;
},doContentEvent:function(e){
if(this.content.decorateEvent(e)){
this.grid.onContentEvent(e);
}
},doHeaderEvent:function(e){
if(this.header.decorateEvent(e)){
this.grid.onHeaderEvent(e);
}
},dispatchContentEvent:function(e){
return this.content.dispatchEvent(e);
},dispatchHeaderEvent:function(e){
return this.header.dispatchEvent(e);
},setColWidth:function(_70d,_70e){
this.grid.setCellWidth(_70d,_70e+"px");
},update:function(){
if(!this.domNode){
return;
}
this.content.update();
this.grid.update();
var left=this.scrollboxNode.scrollLeft;
this.scrollboxNode.scrollLeft=left;
this.headerNode.scrollLeft=left;
}});
dojo.declare("dojox.grid._GridAvatar",dojo.dnd.Avatar,{construct:function(){
var dd=dojo.doc;
var a=dd.createElement("table");
a.cellPadding=a.cellSpacing="0";
a.className="dojoxGridDndAvatar";
a.style.position="absolute";
a.style.zIndex=1999;
a.style.margin="0px";
var b=dd.createElement("tbody");
var tr=dd.createElement("tr");
var td=dd.createElement("td");
var img=dd.createElement("td");
tr.className="dojoxGridDndAvatarItem";
img.className="dojoxGridDndAvatarItemImage";
img.style.width="16px";
var _70f=this.manager.source,node;
if(_70f.creator){
node=_70f._normalizedCreator(_70f.getItem(this.manager.nodes[0].id).data,"avatar").node;
}else{
node=this.manager.nodes[0].cloneNode(true);
var _710,_711;
if(node.tagName.toLowerCase()=="tr"){
_710=dd.createElement("table");
_711=dd.createElement("tbody");
_711.appendChild(node);
_710.appendChild(_711);
node=_710;
}else{
if(node.tagName.toLowerCase()=="th"){
_710=dd.createElement("table");
_711=dd.createElement("tbody");
var r=dd.createElement("tr");
_710.cellPadding=_710.cellSpacing="0";
r.appendChild(node);
_711.appendChild(r);
_710.appendChild(_711);
node=_710;
}
}
}
node.id="";
td.appendChild(node);
tr.appendChild(img);
tr.appendChild(td);
dojo.style(tr,"opacity",0.9);
b.appendChild(tr);
a.appendChild(b);
this.node=a;
var m=dojo.dnd.manager();
this.oldOffsetY=m.OFFSET_Y;
m.OFFSET_Y=1;
},destroy:function(){
dojo.dnd.manager().OFFSET_Y=this.oldOffsetY;
this.inherited(arguments);
}});
var _712=dojo.dnd.manager().makeAvatar;
dojo.dnd.manager().makeAvatar=function(){
var src=this.source;
if(src.viewIndex!==undefined&&!dojo.hasClass(dojo.body(),"dijit_a11y")){
return new dojox.grid._GridAvatar(this);
}
return _712.call(dojo.dnd.manager());
};
})();
}
if(!dojo._hasResource["dojox.grid._RowSelector"]){
dojo._hasResource["dojox.grid._RowSelector"]=true;
dojo.provide("dojox.grid._RowSelector");
dojo.declare("dojox.grid._RowSelector",dojox.grid._View,{defaultWidth:"2em",noscroll:true,padBorderWidth:2,buildRendering:function(){
this.inherited("buildRendering",arguments);
this.scrollboxNode.style.overflow="hidden";
this.headerNode.style.visibility="hidden";
},getWidth:function(){
return this.viewWidth||this.defaultWidth;
},buildRowContent:function(_713,_714){
var w=this.contentWidth||0;
_714.innerHTML="<table class=\"dojoxGridRowbarTable\" style=\"width:"+w+"px;height:1px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" role=\"presentation\"><tr><td class=\"dojoxGridRowbarInner\" tabindex=\"-1\">&nbsp;</td></tr></table>";
},renderHeader:function(){
},updateRow:function(){
},resize:function(){
this.adaptHeight();
},adaptWidth:function(){
if(!("contentWidth" in this)&&this.contentNode){
this.contentWidth=this.contentNode.offsetWidth-this.padBorderWidth;
}
},doStyleRowNode:function(_715,_716){
var n=["dojoxGridRowbar dojoxGridNonNormalizedCell"];
if(this.grid.rows.isOver(_715)){
n.push("dojoxGridRowbarOver");
}
if(this.grid.selection.isSelected(_715)){
n.push("dojoxGridRowbarSelected");
}
_716.className=n.join(" ");
},domouseover:function(e){
this.grid.onMouseOverRow(e);
},domouseout:function(e){
if(!this.isIntraRowEvent(e)){
this.grid.onMouseOutRow(e);
}
}});
}
if(!dojo._hasResource["dojox.grid._Layout"]){
dojo._hasResource["dojox.grid._Layout"]=true;
dojo.provide("dojox.grid._Layout");
dojo.declare("dojox.grid._Layout",null,{constructor:function(_717){
this.grid=_717;
},cells:[],structure:null,defaultWidth:"6em",moveColumn:function(_718,_719,_71a,_71b,_71c){
var _71d=this.structure[_718].cells[0];
var _71e=this.structure[_719].cells[0];
var cell=null;
var _71f=0;
var _720=0;
for(var i=0,c;c=_71d[i];i++){
if(c.index==_71a){
_71f=i;
break;
}
}
cell=_71d.splice(_71f,1)[0];
cell.view=this.grid.views.views[_719];
for(i=0,c=null;c=_71e[i];i++){
if(c.index==_71b){
_720=i;
break;
}
}
if(!_71c){
_720+=1;
}
_71e.splice(_720,0,cell);
var _721=this.grid.getCell(this.grid.getSortIndex());
if(_721){
_721._currentlySorted=this.grid.getSortAsc();
}
this.cells=[];
_71a=0;
var v;
for(i=0;v=this.structure[i];i++){
for(var j=0,cs;cs=v.cells[j];j++){
for(var k=0;c=cs[k];k++){
c.index=_71a;
this.cells.push(c);
if("_currentlySorted" in c){
var si=_71a+1;
si*=c._currentlySorted?1:-1;
this.grid.sortInfo=si;
delete c._currentlySorted;
}
_71a++;
}
}
}
dojo.forEach(this.cells,function(c){
var _722=c.markup[2].split(" ");
var _723=parseInt(_722[1].substring(5));
if(_723!=c.index){
_722[1]="idx=\""+c.index+"\"";
c.markup[2]=_722.join(" ");
}
});
this.grid.setupHeaderMenu();
},setColumnVisibility:function(_724,_725){
var cell=this.cells[_724];
if(cell.hidden==_725){
cell.hidden=!_725;
var v=cell.view,w=v.viewWidth;
if(w&&w!="auto"){
v._togglingColumn=dojo.marginBox(cell.getHeaderNode()).w||0;
}
v.update();
return true;
}else{
return false;
}
},addCellDef:function(_726,_727,_728){
var self=this;
var _729=function(_72a){
var w=0;
if(_72a.colSpan>1){
w=0;
}else{
w=_72a.width||self._defaultCellProps.width||self.defaultWidth;
if(!isNaN(w)){
w=w+"em";
}
}
return w;
};
var _72b={grid:this.grid,subrow:_726,layoutIndex:_727,index:this.cells.length};
if(_728&&_728 instanceof dojox.grid.cells._Base){
var _72c=dojo.clone(_728);
_72b.unitWidth=_729(_72c._props);
_72c=dojo.mixin(_72c,this._defaultCellProps,_728._props,_72b);
return _72c;
}
var _72d=_728.type||_728.cellType||this._defaultCellProps.type||this._defaultCellProps.cellType||dojox.grid.cells.Cell;
_72b.unitWidth=_729(_728);
return new _72d(dojo.mixin({},this._defaultCellProps,_728,_72b));
},addRowDef:function(_72e,_72f){
var _730=[];
var _731=0,_732=0,_733=true;
for(var i=0,def,cell;(def=_72f[i]);i++){
cell=this.addCellDef(_72e,i,def);
_730.push(cell);
this.cells.push(cell);
if(_733&&cell.relWidth){
_731+=cell.relWidth;
}else{
if(cell.width){
var w=cell.width;
if(typeof w=="string"&&w.slice(-1)=="%"){
_732+=window.parseInt(w,10);
}else{
if(w=="auto"){
_733=false;
}
}
}
}
}
if(_731&&_733){
dojo.forEach(_730,function(cell){
if(cell.relWidth){
cell.width=cell.unitWidth=((cell.relWidth/_731)*(100-_732))+"%";
}
});
}
return _730;
},addRowsDef:function(_734){
var _735=[];
if(dojo.isArray(_734)){
if(dojo.isArray(_734[0])){
for(var i=0,row;_734&&(row=_734[i]);i++){
_735.push(this.addRowDef(i,row));
}
}else{
_735.push(this.addRowDef(0,_734));
}
}
return _735;
},addViewDef:function(_736){
this._defaultCellProps=_736.defaultCell||{};
if(_736.width&&_736.width=="auto"){
delete _736.width;
}
return dojo.mixin({},_736,{cells:this.addRowsDef(_736.rows||_736.cells)});
},setStructure:function(_737){
this.fieldIndex=0;
this.cells=[];
var s=this.structure=[];
if(this.grid.rowSelector){
var sel={type:dojox._scopeName+".grid._RowSelector"};
if(dojo.isString(this.grid.rowSelector)){
var _738=this.grid.rowSelector;
if(_738=="false"){
sel=null;
}else{
if(_738!="true"){
sel["width"]=_738;
}
}
}else{
if(!this.grid.rowSelector){
sel=null;
}
}
if(sel){
s.push(this.addViewDef(sel));
}
}
var _739=function(def){
return ("name" in def||"field" in def||"get" in def);
};
var _73a=function(def){
if(dojo.isArray(def)){
if(dojo.isArray(def[0])||_739(def[0])){
return true;
}
}
return false;
};
var _73b=function(def){
return (def!==null&&dojo.isObject(def)&&("cells" in def||"rows" in def||("type" in def&&!_739(def))));
};
if(dojo.isArray(_737)){
var _73c=false;
for(var i=0,st;(st=_737[i]);i++){
if(_73b(st)){
_73c=true;
break;
}
}
if(!_73c){
s.push(this.addViewDef({cells:_737}));
}else{
for(i=0;(st=_737[i]);i++){
if(_73a(st)){
s.push(this.addViewDef({cells:st}));
}else{
if(_73b(st)){
s.push(this.addViewDef(st));
}
}
}
}
}else{
if(_73b(_737)){
s.push(this.addViewDef(_737));
}
}
this.cellCount=this.cells.length;
this.grid.setupHeaderMenu();
}});
}
if(!dojo._hasResource["dojox.grid._ViewManager"]){
dojo._hasResource["dojox.grid._ViewManager"]=true;
dojo.provide("dojox.grid._ViewManager");
dojo.declare("dojox.grid._ViewManager",null,{constructor:function(_73d){
this.grid=_73d;
},defaultWidth:200,views:[],resize:function(){
this.onEach("resize");
},render:function(){
this.onEach("render");
},addView:function(_73e){
_73e.idx=this.views.length;
this.views.push(_73e);
},destroyViews:function(){
for(var i=0,v;v=this.views[i];i++){
v.destroy();
}
this.views=[];
},getContentNodes:function(){
var _73f=[];
for(var i=0,v;v=this.views[i];i++){
_73f.push(v.contentNode);
}
return _73f;
},forEach:function(_740){
for(var i=0,v;v=this.views[i];i++){
_740(v,i);
}
},onEach:function(_741,_742){
_742=_742||[];
for(var i=0,v;v=this.views[i];i++){
if(_741 in v){
v[_741].apply(v,_742);
}
}
},normalizeHeaderNodeHeight:function(){
var _743=[];
for(var i=0,v;(v=this.views[i]);i++){
if(v.headerContentNode.firstChild){
_743.push(v.headerContentNode);
}
}
this.normalizeRowNodeHeights(_743);
},normalizeRowNodeHeights:function(_744){
var h=0;
var _745=[];
if(this.grid.rowHeight){
h=this.grid.rowHeight;
}else{
if(_744.length<=1){
return;
}
for(var i=0,n;(n=_744[i]);i++){
if(!dojo.hasClass(n,"dojoxGridNonNormalizedCell")){
_745[i]=n.firstChild.offsetHeight;
h=Math.max(h,_745[i]);
}
}
h=(h>=0?h:0);
if(dojo.isMoz&&h){
h++;
}
}
for(i=0;(n=_744[i]);i++){
if(_745[i]!=h){
n.firstChild.style.height=h+"px";
}
}
},resetHeaderNodeHeight:function(){
for(var i=0,v,n;(v=this.views[i]);i++){
n=v.headerContentNode.firstChild;
if(n){
n.style.height="";
}
}
},renormalizeRow:function(_746){
var _747=[];
for(var i=0,v,n;(v=this.views[i])&&(n=v.getRowNode(_746));i++){
n.firstChild.style.height="";
_747.push(n);
}
this.normalizeRowNodeHeights(_747);
},getViewWidth:function(_748){
return this.views[_748].getWidth()||this.defaultWidth;
},measureHeader:function(){
this.resetHeaderNodeHeight();
this.forEach(function(_749){
_749.headerContentNode.style.height="";
});
var h=0;
this.forEach(function(_74a){
h=Math.max(_74a.headerNode.offsetHeight,h);
});
return h;
},measureContent:function(){
var h=0;
this.forEach(function(_74b){
h=Math.max(_74b.domNode.offsetHeight,h);
});
return h;
},findClient:function(_74c){
var c=this.grid.elasticView||-1;
if(c<0){
for(var i=1,v;(v=this.views[i]);i++){
if(v.viewWidth){
for(i=1;(v=this.views[i]);i++){
if(!v.viewWidth){
c=i;
break;
}
}
break;
}
}
}
if(c<0){
c=Math.floor(this.views.length/2);
}
return c;
},arrange:function(l,w){
var i,v,vw,len=this.views.length;
var c=(w<=0?len:this.findClient());
var _74d=function(v,l){
var ds=v.domNode.style;
var hs=v.headerNode.style;
if(!dojo._isBodyLtr()){
ds.right=l+"px";
if(dojo.isMoz){
hs.right=l+v.getScrollbarWidth()+"px";
hs.width=parseInt(hs.width,10)-v.getScrollbarWidth()+"px";
}else{
hs.right=l+"px";
}
}else{
ds.left=l+"px";
hs.left=l+"px";
}
ds.top=0+"px";
hs.top=0;
};
for(i=0;(v=this.views[i])&&(i<c);i++){
vw=this.getViewWidth(i);
v.setSize(vw,0);
_74d(v,l);
if(v.headerContentNode&&v.headerContentNode.firstChild){
vw=v.getColumnsWidth()+v.getScrollbarWidth();
}else{
vw=v.domNode.offsetWidth;
}
l+=vw;
}
i++;
var r=w;
for(var j=len-1;(v=this.views[j])&&(i<=j);j--){
vw=this.getViewWidth(j);
v.setSize(vw,0);
vw=v.domNode.offsetWidth;
r-=vw;
_74d(v,r);
}
if(c<len){
v=this.views[c];
vw=Math.max(1,r-l);
v.setSize(vw+"px",0);
_74d(v,l);
}
return l;
},renderRow:function(_74e,_74f,_750){
var _751=[];
for(var i=0,v,n,_752;(v=this.views[i])&&(n=_74f[i]);i++){
_752=v.renderRow(_74e);
n.appendChild(_752);
_751.push(_752);
}
if(!_750){
this.normalizeRowNodeHeights(_751);
}
},rowRemoved:function(_753){
this.onEach("rowRemoved",[_753]);
},updateRow:function(_754,_755){
for(var i=0,v;v=this.views[i];i++){
v.updateRow(_754);
}
if(!_755){
this.renormalizeRow(_754);
}
},updateRowStyles:function(_756){
this.onEach("updateRowStyles",[_756]);
},setScrollTop:function(_757){
var top=_757;
for(var i=0,v;v=this.views[i];i++){
top=v.setScrollTop(_757);
if(dojo.isIE&&v.headerNode&&v.scrollboxNode){
v.headerNode.scrollLeft=v.scrollboxNode.scrollLeft;
}
}
return top;
},getFirstScrollingView:function(){
for(var i=0,v;(v=this.views[i]);i++){
if(v.hasHScrollbar()||v.hasVScrollbar()){
return v;
}
}
return null;
}});
}
if(!dojo._hasResource["dojox.grid._RowManager"]){
dojo._hasResource["dojox.grid._RowManager"]=true;
dojo.provide("dojox.grid._RowManager");
(function(){
var _758=function(_759,_75a){
if(_759.style.cssText==undefined){
_759.setAttribute("style",_75a);
}else{
_759.style.cssText=_75a;
}
};
dojo.declare("dojox.grid._RowManager",null,{constructor:function(_75b){
this.grid=_75b;
},linesToEms:2,overRow:-2,prepareStylingRow:function(_75c,_75d){
return {index:_75c,node:_75d,odd:Boolean(_75c&1),selected:!!this.grid.selection.isSelected(_75c),over:this.isOver(_75c),customStyles:"",customClasses:"dojoxGridRow"};
},styleRowNode:function(_75e,_75f){
var row=this.prepareStylingRow(_75e,_75f);
this.grid.onStyleRow(row);
this.applyStyles(row);
},applyStyles:function(_760){
var i=_760;
i.node.className=i.customClasses;
var h=i.node.style.height;
_758(i.node,i.customStyles+";"+(i.node._style||""));
i.node.style.height=h;
},updateStyles:function(_761){
this.grid.updateRowStyles(_761);
},setOverRow:function(_762){
var last=this.overRow;
this.overRow=_762;
if((last!=this.overRow)&&(dojo.isString(last)||last>=0)){
this.updateStyles(last);
}
this.updateStyles(this.overRow);
},isOver:function(_763){
return (this.overRow==_763&&!dojo.hasClass(this.grid.domNode,"dojoxGridColumnResizing"));
}});
})();
}
if(!dojo._hasResource["dojox.grid._FocusManager"]){
dojo._hasResource["dojox.grid._FocusManager"]=true;
dojo.provide("dojox.grid._FocusManager");
dojo.declare("dojox.grid._FocusManager",null,{constructor:function(_764){
this.grid=_764;
this.cell=null;
this.rowIndex=-1;
this._connects=[];
this._headerConnects=[];
this.headerMenu=this.grid.headerMenu;
this._connects.push(dojo.connect(this.grid.domNode,"onfocus",this,"doFocus"));
this._connects.push(dojo.connect(this.grid.domNode,"onblur",this,"doBlur"));
this._connects.push(dojo.connect(this.grid.domNode,"oncontextmenu",this,"doContextMenu"));
this._connects.push(dojo.connect(this.grid.lastFocusNode,"onfocus",this,"doLastNodeFocus"));
this._connects.push(dojo.connect(this.grid.lastFocusNode,"onblur",this,"doLastNodeBlur"));
this._connects.push(dojo.connect(this.grid,"_onFetchComplete",this,"_delayedCellFocus"));
this._connects.push(dojo.connect(this.grid,"postrender",this,"_delayedHeaderFocus"));
},destroy:function(){
dojo.forEach(this._connects,dojo.disconnect);
dojo.forEach(this._headerConnects,dojo.disconnect);
delete this.grid;
delete this.cell;
},_colHeadNode:null,_colHeadFocusIdx:null,_contextMenuBindNode:null,tabbingOut:false,focusClass:"dojoxGridCellFocus",focusView:null,initFocusView:function(){
this.focusView=this.grid.views.getFirstScrollingView()||this.focusView||this.grid.views.views[0];
this._initColumnHeaders();
},isFocusCell:function(_765,_766){
return (this.cell==_765)&&(this.rowIndex==_766);
},isLastFocusCell:function(){
if(this.cell){
return (this.rowIndex==this.grid.rowCount-1)&&(this.cell.index==this.grid.layout.cellCount-1);
}
return false;
},isFirstFocusCell:function(){
if(this.cell){
return (this.rowIndex===0)&&(this.cell.index===0);
}
return false;
},isNoFocusCell:function(){
return (this.rowIndex<0)||!this.cell;
},isNavHeader:function(){
return (!!this._colHeadNode);
},getHeaderIndex:function(){
if(this._colHeadNode){
return dojo.indexOf(this._findHeaderCells(),this._colHeadNode);
}else{
return -1;
}
},_focusifyCellNode:function(_767){
var n=this.cell&&this.cell.getNode(this.rowIndex);
if(n){
dojo.toggleClass(n,this.focusClass,_767);
if(_767){
var sl=this.scrollIntoView();
try{
if(!this.grid.edit.isEditing()){
dojox.grid.util.fire(n,"focus");
if(sl){
this.cell.view.scrollboxNode.scrollLeft=sl;
}
}
}
catch(e){
}
}
}
},_delayedCellFocus:function(){
if(this.isNavHeader()||!this.grid._focused){
return;
}
var n=this.cell&&this.cell.getNode(this.rowIndex);
if(n){
try{
if(!this.grid.edit.isEditing()){
dojo.toggleClass(n,this.focusClass,true);
if(this._colHeadNode){
this.blurHeader();
}
dojox.grid.util.fire(n,"focus");
}
}
catch(e){
}
}
},_delayedHeaderFocus:function(){
if(this.isNavHeader()){
this.focusHeader();
dijit.focus(this.grid.domNode);
}
},_initColumnHeaders:function(){
dojo.forEach(this._headerConnects,dojo.disconnect);
this._headerConnects=[];
var _768=this._findHeaderCells();
for(var i=0;i<_768.length;i++){
this._headerConnects.push(dojo.connect(_768[i],"onfocus",this,"doColHeaderFocus"));
this._headerConnects.push(dojo.connect(_768[i],"onblur",this,"doColHeaderBlur"));
}
},_findHeaderCells:function(){
var _769=dojo.query("th",this.grid.viewsHeaderNode);
var _76a=[];
for(var i=0;i<_769.length;i++){
var _76b=_769[i];
var _76c=dojo.hasAttr(_76b,"tabIndex");
var _76d=dojo.attr(_76b,"tabIndex");
if(_76c&&_76d<0){
_76a.push(_76b);
}
}
return _76a;
},_setActiveColHeader:function(_76e,_76f,_770){
this.grid.domNode.setAttribute("aria-activedescendant",_76e.id);
if(_770!=null&&_770>=0&&_770!=_76f){
dojo.toggleClass(this._findHeaderCells()[_770],this.focusClass,false);
}
dojo.toggleClass(_76e,this.focusClass,true);
this._colHeadNode=_76e;
this._colHeadFocusIdx=_76f;
this._scrollHeader(this._colHeadFocusIdx);
},scrollIntoView:function(){
var info=(this.cell?this._scrollInfo(this.cell):null);
if(!info||!info.s){
return null;
}
var rt=this.grid.scroller.findScrollTop(this.rowIndex);
if(info.n&&info.sr){
if(info.n.offsetLeft+info.n.offsetWidth>info.sr.l+info.sr.w){
info.s.scrollLeft=info.n.offsetLeft+info.n.offsetWidth-info.sr.w;
}else{
if(info.n.offsetLeft<info.sr.l){
info.s.scrollLeft=info.n.offsetLeft;
}
}
}
if(info.r&&info.sr){
if(rt+info.r.offsetHeight>info.sr.t+info.sr.h){
this.grid.setScrollTop(rt+info.r.offsetHeight-info.sr.h);
}else{
if(rt<info.sr.t){
this.grid.setScrollTop(rt);
}
}
}
return info.s.scrollLeft;
},_scrollInfo:function(cell,_771){
if(cell){
var cl=cell,sbn=cl.view.scrollboxNode,sbnr={w:sbn.clientWidth,l:sbn.scrollLeft,t:sbn.scrollTop,h:sbn.clientHeight},rn=cl.view.getRowNode(this.rowIndex);
return {c:cl,s:sbn,sr:sbnr,n:(_771?_771:cell.getNode(this.rowIndex)),r:rn};
}
return null;
},_scrollHeader:function(_772){
var info=null;
if(this._colHeadNode){
var cell=this.grid.getCell(_772);
if(!cell){
return;
}
info=this._scrollInfo(cell,cell.getNode(0));
}
if(info&&info.s&&info.sr&&info.n){
var _773=info.sr.l+info.sr.w;
if(info.n.offsetLeft+info.n.offsetWidth>_773){
info.s.scrollLeft=info.n.offsetLeft+info.n.offsetWidth-info.sr.w;
}else{
if(info.n.offsetLeft<info.sr.l){
info.s.scrollLeft=info.n.offsetLeft;
}else{
if(dojo.isIE<=7&&cell&&cell.view.headerNode){
cell.view.headerNode.scrollLeft=info.s.scrollLeft;
}
}
}
}
},_isHeaderHidden:function(){
var _774=this.focusView;
if(!_774){
for(var i=0,_775;(_775=this.grid.views.views[i]);i++){
if(_775.headerNode){
_774=_775;
break;
}
}
}
return (_774&&dojo.getComputedStyle(_774.headerNode).display=="none");
},colSizeAdjust:function(e,_776,_777){
var _778=this._findHeaderCells();
var view=this.focusView;
if(!view){
for(var i=0,_779;(_779=this.grid.views.views[i]);i++){
if(_779.header.tableMap.map){
view=_779;
break;
}
}
}
var _77a=_778[_776];
if(!view||(_776==_778.length-1&&_776===0)){
return;
}
view.content.baseDecorateEvent(e);
e.cellNode=_77a;
e.cellIndex=view.content.getCellNodeIndex(e.cellNode);
e.cell=(e.cellIndex>=0?this.grid.getCell(e.cellIndex):null);
if(view.header.canResize(e)){
var _77b={l:_777};
var drag=view.header.colResizeSetup(e,false);
view.header.doResizeColumn(drag,null,_77b);
view.update();
}
},styleRow:function(_77c){
return;
},setFocusIndex:function(_77d,_77e){
this.setFocusCell(this.grid.getCell(_77e),_77d);
},setFocusCell:function(_77f,_780){
if(_77f&&!this.isFocusCell(_77f,_780)){
this.tabbingOut=false;
if(this._colHeadNode){
this.blurHeader();
}
this._colHeadNode=this._colHeadFocusIdx=null;
this.focusView=_77f.view;
this.focusGridView();
this._focusifyCellNode(false);
this.cell=_77f;
this.rowIndex=_780;
this._focusifyCellNode(true);
}
if(dojo.isOpera){
setTimeout(dojo.hitch(this.grid,"onCellFocus",this.cell,this.rowIndex),1);
}else{
this.grid.onCellFocus(this.cell,this.rowIndex);
}
},next:function(){
if(this.cell){
var row=this.rowIndex,col=this.cell.index+1,cc=this.grid.layout.cellCount-1,rc=this.grid.rowCount-1;
if(col>cc){
col=0;
row++;
}
if(row>rc){
col=cc;
row=rc;
}
if(this.grid.edit.isEditing()){
var _781=this.grid.getCell(col);
if(!this.isLastFocusCell()&&(!_781.editable||this.grid.canEdit&&!this.grid.canEdit(_781,row))){
this.cell=_781;
this.rowIndex=row;
this.next();
return;
}
}
this.setFocusIndex(row,col);
}
},previous:function(){
if(this.cell){
var row=(this.rowIndex||0),col=(this.cell.index||0)-1;
if(col<0){
col=this.grid.layout.cellCount-1;
row--;
}
if(row<0){
row=0;
col=0;
}
if(this.grid.edit.isEditing()){
var _782=this.grid.getCell(col);
if(!this.isFirstFocusCell()&&!_782.editable){
this.cell=_782;
this.rowIndex=row;
this.previous();
return;
}
}
this.setFocusIndex(row,col);
}
},move:function(_783,_784){
var _785=_784<0?-1:1;
if(this.isNavHeader()){
var _786=this._findHeaderCells();
var _787=currentIdx=dojo.indexOf(_786,this._colHeadNode);
currentIdx+=_784;
while(currentIdx>=0&&currentIdx<_786.length&&_786[currentIdx].style.display=="none"){
currentIdx+=_785;
}
if((currentIdx>=0)&&(currentIdx<_786.length)){
this._setActiveColHeader(_786[currentIdx],currentIdx,_787);
}
}else{
if(this.cell){
var sc=this.grid.scroller,r=this.rowIndex,rc=this.grid.rowCount-1,row=Math.min(rc,Math.max(0,r+_783));
if(_783){
if(_783>0){
if(row>sc.getLastPageRow(sc.page)){
this.grid.setScrollTop(this.grid.scrollTop+sc.findScrollTop(row)-sc.findScrollTop(r));
}
}else{
if(_783<0){
if(row<=sc.getPageRow(sc.page)){
this.grid.setScrollTop(this.grid.scrollTop-sc.findScrollTop(r)-sc.findScrollTop(row));
}
}
}
}
var cc=this.grid.layout.cellCount-1,i=this.cell.index,col=Math.min(cc,Math.max(0,i+_784));
var cell=this.grid.getCell(col);
while(col>=0&&col<cc&&cell&&cell.hidden===true){
col+=_785;
cell=this.grid.getCell(col);
}
if(!cell||cell.hidden===true){
col=i;
}
var n=cell.getNode(row);
if(!n&&_783){
if((row+_783)>=0&&(row+_783)<=rc){
this.move(_783>0?++_783:--_783,_784);
}
return;
}else{
if((!n||dojo.style(n,"display")==="none")&&_784){
if((col+_783)>=0&&(col+_783)<=cc){
this.move(_783,_784>0?++_784:--_784);
}
return;
}
}
this.setFocusIndex(row,col);
}
}
},previousKey:function(e){
if(this.grid.edit.isEditing()){
dojo.stopEvent(e);
this.previous();
}else{
if(!this.isNavHeader()&&!this._isHeaderHidden()){
this.grid.domNode.focus();
dojo.stopEvent(e);
}else{
this.tabOut(this.grid.domNode);
if(this._colHeadFocusIdx!=null){
dojo.toggleClass(this._findHeaderCells()[this._colHeadFocusIdx],this.focusClass,false);
this._colHeadFocusIdx=null;
}
this._focusifyCellNode(false);
}
}
},nextKey:function(e){
var _788=(this.grid.rowCount===0);
if(e.target===this.grid.domNode&&this._colHeadFocusIdx==null){
this.focusHeader();
dojo.stopEvent(e);
}else{
if(this.isNavHeader()){
this.blurHeader();
if(!this.findAndFocusGridCell()){
this.tabOut(this.grid.lastFocusNode);
}
this._colHeadNode=this._colHeadFocusIdx=null;
}else{
if(this.grid.edit.isEditing()){
dojo.stopEvent(e);
this.next();
}else{
this.tabOut(this.grid.lastFocusNode);
}
}
}
},tabOut:function(_789){
this.tabbingOut=true;
_789.focus();
},focusGridView:function(){
dojox.grid.util.fire(this.focusView,"focus");
},focusGrid:function(_78a){
this.focusGridView();
this._focusifyCellNode(true);
},findAndFocusGridCell:function(){
var _78b=true;
var _78c=(this.grid.rowCount===0);
if(this.isNoFocusCell()&&!_78c){
var _78d=0;
var cell=this.grid.getCell(_78d);
if(cell.hidden){
_78d=this.isNavHeader()?this._colHeadFocusIdx:0;
}
this.setFocusIndex(0,_78d);
}else{
if(this.cell&&!_78c){
if(this.focusView&&!this.focusView.rowNodes[this.rowIndex]){
this.grid.scrollToRow(this.rowIndex);
}
this.focusGrid();
}else{
_78b=false;
}
}
this._colHeadNode=this._colHeadFocusIdx=null;
return _78b;
},focusHeader:function(){
var _78e=this._findHeaderCells();
var _78f=this._colHeadFocusIdx;
if(this._isHeaderHidden()){
this.findAndFocusGridCell();
}else{
if(!this._colHeadFocusIdx){
if(this.isNoFocusCell()){
this._colHeadFocusIdx=0;
}else{
this._colHeadFocusIdx=this.cell.index;
}
}
}
this._colHeadNode=_78e[this._colHeadFocusIdx];
while(this._colHeadNode&&this._colHeadFocusIdx>=0&&this._colHeadFocusIdx<_78e.length&&this._colHeadNode.style.display=="none"){
this._colHeadFocusIdx++;
this._colHeadNode=_78e[this._colHeadFocusIdx];
}
if(this._colHeadNode&&this._colHeadNode.style.display!="none"){
this.focusView=this.grid.getCell(this._colHeadFocusIdx).view;
if(this.headerMenu&&this._contextMenuBindNode!=this.grid.domNode){
this.headerMenu.unBindDomNode(this.grid.viewsHeaderNode);
this.headerMenu.bindDomNode(this.grid.domNode);
this._contextMenuBindNode=this.grid.domNode;
}
this._setActiveColHeader(this._colHeadNode,this._colHeadFocusIdx,_78f);
this._scrollHeader(this._colHeadFocusIdx);
this._focusifyCellNode(false);
}else{
this.findAndFocusGridCell();
}
},blurHeader:function(){
dojo.removeClass(this._colHeadNode,this.focusClass);
dojo.removeAttr(this.grid.domNode,"aria-activedescendant");
if(this.headerMenu&&this._contextMenuBindNode==this.grid.domNode){
var _790=this.grid.viewsHeaderNode;
this.headerMenu.unBindDomNode(this.grid.domNode);
this.headerMenu.bindDomNode(_790);
this._contextMenuBindNode=_790;
}
},doFocus:function(e){
if(e&&e.target!=e.currentTarget){
dojo.stopEvent(e);
return;
}
if(!this.tabbingOut){
this.focusHeader();
}
this.tabbingOut=false;
dojo.stopEvent(e);
},doBlur:function(e){
dojo.stopEvent(e);
},doContextMenu:function(e){
if(!this.headerMenu){
dojo.stopEvent(e);
}
},doLastNodeFocus:function(e){
if(this.tabbingOut){
this._focusifyCellNode(false);
}else{
if(this.grid.rowCount>0){
if(this.isNoFocusCell()){
this.setFocusIndex(0,0);
}
this._focusifyCellNode(true);
}else{
this.focusHeader();
}
}
this.tabbingOut=false;
dojo.stopEvent(e);
},doLastNodeBlur:function(e){
dojo.stopEvent(e);
},doColHeaderFocus:function(e){
this._setActiveColHeader(e.target,dojo.attr(e.target,"idx"),this._colHeadFocusIdx);
this._scrollHeader(this.getHeaderIndex());
dojo.stopEvent(e);
},doColHeaderBlur:function(e){
dojo.toggleClass(e.target,this.focusClass,false);
}});
}
if(!dojo._hasResource["dojox.grid._EditManager"]){
dojo._hasResource["dojox.grid._EditManager"]=true;
dojo.provide("dojox.grid._EditManager");
dojo.declare("dojox.grid._EditManager",null,{constructor:function(_791){
this.grid=_791;
if(dojo.isIE){
this.connections=[dojo.connect(document.body,"onfocus",dojo.hitch(this,"_boomerangFocus"))];
}else{
this.connections=[dojo.connect(this.grid,"onBlur",this,"apply")];
}
},info:{},destroy:function(){
dojo.forEach(this.connections,dojo.disconnect);
},cellFocus:function(_792,_793){
if(this.grid.singleClickEdit||this.isEditRow(_793)){
this.setEditCell(_792,_793);
}else{
this.apply();
}
if(this.isEditing()||(_792&&_792.editable&&_792.alwaysEditing)){
this._focusEditor(_792,_793);
}
},rowClick:function(e){
if(this.isEditing()&&!this.isEditRow(e.rowIndex)){
this.apply();
}
},styleRow:function(_794){
if(_794.index==this.info.rowIndex){
_794.customClasses+=" dojoxGridRowEditing";
}
},dispatchEvent:function(e){
var c=e.cell,ed=(c&&c["editable"])?c:0;
return ed&&ed.dispatchEvent(e.dispatch,e);
},isEditing:function(){
return this.info.rowIndex!==undefined;
},isEditCell:function(_795,_796){
return (this.info.rowIndex===_795)&&(this.info.cell.index==_796);
},isEditRow:function(_797){
return this.info.rowIndex===_797;
},setEditCell:function(_798,_799){
if(!this.isEditCell(_799,_798.index)&&this.grid.canEdit&&this.grid.canEdit(_798,_799)){
this.start(_798,_799,this.isEditRow(_799)||_798.editable);
}
},_focusEditor:function(_79a,_79b){
dojox.grid.util.fire(_79a,"focus",[_79b]);
},focusEditor:function(){
if(this.isEditing()){
this._focusEditor(this.info.cell,this.info.rowIndex);
}
},_boomerangWindow:500,_shouldCatchBoomerang:function(){
return this._catchBoomerang>new Date().getTime();
},_boomerangFocus:function(){
if(this._shouldCatchBoomerang()){
this.grid.focus.focusGrid();
this.focusEditor();
this._catchBoomerang=0;
}
},_doCatchBoomerang:function(){
if(dojo.isIE){
this._catchBoomerang=new Date().getTime()+this._boomerangWindow;
}
},start:function(_79c,_79d,_79e){
if(!this._isValidInput()){
return;
}
this.grid.beginUpdate();
try{
this.editorApply();
}
catch(e){
console.warn("_base.start:",e);
}
if(this.isEditing()&&!this.isEditRow(_79d)){
this.applyRowEdit();
this.grid.updateRow(_79d);
}
if(_79e){
this.info={cell:_79c,rowIndex:_79d};
this.grid.doStartEdit(_79c,_79d);
this.grid.updateRow(_79d);
}else{
this.info={};
}
this.grid.endUpdate();
this.grid.focus.focusGrid();
this._focusEditor(_79c,_79d);
this._doCatchBoomerang();
},_editorDo:function(_79f){
var c=this.info.cell;
if(c&&c.editable){
c[_79f](this.info.rowIndex);
}
},editorApply:function(){
this._editorDo("apply");
},editorCancel:function(){
this._editorDo("cancel");
},applyCellEdit:function(_7a0,_7a1,_7a2){
if(this.grid.canEdit(_7a1,_7a2)){
this.grid.doApplyCellEdit(_7a0,_7a2,_7a1.field);
}
},applyRowEdit:function(){
this.grid.doApplyEdit(this.info.rowIndex,this.info.cell.field);
},apply:function(){
if(this.isEditing()&&this._isValidInput()){
this.grid.beginUpdate();
this.editorApply();
this.applyRowEdit();
this.info={};
this.grid.endUpdate();
this.grid.focus.focusGrid();
this._doCatchBoomerang();
}
},cancel:function(){
if(this.isEditing()){
this.grid.beginUpdate();
this.editorCancel();
this.info={};
this.grid.endUpdate();
this.grid.focus.focusGrid();
this._doCatchBoomerang();
}
},save:function(_7a3,_7a4){
var c=this.info.cell;
if(this.isEditRow(_7a3)&&(!_7a4||c.view==_7a4)&&c.editable){
c.save(c,this.info.rowIndex);
}
},restore:function(_7a5,_7a6){
var c=this.info.cell;
if(this.isEditRow(_7a6)&&c.view==_7a5&&c.editable){
c.restore(c,this.info.rowIndex);
}
},_isValidInput:function(){
var w=(this.info.cell||{}).widget;
if(!w||!w.isValid){
return true;
}
w.focused=true;
return w.isValid(true);
}});
}
if(!dojo._hasResource["dojox.grid.Selection"]){
dojo._hasResource["dojox.grid.Selection"]=true;
dojo.provide("dojox.grid.Selection");
dojo.declare("dojox.grid.Selection",null,{constructor:function(_7a7){
this.grid=_7a7;
this.selected=[];
this.setMode(_7a7.selectionMode);
},mode:"extended",selected:null,updating:0,selectedIndex:-1,setMode:function(mode){
if(this.selected.length){
this.deselectAll();
}
if(mode!="extended"&&mode!="multiple"&&mode!="single"&&mode!="none"){
this.mode="extended";
}else{
this.mode=mode;
}
},onCanSelect:function(_7a8){
return this.grid.onCanSelect(_7a8);
},onCanDeselect:function(_7a9){
return this.grid.onCanDeselect(_7a9);
},onSelected:function(_7aa){
},onDeselected:function(_7ab){
},onChanging:function(){
},onChanged:function(){
},isSelected:function(_7ac){
if(this.mode=="none"){
return false;
}
return this.selected[_7ac];
},getFirstSelected:function(){
if(!this.selected.length||this.mode=="none"){
return -1;
}
for(var i=0,l=this.selected.length;i<l;i++){
if(this.selected[i]){
return i;
}
}
return -1;
},getNextSelected:function(_7ad){
if(this.mode=="none"){
return -1;
}
for(var i=_7ad+1,l=this.selected.length;i<l;i++){
if(this.selected[i]){
return i;
}
}
return -1;
},getSelected:function(){
var _7ae=[];
for(var i=0,l=this.selected.length;i<l;i++){
if(this.selected[i]){
_7ae.push(i);
}
}
return _7ae;
},getSelectedCount:function(){
var c=0;
for(var i=0;i<this.selected.length;i++){
if(this.selected[i]){
c++;
}
}
return c;
},_beginUpdate:function(){
if(this.updating===0){
this.onChanging();
}
this.updating++;
},_endUpdate:function(){
this.updating--;
if(this.updating===0){
this.onChanged();
}
},select:function(_7af){
if(this.mode=="none"){
return;
}
if(this.mode!="multiple"){
this.deselectAll(_7af);
this.addToSelection(_7af);
}else{
this.toggleSelect(_7af);
}
},addToSelection:function(_7b0){
if(this.mode=="none"){
return;
}
if(dojo.isArray(_7b0)){
dojo.forEach(_7b0,this.addToSelection,this);
return;
}
_7b0=Number(_7b0);
if(this.selected[_7b0]){
this.selectedIndex=_7b0;
}else{
if(this.onCanSelect(_7b0)!==false){
this.selectedIndex=_7b0;
var _7b1=this.grid.getRowNode(_7b0);
if(_7b1){
dojo.attr(_7b1,"aria-selected","true");
}
this._beginUpdate();
this.selected[_7b0]=true;
this.onSelected(_7b0);
this._endUpdate();
}
}
},deselect:function(_7b2){
if(this.mode=="none"){
return;
}
if(dojo.isArray(_7b2)){
dojo.forEach(_7b2,this.deselect,this);
return;
}
_7b2=Number(_7b2);
if(this.selectedIndex==_7b2){
this.selectedIndex=-1;
}
if(this.selected[_7b2]){
if(this.onCanDeselect(_7b2)===false){
return;
}
var _7b3=this.grid.getRowNode(_7b2);
if(_7b3){
dojo.attr(_7b3,"aria-selected","false");
}
this._beginUpdate();
delete this.selected[_7b2];
this.onDeselected(_7b2);
this._endUpdate();
}
},setSelected:function(_7b4,_7b5){
this[(_7b5?"addToSelection":"deselect")](_7b4);
},toggleSelect:function(_7b6){
if(dojo.isArray(_7b6)){
dojo.forEach(_7b6,this.toggleSelect,this);
return;
}
this.setSelected(_7b6,!this.selected[_7b6]);
},_range:function(_7b7,inTo,func){
var s=(_7b7>=0?_7b7:inTo),e=inTo;
if(s>e){
e=s;
s=inTo;
}
for(var i=s;i<=e;i++){
func(i);
}
},selectRange:function(_7b8,inTo){
this._range(_7b8,inTo,dojo.hitch(this,"addToSelection"));
},deselectRange:function(_7b9,inTo){
this._range(_7b9,inTo,dojo.hitch(this,"deselect"));
},insert:function(_7ba){
this.selected.splice(_7ba,0,false);
if(this.selectedIndex>=_7ba){
this.selectedIndex++;
}
},remove:function(_7bb){
this.selected.splice(_7bb,1);
if(this.selectedIndex>=_7bb){
this.selectedIndex--;
}
},deselectAll:function(_7bc){
for(var i in this.selected){
if((i!=_7bc)&&(this.selected[i]===true)){
this.deselect(i);
}
}
},clickSelect:function(_7bd,_7be,_7bf){
if(this.mode=="none"){
return;
}
this._beginUpdate();
if(this.mode!="extended"){
this.select(_7bd);
}else{
var _7c0=this.selectedIndex;
if(!_7be){
this.deselectAll(_7bd);
}
if(_7bf){
this.selectRange(_7c0,_7bd);
}else{
if(_7be){
this.toggleSelect(_7bd);
}else{
this.addToSelection(_7bd);
}
}
}
this._endUpdate();
},clickSelectEvent:function(e){
this.clickSelect(e.rowIndex,dojo.isCopyKey(e),e.shiftKey);
},clear:function(){
this._beginUpdate();
this.deselectAll();
this._endUpdate();
}});
}
if(!dojo._hasResource["dojox.grid._Events"]){
dojo._hasResource["dojox.grid._Events"]=true;
dojo.provide("dojox.grid._Events");
dojo.declare("dojox.grid._Events",null,{cellOverClass:"dojoxGridCellOver",onKeyEvent:function(e){
this.dispatchKeyEvent(e);
},onContentEvent:function(e){
this.dispatchContentEvent(e);
},onHeaderEvent:function(e){
this.dispatchHeaderEvent(e);
},onStyleRow:function(_7c1){
var i=_7c1;
i.customClasses+=(i.odd?" dojoxGridRowOdd":"")+(i.selected?" dojoxGridRowSelected":"")+(i.over?" dojoxGridRowOver":"");
this.focus.styleRow(_7c1);
this.edit.styleRow(_7c1);
},onKeyDown:function(e){
if(e.altKey||e.metaKey){
return;
}
var dk=dojo.keys;
var _7c2;
switch(e.keyCode){
case dk.ESCAPE:
this.edit.cancel();
break;
case dk.ENTER:
if(!this.edit.isEditing()){
_7c2=this.focus.getHeaderIndex();
if(_7c2>=0){
this.setSortIndex(_7c2);
break;
}else{
this.selection.clickSelect(this.focus.rowIndex,dojo.isCopyKey(e),e.shiftKey);
}
dojo.stopEvent(e);
}
if(!e.shiftKey){
var _7c3=this.edit.isEditing();
this.edit.apply();
if(!_7c3){
this.edit.setEditCell(this.focus.cell,this.focus.rowIndex);
}
}
if(!this.edit.isEditing()){
var _7c4=this.focus.focusView||this.views.views[0];
_7c4.content.decorateEvent(e,_7c4.rowNodes[this.focus.rowIndex]);
this.onRowClick(e);
dojo.stopEvent(e);
}
break;
case dk.SPACE:
if(!this.edit.isEditing()){
_7c2=this.focus.getHeaderIndex();
if(_7c2>=0){
this.setSortIndex(_7c2);
break;
}else{
this.selection.clickSelect(this.focus.rowIndex,dojo.isCopyKey(e),e.shiftKey);
}
}
break;
case dk.TAB:
this.focus[e.shiftKey?"previousKey":"nextKey"](e);
break;
case dk.LEFT_ARROW:
case dk.RIGHT_ARROW:
if(!this.edit.isEditing()){
var _7c5=e.keyCode;
dojo.stopEvent(e);
_7c2=this.focus.getHeaderIndex();
if(_7c2>=0&&(e.shiftKey&&e.ctrlKey)){
this.focus.colSizeAdjust(e,_7c2,(_7c5==dk.LEFT_ARROW?-1:1)*5);
}else{
var _7c6=(_7c5==dk.LEFT_ARROW)?1:-1;
if(dojo._isBodyLtr()){
_7c6*=-1;
}
this.focus.move(0,_7c6);
}
}
break;
case dk.UP_ARROW:
if(!this.edit.isEditing()&&this.focus.rowIndex!==0){
dojo.stopEvent(e);
this.focus.move(-1,0);
}
break;
case dk.DOWN_ARROW:
if(!this.edit.isEditing()&&this.focus.rowIndex+1!=this.rowCount){
dojo.stopEvent(e);
this.focus.move(1,0);
}
break;
case dk.PAGE_UP:
if(!this.edit.isEditing()&&this.focus.rowIndex!==0){
dojo.stopEvent(e);
if(this.focus.rowIndex!=this.scroller.firstVisibleRow+1){
this.focus.move(this.scroller.firstVisibleRow-this.focus.rowIndex,0);
}else{
this.setScrollTop(this.scroller.findScrollTop(this.focus.rowIndex-1));
this.focus.move(this.scroller.firstVisibleRow-this.scroller.lastVisibleRow+1,0);
}
}
break;
case dk.PAGE_DOWN:
if(!this.edit.isEditing()&&this.focus.rowIndex+1!=this.rowCount){
dojo.stopEvent(e);
if(this.focus.rowIndex!=this.scroller.lastVisibleRow-1){
this.focus.move(this.scroller.lastVisibleRow-this.focus.rowIndex-1,0);
}else{
this.setScrollTop(this.scroller.findScrollTop(this.focus.rowIndex+1));
this.focus.move(this.scroller.lastVisibleRow-this.scroller.firstVisibleRow-1,0);
}
}
break;
default:
break;
}
},onMouseOver:function(e){
e.rowIndex==-1?this.onHeaderCellMouseOver(e):this.onCellMouseOver(e);
},onMouseOut:function(e){
e.rowIndex==-1?this.onHeaderCellMouseOut(e):this.onCellMouseOut(e);
},onMouseDown:function(e){
e.rowIndex==-1?this.onHeaderCellMouseDown(e):this.onCellMouseDown(e);
},onMouseOverRow:function(e){
if(!this.rows.isOver(e.rowIndex)){
this.rows.setOverRow(e.rowIndex);
e.rowIndex==-1?this.onHeaderMouseOver(e):this.onRowMouseOver(e);
}
},onMouseOutRow:function(e){
if(this.rows.isOver(-1)){
this.onHeaderMouseOut(e);
}else{
if(!this.rows.isOver(-2)){
this.rows.setOverRow(-2);
this.onRowMouseOut(e);
}
}
},onMouseDownRow:function(e){
if(e.rowIndex!=-1){
this.onRowMouseDown(e);
}
},onCellMouseOver:function(e){
if(e.cellNode){
dojo.addClass(e.cellNode,this.cellOverClass);
}
},onCellMouseOut:function(e){
if(e.cellNode){
dojo.removeClass(e.cellNode,this.cellOverClass);
}
},onCellMouseDown:function(e){
},onCellClick:function(e){
this._click[0]=this._click[1];
this._click[1]=e;
if(!this.edit.isEditCell(e.rowIndex,e.cellIndex)){
this.focus.setFocusCell(e.cell,e.rowIndex);
}
if(this._click.length>1&&this._click[0]==null){
this._click.shift();
}
this.onRowClick(e);
},onCellDblClick:function(e){
var _7c7;
if(this._click.length>1&&dojo.isIE){
_7c7=this._click[1];
}else{
if(this._click.length>1&&this._click[0].rowIndex!=this._click[1].rowIndex){
_7c7=this._click[0];
}else{
_7c7=e;
}
}
this.focus.setFocusCell(_7c7.cell,_7c7.rowIndex);
this.onRowClick(_7c7);
this.edit.setEditCell(_7c7.cell,_7c7.rowIndex);
this.onRowDblClick(e);
},onCellContextMenu:function(e){
this.onRowContextMenu(e);
},onCellFocus:function(_7c8,_7c9){
this.edit.cellFocus(_7c8,_7c9);
},onRowClick:function(e){
this.edit.rowClick(e);
this.selection.clickSelectEvent(e);
},onRowDblClick:function(e){
},onRowMouseOver:function(e){
},onRowMouseOut:function(e){
},onRowMouseDown:function(e){
},onRowContextMenu:function(e){
dojo.stopEvent(e);
},onHeaderMouseOver:function(e){
},onHeaderMouseOut:function(e){
},onHeaderCellMouseOver:function(e){
if(e.cellNode){
dojo.addClass(e.cellNode,this.cellOverClass);
}
},onHeaderCellMouseOut:function(e){
if(e.cellNode){
dojo.removeClass(e.cellNode,this.cellOverClass);
}
},onHeaderCellMouseDown:function(e){
},onHeaderClick:function(e){
},onHeaderCellClick:function(e){
this.setSortIndex(e.cell.index);
this.onHeaderClick(e);
},onHeaderDblClick:function(e){
},onHeaderCellDblClick:function(e){
this.onHeaderDblClick(e);
},onHeaderCellContextMenu:function(e){
this.onHeaderContextMenu(e);
},onHeaderContextMenu:function(e){
if(!this.headerMenu){
dojo.stopEvent(e);
}
},onStartEdit:function(_7ca,_7cb){
},onApplyCellEdit:function(_7cc,_7cd,_7ce){
},onCancelEdit:function(_7cf){
},onApplyEdit:function(_7d0){
},onCanSelect:function(_7d1){
return true;
},onCanDeselect:function(_7d2){
return true;
},onSelected:function(_7d3){
this.updateRowStyles(_7d3);
},onDeselected:function(_7d4){
this.updateRowStyles(_7d4);
},onSelectionChanged:function(){
}});
}
if(!dojo._hasResource["dojox.grid._Grid"]){
dojo._hasResource["dojox.grid._Grid"]=true;
dojo.provide("dojox.grid._Grid");
(function(){
if(!dojo.isCopyKey){
dojo.isCopyKey=dojo.dnd.getCopyKeyState;
}
dojo.declare("dojox.grid._Grid",[dijit._Widget,dijit._Templated,dojox.grid._Events],{templateString:"<div hidefocus=\"hidefocus\" role=\"grid\" dojoAttachEvent=\"onmouseout:_mouseOut\">\r\n\t<div class=\"dojoxGridMasterHeader\" dojoAttachPoint=\"viewsHeaderNode\" role=\"presentation\"></div>\r\n\t<div class=\"dojoxGridMasterView\" dojoAttachPoint=\"viewsNode\" role=\"presentation\"></div>\r\n\t<div class=\"dojoxGridMasterMessages\" style=\"display: none;\" dojoAttachPoint=\"messagesNode\"></div>\r\n\t<span dojoAttachPoint=\"lastFocusNode\" tabindex=\"0\"></span>\r\n</div>\r\n",classTag:"dojoxGrid",rowCount:5,keepRows:75,rowsPerPage:25,autoWidth:false,initialWidth:"",autoHeight:"",rowHeight:0,autoRender:true,defaultHeight:"15em",height:"",structure:null,elasticView:-1,singleClickEdit:false,selectionMode:"extended",rowSelector:"",columnReordering:false,headerMenu:null,placeholderLabel:"GridColumns",selectable:false,_click:null,loadingMessage:"<span class='dojoxGridLoading'>${loadingState}</span>",errorMessage:"<span class='dojoxGridError'>${errorState}</span>",noDataMessage:"",escapeHTMLInData:true,formatterScope:null,editable:false,sortInfo:0,themeable:true,_placeholders:null,_layoutClass:dojox.grid._Layout,buildRendering:function(){
this.inherited(arguments);
if(!this.domNode.getAttribute("tabIndex")){
this.domNode.tabIndex="0";
}
this.createScroller();
this.createLayout();
this.createViews();
this.createManagers();
this.createSelection();
this.connect(this.selection,"onSelected","onSelected");
this.connect(this.selection,"onDeselected","onDeselected");
this.connect(this.selection,"onChanged","onSelectionChanged");
dojox.html.metrics.initOnFontResize();
this.connect(dojox.html.metrics,"onFontResize","textSizeChanged");
dojox.grid.util.funnelEvents(this.domNode,this,"doKeyEvent",dojox.grid.util.keyEvents);
if(this.selectionMode!="none"){
this.domNode.setAttribute("aria-multiselectable",this.selectionMode=="single"?"false":"true");
}
dojo.addClass(this.domNode,this.classTag);
if(!this.isLeftToRight()){
dojo.addClass(this.domNode,this.classTag+"Rtl");
}
},postMixInProperties:function(){
this.inherited(arguments);
var _7d5=dojo.i18n.getLocalization("dijit","loading",this.lang);
this.loadingMessage=dojo.string.substitute(this.loadingMessage,_7d5);
this.errorMessage=dojo.string.substitute(this.errorMessage,_7d5);
if(this.srcNodeRef&&this.srcNodeRef.style.height){
this.height=this.srcNodeRef.style.height;
}
this._setAutoHeightAttr(this.autoHeight,true);
this.lastScrollTop=this.scrollTop=0;
},postCreate:function(){
this._placeholders=[];
this._setHeaderMenuAttr(this.headerMenu);
this._setStructureAttr(this.structure);
this._click=[];
this.inherited(arguments);
if(this.domNode&&this.autoWidth&&this.initialWidth){
this.domNode.style.width=this.initialWidth;
}
if(this.domNode&&!this.editable){
dojo.attr(this.domNode,"aria-readonly","true");
}
},destroy:function(){
this.domNode.onReveal=null;
this.domNode.onSizeChange=null;
delete this._click;
if(this.scroller){
this.scroller.destroy();
delete this.scroller;
}
this.edit.destroy();
delete this.edit;
this.views.destroyViews();
if(this.focus){
this.focus.destroy();
delete this.focus;
}
if(this.headerMenu&&this._placeholders.length){
dojo.forEach(this._placeholders,function(p){
p.unReplace(true);
});
this.headerMenu.unBindDomNode(this.viewsHeaderNode);
}
this.inherited(arguments);
},_setAutoHeightAttr:function(ah,_7d6){
if(typeof ah=="string"){
if(!ah||ah=="false"){
ah=false;
}else{
if(ah=="true"){
ah=true;
}else{
ah=window.parseInt(ah,10);
}
}
}
if(typeof ah=="number"){
if(isNaN(ah)){
ah=false;
}
if(ah<0){
ah=true;
}else{
if(ah===0){
ah=false;
}
}
}
this.autoHeight=ah;
if(typeof ah=="boolean"){
this._autoHeight=ah;
}else{
if(typeof ah=="number"){
this._autoHeight=(ah>=this.get("rowCount"));
}else{
this._autoHeight=false;
}
}
if(this._started&&!_7d6){
this.render();
}
},_getRowCountAttr:function(){
return this.updating&&this.invalidated&&this.invalidated.rowCount!=undefined?this.invalidated.rowCount:this.rowCount;
},textSizeChanged:function(){
this.render();
},sizeChange:function(){
this.update();
},createManagers:function(){
this.rows=new dojox.grid._RowManager(this);
this.focus=new dojox.grid._FocusManager(this);
this.edit=new dojox.grid._EditManager(this);
},createSelection:function(){
this.selection=new dojox.grid.Selection(this);
},createScroller:function(){
this.scroller=new dojox.grid._Scroller();
this.scroller.grid=this;
this.scroller.renderRow=dojo.hitch(this,"renderRow");
this.scroller.removeRow=dojo.hitch(this,"rowRemoved");
},createLayout:function(){
this.layout=new this._layoutClass(this);
this.connect(this.layout,"moveColumn","onMoveColumn");
},onMoveColumn:function(){
this.render();
},onResizeColumn:function(_7d7){
},createViews:function(){
this.views=new dojox.grid._ViewManager(this);
this.views.createView=dojo.hitch(this,"createView");
},createView:function(_7d8,idx){
var c=dojo.getObject(_7d8);
var view=new c({grid:this,index:idx});
this.viewsNode.appendChild(view.domNode);
this.viewsHeaderNode.appendChild(view.headerNode);
this.views.addView(view);
dojo.attr(this.domNode,"align",dojo._isBodyLtr()?"left":"right");
return view;
},buildViews:function(){
for(var i=0,vs;(vs=this.layout.structure[i]);i++){
this.createView(vs.type||dojox._scopeName+".grid._View",i).setStructure(vs);
}
this.scroller.setContentNodes(this.views.getContentNodes());
},_setStructureAttr:function(_7d9){
var s=_7d9;
if(s&&dojo.isString(s)){
dojo.deprecated("dojox.grid._Grid.set('structure', 'objVar')","use dojox.grid._Grid.set('structure', objVar) instead","2.0");
s=dojo.getObject(s);
}
this.structure=s;
if(!s){
if(this.layout.structure){
s=this.layout.structure;
}else{
return;
}
}
this.views.destroyViews();
this.focus.focusView=null;
if(s!==this.layout.structure){
this.layout.setStructure(s);
}
this._structureChanged();
},setStructure:function(_7da){
dojo.deprecated("dojox.grid._Grid.setStructure(obj)","use dojox.grid._Grid.set('structure', obj) instead.","2.0");
this._setStructureAttr(_7da);
},getColumnTogglingItems:function(){
return dojo.map(this.layout.cells,function(cell){
if(!cell.menuItems){
cell.menuItems=[];
}
var self=this;
var item=new dijit.CheckedMenuItem({label:cell.name,checked:!cell.hidden,_gridCell:cell,onChange:function(_7db){
if(self.layout.setColumnVisibility(this._gridCell.index,_7db)){
var _7dc=this._gridCell.menuItems;
if(_7dc.length>1){
dojo.forEach(_7dc,function(item){
if(item!==this){
item.setAttribute("checked",_7db);
}
},this);
}
_7db=dojo.filter(self.layout.cells,function(c){
if(c.menuItems.length>1){
dojo.forEach(c.menuItems,"item.set('disabled', false);");
}else{
c.menuItems[0].set("disabled",false);
}
return !c.hidden;
});
if(_7db.length==1){
dojo.forEach(_7db[0].menuItems,"item.set('disabled', true);");
}
}
},destroy:function(){
var _7dd=dojo.indexOf(this._gridCell.menuItems,this);
this._gridCell.menuItems.splice(_7dd,1);
delete this._gridCell;
dijit.CheckedMenuItem.prototype.destroy.apply(this,arguments);
}});
cell.menuItems.push(item);
return item;
},this);
},_setHeaderMenuAttr:function(menu){
if(this._placeholders&&this._placeholders.length){
dojo.forEach(this._placeholders,function(p){
p.unReplace(true);
});
this._placeholders=[];
}
if(this.headerMenu){
this.headerMenu.unBindDomNode(this.viewsHeaderNode);
}
this.headerMenu=menu;
if(!menu){
return;
}
this.headerMenu.bindDomNode(this.viewsHeaderNode);
if(this.headerMenu.getPlaceholders){
this._placeholders=this.headerMenu.getPlaceholders(this.placeholderLabel);
}
},setHeaderMenu:function(menu){
dojo.deprecated("dojox.grid._Grid.setHeaderMenu(obj)","use dojox.grid._Grid.set('headerMenu', obj) instead.","2.0");
this._setHeaderMenuAttr(menu);
},setupHeaderMenu:function(){
if(this._placeholders&&this._placeholders.length){
dojo.forEach(this._placeholders,function(p){
if(p._replaced){
p.unReplace(true);
}
p.replace(this.getColumnTogglingItems());
},this);
}
},_fetch:function(_7de){
this.setScrollTop(0);
},getItem:function(_7df){
return null;
},showMessage:function(_7e0){
if(_7e0){
this.messagesNode.innerHTML=_7e0;
this.messagesNode.style.display="";
}else{
this.messagesNode.innerHTML="";
this.messagesNode.style.display="none";
}
},_structureChanged:function(){
this.buildViews();
if(this.autoRender&&this._started){
this.render();
}
},hasLayout:function(){
return this.layout.cells.length;
},resize:function(_7e1,_7e2){
this._pendingChangeSize=_7e1;
this._pendingResultSize=_7e2;
this.sizeChange();
},_getPadBorder:function(){
this._padBorder=this._padBorder||dojo._getPadBorderExtents(this.domNode);
return this._padBorder;
},_getHeaderHeight:function(){
var vns=this.viewsHeaderNode.style,t=vns.display=="none"?0:this.views.measureHeader();
vns.height=t+"px";
this.views.normalizeHeaderNodeHeight();
return t;
},_resize:function(_7e3,_7e4){
_7e3=_7e3||this._pendingChangeSize;
_7e4=_7e4||this._pendingResultSize;
delete this._pendingChangeSize;
delete this._pendingResultSize;
if(!this.domNode){
return;
}
var pn=this.domNode.parentNode;
if(!pn||pn.nodeType!=1||!this.hasLayout()||pn.style.visibility=="hidden"||pn.style.display=="none"){
return;
}
var _7e5=this._getPadBorder();
var hh=undefined;
var h;
if(this._autoHeight){
this.domNode.style.height="auto";
}else{
if(typeof this.autoHeight=="number"){
h=hh=this._getHeaderHeight();
h+=(this.scroller.averageRowHeight*this.autoHeight);
this.domNode.style.height=h+"px";
}else{
if(this.domNode.clientHeight<=_7e5.h){
if(pn==document.body){
this.domNode.style.height=this.defaultHeight;
}else{
if(this.height){
this.domNode.style.height=this.height;
}else{
if(dojo.style(this.domNode,"height")>0){
this.domNode.style.height=dojo.style(this.domNode,"height");
}else{
this.fitTo="parent";
}
}
}
}
}
}
if(_7e4){
_7e3=_7e4;
}
if(!this._autoHeight&&_7e3){
dojo.marginBox(this.domNode,_7e3);
this.height=this.domNode.style.height;
delete this.fitTo;
}else{
if(this.fitTo=="parent"){
h=this._parentContentBoxHeight=this._parentContentBoxHeight||dojo._getContentBox(pn).h;
this.domNode.style.height=Math.max(0,h)+"px";
}
}
var _7e6=dojo.some(this.views.views,function(v){
return v.flexCells;
});
if(!this._autoHeight&&(h||dojo._getContentBox(this.domNode).h)===0){
this.viewsHeaderNode.style.display="none";
}else{
this.viewsHeaderNode.style.display="block";
if(!_7e6&&hh===undefined){
hh=this._getHeaderHeight();
}
}
if(_7e6){
hh=undefined;
}
this.adaptWidth();
this.adaptHeight(hh);
this.postresize();
},adaptWidth:function(){
var _7e7=(!this.initialWidth&&this.autoWidth);
var w=_7e7?0:this.domNode.clientWidth||(this.domNode.offsetWidth-this._getPadBorder().w),vw=this.views.arrange(1,w);
this.views.onEach("adaptWidth");
if(_7e7){
this.domNode.style.width=vw+"px";
}
},adaptHeight:function(_7e8){
var t=_7e8===undefined?this._getHeaderHeight():_7e8;
var h=(this._autoHeight?-1:Math.max(this.domNode.clientHeight-t,0)||0);
this.views.onEach("setSize",[0,h]);
this.views.onEach("adaptHeight");
if(!this._autoHeight){
var _7e9=0,_7ea=0;
var _7eb=dojo.filter(this.views.views,function(v){
var has=v.hasHScrollbar();
if(has){
_7e9++;
}else{
_7ea++;
}
return (!has);
});
if(_7e9>0&&_7ea>0){
dojo.forEach(_7eb,function(v){
v.adaptHeight(true);
});
}
}
if(this.autoHeight===true||h!=-1||(typeof this.autoHeight=="number"&&this.autoHeight>=this.get("rowCount"))){
this.scroller.windowHeight=h;
}else{
this.scroller.windowHeight=Math.max(this.domNode.clientHeight-t,0);
}
},startup:function(){
if(this._started){
return;
}
this.inherited(arguments);
if(this.autoRender){
this.render();
}
},render:function(){
if(!this.domNode){
return;
}
if(!this._started){
return;
}
if(!this.hasLayout()){
this.scroller.init(0,this.keepRows,this.rowsPerPage);
return;
}
this.update=this.defaultUpdate;
this._render();
},_render:function(){
this.scroller.init(this.get("rowCount"),this.keepRows,this.rowsPerPage);
this.prerender();
this.setScrollTop(0);
this.postrender();
},prerender:function(){
this.keepRows=this._autoHeight?0:this.keepRows;
this.scroller.setKeepInfo(this.keepRows);
this.views.render();
this._resize();
},postrender:function(){
this.postresize();
this.focus.initFocusView();
dojo.setSelectable(this.domNode,this.selectable);
if(dojo.isIE){
dojo.query("th.dojoxGridCell",this.viewsHeaderNode).forEach(function(node){
dojo.setSelectable(node,true);
});
}
},postresize:function(){
if(this._autoHeight){
var size=Math.max(this.views.measureContent())+"px";
this.viewsNode.style.height=size;
}
},renderRow:function(_7ec,_7ed){
this.views.renderRow(_7ec,_7ed,this._skipRowRenormalize);
},rowRemoved:function(_7ee){
this.views.rowRemoved(_7ee);
},invalidated:null,updating:false,beginUpdate:function(){
this.invalidated=[];
this.updating=true;
},endUpdate:function(){
this.updating=false;
var i=this.invalidated,r;
if(i.all){
this.update();
}else{
if(i.rowCount!=undefined){
this.updateRowCount(i.rowCount);
}else{
for(r in i){
this.updateRow(Number(r));
}
}
}
this.invalidated=[];
},defaultUpdate:function(){
if(!this.domNode){
return;
}
if(this.updating){
this.invalidated.all=true;
return;
}
this.lastScrollTop=this.scrollTop;
this.prerender();
this.scroller.invalidateNodes();
this.setScrollTop(this.lastScrollTop);
this.postrender();
},update:function(){
this.render();
},updateRow:function(_7ef){
_7ef=Number(_7ef);
if(this.updating){
this.invalidated[_7ef]=true;
}else{
this.views.updateRow(_7ef);
this.scroller.rowHeightChanged(_7ef);
}
},updateRows:function(_7f0,_7f1){
_7f0=Number(_7f0);
_7f1=Number(_7f1);
var i;
if(this.updating){
for(i=0;i<_7f1;i++){
this.invalidated[i+_7f0]=true;
}
}else{
for(i=0;i<_7f1;i++){
this.views.updateRow(i+_7f0,this._skipRowRenormalize);
}
this.scroller.rowHeightChanged(_7f0);
}
},updateRowCount:function(_7f2){
if(this.updating){
this.invalidated.rowCount=_7f2;
}else{
this.rowCount=_7f2;
this._setAutoHeightAttr(this.autoHeight,true);
if(this.layout.cells.length){
this.scroller.updateRowCount(_7f2);
}
this._resize();
if(this.layout.cells.length){
this.setScrollTop(this.scrollTop);
}
}
},updateRowStyles:function(_7f3){
this.views.updateRowStyles(_7f3);
},getRowNode:function(_7f4){
if(this.focus.focusView&&!(this.focus.focusView instanceof dojox.grid._RowSelector)){
return this.focus.focusView.rowNodes[_7f4];
}else{
for(var i=0,_7f5;(_7f5=this.views.views[i]);i++){
if(!(_7f5 instanceof dojox.grid._RowSelector)){
return _7f5.rowNodes[_7f4];
}
}
}
return null;
},rowHeightChanged:function(_7f6){
this.views.renormalizeRow(_7f6);
this.scroller.rowHeightChanged(_7f6);
},fastScroll:true,delayScroll:false,scrollRedrawThreshold:(dojo.isIE?100:50),scrollTo:function(_7f7){
if(!this.fastScroll){
this.setScrollTop(_7f7);
return;
}
var _7f8=Math.abs(this.lastScrollTop-_7f7);
this.lastScrollTop=_7f7;
if(_7f8>this.scrollRedrawThreshold||this.delayScroll){
this.delayScroll=true;
this.scrollTop=_7f7;
this.views.setScrollTop(_7f7);
if(this._pendingScroll){
window.clearTimeout(this._pendingScroll);
}
var _7f9=this;
this._pendingScroll=window.setTimeout(function(){
delete _7f9._pendingScroll;
_7f9.finishScrollJob();
},200);
}else{
this.setScrollTop(_7f7);
}
},finishScrollJob:function(){
this.delayScroll=false;
this.setScrollTop(this.scrollTop);
},setScrollTop:function(_7fa){
this.scroller.scroll(this.views.setScrollTop(_7fa));
},scrollToRow:function(_7fb){
this.setScrollTop(this.scroller.findScrollTop(_7fb)+1);
},styleRowNode:function(_7fc,_7fd){
if(_7fd){
this.rows.styleRowNode(_7fc,_7fd);
}
},_mouseOut:function(e){
this.rows.setOverRow(-2);
},getCell:function(_7fe){
return this.layout.cells[_7fe];
},setCellWidth:function(_7ff,_800){
this.getCell(_7ff).unitWidth=_800;
},getCellName:function(_801){
return "Cell "+_801.index;
},canSort:function(_802){
},sort:function(){
},getSortAsc:function(_803){
_803=_803==undefined?this.sortInfo:_803;
return Boolean(_803>0);
},getSortIndex:function(_804){
if(this.sortInfo===0&&this.sortFields){
var _805=this.sortFields[0].attribute;
var _806;
dojo.some(this.layout.cells,function(c,idx){
if(c.field===_805){
_806=idx+1;
return true;
}
return false;
});
this.sortInfo=this.sortFields[0].descending?-_806:_806;
}
_804=_804==undefined?this.sortInfo:_804;
return Math.abs(_804)-1;
},setSortIndex:function(_807,_808){
var si=_807+1;
if(_808!=undefined){
si*=(_808?1:-1);
}else{
if(this.getSortIndex()==_807){
si=-this.sortInfo;
}
}
this.setSortInfo(si);
},setSortInfo:function(_809){
if(this.canSort(_809)){
this.sortInfo=_809;
this.sort();
this.update();
}
},doKeyEvent:function(e){
e.dispatch="do"+e.type;
this.onKeyEvent(e);
},_dispatch:function(m,e){
if(m in this){
return this[m](e);
}
return false;
},dispatchKeyEvent:function(e){
this._dispatch(e.dispatch,e);
},dispatchContentEvent:function(e){
this.edit.dispatchEvent(e)||e.sourceView.dispatchContentEvent(e)||this._dispatch(e.dispatch,e);
},dispatchHeaderEvent:function(e){
e.sourceView.dispatchHeaderEvent(e)||this._dispatch("doheader"+e.type,e);
},dokeydown:function(e){
this.onKeyDown(e);
},doclick:function(e){
if(e.cellNode){
this.onCellClick(e);
}else{
this.onRowClick(e);
}
},dodblclick:function(e){
if(e.cellNode){
this.onCellDblClick(e);
}else{
this.onRowDblClick(e);
}
},docontextmenu:function(e){
if(e.cellNode){
this.onCellContextMenu(e);
}else{
this.onRowContextMenu(e);
}
},doheaderclick:function(e){
if(e.cellNode){
this.onHeaderCellClick(e);
}else{
this.onHeaderClick(e);
}
},doheaderdblclick:function(e){
if(e.cellNode){
this.onHeaderCellDblClick(e);
}else{
this.onHeaderDblClick(e);
}
},doheadercontextmenu:function(e){
if(e.cellNode){
this.onHeaderCellContextMenu(e);
}else{
this.onHeaderContextMenu(e);
}
},doStartEdit:function(_80a,_80b){
this.onStartEdit(_80a,_80b);
},doApplyCellEdit:function(_80c,_80d,_80e){
this.onApplyCellEdit(_80c,_80d,_80e);
},doCancelEdit:function(_80f){
this.onCancelEdit(_80f);
},doApplyEdit:function(_810){
this.onApplyEdit(_810);
},addRow:function(){
this.updateRowCount(this.get("rowCount")+1);
},removeSelectedRows:function(){
if(this.allItemsSelected){
this.updateRowCount(0);
}else{
this.updateRowCount(Math.max(0,this.get("rowCount")-this.selection.getSelected().length));
}
this.selection.clear();
}});
dojox.grid._Grid.markupFactory=function(_811,node,ctor,_812){
var d=dojo;
var _813=function(n){
var w=d.attr(n,"width")||"auto";
if((w!="auto")&&(w.slice(-2)!="em")&&(w.slice(-1)!="%")){
w=parseInt(w,10)+"px";
}
return w;
};
if(!_811.structure&&node.nodeName.toLowerCase()=="table"){
_811.structure=d.query("> colgroup",node).map(function(cg){
var sv=d.attr(cg,"span");
var v={noscroll:(d.attr(cg,"noscroll")=="true")?true:false,__span:(!!sv?parseInt(sv,10):1),cells:[]};
if(d.hasAttr(cg,"width")){
v.width=_813(cg);
}
return v;
});
if(!_811.structure.length){
_811.structure.push({__span:Infinity,cells:[]});
}
d.query("thead > tr",node).forEach(function(tr,_814){
var _815=0;
var _816=0;
var _817;
var _818=null;
d.query("> th",tr).map(function(th){
if(!_818){
_817=0;
_818=_811.structure[0];
}else{
if(_815>=(_817+_818.__span)){
_816++;
_817+=_818.__span;
var _819=_818;
_818=_811.structure[_816];
}
}
var cell={name:d.trim(d.attr(th,"name")||th.innerHTML),colSpan:parseInt(d.attr(th,"colspan")||1,10),type:d.trim(d.attr(th,"cellType")||""),id:d.trim(d.attr(th,"id")||"")};
_815+=cell.colSpan;
var _81a=d.attr(th,"rowspan");
if(_81a){
cell.rowSpan=_81a;
}
if(d.hasAttr(th,"width")){
cell.width=_813(th);
}
if(d.hasAttr(th,"relWidth")){
cell.relWidth=window.parseInt(dojo.attr(th,"relWidth"),10);
}
if(d.hasAttr(th,"hidden")){
cell.hidden=(d.attr(th,"hidden")=="true"||d.attr(th,"hidden")===true);
}
if(_812){
_812(th,cell);
}
cell.type=cell.type?dojo.getObject(cell.type):dojox.grid.cells.Cell;
if(cell.type&&cell.type.markupFactory){
cell.type.markupFactory(th,cell);
}
if(!_818.cells[_814]){
_818.cells[_814]=[];
}
_818.cells[_814].push(cell);
});
});
}
return new ctor(_811,node);
};
})();
}
if(!dojo._hasResource["dojo.DeferredList"]){
dojo._hasResource["dojo.DeferredList"]=true;
dojo.provide("dojo.DeferredList");
dojo.DeferredList=function(list,_81b,_81c,_81d,_81e){
var _81f=[];
dojo.Deferred.call(this);
var self=this;
if(list.length===0&&!_81b){
this.resolve([0,[]]);
}
var _820=0;
dojo.forEach(list,function(item,i){
item.then(function(_821){
if(_81b){
self.resolve([i,_821]);
}else{
_822(true,_821);
}
},function(_823){
if(_81c){
self.reject(_823);
}else{
_822(false,_823);
}
if(_81d){
return null;
}
throw _823;
});
function _822(_824,_825){
_81f[i]=[_824,_825];
_820++;
if(_820===list.length){
self.resolve(_81f);
}
};
});
};
dojo.DeferredList.prototype=new dojo.Deferred();
dojo.DeferredList.prototype.gatherResults=function(_826){
var d=new dojo.DeferredList(_826,false,true,false);
d.addCallback(function(_827){
var ret=[];
dojo.forEach(_827,function(_828){
ret.push(_828[1]);
});
return ret;
});
return d;
};
}
if(!dojo._hasResource["dojox.grid._SelectionPreserver"]){
dojo._hasResource["dojox.grid._SelectionPreserver"]=true;
dojo.provide("dojox.grid._SelectionPreserver");
dojo.declare("dojox.grid._SelectionPreserver",null,{constructor:function(_829){
this.selection=_829;
var grid=this.grid=_829.grid;
this.reset();
this._connects=[dojo.connect(grid,"_setStore",this,"reset"),dojo.connect(grid,"_addItem",this,"_reSelectById"),dojo.connect(_829,"addToSelection",dojo.hitch(this,"_selectById",true)),dojo.connect(_829,"deselect",dojo.hitch(this,"_selectById",false)),dojo.connect(_829,"deselectAll",this,"reset")];
},destroy:function(){
this.reset();
dojo.forEach(this._connects,dojo.disconnect);
delete this._connects;
},reset:function(){
this._selectedById={};
},_reSelectById:function(item,_82a){
if(item&&this.grid._hasIdentity){
this.selection.selected[_82a]=this._selectedById[this.grid.store.getIdentity(item)];
}
},_selectById:function(_82b,_82c){
if(this.selection.mode=="none"||!this.grid._hasIdentity){
return;
}
var item=_82c,g=this.grid;
if(typeof _82c=="number"||typeof _82c=="string"){
var _82d=g._by_idx[_82c];
item=_82d&&_82d.item;
}
if(item){
this._selectedById[g.store.getIdentity(item)]=!!_82b;
}
return item;
}});
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins._SelectionPreserver"]){
dojo._hasResource["dojox.grid.enhanced.plugins._SelectionPreserver"]=true;
dojo.provide("dojox.grid.enhanced.plugins._SelectionPreserver");
dojo.declare("dojox.grid.enhanced.plugins._SelectionPreserver",dojox.grid._SelectionPreserver,{constructor:function(_82e){
var grid=this.grid;
grid.onSelectedById=this.onSelectedById;
this._oldClearData=grid._clearData;
var self=this;
grid._clearData=function(){
self._updateMapping(!grid._noInternalMapping);
self._trustSelection=[];
self._oldClearData.apply(grid,arguments);
};
this._connects.push(dojo.connect(_82e,"selectRange",dojo.hitch(this,"_updateMapping",true,true,false)),dojo.connect(_82e,"deselectRange",dojo.hitch(this,"_updateMapping",true,false,false)),dojo.connect(_82e,"deselectAll",dojo.hitch(this,"_updateMapping",true,false,true)));
},destroy:function(){
this.inherited(arguments);
this.grid._clearData=this._oldClearData;
},reset:function(){
this.inherited(arguments);
this._idMap=[];
this._trustSelection=[];
this._defaultSelected=false;
},_reSelectById:function(item,_82f){
var s=this.selection,g=this.grid;
if(item&&g._hasIdentity){
var id=g.store.getIdentity(item);
if(this._selectedById[id]===undefined){
if(!this._trustSelection[_82f]){
s.selected[_82f]=this._defaultSelected;
}
}else{
s.selected[_82f]=this._selectedById[id];
}
this._idMap.push(id);
g.onSelectedById(id,_82f,s.selected[_82f]);
}
},_selectById:function(_830,_831){
if(!this.inherited(arguments)){
this._trustSelection[_831]=true;
}
},onSelectedById:function(id,_832,_833){
},_updateMapping:function(_834,_835,_836,from,to){
var s=this.selection,g=this.grid,flag=0,_837=0,i,id;
for(i=g.rowCount-1;i>=0;--i){
if(!g._by_idx[i]){
++_837;
flag+=s.selected[i]?1:-1;
}else{
id=g._by_idx[i].idty;
if(id&&(_834||this._selectedById[id]===undefined)){
this._selectedById[id]=!!s.selected[i];
}
}
}
if(_837){
this._defaultSelected=flag>0;
}
if(!_836&&from!==undefined&&to!==undefined){
_836=!g.usingPagination&&Math.abs(to-from+1)===g.rowCount;
}
if(_836&&(!g.usingPagination||g.selectionMode==="single")){
for(i=this._idMap.length-1;i>=0;--i){
this._selectedById[this._idMap[i]]=_835;
}
}
}});
}
if(!dojo._hasResource["dojox.grid.DataSelection"]){
dojo._hasResource["dojox.grid.DataSelection"]=true;
dojo.provide("dojox.grid.DataSelection");
dojo.declare("dojox.grid.DataSelection",dojox.grid.Selection,{constructor:function(grid){
if(grid.keepSelection){
this.preserver=new dojox.grid.enhanced.plugins._SelectionPreserver(this);
}
},destroy:function(){
if(this.preserver){
this.preserver.destroy();
}
},getFirstSelected:function(){
var idx=dojox.grid.Selection.prototype.getFirstSelected.call(this);
if(idx==-1){
return null;
}
return this.grid.getItem(idx);
},getNextSelected:function(_838){
var _839=this.grid.getItemIndex(_838);
var idx=dojox.grid.Selection.prototype.getNextSelected.call(this,_839);
if(idx==-1){
return null;
}
return this.grid.getItem(idx);
},getSelected:function(){
var _83a=[];
for(var i=0,l=this.selected.length;i<l;i++){
if(this.selected[i]){
_83a.push(this.grid.getItem(i));
}
}
return _83a;
},getSelectedItems:function(_83b){
var res=[],d=new dojo.Deferred(),defs=[],_83c,i,len,item,_83d=[],grid=this.grid,_83e=this,ps=_83b||grid.rowsPerPage,_83f={query:grid.query,sort:grid.getSortProps(),queryOptions:grid.queryOptions,onError:dojo.hitch(d,d.errback)},_840=function(def,_841,_842){
for(var i=0,len=_842.length;i<len;++i){
res[_83d[_841]+i]=_842[i];
}
def.callback();
};
for(i=0,len=this.selected.length;i<len;++i){
if(this.selected[i]){
item=grid._by_idx[i];
res[i]=item&&item.item;
if(!item){
_83d.push(i);
}
}
}
for(_83c=0,len=_83d.length;_83c<len;_83c=i){
for(i=_83c+1;i<len&&_83d[i]===_83d[i-1]+1&&ps<0||i-_83c<ps;++i){
}
var def=new dojo.Deferred();
var req=dojo.mixin({start:_83d[_83c],count:i-_83c,onComplete:dojo.partial(_840,def,_83c)},_83f);
defs.push(def);
if(grid._storeLayerFetch){
grid._storeLayerFetch(req);
}else{
grid.store.fetch(req);
}
}
(new dojo.DeferredList(defs)).then(function(){
res=dojo.filter(res,function(item){
return item;
});
if(_83e.preserver){
var id,dl=[],_843=function(_844,item){
res.push(item);
_844.callback();
},_845=dojo.map(res,function(item){
return grid.store.getIdentity(item);
});
for(id in _83e.preserver._selectedById){
if(_83e.preserver._selectedById[id]===true&&dojo.indexOf(_845,id)<0){
var dd=new dojo.Deferred();
grid.store.fetchItemByIdentity({identity:id,onItem:dojo.partial(_843,dd)});
dl.push(dd);
}
}
if(dl.length){
(new dojo.DeferredList(dl)).then(function(){
d.callback(res);
});
return;
}
}
d.callback(res);
},dojo.hitch(d,d.errback));
return d;
},addToSelection:function(_846){
if(this.mode=="none"){
return;
}
var idx=null;
if(typeof _846=="number"||typeof _846=="string"){
idx=_846;
}else{
idx=this.grid.getItemIndex(_846);
}
dojox.grid.Selection.prototype.addToSelection.call(this,idx);
},deselect:function(_847){
if(this.mode=="none"){
return;
}
var idx=null;
if(typeof _847=="number"||typeof _847=="string"){
idx=_847;
}else{
idx=this.grid.getItemIndex(_847);
}
dojox.grid.Selection.prototype.deselect.call(this,idx);
},deselectAll:function(_848){
var idx=null;
if(_848||typeof _848=="number"){
if(typeof _848=="number"||typeof _848=="string"){
idx=_848;
}else{
idx=this.grid.getItemIndex(_848);
}
dojox.grid.Selection.prototype.deselectAll.call(this,idx);
}else{
this.inherited(arguments);
}
}});
}
if(!dojo._hasResource["dojox.grid.DataGrid"]){
dojo._hasResource["dojox.grid.DataGrid"]=true;
dojo.provide("dojox.grid.DataGrid");
dojo.declare("dojox.grid.DataGrid",dojox.grid._Grid,{store:null,query:null,queryOptions:null,fetchText:"...",sortFields:null,updateDelay:1,items:null,_store_connects:null,_by_idty:null,_by_idx:null,_cache:null,_pages:null,_pending_requests:null,_bop:-1,_eop:-1,_requests:0,rowCount:0,_isLoaded:false,_isLoading:false,keepSelection:false,postCreate:function(){
this._pages=[];
this._store_connects=[];
this._by_idty={};
this._by_idx=[];
this._cache=[];
this._pending_requests={};
this._setStore(this.store);
this.inherited(arguments);
},destroy:function(){
this.selection.destroy();
this.inherited(arguments);
},createSelection:function(){
this.selection=new dojox.grid.DataSelection(this);
},get:function(_849,_84a){
if(_84a&&this.field=="_item"&&!this.fields){
return _84a;
}else{
if(_84a&&this.fields){
var ret=[];
var s=this.grid.store;
dojo.forEach(this.fields,function(f){
ret=ret.concat(s.getValues(_84a,f));
});
return ret;
}else{
if(!_84a&&typeof _849==="string"){
return this.inherited(arguments);
}
}
}
return (!_84a?this.defaultValue:(!this.field?this.value:(this.field=="_item"?_84a:this.grid.store.getValue(_84a,this.field))));
},_checkUpdateStatus:function(){
if(this.updateDelay>0){
var _84b=false;
if(this._endUpdateDelay){
clearTimeout(this._endUpdateDelay);
delete this._endUpdateDelay;
_84b=true;
}
if(!this.updating){
this.beginUpdate();
_84b=true;
}
if(_84b){
var _84c=this;
this._endUpdateDelay=setTimeout(function(){
delete _84c._endUpdateDelay;
_84c.endUpdate();
},this.updateDelay);
}
}
},_onSet:function(item,_84d,_84e,_84f){
this._checkUpdateStatus();
var idx=this.getItemIndex(item);
if(idx>-1){
this.updateRow(idx);
}
},_createItem:function(item,_850){
var idty=this._hasIdentity?this.store.getIdentity(item):dojo.toJson(this.query)+":idx:"+_850+":sort:"+dojo.toJson(this.getSortProps());
var o=this._by_idty[idty]={idty:idty,item:item};
return o;
},_addItem:function(item,_851,_852){
this._by_idx[_851]=this._createItem(item,_851);
if(!_852){
this.updateRow(_851);
}
},_onNew:function(item,_853){
this._checkUpdateStatus();
var _854=this.get("rowCount");
this._addingItem=true;
this.updateRowCount(_854+1);
this._addingItem=false;
this._addItem(item,_854);
this.showMessage();
},_onDelete:function(item){
this._checkUpdateStatus();
var idx=this._getItemIndex(item,true);
if(idx>=0){
if(this.selection.isSelected(idx)){
this.selection.deselect(idx);
this.selection.selected.splice(idx,1);
}
this._pages=[];
this._bop=-1;
this._eop=-1;
var o=this._by_idx[idx];
this._by_idx.splice(idx,1);
delete this._by_idty[o.idty];
this.updateRowCount(this.get("rowCount")-1);
if(this.get("rowCount")===0){
this.showMessage(this.noDataMessage);
}
}
},_onRevert:function(){
this._refresh();
},setStore:function(_855,_856,_857){
this._setQuery(_856,_857);
this._setStore(_855);
this._refresh(true);
},setQuery:function(_858,_859){
this._setQuery(_858,_859);
this._refresh(true);
},setItems:function(_85a){
this.items=_85a;
this._setStore(this.store);
this._refresh(true);
},_setQuery:function(_85b,_85c){
this.query=_85b;
this.queryOptions=_85c||this.queryOptions;
},_setStore:function(_85d){
if(this.store&&this._store_connects){
dojo.forEach(this._store_connects,this.disconnect,this);
}
this.store=_85d;
if(this.store){
var f=this.store.getFeatures();
var h=[];
this._canEdit=!!f["dojo.data.api.Write"]&&!!f["dojo.data.api.Identity"];
this._hasIdentity=!!f["dojo.data.api.Identity"];
if(!!f["dojo.data.api.Notification"]&&!this.items){
h.push(this.connect(this.store,"onSet","_onSet"));
h.push(this.connect(this.store,"onNew","_onNew"));
h.push(this.connect(this.store,"onDelete","_onDelete"));
}
if(this._canEdit){
h.push(this.connect(this.store,"revert","_onRevert"));
}
this._store_connects=h;
}
},_onFetchBegin:function(size,req){
if(!this.scroller){
return;
}
if(this.rowCount!=size){
if(req.isRender){
this.scroller.init(size,this.keepRows,this.rowsPerPage);
this.rowCount=size;
this._setAutoHeightAttr(this.autoHeight,true);
this._skipRowRenormalize=true;
this.prerender();
this._skipRowRenormalize=false;
}else{
this.updateRowCount(size);
}
}
if(!size){
this.views.render();
this._resize();
this.showMessage(this.noDataMessage);
this.focus.initFocusView();
}else{
this.showMessage();
}
},_onFetchComplete:function(_85e,req){
if(!this.scroller){
return;
}
if(_85e&&_85e.length>0){
dojo.forEach(_85e,function(item,idx){
this._addItem(item,req.start+idx,true);
},this);
this.updateRows(req.start,_85e.length);
if(req.isRender){
this.setScrollTop(0);
this.postrender();
}else{
if(this._lastScrollTop){
this.setScrollTop(this._lastScrollTop);
}
}
if(dojo.isIE){
dojo.setSelectable(this.domNode,this.selectable);
dojo.query("th.dojoxGridCell",this.viewsHeaderNode).forEach(function(node){
dojo.setSelectable(node,true);
});
}
}
delete this._lastScrollTop;
if(!this._isLoaded){
this._isLoading=false;
this._isLoaded=true;
}
this._pending_requests[req.start]=false;
},_onFetchError:function(err,req){
delete this._lastScrollTop;
if(!this._isLoaded){
this._isLoading=false;
this._isLoaded=true;
this.showMessage(this.errorMessage);
}
this._pending_requests[req.start]=false;
this.onFetchError(err,req);
},onFetchError:function(err,req){
},_fetch:function(_85f,_860){
_85f=_85f||0;
if(this.store&&!this._pending_requests[_85f]){
if(!this._isLoaded&&!this._isLoading){
this._isLoading=true;
this.showMessage(this.loadingMessage);
}
this._pending_requests[_85f]=true;
try{
if(this.items){
var _861=this.items;
var _862=this.store;
this.rowsPerPage=_861.length;
var req={start:_85f,count:this.rowsPerPage,isRender:_860};
this._onFetchBegin(_861.length,req);
var _863=0;
dojo.forEach(_861,function(i){
if(!_862.isItemLoaded(i)){
_863++;
}
});
if(_863===0){
this._onFetchComplete(_861,req);
}else{
var _864=function(item){
_863--;
if(_863===0){
this._onFetchComplete(_861,req);
}
};
dojo.forEach(_861,function(i){
if(!_862.isItemLoaded(i)){
_862.loadItem({item:i,onItem:_864,scope:this});
}
},this);
}
}else{
this.store.fetch({start:_85f,count:this.rowsPerPage,query:this.query,sort:this.getSortProps(),queryOptions:this.queryOptions,isRender:_860,onBegin:dojo.hitch(this,"_onFetchBegin"),onComplete:dojo.hitch(this,"_onFetchComplete"),onError:dojo.hitch(this,"_onFetchError")});
}
}
catch(e){
this._onFetchError(e,{start:_85f,count:this.rowsPerPage});
}
}
},_clearData:function(){
this.updateRowCount(0);
this._by_idty={};
this._by_idx=[];
this._pages=[];
this._bop=this._eop=-1;
this._isLoaded=false;
this._isLoading=false;
},getItem:function(idx){
var data=this._by_idx[idx];
if(!data||(data&&!data.item)){
this._preparePage(idx);
return null;
}
return data.item;
},getItemIndex:function(item){
return this._getItemIndex(item,false);
},_getItemIndex:function(item,_865){
if(!_865&&!this.store.isItem(item)){
return -1;
}
var idty=this._hasIdentity?this.store.getIdentity(item):null;
for(var i=0,l=this._by_idx.length;i<l;i++){
var d=this._by_idx[i];
if(d&&((idty&&d.idty==idty)||(d.item===item))){
return i;
}
}
return -1;
},filter:function(_866,_867){
this.query=_866;
if(_867){
this._clearData();
}
this._fetch();
},_getItemAttr:function(idx,attr){
var item=this.getItem(idx);
return (!item?this.fetchText:this.store.getValue(item,attr));
},_render:function(){
if(this.domNode.parentNode){
this.scroller.init(this.get("rowCount"),this.keepRows,this.rowsPerPage);
this.prerender();
this._fetch(0,true);
}
},_requestsPending:function(_868){
return this._pending_requests[_868];
},_rowToPage:function(_869){
return (this.rowsPerPage?Math.floor(_869/this.rowsPerPage):_869);
},_pageToRow:function(_86a){
return (this.rowsPerPage?this.rowsPerPage*_86a:_86a);
},_preparePage:function(_86b){
if((_86b<this._bop||_86b>=this._eop)&&!this._addingItem){
var _86c=this._rowToPage(_86b);
this._needPage(_86c);
this._bop=_86c*this.rowsPerPage;
this._eop=this._bop+(this.rowsPerPage||this.get("rowCount"));
}
},_needPage:function(_86d){
if(!this._pages[_86d]){
this._pages[_86d]=true;
this._requestPage(_86d);
}
},_requestPage:function(_86e){
var row=this._pageToRow(_86e);
var _86f=Math.min(this.rowsPerPage,this.get("rowCount")-row);
if(_86f>0){
this._requests++;
if(!this._requestsPending(row)){
setTimeout(dojo.hitch(this,"_fetch",row,false),1);
}
}
},getCellName:function(_870){
return _870.field;
},_refresh:function(_871){
this._clearData();
this._fetch(0,_871);
},sort:function(){
this.edit.apply();
this._lastScrollTop=this.scrollTop;
this._refresh();
},canSort:function(){
return (!this._isLoading);
},getSortProps:function(){
var c=this.getCell(this.getSortIndex());
if(!c){
if(this.sortFields){
return this.sortFields;
}
return null;
}else{
var desc=c["sortDesc"];
var si=!(this.sortInfo>0);
if(typeof desc=="undefined"){
desc=si;
}else{
desc=si?!desc:desc;
}
return [{attribute:c.field,descending:desc}];
}
},styleRowState:function(_872){
if(this.store&&this.store.getState){
var _873=this.store.getState(_872.index),c="";
for(var i=0,ss=["inflight","error","inserting"],s;s=ss[i];i++){
if(_873[s]){
c=" dojoxGridRow-"+s;
break;
}
}
_872.customClasses+=c;
}
},onStyleRow:function(_874){
this.styleRowState(_874);
this.inherited(arguments);
},scrollToRow:function(_875){
var d=new dojo.Deferred(),_876=this,reqs=this._pending_requests,_877=function(){
_876.setScrollTop(_876.scroller.findScrollTop(_875)+1);
},_878=function(){
for(var i in reqs){
if(reqs[i]){
setTimeout(_878,10);
return;
}
}
_877();
d.callback();
};
_877();
setTimeout(_878,10);
return d;
},canEdit:function(_879,_87a){
return this._canEdit;
},_copyAttr:function(idx,attr){
var row={};
var _87b={};
var src=this.getItem(idx);
return this.store.getValue(src,attr);
},doStartEdit:function(_87c,_87d){
if(!this._cache[_87d]){
this._cache[_87d]=this._copyAttr(_87d,_87c.field);
}
this.onStartEdit(_87c,_87d);
},doApplyCellEdit:function(_87e,_87f,_880){
this.store.fetchItemByIdentity({identity:this._by_idx[_87f].idty,onItem:dojo.hitch(this,function(item){
var _881=this.store.getValue(item,_880);
if(typeof _881=="number"){
_87e=isNaN(_87e)?_87e:parseFloat(_87e);
}else{
if(typeof _881=="boolean"){
_87e=_87e=="true"?true:_87e=="false"?false:_87e;
}else{
if(_881 instanceof Date){
var _882=new Date(_87e);
_87e=isNaN(_882.getTime())?_87e:_882;
}
}
}
this.store.setValue(item,_880,_87e);
this.onApplyCellEdit(_87e,_87f,_880);
})});
},doCancelEdit:function(_883){
var _884=this._cache[_883];
if(_884){
this.updateRow(_883);
delete this._cache[_883];
}
this.onCancelEdit.apply(this,arguments);
},doApplyEdit:function(_885,_886){
var _887=this._cache[_885];
this.onApplyEdit(_885);
},removeSelectedRows:function(){
if(this._canEdit){
this.edit.apply();
var fx=dojo.hitch(this,function(_888){
if(_888.length){
dojo.forEach(_888,this.store.deleteItem,this.store);
this.selection.clear();
}
});
if(this.allItemsSelected){
this.store.fetch({query:this.query,queryOptions:this.queryOptions,onComplete:fx});
}else{
fx(this.selection.getSelected());
}
}
}});
dojox.grid.DataGrid.cell_markupFactory=function(_889,node,_88a){
var _88b=dojo.trim(dojo.attr(node,"field")||"");
if(_88b){
_88a.field=_88b;
}
_88a.field=_88a.field||_88a.name;
var _88c=dojo.trim(dojo.attr(node,"fields")||"");
if(_88c){
_88a.fields=_88c.split(",");
}
if(_889){
_889(node,_88a);
}
};
dojox.grid.DataGrid.markupFactory=function(_88d,node,ctor,_88e){
return dojox.grid._Grid.markupFactory(_88d,node,ctor,dojo.partial(dojox.grid.DataGrid.cell_markupFactory,_88e));
};
}
if(!dojo._hasResource["dojox.grid.enhanced._Events"]){
dojo._hasResource["dojox.grid.enhanced._Events"]=true;
dojo.provide("dojox.grid.enhanced._Events");
dojo.declare("dojox.grid.enhanced._Events",null,{_events:null,headerCellActiveClass:"dojoxGridHeaderActive",cellActiveClass:"dojoxGridCellActive",rowActiveClass:"dojoxGridRowActive",constructor:function(_88f){
this._events=new dojox.grid._Events();
_88f.mixin(_88f,this);
},dokeyup:function(e){
this.focus.currentArea().keyup(e);
},onKeyDown:function(e){
if(e.altKey||e.metaKey){
return;
}
var dk=dojo.keys;
var _890=this.focus;
var _891=this.edit.isEditing();
switch(e.keyCode){
case dk.TAB:
if(e.ctrlKey){
return;
}
_890.tab(e.shiftKey?-1:1,e);
break;
case dk.UP_ARROW:
case dk.DOWN_ARROW:
if(_891){
return;
}
_890.currentArea().move(e.keyCode==dk.UP_ARROW?-1:1,0,e);
break;
case dk.LEFT_ARROW:
case dk.RIGHT_ARROW:
if(_891){
return;
}
var _892=(e.keyCode==dk.LEFT_ARROW)?1:-1;
if(dojo._isBodyLtr()){
_892*=-1;
}
_890.currentArea().move(0,_892,e);
break;
case dk.F10:
if(this.menus&&e.shiftKey){
this.onRowContextMenu(e);
}
break;
default:
_890.currentArea().keydown(e);
break;
}
},domouseup:function(e){
if(e.cellNode){
this.onMouseUp(e);
}else{
this.onRowSelectorMouseUp(e);
}
},domousedown:function(e){
if(!e.cellNode){
this.onRowSelectorMouseDown(e);
}
},onMouseUp:function(e){
this[e.rowIndex==-1?"onHeaderCellMouseUp":"onCellMouseUp"](e);
},onCellMouseDown:function(e){
dojo.addClass(e.cellNode,this.cellActiveClass);
dojo.addClass(e.rowNode,this.rowActiveClass);
},onCellMouseUp:function(e){
dojo.removeClass(e.cellNode,this.cellActiveClass);
dojo.removeClass(e.rowNode,this.rowActiveClass);
},onCellClick:function(e){
this._events.onCellClick.call(this,e);
this.focus.contentMouseEvent(e);
},onCellDblClick:function(e){
if(this.pluginMgr.isFixedCell(e.cell)){
return;
}
if(this._click.length>1&&(!this._click[0]||!this._click[1])){
this._click[0]=this._click[1]=e;
}
this._events.onCellDblClick.call(this,e);
},onRowClick:function(e){
this.edit.rowClick(e);
if(!e.cell||!this.plugin("indirectSelection")){
this.selection.clickSelectEvent(e);
}
},onRowContextMenu:function(e){
if(!this.edit.isEditing()&&this.menus){
this.showMenu(e);
}
},onSelectedRegionContextMenu:function(e){
if(this.selectedRegionMenu){
this.selectedRegionMenu._openMyself({target:e.target,coords:e.keyCode!==dojo.keys.F10&&"pageX" in e?{x:e.pageX,y:e.pageY}:null});
dojo.stopEvent(e);
}
},onHeaderCellMouseOut:function(e){
if(e.cellNode){
dojo.removeClass(e.cellNode,this.cellOverClass);
dojo.removeClass(e.cellNode,this.headerCellActiveClass);
}
},onHeaderCellMouseDown:function(e){
if(e.cellNode){
dojo.addClass(e.cellNode,this.headerCellActiveClass);
}
},onHeaderCellMouseUp:function(e){
if(e.cellNode){
dojo.removeClass(e.cellNode,this.headerCellActiveClass);
}
},onHeaderCellClick:function(e){
this.focus.currentArea("header");
if(!e.cell.isRowSelector){
this._events.onHeaderCellClick.call(this,e);
}
this.focus.headerMouseEvent(e);
},onRowSelectorMouseDown:function(e){
this.focus.focusArea("rowHeader",e);
},onRowSelectorMouseUp:function(e){
},onMouseUpRow:function(e){
if(e.rowIndex!=-1){
this.onRowMouseUp(e);
}
},onRowMouseUp:function(e){
}});
}
if(!dojo._hasResource["dojox.grid.enhanced._FocusManager"]){
dojo._hasResource["dojox.grid.enhanced._FocusManager"]=true;
dojo.provide("dojox.grid.enhanced._FocusManager");
dojo.declare("dojox.grid.enhanced._FocusArea",null,{constructor:function(area,_893){
this._fm=_893;
this._evtStack=[area.name];
var _894=function(){
return true;
};
area.onFocus=area.onFocus||_894;
area.onBlur=area.onBlur||_894;
area.onMove=area.onMove||_894;
area.onKeyUp=area.onKeyUp||_894;
area.onKeyDown=area.onKeyDown||_894;
dojo.mixin(this,area);
},move:function(_895,_896,evt){
if(this.name){
var i,len=this._evtStack.length;
for(i=len-1;i>=0;--i){
if(this._fm._areas[this._evtStack[i]].onMove(_895,_896,evt)===false){
return false;
}
}
}
return true;
},_onKeyEvent:function(evt,_897){
if(this.name){
var i,len=this._evtStack.length;
for(i=len-1;i>=0;--i){
if(this._fm._areas[this._evtStack[i]][_897](evt,false)===false){
return false;
}
}
for(i=0;i<len;++i){
if(this._fm._areas[this._evtStack[i]][_897](evt,true)===false){
return false;
}
}
}
return true;
},keydown:function(evt){
return this._onKeyEvent(evt,"onKeyDown");
},keyup:function(evt){
return this._onKeyEvent(evt,"onKeyUp");
},contentMouseEventPlanner:function(){
return 0;
},headerMouseEventPlanner:function(){
return 0;
}});
dojo.declare("dojox.grid.enhanced._FocusManager",dojox.grid._FocusManager,{_stopEvent:function(evt){
try{
if(evt&&evt.preventDefault){
dojo.stopEvent(evt);
}
}
catch(e){
}
},constructor:function(grid){
this.grid=grid;
this._areas={};
this._areaQueue=[];
this._contentMouseEventHandlers=[];
this._headerMouseEventHandlers=[];
this._currentAreaIdx=-1;
this._gridBlured=true;
this._connects.push(dojo.connect(grid,"onBlur",this,"_doBlur"));
this._connects.push(dojo.connect(grid.scroller,"renderPage",this,"_delayedCellFocus"));
this.addArea({name:"header",onFocus:dojo.hitch(this,this.focusHeader),onBlur:dojo.hitch(this,this._blurHeader),onMove:dojo.hitch(this,this._navHeader),getRegions:dojo.hitch(this,this._findHeaderCells),onRegionFocus:dojo.hitch(this,this.doColHeaderFocus),onRegionBlur:dojo.hitch(this,this.doColHeaderBlur),onKeyDown:dojo.hitch(this,this._onHeaderKeyDown)});
this.addArea({name:"content",onFocus:dojo.hitch(this,this._focusContent),onBlur:dojo.hitch(this,this._blurContent),onMove:dojo.hitch(this,this._navContent),onKeyDown:dojo.hitch(this,this._onContentKeyDown)});
this.addArea({name:"editableCell",onFocus:dojo.hitch(this,this._focusEditableCell),onBlur:dojo.hitch(this,this._blurEditableCell),onKeyDown:dojo.hitch(this,this._onEditableCellKeyDown),onContentMouseEvent:dojo.hitch(this,this._onEditableCellMouseEvent),contentMouseEventPlanner:function(evt,_898){
return -1;
}});
this.placeArea("header");
this.placeArea("content");
this.placeArea("editableCell");
this.placeArea("editableCell","above","content");
},destroy:function(){
for(var name in this._areas){
var area=this._areas[name];
dojo.forEach(area._connects,dojo.disconnect);
area._connects=null;
if(area.uninitialize){
area.uninitialize();
}
}
this.inherited(arguments);
},addArea:function(area){
if(area.name&&dojo.isString(area.name)){
if(this._areas[area.name]){
dojo.forEach(area._connects,dojo.disconnect);
}
this._areas[area.name]=new dojox.grid.enhanced._FocusArea(area,this);
if(area.onHeaderMouseEvent){
this._headerMouseEventHandlers.push(area.name);
}
if(area.onContentMouseEvent){
this._contentMouseEventHandlers.push(area.name);
}
}
},getArea:function(_899){
return this._areas[_899];
},_bindAreaEvents:function(){
var area,hdl,_89a=this._areas;
dojo.forEach(this._areaQueue,function(name){
area=_89a[name];
if(!area._initialized&&dojo.isFunction(area.initialize)){
area.initialize();
area._initialized=true;
}
if(area.getRegions){
area._regions=area.getRegions()||[];
dojo.forEach(area._connects||[],dojo.disconnect);
area._connects=[];
dojo.forEach(area._regions,function(r){
if(area.onRegionFocus){
hdl=dojo.connect(r,"onfocus",area.onRegionFocus);
area._connects.push(hdl);
}
if(area.onRegionBlur){
hdl=dojo.connect(r,"onblur",area.onRegionBlur);
area._connects.push(hdl);
}
});
}
});
},removeArea:function(_89b){
var area=this._areas[_89b];
if(area){
this.ignoreArea(_89b);
var i=dojo.indexOf(this._contentMouseEventHandlers,_89b);
if(i>=0){
this._contentMouseEventHandlers.splice(i,1);
}
i=dojo.indexOf(this._headerMouseEventHandlers,_89b);
if(i>=0){
this._headerMouseEventHandlers.splice(i,1);
}
dojo.forEach(area._connects,dojo.disconnect);
if(area.uninitialize){
area.uninitialize();
}
delete this._areas[_89b];
}
},currentArea:function(_89c,_89d){
var idx,cai=this._currentAreaIdx;
if(dojo.isString(_89c)&&(idx=dojo.indexOf(this._areaQueue,_89c))>=0){
if(cai!=idx){
this.tabbingOut=false;
if(_89d&&cai>=0&&cai<this._areaQueue.length){
this._areas[this._areaQueue[cai]].onBlur();
}
this._currentAreaIdx=idx;
}
}else{
return (cai<0||cai>=this._areaQueue.length)?new dojox.grid.enhanced._FocusArea({},this):this._areas[this._areaQueue[this._currentAreaIdx]];
}
return null;
},placeArea:function(name,pos,_89e){
if(!this._areas[name]){
return;
}
var idx=dojo.indexOf(this._areaQueue,_89e);
switch(pos){
case "after":
if(idx>=0){
++idx;
}
case "before":
if(idx>=0){
this._areaQueue.splice(idx,0,name);
break;
}
default:
this._areaQueue.push(name);
break;
case "above":
var _89f=true;
case "below":
var _8a0=this._areas[_89e];
if(_8a0){
if(_89f){
_8a0._evtStack.push(name);
}else{
_8a0._evtStack.splice(0,0,name);
}
}
}
},ignoreArea:function(name){
this._areaQueue=dojo.filter(this._areaQueue,function(_8a1){
return _8a1!=name;
});
},focusArea:function(_8a2,evt){
var idx;
if(typeof _8a2=="number"){
idx=_8a2<0?this._areaQueue.length+_8a2:_8a2;
}else{
idx=dojo.indexOf(this._areaQueue,dojo.isString(_8a2)?_8a2:(_8a2&&_8a2.name));
}
if(idx<0){
idx=0;
}
var step=idx-this._currentAreaIdx;
this._gridBlured=false;
if(step){
this.tab(step,evt);
}else{
this.currentArea().onFocus(evt,step);
}
},tab:function(step,evt){
this._gridBlured=false;
this.tabbingOut=false;
if(step===0){
return;
}
var cai=this._currentAreaIdx;
var dir=step>0?1:-1;
if(cai<0||cai>=this._areaQueue.length){
cai=(this._currentAreaIdx+=step);
}else{
var _8a3=this._areas[this._areaQueue[cai]].onBlur(evt,step);
if(_8a3===true){
cai=(this._currentAreaIdx+=step);
}else{
if(dojo.isString(_8a3)&&this._areas[_8a3]){
cai=this._currentAreaIdx=dojo.indexOf(this._areaQueue,_8a3);
}
}
}
for(;cai>=0&&cai<this._areaQueue.length;cai+=dir){
this._currentAreaIdx=cai;
if(this._areaQueue[cai]&&this._areas[this._areaQueue[cai]].onFocus(evt,step)){
return;
}
}
this.tabbingOut=true;
if(step<0){
this._currentAreaIdx=-1;
dijit.focus(this.grid.domNode);
}else{
this._currentAreaIdx=this._areaQueue.length;
dijit.focus(this.grid.lastFocusNode);
}
},_onMouseEvent:function(type,evt){
var _8a4=type.toLowerCase(),_8a5=this["_"+_8a4+"MouseEventHandlers"],res=dojo.map(_8a5,function(_8a6){
return {"area":_8a6,"idx":this._areas[_8a6][_8a4+"MouseEventPlanner"](evt,_8a5)};
},this).sort(function(a,b){
return b.idx-a.idx;
}),_8a7=dojo.map(res,function(_8a8){
return res.area;
}),i=res.length;
while(--i>=0){
if(this._areas[res[i].area]["on"+type+"MouseEvent"](evt,_8a7)===false){
return;
}
}
},contentMouseEvent:function(evt){
this._onMouseEvent("Content",evt);
},headerMouseEvent:function(evt){
this._onMouseEvent("Header",evt);
},initFocusView:function(){
this.focusView=this.grid.views.getFirstScrollingView()||this.focusView||this.grid.views.views[0];
this._bindAreaEvents();
},isNavHeader:function(){
return this._areaQueue[this._currentAreaIdx]=="header";
},previousKey:function(e){
this.tab(-1,e);
},nextKey:function(e){
this.tab(1,e);
},setFocusCell:function(_8a9,_8aa){
if(_8a9){
this.currentArea(this.grid.edit.isEditing()?"editableCell":"content",true);
this.focusView=_8a9.view;
this._focusifyCellNode(false);
this.cell=_8a9;
this.rowIndex=_8aa;
this._focusifyCellNode(true);
}
this.grid.onCellFocus(this.cell,this.rowIndex);
},doFocus:function(e){
if(e&&e.target==e.currentTarget&&!this.tabbingOut){
if(this._gridBlured){
this._gridBlured=false;
if(this._currentAreaIdx<0||this._currentAreaIdx>=this._areaQueue.length){
this.focusArea(0,e);
}else{
this.focusArea(this._currentAreaIdx,e);
}
}
}else{
this.tabbingOut=false;
}
dojo.stopEvent(e);
},_doBlur:function(){
this._gridBlured=true;
},doLastNodeFocus:function(e){
if(this.tabbingOut){
this.tabbingOut=false;
}else{
this.focusArea(-1,e);
}
},_delayedHeaderFocus:function(){
if(this.isNavHeader()){
this.focusHeader();
}
},_delayedCellFocus:function(){
},_changeMenuBindNode:function(_8ab,_8ac){
var hm=this.grid.headerMenu;
if(hm&&this._contextMenuBindNode==_8ab){
hm.unBindDomNode(_8ab);
hm.bindDomNode(_8ac);
this._contextMenuBindNode=_8ac;
}
},focusHeader:function(evt,step){
var _8ad=false;
this.inherited(arguments);
if(this._colHeadNode&&dojo.style(this._colHeadNode,"display")!="none"){
dijit.focus(this._colHeadNode);
this._stopEvent(evt);
_8ad=true;
}
return _8ad;
},_blurHeader:function(evt,step){
if(this._colHeadNode){
dojo.removeClass(this._colHeadNode,this.focusClass);
}
dojo.removeAttr(this.grid.domNode,"aria-activedescendant");
this._changeMenuBindNode(this.grid.domNode,this.grid.viewsHeaderNode);
this._colHeadNode=this._colHeadFocusIdx=null;
return true;
},_navHeader:function(_8ae,_8af,evt){
var _8b0=_8af<0?-1:1,_8b1=dojo.indexOf(this._findHeaderCells(),this._colHeadNode);
if(_8b1>=0&&(evt.shiftKey&&evt.ctrlKey)){
this.colSizeAdjust(evt,_8b1,_8b0*5);
return;
}
this.move(_8ae,_8af);
},_onHeaderKeyDown:function(e,_8b2){
if(_8b2){
var dk=dojo.keys;
switch(e.keyCode){
case dk.ENTER:
case dk.SPACE:
var _8b3=this.getHeaderIndex();
if(_8b3>=0&&!this.grid.pluginMgr.isFixedCell(e.cell)){
this.grid.setSortIndex(_8b3,null,e);
dojo.stopEvent(e);
}
break;
}
}
return true;
},_setActiveColHeader:function(){
this.inherited(arguments);
dijit.focus(this._colHeadNode);
},findAndFocusGridCell:function(){
this._focusContent();
},_focusContent:function(evt,step){
var _8b4=true;
var _8b5=(this.grid.rowCount===0);
if(this.isNoFocusCell()&&!_8b5){
for(var i=0,cell=this.grid.getCell(0);cell&&cell.hidden;cell=this.grid.getCell(++i)){
}
this.setFocusIndex(0,cell?i:0);
}else{
if(this.cell&&!_8b5){
if(this.focusView&&!this.focusView.rowNodes[this.rowIndex]){
this.grid.scrollToRow(this.rowIndex);
this.focusGrid();
}else{
this.setFocusIndex(this.rowIndex,this.cell.index);
}
}else{
_8b4=false;
}
}
if(_8b4){
this._stopEvent(evt);
}
return _8b4;
},_blurContent:function(evt,step){
this._focusifyCellNode(false);
return true;
},_navContent:function(_8b6,_8b7,evt){
if((this.rowIndex===0&&_8b6<0)||(this.rowIndex===this.grid.rowCount-1&&_8b6>0)){
return;
}
this._colHeadNode=null;
this.move(_8b6,_8b7,evt);
if(evt){
dojo.stopEvent(evt);
}
},_onContentKeyDown:function(e,_8b8){
if(_8b8){
var dk=dojo.keys,s=this.grid.scroller;
switch(e.keyCode){
case dk.ENTER:
case dk.SPACE:
var g=this.grid;
if(g.indirectSelection){
break;
}
g.selection.clickSelect(this.rowIndex,dojo.isCopyKey(e),e.shiftKey);
g.onRowClick(e);
dojo.stopEvent(e);
break;
case dk.PAGE_UP:
if(this.rowIndex!==0){
if(this.rowIndex!=s.firstVisibleRow+1){
this._navContent(s.firstVisibleRow-this.rowIndex,0);
}else{
this.grid.setScrollTop(s.findScrollTop(this.rowIndex-1));
this._navContent(s.firstVisibleRow-s.lastVisibleRow+1,0);
}
dojo.stopEvent(e);
}
break;
case dk.PAGE_DOWN:
if(this.rowIndex+1!=this.grid.rowCount){
dojo.stopEvent(e);
if(this.rowIndex!=s.lastVisibleRow-1){
this._navContent(s.lastVisibleRow-this.rowIndex-1,0);
}else{
this.grid.setScrollTop(s.findScrollTop(this.rowIndex+1));
this._navContent(s.lastVisibleRow-s.firstVisibleRow-1,0);
}
dojo.stopEvent(e);
}
break;
}
}
return true;
},_blurFromEditableCell:false,_isNavigating:false,_navElems:null,_focusEditableCell:function(evt,step){
var _8b9=false;
if(this._isNavigating){
_8b9=true;
}else{
if(this.grid.edit.isEditing()&&this.cell){
if(this._blurFromEditableCell||!this._blurEditableCell(evt,step)){
this.setFocusIndex(this.rowIndex,this.cell.index);
_8b9=true;
}
this._stopEvent(evt);
}
}
return _8b9;
},_applyEditableCell:function(){
try{
this.grid.edit.apply();
}
catch(e){
console.warn("_FocusManager._applyEditableCell() error:",e);
}
},_blurEditableCell:function(evt,step){
this._blurFromEditableCell=false;
if(this._isNavigating){
var _8ba=true;
if(evt){
var _8bb=this._navElems;
var _8bc=_8bb.lowest||_8bb.first;
var _8bd=_8bb.last||_8bb.highest||_8bc;
var _8be=dojo.isIE?evt.srcElement:evt.target;
_8ba=_8be==(step>0?_8bd:_8bc);
}
if(_8ba){
this._isNavigating=false;
dojo.setSelectable(this.cell.getNode(this.rowIndex),false);
return "content";
}
return false;
}else{
if(this.grid.edit.isEditing()&&this.cell){
if(!step||typeof step!="number"){
return false;
}
var dir=step>0?1:-1;
var cc=this.grid.layout.cellCount;
for(var cell,col=this.cell.index+dir;col>=0&&col<cc;col+=dir){
cell=this.grid.getCell(col);
if(cell.editable){
this.cell=cell;
this._blurFromEditableCell=true;
return false;
}
}
if((this.rowIndex>0||dir==1)&&(this.rowIndex<this.grid.rowCount||dir==-1)){
this.rowIndex+=dir;
for(col=dir>0?0:cc-1;col>=0&&col<cc;col+=dir){
cell=this.grid.getCell(col);
if(cell.editable){
this.cell=cell;
break;
}
}
this._applyEditableCell();
return "content";
}
}
}
return true;
},_initNavigatableElems:function(){
this._navElems=dijit._getTabNavigable(this.cell.getNode(this.rowIndex));
},_onEditableCellKeyDown:function(e,_8bf){
var dk=dojo.keys,g=this.grid,edit=g.edit,_8c0=false,_8c1=true;
switch(e.keyCode){
case dk.ENTER:
if(_8bf&&edit.isEditing()){
this._applyEditableCell();
_8c0=true;
dojo.stopEvent(e);
}
case dk.SPACE:
if(!_8bf&&this._isNavigating){
_8c1=false;
break;
}
if(_8bf){
if(!this.cell.editable&&this.cell.navigatable){
this._initNavigatableElems();
var _8c2=this._navElems.lowest||this._navElems.first;
if(_8c2){
this._isNavigating=true;
dojo.setSelectable(this.cell.getNode(this.rowIndex),true);
dijit.focus(_8c2);
dojo.stopEvent(e);
this.currentArea("editableCell",true);
break;
}
}
if(!_8c0&&!edit.isEditing()&&!g.pluginMgr.isFixedCell(this.cell)){
edit.setEditCell(this.cell,this.rowIndex);
}
if(_8c0){
this.currentArea("content",true);
}else{
if(this.cell.editable&&g.canEdit()){
this.currentArea("editableCell",true);
}
}
}
break;
case dk.PAGE_UP:
case dk.PAGE_DOWN:
if(!_8bf&&edit.isEditing()){
_8c1=false;
}
break;
case dk.ESCAPE:
if(!_8bf){
edit.cancel();
this.currentArea("content",true);
}
}
return _8c1;
},_onEditableCellMouseEvent:function(evt){
if(evt.type=="click"){
var cell=this.cell||evt.cell;
if(cell&&!cell.editable&&cell.navigatable){
this._initNavigatableElems();
if(this._navElems.lowest||this._navElems.first){
var _8c3=dojo.isIE?evt.srcElement:evt.target;
if(_8c3!=cell.getNode(evt.rowIndex)){
this._isNavigating=true;
this.focusArea("editableCell",evt);
dojo.setSelectable(cell.getNode(evt.rowIndex),true);
dijit.focus(_8c3);
return false;
}
}
}else{
if(this.grid.singleClickEdit){
this.currentArea("editableCell");
return false;
}
}
}
return true;
}});
}
if(!dojo._hasResource["dojox.grid.enhanced._PluginManager"]){
dojo._hasResource["dojox.grid.enhanced._PluginManager"]=true;
dojo.provide("dojox.grid.enhanced._PluginManager");
dojo.declare("dojox.grid.enhanced._PluginManager",null,{_options:null,_plugins:null,_connects:null,constructor:function(_8c4){
this.grid=_8c4;
this._store=_8c4.store;
this._options={};
this._plugins=[];
this._connects=[];
this._parseProps(this.grid.plugins);
_8c4.connect(_8c4,"_setStore",dojo.hitch(this,function(_8c5){
if(this._store!==_8c5){
this.forEach("onSetStore",[_8c5,this._store]);
this._store=_8c5;
}
}));
},startup:function(){
this.forEach("onStartUp");
},preInit:function(){
this.grid.focus.destroy();
this.grid.focus=new dojox.grid.enhanced._FocusManager(this.grid);
new dojox.grid.enhanced._Events(this.grid);
this._init(true);
this.forEach("onPreInit");
},postInit:function(){
this._init(false);
dojo.forEach(this.grid.views.views,this._initView,this);
this._connects.push(dojo.connect(this.grid.views,"addView",dojo.hitch(this,this._initView)));
if(this._plugins.length>0){
var edit=this.grid.edit;
if(edit){
edit.styleRow=function(_8c6){
};
}
}
this.forEach("onPostInit");
},forEach:function(func,args){
dojo.forEach(this._plugins,function(p){
if(!p||!p[func]){
return;
}
p[func].apply(p,args?args:[]);
});
},_parseProps:function(_8c7){
if(!_8c7){
return;
}
var p,_8c8={},_8c9=this._options,grid=this.grid;
var _8ca=dojox.grid.enhanced._PluginManager.registry;
for(p in _8c7){
if(_8c7[p]){
this._normalize(p,_8c7,_8ca,_8c8);
}
}
if(_8c9.dnd||_8c9.indirectSelection){
_8c9.columnReordering=false;
}
dojo.mixin(grid,_8c9);
},_normalize:function(p,_8cb,_8cc,_8cd){
if(!_8cc[p]){
throw new Error("Plugin "+p+" is required.");
}
if(_8cd[p]){
throw new Error("Recursive cycle dependency is not supported.");
}
var _8ce=this._options;
if(_8ce[p]){
return _8ce[p];
}
_8cd[p]=true;
_8ce[p]=dojo.mixin({},_8cc[p],dojo.isObject(_8cb[p])?_8cb[p]:{});
var _8cf=_8ce[p]["dependency"];
if(_8cf){
if(!dojo.isArray(_8cf)){
_8cf=_8ce[p]["dependency"]=[_8cf];
}
dojo.forEach(_8cf,function(_8d0){
if(!this._normalize(_8d0,_8cb,_8cc,_8cd)){
throw new Error("Plugin "+_8d0+" is required.");
}
},this);
}
delete _8cd[p];
return _8ce[p];
},_init:function(pre){
var p,_8d1,_8d2=this._options;
for(p in _8d2){
_8d1=_8d2[p]["preInit"];
if((pre?_8d1:!_8d1)&&_8d2[p]["class"]&&!this.pluginExisted(p)){
this.loadPlugin(p);
}
}
},loadPlugin:function(name){
var _8d3=this._options[name];
if(!_8d3){
return null;
}
var _8d4=this.getPlugin(name);
if(_8d4){
return _8d4;
}
var _8d5=_8d3["dependency"];
dojo.forEach(_8d5,function(_8d6){
if(!this.loadPlugin(_8d6)){
throw new Error("Plugin "+_8d6+" is required.");
}
},this);
var cls=_8d3["class"];
delete _8d3["class"];
_8d4=new this.getPluginClazz(cls)(this.grid,_8d3);
this._plugins.push(_8d4);
return _8d4;
},_initView:function(view){
if(!view){
return;
}
dojox.grid.util.funnelEvents(view.contentNode,view,"doContentEvent",["mouseup","mousemove"]);
dojox.grid.util.funnelEvents(view.headerNode,view,"doHeaderEvent",["mouseup"]);
},pluginExisted:function(name){
return !!this.getPlugin(name);
},getPlugin:function(name){
var _8d7=this._plugins;
name=name.toLowerCase();
for(var i=0,len=_8d7.length;i<len;i++){
if(name==_8d7[i]["name"].toLowerCase()){
return _8d7[i];
}
}
return null;
},getPluginClazz:function(_8d8){
if(dojo.isFunction(_8d8)){
return _8d8;
}
var _8d9="Please make sure Plugin \""+_8d8+"\" is existed.";
try{
var cls=dojo.getObject(_8d8);
if(!cls){
throw new Error(_8d9);
}
return cls;
}
catch(e){
throw new Error(_8d9);
}
},isFixedCell:function(cell){
return cell&&(cell.isRowSelector||cell.fixedPos);
},destroy:function(){
dojo.forEach(this._connects,dojo.disconnect);
this.forEach("destroy");
if(this.grid.unwrap){
this.grid.unwrap();
}
delete this._connects;
delete this._plugins;
delete this._options;
}});
dojox.grid.enhanced._PluginManager.registerPlugin=function(_8da,_8db){
if(!_8da){
console.warn("Failed to register plugin, class missed!");
return;
}
var cls=dojox.grid.enhanced._PluginManager;
cls.registry=cls.registry||{};
cls.registry[_8da.prototype.name]=dojo.mixin({"class":_8da},(_8db?_8db:{}));
};
}
if(!dojo._hasResource["dojox.grid.EnhancedGrid"]){
dojo._hasResource["dojox.grid.EnhancedGrid"]=true;
dojo.provide("dojox.grid.EnhancedGrid");
dojo.experimental("dojox.grid.EnhancedGrid");
dojo.declare("dojox.grid.EnhancedGrid",dojox.grid.DataGrid,{plugins:null,pluginMgr:null,_pluginMgrClass:dojox.grid.enhanced._PluginManager,postMixInProperties:function(){
this._nls=dojo.i18n.getLocalization("dojox.grid.enhanced","EnhancedGrid",this.lang);
this.inherited(arguments);
},postCreate:function(){
this.pluginMgr=new this._pluginMgrClass(this);
this.pluginMgr.preInit();
this.inherited(arguments);
this.pluginMgr.postInit();
},plugin:function(name){
return this.pluginMgr.getPlugin(name);
},startup:function(){
this.inherited(arguments);
this.pluginMgr.startup();
},createSelection:function(){
this.selection=new dojox.grid.enhanced.DataSelection(this);
},canSort:function(_8dc,_8dd){
return true;
},doKeyEvent:function(e){
try{
var view=this.focus.focusView;
view.content.decorateEvent(e);
if(!e.cell){
view.header.decorateEvent(e);
}
}
catch(e){
}
this.inherited(arguments);
},doApplyCellEdit:function(_8de,_8df,_8e0){
if(!_8e0){
this.invalidated[_8df]=true;
return;
}
this.inherited(arguments);
},mixin:function(_8e1,_8e2){
var _8e3={};
for(var p in _8e2){
if(p=="_inherited"||p=="declaredClass"||p=="constructor"||_8e2["privates"]&&_8e2["privates"][p]){
continue;
}
_8e3[p]=_8e2[p];
}
dojo.mixin(_8e1,_8e3);
},_copyAttr:function(idx,attr){
if(!attr){
return;
}
return this.inherited(arguments);
},_getHeaderHeight:function(){
this.inherited(arguments);
return dojo.marginBox(this.viewsHeaderNode).h;
},_fetch:function(_8e4,_8e5){
if(this.items){
return this.inherited(arguments);
}
_8e4=_8e4||0;
if(this.store&&!this._pending_requests[_8e4]){
if(!this._isLoaded&&!this._isLoading){
this._isLoading=true;
this.showMessage(this.loadingMessage);
}
this._pending_requests[_8e4]=true;
try{
var req={start:_8e4,count:this.rowsPerPage,query:this.query,sort:this.getSortProps(),queryOptions:this.queryOptions,isRender:_8e5,onBegin:dojo.hitch(this,"_onFetchBegin"),onComplete:dojo.hitch(this,"_onFetchComplete"),onError:dojo.hitch(this,"_onFetchError")};
this._storeLayerFetch(req);
}
catch(e){
this._onFetchError(e,{start:_8e4,count:this.rowsPerPage});
}
}
return 0;
},_storeLayerFetch:function(req){
this.store.fetch(req);
},getCellByField:function(_8e6){
return dojo.filter(this.layout.cells,function(cell){
return cell.field==_8e6;
})[0];
},onMouseUp:function(e){
},createView:function(){
var view=this.inherited(arguments);
if(dojo.isMoz){
var _8e7=function(_8e8,_8e9){
for(var n=_8e8;n&&_8e9(n);n=n.parentNode){
}
return n;
};
var _8ea=function(_8eb){
var name=_8eb.toUpperCase();
return function(node){
return node.tagName!=name;
};
};
var func=view.header.getCellX;
view.header.getCellX=function(e){
var x=func.call(view.header,e);
var n=_8e7(e.target,_8ea("th"));
if(n&&n!==e.target&&dojo.isDescendant(e.target,n)){
x+=n.firstChild.offsetLeft;
}
return x;
};
}
return view;
},destroy:function(){
delete this._nls;
this.pluginMgr.destroy();
this.inherited(arguments);
}});
dojo.provide("dojox.grid.enhanced.DataSelection");
dojo.declare("dojox.grid.enhanced.DataSelection",dojox.grid.DataSelection,{constructor:function(grid){
if(grid.keepSelection){
if(this.preserver){
this.preserver.destroy();
}
this.preserver=new dojox.grid.enhanced.plugins._SelectionPreserver(this);
}
},_range:function(_8ec,inTo){
this.grid._selectingRange=true;
this.inherited(arguments);
this.grid._selectingRange=false;
this.onChanged();
},deselectAll:function(_8ed){
this.grid._selectingRange=true;
this.inherited(arguments);
this.grid._selectingRange=false;
this.onChanged();
}});
dojox.grid.EnhancedGrid.markupFactory=function(_8ee,node,ctor,_8ef){
return dojox.grid._Grid.markupFactory(_8ee,node,ctor,dojo.partial(dojox.grid.DataGrid.cell_markupFactory,_8ef));
};
dojox.grid.EnhancedGrid.registerPlugin=function(_8f0,_8f1){
dojox.grid.enhanced._PluginManager.registerPlugin(_8f0,_8f1);
};
}
if(!dojo._hasResource["dojox.grid.enhanced._Plugin"]){
dojo._hasResource["dojox.grid.enhanced._Plugin"]=true;
dojo.provide("dojox.grid.enhanced._Plugin");
dojo.declare("dojox.grid.enhanced._Plugin",null,{name:"plugin",grid:null,option:{},_connects:[],_subscribes:[],privates:{},constructor:function(_8f2,_8f3){
this.grid=_8f2;
this.option=_8f3;
this._connects=[];
this._subscribes=[];
this.privates=dojo.mixin({},dojox.grid.enhanced._Plugin.prototype);
this.init();
},init:function(){
},onPreInit:function(){
},onPostInit:function(){
},onStartUp:function(){
},connect:function(obj,_8f4,_8f5){
var conn=dojo.connect(obj,_8f4,this,_8f5);
this._connects.push(conn);
return conn;
},disconnect:function(_8f6){
dojo.some(this._connects,function(conn,i,_8f7){
if(conn==_8f6){
dojo.disconnect(_8f6);
_8f7.splice(i,1);
return true;
}
return false;
});
},subscribe:function(_8f8,_8f9){
var _8fa=dojo.subscribe(_8f8,this,_8f9);
this._subscribes.push(_8fa);
return _8fa;
},unsubscribe:function(_8fb){
dojo.some(this._subscribes,function(_8fc,i,_8fd){
if(_8fc==_8fb){
dojo.unsubscribe(_8fb);
_8fd.splice(i,1);
return true;
}
return false;
});
},onSetStore:function(_8fe){
},destroy:function(){
dojo.forEach(this._connects,dojo.disconnect);
dojo.forEach(this._subscribes,dojo.unsubscribe);
delete this._connects;
delete this._subscribes;
delete this.option;
delete this.privates;
}});
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.NestedSorting"]){
dojo._hasResource["dojox.grid.enhanced.plugins.NestedSorting"]=true;
dojo.provide("dojox.grid.enhanced.plugins.NestedSorting");
dojo.declare("dojox.grid.enhanced.plugins.NestedSorting",dojox.grid.enhanced._Plugin,{name:"nestedSorting",_currMainSort:"none",_currRegionIdx:-1,_a11yText:{"dojoxGridDescending":"&#9662;","dojoxGridAscending":"&#9652;","dojoxGridAscendingTip":"&#1784;","dojoxGridDescendingTip":"&#1783;","dojoxGridUnsortedTip":"x"},constructor:function(){
this._sortDef=[];
this._sortData={};
this._headerNodes={};
this._excludedColIdx=[];
this.nls=this.grid._nls;
this.grid.setSortInfo=function(){
};
this.grid.setSortIndex=dojo.hitch(this,"_setGridSortIndex");
this.grid.getSortIndex=function(){
};
this.grid.getSortProps=dojo.hitch(this,"getSortProps");
if(this.grid.sortFields){
this._setGridSortIndex(this.grid.sortFields,null,true);
}
this.connect(this.grid.views,"render","_initSort");
this.initCookieHandler();
dojo.subscribe("dojox/grid/rearrange/move/"+this.grid.id,dojo.hitch(this,"_onColumnDnD"));
},onStartUp:function(){
this.inherited(arguments);
this.connect(this.grid,"onHeaderCellClick","_onHeaderCellClick");
this.connect(this.grid,"onHeaderCellMouseOver","_onHeaderCellMouseOver");
this.connect(this.grid,"onHeaderCellMouseOut","_onHeaderCellMouseOut");
},_onColumnDnD:function(type,_8ff){
if(type!=="col"){
return;
}
var m=_8ff,obj={},d=this._sortData,p;
var cr=this._getCurrentRegion();
this._blurRegion(cr);
var idx=dojo.attr(this._getRegionHeader(cr),"idx");
for(p in m){
if(d[p]){
obj[m[p]]=d[p];
delete d[p];
}
if(p===idx){
idx=m[p];
}
}
for(p in obj){
d[p]=obj[p];
}
var c=this._headerNodes[idx];
this._currRegionIdx=dojo.indexOf(this._getRegions(),c.firstChild);
this._initSort(false);
},_setGridSortIndex:function(_900,_901,_902){
if(dojo.isArray(_900)){
var i,d,cell;
for(i=0;i<_900.length;i++){
d=_900[i];
cell=this.grid.getCellByField(d.attribute);
if(!cell){
console.warn("Invalid sorting option, column ",d.attribute," not found.");
return;
}
if(cell["nosort"]||!this.grid.canSort(cell.index,cell.field)){
console.warn("Invalid sorting option, column ",d.attribute," is unsortable.");
return;
}
}
this.clearSort();
dojo.forEach(_900,function(d,i){
cell=this.grid.getCellByField(d.attribute);
this.setSortData(cell.index,"index",i);
this.setSortData(cell.index,"order",d.descending?"desc":"asc");
},this);
}else{
if(!isNaN(_900)){
if(_901===undefined){
return;
}
this.setSortData(_900,"order",_901?"asc":"desc");
}else{
return;
}
}
this._updateSortDef();
if(!_902){
this.grid.sort();
}
},getSortProps:function(){
return this._sortDef.length?this._sortDef:null;
},_initSort:function(_903){
var g=this.grid,n=g.domNode,len=this._sortDef.length;
dojo.toggleClass(n,"dojoxGridSorted",!!len);
dojo.toggleClass(n,"dojoxGridSingleSorted",len===1);
dojo.toggleClass(n,"dojoxGridNestSorted",len>1);
if(len>0){
this._currMainSort=this._sortDef[0].descending?"desc":"asc";
}
var idx,_904=this._excludedCoIdx=[];
this._headerNodes=dojo.query("th",g.viewsHeaderNode).forEach(function(n){
idx=parseInt(dojo.attr(n,"idx"),10);
if(dojo.style(n,"display")==="none"||g.layout.cells[idx]["nosort"]||(g.canSort&&!g.canSort(idx,g.layout.cells[idx]["field"]))){
_904.push(idx);
}
});
this._headerNodes.forEach(this._initHeaderNode,this);
this._initFocus();
if(_903){
this._focusHeader();
}
},_initHeaderNode:function(node){
dojo.toggleClass(node,"dojoxGridSortNoWrap",true);
var _905=dojo.query(".dojoxGridSortNode",node)[0];
if(_905){
dojo.toggleClass(_905,"dojoxGridSortNoWrap",true);
}
if(dojo.indexOf(this._excludedCoIdx,dojo.attr(node,"idx"))>=0){
dojo.addClass(node,"dojoxGridNoSort");
return;
}
if(!dojo.query(".dojoxGridSortBtn",node).length){
this._connects=dojo.filter(this._connects,function(conn){
if(conn._sort){
dojo.disconnect(conn);
return false;
}
return true;
});
var n=dojo.create("a",{className:"dojoxGridSortBtn dojoxGridSortBtnNested",title:dojo.string.substitute(this.nls.sortingState,[this.nls.nestedSort,this.nls.ascending]),innerHTML:"1"},node.firstChild,"last");
n.onmousedown=dojo.stopEvent;
n=dojo.create("a",{className:"dojoxGridSortBtn dojoxGridSortBtnSingle",title:dojo.string.substitute(this.nls.sortingState,[this.nls.singleSort,this.nls.ascending])},node.firstChild,"last");
n.onmousedown=dojo.stopEvent;
}else{
var a1=dojo.query(".dojoxGridSortBtnSingle",node)[0];
var a2=dojo.query(".dojoxGridSortBtnNested",node)[0];
a1.className="dojoxGridSortBtn dojoxGridSortBtnSingle";
a2.className="dojoxGridSortBtn dojoxGridSortBtnNested";
a2.innerHTML="1";
dojo.removeClass(node,"dojoxGridCellShowIndex");
dojo.removeClass(node.firstChild,"dojoxGridSortNodeSorted");
dojo.removeClass(node.firstChild,"dojoxGridSortNodeAsc");
dojo.removeClass(node.firstChild,"dojoxGridSortNodeDesc");
dojo.removeClass(node.firstChild,"dojoxGridSortNodeMain");
dojo.removeClass(node.firstChild,"dojoxGridSortNodeSub");
}
this._updateHeaderNodeUI(node);
},_onHeaderCellClick:function(e){
this._focusRegion(e.target);
if(dojo.hasClass(e.target,"dojoxGridSortBtn")){
this._onSortBtnClick(e);
dojo.stopEvent(e);
this._focusRegion(this._getCurrentRegion());
}
},_onHeaderCellMouseOver:function(e){
if(!e.cell){
return;
}
if(this._sortDef.length>1){
return;
}
if(this._sortData[e.cellIndex]&&this._sortData[e.cellIndex].index===0){
return;
}
var p;
for(p in this._sortData){
if(this._sortData[p]&&this._sortData[p].index===0){
dojo.addClass(this._headerNodes[p],"dojoxGridCellShowIndex");
break;
}
}
if(!dojo.hasClass(dojo.body(),"dijit_a11y")){
return;
}
var i=e.cell.index,node=e.cellNode;
var _906=dojo.query(".dojoxGridSortBtnSingle",node)[0];
var _907=dojo.query(".dojoxGridSortBtnNested",node)[0];
var _908="none";
if(dojo.hasClass(this.grid.domNode,"dojoxGridSingleSorted")){
_908="single";
}else{
if(dojo.hasClass(this.grid.domNode,"dojoxGridNestSorted")){
_908="nested";
}
}
var _909=dojo.attr(_907,"orderIndex");
if(_909===null||_909===undefined){
dojo.attr(_907,"orderIndex",_907.innerHTML);
_909=_907.innerHTML;
}
if(this.isAsc(i)){
_907.innerHTML=_909+this._a11yText.dojoxGridDescending;
}else{
if(this.isDesc(i)){
_907.innerHTML=_909+this._a11yText.dojoxGridUnsortedTip;
}else{
_907.innerHTML=_909+this._a11yText.dojoxGridAscending;
}
}
if(this._currMainSort==="none"){
_906.innerHTML=this._a11yText.dojoxGridAscending;
}else{
if(this._currMainSort==="asc"){
_906.innerHTML=this._a11yText.dojoxGridDescending;
}else{
if(this._currMainSort==="desc"){
_906.innerHTML=this._a11yText.dojoxGridUnsortedTip;
}
}
}
this._updateA11y(node);
},_onHeaderCellMouseOut:function(e){
var p;
for(p in this._sortData){
if(this._sortData[p]&&this._sortData[p].index===0){
dojo.removeClass(this._headerNodes[p],"dojoxGridCellShowIndex");
break;
}
}
if(e.cellNode){
this._updateA11y(e.cellNode);
}
},_onSortBtnClick:function(e){
var _90a=e.cell.index;
if(dojo.hasClass(e.target,"dojoxGridSortBtnSingle")){
this._prepareSingleSort(_90a);
}else{
if(dojo.hasClass(e.target,"dojoxGridSortBtnNested")){
this._prepareNestedSort(_90a);
}else{
return;
}
}
dojo.stopEvent(e);
this._doSort(_90a);
},_doSort:function(_90b){
if(!this._sortData[_90b]||!this._sortData[_90b].order){
this.setSortData(_90b,"order","asc");
}else{
if(this.isAsc(_90b)){
this.setSortData(_90b,"order","desc");
}else{
if(this.isDesc(_90b)){
this.removeSortData(_90b);
}
}
}
this._updateSortDef();
this.grid.sort();
this._initSort(true);
},setSortData:function(_90c,attr,_90d){
var sd=this._sortData[_90c];
if(!sd){
sd=this._sortData[_90c]={};
}
sd[attr]=_90d;
},removeSortData:function(_90e){
var d=this._sortData,i=d[_90e].index,p;
delete d[_90e];
for(p in d){
if(d[p].index>i){
d[p].index--;
}
}
},_prepareSingleSort:function(_90f){
var d=this._sortData,p;
for(p in d){
delete d[p];
}
this.setSortData(_90f,"index",0);
this.setSortData(_90f,"order",this._currMainSort==="none"?null:this._currMainSort);
if(!this._sortData[_90f]||!this._sortData[_90f].order){
this._currMainSort="asc";
}else{
if(this.isAsc(_90f)){
this._currMainSort="desc";
}else{
if(this.isDesc(_90f)){
this._currMainSort="none";
}
}
}
},_prepareNestedSort:function(_910){
var i=this._sortData[_910]?this._sortData[_910].index:null;
if(i===0||!!i){
return;
}
this.setSortData(_910,"index",this._sortDef.length);
},_updateSortDef:function(){
this._sortDef.length=0;
var d=this._sortData,p;
for(p in d){
this._sortDef[d[p].index]={attribute:this.grid.layout.cells[p].field,descending:d[p].order==="desc"};
}
},_updateHeaderNodeUI:function(node){
var cell=this._getCellByNode(node);
var _911=cell.index;
var data=this._sortData[_911];
var _912=dojo.query(".dojoxGridSortNode",node)[0];
var _913=dojo.query(".dojoxGridSortBtnSingle",node)[0];
var _914=dojo.query(".dojoxGridSortBtnNested",node)[0];
dojo.toggleClass(_913,"dojoxGridSortBtnAsc",this._currMainSort==="asc");
dojo.toggleClass(_913,"dojoxGridSortBtnDesc",this._currMainSort==="desc");
if(this._currMainSort==="asc"){
_913.title=dojo.string.substitute(this.nls.sortingState,[this.nls.singleSort,this.nls.descending]);
}else{
if(this._currMainSort==="desc"){
_913.title=dojo.string.substitute(this.nls.sortingState,[this.nls.singleSort,this.nls.unsorted]);
}else{
_913.title=dojo.string.substitute(this.nls.sortingState,[this.nls.singleSort,this.nls.ascending]);
}
}
var _915=this;
function _916(){
var _917="Column "+(cell.index+1)+" "+cell.field;
var _918="none";
var _919="ascending";
if(data){
_918=data.order==="asc"?"ascending":"descending";
_919=data.order==="asc"?"descending":"none";
}
var _91a=_917+" - is sorted by "+_918;
var _91b=_917+" - is nested sorted by "+_918;
var _91c=_917+" - choose to sort by "+_919;
var _91d=_917+" - choose to nested sort by "+_919;
_913.setAttribute("aria-label",_91a);
_914.setAttribute("aria-label",_91b);
var _91e=[_915.connect(_913,"onmouseover",function(){
_913.setAttribute("aria-label",_91c);
}),_915.connect(_913,"onmouseout",function(){
_913.setAttribute("aria-label",_91a);
}),_915.connect(_914,"onmouseover",function(){
_914.setAttribute("aria-label",_91d);
}),_915.connect(_914,"onmouseout",function(){
_914.setAttribute("aria-label",_91b);
})];
dojo.forEach(_91e,function(_91f){
_91f._sort=true;
});
};
_916();
var a11y=dojo.hasClass(dojo.body(),"dijit_a11y");
if(!data){
_914.innerHTML=this._sortDef.length+1;
_914.title=dojo.string.substitute(this.nls.sortingState,[this.nls.nestedSort,this.nls.ascending]);
}else{
if(data.index||(data.index===0&&this._sortDef.length>1)){
_914.innerHTML=data.index+1;
}
dojo.addClass(_912,"dojoxGridSortNodeSorted");
if(this.isAsc(_911)){
dojo.addClass(_912,"dojoxGridSortNodeAsc");
_914.title=dojo.string.substitute(this.nls.sortingState,[this.nls.nestedSort,this.nls.descending]);
}else{
if(this.isDesc(_911)){
dojo.addClass(_912,"dojoxGridSortNodeDesc");
_914.title=dojo.string.substitute(this.nls.sortingState,[this.nls.nestedSort,this.nls.unsorted]);
}
}
dojo.addClass(_912,(data.index===0?"dojoxGridSortNodeMain":"dojoxGridSortNodeSub"));
}
this._updateA11y(node);
},isAsc:function(_920){
return this._sortData[_920]&&this._sortData[_920].order==="asc";
},isDesc:function(_921){
return this._sortData[_921]&&this._sortData[_921].order==="desc";
},_updateA11y:function(node){
if(!dojo.hasClass(dojo.body(),"dijit_a11y")){
return;
}
var cell=this._getCellByNode(node),_922=cell.index,data=this._sortData[_922];
var nls=this.nls,txt=this._a11yText;
var _923=dojo.query(".dojoxGridSortNode",node)[0];
var _924=dojo.query(".dojoxGridSortBtnSingle",node)[0];
var _925=dojo.query(".dojoxGridSortBtnNested",node)[0];
var _926=dojo.hasClass(node,"dojoxGridCellOver")||dojo.hasClass(node,"dojoxGridCellSortFocus");
var idx=(data?data.index:this._sortDef.length)+1;
var s1,s2;
if(this.isAsc(_922)){
s2=idx+"&nbsp;"+(_926?txt.dojoxGridDescendingTip:txt.dojoxGridAscending);
}else{
if(this.isDesc(_922)){
s2=idx+"&nbsp;"+(_926?txt.dojoxGridUnsortedTip:txt.dojoxGridDescending);
}else{
s2=idx+"&nbsp;"+(_926?txt.dojoxGridAscendingTip:"");
}
}
if(this._currMainSort==="asc"){
s1=_926?txt.dojoxGridDescendingTip:txt.dojoxGridAscending;
}else{
if(this._currMainSort==="desc"){
s1=_926?txt.dojoxGridUnsortedTip:txt.dojoxGridDescending;
}else{
s1=_926?txt.dojoxGridAscendingTip:"";
}
}
_924.innerHTML=s1;
_925.innerHTML=s2;
},_getCellByNode:function(node){
var i;
for(i=0;i<this._headerNodes.length;i++){
if(this._headerNodes[i]===node){
return this.grid.layout.cells[i];
}
}
return null;
},clearSort:function(){
this._sortData={};
this._sortDef.length=0;
},initCookieHandler:function(){
if(this.grid.addCookieHandler){
this.grid.addCookieHandler({name:"sortOrder",onLoad:dojo.hitch(this,"_loadNestedSortingProps"),onSave:dojo.hitch(this,"_saveNestedSortingProps")});
}
},_loadNestedSortingProps:function(_927,grid){
this._setGridSortIndex(_927);
},_saveNestedSortingProps:function(grid){
return this.getSortProps();
},_initFocus:function(){
var f=this.focus=this.grid.focus;
this._focusRegions=this._getRegions();
if(!this._headerArea){
var area=this._headerArea=f.getArea("header");
area.onFocus=f.focusHeader=dojo.hitch(this,"_focusHeader");
area.onBlur=f.blurHeader=f._blurHeader=dojo.hitch(this,"_blurHeader");
area.onMove=dojo.hitch(this,"_onMove");
area.onKeyDown=dojo.hitch(this,"_onKeyDown");
area._regions=[];
area.getRegions=null;
this.connect(this.grid,"onBlur","_blurHeader");
}
},_focusHeader:function(evt){
if(this._currRegionIdx===-1){
this._onMove(0,1,null);
}else{
this._focusRegion(this._getCurrentRegion());
}
try{
dojo.stopEvent(evt);
}
catch(e){
}
return true;
},_blurHeader:function(evt){
this._blurRegion(this._getCurrentRegion());
return true;
},_onMove:function(_928,_929,evt){
var curr=this._currRegionIdx||0,_92a=this._focusRegions;
var _92b=_92a[curr+_929];
if(!_92b){
return;
}else{
if(dojo.style(_92b,"display")==="none"||dojo.style(_92b,"visibility")==="hidden"){
this._onMove(_928,_929+(_929>0?1:-1),evt);
return;
}
}
this._focusRegion(_92b);
var view=this._getRegionView(_92b);
view.scrollboxNode.scrollLeft=view.headerNode.scrollLeft;
},_onKeyDown:function(e,_92c){
if(_92c){
switch(e.keyCode){
case dojo.keys.ENTER:
case dojo.keys.SPACE:
if(dojo.hasClass(e.target,"dojoxGridSortBtnSingle")||dojo.hasClass(e.target,"dojoxGridSortBtnNested")){
this._onSortBtnClick(e);
}
}
}
},_getRegionView:function(_92d){
var _92e=_92d;
while(_92e&&!dojo.hasClass(_92e,"dojoxGridHeader")){
_92e=_92e.parentNode;
}
if(_92e){
return dojo.filter(this.grid.views.views,function(view){
return view.headerNode===_92e;
})[0]||null;
}
return null;
},_getRegions:function(){
var _92f=[],_930=this.grid.layout.cells;
this._headerNodes.forEach(function(n,i){
if(dojo.style(n,"display")==="none"){
return;
}
if(_930[i]["isRowSelector"]){
_92f.push(n);
return;
}
dojo.query(".dojoxGridSortNode,.dojoxGridSortBtnNested,.dojoxGridSortBtnSingle",n).forEach(function(node){
dojo.attr(node,"tabindex",0);
_92f.push(node);
});
},this);
return _92f;
},_focusRegion:function(_931){
if(!_931){
return;
}
var _932=this._getCurrentRegion();
if(_932&&_931!==_932){
this._blurRegion(_932);
}
var _933=this._getRegionHeader(_931);
dojo.addClass(_933,"dojoxGridCellSortFocus");
if(dojo.hasClass(_931,"dojoxGridSortNode")){
dojo.addClass(_931,"dojoxGridSortNodeFocus");
}else{
if(dojo.hasClass(_931,"dojoxGridSortBtn")){
dojo.addClass(_931,"dojoxGridSortBtnFocus");
}
}
_931.focus();
this.focus.currentArea("header");
this._currRegionIdx=dojo.indexOf(this._focusRegions,_931);
},_blurRegion:function(_934){
if(!_934){
return;
}
var _935=this._getRegionHeader(_934);
dojo.removeClass(_935,"dojoxGridCellSortFocus");
if(dojo.hasClass(_934,"dojoxGridSortNode")){
dojo.removeClass(_934,"dojoxGridSortNodeFocus");
}else{
if(dojo.hasClass(_934,"dojoxGridSortBtn")){
dojo.removeClass(_934,"dojoxGridSortBtnFocus");
}
}
_934.blur();
this._updateA11y(_935);
},_getCurrentRegion:function(){
return this._focusRegions?this._focusRegions[this._currRegionIdx]:null;
},_getRegionHeader:function(_936){
while(_936&&!dojo.hasClass(_936,"dojoxGridCell")){
_936=_936.parentNode;
}
return _936;
},destroy:function(){
this._sortDef=this._sortData=null;
this._headerNodes=this._focusRegions=null;
this.inherited(arguments);
}});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.NestedSorting);
}
if(!dojo._hasResource["dojox.collections._base"]){
dojo._hasResource["dojox.collections._base"]=true;
dojo.provide("dojox.collections._base");
dojox.collections.DictionaryEntry=function(k,v){
this.key=k;
this.value=v;
this.valueOf=function(){
return this.value;
};
this.toString=function(){
return String(this.value);
};
};
dojox.collections.Iterator=function(arr){
var a=arr;
var _937=0;
this.element=a[_937]||null;
this.atEnd=function(){
return (_937>=a.length);
};
this.get=function(){
if(this.atEnd()){
return null;
}
this.element=a[_937++];
return this.element;
};
this.map=function(fn,_938){
return dojo.map(a,fn,_938);
};
this.reset=function(){
_937=0;
this.element=a[_937];
};
};
dojox.collections.DictionaryIterator=function(obj){
var a=[];
var _939={};
for(var p in obj){
if(!_939[p]){
a.push(obj[p]);
}
}
var _93a=0;
this.element=a[_93a]||null;
this.atEnd=function(){
return (_93a>=a.length);
};
this.get=function(){
if(this.atEnd()){
return null;
}
this.element=a[_93a++];
return this.element;
};
this.map=function(fn,_93b){
return dojo.map(a,fn,_93b);
};
this.reset=function(){
_93a=0;
this.element=a[_93a];
};
};
}
if(!dojo._hasResource["dojox.collections.ArrayList"]){
dojo._hasResource["dojox.collections.ArrayList"]=true;
dojo.provide("dojox.collections.ArrayList");
dojox.collections.ArrayList=function(arr){
var _93c=[];
if(arr){
_93c=_93c.concat(arr);
}
this.count=_93c.length;
this.add=function(obj){
_93c.push(obj);
this.count=_93c.length;
};
this.addRange=function(a){
if(a.getIterator){
var e=a.getIterator();
while(!e.atEnd()){
this.add(e.get());
}
this.count=_93c.length;
}else{
for(var i=0;i<a.length;i++){
_93c.push(a[i]);
}
this.count=_93c.length;
}
};
this.clear=function(){
_93c.splice(0,_93c.length);
this.count=0;
};
this.clone=function(){
return new dojox.collections.ArrayList(_93c);
};
this.contains=function(obj){
for(var i=0;i<_93c.length;i++){
if(_93c[i]==obj){
return true;
}
}
return false;
};
this.forEach=function(fn,_93d){
dojo.forEach(_93c,fn,_93d);
};
this.getIterator=function(){
return new dojox.collections.Iterator(_93c);
};
this.indexOf=function(obj){
for(var i=0;i<_93c.length;i++){
if(_93c[i]==obj){
return i;
}
}
return -1;
};
this.insert=function(i,obj){
_93c.splice(i,0,obj);
this.count=_93c.length;
};
this.item=function(i){
return _93c[i];
};
this.remove=function(obj){
var i=this.indexOf(obj);
if(i>=0){
_93c.splice(i,1);
}
this.count=_93c.length;
};
this.removeAt=function(i){
_93c.splice(i,1);
this.count=_93c.length;
};
this.reverse=function(){
_93c.reverse();
};
this.sort=function(fn){
if(fn){
_93c.sort(fn);
}else{
_93c.sort();
}
};
this.setByIndex=function(i,obj){
_93c[i]=obj;
this.count=_93c.length;
};
this.toArray=function(){
return [].concat(_93c);
};
this.toString=function(_93e){
return _93c.join((_93e||","));
};
};
}
if(!dojo._hasResource["dojoe.treetable._ConfigureColumnsDialog"]){
dojo._hasResource["dojoe.treetable._ConfigureColumnsDialog"]=true;
dojo.provide("dojoe.treetable._ConfigureColumnsDialog");
dojo.declare("dojoe.treetable._ConfigureColumnsDialog",[dijit._Widget,dijit._Templated],{widgetsInTemplate:true,templateString:dojo.cache("dojoe.treetable","templates/ConfigureColumnsDialog.html","<div>\r\n\t<div dojoType=\"dijit.Dialog\" dojoAttachPoint=\"dialog\"\ttitle=\"${resources_.CONFIGURE_TREETABLE}\" tabindex=0 role=\"dialog\">\r\n\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" role=\"presentation\" style=\"width:100%height:100%\">\r\n\t\t\t<tr height=\"20%\" style=\"vertical-align:top;\"><td><label>${resources_.COLUMNS_VISIBLE}</label></td><tr>\r\n\t\t\t<tr><td>\r\n\t\t\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" role=\"presentation\">\r\n\t\t\t\t\t<tbody>\r\n\t\t\t\t\t\t<tr><td>\r\n\t\t\t\t\t\t\t\t<span dojoAttachPoint=\"selectAllButton\" role=\"button\">\r\n\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t<td>\r\n\t\t\t\t\t\t\t\t<span dojoAttachPoint=\"deselectAllButton\" role=\"button\">\r\n\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t</tbody>\r\n\t\t\t\t</table>\r\n\t\t\t</td></tr>\r\n\t\t\t<tr><td>\r\n\t\t\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\"  role=\"presentation\">\r\n\t\t\t\t\t<tbody>\r\n\t\t\t\t\t\t<tr valign=\"center\">\r\n\t\t\t\t\t\t\t<td width=\"90%\" height=\"100%\">\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t<div id=\"${id}tabs\" dojoType=\"dijit.layout.BorderContainer\" class=\"dialog\" style=\"height:200px;width:260px;\">\r\n\t\t\t\t\t\t\t\t\t<div dojoType=\"dijit.layout.ContentPane\" region=\"top\" >\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t<div  dojoAttachPoint=\"enhancedGridNode\" style=\"height:170px;width:200px;\" role=\"grid\"></div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t<td width=\"10%\" height=\"100%\">\r\n\t\t\t\t\t\t\t\t<table role=\"presentation\">\r\n\t\t\t\t\t\t\t\t\t<tr><td><span dojoAttachPoint=\"upButton\" role=\"button\"></td></tr>  \r\n\t\t\t\t\t\t\t\t\t<tr><td><span dojoAttachPoint=\"downButton\" role=\"button\"></td></tr> \r\n\t\t\t\t\t\t\t\t</table>\r\n\t\t\t\t\t\t</td></tr>\t\r\n\t\t\t\t\t</tbody>\t\t\r\n\t\t\t\t</table>\t\t\t\t\t\t\t\r\n\t\t\t</td></tr>\r\n\t\t\t<tr><td>\r\n\t\t\t\t<button value=\"${resources_.OK}\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:onOK,onKeypress:onOK\" role=\"button\">${resources_.OK}</button>\r\n\t\t\t\t&nbsp;&nbsp;<button value=\"${resources_.CANCEL}\" dojoType=\"dijit.form.Button\" dojoAttachPoint=\"cancelButton\" dojoAttachEvent=\"onClick:onCancel,onKeypress:onCancel\" role=\"button\">${resources_.CANCEL}</button>\r\n\t\t\t</td></tr>\r\n\t\t</table>\r\n\t</div>\r\n</div>\r\n"),optionsWidget_:null,grid:null,indirectSelection:null,enableColumnReorder:null,enhancedGrid:null,columndata:null,constructor:function(){
this.resources_=dojo.i18n.getLocalization("dojoe.treetable","TreeTable",this.lang);
},postCreate:function(){
this.inherited("postCreate",arguments);
var _93f=this.grid.layout.cells;
var _940=new Array();
for(var i=0 in _93f){
var _941=_93f[i];
var size=dojo.trim(_941.name).length;
if(size>0){
if(!_941.isCollapsable){
_940.push(_941);
}
}
}
columndata={identifier:"id",label:"id",items:[]};
var len=_940.length;
for(var i=0;i<_940.length;++i){
var row={id:(i+1),"name":_940[i].name,"hidden":!_940[i].hidden};
columndata.items.push(row);
}
var _942=[{rows:[{field:"hidden",width:"30%",name:this.resources_.VISIBLE,editable:true,cellType:dojox.grid.cells.Bool},{field:"name",width:"70%",name:this.resources_.COLUMNS}]}];
var _943={};
var _944=new dojo.data.ItemFileWriteStore({data:columndata});
var _945={store:_944,structure:_942,plugins:_943,selectionMode:"single",canSort:function(){
return false;
},keepSelection:false};
this.enhancedGrid=new dojox.grid.EnhancedGrid(_945,this.enhancedGridNode);
dojo.connect(this,"resize",this.enhancedGrid,"resize");
var _946=new dijit.form.Button({id:this.id+"selectAllIcon",showLabel:false,iconClass:"selectAllIcon",label:this.resources_.SELECT_ALL},this.selectAllButton);
_946.onClick=dojo.hitch(this,"onSelectAll");
_946.onKeypress=dojo.hitch(this,"onSelectAll");
var _947=new dijit.form.Button({id:this.id+"deselectAllIcon",showLabel:false,iconClass:"deselectAllIcon",label:this.resources_.DESELECT_ALL},this.deselectAllButton);
_947.onClick=dojo.hitch(this,"onDeselectAll");
_947.onKeypress=dojo.hitch(this,"onDeselectAll");
if(this.enableColumnReorder){
var _948=new dijit.form.Button({id:this.id+"upIcon",showLabel:false,iconClass:"upIcon",label:this.resources_.UP},this.upButton);
_948.onClick=dojo.hitch(this,"onUp");
_948.onKeypress=dojo.hitch(this,"onUp");
var _949=new dijit.form.Button({id:this.id+"downIcon",showLabel:false,iconClass:"downIcon",label:this.resources_.DOWN},this.downButton);
_949.onClick=dojo.hitch(this,"onDown");
_949.onKeypress=dojo.hitch(this,"onDown");
}else{
dojo.style(this.upButton.parentNode,"width","0px");
dojo.style(this.downButton.parentNode,"width","0px");
}
this.connect(this.dialog,"onHide",dojo.hitch(this,this.kill));
},onSelectAll:function(){
var _94a=this.enhancedGrid.rowCount;
for(var i=0;i<_94a;i++){
columndata.items[i].hidden[0]=true;
}
this.enhancedGrid._refresh();
},onDeselectAll:function(){
var _94b=this.enhancedGrid.rowCount;
for(var i=0;i<_94b;i++){
columndata.items[i].hidden[0]=false;
}
this.enhancedGrid._refresh();
},_reorderColumn:function(_94c){
var _94d=this.enhancedGrid.rowCount;
var _94e=this.grid.structure;
var _94f=new Array();
if(this.indirectSelection){
_94f[0]=_94e[0];
_94f[1]=_94e[1];
for(var i=0;i<_94d;i++){
var _950=this.enhancedGrid.getItem(i);
for(var j=0;j<_94d+2;j++){
if(_950.name[0]===_94e[j].name){
_94f[i+2]=_94e[j];
}
}
}
}else{
_94f[0]=_94e[0];
for(var i=0;i<_94d;i++){
var _950=this.enhancedGrid.getItem(i);
for(var j=0;j<_94d+1;j++){
if(_950.name[0]===_94e[j].name){
_94f[i+1]=_94e[j];
}
}
}
}
this.grid.setStructure(_94f);
},onOK:function(){
var _951=this.enhancedGrid.rowCount;
this._reorderColumn();
if(this.indirectSelection){
for(var i=0;i<_951;i++){
if(columndata.items[i].hidden[0]==false){
this.grid.layout.setColumnVisibility(i+2,false);
}else{
this.grid.layout.setColumnVisibility(i+2,true);
}
}
}else{
for(var i=0;i<_951;i++){
if(columndata.items[i].hidden[0]==false){
this.grid.layout.setColumnVisibility(i+1,false);
}else{
this.grid.layout.setColumnVisibility(i+1,true);
}
}
}
this.hide();
},onCancel:function(){
this.hide();
},clearSelection:function(){
this.enhancedGrid.selection.clear();
},onUp:function(){
var _952=this.enhancedGrid.selection.selectedIndex;
if(_952<=0){
return;
}
var _953=new Array();
if(_952-1>=0){
_953=_953.concat(columndata.items.slice(0,_952-1));
}
_953=_953.concat(this.enhancedGrid.selection.getSelected());
if(_952-1>=0){
_953.push(columndata.items[_952-1]);
}
_953=_953.concat(columndata.items.slice(_952+1,columndata.items.length));
this.enhancedGrid.store.close();
columndata.items=_953;
this.enhancedGrid.store=new dojo.data.ItemFileWriteStore({data:columndata});
this.enhancedGrid.selection.clear();
this.enhancedGrid._refresh();
this.enhancedGrid.selection.addToSelection(_952-1);
},onDown:function(){
var _954=this.enhancedGrid.selection.selectedIndex;
if(_954<0){
return;
}
if(_954==columndata.items.length-1){
return;
}
var _955=new Array();
_955=_955.concat(columndata.items.slice(0,_954));
if(columndata.items[_954+1]!=="undefined"){
_955.push(columndata.items[_954+1]);
}
_955=_955.concat(this.enhancedGrid.selection.getSelected());
if(columndata.items[_954+2]!=="undefined"){
_955=_955.concat(columndata.items.slice(_954+2,columndata.items.length));
}
this.enhancedGrid.store.close();
columndata.items=_955;
this.enhancedGrid.store=new dojo.data.ItemFileWriteStore({data:columndata});
this.enhancedGrid.selection.clear();
this.enhancedGrid._refresh();
this.enhancedGrid.selection.addToSelection(_954+1);
},_selectColumns:function(){
var _956=this.enhancedGrid.rowCount;
for(var i=0;i<_956;i++){
var _957=this.enhancedGrid.getItem(i);
if(_957.hidden[0]===false){
this.enhancedGrid.selection.addToSelection(i);
}
}
},show:function(){
this.dialog.show();
this.enhancedGrid.startup();
dijit.byId(this.id+"tabs").resize();
},hide:function(){
this.dialog.hide();
},kill:function(){
setTimeout(dojo.hitch(this,this.destroy),100);
},getTableOptions:function(){
return this.optionsWidget_;
},destroy:function(){
try{
delete this.resources_;
var _958=dijit.byId(this.dialog);
var _959=this.id+"tabs";
var _95a=dijit.byId(_959);
if(_95a){
_95a.destroyRecursive();
}
if(_958){
_958.destroyRecursive();
}
var _95b=dijit.findWidgets(this.domNode);
dojo.forEach(_95b,function(w){
if(w){
if(w.destroyRecursive){
w.destroyRecursive();
}else{
if(w.destroy){
w.destroy();
}
}
}
});
var _95c=this.getChildren();
dojo.forEach(_95c,function(_95d){
if(_95d){
if(_95d.destroyRecursive){
_95d.destroyRecursive();
}else{
if(_95d.destroy){
_95d.destroy();
}
}
}
});
this.inherited(arguments);
}
catch(ex){
console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
}
}});
}
if(!dojo._hasResource["dijit.form.DropDownButton"]){
dojo._hasResource["dijit.form.DropDownButton"]=true;
dojo.provide("dijit.form.DropDownButton");
}
if(!dojo._hasResource["dojoe.treetable._Toolbar"]){
dojo._hasResource["dojoe.treetable._Toolbar"]=true;
dojo.provide("dojoe.treetable._Toolbar");
dojo.declare("dojoe.treetable._Toolbar",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dojoe.treetable","templates/Toolbar.html","<div dojoAttachEvent='oncontextmenu:_stopEvent' class=\"tivTable dijitToolbar\"  width=\"100%\" >\r\n<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" role=\"presentation\">\r\n\t<tbody>\r\n\t\t<tr valign=\"center\">\r\n\t\t\t<td width=\"80%\" height=\"100%\">\r\n\t\t\t\t<span dojoAttachPoint=\"toolbarFirstRow\"><span dojoAttachPoint=\"refreshNode\" role=\"button\"></span><span dojoAttachPoint=\"refSeperator\" role=\"separator\"></span><span dojoAttachPoint=\"toolbarFirstRow_userItems\"></span><span dojoAttachPoint=\"selectAllIcon\" role=\"button\"></span><span dojoAttachPoint=\"deselectAllIcon\" role=\"button\"></span><span dojoAttachPoint=\"expandtAllIcon\" role=\"button\"></span><span dojoAttachPoint=\"collapseAllIcon\" role=\"button\"></span><span dojoAttachPoint=\"removeSortIcon\" role=\"button\"></span><span dojoAttachPoint=\"configureColNode\" role=\"button\"></span><span dojoAttachPoint=\"actionListNode\" role=\"button\"></span></span>\r\n\t\t\t</td>\r\n\t\t\t<td width=\"20%\" height=\"100%\" align=\"right\"><div dojoAttachPoint=\"quickFilterNode\" role=\"search\"></div></td>\r\n\t\t\t<td><div dojoAttachPoint=\"filterNode\" role=\"button\"></div></td>\r\n\t\t</tr>\r\n\t\t<tr valign=\"center\">\r\n\t\t\t<td width=\"100%\">\r\n\t\t\t\t<span dojoAttachPoint=\"toolbarSecondRow\">\r\n\t\t\t\t</span>\t\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t</tbody>\t\t\r\n</table>\r\n</div>\r\n"),widgetsInTemplate:true,treeTable:null,actionListWidget:null,quickFilter:null,filterOptions:null,refreshIcon:true,refreshMenu:true,showSelectAllIcon:true,onlySelectAllIcon:false,onlyDeselectAllIcon:false,expandAllIcon:true,clearSortIcon:true,configureTreeTableIcon:true,actionMenu:true,selectAllMenu:true,expandAllMenu:true,clearSortMenu:true,configureTreeTableMenu:true,toolbarOptions:null,quickFilterVisible:true,showQuickFilterButton:false,_mapToolbarControls:function(){
if(this.toolbarOptions){
if(this.toolbarOptions.refreshIcon==false){
this.refreshIcon=this.toolbarOptions.refreshIcon;
}
if(this.toolbarOptions.refreshMenu==false){
this.refreshMenu=this.toolbarOptions.refreshMenu;
}
if(this.toolbarOptions.selectAllIcon==false){
this.showSelectAllIcon=this.toolbarOptions.selectAllIcon;
}else{
if(this.toolbarOptions.onlySelectAllIcon==true){
this.onlySelectAllIcon=this.toolbarOptions.onlySelectAllIcon;
}
if(this.toolbarOptions.onlyDeselectAllIcon==true){
this.onlyDeselectAllIcon=this.toolbarOptions.onlyDeselectAllIcon;
}
}
if(this.toolbarOptions.selectAllMenu==false){
this.selectAllMenu=this.toolbarOptions.selectAllMenu;
}
if(this.toolbarOptions.expandAllIcon==false){
this.expandAllIcon=this.toolbarOptions.expandAllIcon;
}
if(this.toolbarOptions.expandAllMenu==false){
this.expandAllMenu=this.toolbarOptions.expandAllMenu;
}
if(this.toolbarOptions.clearSortIcon==false){
this.clearSortIcon=this.toolbarOptions.clearSortIcon;
}
if(this.toolbarOptions.clearSortMenu==false){
this.clearSortMenu=this.toolbarOptions.clearSortMenu;
}
if(this.toolbarOptions.configureTreeTableIcon==false){
this.configureTreeTableIcon=this.toolbarOptions.configureTreeTableIcon;
}
if(this.toolbarOptions.configureTreeTableMenu==false){
this.configureTreeTableMenu=this.toolbarOptions.configureTreeTableMenu;
}
if(this.toolbarOptions.actionMenu==false){
this.actionMenu=this.toolbarOptions.actionMenu;
}
if(this.toolbarOptions.quickFilterVisible==false){
this.quickFilterVisible=this.toolbarOptions.quickFilterVisible;
}
if(this.toolbarOptions.quickFilterVisible&&this.toolbarOptions.showQuickFilterButton){
this.showQuickFilterButton=this.toolbarOptions.showQuickFilterButton;
}
}
},constructor:function(){
this.resources_=dojo.i18n.getLocalization("dojoe.treetable","TreeTable",this.lang);
},_refreshTreeTable:function(){
this.treeTable.refresh(true);
},_selectAll:function(){
if(this.treeTable.indirectSelection===true){
this.treeTable._loadIndSelection.selectAllRows();
}else{
var _95e=this.treeTable.grid.rowCount;
for(var i=0;i<_95e;i++){
this.treeTable.grid.selection.addToSelection(i);
}
}
},_deselectAll:function(){
if(this.treeTable.indirectSelection===true){
this.treeTable._loadIndSelection.deSelectAllRows();
}else{
this.treeTable.grid.selection.deselectAll();
}
},_collapseAll:function(){
this.treeTable.grid._cleanup();
this.treeTable.grid._refresh(true);
},_clearSort:function(){
this.treeTable.grid._cleanup();
this.treeTable.grid.setSortInfo(0);
this.treeTable.grid._refresh(true);
},_configureColumn:function(){
this.tableOptionsDialog=new dojoe.treetable._ConfigureColumnsDialog({grid:this.treeTable.grid,indirectSelection:this.treeTable.indirectSelection,enableColumnReorder:this.treeTable.enableColumnReorder});
this.tableOptionsDialog.show();
},postCreate:function(){
if(this.filterOptions&&this.filterOptions.showQuickFilter!==undefined){
this.quickFilterVisible=this.filterOptions.showQuickFilter;
}
if(this.filterOptions&&this.filterOptions.showQuickFilterButton!==undefined){
this.showQuickFilterButton=this.filterOptions.showQuickFilterButton;
}
this.toolbarOptions=this.treeTable.toolbarOptions;
this._mapToolbarControls();
this._createToolBarControls();
},_stopEvent:function(e){
dojo.stopEvent(e);
},_createToolBarControls:function(){
if(this.refreshIcon){
var _95f=new dijit.form.Button({id:this.id+"refreshIcon",showLabel:false,iconClass:"refreshIcon",label:this.resources_.REFRESH},this.refreshNode);
_95f.onClick=dojo.hitch(this,"_refreshTreeTable");
_95f.onKeypress=dojo.hitch(this,"_refreshTreeTable");
var _960=new dijit.ToolbarSeparator({id:this.id+"refSeperator"},this.refSeperator);
}else{
dojo.style(this.refreshNode.parentNode,"width","0px");
dojo.style(this.refSeperator.parentNode,"width","0px");
}
if(this.showSelectAllIcon){
if(this.onlySelectAllIcon){
var _961=new dijit.form.Button({id:this.id+"selectAllIcon",showLabel:false,iconClass:"selectAllIcon",label:this.resources_.SELECT_ALL},this.selectAllIcon);
_961.onClick=dojo.hitch(this,"_selectAll");
_961.onKeypress=dojo.hitch(this,"_selectAll");
dojo.style(this.deselectAllIcon.parentNode,"width","0px");
}else{
if(this.onlyDeselectAllIcon){
var _962=new dijit.form.Button({id:this.id+"deselectAllIcon",showLabel:false,iconClass:"deselectAllIcon",label:this.resources_.DESELECT_ALL},this.deselectAllIcon);
_962.onClick=dojo.hitch(this,"_deselectAll");
_962.onKeypress=dojo.hitch(this,"_deselectAll");
_962.onClick=dojo.hitch(this,"_deselectAll");
}else{
var _961=new dijit.form.Button({id:this.id+"selectAllIcon",showLabel:false,iconClass:"selectAllIcon",label:this.resources_.SELECT_ALL},this.selectAllIcon);
_961.onClick=dojo.hitch(this,"_selectAll");
_961.onKeypress=dojo.hitch(this,"_selectAll");
var _962=new dijit.form.Button({id:this.id+"deselectAllIcon",showLabel:false,iconClass:"deselectAllIcon",label:this.resources_.DESELECT_ALL},this.deselectAllIcon);
_962.onClick=dojo.hitch(this,"_deselectAll");
_962.onKeypress=dojo.hitch(this,"_deselectAll");
}
}
}else{
dojo.style(this.selectAllIcon.parentNode,"width","0px");
dojo.style(this.deselectAllIcon.parentNode,"width","0px");
}
if(this.expandAllIcon){
var _963=new dijit.form.Button({id:this.id+"collapseAllIcon",showLabel:false,iconClass:"collapseAllIcon",label:this.resources_.COLLAPSE_ALL},this.collapseAllIcon);
_963.onClick=dojo.hitch(this,"_collapseAll");
_963.onKeypress=dojo.hitch(this,"_collapseAll");
}else{
dojo.style(this.collapseAllIcon.parentNode,"width","0px");
dojo.style(this.expandtAllIcon.parentNode,"width","0px");
}
if(this.clearSortIcon){
var _964=new dijit.form.Button({id:this.id+"clearSortIcon",showLabel:false,iconClass:"removeSortIcon",label:this.resources_.CLEAR_SORT},this.removeSortIcon);
_964.onClick=dojo.hitch(this,"_clearSort");
_964.onKeypress=dojo.hitch(this,"_clearSort");
}else{
dojo.style(this.removeSortIcon.parentNode,"width","0px");
}
if(this.configureTreeTableIcon){
var _965=new dijit.form.Button({id:this.id+"configureTreeTableIcon",showLabel:false,iconClass:"configureColIcon",label:this.resources_.CONFIGURE_TREETABLE},this.configureColNode);
_965.onClick=dojo.hitch(this,"_configureColumn");
_965.onKeypress=dojo.hitch(this,"_configureColumn");
}else{
dojo.style(this.configureColNode.parentNode,"width","0px");
}
if(this.quickFilterVisible&&this.showQuickFilterButton){
this.quickFilter=new dojoe.treetable._QuickSearchFilter({id:this.id+"quickFilter",grid:this.treeTable.grid,_quickFilterButton:true,filterOptions:this.filterOptions},this.quickFilterNode);
var _966=new dijit.form.Button({showLabel:false,iconClass:"filterIcon",id:"quickFilterIcon"+this.id,label:this.resources_.QUICK_FILTER,title:this.resources_.QUICK_FILTER},this.filterNode);
_966.onClick=dojo.hitch(this,"_setQuickFilter");
_966.onKeypress=dojo.hitch(this,"_setQuickFilter");
_966.domNode.title=this.resources_.QUICK_FILTER;
}else{
if(this.quickFilterVisible&&!this.showQuickFilterButton){
this.quickFilter=new dojoe.treetable._QuickSearchFilter({id:this.id+"quickFilter",grid:this.treeTable.grid,_quickFilterButton:false,filterOptions:this.filterOptions},this.quickFilterNode);
}
}
if(this.actionMenu){
var menu=new dijit.Menu({style:"display: none;"});
if(this.refreshMenu){
var _967=new dijit.MenuItem({title:this.resources_.REFRESH,label:this.resources_.REFRESH,iconClass:"refreshIcon"});
_967.onClick=dojo.hitch(this,"_refreshTreeTable");
_967.onKeypress=dojo.hitch(this,"_refreshTreeTable");
menu.addChild(_967);
}
if(this.selectAllMenu){
var _968=new dijit.MenuItem({title:this.resources_.SELECT_ALL,label:this.resources_.SELECT_ALL,iconClass:"selectAllIcon"});
_968.onClick=dojo.hitch(this,"_selectAll");
_968.onKeypress=dojo.hitch(this,"_selectAll");
menu.addChild(_968);
var _969=new dijit.MenuItem({title:this.resources_.DESELECT_ALL,label:this.resources_.DESELECT_ALL,iconClass:"deselectAllIcon"});
_969.onClick=dojo.hitch(this,"_deselectAll");
_969.onKeypress=dojo.hitch(this,"_deselectAll");
menu.addChild(_969);
}
if(this.expandAllMenu){
var _96a=new dijit.MenuItem({title:this.resources_.COLLAPSE_ALL,label:this.resources_.COLLAPSE_ALL,iconClass:"collapseAllIcon"});
_96a.onClick=dojo.hitch(this,"_collapseAll");
_96a.onKeypress=dojo.hitch(this,"_collapseAll");
menu.addChild(_96a);
}
if(this.clearSortMenu){
var _96b=new dijit.MenuItem({title:this.resources_.CLEAR_SORT,label:this.resources_.CLEAR_SORT,iconClass:"removeSortIcon"});
_96b.onClick=dojo.hitch(this,"_clearSort");
_96b.onKeypress=dojo.hitch(this,"_clearSort");
menu.addChild(_96b);
}
if(this.configureTreeTableMenu){
var _96c=new dijit.MenuItem({title:this.resources_.CONFIGURE_TREETABLE,label:this.resources_.CONFIGURE_TREETABLE,iconClass:"configureColIcon"});
_96c.onClick=dojo.hitch(this,"_configureColumn");
_96c.onKeypress=dojo.hitch(this,"_configureColumn");
menu.addChild(_96c);
}
menu.startup();
var _96d=new dijit.form.DropDownButton({optionsTitle:this.resources_.ACTIONS,label:this.resources_.ACTIONS,dropDown:menu,scrollOnFocus:true},this.actionListNode);
this.actionListWidget=_96d;
}else{
dojo.style(this.actionListNode.parentNode,"width","0px");
}
},_setQuickFilter:function(){
this.quickFilter._setFilter();
},_removeFromActionList:function(_96e){
var _96f=dijit.byId(_96e);
if(_96f!==null&&_96f!==undefined){
_96f.destroyRecursive();
}
},_removeItem:function(_970){
var _971=dijit.byId(_970);
if(_971!==null&&_971!==undefined){
if(_971.domNode.parentNode){
buttonParent=_971.domNode.parentNode;
buttonParent.parentNode.removeChild(buttonParent);
}
_971.destroyRecursive();
}
},_addToToolbarFirstRow:function(item,_972){
var _973=dojo.doc.createElement("span");
if(_972!==undefined){
dojo.place(_973,this.toolbarFirstRow_userItems,parseInt(_972));
}else{
dojo.place(_973,this.toolbarFirstRow_userItems,"last");
}
_973.appendChild(item.domNode);
},_addToToolbarSecondRow:function(item,_974){
var _975=dojo.doc.createElement("span");
dojo.style(_975,"width","1px");
if(_974!==undefined){
dojo.place(_975,this.toolbarSecondRow,parseInt(_974));
}else{
dojo.place(_975,this.toolbarSecondRow,"last");
}
_975.appendChild(item.domNode);
},destroy:function(){
try{
delete this.resources_;
var _976=dijit.findWidgets(this.domNode);
dojo.forEach(_976,function(w){
if(w){
if(w.destroyRecursive){
w.destroyRecursive();
}else{
if(w.destroy){
w.destroy();
}
}
}
});
var _977=this.getChildren();
dojo.forEach(_977,function(_978){
if(_978){
if(_978.destroyRecursive){
_978.destroyRecursive();
}else{
if(_978.destroy){
_978.destroy();
}
}
}
});
this.inherited(arguments);
}
catch(ex){
console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
}
}});
}
if(!dojo._hasResource["dojox.grid._TreeView"]){
dojo._hasResource["dojox.grid._TreeView"]=true;
dojo.provide("dojox.grid._TreeView");
dojo.declare("dojox.grid._Expando",[dijit._Widget,dijit._Templated],{open:false,toggleClass:"",itemId:"",cellIdx:-1,view:null,rowNode:null,rowIdx:-1,expandoCell:null,level:0,templateString:"<div class=\"dojoxGridExpando\"\r\n\t><div class=\"dojoxGridExpandoNode\" dojoAttachEvent=\"onclick:onToggle\"\r\n\t\t><div class=\"dojoxGridExpandoNodeInner\" dojoAttachPoint=\"expandoInner\"></div\r\n\t></div\r\n></div>\r\n",_toggleRows:function(_979,open){
if(!_979||!this.rowNode){
return;
}
if(dojo.query("table.dojoxGridRowTableNeedsRowUpdate").length){
if(this._initialized){
this.view.grid.updateRow(this.rowIdx);
}
return;
}
var self=this;
var g=this.view.grid;
if(g.treeModel){
var p=this._tableRow?dojo.attr(this._tableRow,"dojoxTreeGridPath"):"";
if(p){
dojo.query("tr[dojoxTreeGridPath^=\""+p+"/\"]",this.rowNode).forEach(function(n){
var en=dojo.query(".dojoxGridExpando",n)[0];
if(en&&en.parentNode&&en.parentNode.parentNode&&!dojo.hasClass(en.parentNode.parentNode,"dojoxGridNoChildren")){
var ew=dijit.byNode(en);
if(ew){
ew._toggleRows(_979,ew.open&&open);
}
}
n.style.display=open?"":"none";
});
}
}else{
dojo.query("tr."+_979,this.rowNode).forEach(function(n){
if(dojo.hasClass(n,"dojoxGridExpandoRow")){
var en=dojo.query(".dojoxGridExpando",n)[0];
if(en){
var ew=dijit.byNode(en);
var _97a=ew?ew.toggleClass:en.getAttribute("toggleClass");
var _97b=ew?ew.open:self.expandoCell.getOpenState(en.getAttribute("itemId"));
self._toggleRows(_97a,_97b&&open);
}
}
n.style.display=open?"":"none";
});
}
},setOpen:function(open){
if(open&&dojo.hasClass(this.domNode,"dojoxGridExpandoLoading")){
open=false;
}
var view=this.view;
var grid=view.grid;
var _97c=grid.store;
var _97d=grid.treeModel;
var d=this;
var idx=this.rowIdx;
var me=grid._by_idx[idx];
if(!me){
return;
}
if(_97d&&!this._loadedChildren){
if(open){
var itm=grid.getItem(dojo.attr(this._tableRow,"dojoxTreeGridPath"));
if(itm){
this.expandoInner.innerHTML="o";
dojo.addClass(this.domNode,"dojoxGridExpandoLoading");
_97d.getChildren(itm,function(_97e){
d._loadedChildren=true;
d._setOpen(open);
});
}else{
this._setOpen(open);
}
}else{
this._setOpen(open);
}
}else{
if(!_97d&&_97c){
if(open){
var data=grid._by_idx[this.rowIdx];
if(data&&!_97c.isItemLoaded(data.item)){
this.expandoInner.innerHTML="o";
dojo.addClass(this.domNode,"dojoxGridExpandoLoading");
_97c.loadItem({item:data.item,onItem:dojo.hitch(this,function(i){
var idty=_97c.getIdentity(i);
grid._by_idty[idty]=grid._by_idx[this.rowIdx]={idty:idty,item:i};
this._setOpen(open);
})});
}else{
this._setOpen(open);
}
}else{
this._setOpen(open);
}
}else{
this._setOpen(open);
}
}
},_setOpen:function(open){
if(open&&this._tableRow&&dojo.hasClass(this._tableRow,"dojoxGridNoChildren")){
this._setOpen(false);
return;
}
this.expandoInner.innerHTML=open?"-":"+";
dojo.removeClass(this.domNode,"dojoxGridExpandoLoading");
dojo.toggleClass(this.domNode,"dojoxGridExpandoOpened",open);
if(this._tableRow){
dojo.toggleClass(this._tableRow,"dojoxGridRowCollapsed",!open);
var base=dojo.attr(this._tableRow,"dojoxTreeGridBaseClasses");
var _97f="";
if(open){
_97f=dojo.trim((" "+base+" ").replace(" dojoxGridRowCollapsed "," "));
}else{
if((" "+base+" ").indexOf(" dojoxGridRowCollapsed ")<0){
_97f=base+(base?" ":"")+"dojoxGridRowCollapsed";
}else{
_97f=base;
}
}
dojo.attr(this._tableRow,"dojoxTreeGridBaseClasses",_97f);
}
var _980=(this.open!==open);
this.open=open;
if(this.expandoCell&&this.itemId){
this.expandoCell.openStates[this.itemId]=open;
}
var v=this.view;
var g=v.grid;
if(this.toggleClass&&_980){
if(!this._tableRow||!this._tableRow.style.display){
this._toggleRows(this.toggleClass,open);
}
}
if(v&&this._initialized&&this.rowIdx>=0){
g.rowHeightChanged(this.rowIdx);
g.postresize();
v.hasVScrollbar(true);
}
this._initialized=true;
},onToggle:function(e){
this.setOpen(!this.open);
dojo.stopEvent(e);
},setRowNode:function(_981,_982,view){
if(this.cellIdx<0||!this.itemId){
return false;
}
this._initialized=false;
this.view=view;
this.rowNode=_982;
this.rowIdx=_981;
this.expandoCell=view.structure.cells[0][this.cellIdx];
var d=this.domNode;
if(d&&d.parentNode&&d.parentNode.parentNode){
this._tableRow=d.parentNode.parentNode;
}
this.open=this.expandoCell.getOpenState(this.itemId);
if(view.grid.treeModel){
dojo.style(this.domNode,"marginLeft",(this.level*18)+"px");
if(this.domNode.parentNode){
dojo.style(this.domNode.parentNode,"backgroundPosition",((this.level*18)+(3))+"px");
}
}
this.setOpen(this.open);
return true;
}});
dojo.declare("dojox.grid._TreeContentBuilder",dojox.grid._ContentBuilder,{generateHtml:function(_983,_984){
var html=this.getTableArray(),v=this.view,row=v.structure.cells[0],item=this.grid.getItem(_984),grid=this.grid,_985=this.grid.store;
dojox.grid.util.fire(this.view,"onBeforeRow",[_984,[row]]);
var _986=function(_987,_988,_989,_98a,_98b,_98c){
if(!_98c){
if(html[0].indexOf("dojoxGridRowTableNeedsRowUpdate")==-1){
html[0]=html[0].replace("dojoxGridRowTable","dojoxGridRowTable dojoxGridRowTableNeedsRowUpdate");
}
return;
}
var _98d=html.length;
_98a=_98a||[];
var _98e=_98a.join("|");
var _98f=_98a[_98a.length-1];
var _990=_98f+(_989?" dojoxGridSummaryRow":"");
var _991="";
if(grid.treeModel&&_988&&!grid.treeModel.mayHaveChildren(_988)){
_990+=" dojoxGridNoChildren";
}
html.push("<tr style=\""+_991+"\" class=\""+_990+"\" dojoxTreeGridPath=\""+_98b.join("/")+"\" dojoxTreeGridBaseClasses=\""+_990+"\">");
var _992=_987+1;
var _993=null;
for(var i=0,cell;(cell=row[i]);i++){
var m=cell.markup,cc=cell.customClasses=[],cs=cell.customStyles=[];
m[5]=cell.formatAtLevel(_98b,_988,_987,_989,_98f,cc);
m[5]=dojox.grid.util.fixIEEmptyCell(m[5]);
m[1]=cc.join(" ");
m[3]=cs.join(";");
html.push.apply(html,m);
if(!_993&&cell.level===_992&&cell.parentCell){
_993=cell.parentCell;
}
}
html.push("</tr>");
if(_988&&_985&&_985.isItem(_988)){
var idty=_985.getIdentity(_988);
if(typeof grid._by_idty_paths[idty]=="undefined"){
grid._by_idty_paths[idty]=_98b.join("/");
}
}
var _994;
var _995;
var path;
var _996;
var _997=_98b.concat([]);
if(grid.treeModel&&_988){
if(grid.treeModel.mayHaveChildren(_988)){
_994=v.structure.cells[0][grid.expandoCell||0];
_995=_994.getOpenState(_988)&&_98c;
path=new dojox.grid.TreePath(_98b.join("/"),grid);
_996=path.children(true)||[];
dojo.forEach(_996,function(cItm,idx){
var _998=_98e.split("|");
_998.push(_998[_998.length-1]+"-"+idx);
_997.push(idx);
_986(_992,cItm,false,_998,_997,_995);
_997.pop();
});
}
}else{
if(_988&&_993&&!_989){
_994=v.structure.cells[0][_993.level];
_995=_994.getOpenState(_988)&&_98c;
if(_985.hasAttribute(_988,_993.field)){
var _999=_98e.split("|");
_999.pop();
path=new dojox.grid.TreePath(_98b.join("/"),grid);
_996=path.children(true)||[];
if(_996.length){
html[_98d]="<tr class=\""+_999.join(" ")+" dojoxGridExpandoRow\" dojoxTreeGridPath=\""+_98b.join("/")+"\">";
dojo.forEach(_996,function(cItm,idx){
var _99a=_98e.split("|");
_99a.push(_99a[_99a.length-1]+"-"+idx);
_997.push(idx);
_986(_992,cItm,false,_99a,_997,_995);
_997.pop();
});
_997.push(_996.length);
_986(_987,_988,true,_98a,_997,_995);
}else{
html[_98d]="<tr class=\""+_98f+" dojoxGridNoChildren\" dojoxTreeGridPath=\""+_98b.join("/")+"\">";
}
}else{
if(!_985.isItemLoaded(_988)){
html[0]=html[0].replace("dojoxGridRowTable","dojoxGridRowTable dojoxGridRowTableNeedsRowUpdate");
}else{
html[_98d]="<tr class=\""+_98f+" dojoxGridNoChildren\" dojoxTreeGridPath=\""+_98b.join("/")+"\">";
}
}
}else{
if(_988&&!_989&&_98a.length>1){
html[_98d]="<tr class=\""+_98a[_98a.length-2]+"\" dojoxTreeGridPath=\""+_98b.join("/")+"\">";
}
}
}
};
_986(0,item,false,["dojoxGridRowToggle-"+_984],[_984],true);
html.push("</table>");
return html.join("");
},findTarget:function(_99b,_99c){
var n=_99b;
while(n&&(n!=this.domNode)){
if(n.tagName&&n.tagName.toLowerCase()=="tr"){
break;
}
n=n.parentNode;
}
return (n!=this.domNode)?n:null;
},getCellNode:function(_99d,_99e){
var node=dojo.query("td[idx='"+_99e+"']",_99d)[0];
if(node&&node.parentNode&&!dojo.hasClass(node.parentNode,"dojoxGridSummaryRow")){
return node;
}
},decorateEvent:function(e){
e.rowNode=this.findRowTarget(e.target);
if(!e.rowNode){
return false;
}
e.rowIndex=dojo.attr(e.rowNode,"dojoxTreeGridPath");
this.baseDecorateEvent(e);
e.cell=this.grid.getCell(e.cellIndex);
return true;
}});
dojo.declare("dojox.grid._TreeView",[dojox.grid._View],{_contentBuilderClass:dojox.grid._TreeContentBuilder,_onDndDrop:function(_99f,_9a0,copy){
if(this.grid&&this.grid.aggregator){
this.grid.aggregator.clearSubtotalCache();
}
this.inherited(arguments);
},postCreate:function(){
this.inherited(arguments);
this.connect(this.grid,"_cleanupExpandoCache","_cleanupExpandoCache");
},_cleanupExpandoCache:function(_9a1,_9a2,item){
if(_9a1==-1){
return;
}
dojo.forEach(this.grid.layout.cells,function(cell){
if(typeof cell["openStates"]!="undefined"){
if(_9a2 in cell.openStates){
delete cell.openStates[_9a2];
}
}
});
if(typeof _9a1=="string"&&_9a1.indexOf("/")>-1){
var path=new dojox.grid.TreePath(_9a1,this.grid);
var _9a3=path.parent();
while(_9a3){
path=_9a3;
_9a3=path.parent();
}
var _9a4=path.item();
if(!_9a4){
return;
}
var idty=this.grid.store.getIdentity(_9a4);
if(typeof this._expandos[idty]!="undefined"){
for(var i in this._expandos[idty]){
var exp=this._expandos[idty][i];
if(exp){
exp.destroy();
}
delete this._expandos[idty][i];
}
delete this._expandos[idty];
}
}else{
for(var i in this._expandos){
if(typeof this._expandos[i]!="undefined"){
for(var j in this._expandos[i]){
var exp=this._expandos[i][j];
if(exp){
exp.destroy();
}
}
}
}
this._expandos={};
}
},postMixInProperties:function(){
this.inherited(arguments);
this._expandos={};
},onBeforeRow:function(_9a5,_9a6){
var g=this.grid;
if(g._by_idx&&g._by_idx[_9a5]&&g._by_idx[_9a5].idty){
var idty=g._by_idx[_9a5].idty;
this._expandos[idty]=this._expandos[idty]||{};
}
this.inherited(arguments);
},onAfterRow:function(_9a7,_9a8,_9a9){
dojo.forEach(dojo.query("span.dojoxGridExpando",_9a9),function(n){
if(n&&n.parentNode){
var tc=n.getAttribute("toggleClass");
var idty;
var _9aa;
var g=this.grid;
if(g._by_idx&&g._by_idx[_9a7]&&g._by_idx[_9a7].idty){
idty=g._by_idx[_9a7].idty;
_9aa=this._expandos[idty][tc];
}
if(_9aa){
dojo.place(_9aa.domNode,n,"replace");
_9aa.itemId=n.getAttribute("itemId");
_9aa.cellIdx=parseInt(n.getAttribute("cellIdx"),10);
if(isNaN(_9aa.cellIdx)){
_9aa.cellIdx=-1;
}
}else{
if(idty){
_9aa=dojo.parser.parse(n.parentNode)[0];
this._expandos[idty][tc]=_9aa;
}
}
if(_9aa&&!_9aa.setRowNode(_9a7,_9a9,this)){
_9aa.domNode.parentNode.removeChild(_9aa.domNode);
}
}
},this);
var alt=false;
var self=this;
dojo.query("tr[dojoxTreeGridPath]",_9a9).forEach(function(n){
dojo.toggleClass(n,"dojoxGridSubRowAlt",alt);
dojo.attr(n,"dojoxTreeGridBaseClasses",n.className);
alt=!alt;
self.grid.rows.styleRowNode(dojo.attr(n,"dojoxTreeGridPath"),n);
});
this.inherited(arguments);
},updateRowStyles:function(_9ab){
var _9ac=dojo.query("tr[dojoxTreeGridPath='"+_9ab+"']",this.domNode);
if(_9ac.length){
this.styleRowNode(_9ab,_9ac[0]);
}
},getCellNode:function(_9ad,_9ae){
var row=dojo.query("tr[dojoxTreeGridPath='"+_9ad+"']",this.domNode)[0];
if(row){
return this.content.getCellNode(row,_9ae);
}
},destroy:function(){
this._cleanupExpandoCache();
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dojox.grid.cells.tree"]){
dojo._hasResource["dojox.grid.cells.tree"]=true;
dojo.provide("dojox.grid.cells.tree");
dojox.grid.cells.TreeCell={formatAggregate:function(_9af,_9b0,_9b1){
var f,g=this.grid,i=g.edit.info,d=g.aggregator?g.aggregator.getForCell(this,_9b0,_9af,_9b0===this.level?"cnt":this.parentCell.aggregate):(this.value||this.defaultValue);
return this._defaultFormat(d,[d,_9b0-this.level,_9b1,this]);
},formatIndexes:function(_9b2,_9b3){
var f,g=this.grid,i=g.edit.info,d=this.get?this.get(_9b2[0],_9b3,_9b2):(this.value||this.defaultValue);
if(this.editable&&(this.alwaysEditing||(i.rowIndex==_9b2[0]&&i.cell==this))){
return this.formatEditing(d,_9b2[0],_9b2);
}else{
return this._defaultFormat(d,[d,_9b2[0],_9b2,this]);
}
},getOpenState:function(_9b4){
var grid=this.grid,_9b5=grid.store,itm=null;
if(_9b5.isItem(_9b4)){
itm=_9b4;
_9b4=_9b5.getIdentity(_9b4);
}
if(!this.openStates){
this.openStates={};
}
if(!(_9b4 in this.openStates)){
this.openStates[_9b4]=grid.getDefaultOpenState(this,itm);
}
return this.openStates[_9b4];
},formatAtLevel:function(_9b6,_9b7,_9b8,_9b9,_9ba,_9bb){
if(!dojo.isArray(_9b6)){
_9b6=[_9b6];
}
var _9bc="";
if(_9b8>this.level||(_9b8===this.level&&_9b9)){
_9bb.push("dojoxGridSpacerCell");
if(_9b8===this.level){
_9bb.push("dojoxGridTotalCell");
}
_9bc="<span></span>";
}else{
if(_9b8<this.level){
_9bb.push("dojoxGridSummaryCell");
_9bc="<span class=\"dojoxGridSummarySpan\">"+this.formatAggregate(_9b7,_9b8,_9b6)+"</span>";
}else{
var ret="";
if(this.isCollapsable){
var _9bd=this.grid.store,id="";
if(_9bd.isItem(_9b7)){
id=_9bd.getIdentity(_9b7);
}
_9bb.push("dojoxGridExpandoCell");
ret="<span dojoType=\"dojox.grid._Expando\" level=\""+_9b8+"\" class=\"dojoxGridExpando\""+"\" toggleClass=\""+_9ba+"\" itemId=\""+id+"\" cellIdx=\""+this.index+"\"></span>";
}
_9bc=ret+this.formatIndexes(_9b6,_9b7);
}
}
if(this.grid.focus.cell&&this.index==this.grid.focus.cell.index&&_9b6.join("/")==this.grid.focus.rowIndex){
_9bb.push(this.grid.focus.focusClass);
}
return _9bc;
}};
}
if(!dojo._hasResource["dojox.grid.TreeSelection"]){
dojo._hasResource["dojox.grid.TreeSelection"]=true;
dojo.provide("dojox.grid.TreeSelection");
dojo.declare("dojox.grid.TreeSelection",dojox.grid.DataSelection,{setMode:function(mode){
this.selected={};
this.sorted_sel=[];
this.sorted_ltos={};
this.sorted_stol={};
dojox.grid.DataSelection.prototype.setMode.call(this,mode);
},addToSelection:function(_9be){
if(this.mode=="none"){
return;
}
var idx=null;
if(typeof _9be=="number"||typeof _9be=="string"){
idx=_9be;
}else{
idx=this.grid.getItemIndex(_9be);
}
if(this.selected[idx]){
this.selectedIndex=idx;
}else{
if(this.onCanSelect(idx)!==false){
this.selectedIndex=idx;
var _9bf=dojo.query("tr[dojoxTreeGridPath='"+idx+"']",this.grid.domNode);
if(_9bf.length){
dojo.attr(_9bf[0],"aria-selected","true");
}
this._beginUpdate();
this.selected[idx]=true;
this._insertSortedSelection(idx);
this.onSelected(idx);
this._endUpdate();
}
}
},deselect:function(_9c0){
if(this.mode=="none"){
return;
}
var idx=null;
if(typeof _9c0=="number"||typeof _9c0=="string"){
idx=_9c0;
}else{
idx=this.grid.getItemIndex(_9c0);
}
if(this.selectedIndex==idx){
this.selectedIndex=-1;
}
if(this.selected[idx]){
if(this.onCanDeselect(idx)===false){
return;
}
var _9c1=dojo.query("tr[dojoxTreeGridPath='"+idx+"']",this.grid.domNode);
if(_9c1.length){
dojo.attr(_9c1[0],"aria-selected","false");
}
this._beginUpdate();
delete this.selected[idx];
this._removeSortedSelection(idx);
this.onDeselected(idx);
this._endUpdate();
}
},getSelected:function(){
var _9c2=[];
for(var i in this.selected){
if(this.selected[i]){
_9c2.push(this.grid.getItem(i));
}
}
return _9c2;
},getSelectedCount:function(){
var c=0;
for(var i in this.selected){
if(this.selected[i]){
c++;
}
}
return c;
},_bsearch:function(v){
var o=this.sorted_sel;
var h=o.length-1,l=0,m;
while(l<=h){
var cmp=this._comparePaths(o[m=(l+h)>>1],v);
if(cmp<0){
l=m+1;
continue;
}
if(cmp>0){
h=m-1;
continue;
}
return m;
}
return cmp<0?m-cmp:m;
},_comparePaths:function(a,b){
for(var i=0,l=(a.length<b.length?a.length:b.length);i<l;i++){
if(a[i]<b[i]){
return -1;
}
if(a[i]>b[i]){
return 1;
}
}
if(a.length<b.length){
return -1;
}
if(a.length>b.length){
return 1;
}
return 0;
},_insertSortedSelection:function(_9c3){
_9c3=String(_9c3);
var s=this.sorted_sel;
var sl=this.sorted_ltos;
var ss=this.sorted_stol;
var _9c4=_9c3.split("/");
_9c4=dojo.map(_9c4,function(item){
return parseInt(item,10);
});
sl[_9c4]=_9c3;
ss[_9c3]=_9c4;
if(s.length===0){
s.push(_9c4);
return;
}
if(s.length==1){
var cmp=this._comparePaths(s[0],_9c4);
if(cmp==1){
s.unshift(_9c4);
}else{
s.push(_9c4);
}
return;
}
var idx=this._bsearch(_9c4);
this.sorted_sel.splice(idx,0,_9c4);
},_removeSortedSelection:function(_9c5){
_9c5=String(_9c5);
var s=this.sorted_sel;
var sl=this.sorted_ltos;
var ss=this.sorted_stol;
if(s.length===0){
return;
}
var _9c6=ss[_9c5];
if(!_9c6){
return;
}
var idx=this._bsearch(_9c6);
if(idx>-1){
delete sl[_9c6];
delete ss[_9c5];
s.splice(idx,1);
}
},getFirstSelected:function(){
if(!this.sorted_sel.length||this.mode=="none"){
return -1;
}
var _9c7=this.sorted_sel[0];
if(!_9c7){
return -1;
}
_9c7=this.sorted_ltos[_9c7];
if(!_9c7){
return -1;
}
return _9c7;
},getNextSelected:function(_9c8){
if(!this.sorted_sel.length||this.mode=="none"){
return -1;
}
_9c8=String(_9c8);
var _9c9=this.sorted_stol[_9c8];
if(!_9c9){
return -1;
}
var idx=this._bsearch(_9c9);
var _9ca=this.sorted_sel[idx+1];
if(!_9ca){
return -1;
}
return this.sorted_ltos[_9ca];
},_range:function(_9cb,inTo,func){
if(!dojo.isString(_9cb)&&_9cb<0){
_9cb=inTo;
}
var _9cc=this.grid.layout.cells,_9cd=this.grid.store,grid=this.grid;
_9cb=new dojox.grid.TreePath(String(_9cb),grid);
inTo=new dojox.grid.TreePath(String(inTo),grid);
if(_9cb.compare(inTo)>0){
var tmp=_9cb;
_9cb=inTo;
inTo=tmp;
}
var _9ce=_9cb._str,_9cf=inTo._str;
func(_9ce);
var p=_9cb;
while((p=p.next())){
if(p._str==_9cf){
break;
}
func(p._str);
}
func(_9cf);
}});
}
if(!dojo._hasResource["dojox.grid.TreeGrid"]){
dojo._hasResource["dojox.grid.TreeGrid"]=true;
dojo.experimental("dojox.grid.TreeGrid");
dojo.provide("dojox.grid.TreeGrid");
dojo.declare("dojox.grid._TreeAggregator",null,{cells:[],grid:null,childFields:[],constructor:function(_9d0){
this.cells=_9d0.cells||[];
this.childFields=_9d0.childFields||[];
this.grid=_9d0.grid;
this.store=this.grid.store;
},_cacheValue:function(_9d1,id,_9d2){
_9d1[id]=_9d2;
return _9d2;
},clearSubtotalCache:function(){
if(this.store){
delete this.store._cachedAggregates;
}
},cnt:function(cell,_9d3,item){
var _9d4=0;
var _9d5=this.store;
var _9d6=this.childFields;
if(_9d6[_9d3]){
var _9d7=_9d5.getValues(item,_9d6[_9d3]);
if(cell.index<=_9d3+1){
_9d4=_9d7.length;
}else{
dojo.forEach(_9d7,function(c){
_9d4+=this.getForCell(cell,_9d3+1,c,"cnt");
},this);
}
}else{
_9d4=1;
}
return _9d4;
},sum:function(cell,_9d8,item){
var _9d9=0;
var _9da=this.store;
var _9db=this.childFields;
if(_9db[_9d8]){
dojo.forEach(_9da.getValues(item,_9db[_9d8]),function(c){
_9d9+=this.getForCell(cell,_9d8+1,c,"sum");
},this);
}else{
_9d9+=_9da.getValue(item,cell.field);
}
return _9d9;
},value:function(cell,_9dc,item){
},getForCell:function(cell,_9dd,item,type){
var _9de=this.store;
if(!_9de||!item||!_9de.isItem(item)){
return "";
}
var _9df=_9de._cachedAggregates=_9de._cachedAggregates||{};
var id=_9de.getIdentity(item);
var _9e0=_9df[id]=_9df[id]||[];
if(!cell.getOpenState){
cell=this.grid.getCell(cell.layoutIndex+_9dd+1);
}
var idx=cell.index;
var _9e1=_9e0[idx]=_9e0[idx]||{};
type=(type||(cell.parentCell?cell.parentCell.aggregate:"sum"))||"sum";
var attr=cell.field;
if(attr==_9de.getLabelAttributes()[0]){
type="cnt";
}
var _9e2=_9e1[type]=_9e1[type]||[];
if(_9e2[_9dd]!=undefined){
return _9e2[_9dd];
}
var _9e3=((cell.parentCell&&cell.parentCell.itemAggregates)?cell.parentCell.itemAggregates[cell.idxInParent]:"")||"";
if(_9e3&&_9de.hasAttribute(item,_9e3)){
return this._cacheValue(_9e2,_9dd,_9de.getValue(item,_9e3));
}else{
if(_9e3){
return this._cacheValue(_9e2,_9dd,0);
}
}
return this._cacheValue(_9e2,_9dd,this[type](cell,_9dd,item));
}});
dojo.declare("dojox.grid._TreeLayout",dojox.grid._Layout,{_isCollapsable:false,_getInternalStructure:function(_9e4){
var g=this.grid;
var s=_9e4;
var _9e5=s[0].cells[0];
var tree={type:"dojox.grid._TreeView",cells:[[]]};
var _9e6=[];
var _9e7=0;
var _9e8=function(_9e9,_9ea){
var _9eb=_9e9.children;
var _9ec=function(_9ed,idx){
var k,n={};
for(k in _9ed){
n[k]=_9ed[k];
}
n=dojo.mixin(n,{level:_9ea,idxInParent:_9ea>0?idx:-1,parentCell:_9ea>0?_9e9:null});
return n;
};
var ret=[];
dojo.forEach(_9eb,function(c,idx){
if("children" in c){
_9e6.push(c.field);
var last=ret[ret.length-1];
last.isCollapsable=true;
c.level=_9ea;
ret=ret.concat(_9e8(c,_9ea+1));
}else{
ret.push(_9ec(c,idx));
}
});
_9e7=Math.max(_9e7,_9ea);
return ret;
};
var _9ee={children:_9e5,itemAggregates:[]};
tree.cells[0]=_9e8(_9ee,0);
g.aggregator=new dojox.grid._TreeAggregator({cells:tree.cells[0],grid:g,childFields:_9e6});
if(g.scroller&&g.defaultOpen){
g.scroller.defaultRowHeight=g.scroller._origDefaultRowHeight*(2*_9e7+1);
}
return [tree];
},setStructure:function(_9ef){
var s=_9ef;
var g=this.grid;
if(g&&g.treeModel&&!dojo.every(s,function(i){
return ("cells" in i);
})){
s=arguments[0]=[{cells:[s]}];
}
if(s.length==1&&s[0].cells.length==1){
if(g&&g.treeModel){
s[0].type="dojox.grid._TreeView";
this._isCollapsable=true;
s[0].cells[0][(this.grid.treeModel?this.grid.expandoCell:0)].isCollapsable=true;
}else{
var _9f0=dojo.filter(s[0].cells[0],function(c){
return ("children" in c);
});
if(_9f0.length===1){
this._isCollapsable=true;
}
}
}
if(this._isCollapsable&&(!g||!g.treeModel)){
arguments[0]=this._getInternalStructure(s);
}
this.inherited(arguments);
},addCellDef:function(_9f1,_9f2,_9f3){
var obj=this.inherited(arguments);
return dojo.mixin(obj,dojox.grid.cells.TreeCell);
}});
dojo.declare("dojox.grid.TreePath",null,{level:0,_str:"",_arr:null,grid:null,store:null,cell:null,item:null,constructor:function(path,grid){
if(dojo.isString(path)){
this._str=path;
this._arr=dojo.map(path.split("/"),function(item){
return parseInt(item,10);
});
}else{
if(dojo.isArray(path)){
this._str=path.join("/");
this._arr=path.slice(0);
}else{
if(typeof path=="number"){
this._str=String(path);
this._arr=[path];
}else{
this._str=path._str;
this._arr=path._arr.slice(0);
}
}
}
this.level=this._arr.length-1;
this.grid=grid;
this.store=this.grid.store;
if(grid.treeModel){
this.cell=grid.layout.cells[grid.expandoCell];
}else{
this.cell=grid.layout.cells[this.level];
}
},item:function(){
if(!this._item){
this._item=this.grid.getItem(this._arr);
}
return this._item;
},compare:function(path){
if(dojo.isString(path)||dojo.isArray(path)){
if(this._str==path){
return 0;
}
if(path.join&&this._str==path.join("/")){
return 0;
}
path=new dojox.grid.TreePath(path,this.grid);
}else{
if(path instanceof dojox.grid.TreePath){
if(this._str==path._str){
return 0;
}
}
}
for(var i=0,l=(this._arr.length<path._arr.length?this._arr.length:path._arr.length);i<l;i++){
if(this._arr[i]<path._arr[i]){
return -1;
}
if(this._arr[i]>path._arr[i]){
return 1;
}
}
if(this._arr.length<path._arr.length){
return -1;
}
if(this._arr.length>path._arr.length){
return 1;
}
return 0;
},isOpen:function(){
return this.cell.openStates&&this.cell.getOpenState(this.item());
},previous:function(){
var _9f4=this._arr.slice(0);
if(this._str=="0"){
return null;
}
var last=_9f4.length-1;
if(_9f4[last]===0){
_9f4.pop();
return new dojox.grid.TreePath(_9f4,this.grid);
}
_9f4[last]--;
var path=new dojox.grid.TreePath(_9f4,this.grid);
return path.lastChild(true);
},next:function(){
var _9f5=this._arr.slice(0);
if(this.isOpen()){
_9f5.push(0);
}else{
_9f5[_9f5.length-1]++;
for(var i=this.level;i>=0;i--){
var item=this.grid.getItem(_9f5.slice(0,i+1));
if(i>0){
if(!item){
_9f5.pop();
_9f5[i-1]++;
}
}else{
if(!item){
return null;
}
}
}
}
return new dojox.grid.TreePath(_9f5,this.grid);
},children:function(_9f6){
if(!this.isOpen()&&!_9f6){
return null;
}
var _9f7=[];
var _9f8=this.grid.treeModel;
if(_9f8){
var item=this.item();
var _9f9=_9f8.store;
if(!_9f8.mayHaveChildren(item)){
return null;
}
dojo.forEach(_9f8.childrenAttrs,function(attr){
_9f7=_9f7.concat(_9f9.getValues(item,attr));
});
}else{
_9f7=this.store.getValues(this.item(),this.grid.layout.cells[this.cell.level+1].parentCell.field);
if(_9f7.length>1&&this.grid.sortChildItems){
var _9fa=this.grid.getSortProps();
if(_9fa&&_9fa.length){
var attr=_9fa[0].attribute,grid=this.grid;
if(attr&&_9f7[0][attr]){
var desc=!!_9fa[0].descending;
_9f7=_9f7.slice(0);
_9f7.sort(function(a,b){
return grid._childItemSorter(a,b,attr,desc);
});
}
}
}
}
return _9f7;
},childPaths:function(){
var _9fb=this.children();
if(!_9fb){
return [];
}
return dojo.map(_9fb,function(item,_9fc){
return new dojox.grid.TreePath(this._str+"/"+_9fc,this.grid);
},this);
},parent:function(){
if(this.level===0){
return null;
}
return new dojox.grid.TreePath(this._arr.slice(0,this.level),this.grid);
},lastChild:function(_9fd){
var _9fe=this.children();
if(!_9fe||!_9fe.length){
return this;
}
var path=new dojox.grid.TreePath(this._str+"/"+String(_9fe.length-1),this.grid);
if(!_9fd){
return path;
}
return path.lastChild(true);
},toString:function(){
return this._str;
}});
dojo.declare("dojox.grid._TreeFocusManager",dojox.grid._FocusManager,{setFocusCell:function(_9ff,_a00){
if(_9ff&&_9ff.getNode(_a00)){
this.inherited(arguments);
}
},isLastFocusCell:function(){
if(this.cell&&this.cell.index==this.grid.layout.cellCount-1){
var path=new dojox.grid.TreePath(this.grid.rowCount-1,this.grid);
path=path.lastChild(true);
return this.rowIndex==path._str;
}
return false;
},next:function(){
if(this.cell){
var row=this.rowIndex,col=this.cell.index+1,cc=this.grid.layout.cellCount-1;
var path=new dojox.grid.TreePath(this.rowIndex,this.grid);
if(col>cc){
var _a01=path.next();
if(!_a01){
col--;
}else{
col=0;
path=_a01;
}
}
if(this.grid.edit.isEditing()){
var _a02=this.grid.getCell(col);
if(!this.isLastFocusCell()&&!_a02.editable){
this._focusifyCellNode(false);
this.cell=_a02;
this.rowIndex=path._str;
this.next();
return;
}
}
this.setFocusIndex(path._str,col);
}
},previous:function(){
if(this.cell){
var row=(this.rowIndex||0),col=(this.cell.index||0)-1;
var path=new dojox.grid.TreePath(row,this.grid);
if(col<0){
var _a03=path.previous();
if(!_a03){
col=0;
}else{
col=this.grid.layout.cellCount-1;
path=_a03;
}
}
if(this.grid.edit.isEditing()){
var _a04=this.grid.getCell(col);
if(!this.isFirstFocusCell()&&!_a04.editable){
this._focusifyCellNode(false);
this.cell=_a04;
this.rowIndex=path._str;
this.previous();
return;
}
}
this.setFocusIndex(path._str,col);
}
},move:function(_a05,_a06){
if(this.isNavHeader()){
this.inherited(arguments);
return;
}
if(!this.cell){
return;
}
var sc=this.grid.scroller,r=this.rowIndex,rc=this.grid.rowCount-1,path=new dojox.grid.TreePath(this.rowIndex,this.grid);
if(_a05){
var row;
if(_a05>0){
path=path.next();
row=path._arr[0];
if(row>sc.getLastPageRow(sc.page)){
this.grid.setScrollTop(this.grid.scrollTop+sc.findScrollTop(row)-sc.findScrollTop(r));
}
}else{
if(_a05<0){
path=path.previous();
row=path._arr[0];
if(row<=sc.getPageRow(sc.page)){
this.grid.setScrollTop(this.grid.scrollTop-sc.findScrollTop(r)-sc.findScrollTop(row));
}
}
}
}
var cc=this.grid.layout.cellCount-1,i=this.cell.index,col=Math.min(cc,Math.max(0,i+_a06));
var cell=this.grid.getCell(col);
var _a07=_a06<0?-1:1;
while(col>=0&&col<cc&&cell&&cell.hidden===true){
col+=_a07;
cell=this.grid.getCell(col);
}
if(!cell||cell.hidden===true){
col=i;
}
if(_a05){
this.grid.updateRow(r);
}
this.setFocusIndex(path._str,col);
}});
dojo.declare("dojox.grid.TreeGrid",dojox.grid.DataGrid,{defaultOpen:true,sortChildItems:false,openAtLevels:[],treeModel:null,expandoCell:0,aggregator:null,_layoutClass:dojox.grid._TreeLayout,createSelection:function(){
this.selection=new dojox.grid.TreeSelection(this);
},_childItemSorter:function(a,b,_a08,_a09){
var av=this.store.getValue(a,_a08);
var bv=this.store.getValue(b,_a08);
if(av!=bv){
return av<bv==_a09?1:-1;
}
return 0;
},_onNew:function(item,_a0a){
if(!_a0a||!_a0a.item){
this.inherited(arguments);
}else{
var idx=this.getItemIndex(_a0a.item);
if(typeof idx=="string"){
this.updateRow(idx.split("/")[0]);
}else{
if(idx>-1){
this.updateRow(idx);
}
}
}
},_onSet:function(item,_a0b,_a0c,_a0d){
this._checkUpdateStatus();
if(this.aggregator){
this.aggregator.clearSubtotalCache();
}
var idx=this.getItemIndex(item);
if(typeof idx=="string"){
this.updateRow(idx.split("/")[0]);
}else{
if(idx>-1){
this.updateRow(idx);
}
}
},_onDelete:function(item){
this._cleanupExpandoCache(this._getItemIndex(item,true),this.store.getIdentity(item),item);
this.inherited(arguments);
},_cleanupExpandoCache:function(_a0e,_a0f,item){
},_addItem:function(item,_a10,_a11,_a12){
if(!_a12&&this.model&&dojo.indexOf(this.model.root.children,item)==-1){
this.model.root.children[_a10]=item;
}
this.inherited(arguments);
},getItem:function(idx){
var _a13=dojo.isArray(idx);
if(dojo.isString(idx)&&idx.indexOf("/")){
idx=idx.split("/");
_a13=true;
}
if(_a13&&idx.length==1){
idx=idx[0];
_a13=false;
}
if(!_a13){
return dojox.grid.DataGrid.prototype.getItem.call(this,idx);
}
var s=this.store;
var itm=dojox.grid.DataGrid.prototype.getItem.call(this,idx[0]);
var cf,i,j;
if(this.aggregator){
cf=this.aggregator.childFields||[];
if(cf){
for(i=0;i<idx.length-1&&itm;i++){
if(cf[i]){
itm=(s.getValues(itm,cf[i])||[])[idx[i+1]];
}else{
itm=null;
}
}
}
}else{
if(this.treeModel){
cf=this.treeModel.childrenAttrs||[];
if(cf&&itm){
for(i=1,il=idx.length;(i<il)&&itm;i++){
for(j=0,jl=cf.length;j<jl;j++){
if(cf[j]){
itm=(s.getValues(itm,cf[j])||[])[idx[i]];
}else{
itm=null;
}
if(itm){
break;
}
}
}
}
}
}
return itm||null;
},_getItemIndex:function(item,_a14){
if(!_a14&&!this.store.isItem(item)){
return -1;
}
var idx=this.inherited(arguments);
if(idx==-1){
var idty=this.store.getIdentity(item);
return this._by_idty_paths[idty]||-1;
}
return idx;
},postMixInProperties:function(){
if(this.treeModel&&!("defaultOpen" in this.params)){
this.defaultOpen=false;
}
var def=this.defaultOpen;
this.openAtLevels=dojo.map(this.openAtLevels,function(l){
if(typeof l=="string"){
switch(l.toLowerCase()){
case "true":
return true;
break;
case "false":
return false;
break;
default:
var r=parseInt(l,10);
if(isNaN(r)){
return def;
}
return r;
break;
}
}
return l;
});
this._by_idty_paths={};
this.inherited(arguments);
},postCreate:function(){
this.inherited(arguments);
if(this.treeModel){
this._setModel(this.treeModel);
}
},setModel:function(_a15){
this._setModel(_a15);
this._refresh(true);
},_setModel:function(_a16){
if(_a16&&(!dijit.tree.ForestStoreModel||!(_a16 instanceof dijit.tree.ForestStoreModel))){
throw new Error("dojox.grid.TreeGrid: treeModel must be an instance of dijit.tree.ForestStoreModel");
}
this.treeModel=_a16;
dojo.toggleClass(this.domNode,"dojoxGridTreeModel",this.treeModel?true:false);
this._setQuery(_a16?_a16.query:null);
this._setStore(_a16?_a16.store:null);
},createScroller:function(){
this.inherited(arguments);
this.scroller._origDefaultRowHeight=this.scroller.defaultRowHeight;
},createManagers:function(){
this.rows=new dojox.grid._RowManager(this);
this.focus=new dojox.grid._TreeFocusManager(this);
this.edit=new dojox.grid._EditManager(this);
},_setStore:function(_a17){
this.inherited(arguments);
if(this.treeModel&&!this.treeModel.root.children){
this.treeModel.root.children=[];
}
if(this.aggregator){
this.aggregator.store=_a17;
}
},getDefaultOpenState:function(_a18,item){
var cf;
var _a19=this.store;
if(this.treeModel){
return this.defaultOpen;
}
if(!_a18||!_a19||!_a19.isItem(item)||!(cf=this.aggregator.childFields[_a18.level])){
return this.defaultOpen;
}
if(this.openAtLevels.length>_a18.level){
var dVal=this.openAtLevels[_a18.level];
if(typeof dVal=="boolean"){
return dVal;
}else{
if(typeof dVal=="number"){
return (_a19.getValues(item,cf).length<=dVal);
}
}
}
return this.defaultOpen;
},onStyleRow:function(row){
if(!this.layout._isCollapsable){
this.inherited(arguments);
return;
}
var base=dojo.attr(row.node,"dojoxTreeGridBaseClasses");
if(base){
row.customClasses=base;
}
var i=row;
var _a1a=i.node.tagName.toLowerCase();
i.customClasses+=(i.odd?" dojoxGridRowOdd":"")+(i.selected&&_a1a=="tr"?" dojoxGridRowSelected":"")+(i.over&&_a1a=="tr"?" dojoxGridRowOver":"");
this.focus.styleRow(i);
this.edit.styleRow(i);
},styleRowNode:function(_a1b,_a1c){
if(_a1c){
if(_a1c.tagName.toLowerCase()=="div"&&this.aggregator){
dojo.query("tr[dojoxTreeGridPath]",_a1c).forEach(function(_a1d){
this.rows.styleRowNode(dojo.attr(_a1d,"dojoxTreeGridPath"),_a1d);
},this);
}
this.rows.styleRowNode(_a1b,_a1c);
}
},onCanSelect:function(_a1e){
var _a1f=dojo.query("tr[dojoxTreeGridPath='"+_a1e+"']",this.domNode);
if(_a1f.length){
if(dojo.hasClass(_a1f[0],"dojoxGridSummaryRow")){
return false;
}
}
return this.inherited(arguments);
},onKeyDown:function(e){
if(e.altKey||e.metaKey){
return;
}
var dk=dojo.keys;
switch(e.keyCode){
case dk.UP_ARROW:
if(!this.edit.isEditing()&&this.focus.rowIndex!="0"){
dojo.stopEvent(e);
this.focus.move(-1,0);
}
break;
case dk.DOWN_ARROW:
var _a20=new dojox.grid.TreePath(this.focus.rowIndex,this);
var _a21=new dojox.grid.TreePath(this.rowCount-1,this);
_a21=_a21.lastChild(true);
if(!this.edit.isEditing()&&_a20.toString()!=_a21.toString()){
dojo.stopEvent(e);
this.focus.move(1,0);
}
break;
default:
this.inherited(arguments);
break;
}
},canEdit:function(_a22,_a23){
var node=_a22.getNode(_a23);
return node&&this._canEdit;
},doApplyCellEdit:function(_a24,_a25,_a26){
var item=this.getItem(_a25);
var _a27=this.store.getValue(item,_a26);
if(typeof _a27=="number"){
_a24=isNaN(_a24)?_a24:parseFloat(_a24);
}else{
if(typeof _a27=="boolean"){
_a24=_a24=="true"?true:_a24=="false"?false:_a24;
}else{
if(_a27 instanceof Date){
var _a28=new Date(_a24);
_a24=isNaN(_a28.getTime())?_a24:_a28;
}
}
}
this.store.setValue(item,_a26,_a24);
this.onApplyCellEdit(_a24,_a25,_a26);
}});
dojox.grid.TreeGrid.markupFactory=function(_a29,node,ctor,_a2a){
var d=dojo;
var _a2b=function(n){
var w=d.attr(n,"width")||"auto";
if((w!="auto")&&(w.slice(-2)!="em")&&(w.slice(-1)!="%")){
w=parseInt(w,10)+"px";
}
return w;
};
var _a2c=function(_a2d){
var rows;
if(_a2d.nodeName.toLowerCase()=="table"&&d.query("> colgroup",_a2d).length===0&&(rows=d.query("> thead > tr",_a2d)).length==1){
var tr=rows[0];
return d.query("> th",rows[0]).map(function(th){
var cell={type:d.trim(d.attr(th,"cellType")||""),field:d.trim(d.attr(th,"field")||"")};
if(cell.type){
cell.type=d.getObject(cell.type);
}
var _a2e=d.query("> table",th)[0];
if(_a2e){
cell.name="";
cell.children=_a2c(_a2e);
if(d.hasAttr(th,"itemAggregates")){
cell.itemAggregates=d.map(d.attr(th,"itemAggregates").split(","),function(v){
return d.trim(v);
});
}else{
cell.itemAggregates=[];
}
if(d.hasAttr(th,"aggregate")){
cell.aggregate=d.attr(th,"aggregate");
}
cell.type=cell.type||dojox.grid.cells.SubtableCell;
}else{
cell.name=d.trim(d.attr(th,"name")||th.innerHTML);
if(d.hasAttr(th,"width")){
cell.width=_a2b(th);
}
if(d.hasAttr(th,"relWidth")){
cell.relWidth=window.parseInt(d.attr(th,"relWidth"),10);
}
if(d.hasAttr(th,"hidden")){
cell.hidden=d.attr(th,"hidden")=="true";
}
cell.field=cell.field||cell.name;
dojox.grid.DataGrid.cell_markupFactory(_a2a,th,cell);
cell.type=cell.type||dojox.grid.cells.Cell;
}
if(cell.type&&cell.type.markupFactory){
cell.type.markupFactory(th,cell);
}
return cell;
});
}
return [];
};
var rows;
if(!_a29.structure){
var row=_a2c(node);
if(row.length){
_a29.structure=[{__span:Infinity,cells:[row]}];
}
}
return dojox.grid.DataGrid.markupFactory(_a29,node,ctor,_a2a);
};
}
if(!dojo._hasResource["dijit.tree.TreeStoreModel"]){
dojo._hasResource["dijit.tree.TreeStoreModel"]=true;
dojo.provide("dijit.tree.TreeStoreModel");
dojo.declare("dijit.tree.TreeStoreModel",null,{store:null,childrenAttrs:["children"],newItemIdAttr:"id",labelAttr:"",root:null,query:null,deferItemLoadingUntilExpand:false,constructor:function(args){
dojo.mixin(this,args);
this.connects=[];
var _a2f=this.store;
if(!_a2f.getFeatures()["dojo.data.api.Identity"]){
throw new Error("dijit.Tree: store must support dojo.data.Identity");
}
if(_a2f.getFeatures()["dojo.data.api.Notification"]){
this.connects=this.connects.concat([dojo.connect(_a2f,"onNew",this,"onNewItem"),dojo.connect(_a2f,"onDelete",this,"onDeleteItem"),dojo.connect(_a2f,"onSet",this,"onSetItem")]);
}
},destroy:function(){
dojo.forEach(this.connects,dojo.disconnect);
},getRoot:function(_a30,_a31){
if(this.root){
_a30(this.root);
}else{
this.store.fetch({query:this.query,onComplete:dojo.hitch(this,function(_a32){
if(_a32.length!=1){
throw new Error(this.declaredClass+": query "+dojo.toJson(this.query)+" returned "+_a32.length+" items, but must return exactly one item");
}
this.root=_a32[0];
_a30(this.root);
}),onError:_a31});
}
},mayHaveChildren:function(item){
return dojo.some(this.childrenAttrs,function(attr){
return this.store.hasAttribute(item,attr);
},this);
},getChildren:function(_a33,_a34,_a35){
var _a36=this.store;
if(!_a36.isItemLoaded(_a33)){
var _a37=dojo.hitch(this,arguments.callee);
_a36.loadItem({item:_a33,onItem:function(_a38){
_a37(_a38,_a34,_a35);
},onError:_a35});
return;
}
var _a39=[];
for(var i=0;i<this.childrenAttrs.length;i++){
var vals=_a36.getValues(_a33,this.childrenAttrs[i]);
_a39=_a39.concat(vals);
}
var _a3a=0;
if(!this.deferItemLoadingUntilExpand){
dojo.forEach(_a39,function(item){
if(!_a36.isItemLoaded(item)){
_a3a++;
}
});
}
if(_a3a==0){
_a34(_a39);
}else{
dojo.forEach(_a39,function(item,idx){
if(!_a36.isItemLoaded(item)){
_a36.loadItem({item:item,onItem:function(item){
_a39[idx]=item;
if(--_a3a==0){
_a34(_a39);
}
},onError:_a35});
}
});
}
},isItem:function(_a3b){
return this.store.isItem(_a3b);
},fetchItemByIdentity:function(_a3c){
this.store.fetchItemByIdentity(_a3c);
},getIdentity:function(item){
return this.store.getIdentity(item);
},getLabel:function(item){
if(this.labelAttr){
return this.store.getValue(item,this.labelAttr);
}else{
return this.store.getLabel(item);
}
},newItem:function(args,_a3d,_a3e){
var _a3f={parent:_a3d,attribute:this.childrenAttrs[0]},_a40;
if(this.newItemIdAttr&&args[this.newItemIdAttr]){
this.fetchItemByIdentity({identity:args[this.newItemIdAttr],scope:this,onItem:function(item){
if(item){
this.pasteItem(item,null,_a3d,true,_a3e);
}else{
_a40=this.store.newItem(args,_a3f);
if(_a40&&(_a3e!=undefined)){
this.pasteItem(_a40,_a3d,_a3d,false,_a3e);
}
}
}});
}else{
_a40=this.store.newItem(args,_a3f);
if(_a40&&(_a3e!=undefined)){
this.pasteItem(_a40,_a3d,_a3d,false,_a3e);
}
}
},pasteItem:function(_a41,_a42,_a43,_a44,_a45){
var _a46=this.store,_a47=this.childrenAttrs[0];
if(_a42){
dojo.forEach(this.childrenAttrs,function(attr){
if(_a46.containsValue(_a42,attr,_a41)){
if(!_a44){
var _a48=dojo.filter(_a46.getValues(_a42,attr),function(x){
return x!=_a41;
});
_a46.setValues(_a42,attr,_a48);
}
_a47=attr;
}
});
}
if(_a43){
if(typeof _a45=="number"){
var _a49=_a46.getValues(_a43,_a47).slice();
_a49.splice(_a45,0,_a41);
_a46.setValues(_a43,_a47,_a49);
}else{
_a46.setValues(_a43,_a47,_a46.getValues(_a43,_a47).concat(_a41));
}
}
},onChange:function(item){
},onChildrenChange:function(_a4a,_a4b){
},onDelete:function(_a4c,_a4d){
},onNewItem:function(item,_a4e){
if(!_a4e){
return;
}
this.getChildren(_a4e.item,dojo.hitch(this,function(_a4f){
this.onChildrenChange(_a4e.item,_a4f);
}));
},onDeleteItem:function(item){
this.onDelete(item);
},onSetItem:function(item,_a50,_a51,_a52){
if(dojo.indexOf(this.childrenAttrs,_a50)!=-1){
this.getChildren(item,dojo.hitch(this,function(_a53){
this.onChildrenChange(item,_a53);
}));
}else{
this.onChange(item);
}
}});
}
if(!dojo._hasResource["dijit.tree.ForestStoreModel"]){
dojo._hasResource["dijit.tree.ForestStoreModel"]=true;
dojo.provide("dijit.tree.ForestStoreModel");
dojo.declare("dijit.tree.ForestStoreModel",dijit.tree.TreeStoreModel,{rootId:"$root$",rootLabel:"ROOT",query:null,constructor:function(_a54){
this.root={store:this,root:true,id:_a54.rootId,label:_a54.rootLabel,children:_a54.rootChildren};
},mayHaveChildren:function(item){
return item===this.root||this.inherited(arguments);
},getChildren:function(_a55,_a56,_a57){
if(_a55===this.root){
if(this.root.children){
_a56(this.root.children);
}else{
this.store.fetch({query:this.query,onComplete:dojo.hitch(this,function(_a58){
this.root.children=_a58;
_a56(_a58);
}),onError:_a57});
}
}else{
this.inherited(arguments);
}
},isItem:function(_a59){
return (_a59===this.root)?true:this.inherited(arguments);
},fetchItemByIdentity:function(_a5a){
if(_a5a.identity==this.root.id){
var _a5b=_a5a.scope?_a5a.scope:dojo.global;
if(_a5a.onItem){
_a5a.onItem.call(_a5b,this.root);
}
}else{
this.inherited(arguments);
}
},getIdentity:function(item){
return (item===this.root)?this.root.id:this.inherited(arguments);
},getLabel:function(item){
return (item===this.root)?this.root.label:this.inherited(arguments);
},newItem:function(args,_a5c,_a5d){
if(_a5c===this.root){
this.onNewRootItem(args);
return this.store.newItem(args);
}else{
return this.inherited(arguments);
}
},onNewRootItem:function(args){
},pasteItem:function(_a5e,_a5f,_a60,_a61,_a62){
if(_a5f===this.root){
if(!_a61){
this.onLeaveRoot(_a5e);
}
}
dijit.tree.TreeStoreModel.prototype.pasteItem.call(this,_a5e,_a5f===this.root?null:_a5f,_a60===this.root?null:_a60,_a61,_a62);
if(_a60===this.root){
this.onAddToRoot(_a5e);
}
},onAddToRoot:function(item){
},onLeaveRoot:function(item){
},_requeryTop:function(){
var _a63=this.root.children||[];
this.store.fetch({query:this.query,onComplete:dojo.hitch(this,function(_a64){
this.root.children=_a64;
if(_a63.length!=_a64.length||dojo.some(_a63,function(item,idx){
return _a64[idx]!=item;
})){
this.onChildrenChange(this.root,_a64);
}
})});
},onNewItem:function(item,_a65){
this._requeryTop();
this.inherited(arguments);
},onDeleteItem:function(item){
if(dojo.indexOf(this.root.children,item)!=-1){
this._requeryTop();
}
this.inherited(arguments);
},onSetItem:function(item,_a66,_a67,_a68){
this._requeryTop();
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dojox.grid.LazyTreeGridStoreModel"]){
dojo._hasResource["dojox.grid.LazyTreeGridStoreModel"]=true;
dojo.provide("dojox.grid.LazyTreeGridStoreModel");
dojo.declare("dojox.grid.LazyTreeGridStoreModel",dijit.tree.ForestStoreModel,{serverStore:false,constructor:function(args){
this.serverStore=!!args.serverStore;
},mayHaveChildren:function(item){
var _a69=null;
return dojo.some(this.childrenAttrs,function(attr){
_a69=this.store.getValue(item,attr);
if(dojo.isString(_a69)){
return parseInt(_a69,10)>0||_a69.toLowerCase()==="true"?true:false;
}else{
if(typeof _a69=="number"){
return _a69>0;
}else{
if(typeof _a69=="boolean"){
return _a69;
}else{
if(this.store.isItem(_a69)){
_a69=this.store.getValues(item,attr);
return dojo.isArray(_a69)?_a69.length>0:false;
}else{
return false;
}
}
}
}
},this);
},getChildren:function(_a6a,_a6b,_a6c,_a6d){
if(_a6d){
var _a6e=_a6d.start||0,_a6f=_a6d.count,_a70=_a6d.parentId,sort=_a6d.sort;
if(_a6a===this.root){
this.root.size=0;
this.store.fetch({start:_a6e,count:_a6f,sort:sort,query:this.query,onBegin:dojo.hitch(this,function(size){
this.root.size=size;
}),onComplete:dojo.hitch(this,function(_a71){
_a6b(_a71,_a6d,this.root.size);
}),onError:_a6c});
}else{
var _a72=this.store;
if(!_a72.isItemLoaded(_a6a)){
var _a73=dojo.hitch(this,arguments.callee);
_a72.loadItem({item:_a6a,onItem:function(_a74){
_a73(_a74,_a6b,_a6c,_a6d);
},onError:_a6c});
return;
}
if(this.serverStore&&!this._isChildrenLoaded(_a6a)){
this.childrenSize=0;
this.store.fetch({start:_a6e,count:_a6f,sort:sort,query:dojo.mixin({parentId:_a70},this.query||{}),onBegin:dojo.hitch(this,function(size){
this.childrenSize=size;
}),onComplete:dojo.hitch(this,function(_a75){
_a6b(_a75,_a6d,this.childrenSize);
}),onError:_a6c});
}else{
this.inherited(arguments);
}
}
}else{
this.inherited(arguments);
}
},_isChildrenLoaded:function(_a76){
var _a77=null;
return dojo.every(this.childrenAttrs,function(attr){
_a77=this.store.getValues(_a76,attr);
return dojo.every(_a77,function(c){
return this.store.isItemLoaded(c);
},this);
},this);
},onNewItem:function(item,_a78){
},onDeleteItem:function(item){
}});
}
if(!dojo._hasResource["dojox.grid.LazyTreeGrid"]){
dojo._hasResource["dojox.grid.LazyTreeGrid"]=true;
dojo.provide("dojox.grid.LazyTreeGrid");
dojo.declare("dojox.grid._LazyExpando",[dijit._Widget,dijit._Templated],{itemId:"",cellIdx:-1,view:null,rowIdx:-1,expandoCell:null,level:0,open:false,templateString:"<div class=\"dojoxGridExpando\"\r\n\t><div class=\"dojoxGridExpandoNode\" dojoAttachEvent=\"onclick:onToggle\"\r\n\t\t><div class=\"dojoxGridExpandoNodeInner\" dojoAttachPoint=\"expandoInner\"></div\r\n\t></div\r\n></div>\r\n",onToggle:function(_a79){
this.view.grid.focus.setFocusIndex(this.rowIdx,this.cellIdx);
this.setOpen(!this.view.grid.cache.getExpandoStatusByRowIndex(this.rowIdx));
try{
dojo.stopEvent(_a79);
}
catch(e){
}
},setOpen:function(open){
var g=this.view.grid,item=g.cache.getItemByRowIndex(this.rowIdx);
if(!g.treeModel.mayHaveChildren(item)){
g.stateChangeNode=null;
return;
}
if(item&&!g._loading){
g.stateChangeNode=this.domNode;
g.cache.updateCache(this.rowIdx,{"expandoStatus":open});
g.expandoFetch(this.rowIdx,open);
this.open=open;
}
this._updateOpenState(item);
},_updateOpenState:function(item){
var grid=this.view.grid;
if(item&&grid.treeModel.mayHaveChildren(item)){
var _a7a=grid.cache.getExpandoStatusByRowIndex(this.rowIdx);
if(this.expandoInner){
this.expandoInner.innerHTML=_a7a?"-":"+";
dojo.toggleClass(this.domNode,"dojoxGridExpandoOpened",_a7a);
this.domNode.parentNode.parentNode.setAttribute("aria-expanded",_a7a);
}
}else{
dojo.removeClass(this.domNode,"dojoxGridExpandoOpened");
}
},setRowNode:function(_a7b,_a7c,view){
if(this.cellIdx<0||!this.itemId){
return false;
}
this._initialized=false;
this.view=view;
this.rowIdx=_a7b;
this.expandoCell=view.structure.cells[0][this.cellIdx];
var _a7d=view.grid.isLeftToRight()?"marginLeft":"marginRight";
dojo.style(this.domNode.parentNode,_a7d,(this.level*1.125)+"em");
this._updateOpenState(view.grid.cache.getItemByRowIndex(this.rowIdx));
return true;
}});
dojo.declare("dojox.grid._TreeGridContentBuilder",dojox.grid._ContentBuilder,{generateHtml:function(_a7e,_a7f){
var html=this.getTableArray(),grid=this.grid,v=this.view,_a80=v.structure.cells,item=grid.getItem(_a7f),_a81=0,_a82=grid.cache.getTreePathByRowIndex(_a7f),_a83=[],_a84=[];
dojox.grid.util.fire(this.view,"onBeforeRow",[_a7f,_a80]);
if(item!==null&&_a82!==null){
_a83=_a82.split("/");
_a81=_a83.length-1;
_a84[0]="dojoxGridRowToggle-"+_a83.join("-");
if(!grid.treeModel.mayHaveChildren(item)){
_a84.push("dojoxGridNoChildren");
}
}
for(var j=0,row;(row=_a80[j]);j++){
if(row.hidden||row.header){
continue;
}
var tr="<tr style=\"\" class=\""+_a84.join(" ")+"\" dojoxTreeGridPath=\""+_a83.join("/")+"\" dojoxTreeGridBaseClasses=\""+_a84.join(" ")+"\">";
html.push(tr);
var k=0,_a85=this._getColSpans(_a81);
var _a86=0,_a87=[];
if(_a85){
dojo.forEach(_a85,function(c){
for(var i=0,cell;(cell=row[i]);i++){
if(i>=c.start&&i<=c.end){
_a86+=this._getCellWidth(row,i);
}
}
_a87.push(_a86);
_a86=0;
},this);
}
for(var i=0,cell,m,cc,cs;(cell=row[i]);i++){
m=cell.markup;
cc=cell.customClasses=[];
cs=cell.customStyles=[];
if(_a85&&_a85[k]&&(i>=_a85[k].start&&i<=_a85[k].end)){
var _a88=_a85[k].primary?_a85[k].primary:_a85[k].start;
if(i===_a88){
m[5]=cell.formatAtLevel(_a83,item,_a81,false,_a84[0],cc,_a7f);
m[1]=cc.join(" ");
var pbm=dojo.marginBox(cell.getHeaderNode()).w-dojo.contentBox(cell.getHeaderNode()).w;
cs=cell.customStyles=["width:"+(_a87[k]-pbm)+"px"];
m[3]=cs.join(";");
html.push.apply(html,m);
}else{
if(i===_a85[k].end){
k++;
continue;
}else{
continue;
}
}
}else{
m[5]=cell.formatAtLevel(_a83,item,_a81,false,_a84[0],cc,_a7f);
m[1]=cc.join(" ");
m[3]=cs.join(";");
html.push.apply(html,m);
}
}
html.push("</tr>");
}
html.push("</table>");
return html.join("");
},_getColSpans:function(_a89){
var _a8a=this.grid.colSpans;
if(_a8a&&(_a8a[_a89])){
return _a8a[_a89];
}else{
return null;
}
},_getCellWidth:function(_a8b,_a8c){
var _a8d=_a8b[_a8c],node=_a8d.getHeaderNode();
if(_a8d.hidden){
return 0;
}
if(_a8c==_a8b.length-1||dojo.every(_a8b.slice(_a8c+1),function(cell){
return cell.hidden;
})){
var _a8e=dojo.position(_a8b[_a8c].view.headerContentNode.firstChild);
return _a8e.x+_a8e.w-dojo.position(node).x;
}else{
var _a8f;
do{
_a8f=_a8b[++_a8c];
}while(_a8f.hidden);
return dojo.position(_a8f.getHeaderNode()).x-dojo.position(node).x;
}
}});
dojo.declare("dojox.grid._TreeGridView",[dojox.grid._View],{_contentBuilderClass:dojox.grid._TreeGridContentBuilder,postCreate:function(){
this.inherited(arguments);
this._expandos={};
this.connect(this.grid,"_cleanupExpandoCache","_cleanupExpandoCache");
},destroy:function(){
this._cleanupExpandoCache();
this.inherited(arguments);
},_cleanupExpandoCache:function(_a90,_a91,item){
if(_a90===-1){
return;
}
dojo.forEach(this.grid.layout.cells,function(cell){
if(cell.openStates&&cell.openStates[_a91]){
delete cell.openStates[_a91];
}
});
for(var i in this._expandos){
if(this._expandos[i]){
this._expandos[i].destroy();
}
}
this._expandos={};
},onAfterRow:function(_a92,_a93,_a94){
dojo.query("span.dojoxGridExpando",_a94).forEach(function(n){
if(n&&n.parentNode){
var idty,_a95,_a96=this.grid._by_idx;
if(_a96&&_a96[_a92]&&_a96[_a92].idty){
idty=_a96[_a92].idty;
_a95=this._expandos[idty];
}
if(_a95){
dojo.place(_a95.domNode,n,"replace");
_a95.itemId=n.getAttribute("itemId");
_a95.cellIdx=parseInt(n.getAttribute("cellIdx"),10);
if(isNaN(_a95.cellIdx)){
_a95.cellIdx=-1;
}
}else{
_a95=dojo.parser.parse(n.parentNode)[0];
if(idty){
this._expandos[idty]=_a95;
}
}
if(!_a95.setRowNode(_a92,_a94,this)){
_a95.domNode.parentNode.removeChild(_a95.domNode);
}
dojo.destroy(n);
}
},this);
this.inherited(arguments);
},updateRow:function(_a97){
var grid=this.grid;
if(grid.keepSelection){
var item=grid.getItem(_a97);
if(item){
grid.selection.preserver._reSelectById(item,_a97);
}
}
this.inherited(arguments);
}});
dojox.grid.cells.LazyTreeCell=dojo.mixin(dojo.clone(dojox.grid.cells.TreeCell),{formatAtLevel:function(_a98,_a99,_a9a,_a9b,_a9c,_a9d,_a9e){
if(!_a99){
return this.formatIndexes(_a9e,_a98,_a99,_a9a);
}
if(!dojo.isArray(_a98)){
_a98=[_a98];
}
var _a9f="";
var ret="";
if(this.isCollapsable){
var _aa0=this.grid.store,id="";
if(_a99&&_aa0.isItem(_a99)){
id=_aa0.getIdentity(_a99);
}
_a9d.push("dojoxGridExpandoCell");
ret="<span "+dojo._scopeName+"Type=\"dojox.grid._LazyExpando\" level=\""+_a9a+"\" class=\"dojoxGridExpando\""+"\" toggleClass=\""+_a9c+"\" itemId=\""+id+"\" cellIdx=\""+this.index+"\"></span>";
}
var _aa1=this.formatIndexes(_a9e,_a98,_a99,_a9a);
_a9f=ret!==""?"<div>"+ret+_aa1+"</div>":_aa1;
if(this.grid.focus.cell&&this.index===this.grid.focus.cell.index&&_a98.join("/")===this.grid.focus.rowIndex){
_a9d.push(this.grid.focus.focusClass);
}
return _a9f;
},formatIndexes:function(_aa2,_aa3,_aa4,_aa5){
var info=this.grid.edit.info,d=this.get?this.get(_aa3[0],_aa4,_aa3):(this.value||this.defaultValue);
if(this.editable&&(this.alwaysEditing||(info.rowIndex===_aa3[0]&&info.cell===this))){
return this.formatEditing(d,_aa2,_aa3);
}else{
return this._defaultFormat(d,[d,_aa2,_aa5,this]);
}
}});
dojo.declare("dojox.grid._LazyTreeLayout",dojox.grid._Layout,{setStructure:function(_aa6){
var s=_aa6;
var g=this.grid;
if(g&&!dojo.every(s,function(i){
return ("cells" in i);
})){
s=arguments[0]=[{cells:[s]}];
}
if(s.length===1&&s[0].cells.length===1){
s[0].type="dojox.grid._TreeGridView";
this._isCollapsable=true;
s[0].cells[0][this.grid.expandoCell].isCollapsable=true;
}
this.inherited(arguments);
},addCellDef:function(_aa7,_aa8,_aa9){
var obj=this.inherited(arguments);
return dojo.mixin(obj,dojox.grid.cells.LazyTreeCell);
}});
dojo.declare("dojox.grid.TreeGridItemCache",null,{unInit:true,items:null,constructor:function(grid){
this.rowsPerPage=grid.rowsPerPage;
if(grid.defaultState&&grid.defaultState.cachedItems){
this.unInit=false;
this.items=grid.defaultState.cachedItems;
}else{
this._buildCache(grid.rowsPerPage);
}
},_buildCache:function(size){
this.items=[];
for(var i=0;i<size;i++){
this.cacheItem(i,{item:null,treePath:i+"",expandoStatus:false});
}
},cacheItem:function(_aaa,_aab){
this.items[_aaa]=dojo.mixin({item:null,treePath:"",expandoStatus:false},_aab);
},insertItem:function(_aac,_aad){
this.items.splice(_aac,0,dojo.mixin({item:null,treePath:"",expandoStatus:false},_aad));
},initCache:function(size){
if(!this.unInit){
return;
}
this._buildCache(size);
this.unInit=false;
},getItemByRowIndex:function(_aae){
return this.items[_aae]?this.items[_aae].item:null;
},getItemByTreePath:function(_aaf){
for(var i=0,len=this.items.length;i<len;i++){
if(this.items[i].treePath===_aaf){
return this.items[i].item;
}
}
return null;
},getTreePathByRowIndex:function(_ab0){
return this.items[_ab0]?this.items[_ab0].treePath:null;
},getExpandoStatusByRowIndex:function(_ab1){
return this.items[_ab1]?this.items[_ab1].expandoStatus:null;
},getInfoByItem:function(item){
for(var i=0,len=this.items.length;i<len;i++){
if(this.items[i].item===item){
return dojo.mixin({rowIdx:i},this.items[i]);
}
}
return null;
},updateCache:function(_ab2,_ab3){
if(this.items[_ab2]){
dojo.mixin(this.items[_ab2],_ab3);
}
},deleteItem:function(_ab4){
if(this.items[_ab4]){
var _ab5=this.items[_ab4].treePath,i=_ab4,_ab6,_ab7=_ab5.indexOf("/")>0?_ab5.substring(0,_ab5.lastIndexOf("/")+1):"";
for(;i<this.items.length;i++){
if(this.items[i].treePath.indexOf(_ab7+"/")==0){
_ab6=this.items[i].treePath.substring(_ab7.length).split("/");
_ab6[0]=parseInt(_ab6[0],10)-1;
this.updateCache(i,{treePath:_ab7+_ab6.join("/")});
}else{
break;
}
}
this.items.splice(_ab4,1);
}
},cleanChildren:function(_ab8){
var _ab9=this.getTreePathByRowIndex(_ab8);
var _aba=0,i=this.items.length-1;
for(;i>=0;i--){
if(this.items[i].treePath.indexOf(_ab9+"/")===0&&this.items[i].treePath!==_ab9){
this.items.splice(i,1);
_aba++;
}
}
return _aba;
},emptyCache:function(){
this.unInit=true;
this._buildCache(this.rowsPerPage);
},cleanupCache:function(){
this.items=null;
},getCurrentCacheItems:function(){
var _abb=[];
dojo.forEach(this.items,function(item,idx){
_abb[idx]={item:item.item,treePath:item.treePath,expandoStatus:item.expandoStatus};
});
return _abb;
}});
dojo.declare("dojox.grid.LazyTreeGrid",dojox.grid.TreeGrid,{treeModel:null,_layoutClass:dojox.grid._LazyTreeLayout,defaultState:null,colSpans:null,postCreate:function(){
this._setState();
this.inherited(arguments);
this.cache=new dojox.grid.TreeGridItemCache(this);
if(!this.treeModel||!(this.treeModel instanceof dijit.tree.ForestStoreModel)){
throw new Error("dojox.grid.LazyTreeGrid: must use a treeModel and treeModel must be an instance of dijit.tree.ForestStoreModel");
}
dojo.addClass(this.domNode,"dojoxGridTreeModel");
dojo.setSelectable(this.domNode,this.selectable);
},createManagers:function(){
this.rows=new dojox.grid._RowManager(this);
this.focus=new dojox.grid._FocusManager(this);
this.edit=new dojox.grid._EditManager(this);
},createSelection:function(){
this.selection=new dojox.grid.DataSelection(this);
},setModel:function(_abc){
if(!_abc){
return;
}
this._setModel(_abc);
this._cleanup();
this._refresh(true);
},setStore:function(_abd,_abe,_abf){
if(!_abd){
return;
}
this._setQuery(_abe,_abf);
this.treeModel.query=_abe;
this.treeModel.store=_abd;
this.treeModel.root.children=[];
this.setModel(this.treeModel);
},canSort:function(){
return (!this._loading);
},onSetState:function(){
},_setState:function(){
if(this.defaultState){
this.sortInfo=this.defaultState.sortInfo||0;
this.query=this.defaultState.query||this.query;
this._lastScrollTop=this.defaultState.scrollTop;
if(this.keepSelection){
this.selection.preserver._selectedById=this.defaultState.selection;
}else{
this.selection.selected=this.defaultState.selection||[];
}
this.onSetState();
}
},getState:function(){
var _ac0=this;
var _ac1=this.keepSelection?this.selection.preserver._selectedById:this.selection.selected;
return {cachedItems:_ac0.cache.getCurrentCacheItems(),query:_ac0.query,sortInfo:_ac0.sortInfo,scrollTop:_ac0.scrollTop,selection:_ac1};
},_setQuery:function(_ac2,_ac3){
this.inherited(arguments);
this.treeModel.query=_ac2;
},destroy:function(){
this._cleanup();
this.inherited(arguments);
},_cleanup:function(){
this.cache.emptyCache();
this._cleanupExpandoCache();
},setSortIndex:function(_ac4,_ac5){
if(this.canSort(_ac4+1)){
this._cleanup();
}
this.inherited(arguments);
},_refresh:function(_ac6){
this._clearData();
this.updateRowCount(this.cache.items.length);
this._fetch(0,true);
},_updateChangedRows:function(_ac7){
dojo.forEach(this.scroller.stack,function(p){
if(p*this.rowsPerPage>=_ac7){
this.updateRows(p*this.rowsPerPage,this.rowsPerPage);
}else{
if((p+1)*this.rowsPerPage>=_ac7){
this.updateRows(_ac7,(p+1)*this.rowsPerPage-_ac7+1);
}
}
},this);
},render:function(){
this.inherited(arguments);
this.setScrollTop(this.scrollTop);
},_onNew:function(item,_ac8){
var _ac9=false,info,_aca=this.cache.items;
if(_ac8&&this.store.isItem(_ac8.item)&&dojo.some(this.treeModel.childrenAttrs,function(c){
return c===_ac8.attribute;
})){
_ac9=true;
info=this.cache.getInfoByItem(_ac8.item);
}
if(!_ac9){
this.inherited(arguments);
var _acb=_aca.length>0?String(parseInt(_aca[_aca.length-1].treePath.split("/")[0],10)+1):"0";
this.cache.insertItem(this.get("rowCount"),{item:item,treePath:_acb,expandoStatus:false});
}else{
if(info&&info.expandoStatus&&info.rowIdx>=0){
var _acc=info.childrenNum;
var _acd=info.treePath+"/"+_acc;
var _ace={item:item,treePath:_acd,expandoStatus:false};
var _acf=info.rowIdx+1;
for(;_acf<this.cache.items.length;_acf++){
if(!this.cache.items[_acf]||this.cache.items[_acf].treePath.indexOf(info.treePath+"/")!=0){
break;
}
}
this.cache.insertItem(_acf,_ace);
this.cache.updateCache(info.rowIdx,{childrenNum:_acc+1});
var idty=this.store.getIdentity(item);
this._by_idty[idty]={idty:idty,item:item};
this._by_idx.splice(_acf,0,this._by_idty[idty]);
this.updateRowCount(_aca.length);
this._updateChangedRows(_acf);
}else{
if(info&&info.rowIdx>=0){
this.updateRow(info.rowIdx);
}
}
}
},_onDelete:function(item){
var info=this.cache.getInfoByItem(item),i;
if(info&&info.rowIdx>=0){
if(this.selection.isSelected(info.rowIdx)){
this.selection.deselect(info.rowIdx);
this.selection.selected.splice(info.rowIdx,1);
}
if(info.expandoStatus){
var num=this.cache.cleanChildren(info.rowIdx);
this._by_idx.splice(info.rowIdx+1,num);
}
if(info.treePath.indexOf("/")>0){
var _ad0=info.treePath.substring(0,info.treePath.lastIndexOf("/"));
for(i=info.rowIdx;i>=0;i--){
if(this.cache.items[i].treePath===_ad0){
this.cache.items[i].childrenNum--;
break;
}
}
}
this.cache.deleteItem(info.rowIdx);
this._by_idx.splice(info.rowIdx,1);
this.updateRowCount(this.cache.items.length);
this._updateChangedRows(info.rowIdx);
}
},_cleanupExpandoCache:function(_ad1,_ad2,item){
},_fetch:function(_ad3,_ad4){
if(!this._loading){
this._loading=true;
}
_ad3=_ad3||0;
this.reqQueue=[];
var i=0,_ad5=[];
var _ad6=Math.min(this.rowsPerPage,this.cache.items.length-_ad3);
for(i=_ad3;i<_ad3+_ad6;i++){
if(this.cache.getItemByRowIndex(i)){
_ad5.push(this.cache.getItemByRowIndex(i));
}else{
break;
}
}
if(_ad5.length===_ad6){
this._reqQueueLen=1;
this._onFetchBegin(this.cache.items.length,{startRowIdx:_ad3,count:_ad6});
this._onFetchComplete(_ad5,{startRowIdx:_ad3,count:_ad6});
}else{
this.reqQueueIndex=0;
var _ad7="",_ad8="",_ad9=_ad3,_ada=this.cache.getTreePathByRowIndex(_ad3);
_ad6=0;
for(i=_ad3+1;i<_ad3+this.rowsPerPage;i++){
if(!this.cache.getTreePathByRowIndex(i)){
break;
}
_ad7=this.cache.getTreePathByRowIndex(i-1).split("/").length-1;
_ad8=this.cache.getTreePathByRowIndex(i).split("/").length-1;
if(_ad7!==_ad8){
this.reqQueue.push({startTreePath:_ada,startRowIdx:_ad9,count:_ad6+1});
_ad6=0;
_ad9=i;
_ada=this.cache.getTreePathByRowIndex(i);
}else{
_ad6++;
}
}
this.reqQueue.push({startTreePath:_ada,startRowIdx:_ad9,count:_ad6+1});
this._reqQueueLen=this.reqQueue.length;
for(i=0;i<this.reqQueue.length;i++){
this._fetchItems(i,dojo.hitch(this,"_onFetchBegin"),dojo.hitch(this,"_onFetchComplete"),dojo.hitch(this,"_onFetchError"));
}
}
},_fetchItems:function(idx,_adb,_adc,_add){
if(this._pending_requests[this.reqQueue[idx].startRowIdx]){
return;
}
this.showMessage(this.loadingMessage);
var _ade=this.reqQueue[idx].startTreePath.split("/").length-1;
this._pending_requests[this.reqQueue[idx].startRowIdx]=true;
if(_ade===0){
this.store.fetch({start:parseInt(this.reqQueue[idx].startTreePath,10),startRowIdx:this.reqQueue[idx].startRowIdx,count:this.reqQueue[idx].count,query:this.query,sort:this.getSortProps(),queryOptions:this.queryOptions,onBegin:_adb,onComplete:_adc,onError:_add});
}else{
var _adf=this.reqQueue[idx].startTreePath;
var _ae0=_adf.substring(0,_adf.lastIndexOf("/"));
var _ae1=_adf.substring(_adf.lastIndexOf("/")+1);
var _ae2=this.cache.getItemByTreePath(_ae0);
if(!_ae2){
throw new Error("Lazy loading TreeGrid on fetch error:");
}
var _ae3=this.store.getIdentity(_ae2);
var _ae4={start:parseInt(_ae1,10),startRowIdx:this.reqQueue[idx].startRowIdx,count:this.reqQueue[idx].count,parentId:_ae3,sort:this.getSortProps()};
var _ae5=this;
var _ae6=function(){
if(arguments.length==1){
_adc.apply(_ae5,[arguments[0],_ae4]);
}else{
_adc.apply(_ae5,arguments);
}
};
this.treeModel.getChildren(_ae2,_ae6,_add,_ae4);
}
},_onFetchBegin:function(size,_ae7){
this.cache.initCache(size);
size=this.cache.items.length;
this.inherited(arguments);
},filter:function(_ae8,_ae9){
this.cache.emptyCache();
this.inherited(arguments);
},_onFetchComplete:function(_aea,_aeb,size){
var _aec="",_aed=_aeb.startRowIdx,_aee=_aeb.count,_aef=_aea.length<=_aee?0:_aeb.start;
if(_aea&&_aea.length>0){
var i;
for(i=0;i<_aee;i++){
_aec=this.cache.getTreePathByRowIndex(_aed+i);
if(_aec){
if(!this.cache.getItemByRowIndex(_aed+i)){
this.cache.cacheItem(_aed+i,{item:_aea[_aef+i],treePath:_aec,expandoStatus:this.cache.getExpandoStatusByRowIndex(_aed+i)});
}
}
}
if(!this.scroller){
return;
}
var len=Math.min(_aee,_aea.length);
for(i=0;i<len;i++){
this._addItem(_aea[_aef+i],_aed+i,true);
}
this.updateRows(_aed,len);
}
if(!this.cache.items.length){
this.showMessage(this.noDataMessage);
}else{
this.showMessage();
}
this._pending_requests[_aed]=false;
this._reqQueueLen--;
if(this._loading&&this._reqQueueLen===0){
this._loading=false;
if(this._lastScrollTop){
this.setScrollTop(this._lastScrollTop);
}
}
delete this._lastScrollTop;
},expandoFetch:function(_af0,open){
if(this._loading){
return;
}
this._loading=true;
this.toggleLoadingClass(true);
var item=this.cache.getItemByRowIndex(_af0);
this.expandoRowIndex=_af0;
this._pages=[];
if(open){
var _af1=this.store.getIdentity(item);
var _af2={start:0,count:this.rowsPerPage,parentId:_af1,sort:this.getSortProps()};
this.treeModel.getChildren(item,dojo.hitch(this,"_onExpandoComplete"),dojo.hitch(this,"_onFetchError"),_af2);
}else{
var num=this.cache.cleanChildren(_af0);
this._by_idx.splice(_af0+1,num);
this._bop=this._eop=-1;
this.updateRowCount(this.cache.items.length);
this._updateChangedRows(_af0+1);
this.toggleLoadingClass(false);
if(this._loading){
this._loading=false;
}
this.focus._delayedCellFocus();
}
},_onExpandoComplete:function(_af3,_af4,size){
var _af5=this.cache.getTreePathByRowIndex(this.expandoRowIndex);
if(size&&!isNaN(parseInt(size,10))){
size=parseInt(size,10);
}else{
size=_af3.length;
}
var i,j=0,len=this._by_idx.length;
for(i=this.expandoRowIndex+1;j<size;i++,j++){
this.cache.insertItem(i,{item:null,treePath:_af5+"/"+j,expandoStatus:false});
}
this.updateRowCount(this.cache.items.length);
this.cache.updateCache(this.expandoRowIndex,{childrenNum:size});
for(i=0;i<size;i++){
this.cache.updateCache(this.expandoRowIndex+1+i,{item:_af3[i]});
}
for(i=0;i<size;i++){
this._by_idx.splice(this.expandoRowIndex+1+i,0,null);
}
for(i=0;i<Math.min(size,this.rowsPerPage);i++){
var idty=this.store.getIdentity(_af3[i]);
this._by_idty[idty]={idty:idty,item:_af3[i]};
this._by_idx.splice(this.expandoRowIndex+1+i,1,this._by_idty[idty]);
}
this._updateChangedRows(this.expandoRowIndex+1);
this.toggleLoadingClass(false);
this.stateChangeNode=null;
if(this._loading){
this._loading=false;
}
this.focus._delayedCellFocus();
},toggleLoadingClass:function(flag){
if(this.stateChangeNode){
dojo.toggleClass(this.stateChangeNode,"dojoxGridExpandoLoading",flag);
}
},styleRowNode:function(_af6,_af7){
if(_af7){
this.rows.styleRowNode(_af6,_af7);
}
},onStyleRow:function(row){
if(!this.layout._isCollapsable){
this.inherited(arguments);
return;
}
var base=dojo.attr(row.node,"dojoxTreeGridBaseClasses");
if(base){
row.customClasses=base;
}
var i=row;
i.customClasses+=(i.odd?" dojoxGridRowOdd":"")+(i.selected?" dojoxGridRowSelected":"")+(i.over?" dojoxGridRowOver":"");
this.focus.styleRow(i);
this.edit.styleRow(i);
},dokeydown:function(e){
if(e.altKey||e.metaKey){
return;
}
var dk=dojo.keys,_af8=dijit.findWidgets(e.target)[0];
if(e.keyCode===dk.ENTER&&_af8 instanceof dojox.grid._LazyExpando){
_af8.onToggle();
}
this.onKeyDown(e);
}});
dojox.grid.LazyTreeGrid.markupFactory=function(_af9,node,ctor,_afa){
return dojox.grid.TreeGrid.markupFactory(_af9,node,ctor,_afa);
};
}
if(!dojo._hasResource["dijit.Calendar"]){
dojo._hasResource["dijit.Calendar"]=true;
dojo.provide("dijit.Calendar");
dojo.declare("dijit.Calendar",[dijit._Widget,dijit._Templated,dijit._CssStateMixin],{templateString:dojo.cache("dijit","templates/Calendar.html","<table cellspacing=\"0\" cellpadding=\"0\" class=\"dijitCalendarContainer\" role=\"grid\" dojoAttachEvent=\"onkeypress: _onKeyPress\" aria-labelledby=\"${id}_year\">\r\n\t<thead>\r\n\t\t<tr class=\"dijitReset dijitCalendarMonthContainer\" valign=\"top\">\r\n\t\t\t<th class='dijitReset dijitCalendarArrow' dojoAttachPoint=\"decrementMonth\">\r\n\t\t\t\t<img src=\"${_blankGif}\" alt=\"\" class=\"dijitCalendarIncrementControl dijitCalendarDecrease\" role=\"presentation\"/>\r\n\t\t\t\t<span dojoAttachPoint=\"decreaseArrowNode\" class=\"dijitA11ySideArrow\">-</span>\r\n\t\t\t</th>\r\n\t\t\t<th class='dijitReset' colspan=\"5\">\r\n\t\t\t\t<div dojoType=\"dijit.form.DropDownButton\" dojoAttachPoint=\"monthDropDownButton\"\r\n\t\t\t\t\tid=\"${id}_mddb\" tabIndex=\"-1\">\r\n\t\t\t\t</div>\r\n\t\t\t</th>\r\n\t\t\t<th class='dijitReset dijitCalendarArrow' dojoAttachPoint=\"incrementMonth\">\r\n\t\t\t\t<img src=\"${_blankGif}\" alt=\"\" class=\"dijitCalendarIncrementControl dijitCalendarIncrease\" role=\"presentation\"/>\r\n\t\t\t\t<span dojoAttachPoint=\"increaseArrowNode\" class=\"dijitA11ySideArrow\">+</span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<th class=\"dijitReset dijitCalendarDayLabelTemplate\" role=\"columnheader\"><span class=\"dijitCalendarDayLabel\"></span></th>\r\n\t\t</tr>\r\n\t</thead>\r\n\t<tbody dojoAttachEvent=\"onclick: _onDayClick, onmouseover: _onDayMouseOver, onmouseout: _onDayMouseOut, onmousedown: _onDayMouseDown, onmouseup: _onDayMouseUp\" class=\"dijitReset dijitCalendarBodyContainer\">\r\n\t\t<tr class=\"dijitReset dijitCalendarWeekTemplate\" role=\"row\">\r\n\t\t\t<td class=\"dijitReset dijitCalendarDateTemplate\" role=\"gridcell\"><span class=\"dijitCalendarDateLabel\"></span></td>\r\n\t\t</tr>\r\n\t</tbody>\r\n\t<tfoot class=\"dijitReset dijitCalendarYearContainer\">\r\n\t\t<tr>\r\n\t\t\t<td class='dijitReset' valign=\"top\" colspan=\"7\">\r\n\t\t\t\t<h3 class=\"dijitCalendarYearLabel\">\r\n\t\t\t\t\t<span dojoAttachPoint=\"previousYearLabelNode\" class=\"dijitInline dijitCalendarPreviousYear\"></span>\r\n\t\t\t\t\t<span dojoAttachPoint=\"currentYearLabelNode\" class=\"dijitInline dijitCalendarSelectedYear\" id=\"${id}_year\"></span>\r\n\t\t\t\t\t<span dojoAttachPoint=\"nextYearLabelNode\" class=\"dijitInline dijitCalendarNextYear\"></span>\r\n\t\t\t\t</h3>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t</tfoot>\r\n</table>\r\n"),widgetsInTemplate:true,value:new Date(""),datePackage:"dojo.date",dayWidth:"narrow",tabIndex:"0",currentFocus:new Date(),baseClass:"dijitCalendar",cssStateNodes:{"decrementMonth":"dijitCalendarArrow","incrementMonth":"dijitCalendarArrow","previousYearLabelNode":"dijitCalendarPreviousYear","nextYearLabelNode":"dijitCalendarNextYear"},_isValidDate:function(_afb){
return _afb&&!isNaN(_afb)&&typeof _afb=="object"&&_afb.toString()!=this.constructor.prototype.value.toString();
},setValue:function(_afc){
dojo.deprecated("dijit.Calendar:setValue() is deprecated.  Use set('value', ...) instead.","","2.0");
this.set("value",_afc);
},_getValueAttr:function(){
var _afd=new this.dateClassObj(this.value);
_afd.setHours(0,0,0,0);
if(_afd.getDate()<this.value.getDate()){
_afd=this.dateFuncObj.add(_afd,"hour",1);
}
return _afd;
},_setValueAttr:function(_afe,_aff){
if(_afe){
_afe=new this.dateClassObj(_afe);
}
if(this._isValidDate(_afe)){
if(!this._isValidDate(this.value)||this.dateFuncObj.compare(_afe,this.value)){
_afe.setHours(1,0,0,0);
if(!this.isDisabledDate(_afe,this.lang)){
this._set("value",_afe);
this.set("currentFocus",_afe);
if(_aff||typeof _aff=="undefined"){
this.onChange(this.get("value"));
this.onValueSelected(this.get("value"));
}
}
}
}else{
this._set("value",null);
this.set("currentFocus",this.currentFocus);
}
},_setText:function(node,text){
while(node.firstChild){
node.removeChild(node.firstChild);
}
node.appendChild(dojo.doc.createTextNode(text));
},_populateGrid:function(){
var _b00=new this.dateClassObj(this.currentFocus);
_b00.setDate(1);
var _b01=_b00.getDay(),_b02=this.dateFuncObj.getDaysInMonth(_b00),_b03=this.dateFuncObj.getDaysInMonth(this.dateFuncObj.add(_b00,"month",-1)),_b04=new this.dateClassObj(),_b05=dojo.cldr.supplemental.getFirstDayOfWeek(this.lang);
if(_b05>_b01){
_b05-=7;
}
dojo.query(".dijitCalendarDateTemplate",this.domNode).forEach(function(_b06,i){
i+=_b05;
var date=new this.dateClassObj(_b00),_b07,_b08="dijitCalendar",adj=0;
if(i<_b01){
_b07=_b03-_b01+i+1;
adj=-1;
_b08+="Previous";
}else{
if(i>=(_b01+_b02)){
_b07=i-_b01-_b02+1;
adj=1;
_b08+="Next";
}else{
_b07=i-_b01+1;
_b08+="Current";
}
}
if(adj){
date=this.dateFuncObj.add(date,"month",adj);
}
date.setDate(_b07);
if(!this.dateFuncObj.compare(date,_b04,"date")){
_b08="dijitCalendarCurrentDate "+_b08;
}
if(this._isSelectedDate(date,this.lang)){
_b08="dijitCalendarSelectedDate "+_b08;
}
if(this.isDisabledDate(date,this.lang)){
_b08="dijitCalendarDisabledDate "+_b08;
}
var _b09=this.getClassForDate(date,this.lang);
if(_b09){
_b08=_b09+" "+_b08;
}
_b06.className=_b08+"Month dijitCalendarDateTemplate";
_b06.dijitDateValue=date.valueOf();
dojo.attr(_b06,"dijitDateValue",date.valueOf());
var _b0a=dojo.query(".dijitCalendarDateLabel",_b06)[0],text=date.getDateLocalized?date.getDateLocalized(this.lang):date.getDate();
this._setText(_b0a,text);
},this);
var _b0b=this.dateLocaleModule.getNames("months","wide","standAlone",this.lang,_b00);
this.monthDropDownButton.dropDown.set("months",_b0b);
this.monthDropDownButton.containerNode.innerHTML=(dojo.isIE==6?"":"<div class='dijitSpacer'>"+this.monthDropDownButton.dropDown.domNode.innerHTML+"</div>")+"<div class='dijitCalendarMonthLabel dijitCalendarCurrentMonthLabel'>"+_b0b[_b00.getMonth()]+"</div>";
var y=_b00.getFullYear()-1;
var d=new this.dateClassObj();
dojo.forEach(["previous","current","next"],function(name){
d.setFullYear(y++);
this._setText(this[name+"YearLabelNode"],this.dateLocaleModule.format(d,{selector:"year",locale:this.lang}));
},this);
},goToToday:function(){
this.set("value",new this.dateClassObj());
},constructor:function(args){
var _b0c=(args.datePackage&&(args.datePackage!="dojo.date"))?args.datePackage+".Date":"Date";
this.dateClassObj=dojo.getObject(_b0c,false);
this.datePackage=args.datePackage||this.datePackage;
this.dateFuncObj=dojo.getObject(this.datePackage,false);
this.dateLocaleModule=dojo.getObject(this.datePackage+".locale",false);
},postMixInProperties:function(){
if(isNaN(this.value)){
delete this.value;
}
this.inherited(arguments);
},buildRendering:function(){
this.inherited(arguments);
dojo.setSelectable(this.domNode,false);
var _b0d=dojo.hitch(this,function(_b0e,n){
var _b0f=dojo.query(_b0e,this.domNode)[0];
for(var i=0;i<n;i++){
_b0f.parentNode.appendChild(_b0f.cloneNode(true));
}
});
_b0d(".dijitCalendarDayLabelTemplate",6);
_b0d(".dijitCalendarDateTemplate",6);
_b0d(".dijitCalendarWeekTemplate",5);
var _b10=this.dateLocaleModule.getNames("days",this.dayWidth,"standAlone",this.lang);
var _b11=dojo.cldr.supplemental.getFirstDayOfWeek(this.lang);
dojo.query(".dijitCalendarDayLabel",this.domNode).forEach(function(_b12,i){
this._setText(_b12,_b10[(i+_b11)%7]);
},this);
var _b13=new this.dateClassObj(this.currentFocus);
this.monthDropDownButton.dropDown=new dijit.Calendar._MonthDropDown({id:this.id+"_mdd",onChange:dojo.hitch(this,"_onMonthSelect")});
this.set("currentFocus",_b13,false);
var _b14=this;
var _b15=function(_b16,_b17,adj){
_b14._connects.push(dijit.typematic.addMouseListener(_b14[_b16],_b14,function(_b18){
if(_b18>=0){
_b14._adjustDisplay(_b17,adj);
}
},0.8,500));
};
_b15("incrementMonth","month",1);
_b15("decrementMonth","month",-1);
_b15("nextYearLabelNode","year",1);
_b15("previousYearLabelNode","year",-1);
},_adjustDisplay:function(part,_b19){
this._setCurrentFocusAttr(this.dateFuncObj.add(this.currentFocus,part,_b19));
},_setCurrentFocusAttr:function(date,_b1a){
var _b1b=this.currentFocus,_b1c=_b1b?dojo.query("[dijitDateValue="+_b1b.valueOf()+"]",this.domNode)[0]:null;
date=new this.dateClassObj(date);
date.setHours(1,0,0,0);
this._set("currentFocus",date);
this._populateGrid();
var _b1d=dojo.query("[dijitDateValue="+date.valueOf()+"]",this.domNode)[0];
_b1d.setAttribute("tabIndex",this.tabIndex);
if(this._focused||_b1a){
_b1d.focus();
}
if(_b1c&&_b1c!=_b1d){
if(dojo.isWebKit){
_b1c.setAttribute("tabIndex","-1");
}else{
_b1c.removeAttribute("tabIndex");
}
}
},focus:function(){
this._setCurrentFocusAttr(this.currentFocus,true);
},_onMonthSelect:function(_b1e){
this.currentFocus=this.dateFuncObj.add(this.currentFocus,"month",_b1e-this.currentFocus.getMonth());
this._populateGrid();
},_onDayClick:function(evt){
dojo.stopEvent(evt);
for(var node=evt.target;node&&!node.dijitDateValue;node=node.parentNode){
}
if(node&&!dojo.hasClass(node,"dijitCalendarDisabledDate")){
this.set("value",node.dijitDateValue);
}
},_onDayMouseOver:function(evt){
var node=dojo.hasClass(evt.target,"dijitCalendarDateLabel")?evt.target.parentNode:evt.target;
if(node&&(node.dijitDateValue||node==this.previousYearLabelNode||node==this.nextYearLabelNode)){
dojo.addClass(node,"dijitCalendarHoveredDate");
this._currentNode=node;
}
},_onDayMouseOut:function(evt){
if(!this._currentNode){
return;
}
if(evt.relatedTarget&&evt.relatedTarget.parentNode==this._currentNode){
return;
}
var cls="dijitCalendarHoveredDate";
if(dojo.hasClass(this._currentNode,"dijitCalendarActiveDate")){
cls+=" dijitCalendarActiveDate";
}
dojo.removeClass(this._currentNode,cls);
this._currentNode=null;
},_onDayMouseDown:function(evt){
var node=evt.target.parentNode;
if(node&&node.dijitDateValue){
dojo.addClass(node,"dijitCalendarActiveDate");
this._currentNode=node;
}
},_onDayMouseUp:function(evt){
var node=evt.target.parentNode;
if(node&&node.dijitDateValue){
dojo.removeClass(node,"dijitCalendarActiveDate");
}
},handleKey:function(evt){
var dk=dojo.keys,_b1f=-1,_b20,_b21=this.currentFocus;
switch(evt.keyCode){
case dk.RIGHT_ARROW:
_b1f=1;
case dk.LEFT_ARROW:
_b20="day";
if(!this.isLeftToRight()){
_b1f*=-1;
}
break;
case dk.DOWN_ARROW:
_b1f=1;
case dk.UP_ARROW:
_b20="week";
break;
case dk.PAGE_DOWN:
_b1f=1;
case dk.PAGE_UP:
_b20=evt.ctrlKey||evt.altKey?"year":"month";
break;
case dk.END:
_b21=this.dateFuncObj.add(_b21,"month",1);
_b20="day";
case dk.HOME:
_b21=new this.dateClassObj(_b21);
_b21.setDate(1);
break;
case dk.ENTER:
case dk.SPACE:
this.set("value",this.currentFocus);
break;
default:
return true;
}
if(_b20){
_b21=this.dateFuncObj.add(_b21,_b20,_b1f);
}
this._setCurrentFocusAttr(_b21);
return false;
},_onKeyPress:function(evt){
if(!this.handleKey(evt)){
dojo.stopEvent(evt);
}
},onValueSelected:function(date){
},onChange:function(date){
},_isSelectedDate:function(_b22,_b23){
return this._isValidDate(this.value)&&!this.dateFuncObj.compare(_b22,this.value,"date");
},isDisabledDate:function(_b24,_b25){
},getClassForDate:function(_b26,_b27){
}});
dojo.declare("dijit.Calendar._MonthDropDown",[dijit._Widget,dijit._Templated],{months:[],templateString:"<div class='dijitCalendarMonthMenu dijitMenu' "+"dojoAttachEvent='onclick:_onClick,onmouseover:_onMenuHover,onmouseout:_onMenuHover'></div>",_setMonthsAttr:function(_b28){
this.domNode.innerHTML=dojo.map(_b28,function(_b29,idx){
return _b29?"<div class='dijitCalendarMonthLabel' month='"+idx+"'>"+_b29+"</div>":"";
}).join("");
},_onClick:function(evt){
this.onChange(dojo.attr(evt.target,"month"));
},onChange:function(_b2a){
},_onMenuHover:function(evt){
dojo.toggleClass(evt.target,"dijitCalendarMonthLabelHover",evt.type=="mouseover");
}});
}
if(!dojo._hasResource["dijit.form.TextBox"]){
dojo._hasResource["dijit.form.TextBox"]=true;
dojo.provide("dijit.form.TextBox");
dojo.declare("dijit.form.TextBox",dijit.form._FormValueWidget,{trim:false,uppercase:false,lowercase:false,propercase:false,maxLength:"",selectOnClick:false,placeHolder:"",templateString:dojo.cache("dijit.form","templates/TextBox.html","<div class=\"dijit dijitReset dijitInline dijitLeft\" id=\"widget_${id}\" role=\"presentation\"\r\n\t><div class=\"dijitReset dijitInputField dijitInputContainer\"\r\n\t\t><input class=\"dijitReset dijitInputInner\" dojoAttachPoint='textbox,focusNode' autocomplete=\"off\"\r\n\t\t\t${!nameAttrSetting} type='${type}'\r\n\t/></div\r\n></div>\r\n"),_singleNodeTemplate:"<input class=\"dijit dijitReset dijitLeft dijitInputField\" dojoAttachPoint=\"textbox,focusNode\" autocomplete=\"off\" type=\"${type}\" ${!nameAttrSetting} />",_buttonInputDisabled:dojo.isIE?"disabled":"",baseClass:"dijitTextBox",attributeMap:dojo.delegate(dijit.form._FormValueWidget.prototype.attributeMap,{maxLength:"focusNode"}),postMixInProperties:function(){
var type=this.type.toLowerCase();
if(this.templateString&&this.templateString.toLowerCase()=="input"||((type=="hidden"||type=="file")&&this.templateString==dijit.form.TextBox.prototype.templateString)){
this.templateString=this._singleNodeTemplate;
}
this.inherited(arguments);
},_setPlaceHolderAttr:function(v){
this._set("placeHolder",v);
if(!this._phspan){
this._attachPoints.push("_phspan");
this._phspan=dojo.create("span",{className:"dijitPlaceHolder dijitInputField"},this.textbox,"after");
}
this._phspan.innerHTML="";
this._phspan.appendChild(document.createTextNode(v));
this._updatePlaceHolder();
},_updatePlaceHolder:function(){
if(this._phspan){
this._phspan.style.display=(this.placeHolder&&!this._focused&&!this.textbox.value)?"":"none";
}
},_getValueAttr:function(){
return this.parse(this.get("displayedValue"),this.constraints);
},_setValueAttr:function(_b2b,_b2c,_b2d){
var _b2e;
if(_b2b!==undefined){
_b2e=this.filter(_b2b);
if(typeof _b2d!="string"){
if(_b2e!==null&&((typeof _b2e!="number")||!isNaN(_b2e))){
_b2d=this.filter(this.format(_b2e,this.constraints));
}else{
_b2d="";
}
}
}
if(_b2d!=null&&_b2d!=undefined&&((typeof _b2d)!="number"||!isNaN(_b2d))&&this.textbox.value!=_b2d){
this.textbox.value=_b2d;
this._set("displayedValue",this.get("displayedValue"));
}
this._updatePlaceHolder();
this.inherited(arguments,[_b2e,_b2c]);
},displayedValue:"",getDisplayedValue:function(){
dojo.deprecated(this.declaredClass+"::getDisplayedValue() is deprecated. Use set('displayedValue') instead.","","2.0");
return this.get("displayedValue");
},_getDisplayedValueAttr:function(){
return this.filter(this.textbox.value);
},setDisplayedValue:function(_b2f){
dojo.deprecated(this.declaredClass+"::setDisplayedValue() is deprecated. Use set('displayedValue', ...) instead.","","2.0");
this.set("displayedValue",_b2f);
},_setDisplayedValueAttr:function(_b30){
if(_b30===null||_b30===undefined){
_b30="";
}else{
if(typeof _b30!="string"){
_b30=String(_b30);
}
}
this.textbox.value=_b30;
this._setValueAttr(this.get("value"),undefined);
this._set("displayedValue",this.get("displayedValue"));
},format:function(_b31,_b32){
return ((_b31==null||_b31==undefined)?"":(_b31.toString?_b31.toString():_b31));
},parse:function(_b33,_b34){
return _b33;
},_refreshState:function(){
},_onInput:function(e){
if(e&&e.type&&/key/i.test(e.type)&&e.keyCode){
switch(e.keyCode){
case dojo.keys.SHIFT:
case dojo.keys.ALT:
case dojo.keys.CTRL:
case dojo.keys.TAB:
return;
}
}
if(this.intermediateChanges){
var _b35=this;
setTimeout(function(){
_b35._handleOnChange(_b35.get("value"),false);
},0);
}
this._refreshState();
this._set("displayedValue",this.get("displayedValue"));
},postCreate:function(){
if(dojo.isIE){
setTimeout(dojo.hitch(this,function(){
var s=dojo.getComputedStyle(this.domNode);
if(s){
var ff=s.fontFamily;
if(ff){
var _b36=this.domNode.getElementsByTagName("INPUT");
if(_b36){
for(var i=0;i<_b36.length;i++){
_b36[i].style.fontFamily=ff;
}
}
}
}
}),0);
}
this.textbox.setAttribute("value",this.textbox.value);
this.inherited(arguments);
if(dojo.isMoz||dojo.isOpera){
this.connect(this.textbox,"oninput","_onInput");
}else{
this.connect(this.textbox,"onkeydown","_onInput");
this.connect(this.textbox,"onkeyup","_onInput");
this.connect(this.textbox,"onpaste","_onInput");
this.connect(this.textbox,"oncut","_onInput");
}
},_blankValue:"",filter:function(val){
if(val===null){
return this._blankValue;
}
if(typeof val!="string"){
return val;
}
if(this.trim){
val=dojo.trim(val);
}
if(this.uppercase){
val=val.toUpperCase();
}
if(this.lowercase){
val=val.toLowerCase();
}
if(this.propercase){
val=val.replace(/[^\s]+/g,function(word){
return word.substring(0,1).toUpperCase()+word.substring(1);
});
}
return val;
},_setBlurValue:function(){
this._setValueAttr(this.get("value"),true);
},_onBlur:function(e){
if(this.disabled){
return;
}
this._setBlurValue();
this.inherited(arguments);
if(this._selectOnClickHandle){
this.disconnect(this._selectOnClickHandle);
}
if(this.selectOnClick&&dojo.isMoz){
this.textbox.selectionStart=this.textbox.selectionEnd=undefined;
}
this._updatePlaceHolder();
},_onFocus:function(by){
if(this.disabled||this.readOnly){
return;
}
if(this.selectOnClick&&by=="mouse"){
this._selectOnClickHandle=this.connect(this.domNode,"onmouseup",function(){
this.disconnect(this._selectOnClickHandle);
var _b37;
if(dojo.isIE){
var _b38=dojo.doc.selection.createRange();
var _b39=_b38.parentElement();
_b37=_b39==this.textbox&&_b38.text.length==0;
}else{
_b37=this.textbox.selectionStart==this.textbox.selectionEnd;
}
if(_b37){
dijit.selectInputText(this.textbox);
}
});
}
this._updatePlaceHolder();
this.inherited(arguments);
this._refreshState();
},reset:function(){
this.textbox.value="";
this.inherited(arguments);
}});
dijit.selectInputText=function(_b3a,_b3b,stop){
var _b3c=dojo.global;
var _b3d=dojo.doc;
_b3a=dojo.byId(_b3a);
if(isNaN(_b3b)){
_b3b=0;
}
if(isNaN(stop)){
stop=_b3a.value?_b3a.value.length:0;
}
dijit.focus(_b3a);
if(_b3d["selection"]&&dojo.body()["createTextRange"]){
if(_b3a.createTextRange){
var r=_b3a.createTextRange();
r.collapse(true);
r.moveStart("character",-99999);
r.moveStart("character",_b3b);
r.moveEnd("character",stop-_b3b);
r.select();
}
}else{
if(_b3c["getSelection"]){
if(_b3a.setSelectionRange){
_b3a.setSelectionRange(_b3b,stop);
}
}
}
};
}
if(!dojo._hasResource["dijit.Tooltip"]){
dojo._hasResource["dijit.Tooltip"]=true;
dojo.provide("dijit.Tooltip");
dojo.declare("dijit._MasterTooltip",[dijit._Widget,dijit._Templated],{duration:dijit.defaultDuration,templateString:dojo.cache("dijit","templates/Tooltip.html","<div class=\"dijitTooltip dijitTooltipLeft\" id=\"dojoTooltip\"\r\n\t><div class=\"dijitTooltipContainer dijitTooltipContents\" dojoAttachPoint=\"containerNode\" role='alert'></div\r\n\t><div class=\"dijitTooltipConnector\" dojoAttachPoint=\"connectorNode\"></div\r\n></div>\r\n"),postCreate:function(){
dojo.body().appendChild(this.domNode);
this.bgIframe=new dijit.BackgroundIframe(this.domNode);
this.fadeIn=dojo.fadeIn({node:this.domNode,duration:this.duration,onEnd:dojo.hitch(this,"_onShow")});
this.fadeOut=dojo.fadeOut({node:this.domNode,duration:this.duration,onEnd:dojo.hitch(this,"_onHide")});
},show:function(_b3e,_b3f,_b40,rtl){
if(this.aroundNode&&this.aroundNode===_b3f){
return;
}
this.domNode.width="auto";
if(this.fadeOut.status()=="playing"){
this._onDeck=arguments;
return;
}
this.containerNode.innerHTML=_b3e;
var pos=dijit.placeOnScreenAroundElement(this.domNode,_b3f,dijit.getPopupAroundAlignment((_b40&&_b40.length)?_b40:dijit.Tooltip.defaultPosition,!rtl),dojo.hitch(this,"orient"));
dojo.style(this.domNode,"opacity",0);
this.fadeIn.play();
this.isShowingNow=true;
this.aroundNode=_b3f;
},orient:function(node,_b41,_b42,_b43,_b44){
this.connectorNode.style.top="";
var _b45=_b43.w-this.connectorNode.offsetWidth;
node.className="dijitTooltip "+{"BL-TL":"dijitTooltipBelow dijitTooltipABLeft","TL-BL":"dijitTooltipAbove dijitTooltipABLeft","BR-TR":"dijitTooltipBelow dijitTooltipABRight","TR-BR":"dijitTooltipAbove dijitTooltipABRight","BR-BL":"dijitTooltipRight","BL-BR":"dijitTooltipLeft"}[_b41+"-"+_b42];
this.domNode.style.width="auto";
var size=dojo.contentBox(this.domNode);
var _b46=Math.min((Math.max(_b45,1)),size.w);
var _b47=_b46<size.w;
this.domNode.style.width=_b46+"px";
if(_b47){
this.containerNode.style.overflow="auto";
var _b48=this.containerNode.scrollWidth;
this.containerNode.style.overflow="visible";
if(_b48>_b46){
_b48=_b48+dojo.style(this.domNode,"paddingLeft")+dojo.style(this.domNode,"paddingRight");
this.domNode.style.width=_b48+"px";
}
}
if(_b42.charAt(0)=="B"&&_b41.charAt(0)=="B"){
var mb=dojo.marginBox(node);
var _b49=this.connectorNode.offsetHeight;
if(mb.h>_b43.h){
var _b4a=_b43.h-(_b44.h/2)-(_b49/2);
this.connectorNode.style.top=_b4a+"px";
this.connectorNode.style.bottom="";
}else{
this.connectorNode.style.bottom=Math.min(Math.max(_b44.h/2-_b49/2,0),mb.h-_b49)+"px";
this.connectorNode.style.top="";
}
}else{
this.connectorNode.style.top="";
this.connectorNode.style.bottom="";
}
return Math.max(0,size.w-_b45);
},_onShow:function(){
if(dojo.isIE){
this.domNode.style.filter="";
}
},hide:function(_b4b){
if(this._onDeck&&this._onDeck[1]==_b4b){
this._onDeck=null;
}else{
if(this.aroundNode===_b4b){
this.fadeIn.stop();
this.isShowingNow=false;
this.aroundNode=null;
this.fadeOut.play();
}else{
}
}
},_onHide:function(){
this.domNode.style.cssText="";
this.containerNode.innerHTML="";
if(this._onDeck){
this.show.apply(this,this._onDeck);
this._onDeck=null;
}
}});
dijit.showTooltip=function(_b4c,_b4d,_b4e,rtl){
if(!dijit._masterTT){
dijit._masterTT=new dijit._MasterTooltip();
}
return dijit._masterTT.show(_b4c,_b4d,_b4e,rtl);
};
dijit.hideTooltip=function(_b4f){
if(!dijit._masterTT){
dijit._masterTT=new dijit._MasterTooltip();
}
return dijit._masterTT.hide(_b4f);
};
dojo.declare("dijit.Tooltip",dijit._Widget,{label:"",showDelay:400,connectId:[],position:[],_setConnectIdAttr:function(_b50){
dojo.forEach(this._connections||[],function(_b51){
dojo.forEach(_b51,dojo.hitch(this,"disconnect"));
},this);
var ary=dojo.isArrayLike(_b50)?_b50:(_b50?[_b50]:[]);
this._connections=dojo.map(ary,function(id){
var node=dojo.byId(id);
return node?[this.connect(node,"onmouseenter","_onTargetMouseEnter"),this.connect(node,"onmouseleave","_onTargetMouseLeave"),this.connect(node,"onfocus","_onTargetFocus"),this.connect(node,"onblur","_onTargetBlur")]:[];
},this);
this._set("connectId",_b50);
this._connectIds=ary;
},addTarget:function(node){
var id=node.id||node;
if(dojo.indexOf(this._connectIds,id)==-1){
this.set("connectId",this._connectIds.concat(id));
}
},removeTarget:function(node){
var id=node.id||node,idx=dojo.indexOf(this._connectIds,id);
if(idx>=0){
this._connectIds.splice(idx,1);
this.set("connectId",this._connectIds);
}
},buildRendering:function(){
this.inherited(arguments);
dojo.addClass(this.domNode,"dijitTooltipData");
},startup:function(){
this.inherited(arguments);
var ids=this.connectId;
dojo.forEach(dojo.isArrayLike(ids)?ids:[ids],this.addTarget,this);
},_onTargetMouseEnter:function(e){
this._onHover(e);
},_onTargetMouseLeave:function(e){
this._onUnHover(e);
},_onTargetFocus:function(e){
this._focus=true;
this._onHover(e);
},_onTargetBlur:function(e){
this._focus=false;
this._onUnHover(e);
},_onHover:function(e){
if(!this._showTimer){
var _b52=e.target;
this._showTimer=setTimeout(dojo.hitch(this,function(){
this.open(_b52);
}),this.showDelay);
}
},_onUnHover:function(e){
if(this._focus){
return;
}
if(this._showTimer){
clearTimeout(this._showTimer);
delete this._showTimer;
}
this.close();
},open:function(_b53){
if(this._showTimer){
clearTimeout(this._showTimer);
delete this._showTimer;
}
dijit.showTooltip(this.label||this.domNode.innerHTML,_b53,this.position,!this.isLeftToRight());
this._connectNode=_b53;
this.onShow(_b53,this.position);
},close:function(){
if(this._connectNode){
dijit.hideTooltip(this._connectNode);
delete this._connectNode;
this.onHide();
}
if(this._showTimer){
clearTimeout(this._showTimer);
delete this._showTimer;
}
},onShow:function(_b54,_b55){
},onHide:function(){
},uninitialize:function(){
this.close();
this.inherited(arguments);
}});
dijit.Tooltip.defaultPosition=["after","before"];
}
if(!dojo._hasResource["dijit.form.ValidationTextBox"]){
dojo._hasResource["dijit.form.ValidationTextBox"]=true;
dojo.provide("dijit.form.ValidationTextBox");
dojo.declare("dijit.form.ValidationTextBox",dijit.form.TextBox,{templateString:dojo.cache("dijit.form","templates/ValidationTextBox.html","<div class=\"dijit dijitReset dijitInlineTable dijitLeft\"\r\n\tid=\"widget_${id}\" role=\"presentation\"\r\n\t><div class='dijitReset dijitValidationContainer'\r\n\t\t><input class=\"dijitReset dijitInputField dijitValidationIcon dijitValidationInner\" value=\"&#935; \" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t/></div\r\n\t><div class=\"dijitReset dijitInputField dijitInputContainer\"\r\n\t\t><input class=\"dijitReset dijitInputInner\" dojoAttachPoint='textbox,focusNode' autocomplete=\"off\"\r\n\t\t\t${!nameAttrSetting} type='${type}'\r\n\t/></div\r\n></div>\r\n"),baseClass:"dijitTextBox dijitValidationTextBox",required:false,promptMessage:"",invalidMessage:"$_unset_$",missingMessage:"$_unset_$",message:"",constraints:{},regExp:".*",regExpGen:function(_b56){
return this.regExp;
},state:"",tooltipPosition:[],_setValueAttr:function(){
this.inherited(arguments);
this.validate(this._focused);
},validator:function(_b57,_b58){
return (new RegExp("^(?:"+this.regExpGen(_b58)+")"+(this.required?"":"?")+"$")).test(_b57)&&(!this.required||!this._isEmpty(_b57))&&(this._isEmpty(_b57)||this.parse(_b57,_b58)!==undefined);
},_isValidSubset:function(){
return this.textbox.value.search(this._partialre)==0;
},isValid:function(_b59){
return this.validator(this.textbox.value,this.constraints);
},_isEmpty:function(_b5a){
return (this.trim?/^\s*$/:/^$/).test(_b5a);
},getErrorMessage:function(_b5b){
return (this.required&&this._isEmpty(this.textbox.value))?this.missingMessage:this.invalidMessage;
},getPromptMessage:function(_b5c){
return this.promptMessage;
},_maskValidSubsetError:true,validate:function(_b5d){
var _b5e="";
var _b5f=this.disabled||this.isValid(_b5d);
if(_b5f){
this._maskValidSubsetError=true;
}
var _b60=this._isEmpty(this.textbox.value);
var _b61=!_b5f&&_b5d&&this._isValidSubset();
this._set("state",_b5f?"":(((((!this._hasBeenBlurred||_b5d)&&_b60)||_b61)&&this._maskValidSubsetError)?"Incomplete":"Error"));
dijit.setWaiState(this.focusNode,"invalid",_b5f?"false":"true");
if(this.state=="Error"){
this._maskValidSubsetError=_b5d&&_b61;
_b5e=this.getErrorMessage(_b5d);
}else{
if(this.state=="Incomplete"){
_b5e=this.getPromptMessage(_b5d);
this._maskValidSubsetError=!this._hasBeenBlurred||_b5d;
}else{
if(_b60){
_b5e=this.getPromptMessage(_b5d);
}
}
}
this.set("message",_b5e);
return _b5f;
},displayMessage:function(_b62){
dijit.hideTooltip(this.domNode);
if(_b62&&this._focused){
dijit.showTooltip(_b62,this.domNode,this.tooltipPosition,!this.isLeftToRight());
}
},_refreshState:function(){
this.validate(this._focused);
this.inherited(arguments);
},constructor:function(){
this.constraints={};
},_setConstraintsAttr:function(_b63){
if(!_b63.locale&&this.lang){
_b63.locale=this.lang;
}
this._set("constraints",_b63);
this._computePartialRE();
},_computePartialRE:function(){
var p=this.regExpGen(this.constraints);
this.regExp=p;
var _b64="";
if(p!=".*"){
this.regExp.replace(/\\.|\[\]|\[.*?[^\\]{1}\]|\{.*?\}|\(\?[=:!]|./g,function(re){
switch(re.charAt(0)){
case "{":
case "+":
case "?":
case "*":
case "^":
case "$":
case "|":
case "(":
_b64+=re;
break;
case ")":
_b64+="|$)";
break;
default:
_b64+="(?:"+re+"|$)";
break;
}
});
}
try{
"".search(_b64);
}
catch(e){
_b64=this.regExp;
console.warn("RegExp error in "+this.declaredClass+": "+this.regExp);
}
this._partialre="^(?:"+_b64+")$";
},postMixInProperties:function(){
this.inherited(arguments);
this.messages=dojo.i18n.getLocalization("dijit.form","validate",this.lang);
if(this.invalidMessage=="$_unset_$"){
this.invalidMessage=this.messages.invalidMessage;
}
if(!this.invalidMessage){
this.invalidMessage=this.promptMessage;
}
if(this.missingMessage=="$_unset_$"){
this.missingMessage=this.messages.missingMessage;
}
if(!this.missingMessage){
this.missingMessage=this.invalidMessage;
}
this._setConstraintsAttr(this.constraints);
},_setDisabledAttr:function(_b65){
this.inherited(arguments);
this._refreshState();
},_setRequiredAttr:function(_b66){
this._set("required",_b66);
dijit.setWaiState(this.focusNode,"required",_b66);
this._refreshState();
},_setMessageAttr:function(_b67){
this._set("message",_b67);
this.displayMessage(_b67);
},reset:function(){
this._maskValidSubsetError=true;
this.inherited(arguments);
},_onBlur:function(){
this.displayMessage("");
this.inherited(arguments);
}});
dojo.declare("dijit.form.MappedTextBox",dijit.form.ValidationTextBox,{postMixInProperties:function(){
this.inherited(arguments);
this.nameAttrSetting="";
},serialize:function(val,_b68){
return val.toString?val.toString():"";
},toString:function(){
var val=this.filter(this.get("value"));
return val!=null?(typeof val=="string"?val:this.serialize(val,this.constraints)):"";
},validate:function(){
this.valueNode.value=this.toString();
return this.inherited(arguments);
},buildRendering:function(){
this.inherited(arguments);
this.valueNode=dojo.place("<input type='hidden'"+(this.name?" name='"+this.name.replace(/'/g,"&quot;")+"'":"")+"/>",this.textbox,"after");
},reset:function(){
this.valueNode.value="";
this.inherited(arguments);
}});
dojo.declare("dijit.form.RangeBoundTextBox",dijit.form.MappedTextBox,{rangeMessage:"",rangeCheck:function(_b69,_b6a){
return ("min" in _b6a?(this.compare(_b69,_b6a.min)>=0):true)&&("max" in _b6a?(this.compare(_b69,_b6a.max)<=0):true);
},isInRange:function(_b6b){
return this.rangeCheck(this.get("value"),this.constraints);
},_isDefinitelyOutOfRange:function(){
var val=this.get("value");
var _b6c=false;
var _b6d=false;
if("min" in this.constraints){
var min=this.constraints.min;
min=this.compare(val,((typeof min=="number")&&min>=0&&val!=0)?0:min);
_b6c=(typeof min=="number")&&min<0;
}
if("max" in this.constraints){
var max=this.constraints.max;
max=this.compare(val,((typeof max!="number")||max>0)?max:0);
_b6d=(typeof max=="number")&&max>0;
}
return _b6c||_b6d;
},_isValidSubset:function(){
return this.inherited(arguments)&&!this._isDefinitelyOutOfRange();
},isValid:function(_b6e){
return this.inherited(arguments)&&((this._isEmpty(this.textbox.value)&&!this.required)||this.isInRange(_b6e));
},getErrorMessage:function(_b6f){
var v=this.get("value");
if(v!==null&&v!==""&&v!==undefined&&(typeof v!="number"||!isNaN(v))&&!this.isInRange(_b6f)){
return this.rangeMessage;
}
return this.inherited(arguments);
},postMixInProperties:function(){
this.inherited(arguments);
if(!this.rangeMessage){
this.messages=dojo.i18n.getLocalization("dijit.form","validate",this.lang);
this.rangeMessage=this.messages.rangeMessage;
}
},_setConstraintsAttr:function(_b70){
this.inherited(arguments);
if(this.focusNode){
if(this.constraints.min!==undefined){
dijit.setWaiState(this.focusNode,"valuemin",this.constraints.min);
}else{
dijit.removeWaiState(this.focusNode,"valuemin");
}
if(this.constraints.max!==undefined){
dijit.setWaiState(this.focusNode,"valuemax",this.constraints.max);
}else{
dijit.removeWaiState(this.focusNode,"valuemax");
}
}
},_setValueAttr:function(_b71,_b72){
dijit.setWaiState(this.focusNode,"valuenow",_b71);
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.form._DateTimeTextBox"]){
dojo._hasResource["dijit.form._DateTimeTextBox"]=true;
dojo.provide("dijit.form._DateTimeTextBox");
new Date("X");
dojo.declare("dijit.form._DateTimeTextBox",[dijit.form.RangeBoundTextBox,dijit._HasDropDown],{templateString:dojo.cache("dijit.form","templates/DropDownBox.html","<div class=\"dijit dijitReset dijitInlineTable dijitLeft\"\r\n\tid=\"widget_${id}\"\r\n\trole=\"combobox\"\r\n\t><div class='dijitReset dijitRight dijitButtonNode dijitArrowButton dijitDownArrowButton dijitArrowButtonContainer'\r\n\t\tdojoAttachPoint=\"_buttonNode, _popupStateNode\" role=\"presentation\"\r\n\t\t><input class=\"dijitReset dijitInputField dijitArrowButtonInner\" value=\"&#9660; \" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t\t\t${_buttonInputDisabled}\r\n\t/></div\r\n\t><div class='dijitReset dijitValidationContainer'\r\n\t\t><input class=\"dijitReset dijitInputField dijitValidationIcon dijitValidationInner\" value=\"&#935; \" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t/></div\r\n\t><div class=\"dijitReset dijitInputField dijitInputContainer\"\r\n\t\t><input class='dijitReset dijitInputInner' ${!nameAttrSetting} type=\"text\" autocomplete=\"off\"\r\n\t\t\tdojoAttachPoint=\"textbox,focusNode\" role=\"textbox\" aria-haspopup=\"true\"\r\n\t/></div\r\n></div>\r\n"),hasDownArrow:true,openOnClick:true,regExpGen:dojo.date.locale.regexp,datePackage:"dojo.date",compare:function(val1,val2){
var _b73=this._isInvalidDate(val1);
var _b74=this._isInvalidDate(val2);
return _b73?(_b74?0:-1):(_b74?1:dojo.date.compare(val1,val2,this._selector));
},forceWidth:true,format:function(_b75,_b76){
if(!_b75){
return "";
}
return this.dateLocaleModule.format(_b75,_b76);
},"parse":function(_b77,_b78){
return this.dateLocaleModule.parse(_b77,_b78)||(this._isEmpty(_b77)?null:undefined);
},serialize:function(val,_b79){
if(val.toGregorian){
val=val.toGregorian();
}
return dojo.date.stamp.toISOString(val,_b79);
},dropDownDefaultValue:new Date(),value:new Date(""),_blankValue:null,popupClass:"",_selector:"",constructor:function(args){
var _b7a=args.datePackage?args.datePackage+".Date":"Date";
this.dateClassObj=dojo.getObject(_b7a,false);
this.value=new this.dateClassObj("");
this.datePackage=args.datePackage||this.datePackage;
this.dateLocaleModule=dojo.getObject(this.datePackage+".locale",false);
this.regExpGen=this.dateLocaleModule.regexp;
this._invalidDate=dijit.form._DateTimeTextBox.prototype.value.toString();
},buildRendering:function(){
this.inherited(arguments);
if(!this.hasDownArrow){
this._buttonNode.style.display="none";
}
if(this.openOnClick||!this.hasDownArrow){
this._buttonNode=this.domNode;
this.baseClass+=" dijitComboBoxOpenOnClick";
}
},_setConstraintsAttr:function(_b7b){
_b7b.selector=this._selector;
_b7b.fullYear=true;
var _b7c=dojo.date.stamp.fromISOString;
if(typeof _b7b.min=="string"){
_b7b.min=_b7c(_b7b.min);
}
if(typeof _b7b.max=="string"){
_b7b.max=_b7c(_b7b.max);
}
this.inherited(arguments);
},_isInvalidDate:function(_b7d){
return !_b7d||isNaN(_b7d)||typeof _b7d!="object"||_b7d.toString()==this._invalidDate;
},_setValueAttr:function(_b7e,_b7f,_b80){
if(_b7e!==undefined){
if(typeof _b7e=="string"){
_b7e=dojo.date.stamp.fromISOString(_b7e);
}
if(this._isInvalidDate(_b7e)){
_b7e=null;
}
if(_b7e instanceof Date&&!(this.dateClassObj instanceof Date)){
_b7e=new this.dateClassObj(_b7e);
}
}
this.inherited(arguments);
if(this.dropDown){
this.dropDown.set("value",_b7e,false);
}
},_set:function(attr,_b81){
if(attr=="value"&&this.value instanceof Date&&this.compare(_b81,this.value)==0){
return;
}
this.inherited(arguments);
},_setDropDownDefaultValueAttr:function(val){
if(this._isInvalidDate(val)){
val=new this.dateClassObj();
}
this.dropDownDefaultValue=val;
},openDropDown:function(_b82){
if(this.dropDown){
this.dropDown.destroy();
}
var _b83=dojo.getObject(this.popupClass,false),_b84=this,_b85=this.get("value");
this.dropDown=new _b83({onChange:function(_b86){
dijit.form._DateTimeTextBox.superclass._setValueAttr.call(_b84,_b86,true);
},id:this.id+"_popup",dir:_b84.dir,lang:_b84.lang,value:_b85,currentFocus:!this._isInvalidDate(_b85)?_b85:this.dropDownDefaultValue,constraints:_b84.constraints,filterString:_b84.filterString,datePackage:_b84.datePackage,isDisabledDate:function(date){
return !_b84.rangeCheck(date,_b84.constraints);
}});
this.inherited(arguments);
},_getDisplayedValueAttr:function(){
return this.textbox.value;
},_setDisplayedValueAttr:function(_b87,_b88){
this._setValueAttr(this.parse(_b87,this.constraints),_b88,_b87);
}});
}
if(!dojo._hasResource["dijit.form.DateTextBox"]){
dojo._hasResource["dijit.form.DateTextBox"]=true;
dojo.provide("dijit.form.DateTextBox");
dojo.declare("dijit.form.DateTextBox",dijit.form._DateTimeTextBox,{baseClass:"dijitTextBox dijitComboBox dijitDateTextBox",popupClass:"dijit.Calendar",_selector:"date",value:new Date("")});
}
if(!dojo._hasResource["dijit._TimePicker"]){
dojo._hasResource["dijit._TimePicker"]=true;
dojo.provide("dijit._TimePicker");
dojo.declare("dijit._TimePicker",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dijit","templates/TimePicker.html","<div id=\"widget_${id}\" class=\"dijitMenu\"\r\n    ><div dojoAttachPoint=\"upArrow\" class=\"dijitButtonNode dijitUpArrowButton\" dojoAttachEvent=\"onmouseenter:_buttonMouse,onmouseleave:_buttonMouse\"\r\n\t\t><div class=\"dijitReset dijitInline dijitArrowButtonInner\" role=\"presentation\">&nbsp;</div\r\n\t\t><div class=\"dijitArrowButtonChar\">&#9650;</div></div\r\n    ><div dojoAttachPoint=\"timeMenu,focusNode\" dojoAttachEvent=\"onclick:_onOptionSelected,onmouseover,onmouseout\"></div\r\n    ><div dojoAttachPoint=\"downArrow\" class=\"dijitButtonNode dijitDownArrowButton\" dojoAttachEvent=\"onmouseenter:_buttonMouse,onmouseleave:_buttonMouse\"\r\n\t\t><div class=\"dijitReset dijitInline dijitArrowButtonInner\" role=\"presentation\">&nbsp;</div\r\n\t\t><div class=\"dijitArrowButtonChar\">&#9660;</div></div\r\n></div>\r\n"),baseClass:"dijitTimePicker",clickableIncrement:"T00:15:00",visibleIncrement:"T01:00:00",visibleRange:"T05:00:00",value:new Date(),_visibleIncrement:2,_clickableIncrement:1,_totalIncrements:10,constraints:{},serialize:dojo.date.stamp.toISOString,setValue:function(_b89){
dojo.deprecated("dijit._TimePicker:setValue() is deprecated.  Use set('value', ...) instead.","","2.0");
this.set("value",_b89);
},_setValueAttr:function(date){
this._set("value",date);
this._showText();
},_setFilterStringAttr:function(val){
this._set("filterString",val);
this._showText();
},isDisabledDate:function(_b8a,_b8b){
return false;
},_getFilteredNodes:function(_b8c,_b8d,_b8e,_b8f){
var _b90=[],_b91=_b8f?_b8f.date:this._refDate,n,i=_b8c,max=this._maxIncrement+Math.abs(i),chk=_b8e?-1:1,dec=_b8e?1:0,inc=1-dec;
do{
i=i-dec;
n=this._createOption(i);
if(n){
if((_b8e&&n.date>_b91)||(!_b8e&&n.date<_b91)){
break;
}
_b90[_b8e?"unshift":"push"](n);
_b91=n.date;
}
i=i+inc;
}while(_b90.length<_b8d&&(i*chk)<max);
return _b90;
},_showText:function(){
var _b92=dojo.date.stamp.fromISOString;
this.timeMenu.innerHTML="";
this._clickableIncrementDate=_b92(this.clickableIncrement);
this._visibleIncrementDate=_b92(this.visibleIncrement);
this._visibleRangeDate=_b92(this.visibleRange);
var _b93=function(date){
return date.getHours()*60*60+date.getMinutes()*60+date.getSeconds();
},_b94=_b93(this._clickableIncrementDate),_b95=_b93(this._visibleIncrementDate),_b96=_b93(this._visibleRangeDate),time=(this.value||this.currentFocus).getTime();
this._refDate=new Date(time-time%(_b95*1000));
this._refDate.setFullYear(1970,0,1);
this._clickableIncrement=1;
this._totalIncrements=_b96/_b94;
this._visibleIncrement=_b95/_b94;
this._maxIncrement=(60*60*24)/_b94;
var _b97=this._getFilteredNodes(0,Math.min(this._totalIncrements>>1,10)-1),_b98=this._getFilteredNodes(0,Math.min(this._totalIncrements,10)-_b97.length,true,_b97[0]);
dojo.forEach(_b98.concat(_b97),function(n){
this.timeMenu.appendChild(n);
},this);
},constructor:function(){
this.constraints={};
},postMixInProperties:function(){
this.inherited(arguments);
this._setConstraintsAttr(this.constraints);
},_setConstraintsAttr:function(_b99){
dojo.mixin(this,_b99);
if(!_b99.locale){
_b99.locale=this.lang;
}
},postCreate:function(){
this.connect(this.timeMenu,dojo.isIE?"onmousewheel":"DOMMouseScroll","_mouseWheeled");
this._connects.push(dijit.typematic.addMouseListener(this.upArrow,this,"_onArrowUp",33,250));
this._connects.push(dijit.typematic.addMouseListener(this.downArrow,this,"_onArrowDown",33,250));
this.inherited(arguments);
},_buttonMouse:function(e){
dojo.toggleClass(e.currentTarget,e.currentTarget==this.upArrow?"dijitUpArrowHover":"dijitDownArrowHover",e.type=="mouseenter"||e.type=="mouseover");
},_createOption:function(_b9a){
var date=new Date(this._refDate);
var _b9b=this._clickableIncrementDate;
date.setHours(date.getHours()+_b9b.getHours()*_b9a,date.getMinutes()+_b9b.getMinutes()*_b9a,date.getSeconds()+_b9b.getSeconds()*_b9a);
if(this.constraints.selector=="time"){
date.setFullYear(1970,0,1);
}
var _b9c=dojo.date.locale.format(date,this.constraints);
if(this.filterString&&_b9c.toLowerCase().indexOf(this.filterString)!==0){
return null;
}
var div=dojo.create("div",{"class":this.baseClass+"Item"});
div.date=date;
div.index=_b9a;
dojo.create("div",{"class":this.baseClass+"ItemInner",innerHTML:_b9c},div);
if(_b9a%this._visibleIncrement<1&&_b9a%this._visibleIncrement>-1){
dojo.addClass(div,this.baseClass+"Marker");
}else{
if(!(_b9a%this._clickableIncrement)){
dojo.addClass(div,this.baseClass+"Tick");
}
}
if(this.isDisabledDate(date)){
dojo.addClass(div,this.baseClass+"ItemDisabled");
}
if(this.value&&!dojo.date.compare(this.value,date,this.constraints.selector)){
div.selected=true;
dojo.addClass(div,this.baseClass+"ItemSelected");
if(dojo.hasClass(div,this.baseClass+"Marker")){
dojo.addClass(div,this.baseClass+"MarkerSelected");
}else{
dojo.addClass(div,this.baseClass+"TickSelected");
}
this._highlightOption(div,true);
}
return div;
},_onOptionSelected:function(tgt){
var _b9d=tgt.target.date||tgt.target.parentNode.date;
if(!_b9d||this.isDisabledDate(_b9d)){
return;
}
this._highlighted_option=null;
this.set("value",_b9d);
this.onChange(_b9d);
},onChange:function(time){
},_highlightOption:function(node,_b9e){
if(!node){
return;
}
if(_b9e){
if(this._highlighted_option){
this._highlightOption(this._highlighted_option,false);
}
this._highlighted_option=node;
}else{
if(this._highlighted_option!==node){
return;
}else{
this._highlighted_option=null;
}
}
dojo.toggleClass(node,this.baseClass+"ItemHover",_b9e);
if(dojo.hasClass(node,this.baseClass+"Marker")){
dojo.toggleClass(node,this.baseClass+"MarkerHover",_b9e);
}else{
dojo.toggleClass(node,this.baseClass+"TickHover",_b9e);
}
},onmouseover:function(e){
this._keyboardSelected=null;
var tgr=(e.target.parentNode===this.timeMenu)?e.target:e.target.parentNode;
if(!dojo.hasClass(tgr,this.baseClass+"Item")){
return;
}
this._highlightOption(tgr,true);
},onmouseout:function(e){
this._keyboardSelected=null;
var tgr=(e.target.parentNode===this.timeMenu)?e.target:e.target.parentNode;
this._highlightOption(tgr,false);
},_mouseWheeled:function(e){
this._keyboardSelected=null;
dojo.stopEvent(e);
var _b9f=(dojo.isIE?e.wheelDelta:-e.detail);
this[(_b9f>0?"_onArrowUp":"_onArrowDown")]();
},_onArrowUp:function(_ba0){
if(typeof _ba0=="number"&&_ba0==-1){
return;
}
if(!this.timeMenu.childNodes.length){
return;
}
var _ba1=this.timeMenu.childNodes[0].index;
var divs=this._getFilteredNodes(_ba1,1,true,this.timeMenu.childNodes[0]);
if(divs.length){
this.timeMenu.removeChild(this.timeMenu.childNodes[this.timeMenu.childNodes.length-1]);
this.timeMenu.insertBefore(divs[0],this.timeMenu.childNodes[0]);
}
},_onArrowDown:function(_ba2){
if(typeof _ba2=="number"&&_ba2==-1){
return;
}
if(!this.timeMenu.childNodes.length){
return;
}
var _ba3=this.timeMenu.childNodes[this.timeMenu.childNodes.length-1].index+1;
var divs=this._getFilteredNodes(_ba3,1,false,this.timeMenu.childNodes[this.timeMenu.childNodes.length-1]);
if(divs.length){
this.timeMenu.removeChild(this.timeMenu.childNodes[0]);
this.timeMenu.appendChild(divs[0]);
}
},handleKey:function(e){
var dk=dojo.keys;
if(e.charOrCode==dk.DOWN_ARROW||e.charOrCode==dk.UP_ARROW){
dojo.stopEvent(e);
if(this._highlighted_option&&!this._highlighted_option.parentNode){
this._highlighted_option=null;
}
var _ba4=this.timeMenu,tgt=this._highlighted_option||dojo.query("."+this.baseClass+"ItemSelected",_ba4)[0];
if(!tgt){
tgt=_ba4.childNodes[0];
}else{
if(_ba4.childNodes.length){
if(e.charOrCode==dk.DOWN_ARROW&&!tgt.nextSibling){
this._onArrowDown();
}else{
if(e.charOrCode==dk.UP_ARROW&&!tgt.previousSibling){
this._onArrowUp();
}
}
if(e.charOrCode==dk.DOWN_ARROW){
tgt=tgt.nextSibling;
}else{
tgt=tgt.previousSibling;
}
}
}
this._highlightOption(tgt,true);
this._keyboardSelected=tgt;
return false;
}else{
if(e.charOrCode==dk.ENTER||e.charOrCode===dk.TAB){
if(!this._keyboardSelected&&e.charOrCode===dk.TAB){
return true;
}
if(this._highlighted_option){
this._onOptionSelected({target:this._highlighted_option});
}
return e.charOrCode===dk.TAB;
}
}
}});
}
if(!dojo._hasResource["dijit.form.TimeTextBox"]){
dojo._hasResource["dijit.form.TimeTextBox"]=true;
dojo.provide("dijit.form.TimeTextBox");
dojo.declare("dijit.form.TimeTextBox",dijit.form._DateTimeTextBox,{baseClass:"dijitTextBox dijitComboBox dijitTimeTextBox",popupClass:"dijit._TimePicker",_selector:"time",value:new Date(""),_onKey:function(evt){
if(this.disabled||this.readOnly){
return;
}
this.inherited(arguments);
switch(evt.keyCode){
case dojo.keys.ENTER:
case dojo.keys.TAB:
case dojo.keys.ESCAPE:
case dojo.keys.DOWN_ARROW:
case dojo.keys.UP_ARROW:
break;
default:
setTimeout(dojo.hitch(this,function(){
var val=this.get("displayedValue");
this.filterString=(val&&!this.parse(val,this.constraints))?val.toLowerCase():"";
if(this._opened){
this.closeDropDown();
}
this.openDropDown();
}),0);
}
}});
}
if(!dojo._hasResource["dijit.form.ComboBox"]){
dojo._hasResource["dijit.form.ComboBox"]=true;
dojo.provide("dijit.form.ComboBox");
dojo.declare("dijit.form.ComboBoxMixin",dijit._HasDropDown,{item:null,pageSize:Infinity,store:null,fetchProperties:{},query:{},autoComplete:true,highlightMatch:"first",searchDelay:100,searchAttr:"name",labelAttr:"",labelType:"text",queryExpr:"${0}*",ignoreCase:true,hasDownArrow:true,templateString:dojo.cache("dijit.form","templates/DropDownBox.html","<div class=\"dijit dijitReset dijitInlineTable dijitLeft\"\r\n\tid=\"widget_${id}\"\r\n\trole=\"combobox\"\r\n\t><div class='dijitReset dijitRight dijitButtonNode dijitArrowButton dijitDownArrowButton dijitArrowButtonContainer'\r\n\t\tdojoAttachPoint=\"_buttonNode, _popupStateNode\" role=\"presentation\"\r\n\t\t><input class=\"dijitReset dijitInputField dijitArrowButtonInner\" value=\"&#9660; \" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t\t\t${_buttonInputDisabled}\r\n\t/></div\r\n\t><div class='dijitReset dijitValidationContainer'\r\n\t\t><input class=\"dijitReset dijitInputField dijitValidationIcon dijitValidationInner\" value=\"&#935; \" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t/></div\r\n\t><div class=\"dijitReset dijitInputField dijitInputContainer\"\r\n\t\t><input class='dijitReset dijitInputInner' ${!nameAttrSetting} type=\"text\" autocomplete=\"off\"\r\n\t\t\tdojoAttachPoint=\"textbox,focusNode\" role=\"textbox\" aria-haspopup=\"true\"\r\n\t/></div\r\n></div>\r\n"),baseClass:"dijitTextBox dijitComboBox",dropDownClass:"dijit.form._ComboBoxMenu",cssStateNodes:{"_buttonNode":"dijitDownArrowButton"},maxHeight:-1,_stopClickEvents:false,_getCaretPos:function(_ba5){
var pos=0;
if(typeof (_ba5.selectionStart)=="number"){
pos=_ba5.selectionStart;
}else{
if(dojo.isIE){
var tr=dojo.doc.selection.createRange().duplicate();
var ntr=_ba5.createTextRange();
tr.move("character",0);
ntr.move("character",0);
try{
ntr.setEndPoint("EndToEnd",tr);
pos=String(ntr.text).replace(/\r/g,"").length;
}
catch(e){
}
}
}
return pos;
},_setCaretPos:function(_ba6,_ba7){
_ba7=parseInt(_ba7);
dijit.selectInputText(_ba6,_ba7,_ba7);
},_setDisabledAttr:function(_ba8){
this.inherited(arguments);
dijit.setWaiState(this.domNode,"disabled",_ba8);
},_abortQuery:function(){
if(this.searchTimer){
clearTimeout(this.searchTimer);
this.searchTimer=null;
}
if(this._fetchHandle){
if(this._fetchHandle.abort){
this._fetchHandle.abort();
}
this._fetchHandle=null;
}
},_onInput:function(evt){
if(!this.searchTimer&&(evt.type=="paste"||evt.type=="input")&&this._lastInput!=this.textbox.value){
this.searchTimer=setTimeout(dojo.hitch(this,function(){
this._onKey({charOrCode:229});
}),100);
}
this.inherited(arguments);
},_onKey:function(evt){
var key=evt.charOrCode;
if(evt.altKey||((evt.ctrlKey||evt.metaKey)&&(key!="x"&&key!="v"))||key==dojo.keys.SHIFT){
return;
}
var _ba9=false;
var pw=this.dropDown;
var dk=dojo.keys;
var _baa=null;
this._prev_key_backspace=false;
this._abortQuery();
this.inherited(arguments);
if(this._opened){
_baa=pw.getHighlightedOption();
}
switch(key){
case dk.PAGE_DOWN:
case dk.DOWN_ARROW:
case dk.PAGE_UP:
case dk.UP_ARROW:
if(this._opened){
this._announceOption(_baa);
}
dojo.stopEvent(evt);
break;
case dk.ENTER:
if(_baa){
if(_baa==pw.nextButton){
this._nextSearch(1);
dojo.stopEvent(evt);
break;
}else{
if(_baa==pw.previousButton){
this._nextSearch(-1);
dojo.stopEvent(evt);
break;
}
}
}else{
this._setBlurValue();
this._setCaretPos(this.focusNode,this.focusNode.value.length);
}
if(this._opened||this._fetchHandle){
dojo.stopEvent(evt);
}
case dk.TAB:
var _bab=this.get("displayedValue");
if(pw&&(_bab==pw._messages["previousMessage"]||_bab==pw._messages["nextMessage"])){
break;
}
if(_baa){
this._selectOption();
}
if(this._opened){
this._lastQuery=null;
this.closeDropDown();
}
break;
case " ":
if(_baa){
dojo.stopEvent(evt);
this._selectOption();
this.closeDropDown();
}else{
_ba9=true;
}
break;
case dk.DELETE:
case dk.BACKSPACE:
this._prev_key_backspace=true;
_ba9=true;
break;
default:
_ba9=typeof key=="string"||key==229;
}
if(_ba9){
this.item=undefined;
this.searchTimer=setTimeout(dojo.hitch(this,"_startSearchFromInput"),1);
}
},_autoCompleteText:function(text){
var fn=this.focusNode;
dijit.selectInputText(fn,fn.value.length);
var _bac=this.ignoreCase?"toLowerCase":"substr";
if(text[_bac](0).indexOf(this.focusNode.value[_bac](0))==0){
var cpos=this._getCaretPos(fn);
if((cpos+1)>fn.value.length){
fn.value=text;
dijit.selectInputText(fn,cpos);
}
}else{
fn.value=text;
dijit.selectInputText(fn);
}
},_openResultList:function(_bad,_bae){
this._fetchHandle=null;
if(this.disabled||this.readOnly||(_bae.query[this.searchAttr]!=this._lastQuery)){
return;
}
var _baf=this.dropDown._highlighted_option&&dojo.hasClass(this.dropDown._highlighted_option,"dijitMenuItemSelected");
this.dropDown.clearResultList();
if(!_bad.length&&!this._maxOptions){
this.closeDropDown();
return;
}
_bae._maxOptions=this._maxOptions;
var _bb0=this.dropDown.createOptions(_bad,_bae,dojo.hitch(this,"_getMenuLabelFromItem"));
this._showResultList();
if(_bae.direction){
if(1==_bae.direction){
this.dropDown.highlightFirstOption();
}else{
if(-1==_bae.direction){
this.dropDown.highlightLastOption();
}
}
if(_baf){
this._announceOption(this.dropDown.getHighlightedOption());
}
}else{
if(this.autoComplete&&!this._prev_key_backspace&&!/^[*]+$/.test(_bae.query[this.searchAttr])){
this._announceOption(_bb0[1]);
}
}
},_showResultList:function(){
this.closeDropDown(true);
this.displayMessage("");
this.openDropDown();
dijit.setWaiState(this.domNode,"expanded","true");
},loadDropDown:function(_bb1){
this._startSearchAll();
},isLoaded:function(){
return false;
},closeDropDown:function(){
this._abortQuery();
if(this._opened){
this.inherited(arguments);
dijit.setWaiState(this.domNode,"expanded","false");
dijit.removeWaiState(this.focusNode,"activedescendant");
}
},_setBlurValue:function(){
var _bb2=this.get("displayedValue");
var pw=this.dropDown;
if(pw&&(_bb2==pw._messages["previousMessage"]||_bb2==pw._messages["nextMessage"])){
this._setValueAttr(this._lastValueReported,true);
}else{
if(typeof this.item=="undefined"){
this.item=null;
this.set("displayedValue",_bb2);
}else{
if(this.value!=this._lastValueReported){
dijit.form._FormValueWidget.prototype._setValueAttr.call(this,this.value,true);
}
this._refreshState();
}
}
},_onBlur:function(){
this.closeDropDown();
this.inherited(arguments);
},_setItemAttr:function(item,_bb3,_bb4){
if(!_bb4){
_bb4=this.store.getValue(item,this.searchAttr);
}
var _bb5=this._getValueField()!=this.searchAttr?this.store.getIdentity(item):_bb4;
this._set("item",item);
dijit.form.ComboBox.superclass._setValueAttr.call(this,_bb5,_bb3,_bb4);
},_announceOption:function(node){
if(!node){
return;
}
var _bb6;
if(node==this.dropDown.nextButton||node==this.dropDown.previousButton){
_bb6=node.innerHTML;
this.item=undefined;
this.value="";
}else{
_bb6=this.store.getValue(node.item,this.searchAttr).toString();
this.set("item",node.item,false,_bb6);
}
this.focusNode.value=this.focusNode.value.substring(0,this._lastInput.length);
dijit.setWaiState(this.focusNode,"activedescendant",dojo.attr(node,"id"));
this._autoCompleteText(_bb6);
},_selectOption:function(evt){
if(evt){
this._announceOption(evt.target);
}
this.closeDropDown();
this._setCaretPos(this.focusNode,this.focusNode.value.length);
dijit.form._FormValueWidget.prototype._setValueAttr.call(this,this.value,true);
},_startSearchAll:function(){
this._startSearch("");
},_startSearchFromInput:function(){
this._startSearch(this.focusNode.value.replace(/([\\\*\?])/g,"\\$1"));
},_getQueryString:function(text){
return dojo.string.substitute(this.queryExpr,[text]);
},_startSearch:function(key){
if(!this.dropDown){
var _bb7=this.id+"_popup",_bb8=dojo.getObject(this.dropDownClass,false);
this.dropDown=new _bb8({onChange:dojo.hitch(this,this._selectOption),id:_bb7,dir:this.dir});
dijit.removeWaiState(this.focusNode,"activedescendant");
dijit.setWaiState(this.textbox,"owns",_bb7);
}
var _bb9=dojo.clone(this.query);
this._lastInput=key;
this._lastQuery=_bb9[this.searchAttr]=this._getQueryString(key);
this.searchTimer=setTimeout(dojo.hitch(this,function(_bba,_bbb){
this.searchTimer=null;
var _bbc={queryOptions:{ignoreCase:this.ignoreCase,deep:true},query:_bba,onBegin:dojo.hitch(this,"_setMaxOptions"),onComplete:dojo.hitch(this,"_openResultList"),onError:function(_bbd){
_bbb._fetchHandle=null;
console.error("dijit.form.ComboBox: "+_bbd);
_bbb.closeDropDown();
},start:0,count:this.pageSize};
dojo.mixin(_bbc,_bbb.fetchProperties);
this._fetchHandle=_bbb.store.fetch(_bbc);
var _bbe=function(_bbf,_bc0){
_bbf.start+=_bbf.count*_bc0;
_bbf.direction=_bc0;
this._fetchHandle=this.store.fetch(_bbf);
this.focus();
};
this._nextSearch=this.dropDown.onPage=dojo.hitch(this,_bbe,this._fetchHandle);
},_bb9,this),this.searchDelay);
},_setMaxOptions:function(size,_bc1){
this._maxOptions=size;
},_getValueField:function(){
return this.searchAttr;
},constructor:function(){
this.query={};
this.fetchProperties={};
},postMixInProperties:function(){
if(!this.store){
var _bc2=this.srcNodeRef;
this.store=new dijit.form._ComboBoxDataStore(_bc2);
if(!("value" in this.params)){
var item=(this.item=this.store.fetchSelectedItem());
if(item){
var _bc3=this._getValueField();
this.value=this.store.getValue(item,_bc3);
}
}
}
this.inherited(arguments);
},postCreate:function(){
var _bc4=dojo.query("label[for=\""+this.id+"\"]");
if(_bc4.length){
_bc4[0].id=(this.id+"_label");
dijit.setWaiState(this.domNode,"labelledby",_bc4[0].id);
}
this.inherited(arguments);
},_setHasDownArrowAttr:function(val){
this.hasDownArrow=val;
this._buttonNode.style.display=val?"":"none";
},_getMenuLabelFromItem:function(item){
var _bc5=this.labelFunc(item,this.store),_bc6=this.labelType;
if(this.highlightMatch!="none"&&this.labelType=="text"&&this._lastInput){
_bc5=this.doHighlight(_bc5,this._escapeHtml(this._lastInput));
_bc6="html";
}
return {html:_bc6=="html",label:_bc5};
},doHighlight:function(_bc7,find){
var _bc8=(this.ignoreCase?"i":"")+(this.highlightMatch=="all"?"g":""),i=this.queryExpr.indexOf("${0}");
find=dojo.regexp.escapeString(find);
return this._escapeHtml(_bc7).replace(new RegExp((i==0?"^":"")+"("+find+")"+(i==(this.queryExpr.length-4)?"$":""),_bc8),"<span class=\"dijitComboBoxHighlightMatch\">$1</span>");
},_escapeHtml:function(str){
str=String(str).replace(/&/gm,"&amp;").replace(/</gm,"&lt;").replace(/>/gm,"&gt;").replace(/"/gm,"&quot;");
return str;
},reset:function(){
this.item=null;
this.inherited(arguments);
},labelFunc:function(item,_bc9){
return _bc9.getValue(item,this.labelAttr||this.searchAttr).toString();
}});
dojo.declare("dijit.form._ComboBoxMenu",[dijit._Widget,dijit._Templated,dijit._CssStateMixin],{templateString:"<ul class='dijitReset dijitMenu' dojoAttachEvent='onmousedown:_onMouseDown,onmouseup:_onMouseUp,onmouseover:_onMouseOver,onmouseout:_onMouseOut' style='overflow: \"auto\"; overflow-x: \"hidden\";'>"+"<li class='dijitMenuItem dijitMenuPreviousButton' dojoAttachPoint='previousButton' role='option'></li>"+"<li class='dijitMenuItem dijitMenuNextButton' dojoAttachPoint='nextButton' role='option'></li>"+"</ul>",_messages:null,baseClass:"dijitComboBoxMenu",postMixInProperties:function(){
this.inherited(arguments);
this._messages=dojo.i18n.getLocalization("dijit.form","ComboBox",this.lang);
},buildRendering:function(){
this.inherited(arguments);
this.previousButton.innerHTML=this._messages["previousMessage"];
this.nextButton.innerHTML=this._messages["nextMessage"];
},_setValueAttr:function(_bca){
this.value=_bca;
this.onChange(_bca);
},onChange:function(_bcb){
},onPage:function(_bcc){
},onClose:function(){
this._blurOptionNode();
},_createOption:function(item,_bcd){
var _bce=dojo.create("li",{"class":"dijitReset dijitMenuItem"+(this.isLeftToRight()?"":" dijitMenuItemRtl"),role:"option"});
var _bcf=_bcd(item);
if(_bcf.html){
_bce.innerHTML=_bcf.label;
}else{
_bce.appendChild(dojo.doc.createTextNode(_bcf.label));
}
if(_bce.innerHTML==""){
_bce.innerHTML="&nbsp;";
}
_bce.item=item;
return _bce;
},createOptions:function(_bd0,_bd1,_bd2){
this.previousButton.style.display=(_bd1.start==0)?"none":"";
dojo.attr(this.previousButton,"id",this.id+"_prev");
dojo.forEach(_bd0,function(item,i){
var _bd3=this._createOption(item,_bd2);
dojo.attr(_bd3,"id",this.id+i);
this.domNode.insertBefore(_bd3,this.nextButton);
},this);
var _bd4=false;
if(_bd1._maxOptions&&_bd1._maxOptions!=-1){
if((_bd1.start+_bd1.count)<_bd1._maxOptions){
_bd4=true;
}else{
if((_bd1.start+_bd1.count)>_bd1._maxOptions&&_bd1.count==_bd0.length){
_bd4=true;
}
}
}else{
if(_bd1.count==_bd0.length){
_bd4=true;
}
}
this.nextButton.style.display=_bd4?"":"none";
dojo.attr(this.nextButton,"id",this.id+"_next");
return this.domNode.childNodes;
},clearResultList:function(){
while(this.domNode.childNodes.length>2){
this.domNode.removeChild(this.domNode.childNodes[this.domNode.childNodes.length-2]);
}
this._blurOptionNode();
},_onMouseDown:function(evt){
dojo.stopEvent(evt);
},_onMouseUp:function(evt){
if(evt.target===this.domNode||!this._highlighted_option){
return;
}else{
if(evt.target==this.previousButton){
this._blurOptionNode();
this.onPage(-1);
}else{
if(evt.target==this.nextButton){
this._blurOptionNode();
this.onPage(1);
}else{
var tgt=evt.target;
while(!tgt.item){
tgt=tgt.parentNode;
}
this._setValueAttr({target:tgt},true);
}
}
}
},_onMouseOver:function(evt){
if(evt.target===this.domNode){
return;
}
var tgt=evt.target;
if(!(tgt==this.previousButton||tgt==this.nextButton)){
while(!tgt.item){
tgt=tgt.parentNode;
}
}
this._focusOptionNode(tgt);
},_onMouseOut:function(evt){
if(evt.target===this.domNode){
return;
}
this._blurOptionNode();
},_focusOptionNode:function(node){
if(this._highlighted_option!=node){
this._blurOptionNode();
this._highlighted_option=node;
dojo.addClass(this._highlighted_option,"dijitMenuItemSelected");
}
},_blurOptionNode:function(){
if(this._highlighted_option){
dojo.removeClass(this._highlighted_option,"dijitMenuItemSelected");
this._highlighted_option=null;
}
},_highlightNextOption:function(){
if(!this.getHighlightedOption()){
var fc=this.domNode.firstChild;
this._focusOptionNode(fc.style.display=="none"?fc.nextSibling:fc);
}else{
var ns=this._highlighted_option.nextSibling;
if(ns&&ns.style.display!="none"){
this._focusOptionNode(ns);
}else{
this.highlightFirstOption();
}
}
dojo.window.scrollIntoView(this._highlighted_option);
},highlightFirstOption:function(){
var _bd5=this.domNode.firstChild;
var _bd6=_bd5.nextSibling;
this._focusOptionNode(_bd6.style.display=="none"?_bd5:_bd6);
dojo.window.scrollIntoView(this._highlighted_option);
},highlightLastOption:function(){
this._focusOptionNode(this.domNode.lastChild.previousSibling);
dojo.window.scrollIntoView(this._highlighted_option);
},_highlightPrevOption:function(){
if(!this.getHighlightedOption()){
var lc=this.domNode.lastChild;
this._focusOptionNode(lc.style.display=="none"?lc.previousSibling:lc);
}else{
var ps=this._highlighted_option.previousSibling;
if(ps&&ps.style.display!="none"){
this._focusOptionNode(ps);
}else{
this.highlightLastOption();
}
}
dojo.window.scrollIntoView(this._highlighted_option);
},_page:function(up){
var _bd7=0;
var _bd8=this.domNode.scrollTop;
var _bd9=dojo.style(this.domNode,"height");
if(!this.getHighlightedOption()){
this._highlightNextOption();
}
while(_bd7<_bd9){
if(up){
if(!this.getHighlightedOption().previousSibling||this._highlighted_option.previousSibling.style.display=="none"){
break;
}
this._highlightPrevOption();
}else{
if(!this.getHighlightedOption().nextSibling||this._highlighted_option.nextSibling.style.display=="none"){
break;
}
this._highlightNextOption();
}
var _bda=this.domNode.scrollTop;
_bd7+=(_bda-_bd8)*(up?-1:1);
_bd8=_bda;
}
},pageUp:function(){
this._page(true);
},pageDown:function(){
this._page(false);
},getHighlightedOption:function(){
var ho=this._highlighted_option;
return (ho&&ho.parentNode)?ho:null;
},handleKey:function(evt){
switch(evt.charOrCode){
case dojo.keys.DOWN_ARROW:
this._highlightNextOption();
return false;
case dojo.keys.PAGE_DOWN:
this.pageDown();
return false;
case dojo.keys.UP_ARROW:
this._highlightPrevOption();
return false;
case dojo.keys.PAGE_UP:
this.pageUp();
return false;
default:
return true;
}
}});
dojo.declare("dijit.form.ComboBox",[dijit.form.ValidationTextBox,dijit.form.ComboBoxMixin],{_setValueAttr:function(_bdb,_bdc,_bdd){
this._set("item",null);
if(!_bdb){
_bdb="";
}
dijit.form.ValidationTextBox.prototype._setValueAttr.call(this,_bdb,_bdc,_bdd);
}});
dojo.declare("dijit.form._ComboBoxDataStore",null,{constructor:function(root){
this.root=root;
if(root.tagName!="SELECT"&&root.firstChild){
root=dojo.query("select",root);
if(root.length>0){
root=root[0];
}else{
this.root.innerHTML="<SELECT>"+this.root.innerHTML+"</SELECT>";
root=this.root.firstChild;
}
this.root=root;
}
dojo.query("> option",root).forEach(function(node){
node.innerHTML=dojo.trim(node.innerHTML);
});
},getValue:function(item,_bde,_bdf){
return (_bde=="value")?item.value:(item.innerText||item.textContent||"");
},isItemLoaded:function(_be0){
return true;
},getFeatures:function(){
return {"dojo.data.api.Read":true,"dojo.data.api.Identity":true};
},_fetchItems:function(args,_be1,_be2){
if(!args.query){
args.query={};
}
if(!args.query.name){
args.query.name="";
}
if(!args.queryOptions){
args.queryOptions={};
}
var _be3=dojo.data.util.filter.patternToRegExp(args.query.name,args.queryOptions.ignoreCase),_be4=dojo.query("> option",this.root).filter(function(_be5){
return (_be5.innerText||_be5.textContent||"").match(_be3);
});
if(args.sort){
_be4.sort(dojo.data.util.sorter.createSortFunction(args.sort,this));
}
_be1(_be4,args);
},close:function(_be6){
return;
},getLabel:function(item){
return item.innerHTML;
},getIdentity:function(item){
return dojo.attr(item,"value");
},fetchItemByIdentity:function(args){
var item=dojo.query("> option[value='"+args.identity+"']",this.root)[0];
args.onItem(item);
},fetchSelectedItem:function(){
var root=this.root,si=root.selectedIndex;
return typeof si=="number"?dojo.query("> option:nth-child("+(si!=-1?si+1:1)+")",root)[0]:null;
}});
dojo.extend(dijit.form._ComboBoxDataStore,dojo.data.util.simpleFetch);
}
if(!dojo._hasResource["dijit.form._Spinner"]){
dojo._hasResource["dijit.form._Spinner"]=true;
dojo.provide("dijit.form._Spinner");
dojo.declare("dijit.form._Spinner",dijit.form.RangeBoundTextBox,{defaultTimeout:500,minimumTimeout:10,timeoutChangeRate:0.9,smallDelta:1,largeDelta:10,templateString:dojo.cache("dijit.form","templates/Spinner.html","<div class=\"dijit dijitReset dijitInlineTable dijitLeft\"\r\n\tid=\"widget_${id}\" role=\"presentation\"\r\n\t><div class=\"dijitReset dijitButtonNode dijitSpinnerButtonContainer\"\r\n\t\t><input class=\"dijitReset dijitInputField dijitSpinnerButtonInner\" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t\t/><div class=\"dijitReset dijitLeft dijitButtonNode dijitArrowButton dijitUpArrowButton\"\r\n\t\t\tdojoAttachPoint=\"upArrowNode\"\r\n\t\t\t><div class=\"dijitArrowButtonInner\"\r\n\t\t\t\t><input class=\"dijitReset dijitInputField\" value=\"&#9650;\" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t\t\t\t\t${_buttonInputDisabled}\r\n\t\t\t/></div\r\n\t\t></div\r\n\t\t><div class=\"dijitReset dijitLeft dijitButtonNode dijitArrowButton dijitDownArrowButton\"\r\n\t\t\tdojoAttachPoint=\"downArrowNode\"\r\n\t\t\t><div class=\"dijitArrowButtonInner\"\r\n\t\t\t\t><input class=\"dijitReset dijitInputField\" value=\"&#9660;\" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t\t\t\t\t${_buttonInputDisabled}\r\n\t\t\t/></div\r\n\t\t></div\r\n\t></div\r\n\t><div class='dijitReset dijitValidationContainer'\r\n\t\t><input class=\"dijitReset dijitInputField dijitValidationIcon dijitValidationInner\" value=\"&#935;\" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t/></div\r\n\t><div class=\"dijitReset dijitInputField dijitInputContainer\"\r\n\t\t><input class='dijitReset dijitInputInner' dojoAttachPoint=\"textbox,focusNode\" type=\"${type}\" dojoAttachEvent=\"onkeypress:_onKeyPress\"\r\n\t\t\trole=\"spinbutton\" autocomplete=\"off\" ${!nameAttrSetting}\r\n\t/></div\r\n></div>\r\n"),baseClass:"dijitTextBox dijitSpinner",cssStateNodes:{"upArrowNode":"dijitUpArrowButton","downArrowNode":"dijitDownArrowButton"},adjust:function(val,_be7){
return val;
},_arrowPressed:function(_be8,_be9,_bea){
if(this.disabled||this.readOnly){
return;
}
this._setValueAttr(this.adjust(this.get("value"),_be9*_bea),false);
dijit.selectInputText(this.textbox,this.textbox.value.length);
},_arrowReleased:function(node){
this._wheelTimer=null;
if(this.disabled||this.readOnly){
return;
}
},_typematicCallback:function(_beb,node,evt){
var inc=this.smallDelta;
if(node==this.textbox){
var k=dojo.keys;
var key=evt.charOrCode;
inc=(key==k.PAGE_UP||key==k.PAGE_DOWN)?this.largeDelta:this.smallDelta;
node=(key==k.UP_ARROW||key==k.PAGE_UP)?this.upArrowNode:this.downArrowNode;
}
if(_beb==-1){
this._arrowReleased(node);
}else{
this._arrowPressed(node,(node==this.upArrowNode)?1:-1,inc);
}
},_wheelTimer:null,_mouseWheeled:function(evt){
dojo.stopEvent(evt);
var _bec=evt.detail?(evt.detail*-1):(evt.wheelDelta/120);
if(_bec!==0){
var node=this[(_bec>0?"upArrowNode":"downArrowNode")];
this._arrowPressed(node,_bec,this.smallDelta);
if(!this._wheelTimer){
clearTimeout(this._wheelTimer);
}
this._wheelTimer=setTimeout(dojo.hitch(this,"_arrowReleased",node),50);
}
},postCreate:function(){
this.inherited(arguments);
this.connect(this.domNode,!dojo.isMozilla?"onmousewheel":"DOMMouseScroll","_mouseWheeled");
this._connects.push(dijit.typematic.addListener(this.upArrowNode,this.textbox,{charOrCode:dojo.keys.UP_ARROW,ctrlKey:false,altKey:false,shiftKey:false,metaKey:false},this,"_typematicCallback",this.timeoutChangeRate,this.defaultTimeout,this.minimumTimeout));
this._connects.push(dijit.typematic.addListener(this.downArrowNode,this.textbox,{charOrCode:dojo.keys.DOWN_ARROW,ctrlKey:false,altKey:false,shiftKey:false,metaKey:false},this,"_typematicCallback",this.timeoutChangeRate,this.defaultTimeout,this.minimumTimeout));
this._connects.push(dijit.typematic.addListener(this.upArrowNode,this.textbox,{charOrCode:dojo.keys.PAGE_UP,ctrlKey:false,altKey:false,shiftKey:false,metaKey:false},this,"_typematicCallback",this.timeoutChangeRate,this.defaultTimeout,this.minimumTimeout));
this._connects.push(dijit.typematic.addListener(this.downArrowNode,this.textbox,{charOrCode:dojo.keys.PAGE_DOWN,ctrlKey:false,altKey:false,shiftKey:false,metaKey:false},this,"_typematicCallback",this.timeoutChangeRate,this.defaultTimeout,this.minimumTimeout));
}});
}
if(!dojo._hasResource["dojo.number"]){
dojo._hasResource["dojo.number"]=true;
dojo.provide("dojo.number");
dojo.getObject("number",true,dojo);
dojo.number.format=function(_bed,_bee){
_bee=dojo.mixin({},_bee||{});
var _bef=dojo.i18n.normalizeLocale(_bee.locale),_bf0=dojo.i18n.getLocalization("dojo.cldr","number",_bef);
_bee.customs=_bf0;
var _bf1=_bee.pattern||_bf0[(_bee.type||"decimal")+"Format"];
if(isNaN(_bed)||Math.abs(_bed)==Infinity){
return null;
}
return dojo.number._applyPattern(_bed,_bf1,_bee);
};
dojo.number._numberPatternRE=/[#0,]*[#0](?:\.0*#*)?/;
dojo.number._applyPattern=function(_bf2,_bf3,_bf4){
_bf4=_bf4||{};
var _bf5=_bf4.customs.group,_bf6=_bf4.customs.decimal,_bf7=_bf3.split(";"),_bf8=_bf7[0];
_bf3=_bf7[(_bf2<0)?1:0]||("-"+_bf8);
if(_bf3.indexOf("%")!=-1){
_bf2*=100;
}else{
if(_bf3.indexOf("‰")!=-1){
_bf2*=1000;
}else{
if(_bf3.indexOf("¤")!=-1){
_bf5=_bf4.customs.currencyGroup||_bf5;
_bf6=_bf4.customs.currencyDecimal||_bf6;
_bf3=_bf3.replace(/\u00a4{1,3}/,function(_bf9){
var prop=["symbol","currency","displayName"][_bf9.length-1];
return _bf4[prop]||_bf4.currency||"";
});
}else{
if(_bf3.indexOf("E")!=-1){
throw new Error("exponential notation not supported");
}
}
}
}
var _bfa=dojo.number._numberPatternRE;
var _bfb=_bf8.match(_bfa);
if(!_bfb){
throw new Error("unable to find a number expression in pattern: "+_bf3);
}
if(_bf4.fractional===false){
_bf4.places=0;
}
return _bf3.replace(_bfa,dojo.number._formatAbsolute(_bf2,_bfb[0],{decimal:_bf6,group:_bf5,places:_bf4.places,round:_bf4.round}));
};
dojo.number.round=function(_bfc,_bfd,_bfe){
var _bff=10/(_bfe||10);
return (_bff*+_bfc).toFixed(_bfd)/_bff;
};
if((0.9).toFixed()==0){
(function(){
var _c00=dojo.number.round;
dojo.number.round=function(v,p,m){
var d=Math.pow(10,-p||0),a=Math.abs(v);
if(!v||a>=d||a*Math.pow(10,p+1)<5){
d=0;
}
return _c00(v,p,m)+(v>0?d:-d);
};
})();
}
dojo.number._formatAbsolute=function(_c01,_c02,_c03){
_c03=_c03||{};
if(_c03.places===true){
_c03.places=0;
}
if(_c03.places===Infinity){
_c03.places=6;
}
var _c04=_c02.split("."),_c05=typeof _c03.places=="string"&&_c03.places.indexOf(","),_c06=_c03.places;
if(_c05){
_c06=_c03.places.substring(_c05+1);
}else{
if(!(_c06>=0)){
_c06=(_c04[1]||[]).length;
}
}
if(!(_c03.round<0)){
_c01=dojo.number.round(_c01,_c06,_c03.round);
}
var _c07=String(Math.abs(_c01)).split("."),_c08=_c07[1]||"";
if(_c04[1]||_c03.places){
if(_c05){
_c03.places=_c03.places.substring(0,_c05);
}
var pad=_c03.places!==undefined?_c03.places:(_c04[1]&&_c04[1].lastIndexOf("0")+1);
if(pad>_c08.length){
_c07[1]=dojo.string.pad(_c08,pad,"0",true);
}
if(_c06<_c08.length){
_c07[1]=_c08.substr(0,_c06);
}
}else{
if(_c07[1]){
_c07.pop();
}
}
var _c09=_c04[0].replace(",","");
pad=_c09.indexOf("0");
if(pad!=-1){
pad=_c09.length-pad;
if(pad>_c07[0].length){
_c07[0]=dojo.string.pad(_c07[0],pad);
}
if(_c09.indexOf("#")==-1){
_c07[0]=_c07[0].substr(_c07[0].length-pad);
}
}
var _c0a=_c04[0].lastIndexOf(","),_c0b,_c0c;
if(_c0a!=-1){
_c0b=_c04[0].length-_c0a-1;
var _c0d=_c04[0].substr(0,_c0a);
_c0a=_c0d.lastIndexOf(",");
if(_c0a!=-1){
_c0c=_c0d.length-_c0a-1;
}
}
var _c0e=[];
for(var _c0f=_c07[0];_c0f;){
var off=_c0f.length-_c0b;
_c0e.push((off>0)?_c0f.substr(off):_c0f);
_c0f=(off>0)?_c0f.slice(0,off):"";
if(_c0c){
_c0b=_c0c;
delete _c0c;
}
}
_c07[0]=_c0e.reverse().join(_c03.group||",");
return _c07.join(_c03.decimal||".");
};
dojo.number.regexp=function(_c10){
return dojo.number._parseInfo(_c10).regexp;
};
dojo.number._parseInfo=function(_c11){
_c11=_c11||{};
var _c12=dojo.i18n.normalizeLocale(_c11.locale),_c13=dojo.i18n.getLocalization("dojo.cldr","number",_c12),_c14=_c11.pattern||_c13[(_c11.type||"decimal")+"Format"],_c15=_c13.group,_c16=_c13.decimal,_c17=1;
if(_c14.indexOf("%")!=-1){
_c17/=100;
}else{
if(_c14.indexOf("‰")!=-1){
_c17/=1000;
}else{
var _c18=_c14.indexOf("¤")!=-1;
if(_c18){
_c15=_c13.currencyGroup||_c15;
_c16=_c13.currencyDecimal||_c16;
}
}
}
var _c19=_c14.split(";");
if(_c19.length==1){
_c19.push("-"+_c19[0]);
}
var re=dojo.regexp.buildGroupRE(_c19,function(_c1a){
_c1a="(?:"+dojo.regexp.escapeString(_c1a,".")+")";
return _c1a.replace(dojo.number._numberPatternRE,function(_c1b){
var _c1c={signed:false,separator:_c11.strict?_c15:[_c15,""],fractional:_c11.fractional,decimal:_c16,exponent:false},_c1d=_c1b.split("."),_c1e=_c11.places;
if(_c1d.length==1&&_c17!=1){
_c1d[1]="###";
}
if(_c1d.length==1||_c1e===0){
_c1c.fractional=false;
}else{
if(_c1e===undefined){
_c1e=_c11.pattern?_c1d[1].lastIndexOf("0")+1:Infinity;
}
if(_c1e&&_c11.fractional==undefined){
_c1c.fractional=true;
}
if(!_c11.places&&(_c1e<_c1d[1].length)){
_c1e+=","+_c1d[1].length;
}
_c1c.places=_c1e;
}
var _c1f=_c1d[0].split(",");
if(_c1f.length>1){
_c1c.groupSize=_c1f.pop().length;
if(_c1f.length>1){
_c1c.groupSize2=_c1f.pop().length;
}
}
return "("+dojo.number._realNumberRegexp(_c1c)+")";
});
},true);
if(_c18){
re=re.replace(/([\s\xa0]*)(\u00a4{1,3})([\s\xa0]*)/g,function(_c20,_c21,_c22,_c23){
var prop=["symbol","currency","displayName"][_c22.length-1],_c24=dojo.regexp.escapeString(_c11[prop]||_c11.currency||"");
_c21=_c21?"[\\s\\xa0]":"";
_c23=_c23?"[\\s\\xa0]":"";
if(!_c11.strict){
if(_c21){
_c21+="*";
}
if(_c23){
_c23+="*";
}
return "(?:"+_c21+_c24+_c23+")?";
}
return _c21+_c24+_c23;
});
}
return {regexp:re.replace(/[\xa0 ]/g,"[\\s\\xa0]"),group:_c15,decimal:_c16,factor:_c17};
};
dojo.number.parse=function(_c25,_c26){
var info=dojo.number._parseInfo(_c26),_c27=(new RegExp("^"+info.regexp+"$")).exec(_c25);
if(!_c27){
return NaN;
}
var _c28=_c27[1];
if(!_c27[1]){
if(!_c27[2]){
return NaN;
}
_c28=_c27[2];
info.factor*=-1;
}
_c28=_c28.replace(new RegExp("["+info.group+"\\s\\xa0"+"]","g"),"").replace(info.decimal,".");
return _c28*info.factor;
};
dojo.number._realNumberRegexp=function(_c29){
_c29=_c29||{};
if(!("places" in _c29)){
_c29.places=Infinity;
}
if(typeof _c29.decimal!="string"){
_c29.decimal=".";
}
if(!("fractional" in _c29)||/^0/.test(_c29.places)){
_c29.fractional=[true,false];
}
if(!("exponent" in _c29)){
_c29.exponent=[true,false];
}
if(!("eSigned" in _c29)){
_c29.eSigned=[true,false];
}
var _c2a=dojo.number._integerRegexp(_c29),_c2b=dojo.regexp.buildGroupRE(_c29.fractional,function(q){
var re="";
if(q&&(_c29.places!==0)){
re="\\"+_c29.decimal;
if(_c29.places==Infinity){
re="(?:"+re+"\\d+)?";
}else{
re+="\\d{"+_c29.places+"}";
}
}
return re;
},true);
var _c2c=dojo.regexp.buildGroupRE(_c29.exponent,function(q){
if(q){
return "([eE]"+dojo.number._integerRegexp({signed:_c29.eSigned})+")";
}
return "";
});
var _c2d=_c2a+_c2b;
if(_c2b){
_c2d="(?:(?:"+_c2d+")|(?:"+_c2b+"))";
}
return _c2d+_c2c;
};
dojo.number._integerRegexp=function(_c2e){
_c2e=_c2e||{};
if(!("signed" in _c2e)){
_c2e.signed=[true,false];
}
if(!("separator" in _c2e)){
_c2e.separator="";
}else{
if(!("groupSize" in _c2e)){
_c2e.groupSize=3;
}
}
var _c2f=dojo.regexp.buildGroupRE(_c2e.signed,function(q){
return q?"[-+]":"";
},true);
var _c30=dojo.regexp.buildGroupRE(_c2e.separator,function(sep){
if(!sep){
return "(?:\\d+)";
}
sep=dojo.regexp.escapeString(sep);
if(sep==" "){
sep="\\s";
}else{
if(sep==" "){
sep="\\s\\xa0";
}
}
var grp=_c2e.groupSize,grp2=_c2e.groupSize2;
if(grp2){
var _c31="(?:0|[1-9]\\d{0,"+(grp2-1)+"}(?:["+sep+"]\\d{"+grp2+"})*["+sep+"]\\d{"+grp+"})";
return ((grp-grp2)>0)?"(?:"+_c31+"|(?:0|[1-9]\\d{0,"+(grp-1)+"}))":_c31;
}
return "(?:0|[1-9]\\d{0,"+(grp-1)+"}(?:["+sep+"]\\d{"+grp+"})*)";
},true);
return _c2f+_c30;
};
}
if(!dojo._hasResource["dijit.form.NumberTextBox"]){
dojo._hasResource["dijit.form.NumberTextBox"]=true;
dojo.provide("dijit.form.NumberTextBox");
dojo.declare("dijit.form.NumberTextBoxMixin",null,{regExpGen:dojo.number.regexp,value:NaN,editOptions:{pattern:"#.######"},_formatter:dojo.number.format,_setConstraintsAttr:function(_c32){
var _c33=typeof _c32.places=="number"?_c32.places:0;
if(_c33){
_c33++;
}
if(typeof _c32.max!="number"){
_c32.max=9*Math.pow(10,15-_c33);
}
if(typeof _c32.min!="number"){
_c32.min=-9*Math.pow(10,15-_c33);
}
this.inherited(arguments,[_c32]);
if(this.focusNode&&this.focusNode.value&&!isNaN(this.value)){
this.set("value",this.value);
}
},_onFocus:function(){
if(this.disabled){
return;
}
var val=this.get("value");
if(typeof val=="number"&&!isNaN(val)){
var _c34=this.format(val,this.constraints);
if(_c34!==undefined){
this.textbox.value=_c34;
}
}
this.inherited(arguments);
},format:function(_c35,_c36){
var _c37=String(_c35);
if(typeof _c35!="number"){
return _c37;
}
if(isNaN(_c35)){
return "";
}
if(!("rangeCheck" in this&&this.rangeCheck(_c35,_c36))&&_c36.exponent!==false&&/\de[-+]?\d/i.test(_c37)){
return _c37;
}
if(this.editOptions&&this._focused){
_c36=dojo.mixin({},_c36,this.editOptions);
}
return this._formatter(_c35,_c36);
},_parser:dojo.number.parse,parse:function(_c38,_c39){
var v=this._parser(_c38,dojo.mixin({},_c39,(this.editOptions&&this._focused)?this.editOptions:{}));
if(this.editOptions&&this._focused&&isNaN(v)){
v=this._parser(_c38,_c39);
}
return v;
},_getDisplayedValueAttr:function(){
var v=this.inherited(arguments);
return isNaN(v)?this.textbox.value:v;
},filter:function(_c3a){
return (_c3a===null||_c3a===""||_c3a===undefined)?NaN:this.inherited(arguments);
},serialize:function(_c3b,_c3c){
return (typeof _c3b!="number"||isNaN(_c3b))?"":this.inherited(arguments);
},_setBlurValue:function(){
var val=dojo.hitch(dojo.mixin({},this,{_focused:true}),"get")("value");
this._setValueAttr(val,true);
},_setValueAttr:function(_c3d,_c3e,_c3f){
if(_c3d!==undefined&&_c3f===undefined){
_c3f=String(_c3d);
if(typeof _c3d=="number"){
if(isNaN(_c3d)){
_c3f="";
}else{
if(("rangeCheck" in this&&this.rangeCheck(_c3d,this.constraints))||this.constraints.exponent===false||!/\de[-+]?\d/i.test(_c3f)){
_c3f=undefined;
}
}
}else{
if(!_c3d){
_c3f="";
_c3d=NaN;
}else{
_c3d=undefined;
}
}
}
this.inherited(arguments,[_c3d,_c3e,_c3f]);
},_getValueAttr:function(){
var v=this.inherited(arguments);
if(isNaN(v)&&this.textbox.value!==""){
if(this.constraints.exponent!==false&&/\de[-+]?\d/i.test(this.textbox.value)&&(new RegExp("^"+dojo.number._realNumberRegexp(dojo.mixin({},this.constraints))+"$").test(this.textbox.value))){
var n=Number(this.textbox.value);
return isNaN(n)?undefined:n;
}else{
return undefined;
}
}else{
return v;
}
},isValid:function(_c40){
if(!this._focused||this._isEmpty(this.textbox.value)){
return this.inherited(arguments);
}else{
var v=this.get("value");
if(!isNaN(v)&&this.rangeCheck(v,this.constraints)){
if(this.constraints.exponent!==false&&/\de[-+]?\d/i.test(this.textbox.value)){
return true;
}else{
return this.inherited(arguments);
}
}else{
return false;
}
}
}});
dojo.declare("dijit.form.NumberTextBox",[dijit.form.RangeBoundTextBox,dijit.form.NumberTextBoxMixin],{baseClass:"dijitTextBox dijitNumberTextBox"});
}
if(!dojo._hasResource["dijit.form.NumberSpinner"]){
dojo._hasResource["dijit.form.NumberSpinner"]=true;
dojo.provide("dijit.form.NumberSpinner");
dojo.declare("dijit.form.NumberSpinner",[dijit.form._Spinner,dijit.form.NumberTextBoxMixin],{adjust:function(val,_c41){
var tc=this.constraints,v=isNaN(val),_c42=!isNaN(tc.max),_c43=!isNaN(tc.min);
if(v&&_c41!=0){
val=(_c41>0)?_c43?tc.min:_c42?tc.max:0:_c42?this.constraints.max:_c43?tc.min:0;
}
var _c44=val+_c41;
if(v||isNaN(_c44)){
return val;
}
if(_c42&&(_c44>tc.max)){
_c44=tc.max;
}
if(_c43&&(_c44<tc.min)){
_c44=tc.min;
}
return _c44;
},_onKeyPress:function(e){
if((e.charOrCode==dojo.keys.HOME||e.charOrCode==dojo.keys.END)&&!(e.ctrlKey||e.altKey||e.metaKey)&&typeof this.get("value")!="undefined"){
var _c45=this.constraints[(e.charOrCode==dojo.keys.HOME?"min":"max")];
if(typeof _c45=="number"){
this._setValueAttr(_c45,false);
}
dojo.stopEvent(e);
}
}});
}
if(!dojo._hasResource["dojo.cldr.monetary"]){
dojo._hasResource["dojo.cldr.monetary"]=true;
dojo.provide("dojo.cldr.monetary");
dojo.getObject("cldr.monetary",true,dojo);
dojo.cldr.monetary.getData=function(code){
var _c46={ADP:0,AFN:0,ALL:0,AMD:0,BHD:3,BIF:0,BYR:0,CLF:0,CLP:0,COP:0,CRC:0,DJF:0,ESP:0,GNF:0,GYD:0,HUF:0,IDR:0,IQD:0,IRR:3,ISK:0,ITL:0,JOD:3,JPY:0,KMF:0,KPW:0,KRW:0,KWD:3,LAK:0,LBP:0,LUF:0,LYD:3,MGA:0,MGF:0,MMK:0,MNT:0,MRO:0,MUR:0,OMR:3,PKR:0,PYG:0,RSD:0,RWF:0,SLL:0,SOS:0,STD:0,SYP:0,TMM:0,TND:3,TRL:0,TZS:0,UGX:0,UZS:0,VND:0,VUV:0,XAF:0,XOF:0,XPF:0,YER:0,ZMK:0,ZWD:0};
var _c47={CHF:5};
var _c48=_c46[code],_c49=_c47[code];
if(typeof _c48=="undefined"){
_c48=2;
}
if(typeof _c49=="undefined"){
_c49=0;
}
return {places:_c48,round:_c49};
};
}
if(!dojo._hasResource["dojo.currency"]){
dojo._hasResource["dojo.currency"]=true;
dojo.provide("dojo.currency");
dojo.getObject("currency",true,dojo);
dojo.currency._mixInDefaults=function(_c4a){
_c4a=_c4a||{};
_c4a.type="currency";
var _c4b=dojo.i18n.getLocalization("dojo.cldr","currency",_c4a.locale)||{};
var iso=_c4a.currency;
var data=dojo.cldr.monetary.getData(iso);
dojo.forEach(["displayName","symbol","group","decimal"],function(prop){
data[prop]=_c4b[iso+"_"+prop];
});
data.fractional=[true,false];
return dojo.mixin(data,_c4a);
};
dojo.currency.format=function(_c4c,_c4d){
return dojo.number.format(_c4c,dojo.currency._mixInDefaults(_c4d));
};
dojo.currency.regexp=function(_c4e){
return dojo.number.regexp(dojo.currency._mixInDefaults(_c4e));
};
dojo.currency.parse=function(_c4f,_c50){
return dojo.number.parse(_c4f,dojo.currency._mixInDefaults(_c50));
};
}
if(!dojo._hasResource["dijit.form.CurrencyTextBox"]){
dojo._hasResource["dijit.form.CurrencyTextBox"]=true;
dojo.provide("dijit.form.CurrencyTextBox");
dojo.declare("dijit.form.CurrencyTextBox",dijit.form.NumberTextBox,{currency:"",baseClass:"dijitTextBox dijitCurrencyTextBox",regExpGen:function(_c51){
return "("+(this._focused?this.inherited(arguments,[dojo.mixin({},_c51,this.editOptions)])+"|":"")+dojo.currency.regexp(_c51)+")";
},_formatter:dojo.currency.format,_parser:dojo.currency.parse,parse:function(_c52,_c53){
var v=this.inherited(arguments);
if(isNaN(v)&&/\d+/.test(_c52)){
v=dojo.hitch(dojo.mixin({},this,{_parser:dijit.form.NumberTextBox.prototype._parser}),"inherited")(arguments);
}
return v;
},_setConstraintsAttr:function(_c54){
if(!_c54.currency&&this.currency){
_c54.currency=this.currency;
}
this.inherited(arguments,[dojo.currency._mixInDefaults(dojo.mixin(_c54,{exponent:false}))]);
}});
}
if(!dojo._hasResource["dijit.form.HorizontalSlider"]){
dojo._hasResource["dijit.form.HorizontalSlider"]=true;
dojo.provide("dijit.form.HorizontalSlider");
dojo.declare("dijit.form.HorizontalSlider",[dijit.form._FormValueWidget,dijit._Container],{templateString:dojo.cache("dijit.form","templates/HorizontalSlider.html","<table class=\"dijit dijitReset dijitSlider dijitSliderH\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\" rules=\"none\" dojoAttachEvent=\"onkeypress:_onKeyPress,onkeyup:_onKeyUp\"\r\n\t><tr class=\"dijitReset\"\r\n\t\t><td class=\"dijitReset\" colspan=\"2\"></td\r\n\t\t><td dojoAttachPoint=\"topDecoration\" class=\"dijitReset dijitSliderDecoration dijitSliderDecorationT dijitSliderDecorationH\"></td\r\n\t\t><td class=\"dijitReset\" colspan=\"2\"></td\r\n\t></tr\r\n\t><tr class=\"dijitReset\"\r\n\t\t><td class=\"dijitReset dijitSliderButtonContainer dijitSliderButtonContainerH\"\r\n\t\t\t><div class=\"dijitSliderDecrementIconH\" style=\"display:none\" dojoAttachPoint=\"decrementButton\"><span class=\"dijitSliderButtonInner\">-</span></div\r\n\t\t></td\r\n\t\t><td class=\"dijitReset\"\r\n\t\t\t><div class=\"dijitSliderBar dijitSliderBumper dijitSliderBumperH dijitSliderLeftBumper\" dojoAttachEvent=\"onmousedown:_onClkDecBumper\"></div\r\n\t\t></td\r\n\t\t><td class=\"dijitReset\"\r\n\t\t\t><input dojoAttachPoint=\"valueNode\" type=\"hidden\" ${!nameAttrSetting}\r\n\t\t\t/><div class=\"dijitReset dijitSliderBarContainerH\" role=\"presentation\" dojoAttachPoint=\"sliderBarContainer\"\r\n\t\t\t\t><div role=\"presentation\" dojoAttachPoint=\"progressBar\" class=\"dijitSliderBar dijitSliderBarH dijitSliderProgressBar dijitSliderProgressBarH\" dojoAttachEvent=\"onmousedown:_onBarClick\"\r\n\t\t\t\t\t><div class=\"dijitSliderMoveable dijitSliderMoveableH\"\r\n\t\t\t\t\t\t><div dojoAttachPoint=\"sliderHandle,focusNode\" class=\"dijitSliderImageHandle dijitSliderImageHandleH\" dojoAttachEvent=\"onmousedown:_onHandleClick\" role=\"slider\" valuemin=\"${minimum}\" valuemax=\"${maximum}\"></div\r\n\t\t\t\t\t></div\r\n\t\t\t\t></div\r\n\t\t\t\t><div role=\"presentation\" dojoAttachPoint=\"remainingBar\" class=\"dijitSliderBar dijitSliderBarH dijitSliderRemainingBar dijitSliderRemainingBarH\" dojoAttachEvent=\"onmousedown:_onBarClick\"></div\r\n\t\t\t></div\r\n\t\t></td\r\n\t\t><td class=\"dijitReset\"\r\n\t\t\t><div class=\"dijitSliderBar dijitSliderBumper dijitSliderBumperH dijitSliderRightBumper\" dojoAttachEvent=\"onmousedown:_onClkIncBumper\"></div\r\n\t\t></td\r\n\t\t><td class=\"dijitReset dijitSliderButtonContainer dijitSliderButtonContainerH\"\r\n\t\t\t><div class=\"dijitSliderIncrementIconH\" style=\"display:none\" dojoAttachPoint=\"incrementButton\"><span class=\"dijitSliderButtonInner\">+</span></div\r\n\t\t></td\r\n\t></tr\r\n\t><tr class=\"dijitReset\"\r\n\t\t><td class=\"dijitReset\" colspan=\"2\"></td\r\n\t\t><td dojoAttachPoint=\"containerNode,bottomDecoration\" class=\"dijitReset dijitSliderDecoration dijitSliderDecorationB dijitSliderDecorationH\"></td\r\n\t\t><td class=\"dijitReset\" colspan=\"2\"></td\r\n\t></tr\r\n></table>\r\n"),value:0,showButtons:true,minimum:0,maximum:100,discreteValues:Infinity,pageIncrement:2,clickSelect:true,slideDuration:dijit.defaultDuration,widgetsInTemplate:true,attributeMap:dojo.delegate(dijit.form._FormWidget.prototype.attributeMap,{id:""}),baseClass:"dijitSlider",cssStateNodes:{incrementButton:"dijitSliderIncrementButton",decrementButton:"dijitSliderDecrementButton",focusNode:"dijitSliderThumb"},_mousePixelCoord:"pageX",_pixelCount:"w",_startingPixelCoord:"x",_startingPixelCount:"l",_handleOffsetCoord:"left",_progressPixelSize:"width",_onKeyUp:function(e){
if(this.disabled||this.readOnly||e.altKey||e.ctrlKey||e.metaKey){
return;
}
this._setValueAttr(this.value,true);
},_onKeyPress:function(e){
if(this.disabled||this.readOnly||e.altKey||e.ctrlKey||e.metaKey){
return;
}
switch(e.charOrCode){
case dojo.keys.HOME:
this._setValueAttr(this.minimum,false);
break;
case dojo.keys.END:
this._setValueAttr(this.maximum,false);
break;
case ((this._descending||this.isLeftToRight())?dojo.keys.RIGHT_ARROW:dojo.keys.LEFT_ARROW):
case (this._descending===false?dojo.keys.DOWN_ARROW:dojo.keys.UP_ARROW):
case (this._descending===false?dojo.keys.PAGE_DOWN:dojo.keys.PAGE_UP):
this.increment(e);
break;
case ((this._descending||this.isLeftToRight())?dojo.keys.LEFT_ARROW:dojo.keys.RIGHT_ARROW):
case (this._descending===false?dojo.keys.UP_ARROW:dojo.keys.DOWN_ARROW):
case (this._descending===false?dojo.keys.PAGE_UP:dojo.keys.PAGE_DOWN):
this.decrement(e);
break;
default:
return;
}
dojo.stopEvent(e);
},_onHandleClick:function(e){
if(this.disabled||this.readOnly){
return;
}
if(!dojo.isIE){
dijit.focus(this.sliderHandle);
}
dojo.stopEvent(e);
},_isReversed:function(){
return !this.isLeftToRight();
},_onBarClick:function(e){
if(this.disabled||this.readOnly||!this.clickSelect){
return;
}
dijit.focus(this.sliderHandle);
dojo.stopEvent(e);
var _c55=dojo.position(this.sliderBarContainer,true);
var _c56=e[this._mousePixelCoord]-_c55[this._startingPixelCoord];
this._setPixelValue(this._isReversed()?(_c55[this._pixelCount]-_c56):_c56,_c55[this._pixelCount],true);
this._movable.onMouseDown(e);
},_setPixelValue:function(_c57,_c58,_c59){
if(this.disabled||this.readOnly){
return;
}
_c57=_c57<0?0:_c58<_c57?_c58:_c57;
var _c5a=this.discreteValues;
if(_c5a<=1||_c5a==Infinity){
_c5a=_c58;
}
_c5a--;
var _c5b=_c58/_c5a;
var _c5c=Math.round(_c57/_c5b);
this._setValueAttr((this.maximum-this.minimum)*_c5c/_c5a+this.minimum,_c59);
},_setValueAttr:function(_c5d,_c5e){
this._set("value",_c5d);
this.valueNode.value=_c5d;
dijit.setWaiState(this.focusNode,"valuenow",_c5d);
this.inherited(arguments);
var _c5f=(_c5d-this.minimum)/(this.maximum-this.minimum);
var _c60=(this._descending===false)?this.remainingBar:this.progressBar;
var _c61=(this._descending===false)?this.progressBar:this.remainingBar;
if(this._inProgressAnim&&this._inProgressAnim.status!="stopped"){
this._inProgressAnim.stop(true);
}
if(_c5e&&this.slideDuration>0&&_c60.style[this._progressPixelSize]){
var _c62=this;
var _c63={};
var _c64=parseFloat(_c60.style[this._progressPixelSize]);
var _c65=this.slideDuration*(_c5f-_c64/100);
if(_c65==0){
return;
}
if(_c65<0){
_c65=0-_c65;
}
_c63[this._progressPixelSize]={start:_c64,end:_c5f*100,units:"%"};
this._inProgressAnim=dojo.animateProperty({node:_c60,duration:_c65,onAnimate:function(v){
_c61.style[_c62._progressPixelSize]=(100-parseFloat(v[_c62._progressPixelSize]))+"%";
},onEnd:function(){
delete _c62._inProgressAnim;
},properties:_c63});
this._inProgressAnim.play();
}else{
_c60.style[this._progressPixelSize]=(_c5f*100)+"%";
_c61.style[this._progressPixelSize]=((1-_c5f)*100)+"%";
}
},_bumpValue:function(_c66,_c67){
if(this.disabled||this.readOnly){
return;
}
var s=dojo.getComputedStyle(this.sliderBarContainer);
var c=dojo._getContentBox(this.sliderBarContainer,s);
var _c68=this.discreteValues;
if(_c68<=1||_c68==Infinity){
_c68=c[this._pixelCount];
}
_c68--;
var _c69=(this.value-this.minimum)*_c68/(this.maximum-this.minimum)+_c66;
if(_c69<0){
_c69=0;
}
if(_c69>_c68){
_c69=_c68;
}
_c69=_c69*(this.maximum-this.minimum)/_c68+this.minimum;
this._setValueAttr(_c69,_c67);
},_onClkBumper:function(val){
if(this.disabled||this.readOnly||!this.clickSelect){
return;
}
this._setValueAttr(val,true);
},_onClkIncBumper:function(){
this._onClkBumper(this._descending===false?this.minimum:this.maximum);
},_onClkDecBumper:function(){
this._onClkBumper(this._descending===false?this.maximum:this.minimum);
},decrement:function(e){
this._bumpValue(e.charOrCode==dojo.keys.PAGE_DOWN?-this.pageIncrement:-1);
},increment:function(e){
this._bumpValue(e.charOrCode==dojo.keys.PAGE_UP?this.pageIncrement:1);
},_mouseWheeled:function(evt){
dojo.stopEvent(evt);
var _c6a=!dojo.isMozilla;
var _c6b=evt[(_c6a?"wheelDelta":"detail")]*(_c6a?1:-1);
this._bumpValue(_c6b<0?-1:1,true);
},startup:function(){
if(this._started){
return;
}
dojo.forEach(this.getChildren(),function(_c6c){
if(this[_c6c.container]!=this.containerNode){
this[_c6c.container].appendChild(_c6c.domNode);
}
},this);
this.inherited(arguments);
},_typematicCallback:function(_c6d,_c6e,e){
if(_c6d==-1){
this._setValueAttr(this.value,true);
}else{
this[(_c6e==(this._descending?this.incrementButton:this.decrementButton))?"decrement":"increment"](e);
}
},buildRendering:function(){
this.inherited(arguments);
if(this.showButtons){
this.incrementButton.style.display="";
this.decrementButton.style.display="";
}
var _c6f=dojo.query("label[for=\""+this.id+"\"]");
if(_c6f.length){
_c6f[0].id=(this.id+"_label");
dijit.setWaiState(this.focusNode,"labelledby",_c6f[0].id);
}
dijit.setWaiState(this.focusNode,"valuemin",this.minimum);
dijit.setWaiState(this.focusNode,"valuemax",this.maximum);
},postCreate:function(){
this.inherited(arguments);
if(this.showButtons){
this._connects.push(dijit.typematic.addMouseListener(this.decrementButton,this,"_typematicCallback",25,500));
this._connects.push(dijit.typematic.addMouseListener(this.incrementButton,this,"_typematicCallback",25,500));
}
this.connect(this.domNode,!dojo.isMozilla?"onmousewheel":"DOMMouseScroll","_mouseWheeled");
var _c70=dojo.declare(dijit.form._SliderMover,{widget:this});
this._movable=new dojo.dnd.Moveable(this.sliderHandle,{mover:_c70});
this._layoutHackIE7();
},destroy:function(){
this._movable.destroy();
if(this._inProgressAnim&&this._inProgressAnim.status!="stopped"){
this._inProgressAnim.stop(true);
}
this._supportingWidgets=dijit.findWidgets(this.domNode);
this.inherited(arguments);
}});
dojo.declare("dijit.form._SliderMover",dojo.dnd.Mover,{onMouseMove:function(e){
var _c71=this.widget;
var _c72=_c71._abspos;
if(!_c72){
_c72=_c71._abspos=dojo.position(_c71.sliderBarContainer,true);
_c71._setPixelValue_=dojo.hitch(_c71,"_setPixelValue");
_c71._isReversed_=_c71._isReversed();
}
var _c73=e.touches?e.touches[0]:e,_c74=_c73[_c71._mousePixelCoord]-_c72[_c71._startingPixelCoord];
_c71._setPixelValue_(_c71._isReversed_?(_c72[_c71._pixelCount]-_c74):_c74,_c72[_c71._pixelCount],false);
},destroy:function(e){
dojo.dnd.Mover.prototype.destroy.apply(this,arguments);
var _c75=this.widget;
_c75._abspos=null;
_c75._setValueAttr(_c75.value,true);
}});
}
if(!dojo._hasResource["dijit._editor.selection"]){
dojo._hasResource["dijit._editor.selection"]=true;
dojo.provide("dijit._editor.selection");
dojo.getObject("_editor.selection",true,dijit);
dojo.mixin(dijit._editor.selection,{getType:function(){
if(dojo.isIE<9){
return dojo.doc.selection.type.toLowerCase();
}else{
var _c76="text";
var oSel;
try{
oSel=dojo.global.getSelection();
}
catch(e){
}
if(oSel&&oSel.rangeCount==1){
var _c77=oSel.getRangeAt(0);
if((_c77.startContainer==_c77.endContainer)&&((_c77.endOffset-_c77.startOffset)==1)&&(_c77.startContainer.nodeType!=3)){
_c76="control";
}
}
return _c76;
}
},getSelectedText:function(){
if(dojo.isIE<9){
if(dijit._editor.selection.getType()=="control"){
return null;
}
return dojo.doc.selection.createRange().text;
}else{
var _c78=dojo.global.getSelection();
if(_c78){
return _c78.toString();
}
}
return "";
},getSelectedHtml:function(){
if(dojo.isIE<9){
if(dijit._editor.selection.getType()=="control"){
return null;
}
return dojo.doc.selection.createRange().htmlText;
}else{
var _c79=dojo.global.getSelection();
if(_c79&&_c79.rangeCount){
var i;
var html="";
for(i=0;i<_c79.rangeCount;i++){
var frag=_c79.getRangeAt(i).cloneContents();
var div=dojo.doc.createElement("div");
div.appendChild(frag);
html+=div.innerHTML;
}
return html;
}
return null;
}
},getSelectedElement:function(){
if(dijit._editor.selection.getType()=="control"){
if(dojo.isIE<9){
var _c7a=dojo.doc.selection.createRange();
if(_c7a&&_c7a.item){
return dojo.doc.selection.createRange().item(0);
}
}else{
var _c7b=dojo.global.getSelection();
return _c7b.anchorNode.childNodes[_c7b.anchorOffset];
}
}
return null;
},getParentElement:function(){
if(dijit._editor.selection.getType()=="control"){
var p=this.getSelectedElement();
if(p){
return p.parentNode;
}
}else{
if(dojo.isIE<9){
var r=dojo.doc.selection.createRange();
r.collapse(true);
return r.parentElement();
}else{
var _c7c=dojo.global.getSelection();
if(_c7c){
var node=_c7c.anchorNode;
while(node&&(node.nodeType!=1)){
node=node.parentNode;
}
return node;
}
}
}
return null;
},hasAncestorElement:function(_c7d){
return this.getAncestorElement.apply(this,arguments)!=null;
},getAncestorElement:function(_c7e){
var node=this.getSelectedElement()||this.getParentElement();
return this.getParentOfType(node,arguments);
},isTag:function(node,tags){
if(node&&node.tagName){
var _c7f=node.tagName.toLowerCase();
for(var i=0;i<tags.length;i++){
var _c80=String(tags[i]).toLowerCase();
if(_c7f==_c80){
return _c80;
}
}
}
return "";
},getParentOfType:function(node,tags){
while(node){
if(this.isTag(node,tags).length){
return node;
}
node=node.parentNode;
}
return null;
},collapse:function(_c81){
if(window.getSelection){
var _c82=dojo.global.getSelection();
if(_c82.removeAllRanges){
if(_c81){
_c82.collapseToStart();
}else{
_c82.collapseToEnd();
}
}else{
_c82.collapse(_c81);
}
}else{
if(dojo.isIE){
var _c83=dojo.doc.selection.createRange();
_c83.collapse(_c81);
_c83.select();
}
}
},remove:function(){
var sel=dojo.doc.selection;
if(dojo.isIE<9){
if(sel.type.toLowerCase()!="none"){
sel.clear();
}
return sel;
}else{
sel=dojo.global.getSelection();
sel.deleteFromDocument();
return sel;
}
},selectElementChildren:function(_c84,_c85){
var win=dojo.global;
var doc=dojo.doc;
var _c86;
_c84=dojo.byId(_c84);
if(doc.selection&&dojo.isIE<9&&dojo.body().createTextRange){
_c86=_c84.ownerDocument.body.createTextRange();
_c86.moveToElementText(_c84);
if(!_c85){
try{
_c86.select();
}
catch(e){
}
}
}else{
if(win.getSelection){
var _c87=dojo.global.getSelection();
if(dojo.isOpera){
if(_c87.rangeCount){
_c86=_c87.getRangeAt(0);
}else{
_c86=doc.createRange();
}
_c86.setStart(_c84,0);
_c86.setEnd(_c84,(_c84.nodeType==3)?_c84.length:_c84.childNodes.length);
_c87.addRange(_c86);
}else{
_c87.selectAllChildren(_c84);
}
}
}
},selectElement:function(_c88,_c89){
var _c8a;
var doc=dojo.doc;
var win=dojo.global;
_c88=dojo.byId(_c88);
if(dojo.isIE<9&&dojo.body().createTextRange){
try{
var tg=_c88.tagName?_c88.tagName.toLowerCase():"";
if(tg==="img"||tg==="table"){
_c8a=dojo.body().createControlRange();
}else{
_c8a=dojo.body().createRange();
}
_c8a.addElement(_c88);
if(!_c89){
_c8a.select();
}
}
catch(e){
this.selectElementChildren(_c88,_c89);
}
}else{
if(dojo.global.getSelection){
var _c8b=win.getSelection();
_c8a=doc.createRange();
if(_c8b.removeAllRanges){
if(dojo.isOpera){
if(_c8b.getRangeAt(0)){
_c8a=_c8b.getRangeAt(0);
}
}
_c8a.selectNode(_c88);
_c8b.removeAllRanges();
_c8b.addRange(_c8a);
}
}
}
},inSelection:function(node){
if(node){
var _c8c;
var doc=dojo.doc;
var _c8d;
if(dojo.global.getSelection){
var sel=dojo.global.getSelection();
if(sel&&sel.rangeCount>0){
_c8d=sel.getRangeAt(0);
}
if(_c8d&&_c8d.compareBoundaryPoints&&doc.createRange){
try{
_c8c=doc.createRange();
_c8c.setStart(node,0);
if(_c8d.compareBoundaryPoints(_c8d.START_TO_END,_c8c)===1){
return true;
}
}
catch(e){
}
}
}else{
if(doc.selection){
_c8d=doc.selection.createRange();
try{
_c8c=node.ownerDocument.body.createControlRange();
if(_c8c){
_c8c.addElement(node);
}
}
catch(e1){
try{
_c8c=node.ownerDocument.body.createTextRange();
_c8c.moveToElementText(node);
}
catch(e2){
}
}
if(_c8d&&_c8c){
if(_c8d.compareEndPoints("EndToStart",_c8c)===1){
return true;
}
}
}
}
}
return false;
}});
}
if(!dojo._hasResource["dijit._editor.range"]){
dojo._hasResource["dijit._editor.range"]=true;
dojo.provide("dijit._editor.range");
dijit.range={};
dijit.range.getIndex=function(node,_c8e){
var ret=[],retR=[];
var stop=_c8e;
var _c8f=node;
var _c90,n;
while(node!=stop){
var i=0;
_c90=node.parentNode;
while((n=_c90.childNodes[i++])){
if(n===node){
--i;
break;
}
}
ret.unshift(i);
retR.unshift(i-_c90.childNodes.length);
node=_c90;
}
if(ret.length>0&&_c8f.nodeType==3){
n=_c8f.previousSibling;
while(n&&n.nodeType==3){
ret[ret.length-1]--;
n=n.previousSibling;
}
n=_c8f.nextSibling;
while(n&&n.nodeType==3){
retR[retR.length-1]++;
n=n.nextSibling;
}
}
return {o:ret,r:retR};
};
dijit.range.getNode=function(_c91,_c92){
if(!dojo.isArray(_c91)||_c91.length==0){
return _c92;
}
var node=_c92;
dojo.every(_c91,function(i){
if(i>=0&&i<node.childNodes.length){
node=node.childNodes[i];
}else{
node=null;
return false;
}
return true;
});
return node;
};
dijit.range.getCommonAncestor=function(n1,n2,root){
root=root||n1.ownerDocument.body;
var _c93=function(n){
var as=[];
while(n){
as.unshift(n);
if(n!==root){
n=n.parentNode;
}else{
break;
}
}
return as;
};
var n1as=_c93(n1);
var n2as=_c93(n2);
var m=Math.min(n1as.length,n2as.length);
var com=n1as[0];
for(var i=1;i<m;i++){
if(n1as[i]===n2as[i]){
com=n1as[i];
}else{
break;
}
}
return com;
};
dijit.range.getAncestor=function(node,_c94,root){
root=root||node.ownerDocument.body;
while(node&&node!==root){
var name=node.nodeName.toUpperCase();
if(_c94.test(name)){
return node;
}
node=node.parentNode;
}
return null;
};
dijit.range.BlockTagNames=/^(?:P|DIV|H1|H2|H3|H4|H5|H6|ADDRESS|PRE|OL|UL|LI|DT|DE)$/;
dijit.range.getBlockAncestor=function(node,_c95,root){
root=root||node.ownerDocument.body;
_c95=_c95||dijit.range.BlockTagNames;
var _c96=null,_c97;
while(node&&node!==root){
var name=node.nodeName.toUpperCase();
if(!_c96&&_c95.test(name)){
_c96=node;
}
if(!_c97&&(/^(?:BODY|TD|TH|CAPTION)$/).test(name)){
_c97=node;
}
node=node.parentNode;
}
return {blockNode:_c96,blockContainer:_c97||node.ownerDocument.body};
};
dijit.range.atBeginningOfContainer=function(_c98,node,_c99){
var _c9a=false;
var _c9b=(_c99==0);
if(!_c9b&&node.nodeType==3){
if(/^[\s\xA0]+$/.test(node.nodeValue.substr(0,_c99))){
_c9b=true;
}
}
if(_c9b){
var _c9c=node;
_c9a=true;
while(_c9c&&_c9c!==_c98){
if(_c9c.previousSibling){
_c9a=false;
break;
}
_c9c=_c9c.parentNode;
}
}
return _c9a;
};
dijit.range.atEndOfContainer=function(_c9d,node,_c9e){
var _c9f=false;
var _ca0=(_c9e==(node.length||node.childNodes.length));
if(!_ca0&&node.nodeType==3){
if(/^[\s\xA0]+$/.test(node.nodeValue.substr(_c9e))){
_ca0=true;
}
}
if(_ca0){
var _ca1=node;
_c9f=true;
while(_ca1&&_ca1!==_c9d){
if(_ca1.nextSibling){
_c9f=false;
break;
}
_ca1=_ca1.parentNode;
}
}
return _c9f;
};
dijit.range.adjacentNoneTextNode=function(_ca2,next){
var node=_ca2;
var len=(0-_ca2.length)||0;
var prop=next?"nextSibling":"previousSibling";
while(node){
if(node.nodeType!=3){
break;
}
len+=node.length;
node=node[prop];
}
return [node,len];
};
dijit.range._w3c=Boolean(window["getSelection"]);
dijit.range.create=function(win){
if(dijit.range._w3c){
return (win||dojo.global).document.createRange();
}else{
return new dijit.range.W3CRange;
}
};
dijit.range.getSelection=function(win,_ca3){
if(dijit.range._w3c){
return win.getSelection();
}else{
var s=new dijit.range.ie.selection(win);
if(!_ca3){
s._getCurrentSelection();
}
return s;
}
};
if(!dijit.range._w3c){
dijit.range.ie={cachedSelection:{},selection:function(win){
this._ranges=[];
this.addRange=function(r,_ca4){
this._ranges.push(r);
if(!_ca4){
r._select();
}
this.rangeCount=this._ranges.length;
};
this.removeAllRanges=function(){
this._ranges=[];
this.rangeCount=0;
};
var _ca5=function(){
var r=win.document.selection.createRange();
var type=win.document.selection.type.toUpperCase();
if(type=="CONTROL"){
return new dijit.range.W3CRange(dijit.range.ie.decomposeControlRange(r));
}else{
return new dijit.range.W3CRange(dijit.range.ie.decomposeTextRange(r));
}
};
this.getRangeAt=function(i){
return this._ranges[i];
};
this._getCurrentSelection=function(){
this.removeAllRanges();
var r=_ca5();
if(r){
this.addRange(r,true);
}
};
},decomposeControlRange:function(_ca6){
var _ca7=_ca6.item(0),_ca8=_ca6.item(_ca6.length-1);
var _ca9=_ca7.parentNode,_caa=_ca8.parentNode;
var _cab=dijit.range.getIndex(_ca7,_ca9).o;
var _cac=dijit.range.getIndex(_ca8,_caa).o+1;
return [_ca9,_cab,_caa,_cac];
},getEndPoint:function(_cad,end){
var _cae=_cad.duplicate();
_cae.collapse(!end);
var _caf="EndTo"+(end?"End":"Start");
var _cb0=_cae.parentElement();
var _cb1,_cb2,_cb3;
if(_cb0.childNodes.length>0){
dojo.every(_cb0.childNodes,function(node,i){
var _cb4;
if(node.nodeType!=3){
_cae.moveToElementText(node);
if(_cae.compareEndPoints(_caf,_cad)>0){
if(_cb3&&_cb3.nodeType==3){
_cb1=_cb3;
_cb4=true;
}else{
_cb1=_cb0;
_cb2=i;
return false;
}
}else{
if(i==_cb0.childNodes.length-1){
_cb1=_cb0;
_cb2=_cb0.childNodes.length;
return false;
}
}
}else{
if(i==_cb0.childNodes.length-1){
_cb1=node;
_cb4=true;
}
}
if(_cb4&&_cb1){
var _cb5=dijit.range.adjacentNoneTextNode(_cb1)[0];
if(_cb5){
_cb1=_cb5.nextSibling;
}else{
_cb1=_cb0.firstChild;
}
var _cb6=dijit.range.adjacentNoneTextNode(_cb1);
_cb5=_cb6[0];
var _cb7=_cb6[1];
if(_cb5){
_cae.moveToElementText(_cb5);
_cae.collapse(false);
}else{
_cae.moveToElementText(_cb0);
}
_cae.setEndPoint(_caf,_cad);
_cb2=_cae.text.length-_cb7;
return false;
}
_cb3=node;
return true;
});
}else{
_cb1=_cb0;
_cb2=0;
}
if(!end&&_cb1.nodeType==1&&_cb2==_cb1.childNodes.length){
var _cb8=_cb1.nextSibling;
if(_cb8&&_cb8.nodeType==3){
_cb1=_cb8;
_cb2=0;
}
}
return [_cb1,_cb2];
},setEndPoint:function(_cb9,_cba,_cbb){
var _cbc=_cb9.duplicate(),node,len;
if(_cba.nodeType!=3){
if(_cbb>0){
node=_cba.childNodes[_cbb-1];
if(node){
if(node.nodeType==3){
_cba=node;
_cbb=node.length;
}else{
if(node.nextSibling&&node.nextSibling.nodeType==3){
_cba=node.nextSibling;
_cbb=0;
}else{
_cbc.moveToElementText(node.nextSibling?node:_cba);
var _cbd=node.parentNode;
var _cbe=_cbd.insertBefore(node.ownerDocument.createTextNode(" "),node.nextSibling);
_cbc.collapse(false);
_cbd.removeChild(_cbe);
}
}
}
}else{
_cbc.moveToElementText(_cba);
_cbc.collapse(true);
}
}
if(_cba.nodeType==3){
var _cbf=dijit.range.adjacentNoneTextNode(_cba);
var _cc0=_cbf[0];
len=_cbf[1];
if(_cc0){
_cbc.moveToElementText(_cc0);
_cbc.collapse(false);
if(_cc0.contentEditable!="inherit"){
len++;
}
}else{
_cbc.moveToElementText(_cba.parentNode);
_cbc.collapse(true);
}
_cbb+=len;
if(_cbb>0){
if(_cbc.move("character",_cbb)!=_cbb){
console.error("Error when moving!");
}
}
}
return _cbc;
},decomposeTextRange:function(_cc1){
var _cc2=dijit.range.ie.getEndPoint(_cc1);
var _cc3=_cc2[0],_cc4=_cc2[1];
var _cc5=_cc2[0],_cc6=_cc2[1];
if(_cc1.htmlText.length){
if(_cc1.htmlText==_cc1.text){
_cc6=_cc4+_cc1.text.length;
}else{
_cc2=dijit.range.ie.getEndPoint(_cc1,true);
_cc5=_cc2[0],_cc6=_cc2[1];
}
}
return [_cc3,_cc4,_cc5,_cc6];
},setRange:function(_cc7,_cc8,_cc9,_cca,_ccb,_ccc){
var _ccd=dijit.range.ie.setEndPoint(_cc7,_cc8,_cc9);
_cc7.setEndPoint("StartToStart",_ccd);
if(!_ccc){
var end=dijit.range.ie.setEndPoint(_cc7,_cca,_ccb);
}
_cc7.setEndPoint("EndToEnd",end||_ccd);
return _cc7;
}};
dojo.declare("dijit.range.W3CRange",null,{constructor:function(){
if(arguments.length>0){
this.setStart(arguments[0][0],arguments[0][1]);
this.setEnd(arguments[0][2],arguments[0][3]);
}else{
this.commonAncestorContainer=null;
this.startContainer=null;
this.startOffset=0;
this.endContainer=null;
this.endOffset=0;
this.collapsed=true;
}
},_updateInternal:function(){
if(this.startContainer!==this.endContainer){
this.commonAncestorContainer=dijit.range.getCommonAncestor(this.startContainer,this.endContainer);
}else{
this.commonAncestorContainer=this.startContainer;
}
this.collapsed=(this.startContainer===this.endContainer)&&(this.startOffset==this.endOffset);
},setStart:function(node,_cce){
_cce=parseInt(_cce);
if(this.startContainer===node&&this.startOffset==_cce){
return;
}
delete this._cachedBookmark;
this.startContainer=node;
this.startOffset=_cce;
if(!this.endContainer){
this.setEnd(node,_cce);
}else{
this._updateInternal();
}
},setEnd:function(node,_ccf){
_ccf=parseInt(_ccf);
if(this.endContainer===node&&this.endOffset==_ccf){
return;
}
delete this._cachedBookmark;
this.endContainer=node;
this.endOffset=_ccf;
if(!this.startContainer){
this.setStart(node,_ccf);
}else{
this._updateInternal();
}
},setStartAfter:function(node,_cd0){
this._setPoint("setStart",node,_cd0,1);
},setStartBefore:function(node,_cd1){
this._setPoint("setStart",node,_cd1,0);
},setEndAfter:function(node,_cd2){
this._setPoint("setEnd",node,_cd2,1);
},setEndBefore:function(node,_cd3){
this._setPoint("setEnd",node,_cd3,0);
},_setPoint:function(what,node,_cd4,ext){
var _cd5=dijit.range.getIndex(node,node.parentNode).o;
this[what](node.parentNode,_cd5.pop()+ext);
},_getIERange:function(){
var r=(this._body||this.endContainer.ownerDocument.body).createTextRange();
dijit.range.ie.setRange(r,this.startContainer,this.startOffset,this.endContainer,this.endOffset,this.collapsed);
return r;
},getBookmark:function(body){
this._getIERange();
return this._cachedBookmark;
},_select:function(){
var r=this._getIERange();
r.select();
},deleteContents:function(){
var r=this._getIERange();
r.pasteHTML("");
this.endContainer=this.startContainer;
this.endOffset=this.startOffset;
this.collapsed=true;
},cloneRange:function(){
var r=new dijit.range.W3CRange([this.startContainer,this.startOffset,this.endContainer,this.endOffset]);
r._body=this._body;
return r;
},detach:function(){
this._body=null;
this.commonAncestorContainer=null;
this.startContainer=null;
this.startOffset=0;
this.endContainer=null;
this.endOffset=0;
this.collapsed=true;
}});
}
}
if(!dojo._hasResource["dijit._editor.html"]){
dojo._hasResource["dijit._editor.html"]=true;
dojo.provide("dijit._editor.html");
var exports=dojo.getObject("_editor",true,dijit);
var escape=exports.escapeXml=function(str,_cd6){
str=str.replace(/&/gm,"&amp;").replace(/</gm,"&lt;").replace(/>/gm,"&gt;").replace(/"/gm,"&quot;");
if(!_cd6){
str=str.replace(/'/gm,"&#39;");
}
return str;
};
exports.getNodeHtml=function(node){
var _cd7=[];
exports.getNodeHtmlHelper(node,_cd7);
return _cd7.join("");
};
exports.getNodeHtmlHelper=function(node,_cd8){
switch(node.nodeType){
case 1:
var _cd9=node.nodeName.toLowerCase();
if(!_cd9||_cd9.charAt(0)=="/"){
return "";
}
_cd8.push("<",_cd9);
var _cda=[];
var attr;
if(dojo.isIE){
var _cdb=/^input$|^img$/i.test(node.nodeName)?node:node.cloneNode(false);
var s=_cdb.outerHTML;
s=s.substr(0,s.indexOf(">")).replace(/(['"])[^"']*\1/g,"");
var reg=/(\b\w+)\s?=/g;
var m,key;
while((m=reg.exec(s))){
key=m[1];
if(key.substr(0,3)!="_dj"){
if(key=="src"||key=="href"){
if(node.getAttribute("_djrealurl")){
_cda.push([key,node.getAttribute("_djrealurl")]);
continue;
}
}
var val,_cdc;
switch(key){
case "style":
val=node.style.cssText.toLowerCase();
break;
case "class":
val=node.className;
break;
case "width":
if(_cd9==="img"){
_cdc=/width=(\S+)/i.exec(s);
if(_cdc){
val=_cdc[1];
}
break;
}
case "height":
if(_cd9==="img"){
_cdc=/height=(\S+)/i.exec(s);
if(_cdc){
val=_cdc[1];
}
break;
}
default:
val=node.getAttribute(key);
}
if(val!=null){
_cda.push([key,val.toString()]);
}
}
}
}else{
var i=0;
while((attr=node.attributes[i++])){
var n=attr.name;
if(n.substr(0,3)!="_dj"){
var v=attr.value;
if(n=="src"||n=="href"){
if(node.getAttribute("_djrealurl")){
v=node.getAttribute("_djrealurl");
}
}
_cda.push([n,v]);
}
}
}
_cda.sort(function(a,b){
return a[0]<b[0]?-1:(a[0]==b[0]?0:1);
});
var j=0;
while((attr=_cda[j++])){
_cd8.push(" ",attr[0],"=\"",(dojo.isString(attr[1])?escape(attr[1],true):attr[1]),"\"");
}
switch(_cd9){
case "br":
case "hr":
case "img":
case "input":
case "base":
case "meta":
case "area":
case "basefont":
_cd8.push(" />");
break;
case "script":
_cd8.push(">",node.innerHTML,"</",_cd9,">");
break;
default:
_cd8.push(">");
if(node.hasChildNodes()){
exports.getChildrenHtmlHelper(node,_cd8);
}
_cd8.push("</",_cd9,">");
}
break;
case 4:
case 3:
_cd8.push(escape(node.nodeValue,true));
break;
case 8:
_cd8.push("<!--",escape(node.nodeValue,true),"-->");
break;
default:
_cd8.push("<!-- Element not recognized - Type: ",node.nodeType," Name: ",node.nodeName,"-->");
}
};
exports.getChildrenHtml=function(node){
var _cdd=[];
exports.getChildrenHtmlHelper(node,_cdd);
return _cdd.join("");
};
exports.getChildrenHtmlHelper=function(dom,_cde){
if(!dom){
return;
}
var _cdf=dom["childNodes"]||dom;
var _ce0=!dojo.isIE||_cdf!==dom;
var node,i=0;
while((node=_cdf[i++])){
if(!_ce0||node.parentNode==dom){
exports.getNodeHtmlHelper(node,_cde);
}
}
};
}
if(!dojo._hasResource["dijit._editor.RichText"]){
dojo._hasResource["dijit._editor.RichText"]=true;
dojo.provide("dijit._editor.RichText");
if(!dojo.config["useXDomain"]||dojo.config["allowXdRichTextSave"]){
if(dojo._postLoad){
(function(){
var _ce1=dojo.doc.createElement("textarea");
_ce1.id=dijit._scopeName+"._editor.RichText.value";
dojo.style(_ce1,{display:"none",position:"absolute",top:"-100px",height:"3px",width:"3px"});
dojo.body().appendChild(_ce1);
})();
}else{
try{
dojo.doc.write("<textarea id=\""+dijit._scopeName+"._editor.RichText.value\" "+"style=\"display:none;position:absolute;top:-100px;left:-100px;height:3px;width:3px;overflow:hidden;\"></textarea>");
}
catch(e){
}
}
}
dojo.declare("dijit._editor.RichText",[dijit._Widget,dijit._CssStateMixin],{constructor:function(_ce2){
this.contentPreFilters=[];
this.contentPostFilters=[];
this.contentDomPreFilters=[];
this.contentDomPostFilters=[];
this.editingAreaStyleSheets=[];
this.events=[].concat(this.events);
this._keyHandlers={};
if(_ce2&&dojo.isString(_ce2.value)){
this.value=_ce2.value;
}
this.onLoadDeferred=new dojo.Deferred();
},baseClass:"dijitEditor",inheritWidth:false,focusOnLoad:false,name:"",styleSheets:"",height:"300px",minHeight:"1em",isClosed:true,isLoaded:false,_SEPARATOR:"@@**%%__RICHTEXTBOUNDRY__%%**@@",_NAME_CONTENT_SEP:"@@**%%:%%**@@",onLoadDeferred:null,isTabIndent:false,disableSpellCheck:false,postCreate:function(){
if("textarea"==this.domNode.tagName.toLowerCase()){
console.warn("RichText should not be used with the TEXTAREA tag.  See dijit._editor.RichText docs.");
}
this.contentPreFilters=[dojo.hitch(this,"_preFixUrlAttributes")].concat(this.contentPreFilters);
if(dojo.isMoz){
this.contentPreFilters=[this._normalizeFontStyle].concat(this.contentPreFilters);
this.contentPostFilters=[this._removeMozBogus].concat(this.contentPostFilters);
}
if(dojo.isWebKit){
this.contentPreFilters=[this._removeWebkitBogus].concat(this.contentPreFilters);
this.contentPostFilters=[this._removeWebkitBogus].concat(this.contentPostFilters);
}
if(dojo.isIE){
this.contentPostFilters=[this._normalizeFontStyle].concat(this.contentPostFilters);
}
this.inherited(arguments);
dojo.publish(dijit._scopeName+"._editor.RichText::init",[this]);
this.open();
this.setupDefaultShortcuts();
},setupDefaultShortcuts:function(){
var exec=dojo.hitch(this,function(cmd,arg){
return function(){
return !this.execCommand(cmd,arg);
};
});
var _ce3={b:exec("bold"),i:exec("italic"),u:exec("underline"),a:exec("selectall"),s:function(){
this.save(true);
},m:function(){
this.isTabIndent=!this.isTabIndent;
},"1":exec("formatblock","h1"),"2":exec("formatblock","h2"),"3":exec("formatblock","h3"),"4":exec("formatblock","h4"),"\\":exec("insertunorderedlist")};
if(!dojo.isIE){
_ce3.Z=exec("redo");
}
for(var key in _ce3){
this.addKeyHandler(key,true,false,_ce3[key]);
}
},events:["onKeyPress","onKeyDown","onKeyUp"],captureEvents:[],_editorCommandsLocalized:false,_localizeEditorCommands:function(){
if(dijit._editor._editorCommandsLocalized){
this._local2NativeFormatNames=dijit._editor._local2NativeFormatNames;
this._native2LocalFormatNames=dijit._editor._native2LocalFormatNames;
return;
}
dijit._editor._editorCommandsLocalized=true;
dijit._editor._local2NativeFormatNames={};
dijit._editor._native2LocalFormatNames={};
this._local2NativeFormatNames=dijit._editor._local2NativeFormatNames;
this._native2LocalFormatNames=dijit._editor._native2LocalFormatNames;
var _ce4=["div","p","pre","h1","h2","h3","h4","h5","h6","ol","ul","address"];
var _ce5="",_ce6,i=0;
while((_ce6=_ce4[i++])){
if(_ce6.charAt(1)!=="l"){
_ce5+="<"+_ce6+"><span>content</span></"+_ce6+"><br/>";
}else{
_ce5+="<"+_ce6+"><li>content</li></"+_ce6+"><br/>";
}
}
var _ce7={position:"absolute",top:"0px",zIndex:10,opacity:0.01};
var div=dojo.create("div",{style:_ce7,innerHTML:_ce5});
dojo.body().appendChild(div);
var _ce8=dojo.hitch(this,function(){
var node=div.firstChild;
while(node){
try{
dijit._editor.selection.selectElement(node.firstChild);
var _ce9=node.tagName.toLowerCase();
this._local2NativeFormatNames[_ce9]=document.queryCommandValue("formatblock");
this._native2LocalFormatNames[this._local2NativeFormatNames[_ce9]]=_ce9;
node=node.nextSibling.nextSibling;
}
catch(e){
}
}
div.parentNode.removeChild(div);
div.innerHTML="";
});
setTimeout(_ce8,0);
},open:function(_cea){
if(!this.onLoadDeferred||this.onLoadDeferred.fired>=0){
this.onLoadDeferred=new dojo.Deferred();
}
if(!this.isClosed){
this.close();
}
dojo.publish(dijit._scopeName+"._editor.RichText::open",[this]);
if(arguments.length==1&&_cea.nodeName){
this.domNode=_cea;
}
var dn=this.domNode;
var html;
if(dojo.isString(this.value)){
html=this.value;
delete this.value;
dn.innerHTML="";
}else{
if(dn.nodeName&&dn.nodeName.toLowerCase()=="textarea"){
var ta=(this.textarea=dn);
this.name=ta.name;
html=ta.value;
dn=this.domNode=dojo.doc.createElement("div");
dn.setAttribute("widgetId",this.id);
ta.removeAttribute("widgetId");
dn.cssText=ta.cssText;
dn.className+=" "+ta.className;
dojo.place(dn,ta,"before");
var _ceb=dojo.hitch(this,function(){
dojo.style(ta,{display:"block",position:"absolute",top:"-1000px"});
if(dojo.isIE){
var s=ta.style;
this.__overflow=s.overflow;
s.overflow="hidden";
}
});
if(dojo.isIE){
setTimeout(_ceb,10);
}else{
_ceb();
}
if(ta.form){
var _cec=ta.value;
this.reset=function(){
var _ced=this.getValue();
if(_ced!=_cec){
this.replaceValue(_cec);
}
};
dojo.connect(ta.form,"onsubmit",this,function(){
dojo.attr(ta,"disabled",this.disabled);
ta.value=this.getValue();
});
}
}else{
html=dijit._editor.getChildrenHtml(dn);
dn.innerHTML="";
}
}
var _cee=dojo.contentBox(dn);
this._oldHeight=_cee.h;
this._oldWidth=_cee.w;
this.value=html;
if(dn.nodeName&&dn.nodeName=="LI"){
dn.innerHTML=" <br>";
}
this.header=dn.ownerDocument.createElement("div");
dn.appendChild(this.header);
this.editingArea=dn.ownerDocument.createElement("div");
dn.appendChild(this.editingArea);
this.footer=dn.ownerDocument.createElement("div");
dn.appendChild(this.footer);
if(!this.name){
this.name=this.id+"_AUTOGEN";
}
if(this.name!==""&&(!dojo.config["useXDomain"]||dojo.config["allowXdRichTextSave"])){
var _cef=dojo.byId(dijit._scopeName+"._editor.RichText.value");
if(_cef&&_cef.value!==""){
var _cf0=_cef.value.split(this._SEPARATOR),i=0,dat;
while((dat=_cf0[i++])){
var data=dat.split(this._NAME_CONTENT_SEP);
if(data[0]==this.name){
html=data[1];
_cf0=_cf0.splice(i,1);
_cef.value=_cf0.join(this._SEPARATOR);
break;
}
}
}
if(!dijit._editor._globalSaveHandler){
dijit._editor._globalSaveHandler={};
dojo.addOnUnload(function(){
var id;
for(id in dijit._editor._globalSaveHandler){
var f=dijit._editor._globalSaveHandler[id];
if(dojo.isFunction(f)){
f();
}
}
});
}
dijit._editor._globalSaveHandler[this.id]=dojo.hitch(this,"_saveContent");
}
this.isClosed=false;
var ifr=(this.editorObject=this.iframe=dojo.doc.createElement("iframe"));
ifr.id=this.id+"_iframe";
this._iframeSrc=this._getIframeDocTxt();
ifr.style.border="none";
ifr.style.width="100%";
if(this._layoutMode){
ifr.style.height="100%";
}else{
if(dojo.isIE>=7){
if(this.height){
ifr.style.height=this.height;
}
if(this.minHeight){
ifr.style.minHeight=this.minHeight;
}
}else{
ifr.style.height=this.height?this.height:this.minHeight;
}
}
ifr.frameBorder=0;
ifr._loadFunc=dojo.hitch(this,function(win){
this.window=win;
this.document=this.window.document;
if(dojo.isIE){
this._localizeEditorCommands();
}
this.onLoad(html);
});
var s="javascript:parent."+dijit._scopeName+".byId(\""+this.id+"\")._iframeSrc";
ifr.setAttribute("src",s);
this.editingArea.appendChild(ifr);
if(dojo.isSafari<=4){
var src=ifr.getAttribute("src");
if(!src||src.indexOf("javascript")==-1){
setTimeout(function(){
ifr.setAttribute("src",s);
},0);
}
}
if(dn.nodeName=="LI"){
dn.lastChild.style.marginTop="-1.2em";
}
dojo.addClass(this.domNode,this.baseClass);
},_local2NativeFormatNames:{},_native2LocalFormatNames:{},_getIframeDocTxt:function(){
var _cf1=dojo.getComputedStyle(this.domNode);
var html="";
var _cf2=true;
if(dojo.isIE||dojo.isWebKit||(!this.height&&!dojo.isMoz)){
html="<div id='dijitEditorBody'></div>";
_cf2=false;
}else{
if(dojo.isMoz){
this._cursorToStart=true;
html="&nbsp;";
}
}
var font=[_cf1.fontWeight,_cf1.fontSize,_cf1.fontFamily].join(" ");
var _cf3=_cf1.lineHeight;
if(_cf3.indexOf("px")>=0){
_cf3=parseFloat(_cf3)/parseFloat(_cf1.fontSize);
}else{
if(_cf3.indexOf("em")>=0){
_cf3=parseFloat(_cf3);
}else{
_cf3="normal";
}
}
var _cf4="";
var self=this;
this.style.replace(/(^|;)\s*(line-|font-?)[^;]+/ig,function(_cf5){
_cf5=_cf5.replace(/^;/ig,"")+";";
var s=_cf5.split(":")[0];
if(s){
s=dojo.trim(s);
s=s.toLowerCase();
var i;
var sC="";
for(i=0;i<s.length;i++){
var c=s.charAt(i);
switch(c){
case "-":
i++;
c=s.charAt(i).toUpperCase();
default:
sC+=c;
}
}
dojo.style(self.domNode,sC,"");
}
_cf4+=_cf5+";";
});
var _cf6=dojo.query("label[for=\""+this.id+"\"]");
return [this.isLeftToRight()?"<html>\n<head>\n":"<html dir='rtl'>\n<head>\n",(dojo.isMoz&&_cf6.length?"<title>"+_cf6[0].innerHTML+"</title>\n":""),"<meta http-equiv='Content-Type' content='text/html'>\n","<style>\n","\tbody,html {\n","\t\tbackground:transparent;\n","\t\tpadding: 1px 0 0 0;\n","\t\tmargin: -1px 0 0 0;\n",((dojo.isWebKit)?"\t\twidth: 100%;\n":""),((dojo.isWebKit)?"\t\theight: 100%;\n":""),"\t}\n","\tbody{\n","\t\ttop:0px;\n","\t\tleft:0px;\n","\t\tright:0px;\n","\t\tfont:",font,";\n",((this.height||dojo.isOpera)?"":"\t\tposition: fixed;\n"),"\t\tmin-height:",this.minHeight,";\n","\t\tline-height:",_cf3,";\n","\t}\n","\tp{ margin: 1em 0; }\n",(!_cf2&&!this.height?"\tbody,html {overflow-y: hidden;}\n":""),"\t#dijitEditorBody{overflow-x: auto; overflow-y:"+(this.height?"auto;":"hidden;")+" outline: 0px;}\n","\tli > ul:-moz-first-node, li > ol:-moz-first-node{ padding-top: 1.2em; }\n",(!dojo.isIE?"\tli{ min-height:1.2em; }\n":""),"</style>\n",this._applyEditingAreaStyleSheets(),"\n","</head>\n<body ",(_cf2?"id='dijitEditorBody' ":""),"onload='frameElement._loadFunc(window,document)' style='"+_cf4+"'>",html,"</body>\n</html>"].join("");
},_applyEditingAreaStyleSheets:function(){
var _cf7=[];
if(this.styleSheets){
_cf7=this.styleSheets.split(";");
this.styleSheets="";
}
_cf7=_cf7.concat(this.editingAreaStyleSheets);
this.editingAreaStyleSheets=[];
var text="",i=0,url;
while((url=_cf7[i++])){
var _cf8=(new dojo._Url(dojo.global.location,url)).toString();
this.editingAreaStyleSheets.push(_cf8);
text+="<link rel=\"stylesheet\" type=\"text/css\" href=\""+_cf8+"\"/>";
}
return text;
},addStyleSheet:function(uri){
var url=uri.toString();
if(url.charAt(0)=="."||(url.charAt(0)!="/"&&!uri.host)){
url=(new dojo._Url(dojo.global.location,url)).toString();
}
if(dojo.indexOf(this.editingAreaStyleSheets,url)>-1){
return;
}
this.editingAreaStyleSheets.push(url);
this.onLoadDeferred.addCallback(dojo.hitch(this,function(){
if(this.document.createStyleSheet){
this.document.createStyleSheet(url);
}else{
var head=this.document.getElementsByTagName("head")[0];
var _cf9=this.document.createElement("link");
_cf9.rel="stylesheet";
_cf9.type="text/css";
_cf9.href=url;
head.appendChild(_cf9);
}
}));
},removeStyleSheet:function(uri){
var url=uri.toString();
if(url.charAt(0)=="."||(url.charAt(0)!="/"&&!uri.host)){
url=(new dojo._Url(dojo.global.location,url)).toString();
}
var _cfa=dojo.indexOf(this.editingAreaStyleSheets,url);
if(_cfa==-1){
return;
}
delete this.editingAreaStyleSheets[_cfa];
dojo.withGlobal(this.window,"query",dojo,["link:[href=\""+url+"\"]"]).orphan();
},disabled:false,_mozSettingProps:{"styleWithCSS":false},_setDisabledAttr:function(_cfb){
_cfb=!!_cfb;
this._set("disabled",_cfb);
if(!this.isLoaded){
return;
}
if(dojo.isIE||dojo.isWebKit||dojo.isOpera){
var _cfc=dojo.isIE&&(this.isLoaded||!this.focusOnLoad);
if(_cfc){
this.editNode.unselectable="on";
}
this.editNode.contentEditable=!_cfb;
if(_cfc){
var _cfd=this;
setTimeout(function(){
_cfd.editNode.unselectable="off";
},0);
}
}else{
try{
this.document.designMode=(_cfb?"off":"on");
}
catch(e){
return;
}
if(!_cfb&&this._mozSettingProps){
var ps=this._mozSettingProps;
for(var n in ps){
if(ps.hasOwnProperty(n)){
try{
this.document.execCommand(n,false,ps[n]);
}
catch(e2){
}
}
}
}
}
this._disabledOK=true;
},onLoad:function(html){
if(!this.window.__registeredWindow){
this.window.__registeredWindow=true;
this._iframeRegHandle=dijit.registerIframe(this.iframe);
}
if(!dojo.isIE&&!dojo.isWebKit&&(this.height||dojo.isMoz)){
this.editNode=this.document.body;
}else{
this.editNode=this.document.body.firstChild;
var _cfe=this;
if(dojo.isIE){
this.tabStop=dojo.create("div",{tabIndex:-1},this.editingArea);
this.iframe.onfocus=function(){
_cfe.editNode.setActive();
};
}
}
this.focusNode=this.editNode;
var _cff=this.events.concat(this.captureEvents);
var ap=this.iframe?this.document:this.editNode;
dojo.forEach(_cff,function(item){
this.connect(ap,item.toLowerCase(),item);
},this);
this.connect(ap,"onmouseup","onClick");
if(dojo.isIE){
this.connect(this.document,"onmousedown","_onIEMouseDown");
this.editNode.style.zoom=1;
}else{
this.connect(this.document,"onmousedown",function(){
delete this._cursorToStart;
});
}
if(dojo.isWebKit){
this._webkitListener=this.connect(this.document,"onmouseup","onDisplayChanged");
this.connect(this.document,"onmousedown",function(e){
var t=e.target;
if(t&&(t===this.document.body||t===this.document)){
setTimeout(dojo.hitch(this,"placeCursorAtEnd"),0);
}
});
}
if(dojo.isIE){
try{
this.document.execCommand("RespectVisibilityInDesign",true,null);
}
catch(e){
}
}
this.isLoaded=true;
this.set("disabled",this.disabled);
var _d00=dojo.hitch(this,function(){
this.setValue(html);
if(this.onLoadDeferred){
this.onLoadDeferred.callback(true);
}
this.onDisplayChanged();
if(this.focusOnLoad){
dojo.addOnLoad(dojo.hitch(this,function(){
setTimeout(dojo.hitch(this,"focus"),this.updateInterval);
}));
}
this.value=this.getValue(true);
});
if(this.setValueDeferred){
this.setValueDeferred.addCallback(_d00);
}else{
_d00();
}
},onKeyDown:function(e){
if(e.keyCode===dojo.keys.TAB&&this.isTabIndent){
dojo.stopEvent(e);
if(this.queryCommandEnabled((e.shiftKey?"outdent":"indent"))){
this.execCommand((e.shiftKey?"outdent":"indent"));
}
}
if(dojo.isIE){
if(e.keyCode==dojo.keys.TAB&&!this.isTabIndent){
if(e.shiftKey&&!e.ctrlKey&&!e.altKey){
this.iframe.focus();
}else{
if(!e.shiftKey&&!e.ctrlKey&&!e.altKey){
this.tabStop.focus();
}
}
}else{
if(e.keyCode===dojo.keys.BACKSPACE&&this.document.selection.type==="Control"){
dojo.stopEvent(e);
this.execCommand("delete");
}else{
if((65<=e.keyCode&&e.keyCode<=90)||(e.keyCode>=37&&e.keyCode<=40)){
e.charCode=e.keyCode;
this.onKeyPress(e);
}
}
}
}
return true;
},onKeyUp:function(e){
return;
},setDisabled:function(_d01){
dojo.deprecated("dijit.Editor::setDisabled is deprecated","use dijit.Editor::attr(\"disabled\",boolean) instead",2);
this.set("disabled",_d01);
},_setValueAttr:function(_d02){
this.setValue(_d02);
},_setDisableSpellCheckAttr:function(_d03){
if(this.document){
dojo.attr(this.document.body,"spellcheck",!_d03);
}else{
this.onLoadDeferred.addCallback(dojo.hitch(this,function(){
dojo.attr(this.document.body,"spellcheck",!_d03);
}));
}
this._set("disableSpellCheck",_d03);
},onKeyPress:function(e){
var c=(e.keyChar&&e.keyChar.toLowerCase())||e.keyCode,_d04=this._keyHandlers[c],args=arguments;
if(_d04&&!e.altKey){
dojo.some(_d04,function(h){
if(!(h.shift^e.shiftKey)&&!(h.ctrl^(e.ctrlKey||e.metaKey))){
if(!h.handler.apply(this,args)){
e.preventDefault();
}
return true;
}
},this);
}
if(!this._onKeyHitch){
this._onKeyHitch=dojo.hitch(this,"onKeyPressed");
}
setTimeout(this._onKeyHitch,1);
return true;
},addKeyHandler:function(key,ctrl,_d05,_d06){
if(!dojo.isArray(this._keyHandlers[key])){
this._keyHandlers[key]=[];
}
this._keyHandlers[key].push({shift:_d05||false,ctrl:ctrl||false,handler:_d06});
},onKeyPressed:function(){
this.onDisplayChanged();
},onClick:function(e){
this.onDisplayChanged(e);
},_onIEMouseDown:function(e){
if(!this._focused&&!this.disabled){
this.focus();
}
},_onBlur:function(e){
this.inherited(arguments);
var _d07=this.getValue(true);
if(_d07!=this.value){
this.onChange(_d07);
}
this._set("value",_d07);
},_onFocus:function(e){
if(!this.disabled){
if(!this._disabledOK){
this.set("disabled",false);
}
this.inherited(arguments);
}
},blur:function(){
if(!dojo.isIE&&this.window.document.documentElement&&this.window.document.documentElement.focus){
this.window.document.documentElement.focus();
}else{
if(dojo.doc.body.focus){
dojo.doc.body.focus();
}
}
},focus:function(){
if(!this.isLoaded){
this.focusOnLoad=true;
return;
}
if(this._cursorToStart){
delete this._cursorToStart;
if(this.editNode.childNodes){
this.placeCursorAtStart();
return;
}
}
if(!dojo.isIE){
dijit.focus(this.iframe);
}else{
if(this.editNode&&this.editNode.focus){
this.iframe.fireEvent("onfocus",document.createEventObject());
}
}
},updateInterval:200,_updateTimer:null,onDisplayChanged:function(e){
if(this._updateTimer){
clearTimeout(this._updateTimer);
}
if(!this._updateHandler){
this._updateHandler=dojo.hitch(this,"onNormalizedDisplayChanged");
}
this._updateTimer=setTimeout(this._updateHandler,this.updateInterval);
},onNormalizedDisplayChanged:function(){
delete this._updateTimer;
},onChange:function(_d08){
},_normalizeCommand:function(cmd,_d09){
var _d0a=cmd.toLowerCase();
if(_d0a=="formatblock"){
if(dojo.isSafari&&_d09===undefined){
_d0a="heading";
}
}else{
if(_d0a=="hilitecolor"&&!dojo.isMoz){
_d0a="backcolor";
}
}
return _d0a;
},_qcaCache:{},queryCommandAvailable:function(_d0b){
var ca=this._qcaCache[_d0b];
if(ca!==undefined){
return ca;
}
return (this._qcaCache[_d0b]=this._queryCommandAvailable(_d0b));
},_queryCommandAvailable:function(_d0c){
var ie=1;
var _d0d=1<<1;
var _d0e=1<<2;
var _d0f=1<<3;
function _d10(_d11){
return {ie:Boolean(_d11&ie),mozilla:Boolean(_d11&_d0d),webkit:Boolean(_d11&_d0e),opera:Boolean(_d11&_d0f)};
};
var _d12=null;
switch(_d0c.toLowerCase()){
case "bold":
case "italic":
case "underline":
case "subscript":
case "superscript":
case "fontname":
case "fontsize":
case "forecolor":
case "hilitecolor":
case "justifycenter":
case "justifyfull":
case "justifyleft":
case "justifyright":
case "delete":
case "selectall":
case "toggledir":
_d12=_d10(_d0d|ie|_d0e|_d0f);
break;
case "createlink":
case "unlink":
case "removeformat":
case "inserthorizontalrule":
case "insertimage":
case "insertorderedlist":
case "insertunorderedlist":
case "indent":
case "outdent":
case "formatblock":
case "inserthtml":
case "undo":
case "redo":
case "strikethrough":
case "tabindent":
_d12=_d10(_d0d|ie|_d0f|_d0e);
break;
case "blockdirltr":
case "blockdirrtl":
case "dirltr":
case "dirrtl":
case "inlinedirltr":
case "inlinedirrtl":
_d12=_d10(ie);
break;
case "cut":
case "copy":
case "paste":
_d12=_d10(ie|_d0d|_d0e);
break;
case "inserttable":
_d12=_d10(_d0d|ie);
break;
case "insertcell":
case "insertcol":
case "insertrow":
case "deletecells":
case "deletecols":
case "deleterows":
case "mergecells":
case "splitcell":
_d12=_d10(ie|_d0d);
break;
default:
return false;
}
return (dojo.isIE&&_d12.ie)||(dojo.isMoz&&_d12.mozilla)||(dojo.isWebKit&&_d12.webkit)||(dojo.isOpera&&_d12.opera);
},execCommand:function(_d13,_d14){
var _d15;
this.focus();
_d13=this._normalizeCommand(_d13,_d14);
if(_d14!==undefined){
if(_d13=="heading"){
throw new Error("unimplemented");
}else{
if((_d13=="formatblock")&&dojo.isIE){
_d14="<"+_d14+">";
}
}
}
var _d16="_"+_d13+"Impl";
if(this[_d16]){
_d15=this[_d16](_d14);
}else{
_d14=arguments.length>1?_d14:null;
if(_d14||_d13!="createlink"){
_d15=this.document.execCommand(_d13,false,_d14);
}
}
this.onDisplayChanged();
return _d15;
},queryCommandEnabled:function(_d17){
if(this.disabled||!this._disabledOK){
return false;
}
_d17=this._normalizeCommand(_d17);
if(dojo.isMoz||dojo.isWebKit){
if(_d17=="unlink"){
return this._sCall("hasAncestorElement",["a"]);
}else{
if(_d17=="inserttable"){
return true;
}
}
}
if(dojo.isWebKit){
if(_d17=="cut"||_d17=="copy"){
var sel=this.window.getSelection();
if(sel){
sel=sel.toString();
}
return !!sel;
}else{
if(_d17=="paste"){
return true;
}
}
}
var elem=dojo.isIE?this.document.selection.createRange():this.document;
try{
return elem.queryCommandEnabled(_d17);
}
catch(e){
return false;
}
},queryCommandState:function(_d18){
if(this.disabled||!this._disabledOK){
return false;
}
_d18=this._normalizeCommand(_d18);
try{
return this.document.queryCommandState(_d18);
}
catch(e){
return false;
}
},queryCommandValue:function(_d19){
if(this.disabled||!this._disabledOK){
return false;
}
var r;
_d19=this._normalizeCommand(_d19);
if(dojo.isIE&&_d19=="formatblock"){
r=this._native2LocalFormatNames[this.document.queryCommandValue(_d19)];
}else{
if(dojo.isMoz&&_d19==="hilitecolor"){
var _d1a;
try{
_d1a=this.document.queryCommandValue("styleWithCSS");
}
catch(e){
_d1a=false;
}
this.document.execCommand("styleWithCSS",false,true);
r=this.document.queryCommandValue(_d19);
this.document.execCommand("styleWithCSS",false,_d1a);
}else{
r=this.document.queryCommandValue(_d19);
}
}
return r;
},_sCall:function(name,args){
return dojo.withGlobal(this.window,name,dijit._editor.selection,args);
},placeCursorAtStart:function(){
this.focus();
var _d1b=false;
if(dojo.isMoz){
var _d1c=this.editNode.firstChild;
while(_d1c){
if(_d1c.nodeType==3){
if(_d1c.nodeValue.replace(/^\s+|\s+$/g,"").length>0){
_d1b=true;
this._sCall("selectElement",[_d1c]);
break;
}
}else{
if(_d1c.nodeType==1){
_d1b=true;
var tg=_d1c.tagName?_d1c.tagName.toLowerCase():"";
if(/br|input|img|base|meta|area|basefont|hr|link/.test(tg)){
this._sCall("selectElement",[_d1c]);
}else{
this._sCall("selectElementChildren",[_d1c]);
}
break;
}
}
_d1c=_d1c.nextSibling;
}
}else{
_d1b=true;
this._sCall("selectElementChildren",[this.editNode]);
}
if(_d1b){
this._sCall("collapse",[true]);
}
},placeCursorAtEnd:function(){
this.focus();
var _d1d=false;
if(dojo.isMoz){
var last=this.editNode.lastChild;
while(last){
if(last.nodeType==3){
if(last.nodeValue.replace(/^\s+|\s+$/g,"").length>0){
_d1d=true;
this._sCall("selectElement",[last]);
break;
}
}else{
if(last.nodeType==1){
_d1d=true;
if(last.lastChild){
this._sCall("selectElement",[last.lastChild]);
}else{
this._sCall("selectElement",[last]);
}
break;
}
}
last=last.previousSibling;
}
}else{
_d1d=true;
this._sCall("selectElementChildren",[this.editNode]);
}
if(_d1d){
this._sCall("collapse",[false]);
}
},getValue:function(_d1e){
if(this.textarea){
if(this.isClosed||!this.isLoaded){
return this.textarea.value;
}
}
return this._postFilterContent(null,_d1e);
},_getValueAttr:function(){
return this.getValue(true);
},setValue:function(html){
if(!this.isLoaded){
this.onLoadDeferred.addCallback(dojo.hitch(this,function(){
this.setValue(html);
}));
return;
}
this._cursorToStart=true;
if(this.textarea&&(this.isClosed||!this.isLoaded)){
this.textarea.value=html;
}else{
html=this._preFilterContent(html);
var node=this.isClosed?this.domNode:this.editNode;
if(html&&dojo.isMoz&&html.toLowerCase()=="<p></p>"){
html="<p>&nbsp;</p>";
}
if(!html&&dojo.isWebKit){
html="&nbsp;";
}
node.innerHTML=html;
this._preDomFilterContent(node);
}
this.onDisplayChanged();
this._set("value",this.getValue(true));
},replaceValue:function(html){
if(this.isClosed){
this.setValue(html);
}else{
if(this.window&&this.window.getSelection&&!dojo.isMoz){
this.setValue(html);
}else{
if(this.window&&this.window.getSelection){
html=this._preFilterContent(html);
this.execCommand("selectall");
if(!html){
this._cursorToStart=true;
html="&nbsp;";
}
this.execCommand("inserthtml",html);
this._preDomFilterContent(this.editNode);
}else{
if(this.document&&this.document.selection){
this.setValue(html);
}
}
}
}
this._set("value",this.getValue(true));
},_preFilterContent:function(html){
var ec=html;
dojo.forEach(this.contentPreFilters,function(ef){
if(ef){
ec=ef(ec);
}
});
return ec;
},_preDomFilterContent:function(dom){
dom=dom||this.editNode;
dojo.forEach(this.contentDomPreFilters,function(ef){
if(ef&&dojo.isFunction(ef)){
ef(dom);
}
},this);
},_postFilterContent:function(dom,_d1f){
var ec;
if(!dojo.isString(dom)){
dom=dom||this.editNode;
if(this.contentDomPostFilters.length){
if(_d1f){
dom=dojo.clone(dom);
}
dojo.forEach(this.contentDomPostFilters,function(ef){
dom=ef(dom);
});
}
ec=dijit._editor.getChildrenHtml(dom);
}else{
ec=dom;
}
if(!dojo.trim(ec.replace(/^\xA0\xA0*/,"").replace(/\xA0\xA0*$/,"")).length){
ec="";
}
dojo.forEach(this.contentPostFilters,function(ef){
ec=ef(ec);
});
return ec;
},_saveContent:function(e){
var _d20=dojo.byId(dijit._scopeName+"._editor.RichText.value");
if(_d20.value){
_d20.value+=this._SEPARATOR;
}
_d20.value+=this.name+this._NAME_CONTENT_SEP+this.getValue(true);
},escapeXml:function(str,_d21){
str=str.replace(/&/gm,"&amp;").replace(/</gm,"&lt;").replace(/>/gm,"&gt;").replace(/"/gm,"&quot;");
if(!_d21){
str=str.replace(/'/gm,"&#39;");
}
return str;
},getNodeHtml:function(node){
dojo.deprecated("dijit.Editor::getNodeHtml is deprecated","use dijit._editor.getNodeHtml instead",2);
return dijit._editor.getNodeHtml(node);
},getNodeChildrenHtml:function(dom){
dojo.deprecated("dijit.Editor::getNodeChildrenHtml is deprecated","use dijit._editor.getChildrenHtml instead",2);
return dijit._editor.getChildrenHtml(dom);
},close:function(save){
if(this.isClosed){
return;
}
if(!arguments.length){
save=true;
}
if(save){
this._set("value",this.getValue(true));
}
if(this.interval){
clearInterval(this.interval);
}
if(this._webkitListener){
this.disconnect(this._webkitListener);
delete this._webkitListener;
}
if(dojo.isIE){
this.iframe.onfocus=null;
}
this.iframe._loadFunc=null;
if(this._iframeRegHandle){
dijit.unregisterIframe(this._iframeRegHandle);
delete this._iframeRegHandle;
}
if(this.textarea){
var s=this.textarea.style;
s.position="";
s.left=s.top="";
if(dojo.isIE){
s.overflow=this.__overflow;
this.__overflow=null;
}
this.textarea.value=this.value;
dojo.destroy(this.domNode);
this.domNode=this.textarea;
}else{
this.domNode.innerHTML=this.value;
}
delete this.iframe;
dojo.removeClass(this.domNode,this.baseClass);
this.isClosed=true;
this.isLoaded=false;
delete this.editNode;
delete this.focusNode;
if(this.window&&this.window._frameElement){
this.window._frameElement=null;
}
this.window=null;
this.document=null;
this.editingArea=null;
this.editorObject=null;
},destroy:function(){
if(!this.isClosed){
this.close(false);
}
this.inherited(arguments);
if(dijit._editor._globalSaveHandler){
delete dijit._editor._globalSaveHandler[this.id];
}
},_removeMozBogus:function(html){
return html.replace(/\stype="_moz"/gi,"").replace(/\s_moz_dirty=""/gi,"").replace(/_moz_resizing="(true|false)"/gi,"");
},_removeWebkitBogus:function(html){
html=html.replace(/\sclass="webkit-block-placeholder"/gi,"");
html=html.replace(/\sclass="apple-style-span"/gi,"");
html=html.replace(/<meta charset=\"utf-8\" \/>/gi,"");
return html;
},_normalizeFontStyle:function(html){
return html.replace(/<(\/)?strong([ \>])/gi,"<$1b$2").replace(/<(\/)?em([ \>])/gi,"<$1i$2");
},_preFixUrlAttributes:function(html){
return html.replace(/(?:(<a(?=\s).*?\shref=)("|')(.*?)\2)|(?:(<a\s.*?href=)([^"'][^ >]+))/gi,"$1$4$2$3$5$2 _djrealurl=$2$3$5$2").replace(/(?:(<img(?=\s).*?\ssrc=)("|')(.*?)\2)|(?:(<img\s.*?src=)([^"'][^ >]+))/gi,"$1$4$2$3$5$2 _djrealurl=$2$3$5$2");
},_inserthorizontalruleImpl:function(_d22){
if(dojo.isIE){
return this._inserthtmlImpl("<hr>");
}
return this.document.execCommand("inserthorizontalrule",false,_d22);
},_unlinkImpl:function(_d23){
if((this.queryCommandEnabled("unlink"))&&(dojo.isMoz||dojo.isWebKit)){
var a=this._sCall("getAncestorElement",["a"]);
this._sCall("selectElement",[a]);
return this.document.execCommand("unlink",false,null);
}
return this.document.execCommand("unlink",false,_d23);
},_hilitecolorImpl:function(_d24){
var _d25;
if(dojo.isMoz){
this.document.execCommand("styleWithCSS",false,true);
_d25=this.document.execCommand("hilitecolor",false,_d24);
this.document.execCommand("styleWithCSS",false,false);
}else{
_d25=this.document.execCommand("hilitecolor",false,_d24);
}
return _d25;
},_backcolorImpl:function(_d26){
if(dojo.isIE){
_d26=_d26?_d26:null;
}
return this.document.execCommand("backcolor",false,_d26);
},_forecolorImpl:function(_d27){
if(dojo.isIE){
_d27=_d27?_d27:null;
}
return this.document.execCommand("forecolor",false,_d27);
},_inserthtmlImpl:function(_d28){
_d28=this._preFilterContent(_d28);
var rv=true;
if(dojo.isIE){
var _d29=this.document.selection.createRange();
if(this.document.selection.type.toUpperCase()=="CONTROL"){
var n=_d29.item(0);
while(_d29.length){
_d29.remove(_d29.item(0));
}
n.outerHTML=_d28;
}else{
_d29.pasteHTML(_d28);
}
_d29.select();
}else{
if(dojo.isMoz&&!_d28.length){
this._sCall("remove");
}else{
rv=this.document.execCommand("inserthtml",false,_d28);
}
}
return rv;
},_boldImpl:function(_d2a){
if(dojo.isIE){
this._adaptIESelection();
}
return this.document.execCommand("bold",false,_d2a);
},_italicImpl:function(_d2b){
if(dojo.isIE){
this._adaptIESelection();
}
return this.document.execCommand("italic",false,_d2b);
},_underlineImpl:function(_d2c){
if(dojo.isIE){
this._adaptIESelection();
}
return this.document.execCommand("underline",false,_d2c);
},_strikethroughImpl:function(_d2d){
if(dojo.isIE){
this._adaptIESelection();
}
return this.document.execCommand("strikethrough",false,_d2d);
},getHeaderHeight:function(){
return this._getNodeChildrenHeight(this.header);
},getFooterHeight:function(){
return this._getNodeChildrenHeight(this.footer);
},_getNodeChildrenHeight:function(node){
var h=0;
if(node&&node.childNodes){
var i;
for(i=0;i<node.childNodes.length;i++){
var size=dojo.position(node.childNodes[i]);
h+=size.h;
}
}
return h;
},_isNodeEmpty:function(node,_d2e){
if(node.nodeType==1){
if(node.childNodes.length>0){
return this._isNodeEmpty(node.childNodes[0],_d2e);
}
return true;
}else{
if(node.nodeType==3){
return (node.nodeValue.substring(_d2e)=="");
}
}
return false;
},_removeStartingRangeFromRange:function(node,_d2f){
if(node.nextSibling){
_d2f.setStart(node.nextSibling,0);
}else{
var _d30=node.parentNode;
while(_d30&&_d30.nextSibling==null){
_d30=_d30.parentNode;
}
if(_d30){
_d2f.setStart(_d30.nextSibling,0);
}
}
return _d2f;
},_adaptIESelection:function(){
var _d31=dijit.range.getSelection(this.window);
if(_d31&&_d31.rangeCount&&!_d31.isCollapsed){
var _d32=_d31.getRangeAt(0);
var _d33=_d32.startContainer;
var _d34=_d32.startOffset;
while(_d33.nodeType==3&&_d34>=_d33.length&&_d33.nextSibling){
_d34=_d34-_d33.length;
_d33=_d33.nextSibling;
}
var _d35=null;
while(this._isNodeEmpty(_d33,_d34)&&_d33!=_d35){
_d35=_d33;
_d32=this._removeStartingRangeFromRange(_d33,_d32);
_d33=_d32.startContainer;
_d34=0;
}
_d31.removeAllRanges();
_d31.addRange(_d32);
}
}});
}
if(!dojo._hasResource["dijit._editor._Plugin"]){
dojo._hasResource["dijit._editor._Plugin"]=true;
dojo.provide("dijit._editor._Plugin");
dojo.declare("dijit._editor._Plugin",null,{constructor:function(args,node){
this.params=args||{};
dojo.mixin(this,this.params);
this._connects=[];
this._attrPairNames={};
},editor:null,iconClassPrefix:"dijitEditorIcon",button:null,command:"",useDefaultCommand:true,buttonClass:dijit.form.Button,disabled:false,getLabel:function(key){
return this.editor.commands[key];
},_initButton:function(){
if(this.command.length){
var _d36=this.getLabel(this.command),_d37=this.editor,_d38=this.iconClassPrefix+" "+this.iconClassPrefix+this.command.charAt(0).toUpperCase()+this.command.substr(1);
if(!this.button){
var _d39=dojo.mixin({label:_d36,dir:_d37.dir,lang:_d37.lang,showLabel:false,iconClass:_d38,dropDown:this.dropDown,tabIndex:"-1"},this.params||{});
this.button=new this.buttonClass(_d39);
}
}
if(this.get("disabled")&&this.button){
this.button.set("disabled",this.get("disabled"));
}
},destroy:function(){
dojo.forEach(this._connects,dojo.disconnect);
if(this.dropDown){
this.dropDown.destroyRecursive();
}
},connect:function(o,f,tf){
this._connects.push(dojo.connect(o,f,this,tf));
},updateState:function(){
var e=this.editor,c=this.command,_d3a,_d3b;
if(!e||!e.isLoaded||!c.length){
return;
}
var _d3c=this.get("disabled");
if(this.button){
try{
_d3b=!_d3c&&e.queryCommandEnabled(c);
if(this.enabled!==_d3b){
this.enabled=_d3b;
this.button.set("disabled",!_d3b);
}
if(typeof this.button.checked=="boolean"){
_d3a=e.queryCommandState(c);
if(this.checked!==_d3a){
this.checked=_d3a;
this.button.set("checked",e.queryCommandState(c));
}
}
}
catch(e){
}
}
},setEditor:function(_d3d){
this.editor=_d3d;
this._initButton();
if(this.button&&this.useDefaultCommand){
if(this.editor.queryCommandAvailable(this.command)){
this.connect(this.button,"onClick",dojo.hitch(this.editor,"execCommand",this.command,this.commandArg));
}else{
this.button.domNode.style.display="none";
}
}
this.connect(this.editor,"onNormalizedDisplayChanged","updateState");
},setToolbar:function(_d3e){
if(this.button){
_d3e.addChild(this.button);
}
},set:function(name,_d3f){
if(typeof name==="object"){
for(var x in name){
this.set(x,name[x]);
}
return this;
}
var _d40=this._getAttrNames(name);
if(this[_d40.s]){
var _d41=this[_d40.s].apply(this,Array.prototype.slice.call(arguments,1));
}else{
this._set(name,_d3f);
}
return _d41||this;
},get:function(name){
var _d42=this._getAttrNames(name);
return this[_d42.g]?this[_d42.g]():this[name];
},_setDisabledAttr:function(_d43){
this.disabled=_d43;
this.updateState();
},_getAttrNames:function(name){
var apn=this._attrPairNames;
if(apn[name]){
return apn[name];
}
var uc=name.charAt(0).toUpperCase()+name.substr(1);
return (apn[name]={s:"_set"+uc+"Attr",g:"_get"+uc+"Attr"});
},_set:function(name,_d44){
var _d45=this[name];
this[name]=_d44;
}});
}
if(!dojo._hasResource["dijit._editor.plugins.EnterKeyHandling"]){
dojo._hasResource["dijit._editor.plugins.EnterKeyHandling"]=true;
dojo.provide("dijit._editor.plugins.EnterKeyHandling");
dojo.declare("dijit._editor.plugins.EnterKeyHandling",dijit._editor._Plugin,{blockNodeForEnter:"BR",constructor:function(args){
if(args){
if("blockNodeForEnter" in args){
args.blockNodeForEnter=args.blockNodeForEnter.toUpperCase();
}
dojo.mixin(this,args);
}
},setEditor:function(_d46){
if(this.editor===_d46){
return;
}
this.editor=_d46;
if(this.blockNodeForEnter=="BR"){
this.editor.customUndo=true;
_d46.onLoadDeferred.addCallback(dojo.hitch(this,function(d){
this.connect(_d46.document,"onkeypress",function(e){
if(e.charOrCode==dojo.keys.ENTER){
var ne=dojo.mixin({},e);
ne.shiftKey=true;
if(!this.handleEnterKey(ne)){
dojo.stopEvent(e);
}
}
});
return d;
}));
}else{
if(this.blockNodeForEnter){
var h=dojo.hitch(this,this.handleEnterKey);
_d46.addKeyHandler(13,0,0,h);
_d46.addKeyHandler(13,0,1,h);
this.connect(this.editor,"onKeyPressed","onKeyPressed");
}
}
},onKeyPressed:function(e){
if(this._checkListLater){
if(dojo.withGlobal(this.editor.window,"isCollapsed",dijit)){
var _d47=dojo.withGlobal(this.editor.window,"getAncestorElement",dijit._editor.selection,["LI"]);
if(!_d47){
dijit._editor.RichText.prototype.execCommand.call(this.editor,"formatblock",this.blockNodeForEnter);
var _d48=dojo.withGlobal(this.editor.window,"getAncestorElement",dijit._editor.selection,[this.blockNodeForEnter]);
if(_d48){
_d48.innerHTML=this.bogusHtmlContent;
if(dojo.isIE){
var r=this.editor.document.selection.createRange();
r.move("character",-1);
r.select();
}
}else{
console.error("onKeyPressed: Cannot find the new block node");
}
}else{
if(dojo.isMoz){
if(_d47.parentNode.parentNode.nodeName=="LI"){
_d47=_d47.parentNode.parentNode;
}
}
var fc=_d47.firstChild;
if(fc&&fc.nodeType==1&&(fc.nodeName=="UL"||fc.nodeName=="OL")){
_d47.insertBefore(fc.ownerDocument.createTextNode(" "),fc);
var _d49=dijit.range.create(this.editor.window);
_d49.setStart(_d47.firstChild,0);
var _d4a=dijit.range.getSelection(this.editor.window,true);
_d4a.removeAllRanges();
_d4a.addRange(_d49);
}
}
}
this._checkListLater=false;
}
if(this._pressedEnterInBlock){
if(this._pressedEnterInBlock.previousSibling){
this.removeTrailingBr(this._pressedEnterInBlock.previousSibling);
}
delete this._pressedEnterInBlock;
}
},bogusHtmlContent:"&nbsp;",blockNodes:/^(?:P|H1|H2|H3|H4|H5|H6|LI)$/,handleEnterKey:function(e){
var _d4b,_d4c,_d4d,_d4e,_d4f,_d50,doc=this.editor.document,br,rs,txt;
if(e.shiftKey){
var _d51=dojo.withGlobal(this.editor.window,"getParentElement",dijit._editor.selection);
var _d52=dijit.range.getAncestor(_d51,this.blockNodes);
if(_d52){
if(_d52.tagName=="LI"){
return true;
}
_d4b=dijit.range.getSelection(this.editor.window);
_d4c=_d4b.getRangeAt(0);
if(!_d4c.collapsed){
_d4c.deleteContents();
_d4b=dijit.range.getSelection(this.editor.window);
_d4c=_d4b.getRangeAt(0);
}
if(dijit.range.atBeginningOfContainer(_d52,_d4c.startContainer,_d4c.startOffset)){
br=doc.createElement("br");
_d4d=dijit.range.create(this.editor.window);
_d52.insertBefore(br,_d52.firstChild);
_d4d.setStartBefore(br.nextSibling);
_d4b.removeAllRanges();
_d4b.addRange(_d4d);
}else{
if(dijit.range.atEndOfContainer(_d52,_d4c.startContainer,_d4c.startOffset)){
_d4d=dijit.range.create(this.editor.window);
br=doc.createElement("br");
_d52.appendChild(br);
_d52.appendChild(doc.createTextNode(" "));
_d4d.setStart(_d52.lastChild,0);
_d4b.removeAllRanges();
_d4b.addRange(_d4d);
}else{
rs=_d4c.startContainer;
if(rs&&rs.nodeType==3){
txt=rs.nodeValue;
dojo.withGlobal(this.editor.window,function(){
_d4e=doc.createTextNode(txt.substring(0,_d4c.startOffset));
_d4f=doc.createTextNode(txt.substring(_d4c.startOffset));
_d50=doc.createElement("br");
if(_d4f.nodeValue==""&&dojo.isWebKit){
_d4f=doc.createTextNode(" ");
}
dojo.place(_d4e,rs,"after");
dojo.place(_d50,_d4e,"after");
dojo.place(_d4f,_d50,"after");
dojo.destroy(rs);
_d4d=dijit.range.create(dojo.gobal);
_d4d.setStart(_d4f,0);
_d4b.removeAllRanges();
_d4b.addRange(_d4d);
});
return false;
}
return true;
}
}
}else{
_d4b=dijit.range.getSelection(this.editor.window);
if(_d4b.rangeCount){
_d4c=_d4b.getRangeAt(0);
if(_d4c&&_d4c.startContainer){
if(!_d4c.collapsed){
_d4c.deleteContents();
_d4b=dijit.range.getSelection(this.editor.window);
_d4c=_d4b.getRangeAt(0);
}
rs=_d4c.startContainer;
if(rs&&rs.nodeType==3){
dojo.withGlobal(this.editor.window,dojo.hitch(this,function(){
var _d53=false;
var _d54=_d4c.startOffset;
if(rs.length<_d54){
ret=this._adjustNodeAndOffset(rs,_d54);
rs=ret.node;
_d54=ret.offset;
}
txt=rs.nodeValue;
_d4e=doc.createTextNode(txt.substring(0,_d54));
_d4f=doc.createTextNode(txt.substring(_d54));
_d50=doc.createElement("br");
if(!_d4f.length){
_d4f=doc.createTextNode(" ");
_d53=true;
}
if(_d4e.length){
dojo.place(_d4e,rs,"after");
}else{
_d4e=rs;
}
dojo.place(_d50,_d4e,"after");
dojo.place(_d4f,_d50,"after");
dojo.destroy(rs);
_d4d=dijit.range.create(dojo.gobal);
_d4d.setStart(_d4f,0);
_d4d.setEnd(_d4f,_d4f.length);
_d4b.removeAllRanges();
_d4b.addRange(_d4d);
if(_d53&&!dojo.isWebKit){
dijit._editor.selection.remove();
}else{
dijit._editor.selection.collapse(true);
}
}));
}else{
var _d55;
if(_d4c.startOffset>=0){
_d55=rs.childNodes[_d4c.startOffset];
}
dojo.withGlobal(this.editor.window,dojo.hitch(this,function(){
var _d56=doc.createElement("br");
var _d57=doc.createTextNode(" ");
if(!_d55){
rs.appendChild(_d56);
rs.appendChild(_d57);
}else{
dojo.place(_d56,_d55,"before");
dojo.place(_d57,_d56,"after");
}
_d4d=dijit.range.create(dojo.global);
_d4d.setStart(_d57,0);
_d4d.setEnd(_d57,_d57.length);
_d4b.removeAllRanges();
_d4b.addRange(_d4d);
dijit._editor.selection.collapse(true);
}));
}
}
}else{
dijit._editor.RichText.prototype.execCommand.call(this.editor,"inserthtml","<br>");
}
}
return false;
}
var _d58=true;
_d4b=dijit.range.getSelection(this.editor.window);
_d4c=_d4b.getRangeAt(0);
if(!_d4c.collapsed){
_d4c.deleteContents();
_d4b=dijit.range.getSelection(this.editor.window);
_d4c=_d4b.getRangeAt(0);
}
var _d59=dijit.range.getBlockAncestor(_d4c.endContainer,null,this.editor.editNode);
var _d5a=_d59.blockNode;
if((this._checkListLater=(_d5a&&(_d5a.nodeName=="LI"||_d5a.parentNode.nodeName=="LI")))){
if(dojo.isMoz){
this._pressedEnterInBlock=_d5a;
}
if(/^(\s|&nbsp;|\xA0|<span\b[^>]*\bclass=['"]Apple-style-span['"][^>]*>(\s|&nbsp;|\xA0)<\/span>)?(<br>)?$/.test(_d5a.innerHTML)){
_d5a.innerHTML="";
if(dojo.isWebKit){
_d4d=dijit.range.create(this.editor.window);
_d4d.setStart(_d5a,0);
_d4b.removeAllRanges();
_d4b.addRange(_d4d);
}
this._checkListLater=false;
}
return true;
}
if(!_d59.blockNode||_d59.blockNode===this.editor.editNode){
try{
dijit._editor.RichText.prototype.execCommand.call(this.editor,"formatblock",this.blockNodeForEnter);
}
catch(e2){
}
_d59={blockNode:dojo.withGlobal(this.editor.window,"getAncestorElement",dijit._editor.selection,[this.blockNodeForEnter]),blockContainer:this.editor.editNode};
if(_d59.blockNode){
if(_d59.blockNode!=this.editor.editNode&&(!(_d59.blockNode.textContent||_d59.blockNode.innerHTML).replace(/^\s+|\s+$/g,"").length)){
this.removeTrailingBr(_d59.blockNode);
return false;
}
}else{
_d59.blockNode=this.editor.editNode;
}
_d4b=dijit.range.getSelection(this.editor.window);
_d4c=_d4b.getRangeAt(0);
}
var _d5b=doc.createElement(this.blockNodeForEnter);
_d5b.innerHTML=this.bogusHtmlContent;
this.removeTrailingBr(_d59.blockNode);
var _d5c=_d4c.endOffset;
var node=_d4c.endContainer;
if(node.length<_d5c){
var ret=this._adjustNodeAndOffset(node,_d5c);
node=ret.node;
_d5c=ret.offset;
}
if(dijit.range.atEndOfContainer(_d59.blockNode,node,_d5c)){
if(_d59.blockNode===_d59.blockContainer){
_d59.blockNode.appendChild(_d5b);
}else{
dojo.place(_d5b,_d59.blockNode,"after");
}
_d58=false;
_d4d=dijit.range.create(this.editor.window);
_d4d.setStart(_d5b,0);
_d4b.removeAllRanges();
_d4b.addRange(_d4d);
if(this.editor.height){
dojo.window.scrollIntoView(_d5b);
}
}else{
if(dijit.range.atBeginningOfContainer(_d59.blockNode,_d4c.startContainer,_d4c.startOffset)){
dojo.place(_d5b,_d59.blockNode,_d59.blockNode===_d59.blockContainer?"first":"before");
if(_d5b.nextSibling&&this.editor.height){
_d4d=dijit.range.create(this.editor.window);
_d4d.setStart(_d5b.nextSibling,0);
_d4b.removeAllRanges();
_d4b.addRange(_d4d);
dojo.window.scrollIntoView(_d5b.nextSibling);
}
_d58=false;
}else{
if(_d59.blockNode===_d59.blockContainer){
_d59.blockNode.appendChild(_d5b);
}else{
dojo.place(_d5b,_d59.blockNode,"after");
}
_d58=false;
if(_d59.blockNode.style){
if(_d5b.style){
if(_d59.blockNode.style.cssText){
_d5b.style.cssText=_d59.blockNode.style.cssText;
}
}
}
rs=_d4c.startContainer;
var _d5d;
if(rs&&rs.nodeType==3){
var _d5e,_d5f;
_d5c=_d4c.endOffset;
if(rs.length<_d5c){
ret=this._adjustNodeAndOffset(rs,_d5c);
rs=ret.node;
_d5c=ret.offset;
}
txt=rs.nodeValue;
_d4e=doc.createTextNode(txt.substring(0,_d5c));
_d4f=doc.createTextNode(txt.substring(_d5c,txt.length));
dojo.place(_d4e,rs,"before");
dojo.place(_d4f,rs,"after");
dojo.destroy(rs);
var _d60=_d4e.parentNode;
while(_d60!==_d59.blockNode){
var tg=_d60.tagName;
var _d61=doc.createElement(tg);
if(_d60.style){
if(_d61.style){
if(_d60.style.cssText){
_d61.style.cssText=_d60.style.cssText;
}
}
}
if(_d60.tagName==="FONT"){
if(_d60.color){
_d61.color=_d60.color;
}
if(_d60.face){
_d61.face=_d60.face;
}
if(_d60.size){
_d61.size=_d60.size;
}
}
_d5e=_d4f;
while(_d5e){
_d5f=_d5e.nextSibling;
_d61.appendChild(_d5e);
_d5e=_d5f;
}
dojo.place(_d61,_d60,"after");
_d4e=_d60;
_d4f=_d61;
_d60=_d60.parentNode;
}
_d5e=_d4f;
if(_d5e.nodeType==1||(_d5e.nodeType==3&&_d5e.nodeValue)){
_d5b.innerHTML="";
}
_d5d=_d5e;
while(_d5e){
_d5f=_d5e.nextSibling;
_d5b.appendChild(_d5e);
_d5e=_d5f;
}
}
_d4d=dijit.range.create(this.editor.window);
var _d62;
var _d63=_d5d;
if(this.blockNodeForEnter!=="BR"){
while(_d63){
_d62=_d63;
_d5f=_d63.firstChild;
_d63=_d5f;
}
if(_d62&&_d62.parentNode){
_d5b=_d62.parentNode;
_d4d.setStart(_d5b,0);
_d4b.removeAllRanges();
_d4b.addRange(_d4d);
if(this.editor.height){
dijit.scrollIntoView(_d5b);
}
if(dojo.isMoz){
this._pressedEnterInBlock=_d59.blockNode;
}
}else{
_d58=true;
}
}else{
_d4d.setStart(_d5b,0);
_d4b.removeAllRanges();
_d4b.addRange(_d4d);
if(this.editor.height){
dijit.scrollIntoView(_d5b);
}
if(dojo.isMoz){
this._pressedEnterInBlock=_d59.blockNode;
}
}
}
}
return _d58;
},_adjustNodeAndOffset:function(node,_d64){
while(node.length<_d64&&node.nextSibling&&node.nextSibling.nodeType==3){
_d64=_d64-node.length;
node=node.nextSibling;
}
var ret={"node":node,"offset":_d64};
return ret;
},removeTrailingBr:function(_d65){
var para=/P|DIV|LI/i.test(_d65.tagName)?_d65:dijit._editor.selection.getParentOfType(_d65,["P","DIV","LI"]);
if(!para){
return;
}
if(para.lastChild){
if((para.childNodes.length>1&&para.lastChild.nodeType==3&&/^[\s\xAD]*$/.test(para.lastChild.nodeValue))||para.lastChild.tagName=="BR"){
dojo.destroy(para.lastChild);
}
}
if(!para.childNodes.length){
para.innerHTML=this.bogusHtmlContent;
}
}});
}
if(!dojo._hasResource["dijit.Editor"]){
dojo._hasResource["dijit.Editor"]=true;
dojo.provide("dijit.Editor");
dojo.declare("dijit.Editor",dijit._editor.RichText,{plugins:null,extraPlugins:null,constructor:function(){
if(!dojo.isArray(this.plugins)){
this.plugins=["undo","redo","|","cut","copy","paste","|","bold","italic","underline","strikethrough","|","insertOrderedList","insertUnorderedList","indent","outdent","|","justifyLeft","justifyRight","justifyCenter","justifyFull","dijit._editor.plugins.EnterKeyHandling"];
}
this._plugins=[];
this._editInterval=this.editActionInterval*1000;
if(dojo.isIE){
this.events.push("onBeforeDeactivate");
this.events.push("onBeforeActivate");
}
},postMixInProperties:function(){
this.setValueDeferred=new dojo.Deferred();
this.inherited(arguments);
},postCreate:function(){
this._steps=this._steps.slice(0);
this._undoedSteps=this._undoedSteps.slice(0);
if(dojo.isArray(this.extraPlugins)){
this.plugins=this.plugins.concat(this.extraPlugins);
}
this.inherited(arguments);
this.commands=dojo.i18n.getLocalization("dijit._editor","commands",this.lang);
if(!this.toolbar){
this.toolbar=new dijit.Toolbar({dir:this.dir,lang:this.lang});
this.header.appendChild(this.toolbar.domNode);
}
dojo.forEach(this.plugins,this.addPlugin,this);
this.setValueDeferred.callback(true);
dojo.addClass(this.iframe.parentNode,"dijitEditorIFrameContainer");
dojo.addClass(this.iframe,"dijitEditorIFrame");
dojo.attr(this.iframe,"allowTransparency",true);
if(dojo.isWebKit){
dojo.style(this.domNode,"KhtmlUserSelect","none");
}
this.toolbar.startup();
this.onNormalizedDisplayChanged();
},destroy:function(){
dojo.forEach(this._plugins,function(p){
if(p&&p.destroy){
p.destroy();
}
});
this._plugins=[];
this.toolbar.destroyRecursive();
delete this.toolbar;
this.inherited(arguments);
},addPlugin:function(_d66,_d67){
var args=dojo.isString(_d66)?{name:_d66}:_d66;
if(!args.setEditor){
var o={"args":args,"plugin":null,"editor":this};
dojo.publish(dijit._scopeName+".Editor.getPlugin",[o]);
if(!o.plugin){
var pc=dojo.getObject(args.name);
if(pc){
o.plugin=new pc(args);
}
}
if(!o.plugin){
console.warn("Cannot find plugin",_d66);
return;
}
_d66=o.plugin;
}
if(arguments.length>1){
this._plugins[_d67]=_d66;
}else{
this._plugins.push(_d66);
}
_d66.setEditor(this);
if(dojo.isFunction(_d66.setToolbar)){
_d66.setToolbar(this.toolbar);
}
},startup:function(){
},resize:function(size){
if(size){
dijit.layout._LayoutWidget.prototype.resize.apply(this,arguments);
}
},layout:function(){
var _d68=(this._contentBox.h-(this.getHeaderHeight()+this.getFooterHeight()+dojo._getPadBorderExtents(this.iframe.parentNode).h+dojo._getMarginExtents(this.iframe.parentNode).h));
this.editingArea.style.height=_d68+"px";
if(this.iframe){
this.iframe.style.height="100%";
}
this._layoutMode=true;
},_onIEMouseDown:function(e){
var _d69;
var b=this.document.body;
var _d6a=b.clientWidth;
var _d6b=b.clientHeight;
var _d6c=b.clientLeft;
var _d6d=b.offsetWidth;
var _d6e=b.offsetHeight;
var _d6f=b.offsetLeft;
bodyDir=b.dir?b.dir.toLowerCase():"";
if(bodyDir!="rtl"){
if(_d6a<_d6d&&e.x>_d6a&&e.x<_d6d){
_d69=true;
}
}else{
if(e.x<_d6c&&e.x>_d6f){
_d69=true;
}
}
if(!_d69){
if(_d6b<_d6e&&e.y>_d6b&&e.y<_d6e){
_d69=true;
}
}
if(!_d69){
delete this._cursorToStart;
delete this._savedSelection;
if(e.target.tagName=="BODY"){
setTimeout(dojo.hitch(this,"placeCursorAtEnd"),0);
}
this.inherited(arguments);
}
},onBeforeActivate:function(e){
this._restoreSelection();
},onBeforeDeactivate:function(e){
if(this.customUndo){
this.endEditing(true);
}
if(e.target.tagName!="BODY"){
this._saveSelection();
}
},customUndo:true,editActionInterval:3,beginEditing:function(cmd){
if(!this._inEditing){
this._inEditing=true;
this._beginEditing(cmd);
}
if(this.editActionInterval>0){
if(this._editTimer){
clearTimeout(this._editTimer);
}
this._editTimer=setTimeout(dojo.hitch(this,this.endEditing),this._editInterval);
}
},_steps:[],_undoedSteps:[],execCommand:function(cmd){
if(this.customUndo&&(cmd=="undo"||cmd=="redo")){
return this[cmd]();
}else{
if(this.customUndo){
this.endEditing();
this._beginEditing();
}
var r;
var _d70=/copy|cut|paste/.test(cmd);
try{
r=this.inherited(arguments);
if(dojo.isWebKit&&_d70&&!r){
throw {code:1011};
}
}
catch(e){
if(e.code==1011&&_d70){
var sub=dojo.string.substitute,_d71={cut:"X",copy:"C",paste:"V"};
alert(sub(this.commands.systemShortcut,[this.commands[cmd],sub(this.commands[dojo.isMac?"appleKey":"ctrlKey"],[_d71[cmd]])]));
}
r=false;
}
if(this.customUndo){
this._endEditing();
}
return r;
}
},queryCommandEnabled:function(cmd){
if(this.customUndo&&(cmd=="undo"||cmd=="redo")){
return cmd=="undo"?(this._steps.length>1):(this._undoedSteps.length>0);
}else{
return this.inherited(arguments);
}
},_moveToBookmark:function(b){
var _d72=b.mark;
var mark=b.mark;
var col=b.isCollapsed;
var r,_d73,_d74,sel;
if(mark){
if(dojo.isIE<9){
if(dojo.isArray(mark)){
_d72=[];
dojo.forEach(mark,function(n){
_d72.push(dijit.range.getNode(n,this.editNode));
},this);
dojo.withGlobal(this.window,"moveToBookmark",dijit,[{mark:_d72,isCollapsed:col}]);
}else{
if(mark.startContainer&&mark.endContainer){
sel=dijit.range.getSelection(this.window);
if(sel&&sel.removeAllRanges){
sel.removeAllRanges();
r=dijit.range.create(this.window);
_d73=dijit.range.getNode(mark.startContainer,this.editNode);
_d74=dijit.range.getNode(mark.endContainer,this.editNode);
if(_d73&&_d74){
r.setStart(_d73,mark.startOffset);
r.setEnd(_d74,mark.endOffset);
sel.addRange(r);
}
}
}
}
}else{
sel=dijit.range.getSelection(this.window);
if(sel&&sel.removeAllRanges){
sel.removeAllRanges();
r=dijit.range.create(this.window);
_d73=dijit.range.getNode(mark.startContainer,this.editNode);
_d74=dijit.range.getNode(mark.endContainer,this.editNode);
if(_d73&&_d74){
r.setStart(_d73,mark.startOffset);
r.setEnd(_d74,mark.endOffset);
sel.addRange(r);
}
}
}
}
},_changeToStep:function(from,to){
this.setValue(to.text);
var b=to.bookmark;
if(!b){
return;
}
this._moveToBookmark(b);
},undo:function(){
var ret=false;
if(!this._undoRedoActive){
this._undoRedoActive=true;
this.endEditing(true);
var s=this._steps.pop();
if(s&&this._steps.length>0){
this.focus();
this._changeToStep(s,this._steps[this._steps.length-1]);
this._undoedSteps.push(s);
this.onDisplayChanged();
delete this._undoRedoActive;
ret=true;
}
delete this._undoRedoActive;
}
return ret;
},redo:function(){
var ret=false;
if(!this._undoRedoActive){
this._undoRedoActive=true;
this.endEditing(true);
var s=this._undoedSteps.pop();
if(s&&this._steps.length>0){
this.focus();
this._changeToStep(this._steps[this._steps.length-1],s);
this._steps.push(s);
this.onDisplayChanged();
ret=true;
}
delete this._undoRedoActive;
}
return ret;
},endEditing:function(_d75){
if(this._editTimer){
clearTimeout(this._editTimer);
}
if(this._inEditing){
this._endEditing(_d75);
this._inEditing=false;
}
},_getBookmark:function(){
var b=dojo.withGlobal(this.window,dijit.getBookmark);
var tmp=[];
if(b&&b.mark){
var mark=b.mark;
if(dojo.isIE<9){
var sel=dijit.range.getSelection(this.window);
if(!dojo.isArray(mark)){
if(sel){
var _d76;
if(sel.rangeCount){
_d76=sel.getRangeAt(0);
}
if(_d76){
b.mark=_d76.cloneRange();
}else{
b.mark=dojo.withGlobal(this.window,dijit.getBookmark);
}
}
}else{
dojo.forEach(b.mark,function(n){
tmp.push(dijit.range.getIndex(n,this.editNode).o);
},this);
b.mark=tmp;
}
}
try{
if(b.mark&&b.mark.startContainer){
tmp=dijit.range.getIndex(b.mark.startContainer,this.editNode).o;
b.mark={startContainer:tmp,startOffset:b.mark.startOffset,endContainer:b.mark.endContainer===b.mark.startContainer?tmp:dijit.range.getIndex(b.mark.endContainer,this.editNode).o,endOffset:b.mark.endOffset};
}
}
catch(e){
b.mark=null;
}
}
return b;
},_beginEditing:function(cmd){
if(this._steps.length===0){
this._steps.push({"text":dijit._editor.getChildrenHtml(this.editNode),"bookmark":this._getBookmark()});
}
},_endEditing:function(_d77){
var v=dijit._editor.getChildrenHtml(this.editNode);
this._undoedSteps=[];
this._steps.push({text:v,bookmark:this._getBookmark()});
},onKeyDown:function(e){
if(!dojo.isIE&&!this.iframe&&e.keyCode==dojo.keys.TAB&&!this.tabIndent){
this._saveSelection();
}
if(!this.customUndo){
this.inherited(arguments);
return;
}
var k=e.keyCode,ks=dojo.keys;
if(e.ctrlKey&&!e.altKey){
if(k==90||k==122){
dojo.stopEvent(e);
this.undo();
return;
}else{
if(k==89||k==121){
dojo.stopEvent(e);
this.redo();
return;
}
}
}
this.inherited(arguments);
switch(k){
case ks.ENTER:
case ks.BACKSPACE:
case ks.DELETE:
this.beginEditing();
break;
case 88:
case 86:
if(e.ctrlKey&&!e.altKey&&!e.metaKey){
this.endEditing();
if(e.keyCode==88){
this.beginEditing("cut");
setTimeout(dojo.hitch(this,this.endEditing),1);
}else{
this.beginEditing("paste");
setTimeout(dojo.hitch(this,this.endEditing),1);
}
break;
}
default:
if(!e.ctrlKey&&!e.altKey&&!e.metaKey&&(e.keyCode<dojo.keys.F1||e.keyCode>dojo.keys.F15)){
this.beginEditing();
break;
}
case ks.ALT:
this.endEditing();
break;
case ks.UP_ARROW:
case ks.DOWN_ARROW:
case ks.LEFT_ARROW:
case ks.RIGHT_ARROW:
case ks.HOME:
case ks.END:
case ks.PAGE_UP:
case ks.PAGE_DOWN:
this.endEditing(true);
break;
case ks.CTRL:
case ks.SHIFT:
case ks.TAB:
break;
}
},_onBlur:function(){
this.inherited(arguments);
this.endEditing(true);
},_saveSelection:function(){
try{
this._savedSelection=this._getBookmark();
}
catch(e){
}
},_restoreSelection:function(){
if(this._savedSelection){
delete this._cursorToStart;
if(dojo.withGlobal(this.window,"isCollapsed",dijit)){
this._moveToBookmark(this._savedSelection);
}
delete this._savedSelection;
}
},onClick:function(){
this.endEditing(true);
this.inherited(arguments);
},replaceValue:function(html){
if(!this.customUndo){
this.inherited(arguments);
}else{
if(this.isClosed){
this.setValue(html);
}else{
this.beginEditing();
if(!html){
html="&nbsp;";
}
this.setValue(html);
this.endEditing();
}
}
},_setDisabledAttr:function(_d78){
var _d79=dojo.hitch(this,function(){
if((!this.disabled&&_d78)||(!this._buttonEnabledPlugins&&_d78)){
dojo.forEach(this._plugins,function(p){
p.set("disabled",true);
});
}else{
if(this.disabled&&!_d78){
dojo.forEach(this._plugins,function(p){
p.set("disabled",false);
});
}
}
});
this.setValueDeferred.addCallback(_d79);
this.inherited(arguments);
},_setStateClass:function(){
try{
this.inherited(arguments);
if(this.document&&this.document.body){
dojo.style(this.document.body,"color",dojo.style(this.iframe,"color"));
}
}
catch(e){
}
}});
dojo.subscribe(dijit._scopeName+".Editor.getPlugin",null,function(o){
if(o.plugin){
return;
}
var args=o.args,p;
var _d7a=dijit._editor._Plugin;
var name=args.name;
switch(name){
case "undo":
case "redo":
case "cut":
case "copy":
case "paste":
case "insertOrderedList":
case "insertUnorderedList":
case "indent":
case "outdent":
case "justifyCenter":
case "justifyFull":
case "justifyLeft":
case "justifyRight":
case "delete":
case "selectAll":
case "removeFormat":
case "unlink":
case "insertHorizontalRule":
p=new _d7a({command:name});
break;
case "bold":
case "italic":
case "underline":
case "strikethrough":
case "subscript":
case "superscript":
p=new _d7a({buttonClass:dijit.form.ToggleButton,command:name});
break;
case "|":
p=new _d7a({button:new dijit.ToolbarSeparator(),setEditor:function(_d7b){
this.editor=_d7b;
}});
}
o.plugin=p;
});
}
if(!dojo._hasResource["dojox.grid.cells.dijit"]){
dojo._hasResource["dojox.grid.cells.dijit"]=true;
dojo.provide("dojox.grid.cells.dijit");
(function(){
var dgc=dojox.grid.cells;
dojo.declare("dojox.grid.cells._Widget",dgc._Base,{widgetClass:dijit.form.TextBox,constructor:function(_d7c){
this.widget=null;
if(typeof this.widgetClass=="string"){
dojo.deprecated("Passing a string to widgetClass is deprecated","pass the widget class object instead","2.0");
this.widgetClass=dojo.getObject(this.widgetClass);
}
},formatEditing:function(_d7d,_d7e){
this.needFormatNode(_d7d,_d7e);
return "<div></div>";
},getValue:function(_d7f){
return this.widget.get("value");
},_unescapeHTML:function(_d80){
return (_d80&&_d80.replace&&this.grid.escapeHTMLInData)?_d80.replace(/&lt;/g,"<").replace(/&amp;/g,"&"):_d80;
},setValue:function(_d81,_d82){
if(this.widget&&this.widget.set){
_d82=this._unescapeHTML(_d82);
if(this.widget.onLoadDeferred){
var self=this;
this.widget.onLoadDeferred.addCallback(function(){
self.widget.set("value",_d82===null?"":_d82);
});
}else{
this.widget.set("value",_d82);
}
}else{
this.inherited(arguments);
}
},getWidgetProps:function(_d83){
return dojo.mixin({dir:this.dir,lang:this.lang},this.widgetProps||{},{constraints:dojo.mixin({},this.constraint)||{},value:this._unescapeHTML(_d83)});
},createWidget:function(_d84,_d85,_d86){
return new this.widgetClass(this.getWidgetProps(_d85),_d84);
},attachWidget:function(_d87,_d88,_d89){
_d87.appendChild(this.widget.domNode);
this.setValue(_d89,_d88);
},formatNode:function(_d8a,_d8b,_d8c){
if(!this.widgetClass){
return _d8b;
}
if(!this.widget){
this.widget=this.createWidget.apply(this,arguments);
}else{
this.attachWidget.apply(this,arguments);
}
this.sizeWidget.apply(this,arguments);
this.grid.views.renormalizeRow(_d8c);
this.grid.scroller.rowHeightChanged(_d8c,true);
this.focus();
return undefined;
},sizeWidget:function(_d8d,_d8e,_d8f){
var c=this.widget.declaredClass;
if(c!="dijit.form.CheckBox"&&c!="dijit.form.RadioButton"){
dojo.marginBox(this.widget.domNode,{w:dojo.contentBox(this.getNode(_d8f)).w});
}
},focus:function(_d90,_d91){
if(this.widget){
setTimeout(dojo.hitch(this.widget,function(){
dojox.grid.util.fire(this,"focus");
}),0);
}
},_finish:function(_d92){
this.inherited(arguments);
dojox.grid.util.removeNode(this.widget.domNode);
if(dojo.isIE){
dojo.setSelectable(this.widget.domNode,true);
}
}});
dgc._Widget.markupFactory=function(node,cell){
dgc._Base.markupFactory(node,cell);
var d=dojo;
var _d93=d.trim(d.attr(node,"widgetProps")||"");
var _d94=d.trim(d.attr(node,"constraint")||"");
var _d95=d.trim(d.attr(node,"widgetClass")||"");
if(_d93){
cell.widgetProps=d.fromJson(_d93);
}
if(_d94){
cell.constraint=d.fromJson(_d94);
}
if(_d95){
cell.widgetClass=d.getObject(_d95);
}
};
dojo.declare("dojox.grid.cells.ComboBox",dgc._Widget,{widgetClass:dijit.form.ComboBox,getWidgetProps:function(_d96){
var _d97=[];
dojo.forEach(this.options,function(o){
_d97.push({name:o,value:o});
});
var _d98=new dojo.data.ItemFileReadStore({data:{identifier:"name",items:_d97}});
return dojo.mixin({},this.widgetProps||{},{value:_d96,store:_d98});
},getValue:function(){
var e=this.widget;
e.set("displayedValue",e.get("displayedValue"));
return e.get("value");
}});
dgc.ComboBox.markupFactory=function(node,cell){
dgc._Widget.markupFactory(node,cell);
var d=dojo;
var _d99=d.trim(d.attr(node,"options")||"");
if(_d99){
var o=_d99.split(",");
if(o[0]!=_d99){
cell.options=o;
}
}
};
dojo.declare("dojox.grid.cells.DateTextBox",dgc._Widget,{widgetClass:dijit.form.DateTextBox,setValue:function(_d9a,_d9b){
if(this.widget){
this.widget.set("value",new Date(_d9b));
}else{
this.inherited(arguments);
}
},getWidgetProps:function(_d9c){
return dojo.mixin(this.inherited(arguments),{value:new Date(_d9c)});
}});
dgc.DateTextBox.markupFactory=function(node,cell){
dgc._Widget.markupFactory(node,cell);
};
dojo.declare("dojox.grid.cells.CheckBox",dgc._Widget,{widgetClass:dijit.form.CheckBox,getValue:function(){
return this.widget.checked;
},setValue:function(_d9d,_d9e){
if(this.widget&&this.widget.attributeMap.checked){
this.widget.set("checked",_d9e);
}else{
this.inherited(arguments);
}
},sizeWidget:function(_d9f,_da0,_da1){
return;
}});
dgc.CheckBox.markupFactory=function(node,cell){
dgc._Widget.markupFactory(node,cell);
};
dojo.declare("dojox.grid.cells.Editor",dgc._Widget,{widgetClass:dijit.Editor,getWidgetProps:function(_da2){
return dojo.mixin({},this.widgetProps||{},{height:this.widgetHeight||"100px"});
},createWidget:function(_da3,_da4,_da5){
var _da6=new this.widgetClass(this.getWidgetProps(_da4),_da3);
dojo.connect(_da6,"onLoad",dojo.hitch(this,"populateEditor"));
return _da6;
},formatNode:function(_da7,_da8,_da9){
this.content=_da8;
this.inherited(arguments);
if(dojo.isMoz){
var e=this.widget;
e.open();
if(this.widgetToolbar){
dojo.place(e.toolbar.domNode,e.editingArea,"before");
}
}
},populateEditor:function(){
this.widget.set("value",this.content);
this.widget.placeCursorAtEnd();
}});
dgc.Editor.markupFactory=function(node,cell){
dgc._Widget.markupFactory(node,cell);
var d=dojo;
var h=dojo.trim(dojo.attr(node,"widgetHeight")||"");
if(h){
if((h!="auto")&&(h.substr(-2)!="em")){
h=parseInt(h,10)+"px";
}
cell.widgetHeight=h;
}
};
})();
}
if(!dojo._hasResource["dojoe.treetable._IndirectSelection"]){
dojo._hasResource["dojoe.treetable._IndirectSelection"]=true;
dojo.provide("dojoe.treetable._IndirectSelection");
dojo.declare("dojoe.treetable._IndirectSelection",null,{grid:null,_selectionCache:[],_updateSelectionByCacheRunning:false,_connectArr:null,constructor:function(grid){
this.grid=grid;
this._connectArr=new Array();
this._addIndirectSelector();
this._connectSelectionHandlers();
},_addIndirectSelector:function(){
this.grid.expandoCell=1;
selector=[{name:" ",width:"22px",styles:"text-align: center;",formatter:this._createCheckbox}];
this.grid.structure=dojo._toArray(this.grid.structure,0,selector);
this.grid.setStructure(this.grid.structure);
this.grid._refresh(true);
},_createCheckbox:function(val,_daa,_dab,cell){
var id=this.grid.store.getIdentity(this.grid.getItem(_daa));
var _dac="treeimgid"+id;
return "<div align=\"right\" id="+_dac+" class=\"treeTableCheckBox\">";
},_updateCacheSelect:function(ridx,item,_dad){
var id=this.grid.store.getIdentity(item);
var _dae=this.grid.cache.getExpandoStatusByRowIndex(ridx);
var _daf=this._getItemIndexById(id);
if(_daf!==-1&&this._selectionCache[_daf]){
this._updateCache(_daf,{selStatus:_dad,item:item,rowIdx:_daf,id:id,expandoStatus:_dae});
}else{
this._cacheItem({selStatus:_dad,item:item,rowIdx:ridx,id:id,expandoStatus:_dae});
}
},_cacheItem:function(_db0){
var idx=this._getItemIndexById(_db0.id);
if(idx==-1){
this._selectionCache.push(dojo.mixin({id:null,selStatus:false,rowIdx:-1,expandoStatus:false},_db0));
}else{
this._updateCache(idx,_db0);
}
},_updateCache:function(idx,_db1){
if(this._selectionCache[idx]){
dojo.mixin(this._selectionCache[idx],_db1);
}
},_getItemIndexById:function(id){
for(var i=0;i<this._selectionCache.length;i++){
if(this._selectionCache[i]){
if(this._selectionCache[i].id==id){
return i;
}
}
}
return -1;
},_getItemById:function(_db2){
for(var i=0,len=this._selectionCache.length;i<len;i++){
if(this._selectionCache[i]&&this._selectionCache[i].id&&(this._selectionCache[i].id===_db2)){
return this._selectionCache[i];
}
}
return null;
},isItemSelectedInCacheByIdx:function(_db3){
var id,sel,item=this.grid.getItem(_db3);
if(item){
id=this.grid.store.getIdentity(item);
var _db4=this._getItemById(id);
if(_db4){
sel=_db4.selStatus;
}
}
return sel;
},getSelectedStatusById:function(id){
var i=this._getItemIndexById(id);
if(i!=-1){
return this._getSelectedStatusByIndex(i);
}
},_getSelectedStatusByIndex:function(idx){
return this._selectionCache[idx]?this._selectionCache[idx].selStatus:null;
},_connectSelectionHandlers:function(){
this.grid.selection.clickSelect=function(){
};
this._connectArr.push(dojo.connect(this.grid,"expandoFetch",dojo.hitch(this,"_updateCacheOnExpando")));
this._connectArr.push(dojo.connect(this.grid,"onCellClick",dojo.hitch(this,"onSelectionChanged")));
this._connectArr.push(dojo.connect(this.grid,"onKeyDown",dojo.hitch(this,"onSelectionChanged")));
this._connectArr.push(dojo.connect(this.grid,"onSelectionChanged",dojo.hitch(this,"onSelectionChanged")));
this._connectArr.push(dojo.connect(this.grid,"onHeaderClick",this,"_updateSelectionOnRefresh"));
this._connectArr.push(dojo.connect(this.grid,"onResizeColumn",this,"_updateSelectionOnRefresh"));
this._connectArr.push(dojo.connect(this.grid,"_refresh",dojo.hitch(this,"_updateSelectionOnFetch")));
this._connectArr.push(dojo.connect(this.grid,"_onFetchComplete",dojo.hitch(this,"_updateSelectionOnFetch")));
this._connectArr.push(dojo.connect(this.grid,"resize",dojo.hitch(this,"_updateSelectionOnRefresh")));
this._connectArr.push(dojo.connect(this.grid,"updateRow",dojo.hitch(this,"_updateSelectionOnRefresh")));
this._connectArr.push(dojo.connect(this.grid,"updateRowCount",dojo.hitch(this,"_updateSelectionOnRefresh")));
},_updateSelectionOnFetch:function(_db5,_db6,size){
var _db7;
if(_db6){
startRowIdx=_db6.startRowIdx;
_db7=_db6.count;
start=0;
}
if(_db7&&_db7>0){
this._updateSelectionOnRefresh();
}
},selectAllRows:function(){
var _db8=dojo.byId("selectDiv");
var _db9=this.grid.rowCount;
for(var i=0;i<_db9;i++){
var item=this.grid.getItem(i);
var id=this.grid.store.getIdentity(item);
var _dba="treeimgid"+id;
var _dbb=dojo.byId(_dba);
this._updateCacheSelect(i,item,true);
}
this._updateParent();
this._updateSelectionByCache();
},deSelectAllRows:function(){
var _dbc=dojo.byId("selectDiv");
var _dbd=this.grid.rowCount;
for(var i=0;i<_dbd;i++){
var item=this.grid.getItem(i);
this._updateCacheSelect(i,item,false);
}
this._updateParent();
this._updateSelectionByCache();
},onSelectionChanged:function(e){
if(e){
if(e.keyCode&&e.keyCode!=13){
return;
}
if(e.cellIndex!=0){
return;
}
var item=this.grid.getItem(e.rowIndex);
var sel=this._isRowSelected(e.rowIndex);
if(sel!=undefined){
this._changeSelectionByRow(e);
}
}else{
this._updateSelectionByCache();
}
},_updateCacheOnExpando:function(_dbe,_dbf){
if(_dbf){
var item=this.grid.getItem(_dbe);
var id=this.grid.store.getIdentity(item);
var _dc0=this._getItemById(id);
if(_dc0){
var _dc1=_dc0.selStatus;
if(_dc1!=="partial"){
if(this.grid.treeModel.mayHaveChildren(item)){
this._selectChildren(item,_dbe,_dc1);
}
}else{
this._updateSelectionByCache();
}
}else{
this._updateSelectionByCache();
}
}else{
this._updateSelectionByCache();
}
},_changeSelectionByRow:function(e){
var _dc2=e.rowIndex;
var item=this.grid.getItem(_dc2);
var _dc3=false;
var _dc4=false;
var id=this.grid.store.getIdentity(item);
if(this.grid.cache.getExpandoStatusByRowIndex(_dc2)&&this.grid.treeModel.mayHaveChildren(item)){
_dc3=true;
_dc4=this._updateSelection(item,id,_dc2);
this._selectChildren(item,_dc2,_dc4);
}else{
this._updateSelection(item,id,_dc2);
this._updateParent();
this._updateSelectionByCache();
}
},_updateSelectionOnRefresh:function(){
this._updateSelectionByCache();
},_updateSelectionByCache:function(){
for(var i=0;i<this.grid.rowCount;i++){
var sel=this.isItemSelectedInCacheByIdx(i);
var item=this.grid.getItem(i);
if(!item){
continue;
}
var id=this.grid.store.getIdentity(item);
var _dc5=dojo.byId("treeimgid"+id);
if(sel==true){
this.grid.selection.addToSelection(i);
if(dojo.hasClass(_dc5,"treeTableCheckBox")){
dojo.removeClass(_dc5,["treeTableCheckBox"]);
}else{
if(dojo.hasClass(_dc5,"treeTableToggleButtonPartial")){
dojo.removeClass(_dc5,["treeTableToggleButtonPartial"]);
}
}
dojo.addClass(_dc5,["treeTableToggleButtonChecked"]);
}else{
if(sel==false){
this.grid.selection.deselect(i);
if(dojo.hasClass(_dc5,"treeTableToggleButtonChecked")){
dojo.removeClass(_dc5,["treeTableToggleButtonChecked"]);
}else{
if(dojo.hasClass(_dc5,"treeTableToggleButtonPartial")){
dojo.removeClass(_dc5,["treeTableToggleButtonPartial"]);
}
}
dojo.addClass(_dc5,["treeTableCheckBox"]);
}else{
if(sel=="partial"){
this.grid.selection.deselect(i);
if(dojo.hasClass(_dc5,"treeTableToggleButtonChecked")){
dojo.removeClass(_dc5,["treeTableToggleButtonChecked"]);
}else{
if(dojo.hasClass(_dc5,"treeTableCheckBox")){
dojo.addClass(_dc5,["treeTableToggleButtonPartial"]);
}
}
dojo.addClass(_dc5,["treeTableToggleButtonPartial"]);
}else{
if(this.grid.selection.isSelected(i)){
this.grid.selection.deselect(i);
}
}
}
}
}
},_updateParent:function(){
for(var i=this.grid.rowCount-1;i>=0;i--){
var _dc6=0;
var item=this.grid.getItem(i);
if(!item){
continue;
}
var id=this.grid.store.getIdentity(item);
if(this.grid.cache.getExpandoStatusByRowIndex(i)===false){
continue;
}
if(this.grid.treeModel.mayHaveChildren(item)){
var _dc7={start:0,count:this.grid.keepRows,parentId:id,parentRowIndex:i,sort:this.grid.getSortProps()};
if(this.grid.treeModel.serverStore){
this.grid.treeModel.getChildren(item,dojo.hitch(this,"_updateParentRecursive"),dojo.hitch(this,"_onError"),_dc7);
}else{
var _dc8=dojo.hitch(this,"_updateParentRecursive");
this.grid.treeModel.getChildren(item,function(_dc9){
_dc8(_dc9,_dc7);
},dojo.hitch(this,"_onError"),_dc7);
}
}
}
},_updateParentRecursive:function(_dca,_dcb,size){
var item=this.grid.getItem(_dcb.parentRowIndex);
var _dcc=false;
var _dcd=0;
for(j=0;j<_dca.length;j++){
var cId=this.grid.store.getIdentity(_dca[j]);
var _dcc=this.getSelectedStatusById(cId);
if(_dcc===true){
_dcd++;
}else{
if(_dcc==="partial"){
_dcc="partial";
break;
}
}
}
if(_dcd>0){
if(_dca.length==_dcd){
this._updateCacheSelect(_dcb.parentRowIndex,item,true);
}else{
this._updateCacheSelect(_dcb.parentRowIndex,item,"partial");
}
}else{
if(_dcc=="partial"){
this._updateCacheSelect(_dcb.parentRowIndex,item,"partial");
}else{
this._updateCacheSelect(_dcb.parentRowIndex,item,false);
}
}
this._updateSelectionByCache();
},_isRowSelected:function(idx){
var sel=this.isItemSelectedInCacheByIdx(idx);
var item=this.grid.getItem(idx);
var id=this.grid.store.getIdentity(item);
var _dce="treeimgid"+id;
var _dcf=dojo.byId(_dce);
if(sel==undefined){
if(dojo.hasClass(_dcf,"treeTableToggleButtonChecked")){
return true;
}else{
return false;
}
}else{
return sel;
}
},_updateSelection:function(item,id,_dd0){
var _dd1;
if(this.getSelectedStatusById(id)===false){
this._updateCacheSelect(_dd0,item,true);
_dd1=true;
}else{
if(this.getSelectedStatusById(id)===true){
this._updateCacheSelect(_dd0,item,false);
_dd1=false;
}else{
if(this.getSelectedStatusById(id)=="partial"){
this._updateCacheSelect(_dd0,item,true);
_dd1=true;
}else{
this._updateCacheSelect(_dd0,item,true);
_dd1=true;
}
}
}
return _dd1;
},_selectChildren:function(item,_dd2,_dd3){
var _dd4=this.grid.store.getIdentity(item);
var _dd5={start:0,count:this.grid.keepRows,parentId:_dd4,sort:this.grid.getSortProps(),parentRowIndex:_dd2,parentSelectFlag:_dd3};
if(this.grid.treeModel.serverStore){
this.grid.treeModel.getChildren(item,dojo.hitch(this,"_recursiveChildSelect"),dojo.hitch(this,"_onError"),_dd5);
}else{
var _dd6=dojo.hitch(this,"_recursiveChildSelect");
this.grid.treeModel.getChildren(item,function(_dd7){
_dd6(_dd7,_dd5);
},dojo.hitch(this,"_onError"),_dd5);
}
},_getChildren:function(item){
var _dd8=this.grid.store.getIdentity(item);
var _dd9={start:0,count:this.grid.keepRows,parentId:_dd8,sort:this.grid.getSortProps()};
this.grid.treeModel.getChildren(item,dojo.hitch(this,"_setChildren"),dojo.hitch(this,"_onError"),_dd9);
},_setChildren:function(_dda,_ddb,size){
this.children=_dda;
},_onError:function(e){
},_recursiveChildSelect:function(_ddc,_ddd,size){
var _dde=_ddd.parentRowIndex;
var _ddf=_ddd.parentSelectFlag;
var _de0=this.grid.cache.getExpandoStatusByRowIndex(_dde);
var _de1=dojo.hitch(this,function(_de2,_de3,_de4,_de5){
if(_de2&&_de3===true){
for(var i=_de4+1,j=0;j<_de2.length;j++){
var item=_de2[j];
var id=this.grid.store.getIdentity(item);
var _de6=this.grid.treeModel.mayHaveChildren(item);
var _de7=this.grid.cache.getExpandoStatusByRowIndex(i);
if(_de6&&_de7){
this._selectChildren(item,i,_de5);
i=i+j;
}else{
i++;
}
if(_de5===false){
this._updateCacheSelect(i,item,false);
}else{
if(_de5===true){
this._updateCacheSelect(i,item,true);
}
}
}
}
return;
});
if(_ddc&&_de0===true){
_de1(_ddc,_de0,_dde,_ddf);
}
this._updateParent();
this._updateSelectionByCache();
},destroy:function(){
try{
dojo.forEach(this._connectArr,dojo.disconnect);
this._connectArr=[];
}
catch(ex){
console.warn("Destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
}
}});
}
if(!dojo._hasResource["dojoe.treetable.TreeTable"]){
dojo._hasResource["dojoe.treetable.TreeTable"]=true;
dojo.provide("dojoe.treetable.TreeTable");
dojo.declare("dojoe.treetable.TreeTable",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dojoe.treetable","templates/TreeTable.html","\r\n<div class=\"tivTreeTable\" tabIndex=0 aria-label=\"tree table\" role=\"application\">\r\n\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  width=\"100%\" height=\"100%\" style=\"width:100%;height:100%;\"  role=\"presentation\">\t\t\r\n\t\t<tr valign=\"center\"><td width=\"100%\" role=\"toolbar\">\r\n\t\t\t<div dojoAttachPoint=\"toolbarNode\"></div></td></tr>\r\n\t\t<tr valign=\"center\"><td width=\"100%\" role=\"treegrid\">\r\n\t\t\t<div dojoAttachPoint=\"treeGridNode\"></div>\t</td></tr>\t\t\r\n\t</table>\r\n</div>\t\r\n"),widgetsInTemplate:true,gridParams:null,grid:null,toolbarVisible:true,width:"",height:"",toolbarOptions:null,onContextMenuEvtObj:null,enableResize:true,_toolbar:null,_defaultHeight:"80%",_defaultWidth:"80%",indirectSelection:false,enableColumnReorder:true,state:null,_loadIndSelection:null,constructor:function(args){
this.resources_=dojo.i18n.getLocalization("dojoe.treetable","TreeTable",this.lang);
this.gridParams={};
this.actionList={};
},postCreate:function(){
if(this.width===""&&!this.gridParams.autoWidth){
this.width=this._defaultWidth;
}
if(this.height===""){
this.height=this._defaultHeight;
}
var size=dijit.getViewport();
var _de8=this.height;
var _de9=this.height.substring(this.height.length-1,this.height.length);
if(_de9=="%"){
_de8=size.h*((parseInt(this.height.slice(0,-1)))/100);
_de8=_de8+"px";
}
if(!this.gridParams.autoWidth){
dojo.style(this.domNode,"width",this.width);
}
dojo.style(this.domNode,"height",_de8);
this.gridParams.columnReordering=false;
if(this.gridParams.keepSelection==undefined){
this.gridParams.keepSelection=true;
}
if(!this.gridParams.rowSelector||this.gridParams.indirectSelection){
this.gridParams.rowSelector=false;
}
if(this.gridParams.structure===null){
this.gridParams.structure=[{}];
}
this._makeGrid();
if(this.gridParams.filter&&this.gridParams.filter.showHierarchy){
}else{
this.grid.treeModel.mayHaveChildren=dojo.hitch(this.grid,function(item){
var _dea=null;
if(this.filterApplied){
return false;
}
return dojo.some(this.treeModel.childrenAttrs,function(attr){
_dea=this.treeModel.store.getValue(item,attr);
if(dojo.isString(_dea)){
return parseInt(_dea,10)>0||_dea.toLowerCase()==="true"?true:false;
}else{
if(typeof _dea=="number"){
return _dea>0;
}else{
if(typeof _dea=="boolean"){
return _dea;
}else{
if(this.store.isItem(_dea)){
_dea=this.treeModel.store.getValues(item,attr);
return dojo.isArray(_dea)?_dea.length>0:false;
}else{
if(dojo.isArray(_dea)){
return _dea.length>0;
}else{
return false;
}
}
}
}
}
},this);
});
}
if(this.menu!==null){
dojo.connect(this.grid,"onRowContextMenu",dojo.hitch(this,"showRowContextMenu"));
}
if(this.toolbarVisible){
this._toolbar=new dojoe.treetable._Toolbar({treeTable:this,filterOptions:this.gridParams.filter},this.toolbarNode);
}
this.resize();
if(this.enableResize===true){
this.connect(window,"onresize",dojo.hitch(this,"resize"));
}
if(this._toolbar&&this._toolbar.actionListWidget){
this.connect(this._toolbar.actionListWidget,"openDropDown",dojo.hitch(this,"onActionListOpen"));
this.connect(this._toolbar.actionListWidget,"closeDropDown",dojo.hitch(this,"onActionListClose"));
}
if(this.grid.defaultState&&this.grid.defaultState.filter){
this.setFilter(this.grid.defaultState.filter);
}
if(this.gridParams.preFilter){
dojo.connect(this,"onTreeTableLoad",dojo.hitch(this,"_preFilter"));
}
setTimeout(dojo.hitch(this,"onTreeTableLoad",this),1000);
},onTreeTableLoad:function(_deb){
},_preFilter:function(){
if(this.gridParams.preFilter){
if(this.gridParams.preFilter[0].column==="any"){
if(this.gridParams.preFilter[0].value){
this.setFilter(this.gridParams.preFilter[0].value);
}
}
}
},onActionListOpen:function(){
},onActionListClose:function(){
},_disableColumnMove:function(_dec){
if(_dec){
try{
_dec.cancelBubble=true;
dojo.stopEvent(_dec);
}
catch(e){
console.error(e);
}
}
},setFilter:function(_ded){
if(this._toolbar){
if(this._toolbar.quickFilter){
this._toolbar.quickFilter._setFilter(_ded);
}
}
},getFilter:function(){
if(this._toolbar){
if(this._toolbar.quickFilter){
return this._toolbar.quickFilter._getFilter();
}
}
},_setState:function(_dee){
if(_dee){
this.gridParams.defaultState=_dee;
}
},getState:function(){
state=this.grid.getState();
return dojo.mixin({filter:this.getFilter()},state);
},selectHeaderRow:function(_def){
if(_def.cell.field!="selector"){
return;
}
var _df0=dojo.byId("selectDiv");
if(dojo.hasClass(_df0,"treeTableToggleButtonChecked")){
dojo.removeClass(_df0,["treeTableToggleButtonChecked"]);
dojo.addClass(_df0,["treeTableCheckBox"]);
this.deSelectAllRows();
}else{
dojo.removeClass(_df0,["treeTableCheckBox"]);
this.selectAllRows();
dojo.addClass(_df0,["treeTableToggleButtonChecked"]);
}
if(_def){
try{
_def.cancelBubble=true;
dojo.stopEvent(_def);
}
catch(e){
console.error(e);
}
}
},_makeGrid:function(){
if(this.gridParams.indirectSelection){
this.indirectSelection=this.gridParams.indirectSelection;
}
if(this.gridParams.enableColumnReorder===false){
this.enableColumnReorder=this.gridParams.enableColumnReorder;
}
if(this.state){
this._setState(this.state);
}
this.grid=new dojox.grid.LazyTreeGrid(this.gridParams,this.treeGridNode);
if(!this.gridParams.noDataMessage){
this.grid.noDataMessage=this.resources_.NO_DATA;
}else{
this.grid.noDataMessage=this.gridParams.noDataMessage;
}
if(this.gridParams.selectable!==undefined){
this.grid.selectable=this.gridParams.selectable;
}else{
this.grid.selectable=true;
}
this.grid.startup();
if(this.indirectSelection){
this._loadIndSelection=new dojoe.treetable._IndirectSelection(this.grid);
}
},showRowContextMenu:function(e){
if(this.menu){
this.menu._openMyself({target:e.target,coords:"pageX" in e?{x:e.pageX,y:e.pageY}:null});
}
return e;
},addToActionList:function(item){
if(this._toolbar){
if(this._toolbar.actionMenu){
this._toolbar.actionListWidget.dropDown.addChild(item,0);
}
}
},addContextMenuToTreeTable:function(_df1,_df2){
if(_df1=="rowMenu"){
_df2.bindDomNode(this.grid.domNode);
this.grid.onRowContextMenu=function(e){
if(!this.menu){
this.menu=_df2;
}
};
}
},addToToolbar:function(item,_df3,row,_df4){
if(this._toolbar){
if(row&&row==2){
this._toolbar._addToToolbarSecondRow(item,_df3);
}else{
this._toolbar._addToToolbarFirstRow(item,_df3);
}
if(_df4==false){
}else{
this.resize();
}
}
},addItemsToToolbar:function(_df5,_df6,row,_df7){
if(this._toolbar){
for(var i=0;i<_df5.length;i++){
if(row&&row==2){
this._toolbar._addToToolbarSecondRow(_df5[i],_df6+i);
}else{
this._toolbar._addToToolbarFirstRow(_df5[i],_df6+i);
}
}
if(_df7==false){
}else{
this.resize();
}
}
},getItem:function(_df8){
return this.grid.getItem(_df8);
},getRowCount:function(){
return this.grid.rowCount;
},getSelectedRowCount:function(){
return this.grid.selection.getSelectedCount();
},getSelectedRows:function(){
return this.grid.selection.getSelected();
},removeSelectedRows:function(){
this.grid.removeSelectedRows();
},isRowSelected:function(_df9){
return this.grid.selection.isSelected(_df9);
},disableMenuItem:function(_dfa){
var _dfb=dijit.byId(_dfa);
if(_dfb){
_dfb.setDisabled(true);
}
},enableMenuItem:function(_dfc){
var _dfd=dijit.byId(_dfc);
if(_dfd){
_dfd.setDisabled(false);
}
},refresh:function(_dfe){
if(this.grid.store.CURIRefresh){
this.grid.store.CURIRefresh();
this.grid._cleanup();
}
if(_dfe){
this.grid._cleanup();
}
var _dff=this.grid.scrollTop;
this.grid._refresh(true);
this.grid.setScrollTop(_dff);
},removeMenuItem:function(_e00){
var _e01=dijit.byId(_e00);
if(_e01){
_e01.destroyRecursive();
}
},deleteRow:function(item){
this.grid.store.deleteItem(item);
},removeItemFromToolbar:function(_e02){
if(this._toolbar){
this._toolbar._removeItem(_e02);
}
},removeFromActionList:function(_e03){
if(this._toolbar){
this._toolbar._removeFromActionList(_e03);
}
},addRow:function(item,_e04){
if(this._toolbar){
if(this._toolbar.quickFilter&&this._toolbar.quickFilter.filterText!==null){
this._toolbar.quickFilter._clearFilter();
}
this._toolbar._clearSort();
}
if(!_e04){
if(this.grid){
var _e05=this.grid.store.newItem(item);
var _e06=this.grid.getItemIndex(_e05);
this.grid.scrollToRow(_e06);
}
}else{
var s=this.grid.store;
s.fetchItemByIdentity({identity:_e04,onItem:function(item){
_e04=item;
}});
if(_e04){
s.newItem(item,{parent:_e04,attribute:"children"});
}
}
},resize:function(_e07){
if(!this.grid||!this.domNode||!this.domNode.parentNode||this.domNode.parentNode.nodeType!=1){
return;
}
if(!this.grid.autoWidth){
dojo.style(this.domNode,"width",this.width);
}else{
dojo.style(this.domNode,"width",dojo.marginBox(this.grid.domNode).w+"px");
}
var _e08=false;
if(_e07&&_e07.currentTarget){
_e08=true;
}
var size=dijit.getViewport();
if(this._previousSize&&this._previousSize.h==size.h&&this._previousSize.w==size.w&&_e08==true){
return;
}else{
this._previousSize=size;
}
var _e09=this.height;
if(!(this.domNode.parentNode.style&&this.domNode.parentNode.style.height)){
var _e0a=this.height.substring(this.height.length-1,this.height.length);
if(_e0a=="%"){
_e09=size.h*((parseInt(this.height.slice(0,-1)))/100);
_e09=_e09+"px";
}
}
dojo.style(this.domNode,"height",_e09);
setTimeout(dojo.hitch(this,function(){
this._delayResize(_e07);
}),100);
},_delayResize:function(_e0b){
var _e0c=dojo.marginBox(this.domNode);
var _e0d=this.grid._getPadBorder().h;
if(this._toolbar){
var _e0e=dojo.marginBox(this._toolbar.domNode);
_e0c.h=_e0c.h-_e0e.h-(2*_e0d);
}
if((_e0c.h<=0||_e0c.w<=0)){
return;
}
if(_e0b&&_e0b.currentTarget){
this.grid.resize({h:_e0c.h,w:_e0c.w});
}else{
this.grid.resize({h:_e0c.h});
}
},destroy:function(){
try{
if(this._toolbar&&this._toolbar.quickFilter){
this._toolbar.quickFilter.unWrapStore();
}
if(this.menu){
this.menu.destroyRecursive();
}
delete this.resources_;
if(this._loadIndSelection){
this._loadIndSelection.destroy();
}
var _e0f=dijit.findWidgets(this.domNode);
dojo.forEach(_e0f,function(w){
if(w){
if(w.destroyRecursive){
w.destroyRecursive();
}else{
if(w.destroy){
w.destroy();
}
}
}
});
var _e10=this.getChildren();
dojo.forEach(_e10,function(_e11){
if(_e11){
if(_e11.destroyRecursive){
_e11.destroyRecursive();
}else{
if(_e11.destroy){
_e11.destroy();
}
}
}
});
this.inherited(arguments);
}
catch(ex){
console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
}
}});
String.prototype.startWith=function(str){
if(str==null||str==""||this.length==0||str.length>this.length){
return false;
}
if(this.substring(0,str.length)==str){
return true;
}else{
return false;
}
};
}
if(!dojo._hasResource["dojoe.treetable.TreeTableAll"]){
dojo._hasResource["dojoe.treetable.TreeTableAll"]=true;
dojo.provide("dojoe.treetable.TreeTableAll");
dojo.require("dojoe.treetable._QuickSearchFilter");
dojo.require("dojoe.treetable._ConfigureColumnsDialog");
dojo.require("dojoe.treetable._Toolbar");
dojo.require("dojoe.treetable.TreeTable");
}
dojo.i18n._preloadLocalizations("dojoe.treetable.nls.TreeTableAll",["ROOT","ar","cs","da","de","es","fi","fr","he","hr","hu","it","ja","ko","nb","nl","pl","pt","pt-br","ru","sl","sv","tr","xx","zh","zh-tw"]);
