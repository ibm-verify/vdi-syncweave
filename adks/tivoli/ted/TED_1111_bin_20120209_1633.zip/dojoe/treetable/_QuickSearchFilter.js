/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.treetable._QuickSearchFilter"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.treetable._QuickSearchFilter"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
// dojo.provide allows pages to use all of the types declared in this resource.
dojo.provide("dojoe.treetable._QuickSearchFilter");

//dojo.require the necessary dijit hierarchy
dojo.require("dijit._Widget");
dojo.require("dijit._Templated");
dojo.require("dojoe.treetable.filter._FilterExpr");
dojo.require("dojoe.treetable.filter.FilterLayer");

dojo.requireLocalization("dojoe.treetable", "TreeTable", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");
dojo.declare("dojoe.treetable._QuickSearchFilter", [dijit._Widget,dijit._Templated], {
		// Path to the template
		templateString : dojo.cache("dojoe.treetable", "templates/QuickSearchFilter.html", "<div class=\"dijitReset  dijitTextBox quickFilter\" dojoAttachEvent='onmouseover:_onHover,mouseleave:_onUnHover,onblur:_onBlur,onclick: _onClick'>\r\n\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" role=\"presentation\">\r\n\t\t<tbody>\r\n\t\t\t<tr valign=\"center\">\r\n\t\t\t\t<td width=\"98%\" height=\"100%\">\r\n\t\t\t\t\t<div class=\"dijitReset  dijitInputContainer\">\t\t    \r\n\t\t\t\t\t\t<input dojoAttachPoint=\"searchField\" title=\"${resources_.QUICK_FILTER}\" class=\"dijitInputInner qf-textfield\" type=\"text\" \r\n\t\t\t\t\t\t\tvalue=\"${resources_.QF_DEFAULT_TEXT}\" valign=\"middle\" tabindex=\"0\"\r\n\t\t\t\t\t\t\tdojoAttachEvent='onfocus:_onFocus,onclick:_onClick,onkeyup:_onKeyUp,onpaste:_onKeyUp,oncut:_onKeyUp,onKeyPress:_onKeyUp' role=\"textbox\"/>\t\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</td>\t\r\n\t\t\t\t<td width=\"2%\" height=\"100%\">\r\n\t\t\t\t\t<div class=\"dijitReset  dijitArrowButtonContainer \">\r\n\t\t\t\t\t\t<button title=\"${resources_.CLEAR_FILTER}\" class=\"dijitReset quickFilterClearInner\" type=\"button\" tabindex=\"0\" \r\n\t\t\t\t\t\t\tvalign=\"middle\"  dojoAttachPoint='clearFilterNode' dojoAttachEvent='onclick:_onCancel,onkeypress:_onCancel' role=\"button\"></button>\t\t\t\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t</tbody>\t\t\r\n\t</table>\r\n</div>\r\n"), 
		
		// Set this to true if your widget contains other widgets
		widgetsInTemplate : false, 
		grid : null, 
		handle : null, 
		filterText : null, 
		filterLayer : null, 
		filterOptions : null, 
		_quickFilterButton: false, //change filter on type based on this	
		_quickFilterDelay: 700,	//delay in ms before quick filter is applied as typed		
		
		// Override this method to perform custom behavior during dijit construction.
		// Common operations for constructor:
		// 1) Initialize non-primitive types (i.e. objects and arrays)
		// 2) Add additional properties needed by succeeding lifecycle methods
		constructor : function () {
			this.resources_ = dojo.i18n.getLocalization("dojoe.treetable", "TreeTable", this.lang);
		}, 
		
		postCreate : function () {
			if(this.filterOptions){
				if(this.filterOptions.showQuickFilterButton !== undefined) this._quickFilterButton = this.filterOptions.showQuickFilterButton;
				if(this.filterOptions.quickFilterDelay) this._quickFilterDelay = this.filterOptions.quickFilterDelay;
			}
			/*LS - 2/08/2011 - 25076 - Treetable - when clicking clear filter 'x' button few times, data is not re-fetched (server-side store) */
			//disabling clear filter icon when there is no filter applied to avoid above confusion	
			if(this.filterText !== null && this.filterText !== "" )	{
				dojo.style(this.clearFilterNode, "display", "block");
			}else{
				dojo.style(this.clearFilterNode, "display", "none");
			}		
		}, 		
		
		// When this method is called, all variables inherited from superclasses are 'mixed in'.
		// Common operations for postMixInProperties
		// 1) Modify or assign values for widget property variables defined in the template HTML file
		postMixInProperties : function () {
		}, 
		
		_parseDecimal : function (v) {
			return parseInt(v, 10);
		}, 
		
		_onFocus : function () {
			//LS- 26/10/2011 - # 30377 - Treetable - incorrect results when setting filter or sorting while data is being loaded
			//return if grid._loading a variable indicating the grid loading is true
			if(this.grid._loading) return;
			dojo.addClass(this.domNode, 'dijitTextBoxFocused');
			if (this.searchField.value == this.resources_.QF_DEFAULT_TEXT) {
				this.searchField.style.color = "#000000";
				this.searchField.value = "";
			}
		}, 
		
		//Latha : 10Apr2011 Fix for defect 16795. Setting Focus to filter box
		_onClick : function () {
			//LS- 26/10/2011 - # 30377 - Treetable - incorrect results when setting filter or sorting while data is being loaded
			//return if grid._loading a variable indicating the grid loading is true
			if(this.grid._loading) return;
			dojo.addClass(this.domNode, 'dijitTextBoxFocused');
			this.searchField.focus();
			this.searchField.style.color = "#000000";
			if (this.searchField.value == this.resources_.QF_DEFAULT_TEXT) {
				this.searchField.value = "";
			}
		},
		
		_onBlur : function () {
			dojo.removeClass(this.domNode, 'dijitTextBoxFocused');
			dojo.removeClass(this.domNode, 'dijitTextBoxHover');
			if (!this.searchField.value) {
				this.searchField.style.color = "#999999";
				this.searchField.value = this.resources_.QF_DEFAULT_TEXT;
			}
		}, 
		
		_onHover : function () {
			//LS- 26/10/2011 - # 30377 - Treetable - incorrect results when setting filter or sorting while data is being loaded
			//return if grid._loading a variable indicating the grid loading is true
			if(this.grid._loading) return;
			dojo.addClass(this.domNode, 'dijitTextBoxHover');
		}, 
		
		_onUnHover : function () {
			dojo.removeClass(this.domNode, 'dijitTextBoxHover');
		}, 
		
		_onKeyUp : function (event) {	
			//LS- 26/10/2011 - # 30377 - Treetable - incorrect results when setting filter or sorting while data is being loaded
			//return if grid._loading a variable indicating the grid loading is true
			if(this.grid._loading) return;
			//Bobby: 25Feb2011, don't do filter when tabbed thru
			//tab & shift keys		
			//console.info("key -"+ event.keyCode);	
			this.filterText = this.searchField.value;
			if(event){
				if (event.keyCode == 9 || event.keyCode == 16) {
					return;
				}else if(this._quickFilterButton && event.keyCode !== 13){
					return;
				}			
				//console.log("filter ---"+this.filterText);
				if (event.keyCode == 13) {
					dojo.stopEvent(event);
					this._setFilter();
					return;
				}
			}
			this.onChangeFilterText();
		}, 
		
		_onCancel : function (event) {			
			//Bobby: 17Apr2011, don't do anything when tabbed thru
			//tab & shift keys	
			if(event.keyCode == 9 || event.keyCode == 16) {
				//Bobby:17Apr2011, tab gets stuck if stopped
				//dojo.stopEvent(event);
				return;
			}else{
				this._clearFilter();			
			}			
		}, 
		
		wrapStore : function () {
			this._store = this.grid.store;
			this._doFilter();
			//this.grid.store = this._store;
			
			this.connect(this.grid, "setStore", function (store) {
				if (store !== this._store) {
					//this.unWrapStore();
					this._doFilter();
					this._store = store;
				}
			});
		}, 
		
		_clearFilter : function () {
			this.searchField.value = "";		
			
			/*pass a string 'clear'  to identify clear filter condition*/
			//Bobby:25Mar2011, need to clear only if layer exists.
			//else error: this.grid.store.layer is not a function
			//Bobby:29Mar2011, filter should be cleared differently for client & server
			//15113: Treetable quickfilter cannot be disabled once entered
			//console.info("clearFilter ...... BEGIN");
			//console.info("filterOptions.isServerSide:"+this.filterOptions.isServerSide);
			this.grid.filterApplied = false;	
			if (this.filterOptions.isServerSide){
				//console.info("calling grid.setQuery.....");
				if (this.filterLayer) {
					this.filterLayer.filterDef(null);
					//#15380 fix to help CURI store to return individual rows when filtered
					//this.unWrapStore();
					/*#17606 - 19/07/2011 - TreeTable: quickfilter disabling results in error*/
					// retaining the old query and appending origins true
					if(this.grid.query){
						this.grid.setQuery(dojo.mixin(this.grid.query,{origins:true,"filterText" : null}));
					}else{
						// if there is no existing query, just fetch origins
						this.grid.setQuery({origins:true});
					}
					this.grid._cleanup(); 
					this.grid._refresh();
				}
			}else{
				if (this.filterLayer) {
					//console.info("clearing filterDef.....");
					this.filterLayer.filterDef('clear');
					//this.filterLayer.filterDef(expr);
					this.grid._cleanup(); 
					this.grid._refresh();
				}
			}	
			this.filterText=null;
			/*LS - 2/08/2011 - 25076 - Treetable - when clicking clear filter 'x' button few times, data is not re-fetched (server-side store) */
			//disabling clear filter icon when there is no filter applied to avoid above confusion		
			this._disableQuickFilter();
			//Connect to onFitered  through filter layers oncommandLoad or connect to fetch complete to enable the filter back with clear filter icon
			this.connect(this.filterLayer,"onFiltered", dojo.hitch(this,"_enableQuickFilter"));
			this.fetchEnableFilterHandler = this.connect(this.grid,"_onFetchComplete", dojo.hitch(this,"_enableQuickFilter"));
			//console.dir(this.grid);
			//console.info("clearFilter ...... END");			
		}, 
		//Satanik:31May2011: Added new api for setting and getting filter. Direct connect to wrapStore is no more required instead now _setFilter should be conected.
		_setFilter : function (filterText){
			if(filterText !== undefined && filterText !==''){
				this.filterText=filterText;
				this.searchField.value=filterText;
			}
			this.wrapStore();
		},
		
		_getFilter : function(){
			return this.filterText;
		},
		_doFilter : function () {
			//Bobby:18Aug2011, adding option to prevent clearing selection on Filter
			//27171: Need option to allow selection after filtering
			if(this.filterOptions && this.filterOptions.retainSelection !== true){
				//Bobby: 09Mar2011
				//13285: Allow for selection to be cleared when filter occurs				
				this.grid.selection.clear();
			}				
			
			var args = this.filterOptions;
			
			//TODO: Using the Enhanced Grid Plugin Filter , might need to copy the StoreLayer.js into treetable toavoid any dependencies.
			//var ns = dojox.grid.enhanced.plugins;
			//Uncomment the below variable to use the enhanced grid filter and comment the next fns
			//var fns = dojox.grid.enhanced.plugins.filter;			
			//Uncomment the below variable to use the customized filter for treegrid
			var fns = dojoe.treetable.filter;
			var QFinput = this.filterText;
			//Satanik:23Jun2011: adding a null check for the filtertext before filtering
			if (QFinput === null || QFinput === undefined) {
				return;
			}
			if (QFinput === "") {
				this._clearFilter();
				return;
			}
			var cells = this.grid.layout.cells;
			var expr = new fns.LogicANY(dojo.map(cells, function (cell) {
				return new fns.ContainsIgnoreCase(
					new fns.StringExpr(cell, true), 
					new fns.StringExpr(QFinput, false));
			}));
			
			if (!this.filterLayer) {
				if (args.isServerSide) {
					this.filterLayer = new fns.ServerSideFilterLayer(args);
					fns.wrap(this.grid.store, "fetch", this.filterLayer);
				} else {
					//Oliver comment : remove cache size
					this.filterLayer = new fns.ClientSideFilterLayer({
							fetchAll : true, 
							grid : this.grid, 
							getter : dojo.hitch(this.grid ? this.grid : this, function (/* data item */datarow, /* cell */cell, /* int */rowIndex) {
									// summary:
									//     Define the grid-specific way to get data from a row.
									//     Argument "cell" is provided by FilterDefDialog when defining filter expressions.
									//     Argument "rowIndex" is provided by FilterLayer when checking a row.
									//     FilterLayer also provides a forth argument: "store", which is inGrid.store,
									//     but we don't need it here.
									try {
										return cell.get(rowIndex, datarow);
									} catch (ex) {
										console.log(ex.message);
									}
								}) 
						});
					fns.wrap(this.grid.store, "fetch", this.filterLayer);
				}
			}
			if (args.isServerSide) {
				this.grid.setQuery({
					filterText : QFinput
				});
			}
			this.filterLayer.filterDef(expr);
			this.grid.filterApplied = true;
			/*LS - 2/08/2011 - 25076 - Treetable - when clicking clear filter 'x' button few times, data is not re-fetched (server-side store) */
			/*LS - 12/11/2011 - Disable QF on press of enter or filter button until the data loads in the grid, */
			this._disableQuickFilter();
			//Connect to onFitered  through filter layers oncommandLoad or connect to fetch complete to enable the filter back with clear filter icon
			this.connect(this.filterLayer,"onFiltered", dojo.hitch(this,"_enableQuickFilter"));
			this.fetchEnableFilterHandler = this.connect(this.grid,"_onFetchComplete", dojo.hitch(this,"_enableQuickFilter"));
			//Display the results
			//Satanik:2Jun2011:Fixing the QF for the ORIA changed in the driver of 1Jun2011
			this.grid._cleanup(); 
			this.grid._refresh(true);
			//this.grid.store.layer("filter").filterDef(null);			
		}, 
		
		_enableQuickFilter: function(fitleredSize, totalSize) {
			if(this.clearFilterNode && this.clearFilterNode.style.display == "none" &&
				(this.filterText && this.filterText !=="" && this.searchField.value != this.resources_.QF_DEFAULT_TEXT )){
					dojo.style(this.clearFilterNode, "display", "block");
				}
			if(this.searchField && this.searchField.disabled == true){
				this.searchField.disabled = false;
				if(this.filterText && this.filterText !=="" && this.searchField.value != this.resources_.QF_DEFAULT_TEXT ){
					this.searchField.focus();
					this.searchField.style.color = "#000000";
				}else if (!this.searchField.value || this.searchField.value == this.resources_.QF_DEFAULT_TEXT ){
					this.searchField.style.color = "#999999";
					this.searchField.value = this.resources_.QF_DEFAULT_TEXT;
				}
			}
			this.disconnect(this.fetchEnableFilterHandler);
			
		},
		
		_disableQuickFilter: function() {
			if(this.clearFilterNode && this.clearFilterNode.style.display == "block"){
				dojo.style(this.clearFilterNode, "display", "none");
			}
			if(this.searchField && this.searchField.disabled == false){
				this.searchField.disabled = true;
				this._onBlur();
				this.searchField.style.color = "#999999";
			}
		},
		
		unWrapStore : function () {
			//console.log("UNWRAPPING STORE");
			this._store = this.grid.store;
			try {
				this._store.unwrap("filter");
			} catch (ex) {
				console.log("no layers wrapped");
			}
		}, 
		
		onChangeFilterText : function () {
			if (this.handle) {
				clearTimeout(this.handle);
				this.handle = null;
			}
			var fnc = dojo.hitch(this, this._setFilter, this.filterText);
			this.handle = setTimeout(fnc, this._quickFilterDelay);
		}, 
		
		destroy: function(){
			// summary:  Destroys the toolbar.
			// tags: public	
			//memory leak issue: custom destroy method to take care of removing all widgets					
			try{
				delete this.resources_;
				//this is for destroying child templated widgets 
				//this should happen by itself but need to figure out why dijit._Templated is not taking care of it...
				var widgets = dijit.findWidgets(this.domNode);
				dojo.forEach(widgets, function(w) {
					if(w){
						if(w.destroyRecursive){
							w.destroyRecursive();
						} else if(w.destroy){
							w.destroy();
						}
					}
				});
				// this is for widgets added as child to this widget and their children..
				//not present in template
				var widgetArr = this.getChildren();
				dojo.forEach(widgetArr, function (child) {
					if(child){
						if(child.destroyRecursive){
							child.destroyRecursive();
						} else if(child.destroy){
							child.destroy();
						}
					}
				});
				this.inherited(arguments);
			}catch(ex){
				console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
			}
		}		
	});
 

}
