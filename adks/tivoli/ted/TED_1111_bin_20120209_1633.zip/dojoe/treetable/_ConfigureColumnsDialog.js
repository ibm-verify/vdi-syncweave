/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.treetable._ConfigureColumnsDialog"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.treetable._ConfigureColumnsDialog"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.treetable._ConfigureColumnsDialog");
dojo.require("dijit._Widget");
dojo.require("dijit._Templated");
dojo.require("dijit.Dialog");
dojo.require("dijit.Toolbar");
dojo.require("dijit.form.Form");
dojo.require("dijit.form.Button");
dojo.require("dijit.form.CheckBox");
dojo.require("dijit.layout.TabContainer");
dojo.require("dijit.layout.BorderContainer");
dojo.require("dijit.layout.ContentPane");

dojo.require("dojo.data.ItemFileWriteStore");
dojo.require("dijit.layout.ContentPane");
dojo.require("dojox.grid.EnhancedGrid");
dojo.require("dojox.grid.enhanced.plugins.NestedSorting");
dojo.require("dijit._Container");
dojo.require("dojo.i18n");
dojo.require("dojox.collections.ArrayList");

// NLS
dojo.requireLocalization("dojoe.treetable", "TreeTable", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");

// define the widget class
dojo.declare ("dojoe.treetable._ConfigureColumnsDialog", [ dijit._Widget, dijit._Templated ],{
		//summary: 		This class handles all UI rendering for configure column dialog options.
		// description: ConfigureColumnsDialog is a widget to control all the operations  
        //              on the dialog.        
		widgetsInTemplate: true,
		templateString: dojo.cache("dojoe.treetable", "templates/ConfigureColumnsDialog.html", "<div>\r\n\t<div dojoType=\"dijit.Dialog\" dojoAttachPoint=\"dialog\"\ttitle=\"${resources_.CONFIGURE_TREETABLE}\" tabindex=0 role=\"dialog\">\r\n\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" role=\"presentation\" style=\"width:100%height:100%\">\r\n\t\t\t<tr height=\"20%\" style=\"vertical-align:top;\"><td><label>${resources_.COLUMNS_VISIBLE}</label></td><tr>\r\n\t\t\t<tr><td>\r\n\t\t\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" role=\"presentation\">\r\n\t\t\t\t\t<tbody>\r\n\t\t\t\t\t\t<tr><td>\r\n\t\t\t\t\t\t\t\t<span dojoAttachPoint=\"selectAllButton\" role=\"button\">\r\n\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t<td>\r\n\t\t\t\t\t\t\t\t<span dojoAttachPoint=\"deselectAllButton\" role=\"button\">\r\n\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t</tbody>\r\n\t\t\t\t</table>\r\n\t\t\t</td></tr>\r\n\t\t\t<tr><td>\r\n\t\t\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\"  role=\"presentation\">\r\n\t\t\t\t\t<tbody>\r\n\t\t\t\t\t\t<tr valign=\"center\">\r\n\t\t\t\t\t\t\t<td width=\"90%\" height=\"100%\">\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t<div id=\"${id}tabs\" dojoType=\"dijit.layout.BorderContainer\" class=\"dialog\" style=\"height:200px;width:260px;\">\r\n\t\t\t\t\t\t\t\t\t<div dojoType=\"dijit.layout.ContentPane\" region=\"top\" >\t\t\t\t\r\n\t\t\t\t\t\t\t\t\t<div  dojoAttachPoint=\"enhancedGridNode\" style=\"height:170px;width:200px;\" role=\"grid\"></div>\r\n\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t<td width=\"10%\" height=\"100%\">\r\n\t\t\t\t\t\t\t\t<table role=\"presentation\">\r\n\t\t\t\t\t\t\t\t\t<tr><td><span dojoAttachPoint=\"upButton\" role=\"button\"></td></tr>  \r\n\t\t\t\t\t\t\t\t\t<tr><td><span dojoAttachPoint=\"downButton\" role=\"button\"></td></tr> \r\n\t\t\t\t\t\t\t\t</table>\r\n\t\t\t\t\t\t</td></tr>\t\r\n\t\t\t\t\t</tbody>\t\t\r\n\t\t\t\t</table>\t\t\t\t\t\t\t\r\n\t\t\t</td></tr>\r\n\t\t\t<tr><td>\r\n\t\t\t\t<button value=\"${resources_.OK}\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:onOK,onKeypress:onOK\" role=\"button\">${resources_.OK}</button>\r\n\t\t\t\t&nbsp;&nbsp;<button value=\"${resources_.CANCEL}\" dojoType=\"dijit.form.Button\" dojoAttachPoint=\"cancelButton\" dojoAttachEvent=\"onClick:onCancel,onKeypress:onCancel\" role=\"button\">${resources_.CANCEL}</button>\r\n\t\t\t</td></tr>\r\n\t\t</table>\r\n\t</div>\r\n</div>\r\n"),
		optionsWidget_: null,
		grid: null,
		indirectSelection: null,
		enableColumnReorder:null,
		enhancedGrid: null,
		columndata:null,
		
		constructor: function() {
			this.resources_ = dojo.i18n.getLocalization("dojoe.treetable", "TreeTable", this.lang);
		},
		
		postCreate: function() { 
		//summary: inherited method from the _Widget
		//description: Instantiate the TreeTableOptions for the the operations of configurecolumn.
			this.inherited ("postCreate", arguments);
			var columns=this.grid.layout.cells;
			var names=new Array();
			for (var i=0 in columns) {
				var column=columns[i];
				//Satanik:06Apr2011 checking for indirectSelection column
				var size=dojo.trim(column.name).length;
				if(size > 0){
				//Satanik:06Apr2011 checking for expandable column
					if(!column.isCollapsable){
						names.push(column);
					}
				}					
			}				
		    columndata = {
				identifier: 'id',
				label: 'id',
				items: []
			};
			var len = names.length;
			for(var i=0; i < names.length; ++i){
				//var row ={id : (i+1), 'name': names[i].name, 'hidden':!names[i].hidden, 'index': i} ;
				var row ={id : (i+1), 'name': names[i].name, 'hidden':!names[i].hidden} ;
				columndata.items.push(row);
			}
			var grid_layout = [{
				rows:[
					//22283: Configure Options dialog, IE - 'Visible' column should be a bit wider
					//Bobby: 20Jun2011, changing 15% & 85% width to 30% & 70%
					{ field: "hidden", width: "30%", name: this.resources_.VISIBLE, editable:true, cellType: dojox.grid.cells.Bool},
					//{ field: "index", width: "auto", name: 'Index'},
					{ field: "name", width: "70%", name: this.resources_.COLUMNS}					
				]
			}];
			var pluginsForGrid = {};	
			var itemStore = new dojo.data.ItemFileWriteStore({data:columndata});			
			var gridParams ={
				store : itemStore,
				structure : grid_layout,
				plugins : pluginsForGrid,
				selectionMode:'single',
				canSort: function(){return false;},
				keepSelection: false
			};
			this.enhancedGrid = new dojox.grid.EnhancedGrid(gridParams, this.enhancedGridNode);
			dojo.connect(this, "resize",this.enhancedGrid, "resize");
			
			var selectIcon = new dijit.form.Button({
				id: this.id+"selectAllIcon",
				showLabel: false,
				iconClass: "selectAllIcon",
				label: this.resources_.SELECT_ALL
			},this.selectAllButton);
				
			selectIcon.onClick = dojo.hitch (this, "onSelectAll");
			selectIcon.onKeypress = dojo.hitch (this, "onSelectAll");		
			
			var deSelectIcon = new dijit.form.Button({
				id: this.id+"deselectAllIcon",
				showLabel: false,
				iconClass: "deselectAllIcon",
				label: this.resources_.DESELECT_ALL
			},this.deselectAllButton);
				
			deSelectIcon.onClick = dojo.hitch (this, "onDeselectAll");
			deSelectIcon.onKeypress = dojo.hitch (this, "onDeselectAll");
				
			//this.enhancedGrid.setSortIndex('1', true);
			//Satanik:25May2011: changes made to address ILMT requiremnt 19890
			if(this.enableColumnReorder){
				var upIcon = new dijit.form.Button({
					id: this.id+"upIcon",
					showLabel: false,
					iconClass: "upIcon",
					label: this.resources_.UP
				},this.upButton);
					
				upIcon.onClick = dojo.hitch (this, "onUp");
				upIcon.onKeypress = dojo.hitch (this, "onUp");		
				
				var downIcon = new dijit.form.Button({
					id: this.id+"downIcon",
					showLabel: false,
					iconClass: "downIcon",
					label: this.resources_.DOWN
				},this.downButton);
					
				downIcon.onClick = dojo.hitch (this, "onDown");
				downIcon.onKeypress = dojo.hitch (this, "onDown");
			}else {
				dojo.style(this.upButton.parentNode, "width", "0px");
				dojo.style(this.downButton.parentNode, "width", "0px");
			}
			/*LS - 12/11/2011 - Opening and closing of Configure columns dialog results in dijit.registry to grow */
			//this change was made to make sure destroy is called even when dialog's close button is hit
			this.connect(this.dialog, "onHide",dojo.hitch (this, this.kill));
			
		},		
		
		onSelectAll: function(){
		//summary: selects all the column shown in the ConfigureColumnsDialog		
			var rowCount = this.enhancedGrid.rowCount;
			for (var i = 0; i < rowCount; i++) {
				columndata.items[i].hidden[0]=true;
			}
			this.enhancedGrid._refresh();	
		},	
		
		onDeselectAll: function(){		
		//summary: deselects all the column shown in the ConfigureColumnsDialog
			var rowCount = this.enhancedGrid.rowCount;
			for (var i = 0; i < rowCount; i++) {
				columndata.items[i].hidden[0]=false;
			}
			this.enhancedGrid._refresh();
		},
		
		/*Satanik:09May2011: This is not required any more*/
		/*Satanik:12May2011: This code is needed for the up/down arrow with current impl will review and refactor later */
		_reorderColumn: function(indirectSelection){
			var rowCount = this.enhancedGrid.rowCount;
			var columns=this.grid.structure;
			var reorderedcolumn=new Array();
			if(this.indirectSelection){
				reorderedcolumn[0]=columns[0];
				reorderedcolumn[1]=columns[1];
				for (var i = 0; i < rowCount; i++) {
					var selectedrow=this.enhancedGrid.getItem(i);
					for (var j = 0; j < rowCount+2; j++) {
						if(selectedrow.name[0] === columns[j].name){
							reorderedcolumn[i+2]=columns[j];
						}
					}
				}
			}else {
				reorderedcolumn[0]=columns[0];
				for (var i = 0; i < rowCount; i++) {
					var selectedrow=this.enhancedGrid.getItem(i);
					for (var j = 0; j < rowCount+1; j++) {
						if(selectedrow.name[0] === columns[j].name){
							reorderedcolumn[i+1]=columns[j];
						}
					}
				}
			}
			this.grid.setStructure(reorderedcolumn);
			//Satanik:12May2011: ILMT requested this to be removed as this is not required.
			//this.grid._refresh();
		},
		
		onOK: function () {
			//this.optionsWidget_.onSave();
			var rowCount = this.enhancedGrid.rowCount;
			this._reorderColumn();
			//console.dir(columndata.items);
			if(this.indirectSelection){
				for (var i = 0; i < rowCount; i++) {
						//if(this.enhancedGrid.selection.selected[i] !== true){
						if(columndata.items[i].hidden[0] == false){
							this.grid.layout.setColumnVisibility(i+2, false);
						} else{
							this.grid.layout.setColumnVisibility(i+2, true);
						}
				}
			}else{
				for (var i = 0; i < rowCount; i++) {
						//if(this.enhancedGrid.selection.selected[i] !== false){
						if(columndata.items[i].hidden[0] == false){
							this.grid.layout.setColumnVisibility(i+1, false);
						} else{
							this.grid.layout.setColumnVisibility(i+1, true);
						}
				}
			}
			this.hide();
		},
		
		onCancel: function () {
			this.hide();
		},		
		
		clearSelection: function () {
			this.enhancedGrid.selection.clear();
		},			
		
		onUp: function () {
			//console.log("onUp");
			//console.dir(this.enhancedGrid.selection.getSelected());
			//console.log("selectedIndex:"+this.enhancedGrid.selection.selectedIndex);
			//console.dir(columndata.items);
			var selectedIndex = this.enhancedGrid.selection.selectedIndex;
			if(selectedIndex <= 0) return;
			var itemsNew = new Array();
			//console.log("columndata.items.length:"+columndata.items.length);
			if (selectedIndex-1 >= 0)
				itemsNew = itemsNew.concat(columndata.items.slice(0,selectedIndex-1));
			itemsNew = itemsNew.concat(this.enhancedGrid.selection.getSelected());
			if (selectedIndex-1 >= 0)
				itemsNew.push(columndata.items[selectedIndex-1]);				
			itemsNew = itemsNew.concat(columndata.items.slice(selectedIndex+1, columndata.items.length));				
			this.enhancedGrid.store.close();
			columndata.items = itemsNew;
			//console.dir(columndata.items);
			this.enhancedGrid.store = new dojo.data.ItemFileWriteStore({data:columndata});
			this.enhancedGrid.selection.clear();
			//24425: In TreeTable Configure Columns popup, A column disappears from the list we try to change the position of column.
			//Satanik:13Jul11 - Selection is not correctly retained on refresh in latest grid, so doing after refresh		
			//this.enhancedGrid.selection.addToSelection(selectedIndex-1);
			this.enhancedGrid._refresh();
			this.enhancedGrid.selection.addToSelection(selectedIndex-1);
		},	

		onDown: function () {
			//console.log("onDown");
			var selectedIndex = this.enhancedGrid.selection.selectedIndex;
			if(selectedIndex < 0) return;
			if(selectedIndex == columndata.items.length-1) return;
			var itemsNew = new Array();
			//console.log("selectedIndex:"+selectedIndex);
			//console.log("columndata.items.length:"+columndata.items.length);
			//console.dir(columndata.items);
			itemsNew = itemsNew.concat(columndata.items.slice(0,selectedIndex));
			if(columndata.items[selectedIndex+1] !== 'undefined')
				itemsNew.push(columndata.items[selectedIndex+1]);			
			itemsNew = itemsNew.concat(this.enhancedGrid.selection.getSelected());
			if(columndata.items[selectedIndex+2] !== 'undefined')
				itemsNew = itemsNew.concat(columndata.items.slice(selectedIndex+2, columndata.items.length));				
			this.enhancedGrid.store.close();
			columndata.items = itemsNew;
			//console.dir(columndata.items);
			this.enhancedGrid.store = new dojo.data.ItemFileWriteStore({data:columndata});
			this.enhancedGrid.selection.clear();
			//24425: In TreeTable Configure Columns popup, A column disappears from the list we try to change the position of column.
			//Satanik:13Jul11  - Selection is not correctly retained on refresh in latest grid, so doing after refresh
			//this.enhancedGrid.selection.addToSelection(selectedIndex+1);
			this.enhancedGrid._refresh();			
			this.enhancedGrid.selection.addToSelection(selectedIndex+1);
		},			
		
		_selectColumns: function(){
			var rowCount = this.enhancedGrid.rowCount;
			for (var i = 0; i < rowCount; i++) {
				var selectedrow=this.enhancedGrid.getItem(i);
				if(selectedrow.hidden[0] === false){
					//this.enhancedGrid.rowSelectCell.toggleRow(selectedrow, true);
					this.enhancedGrid.selection.addToSelection(i);
				}
			}    
		},
		
		show: function () {
			this.dialog.show();
			this.enhancedGrid.startup();
			//this._selectColumns();
			dijit.byId (this.id + "tabs").resize();
		},
		
		hide: function () {
			/*LS - 12/11/2011 - Opening and closing of Configure columns dialog results in dijit.registry to grow */
			//just hide the dialog the destroy would take place with a connect to onhide of dijit.dialog 
			//this change was made to make sure destroy is called even when dialog's close button is hit
			this.dialog.hide();
		},	
		
		kill: function () {
		/*LS - 12/11/2011 - Opening and closing of Configure columns dialog results in dijit.registry to grow */
		//call destroy to completely destroy the widget...
			/*var id = this.id;
			var dId=this.dialog.id;
			this.dialog.destroyRecursive();
			dijit.registry.remove (dId);
			this.destroyRecursive();
			dijit.registry.remove (id);*/
			setTimeout (dojo.hitch (this, this.destroy), 100);
		},
		
		getTableOptions: function () {
			return this.optionsWidget_;
		},
		
		destroy: function(){
			// summary:  Destroys the toolbar.
			// tags: public	
			//memory leak issue: custom destroy method to take care of removing all widgets					
			try{
				delete this.resources_;
				//this is for destroying child templated widgets 
				//this should happen by itself but need to figure out why dijit._Templated is not taking care of it...
				/*LS - 12/11/2011 - Opening and closing of Configure columns dialog results in dijit.registry to grow */
				//destroy the dialog and bordercontainer separately as template is not finding it properly
				//this must be a bug with bordercontainer in template it needs to be destroyed separately
				var dijitDialog = dijit.byId(this.dialog);
				var borderContID = this.id +'tabs';
				var borderContainer = dijit.byId(borderContID );
				if(borderContainer)borderContainer.destroyRecursive();
				if(dijitDialog)dijitDialog.destroyRecursive();
				var widgets = dijit.findWidgets(this.domNode);
				dojo.forEach(widgets, function(w) {
					if(w){
						if(w.destroyRecursive){
							w.destroyRecursive();
						} else if(w.destroy){
							w.destroy();
						}
					}
				});
				// this is for widgets added as child to this widget and their children..
				//not present in template
				var widgetArr = this.getChildren();
				dojo.forEach(widgetArr, function (child) {
					if(child){
						if(child.destroyRecursive){
							child.destroyRecursive();
						} else if(child.destroy){
							child.destroy();
						}
					}
				});
				this.inherited(arguments);
			}catch(ex){
				console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
			}
		}
	}
);

}
