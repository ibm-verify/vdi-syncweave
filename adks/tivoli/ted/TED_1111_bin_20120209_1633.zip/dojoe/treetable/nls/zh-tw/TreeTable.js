/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"快速過濾器","DESELECT_ALL":"取消全選","COLUMNS_VISIBLE":"指出哪些直欄可見：","REFRESH":"重新整理","DOWN":"下移","CONFIGURE_TREETABLE":"配置選項","VISIBLE":"可見","COLUMNS":"直欄","COLLAPSE_ALL":"全部收合","PROCESSING":"處理中...","EXPAND_ALL":"全部展開","CLEAR_SORT":"清除排序","NO_DATA":"沒有資料可供顯示","SELECT_ALL":"全選","CLEAR_FILTER":"清除過濾器","OK":"確定","QF_DEFAULT_TEXT":"過濾器","UP":"向上","CANCEL":"取消","ACTIONS":"動作"})