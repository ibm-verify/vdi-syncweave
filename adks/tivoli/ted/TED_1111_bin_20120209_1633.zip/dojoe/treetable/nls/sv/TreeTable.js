/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Snabbfilter","DESELECT_ALL":"Avmarkera alla","COLUMNS_VISIBLE":"Ange vilka kolumner som ska vara synliga:","REFRESH":"Uppdatera","DOWN":"Ned","CONFIGURE_TREETABLE":"Konfigurera alternativ","VISIBLE":"Synligt","COLUMNS":"Kolumner","COLLAPSE_ALL":"Komprimera alla","PROCESSING":"Bearbetar...","EXPAND_ALL":"Expandera alla","CLEAR_SORT":"Ta bort sortering","NO_DATA":"Det finns inga data att visa","SELECT_ALL":"Markera alla","CLEAR_FILTER":"Rensa filter","OK":"OK","QF_DEFAULT_TEXT":"Filter","UP":"Upp","CANCEL":"Avbryt","ACTIONS":"Åtgärder"})