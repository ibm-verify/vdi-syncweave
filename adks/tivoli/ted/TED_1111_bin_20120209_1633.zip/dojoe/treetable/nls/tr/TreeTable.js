/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Hızlı Süzgeç","DESELECT_ALL":"Tüm Seçimi Kaldır","COLUMNS_VISIBLE":"Hangi sütunlarının görünür olacağını belirtin:","REFRESH":"Yenile","DOWN":"Aşağı","CONFIGURE_TREETABLE":"Seçenekleri Yapılandır","VISIBLE":"Görünür","COLUMNS":"Sütunlar","COLLAPSE_ALL":"Tümünü Daralt","PROCESSING":"İşleniyor...","EXPAND_ALL":"Tümünü Genişlet","CLEAR_SORT":"Sıralamayı Kaldır","NO_DATA":"Görüntülenecek veri yok.","SELECT_ALL":"Tümünü Seç","CLEAR_FILTER":"Süzgeci Kaldır","OK":"Tamam","QF_DEFAULT_TEXT":"Süzgeç","UP":"Yukarı","CANCEL":"İptal","ACTIONS":"İşlemler"})