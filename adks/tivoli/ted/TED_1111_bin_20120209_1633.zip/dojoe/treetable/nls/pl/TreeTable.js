/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Szybki filtr","DESELECT_ALL":"Anuluj wybór wszystkiego","COLUMNS_VISIBLE":"Określ, które kolumny mają być widoczne:","REFRESH":"Odśwież","DOWN":"W dół","CONFIGURE_TREETABLE":"Konfigurowanie opcji","VISIBLE":"Widoczna","COLUMNS":"Kolumny","COLLAPSE_ALL":"Zwiń wszystko","PROCESSING":"Przetwarzanie...","EXPAND_ALL":"Rozwiń wszystko","CLEAR_SORT":"Wyczyść sortowanie","NO_DATA":"Brak danych do wyświetlenia","SELECT_ALL":"Wybierz wszystko","CLEAR_FILTER":"Wyczyść filtr","OK":"OK","QF_DEFAULT_TEXT":"Filtr","UP":"W górę","CANCEL":"Anuluj","ACTIONS":"Działania"})