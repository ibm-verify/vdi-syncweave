/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Hurtigfilter","DESELECT_ALL":"Opphev valg av alle","COLUMNS_VISIBLE":"Oppgi hvilke kolonner som er synlige:","REFRESH":"Oppdater","DOWN":"Ned","CONFIGURE_TREETABLE":"Konfigurer alternativer","VISIBLE":"Synlig","COLUMNS":"Kolonner","COLLAPSE_ALL":"Komprimer alle","PROCESSING":"Behandler...","EXPAND_ALL":"Utvid alle","CLEAR_SORT":"Fjern sortering","NO_DATA":"Ingen data å vise","SELECT_ALL":"Velg alle","CLEAR_FILTER":"Tøm filter","OK":"OK","QF_DEFAULT_TEXT":"Filter","UP":"Opp","CANCEL":"Avbryt","ACTIONS":"Handlinger"})