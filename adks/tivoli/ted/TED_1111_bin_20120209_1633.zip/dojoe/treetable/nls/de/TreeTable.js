/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Schnellfilter","DESELECT_ALL":"Alles abwählen","COLUMNS_VISIBLE":"Angeben, welche Spalten sichtbar sind:","REFRESH":"Aktualisieren","DOWN":"Nach unten","CONFIGURE_TREETABLE":"Konfigurationsoptionen","VISIBLE":"Sichtbar","COLUMNS":"Spalten","COLLAPSE_ALL":"Alles ausblenden","PROCESSING":"Verarbeitung läuft...","EXPAND_ALL":"Alles einblenden","CLEAR_SORT":"Sortierung aufheben","NO_DATA":"Keine Daten zum Anzeigen vorhanden","SELECT_ALL":"Alles auswählen","CLEAR_FILTER":"Filter aufheben","OK":"OK","QF_DEFAULT_TEXT":"Filtern","UP":"Nach oben","CANCEL":"Abbrechen","ACTIONS":"Aktionen"})