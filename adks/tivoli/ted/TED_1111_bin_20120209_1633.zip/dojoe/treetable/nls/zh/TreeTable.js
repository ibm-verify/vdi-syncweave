/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"快速过滤器","DESELECT_ALL":"取消所有选择","COLUMNS_VISIBLE":"表明哪些列是可见的：","REFRESH":"刷新","DOWN":"向下","CONFIGURE_TREETABLE":"配置选项","VISIBLE":"可视","COLUMNS":"列","COLLAPSE_ALL":"全部折叠","PROCESSING":"正在处理...","EXPAND_ALL":"全部展开","CLEAR_SORT":"清除排序","NO_DATA":"没有要显示的数据","SELECT_ALL":"选择全部","CLEAR_FILTER":"清除过滤器","OK":"确定","QF_DEFAULT_TEXT":"过滤器","UP":"向上","CANCEL":"取消","ACTIONS":"操作"})