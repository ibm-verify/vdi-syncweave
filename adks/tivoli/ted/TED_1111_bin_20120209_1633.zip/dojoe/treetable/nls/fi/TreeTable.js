/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Pikasuodatin","DESELECT_ALL":"Poista kaikkien valinta","COLUMNS_VISIBLE":"Määritä, mitkä sarakkeet ovat näkyvissä:","REFRESH":"Päivitä","DOWN":"Alas","CONFIGURE_TREETABLE":"Määritä asetukset","VISIBLE":"Näkyvä","COLUMNS":"Sarakkeet","COLLAPSE_ALL":"Pienennä kaikki","PROCESSING":"Käsittely meneillään...","EXPAND_ALL":"Laajenna kaikki","CLEAR_SORT":"Tyhjennä lajittelu","NO_DATA":"Ei tietoja esitettäväksi","SELECT_ALL":"Valitse kaikki","CLEAR_FILTER":"Tyhjennä suodatin","OK":"OK","QF_DEFAULT_TEXT":"Suodatin","UP":"Ylös","CANCEL":"Peruuta","ACTIONS":"Toiminnot"})