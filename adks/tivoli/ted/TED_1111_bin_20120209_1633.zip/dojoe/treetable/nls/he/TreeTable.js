/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"סינון מהיר","DESELECT_ALL":"ביטול בחירת הכל","COLUMNS_VISIBLE":"ציון עמודות גלויות:","REFRESH":"רענון","DOWN":"למטה","CONFIGURE_TREETABLE":"אפשרויות קביעת תצורה","VISIBLE":"גלוי","COLUMNS":"עמודות","COLLAPSE_ALL":"צמצום הכל","PROCESSING":"מעבד...","EXPAND_ALL":"הרחבת הכל","CLEAR_SORT":"ניקוי מיון","NO_DATA":"אין נתונים להצגה","SELECT_ALL":"בחירת הכל","CLEAR_FILTER":"ניקוי מסנן","OK":"אישור","QF_DEFAULT_TEXT":"מסנן","UP":"למעלה","CANCEL":"ביטול","ACTIONS":"פעולות"})