/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Filtro Rápido","DESELECT_ALL":"Desmarcar Tudo","COLUMNS_VISIBLE":"Indicar quais colunas são visíveis:","REFRESH":"Atualizar","DOWN":"Para Baixo","CONFIGURE_TREETABLE":"Configurar Opções","VISIBLE":"Visível","COLUMNS":"Colunas","COLLAPSE_ALL":"Reduzir Tudo","PROCESSING":"Processando...","EXPAND_ALL":"Expandir Tudo","CLEAR_SORT":"Limpar a Classificação","NO_DATA":"Nenhum dado para exibir","SELECT_ALL":"Selecionar Tudo","CLEAR_FILTER":"Limpar Filtro","OK":"OK","QF_DEFAULT_TEXT":"Filtrar","UP":"Para Cima","CANCEL":"Cancelar","ACTIONS":"Ações"})