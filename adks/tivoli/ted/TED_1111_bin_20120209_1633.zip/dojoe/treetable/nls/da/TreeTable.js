/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Kvikfilter","DESELECT_ALL":"Ophæv markering af alle","COLUMNS_VISIBLE":"Angiv, hvilke kolonner der er synlige:","REFRESH":"Opfrisk","DOWN":"Ned","CONFIGURE_TREETABLE":"Konfigurér indstillinger","VISIBLE":"Synlig","COLUMNS":"Kolonner","COLLAPSE_ALL":"Skjul alle","PROCESSING":"Behandler...","EXPAND_ALL":"Udvid alle","CLEAR_SORT":"Ryd sortering","NO_DATA":"Ingen data at vise","SELECT_ALL":"Markér alle","CLEAR_FILTER":"Ryd filter","OK":"OK","QF_DEFAULT_TEXT":"Filter","UP":"Op","CANCEL":"Annullér","ACTIONS":"Handlinger"})