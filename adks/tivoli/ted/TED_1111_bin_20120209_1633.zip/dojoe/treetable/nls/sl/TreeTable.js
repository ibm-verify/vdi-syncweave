/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Hitri filter","DESELECT_ALL":"Razveljavi izbiro vseh","COLUMNS_VISIBLE":"Navedite katere so vidne kolone:","REFRESH":"Osveži","DOWN":"Dol","CONFIGURE_TREETABLE":"Konfiguriraj možnosti","VISIBLE":"Viden","COLUMNS":"Stolpci","COLLAPSE_ALL":"Strni vse","PROCESSING":"Obdelava...","EXPAND_ALL":"Razširi vse","CLEAR_SORT":"Počisti razvrščanje","NO_DATA":"Ni podatkov za prikaz","SELECT_ALL":"Izberi vse","CLEAR_FILTER":"Počisti filter","OK":"V redu","QF_DEFAULT_TEXT":"Filter","UP":"Gor","CANCEL":"Prekliči","ACTIONS":"Dejanja"})