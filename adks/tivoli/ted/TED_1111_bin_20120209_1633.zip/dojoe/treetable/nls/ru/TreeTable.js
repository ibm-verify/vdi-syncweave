/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Экспресс-фильтр","DESELECT_ALL":"Отменить выбор для всех","COLUMNS_VISIBLE":"Укажите, какие столбцы будут видимы:","REFRESH":"Обновить","DOWN":"Вниз","CONFIGURE_TREETABLE":"Сконфигурировать опции","VISIBLE":"Видимый","COLUMNS":"Вертикальная столбчатая диаграмма","COLLAPSE_ALL":"Свернуть все","PROCESSING":"Выполняется обработка...","EXPAND_ALL":"Раскрыть все","CLEAR_SORT":"Отменить сортировку","NO_DATA":"Нет данных для показа","SELECT_ALL":"Выбрать все","CLEAR_FILTER":"Удалить фильтр","OK":"ОК","QF_DEFAULT_TEXT":"Фильтр","UP":"Вверх","CANCEL":"Отмена","ACTIONS":"Действия"})