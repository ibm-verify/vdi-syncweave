/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Gyorsszűrő","DESELECT_ALL":"Kijelölések megszüntetése","COLUMNS_VISIBLE":"Adja meg, hogy mely oszlopok legyenek láthatók:","REFRESH":"Frissítés","DOWN":"Le","CONFIGURE_TREETABLE":"Beállítások megadása","VISIBLE":"Látható","COLUMNS":"Oszlopok","COLLAPSE_ALL":"Összes összehúzása","PROCESSING":"Feldolgozás...","EXPAND_ALL":"Összes kibontása","CLEAR_SORT":"Rendezés törlése","NO_DATA":"Nincsenek megjeleníthető adatok.","SELECT_ALL":"Mindent kijelöl","CLEAR_FILTER":"Szűrő törlése","OK":"OK","QF_DEFAULT_TEXT":"Szűrő","UP":"Fel","CANCEL":"Mégse","ACTIONS":"Műveletek"})