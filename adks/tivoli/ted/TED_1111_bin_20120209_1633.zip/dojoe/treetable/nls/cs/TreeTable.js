/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Rychlý filtr","DESELECT_ALL":"Zrušit veškerý výběr","COLUMNS_VISIBLE":"Označte, které sloupce jsou viditelné:","REFRESH":"Obnovit","DOWN":"Dolů","CONFIGURE_TREETABLE":"Konfigurovat volby","VISIBLE":"Viditelná","COLUMNS":"Sloupce","COLLAPSE_ALL":"Sbalit vše","PROCESSING":"Probíhá zpracování...","EXPAND_ALL":"Rozbalit vše","CLEAR_SORT":"Vymazat řazení","NO_DATA":"Nejsou žádná data k zobrazení.","SELECT_ALL":"Vybrat vše","CLEAR_FILTER":"Vymazat filtr","OK":"OK","QF_DEFAULT_TEXT":"Filtr","UP":"Nahoru","CANCEL":"Storno","ACTIONS":"Akce"})