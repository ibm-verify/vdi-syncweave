/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Filtre rapide","DESELECT_ALL":"Tout désélectionner","COLUMNS_VISIBLE":"Indiquer les colonnes visibles :","REFRESH":"Actualiser","DOWN":"Vers le bas","CONFIGURE_TREETABLE":"Configurer les options","VISIBLE":"Visible","COLUMNS":"Colonnes","COLLAPSE_ALL":"Tout réduire","PROCESSING":"Traitement en cours...","EXPAND_ALL":"Tout développer","CLEAR_SORT":"Effacer le tri","NO_DATA":"Pas de données à afficher","SELECT_ALL":"Tout sélectionner","CLEAR_FILTER":"Effacer le filtre","OK":"OK","QF_DEFAULT_TEXT":"Filtrer","UP":"Vers le haut","CANCEL":"Annuler","ACTIONS":"Actions"})