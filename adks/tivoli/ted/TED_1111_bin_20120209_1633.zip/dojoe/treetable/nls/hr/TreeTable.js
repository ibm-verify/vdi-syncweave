/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Brzi filter","DESELECT_ALL":"Odznači sve","COLUMNS_VISIBLE":"Označi vidljive stupce:","REFRESH":"Osvježi","DOWN":"Dolje","CONFIGURE_TREETABLE":"Konfiguriraj opcije","VISIBLE":"Vidljivo","COLUMNS":"Stupci","COLLAPSE_ALL":"Sruši sve","PROCESSING":"Obrada...","EXPAND_ALL":"Proširi sve","CLEAR_SORT":"Obriši sort","NO_DATA":"Nema podataka za prikaz","SELECT_ALL":"Izaberi sve","CLEAR_FILTER":"Brisanje filtera","OK":"OK","QF_DEFAULT_TEXT":"Filter","UP":"Gore","CANCEL":"Opoziv","ACTIONS":"Akcije"})