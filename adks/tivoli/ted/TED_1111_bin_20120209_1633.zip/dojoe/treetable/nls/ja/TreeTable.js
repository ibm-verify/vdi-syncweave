/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"クイック・フィルター","DESELECT_ALL":"選択をすべて解除","COLUMNS_VISIBLE":"表示される列を指定します:","REFRESH":"リフレッシュ","DOWN":"下へ移動","CONFIGURE_TREETABLE":"オプションの構成","VISIBLE":"表示","COLUMNS":"列","COLLAPSE_ALL":"すべて縮小","PROCESSING":"処理中...","EXPAND_ALL":"すべて展開","CLEAR_SORT":"ソートのクリア","NO_DATA":"表示するデータがありません","SELECT_ALL":"すべて選択","CLEAR_FILTER":"フィルターのクリア","OK":"OK","QF_DEFAULT_TEXT":"フィルター","UP":"上へ移動","CANCEL":"キャンセル","ACTIONS":"アクション"})