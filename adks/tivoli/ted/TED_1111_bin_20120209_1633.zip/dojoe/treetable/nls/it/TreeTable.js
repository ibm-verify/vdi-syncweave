/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Filtro rapido","DESELECT_ALL":"Deseleziona tutto","COLUMNS_VISIBLE":"Indicare quali colonne sono visibili:","REFRESH":"Aggiorna","DOWN":"Giù","CONFIGURE_TREETABLE":"Configura opzioni","VISIBLE":"Visibile","COLUMNS":"Colonne","COLLAPSE_ALL":"Comprimi tutto","PROCESSING":"Elaborazione in corso...","EXPAND_ALL":"Espandi tutto","CLEAR_SORT":"Cancella ordinamento","NO_DATA":"Nessun dato da visualizzare","SELECT_ALL":"Seleziona tutto","CLEAR_FILTER":"Cancella filtro","OK":"OK","QF_DEFAULT_TEXT":"Filtro","UP":"Su","CANCEL":"Annulla","ACTIONS":"Azioni"})