/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Quick Filter","DESELECT_ALL":"Deselect All","COLUMNS_VISIBLE":"Indicate which columns are visible:","REFRESH":"Refresh","DOWN":"Down","CONFIGURE_TREETABLE":"Configure Options","VISIBLE":"Visible","COLUMNS":"Columns","COLLAPSE_ALL":"Collapse All","PROCESSING":"Processing...","EXPAND_ALL":"Expand All","CLEAR_SORT":"Clear Sort","NO_DATA":"No data to display","SELECT_ALL":"Select All","CLEAR_FILTER":"Clear Filter","OK":"OK","QF_DEFAULT_TEXT":"Filter","UP":"Up","CANCEL":"Cancel","ACTIONS":"Actions"})