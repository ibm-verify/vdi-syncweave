/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"ترشيح بيانات سريع","DESELECT_ALL":"الغاء تحديد كل","COLUMNS_VISIBLE":"الاشارة الى الأعمدة المرئية:","REFRESH":"تجديد","DOWN":"أسفل","CONFIGURE_TREETABLE":"توصيف الاختيارات","VISIBLE":"مرئي","COLUMNS":"أعمدة","COLLAPSE_ALL":"طي  كل","PROCESSING":"تشغيل...","EXPAND_ALL":"عرض كل","CLEAR_SORT":"محو الفرز","NO_DATA":"لا توجد بيانات ليتم عرضها","SELECT_ALL":"تحديد كل","CLEAR_FILTER":"محو ترشيح البيانات","OK":"حسنا","QF_DEFAULT_TEXT":"ترشيح البيانات","UP":"أعلى","CANCEL":"الغاء","ACTIONS":"التصرفات"})