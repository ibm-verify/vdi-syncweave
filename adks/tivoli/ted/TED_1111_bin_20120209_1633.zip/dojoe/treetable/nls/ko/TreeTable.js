/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"빠른 필터","DESELECT_ALL":"모두 선택 취소","COLUMNS_VISIBLE":"볼 수 있는 컬럼 표시:","REFRESH":"새로 고치기","DOWN":"아래로","CONFIGURE_TREETABLE":"선택사항 구성","VISIBLE":"표시 가능","COLUMNS":"컬럼","COLLAPSE_ALL":"모두 접기","PROCESSING":"처리 중...","EXPAND_ALL":"모두 펼치기","CLEAR_SORT":"정렬 지우기","NO_DATA":"표시할 데이터 없음","SELECT_ALL":"모두 선택","CLEAR_FILTER":"필터 지우기","OK":"확인","QF_DEFAULT_TEXT":"필터","UP":"위로","CANCEL":"취소","ACTIONS":"조치"})