/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"QUICK_FILTER":"Snelfilter","DESELECT_ALL":"Alle selecties opheffen","COLUMNS_VISIBLE":"Geef aan welke kolommen zichtbaar zijn:","REFRESH":"Vernieuwen","DOWN":"Omlaag","CONFIGURE_TREETABLE":"Opties configureren","VISIBLE":"Zichtbaar","COLUMNS":"Kolommen","COLLAPSE_ALL":"Geen onderliggende niveaus","PROCESSING":"Verwerken...","EXPAND_ALL":"Alles uitvouwen","CLEAR_SORT":"Sortering opheffen","NO_DATA":"Geen gegevens om af te beelden","SELECT_ALL":"Alles selecteren","CLEAR_FILTER":"Filter wissen","OK":"OK","QF_DEFAULT_TEXT":"Filter","UP":"Omhoog","CANCEL":"Annuleren","ACTIONS":"Acties"})