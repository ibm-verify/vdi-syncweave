/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.treetable._Toolbar"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.treetable._Toolbar"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
// dojo.provide allows pages to use all of the types declared in this resource.
dojo.provide("dojoe.treetable._Toolbar");

//dojo.require("dijit.Toolbar");
dojo.require("dijit.form.Button");
dojo.require("dijit.ToolbarSeparator");
dojo.require("dijit.form.DropDownButton");
//dojo.require("dijit.form.TextBox");
dojo.require("dijit.Menu");
dojo.require("dojo.i18n");
dojo.require("dojoe.treetable._ConfigureColumnsDialog");
dojo.require("dojoe.treetable._QuickSearchFilter");

dojo.requireLocalization("dojoe.treetable", "TreeTable", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");

dojo.declare("dojoe.treetable._Toolbar", [ dijit._Widget, dijit._Templated], {	
		templateString:dojo.cache("dojoe.treetable", "templates/Toolbar.html", "<div dojoAttachEvent='oncontextmenu:_stopEvent' class=\"tivTable dijitToolbar\"  width=\"100%\" >\r\n<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" role=\"presentation\">\r\n\t<tbody>\r\n\t\t<tr valign=\"center\">\r\n\t\t\t<td width=\"80%\" height=\"100%\">\r\n\t\t\t\t<span dojoAttachPoint=\"toolbarFirstRow\"><span dojoAttachPoint=\"refreshNode\" role=\"button\"></span><span dojoAttachPoint=\"refSeperator\" role=\"separator\"></span><span dojoAttachPoint=\"toolbarFirstRow_userItems\"></span><span dojoAttachPoint=\"selectAllIcon\" role=\"button\"></span><span dojoAttachPoint=\"deselectAllIcon\" role=\"button\"></span><span dojoAttachPoint=\"expandtAllIcon\" role=\"button\"></span><span dojoAttachPoint=\"collapseAllIcon\" role=\"button\"></span><span dojoAttachPoint=\"removeSortIcon\" role=\"button\"></span><span dojoAttachPoint=\"configureColNode\" role=\"button\"></span><span dojoAttachPoint=\"actionListNode\" role=\"button\"></span></span>\r\n\t\t\t</td>\r\n\t\t\t<td width=\"20%\" height=\"100%\" align=\"right\"><div dojoAttachPoint=\"quickFilterNode\" role=\"search\"></div></td>\r\n\t\t\t<td><div dojoAttachPoint=\"filterNode\" role=\"button\"></div></td>\r\n\t\t</tr>\r\n\t\t<tr valign=\"center\">\r\n\t\t\t<td width=\"100%\">\r\n\t\t\t\t<span dojoAttachPoint=\"toolbarSecondRow\">\r\n\t\t\t\t</span>\t\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t</tbody>\t\t\r\n</table>\r\n</div>\r\n"),

		widgetsInTemplate:true,
		//toolbar:null,
		treeTable:null,
		actionListWidget:null,
		quickFilter:null,
		filterOptions: null,
		
		refreshIcon:true,
		refreshMenu:true,
		showSelectAllIcon:true,
		onlySelectAllIcon:false,
		onlyDeselectAllIcon:false,
		expandAllIcon: true,
		clearSortIcon: true,
		configureTreeTableIcon:true,
			
		actionMenu:true,
		selectAllMenu: true,
		expandAllMenu : true,
		clearSortMenu: true,
		configureTreeTableMenu:true,
		toolbarOptions : null,
		quickFilterVisible : true,
		showQuickFilterButton: false,		
	
		_mapToolbarControls : function() {
			
			if(this.toolbarOptions) {
				if(this.toolbarOptions.refreshIcon == false){
					this.refreshIcon = this.toolbarOptions.refreshIcon;
				}
				//23789: Refresh should be part of Actions Menu also - OID
				//Bobby:29Jun11
				if(this.toolbarOptions.refreshMenu == false){
					this.refreshMenu = this.toolbarOptions.refreshMenu;
				}				
				if(this.toolbarOptions.selectAllIcon == false){
					this.showSelectAllIcon = this.toolbarOptions.selectAllIcon;
					
				}else{
					if(this.toolbarOptions.onlySelectAllIcon == true){
						this.onlySelectAllIcon=this.toolbarOptions.onlySelectAllIcon;
					}
					if(this.toolbarOptions.onlyDeselectAllIcon == true){
						this.onlyDeselectAllIcon=this.toolbarOptions.onlyDeselectAllIcon;
					}
				}
				if(this.toolbarOptions.selectAllMenu == false){
					this.selectAllMenu = this.toolbarOptions.selectAllMenu;
				}				
				//Only collapseAll is supported in TED 1.1 and TED 1.0.
				if(this.toolbarOptions.expandAllIcon == false){
					this.expandAllIcon = this.toolbarOptions.expandAllIcon;
				}
				if(this.toolbarOptions.expandAllMenu == false){
					this.expandAllMenu = this.toolbarOptions.expandAllMenu;
				}
				
				if(this.toolbarOptions.clearSortIcon == false){
					this.clearSortIcon = this.toolbarOptions.clearSortIcon;
				}
				if(this.toolbarOptions.clearSortMenu == false){
					this.clearSortMenu = this.toolbarOptions.clearSortMenu;
				}
				if(this.toolbarOptions.configureTreeTableIcon == false) 
				{
					this.configureTreeTableIcon = this.toolbarOptions.configureTreeTableIcon;
				}
				if(this.toolbarOptions.configureTreeTableMenu == false){
					this.configureTreeTableMenu = this.toolbarOptions.configureTreeTableMenu;
				}
				if(this.toolbarOptions.actionMenu == false){
					this.actionMenu = this.toolbarOptions.actionMenu;
				}				
				//Keep for backward compatibility?
				//console.log('_mapToolbarControls: this.toolbarOptions.quickFilterVisible:'+this.toolbarOptions.quickFilterVisible);
				if(this.toolbarOptions.quickFilterVisible == false){
					this.quickFilterVisible = this.toolbarOptions.quickFilterVisible;
				}	
				//LS- 26/10/2011 - # 30377 - Treetable - incorrect results when setting filter or sorting while data is being loaded
				//this was missed in mapping
				if(this.toolbarOptions.quickFilterVisible && this.toolbarOptions.showQuickFilterButton){
					this.showQuickFilterButton = this.toolbarOptions.showQuickFilterButton;
				}
				//console.log('_mapToolbarControls: this.quickFilterVisible:'+this.quickFilterVisible);				
			}			
		},
		
		
		// Place comma-separated class attributes here. Note, instance attributes 
		// should be initialized in the constructor. Variables initialized here
		// will be treated as 'static' class variables.

		// Constructor function. Called when instance of this class is created
		constructor : function() {
			this.resources_ = dojo.i18n.getLocalization("dojoe.treetable", "TreeTable", this.lang);	
		},
		
		_refreshTreeTable: function(){
			/*LA - 09/01/2012 - TWL - 16212- TreeTable CURI refresh not clearing cache*/
			//setting forceRefresh true to clear the LTG cache so that data from stores is reloaded...
			this.treeTable.refresh(true);
		},
		
		_selectAll: function () 
		{
			if(this.treeTable.indirectSelection === true){
				//moving this to indirect selection class
				this.treeTable._loadIndSelection.selectAllRows();
			}else{
				var count = this.treeTable.grid.rowCount;
				for (var i=0; i<count; i++) {
					this.treeTable.grid.selection.addToSelection(i);
				}
			}
		},
		
		_deselectAll: function () 
		{
			if(this.treeTable.indirectSelection === true){
				this.treeTable._loadIndSelection.deSelectAllRows();
			}else{
				this.treeTable.grid.selection.deselectAll();
			}			
		},
		
		/* Not supported in the base widget, dojo LazyTreeGrid.
		_expandAll : function(){
			this.treeTable.grid.foldingAll(true);
		},
		*/
		_collapseAll : function()
		{
			//this.treeTable.grid.foldingAll(false);
			//Satanik:07Jun2011: changing the collapse all
			this.treeTable.grid._cleanup();
			/*Lakshmi - 15/07/2011 - 21173 - In Treetable, Collapse all is not working */
			//normal grid refresh solves this issue and even is suffice
			this.treeTable.grid._refresh(true);
		},
		
		_clearSort : function()
		{
			//LS - 21/10/2011 - #30979 - Clear sort does not work for treetable
			//since LTG refresh has changed adding cleanup before clear sort to make sure the applied sort is cleared.
			this.treeTable.grid._cleanup();
			this.treeTable.grid.setSortInfo(0);
			this.treeTable.grid._refresh(true);
		},
		
		_configureColumn : function()
		{ 
		//Satanik:25May2011: changes made to address ILMT requiremnt 19890
			this.tableOptionsDialog = new dojoe.treetable._ConfigureColumnsDialog ({ grid:this.treeTable.grid,indirectSelection:this.treeTable.indirectSelection,enableColumnReorder:this.treeTable.enableColumnReorder});
			this.tableOptionsDialog.show();
		},
		
		postCreate:function(){
			//this.inherited(arguments);
			//console.log("this.filterOptions:"+this.filterOptions);
			//console.dir(this.filterOptions);	
			//22694: Hiding the quickfilter in TreeTable toolbar doesn't work - Bjørn Stadheim
			//Bobby: 22Jun2011, correcting the validation below, undefined doesn't need quotes too.
			//Also changing filterOptions.quickFilter -> filterOptions.showQuickFilter to be consistent with Table
			if(this.filterOptions && this.filterOptions.showQuickFilter !== undefined){
				this.quickFilterVisible = this.filterOptions.showQuickFilter;
			}	
			if(this.filterOptions && this.filterOptions.showQuickFilterButton !== undefined){
				this.showQuickFilterButton = this.filterOptions.showQuickFilterButton;
			}			
			//console.log("postCreate: this.quickFilterVisible:"+this.quickFilterVisible);
			
			//commenting as this not required
			//this.toolbar = new dijit.Toolbar({id: "toolbar"+this.id});
			this.toolbarOptions = this.treeTable.toolbarOptions;
			this._mapToolbarControls();
			this._createToolBarControls();			
		},
		
		//16716: table toolbar has browser popup menu on right click
		_stopEvent: function(e){
			//Since event is oncontextmenu, just stop it!
			dojo.stopEvent(e);				
		},
		
		_createToolBarControls: function(){
			if(this.refreshIcon) {
				var refreshTableIcon = new dijit.form.Button({
					id: this.id+"refreshIcon",
					showLabel: false,
					iconClass: "refreshIcon",
					label: this.resources_.REFRESH
				},this.refreshNode);
					
				refreshTableIcon.onClick = dojo.hitch (this, "_refreshTreeTable");
				refreshTableIcon.onKeypress = dojo.hitch (this, "_refreshTreeTable");
				
				var refSeparator= new dijit.ToolbarSeparator({id: this.id+"refSeperator"},this.refSeperator);
			}
			else{
				dojo.style(this.refreshNode.parentNode, "width", "0px");
				dojo.style(this.refSeperator.parentNode, "width", "0px");
			}
			if(this.showSelectAllIcon) {	
				//Satanik:25May2011: changes made to address ILMT requiremnt of showing only select all or deselect all icon
				if(this.onlySelectAllIcon){
					var selectAllIcon = new dijit.form.Button({
						id: this.id+"selectAllIcon",
						showLabel: false,
						iconClass: "selectAllIcon",
						label: this.resources_.SELECT_ALL
					},this.selectAllIcon);
						
					selectAllIcon.onClick = dojo.hitch (this, "_selectAll");
					selectAllIcon.onKeypress = dojo.hitch (this, "_selectAll");
					dojo.style(this.deselectAllIcon.parentNode, "width", "0px");
				}else if(this.onlyDeselectAllIcon){
					var deselectAllIcon = new dijit.form.Button({
						id: this.id+"deselectAllIcon",
						showLabel: false,
						iconClass: "deselectAllIcon",
						label: this.resources_.DESELECT_ALL
					},this.deselectAllIcon);
						
					deselectAllIcon.onClick = dojo.hitch (this, "_deselectAll");
					deselectAllIcon.onKeypress = dojo.hitch (this, "_deselectAll");
					deselectAllIcon.onClick = dojo.hitch (this, "_deselectAll");
				}else {
					var selectAllIcon = new dijit.form.Button({
						id: this.id+"selectAllIcon",
						showLabel: false,
						iconClass: "selectAllIcon",
						label: this.resources_.SELECT_ALL
					},this.selectAllIcon);
						
					selectAllIcon.onClick = dojo.hitch (this, "_selectAll");
					selectAllIcon.onKeypress = dojo.hitch (this, "_selectAll");
					
					var deselectAllIcon = new dijit.form.Button({
						id: this.id+"deselectAllIcon",
						showLabel: false,
						iconClass: "deselectAllIcon",
						label: this.resources_.DESELECT_ALL
					},this.deselectAllIcon);
						
					deselectAllIcon.onClick = dojo.hitch (this, "_deselectAll");
					deselectAllIcon.onKeypress = dojo.hitch (this, "_deselectAll");
				}
			}
			else{				
				dojo.style(this.selectAllIcon.parentNode, "width", "0px");
				dojo.style(this.deselectAllIcon.parentNode, "width", "0px");
			}
			
			if(this.expandAllIcon) {
				/* Not supported in the base widget, dojo LazyTreeGrid
				var expandtAllIcon = new dijit.form.Button({
						id: this.id+"expandableAllIcon",
						showLabel: false,
						iconClass: "expandtAllIcon",
						label: this.resources_.EXPAND_ALL
					},this.expandtAllIcon);
					
				expandtAllIcon.onClick = dojo.hitch (this, "_expandAll");
				expandtAllIcon.onKeypress = dojo.hitch (this, "_expandAll");*/
				
				var collapseAllIcon = new dijit.form.Button({
					id: this.id+"collapseAllIcon",
					showLabel: false,
					iconClass: "collapseAllIcon",
					label: this.resources_.COLLAPSE_ALL
				},this.collapseAllIcon);				
				//Bobby:18Mar2011. Workaround for now since refresh collapses the grid!	
				//Satanik:07Jun2011: ORIA fixed the refresh code so it does not collapse the grid so calling different api
				collapseAllIcon.onClick = dojo.hitch (this, "_collapseAll");
				collapseAllIcon.onKeypress = dojo.hitch (this, "_collapseAll");			
				//collapseAllIcon.onClick = dojo.hitch (this, "_refreshTreeTable");
				//collapseAllIcon.onKeypress = dojo.hitch (this, "_refreshTreeTable");
			}
			else{				
				dojo.style(this.collapseAllIcon.parentNode, "width", "0px");
				dojo.style(this.expandtAllIcon.parentNode, "width", "0px");
			}			
				
			if(this.clearSortIcon) {
				var removeSortIcon = new dijit.form.Button({
					id: this.id+"clearSortIcon",
					showLabel: false,
					iconClass: "removeSortIcon",
					label: this.resources_.CLEAR_SORT
				},this.removeSortIcon);
					
				removeSortIcon.onClick = dojo.hitch (this, "_clearSort");
				removeSortIcon.onKeypress = dojo.hitch (this, "_clearSort");
			}
			else{				
				dojo.style(this.removeSortIcon.parentNode, "width", "0px");
			}
			if(this.configureTreeTableIcon) {
				var configureColIcon = new dijit.form.Button({
					id: this.id+"configureTreeTableIcon",
					showLabel: false,
					iconClass: "configureColIcon",
					label: this.resources_.CONFIGURE_TREETABLE
				},this.configureColNode);
					
				configureColIcon.onClick = dojo.hitch (this, "_configureColumn");
				configureColIcon.onKeypress = dojo.hitch (this, "_configureColumn");
			}
			else{				
				dojo.style(this.configureColNode.parentNode, "width", "0px");
			}			
			//console.log("this.quickFilterVisible:"+this.quickFilterVisible);
			
			if(this.quickFilterVisible && this.showQuickFilterButton) {
				this.quickFilter = new dojoe.treetable._QuickSearchFilter({
					id: this.id+"quickFilter", 
					grid: this.treeTable.grid,
					_quickFilterButton: true,
					filterOptions: this.filterOptions },this.quickFilterNode);	
				var quickFilterIcon = new dijit.form.Button({
					showLabel: false,
					iconClass: "filterIcon",
					id: "quickFilterIcon"+this.id,
					label: this.resources_.QUICK_FILTER,
					title: this.resources_.QUICK_FILTER
				},this.filterNode);				
				quickFilterIcon.onClick = dojo.hitch (this, "_setQuickFilter");
				quickFilterIcon.onKeypress = dojo.hitch (this, "_setQuickFilter");
				quickFilterIcon.domNode.title = this.resources_.QUICK_FILTER;	
			}else if(this.quickFilterVisible && !this.showQuickFilterButton) {
				this.quickFilter = new dojoe.treetable._QuickSearchFilter({
					id: this.id+"quickFilter", 
					grid: this.treeTable.grid,
					_quickFilterButton: false,
					filterOptions: this.filterOptions },this.quickFilterNode);				
			}
			
			if(this.actionMenu){
				var menu = new dijit.Menu({ style: "display: none;"});
				//menu.addChild(new dijit.MenuSeparator());
				
				//23789: Refresh should be part of Actions Menu also - OID
				//Bobby:29Jun11				
				if(this.refreshMenu) {
					//Menu Item for Configure Columns action
					var refreshMenuItem = new dijit.MenuItem({
						//Bobby:19Jul11, title is reqd by JAWS to anounce the menu item.					
						//24709: JAWS does not read the items in the Actions, Export or Print menus.					
						title: this.resources_.REFRESH,
						label: this.resources_.REFRESH,
						iconClass: "refreshIcon"
					});
					refreshMenuItem.onClick = dojo.hitch (this, "_refreshTreeTable");
					refreshMenuItem.onKeypress = dojo.hitch (this, "_refreshTreeTable");					 
					menu.addChild(refreshMenuItem);
				}				
				
				if(this.selectAllMenu){
					var selectAllMenuItem = new dijit.MenuItem({
						 //id: this.id+"selectAllMenuItem",
						 title: this.resources_.SELECT_ALL,
						 label: this.resources_.SELECT_ALL,
						 iconClass: "selectAllIcon"			         
					 });
					 selectAllMenuItem.onClick = dojo.hitch (this, "_selectAll");
					 selectAllMenuItem.onKeypress = dojo.hitch (this, "_selectAll");	
					 menu.addChild(selectAllMenuItem);
					
					 var deselectAllMenuItem = new dijit.MenuItem({
						 //id: this.id+"deselectAllMenuItem",
						 title: this.resources_.DESELECT_ALL,
						 label: this.resources_.DESELECT_ALL,
						 iconClass: "deselectAllIcon"
					  });
					 deselectAllMenuItem.onClick = dojo.hitch (this, "_deselectAll");
					 deselectAllMenuItem.onKeypress = dojo.hitch (this, "_deselectAll");
					 menu.addChild(deselectAllMenuItem);
				}
				
				if(this.expandAllMenu){
					/* Not supported in the base widget, dojo LazyTreeGrid
					var expandAllMenuItem = new dijit.MenuItem({
						 id: this.id+"expandAllMenuItem",
						 label: this.resources_.EXPAND_ALL,
						 iconClass: "expandtAllIcon"
					 });
					 expandAllMenuItem.onClick = dojo.hitch (this, "_expandAll");
					 expandAllMenuItem.onKeypress = dojo.hitch (this, "_expandAll");
					 menu.addChild(expandAllMenuItem);*/
					 
					 var collapseAllMenuItem = new dijit.MenuItem({
						 //id: this.id+"collapeAllMenuItem",
						 title: this.resources_.COLLAPSE_ALL,						 
						 label: this.resources_.COLLAPSE_ALL,
						 iconClass: "collapseAllIcon"
					 });
					 collapseAllMenuItem.onClick = dojo.hitch (this, "_collapseAll");
					 collapseAllMenuItem.onKeypress = dojo.hitch (this, "_collapseAll");
					 //collapseAllMenuItem.onClick = dojo.hitch (this, "_refreshTreeTable");
					 //collapseAllMenuItem.onKeypress = dojo.hitch (this, "_refreshTreeTable");					 
					 menu.addChild(collapseAllMenuItem);
				}
					
				if(this.clearSortMenu){
					 var clearSortMenuItem = new dijit.MenuItem({
						 //id: this.id+"clearSortMenuItem",
						 title: this.resources_.CLEAR_SORT,
						 label: this.resources_.CLEAR_SORT,
						 iconClass: "removeSortIcon"
					 });
					 clearSortMenuItem.onClick = dojo.hitch (this, "_clearSort");
					 clearSortMenuItem.onKeypress = dojo.hitch (this, "_clearSort");
					 menu.addChild(clearSortMenuItem);
				}
				
				if(this.configureTreeTableMenu){
					 var configureColMenuItem = new dijit.MenuItem({
						 //id: this.id+"configureColMenuItem",
						 title: this.resources_.CONFIGURE_TREETABLE,
						 label: this.resources_.CONFIGURE_TREETABLE,
						 iconClass: "configureColIcon"
					 });
					 configureColMenuItem.onClick = dojo.hitch (this, "_configureColumn");
					 configureColMenuItem.onKeypress = dojo.hitch (this, "_configureColumn");
					 menu.addChild(configureColMenuItem);
				}
				menu.startup();
				var actionList = new dijit.form.DropDownButton({
					optionsTitle : this.resources_.ACTIONS,
			        label: this.resources_.ACTIONS,
			        dropDown: menu,
					scrollOnFocus : true
			    },this.actionListNode);				
				this.actionListWidget = actionList;				
			}
			else{				
				dojo.style(this.actionListNode.parentNode, "width", "0px");
			}
		},
		
		_setQuickFilter: function(){
			//console.info("In _setQuickFilter.....");
			//this.quickFilter.filterObj = this.filterOptions;
			this.quickFilter._setFilter();
		},		
		
		_removeFromActionList: function (menuItemId){		
			var menuItem = dijit.byId(menuItemId);
			if(menuItem !== null && menuItem !== undefined) {
				menuItem.destroyRecursive();
			}
		},
		
		//do not call this method directly, use table.removeItemFromToolbar(itemId) method to remove a custom item from the toolbar
		_removeItem: function(itemId){
			var button= dijit.byId(itemId);
			if(button !== null && button !== undefined) {		
				if (button.domNode.parentNode) {
					//remove td which is the parent of the button
					buttonParent = button.domNode.parentNode;
					buttonParent.parentNode.removeChild(buttonParent);
				}
				button.destroyRecursive();
			}
		},
		//do not call this method directly, use table.addBeforeDefaultIcons(item) method to add a custom item to the toolbar before default buttons
		_addToToolbarFirstRow: function(item, position){
			var itemTD = dojo.doc.createElement("span"); 
			//dojo.style(itemTD, "width", "1px"); 
			//dojo.place(itemTD, this.toolbarFirstRow, parseInt(position));
			//Bobby:28Jun11, making position optional. If not mentioned, added at last.
			//22853: Table toolbar ordering reversed
			//Also creating a new span area for user items
			if(position !== undefined){
				dojo.place(itemTD, this.toolbarFirstRow_userItems, parseInt(position));
			}else dojo.place(itemTD, this.toolbarFirstRow_userItems, 'last');			
			itemTD.appendChild(item.domNode);
		},
		
		_addToToolbarSecondRow: function(item, position){
			var itemTD = dojo.doc.createElement("span"); 
			dojo.style(itemTD, "width", "1px"); 
			//dojo.place(itemTD, this.toolbarSecondRow, parseInt(position));
			//Bobby:28Jun11, making position optional. If not mentioned, added at last.
			if(position !== undefined){
				dojo.place(itemTD, this.toolbarSecondRow, parseInt(position));
			}else dojo.place(itemTD, this.toolbarSecondRow, 'last');			
			itemTD.appendChild(item.domNode);
		},

		destroy: function(){
			// summary:  Destroys the toolbar.
			// tags: public	
			//memory leak issue: custom destroy method to take care of removing all widgets					
			try{
				delete this.resources_;
				//this is for destroying child templated widgets 
				//this should happen by itself but need to figure out why dijit._Templated is not taking care of it...
				var widgets = dijit.findWidgets(this.domNode);
				dojo.forEach(widgets, function(w) {
					if(w){
						if(w.destroyRecursive){
							w.destroyRecursive();
						} else if(w.destroy){
							w.destroy();
						}
					}
				});
				// this is for widgets added as child to this widget and their children..
				//not present in template
				var widgetArr = this.getChildren();
				dojo.forEach(widgetArr, function (child) {
					if(child){
						if(child.destroyRecursive){
							child.destroyRecursive();
						} else if(child.destroy){
							child.destroy();
						}
					}
				});
				this.inherited(arguments);
			}catch(ex){
				console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
			}
		}		
	//Uncomment above comma and add comma-separated functions here. Do not leave a 
	// trailing comma after last element.			
});

}
