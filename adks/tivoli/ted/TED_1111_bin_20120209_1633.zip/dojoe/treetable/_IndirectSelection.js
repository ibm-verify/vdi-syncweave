/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.treetable._IndirectSelection"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.treetable._IndirectSelection"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

dojo.provide("dojoe.treetable._IndirectSelection");
//dojo.require("dojox.widget.Standby");

// define the widget class
dojo.declare("dojoe.treetable._IndirectSelection", null, {
	//Summary:
	//Class for enabling Indirect selection for tree table
	//modifies grid structure to include a selection column to the very left of the tree table
	//updates grid cache with selection status on grid events
	
	//Tree table grid component - to be passed when indirect selection is instantiated	
	grid : null, 
	//private - temporary selection cache which is used to update the grid cache on events like refresh,resize etc..
	_selectionCache : [], 
	
	//_standBy : null,
	
	_updateSelectionByCacheRunning : false,
	
	_connectArr: null,
		
	constructor : function (/*object*/grid) {
		//Summary:
		//Lazy tree grid should be passed as parameter to constructor which is modified to include indirect selection
		//console.debug('here in constructor');
		this.grid = grid;		
		this._connectArr = new Array();		
		//add indirect selection column to the grid
		//this._selectionCache = (this.grid.cache.items).slice();
		this._addIndirectSelector();
		//handle grid events and update the selection accordingly
		this._connectSelectionHandlers();
		/*this._standBy  = new dojox.widget.Standby({
			target: this.grid.id
		});
        document.body.appendChild(this._standBy.domNode);
        this._standBy.startup();*/		
	}, 
	
	_addIndirectSelector : function () {
		//Summary:
		//Include selection column in Lazy tree grid
		//tags: Private		
		this.grid.expandoCell = 1;
		selector = [{
				//Bobby:28Mar2011
				//dojox.data.QueryReadStore.getValue(): Item does not have the attribute 'selector'
				//field: "selector", - disabling this
				//name: '<div dojoAttachPoint="select" align="right" class="treeTableCheckBox" dojoAttachEvent="onclick:selectAllRows">', 
				//Bobby: 09Mar2011, applying similar style as Table indirect selector
				//name: '<div id="selectDiv" align="center" class="treeTableCheckBox">', 
				//Bobby: 17Mar2011, removing selectAll from header as sort can't be disabled
				//Anupama: 12Sept2011
				// Defect 27514:: Safari:In Treetable, Selection column is truncated on initial load.
				//changed width to display selection column
				name : ' ', 
				width : "22px", 
				styles : 'text-align: center;', 
				formatter : this._createCheckbox
			}
		];
		this.grid.structure = dojo._toArray(this.grid.structure, 0, selector);
		this.grid.setStructure(this.grid.structure);
		this.grid._refresh(true);
	}, 
	
	_createCheckbox : function (val, inRowIndex, treePathArr, cell) {
		//Summary:
		//formatter for selection column
		//tags:private
		//return: formatted checkbox
		//var store=this.grid.store;
		//var item = this.grid.getItem(inRowIndex);
		var id = this.grid.store.getIdentity(this.grid.getItem(inRowIndex));
		var indimgid = "treeimgid" + id;
		return '<div align="right" id=' + indimgid + ' class="treeTableCheckBox">';
	}, 
	
	_updateCacheSelect : function (ridx, item, selStatus) {
		//Summary:
		//updates grid cache items with selection status - true,false,'partial'
		//tags:private
		var id = this.grid.store.getIdentity(item);
		var expandoStatus = this.grid.cache.getExpandoStatusByRowIndex(ridx);
		var itemIndex = this._getItemIndexById(id);
		//console.info("_updateCacheSelect");
		//console.info("selStatus:"+selStatus);
		if (itemIndex !== -1 && this._selectionCache[itemIndex]) {
			//console.info("IF - calling _updateCache");
			this._updateCache(itemIndex, {
					selStatus : selStatus,
					item : item,
					rowIdx : itemIndex,
					id : id,
					expandoStatus : expandoStatus
				});
		} else {
			//console.info("ELSE- calling _cacheItem");
			//dojo.mixin(this._selectionCache[ridx], {selStatus: selStatus, item: item, rowIdx: ridx, id: id});
			this._cacheItem({
					selStatus : selStatus,
					item : item,
					rowIdx : ridx,
					id : id,
					expandoStatus : expandoStatus
				});
		}
	}, 
	
	_cacheItem : function (cacheObj) {
		// Summary
		//		Add an item and its tree structure information to the cache.
		//console.info("_cacheItem --------- BEGIN");
		var idx = this._getItemIndexById(cacheObj.id);
		if (idx == -1) {
			this._selectionCache.push(dojo.mixin({
						id : null, 
						selStatus : false, 
						rowIdx : -1, 
						expandoStatus : false
					}, cacheObj));
		} else {
			//Bobby:27Mar11
			//_updateCache -> updateCache
			this._updateCache(idx, cacheObj);
		}
		//console.info("_cacheItem --------- END");
	}, 
	
	_updateCache : function (/*integer*/idx, cacheObj) {
		//Summary
		//update selection cache
		//console.info("_updateCache --------- BEGIN");
		if (this._selectionCache[idx]) {
			dojo.mixin(this._selectionCache[idx], cacheObj);
		}
		//console.info("_updateCache --------- END");		
	}, 
	
	_getItemIndexById : function (id) {
		// check to see item is already in and return the index	
		for (var i = 0; i < this._selectionCache.length; i++) {
			if (this._selectionCache[i]) {
				if (this._selectionCache[i].id == id) {
					return i;
				}
			}
		}
		return - 1;
	}, 
	
	_getItemById : function (/*id*/rowId) {
		//added new interface for grid cache to fetch item by row id for selection rather than index which is faulty
		//this takes care of dojo defect of lazytreegrid selection
		for (var i = 0, len = this._selectionCache.length; i < len; i++) {
			if (this._selectionCache[i] && this._selectionCache[i].id
				 && (this._selectionCache[i].id === rowId)) {
				return this._selectionCache[i];
			}
		}
		return null;
	}, 
	
	isItemSelectedInCacheByIdx : function (rowIdx) {
		//Summary:
		//returns if a particular row is selected in cache by row index
		//Row selection should be tagged to row id rather than row index(which might be incorrect when tree is expanded/collapsed)
		//takes care of dojo defect of wrong grid selection by row index
		//console.info("isItemSelectedInCacheByIdx --------- BEGIN");	
		var id, sel, item = this.grid.getItem(rowIdx);
		if (item) {
			id = this.grid.store.getIdentity(item);
			var cachedItem = this._getItemById(id);
			if (cachedItem) {
				sel = cachedItem.selStatus;
			}
		}
		//console.info("isItemSelectedInCacheByIdx --------- END");	
		return sel;
	}, 
	
	getSelectedStatusById : function (id) {
		// If in the cache, return the selection status, otherwise return undefined
		var i = this._getItemIndexById(id);
		if (i != -1) {
			return this._getSelectedStatusByIndex(i);
		}
	}, 
	
	_getSelectedStatusByIndex : function (/*integer*/idx) {
		return this._selectionCache[idx] ? this._selectionCache[idx].selStatus : null;
	}, 
	
	_connectSelectionHandlers : function () {
		//Summary:
		//handling grid events to update selection in grid cache
		//tags: private
		this.grid.selection.clickSelect = function(){}; //disabling default selection			
		this._connectArr.push(dojo.connect(this.grid, 'expandoFetch', dojo.hitch(this, "_updateCacheOnExpando"))); //expand or collapse
		//Bobby:16Mar2011. Indirect selection should happen only when clicked on selector cell
		//dojo.connect(this.grid, 'onRowClick', dojo.hitch(this, "onSelectionChanged"));					
		this._connectArr.push(dojo.connect(this.grid, 'onCellClick', dojo.hitch(this, "onSelectionChanged"))); //indirect selection					
		this._connectArr.push(dojo.connect(this.grid, 'onKeyDown', dojo.hitch(this, "onSelectionChanged"))); //indirect selection
		this._connectArr.push(dojo.connect(this.grid, 'onSelectionChanged', dojo.hitch(this, "onSelectionChanged")));
		//Bobby:15Mar2011
		this._connectArr.push(dojo.connect(this.grid, 'onHeaderClick', this, "_updateSelectionOnRefresh")); //sorting
		this._connectArr.push(dojo.connect(this.grid, 'onResizeColumn', this, "_updateSelectionOnRefresh")); //column resize			
		this._connectArr.push(dojo.connect(this.grid, '_refresh', dojo.hitch(this, "_updateSelectionOnFetch"))); //grid refresh	
		this._connectArr.push(dojo.connect(this.grid, '_onFetchComplete', dojo.hitch(this, "_updateSelectionOnFetch")));//on Fetch complete update selection
		//dojo.connect(this.grid, '_onExpandoComplete', dojo.hitch(this, "_updateSelectionOnFetch")); //on Fetch complete update selection
		this._connectArr.push(dojo.connect(this.grid, 'resize', dojo.hitch(this, "_updateSelectionOnRefresh"))); //resize				
		//Bobby:15Apr2011
		//14932: Selection goes off when a new row is added
		this._connectArr.push(dojo.connect(this.grid, 'updateRow', dojo.hitch(this, "_updateSelectionOnRefresh"))); //store events	
		this._connectArr.push(dojo.connect(this.grid, 'updateRowCount', dojo.hitch(this, "_updateSelectionOnRefresh"))); //store events	
	}, 
	
	_updateSelectionOnFetch : function (items, request, size) {
		//summary:
		//handles selection update on fetch
		//tags:private
		//console.log('_updateSelectionOnFetch ------------- BEGIN');
		//var tempCache = this._selectionCache;
		//var treePath = "",startRowIdx, count, start;
		//this._standBy.show();
		var count;
		if (request) {
			startRowIdx = request.startRowIdx;
			count = request.count;
			start = 0;
		}
		//for _refresh and _fetchOnComplete events there is a second call which happens when cache is empty and count 0, avoid updating on this scenario
		//also avoid refresh on expando fetch, expando fetch has its own handler 
		//console.info("count:"+count);
		//console.info("grid.rowCount:"+this.grid.rowCount);
		//Bobby: 28Mar11
		//using refresh Icon, this.count=0, so disabling the check
		//if(count &&  count > this.grid.rowCount){
		if (count &&  count > 0){
			this._updateSelectionOnRefresh();
		}
		//this._standBy.hide();
		//console.log('_updateSelectionOnFetch ------------- END');
	}, 
	
	selectAllRows : function () {
		//summary:
		//connected to toolbar select all action and selects all the rows in the grid
		var headerdiv = dojo.byId("selectDiv");
		var rowcnt = this.grid.rowCount;
		for (var i = 0; i < rowcnt; i++) {
			var item = this.grid.getItem(i);
			var id = this.grid.store.getIdentity(item);
			var indimgid = "treeimgid" + id;
			var rowimage = dojo.byId(indimgid);
			//updateCache
			this._updateCacheSelect(i, item, true);
			//update temp cache with grid cache status
			//this._selectionCache = (this.grid.cache.items).slice();
		}
		this._updateParent();
		this._updateSelectionByCache();
	}, 
	
	deSelectAllRows : function () {
		//Summary:
		//de-selects all rows connected to toolbar deselect action
		var headerdiv = dojo.byId("selectDiv");
		var rowcnt = this.grid.rowCount;
		for (var i = 0; i < rowcnt; i++) {
			var item = this.grid.getItem(i);
			this._updateCacheSelect(i, item, false);
		}
		this._updateParent();
		this._updateSelectionByCache();
		//this._selectionCache = (this.grid.cache.items).slice();
	}, 
	
	onSelectionChanged : function (e) {
		//Summary:
		//fired when row selection changes by clicking on indirect selection column
		//console.log('onSelectionChanged ------------- BEGIN');
		
		if (e) { //selection changed by user
			//Bobby:16Mar11, select only if enter pressed
			if (e.keyCode && e.keyCode != 13) {
				//console.log('Not Enter key');
				//console.log('onSelectionChanged ------------- END');
				return;
			}
			//Bobby:16Mar11, if not clicked on selector cell, do nothing
			if (e.cellIndex != 0) {
				//console.log('Not selector cell');
				//console.log('onSelectionChanged ------------- END');		 
				return;
			}
			//e.cancelBubble=true;
			//console.log("if (e) - true");
			var item = this.grid.getItem(e.rowIndex);
			var sel = this._isRowSelected(e.rowIndex);
			if (sel != undefined) { // only care about checkbox click, ignore other
				this._changeSelectionByRow(e);
			}
		} else { //selection changed via API
			//console.log("if (e) - false");
			//this._standBy.show();
			this._updateSelectionByCache();
			//this._standBy.hide();
		}
		
		//this._updateSelectionByCache();
		//console.log('onSelectionChanged ------------- END');
		//this._updateCache();
		//this._initCache();
		
		// this._endUpdate();
		// this.onSelectionDone();
		
	}, 
	
	_updateCacheOnExpando : function (rowIndex, openState) {
		//Summary:
		//fired on 'expandoFetch' to update the selection on fetch of child items
		//tags: Private
		//console.log('_updateCacheOnExpando ------------- BEGIN');
		//this._standBy.show();
		if (openState) {
			var item = this.grid.getItem(rowIndex);
			//console.log("item:"+item);
			var id = this.grid.store.getIdentity(item);
			var cachedItem = this._getItemById(id);
			//console.log("cachedItem -->"+ cachedItem);
			if (cachedItem) {
				var selectflag = cachedItem.selStatus;
				//console.log("selectflag -->"+ selectflag);
				if (selectflag !== 'partial') {
					//var children = this.grid.store.getValues(item, 'children');
					//console.log("going to call mayHaveChildren..");
					if (this.grid.treeModel.mayHaveChildren(item)) {
						//console.info("has children!");
						//var selectflag = cachedItem.selStatus;
						//call recursive child select with selection status of parent
						this._selectChildren(item, rowIndex, selectflag);
						
					}
								
				} else {
					this._updateSelectionByCache();
				}
			}else{
				this._updateSelectionByCache();
			}
			//var tempCache = (this.grid.cache.items).slice();
			//this._selectionCache = (this.grid.cache.items).slice();
		} else {
			this._updateSelectionByCache();
		}		
		//this._standBy.hide();
		//console.log('_updateCacheOnExpando ------------- END');
	}, 
	
	_changeSelectionByRow : function (e) {
		//changes the indirect selection checkboxes depending on the selection status
		
		//console.info('-_changeSelectionByRow ---------- BEGIN');
		//var store = e.grid.store;
		//var row = e.rowIndex;
		var rowIndex = e.rowIndex;
		var item = this.grid.getItem(rowIndex);
		
		//console.dir(item);
		var isParent = false;
		var selectflag = false;
		var id = this.grid.store.getIdentity(item);
		
		//console.info("expando Status:"+this.grid.cache.getExpandoStatusByRowIndex(rowIndex));
		//var children = this.grid.store.getValues(item, 'children');
		//if (children && children != true && children.length>0) {
		if (this.grid.cache.getExpandoStatusByRowIndex(rowIndex) && this.grid.treeModel.mayHaveChildren(item)) {
			isParent = true;
			//console.info("IF calling _updateSelection..");
			selectflag = this._updateSelection(item, id, rowIndex);
			this._selectChildren(item, rowIndex, selectflag);
			
		} else {
			//console.info("ELSE calling _updateSelection..");
			this._updateSelection(item, id, rowIndex);
			this._updateParent();
			this._updateSelectionByCache();
		
		}
		//console.info('_changeSelectionByRow ---------- END');
		
	}, 
	
	_updateSelectionOnRefresh : function () {
		//console.info('-_updateSelectionOnRefresh ---------- BEGIN');
		//this._standBy.show();
		this._updateSelectionByCache();
		//this._updateParent();
		//this._updateSelectionByCache();
		//this._standBy.hide();		
		//console.info('-_updateSelectionOnRefresh ---------- END');
	}, 
	
	_updateSelectionByCache : function () {
		//summary:
		//update grid selection by cache 
		//tags: private
		//console.info('_updateSelectionByCache ---------- BEGIN');
		
		for (var i = 0; i < this.grid.rowCount; i++) {
			var sel = this.isItemSelectedInCacheByIdx(i);
			var item = this.grid.getItem(i);
			//console.dir(item);
			//console.log("item "+i+":"+item);
			if(!item) continue;
			var id = this.grid.store.getIdentity(item);
			//var indimgid="treeimgid"+id;
			var rowimage = dojo.byId("treeimgid" + id);
			
			if (sel == true) {
				this.grid.selection.addToSelection(i);
				if (dojo.hasClass(rowimage, "treeTableCheckBox")) {
					dojo.removeClass(rowimage, ["treeTableCheckBox"]);
				} else if (dojo.hasClass(rowimage, "treeTableToggleButtonPartial")) {
					dojo.removeClass(rowimage, ["treeTableToggleButtonPartial"]);
				}
				dojo.addClass(rowimage, ["treeTableToggleButtonChecked"]);
			} else if (sel == false) {
				this.grid.selection.deselect(i);
				if (dojo.hasClass(rowimage, "treeTableToggleButtonChecked")) {
					dojo.removeClass(rowimage, ["treeTableToggleButtonChecked"]);
				} else if (dojo.hasClass(rowimage, "treeTableToggleButtonPartial")) {
					dojo.removeClass(rowimage, ["treeTableToggleButtonPartial"]);
				}
				dojo.addClass(rowimage, ["treeTableCheckBox"]);
			} else if (sel == 'partial') {
				//console.debug('selection is partial: '+ sel);	
				this.grid.selection.deselect(i);
				if (dojo.hasClass(rowimage, "treeTableToggleButtonChecked")) {
					dojo.removeClass(rowimage, ["treeTableToggleButtonChecked"]);
					
				} else if (dojo.hasClass(rowimage, "treeTableCheckBox")) {
					dojo.addClass(rowimage, ["treeTableToggleButtonPartial"]);
				}
				dojo.addClass(rowimage, ["treeTableToggleButtonPartial"]);
			} else {
				if (this.grid.selection.isSelected(i)) {
					this.grid.selection.deselect(i);
				}
			}
			//this._updateSelectionByCacheRunning = false;
		}
		//console.info('_updateSelectionByCache ---------- END');
	}, 
	
	_updateParent : function () {
		//Summary:
		//updates parent item when child is selected/deselected - totally/partially
		//tags: private
		//console.info('_updateParent ---------- BEGIN');
		//var rowcnt = this.grid.rowCount;
		for (var i = this.grid.rowCount-1; i >= 0; i--) {
			var numSel = 0;
			var item = this.grid.getItem(i);
			if(!item) continue;
			var id = this.grid.store.getIdentity(item);			
			//Bobby: 27Mar2011, following won't work in all stores.
			//var children = store.getValues(item, 'children');
			//if collapsed do nothing
			if (this.grid.cache.getExpandoStatusByRowIndex(i) === false) {
				continue;
			}
			//if expanded, go fetch the children and process further
			if (this.grid.treeModel.mayHaveChildren(item)) {
				var queryObj = {
					start : 0, 
					count : this.grid.keepRows, //or this.grid.rowCount?
					parentId : id, 
					parentRowIndex : i, 
					sort : this.grid.getSortProps() 
				};
				//console.info("Calling getChildren.....");
				if(this.grid.treeModel.serverStore){
					this.grid.treeModel.getChildren(item, dojo.hitch(this, "_updateParentRecursive"), dojo.hitch(this, "_onError"), queryObj);
				
				}
				else{
					//for clientstore treemodel does not set queryobj to callback
					var onComplete = dojo.hitch(this, "_updateParentRecursive");
					this.grid.treeModel.getChildren(item, 
													function(childItems){
														onComplete(childItems,queryObj);
													}, 
													dojo.hitch(this, "_onError"),
													queryObj
													);
				}
				//console.info("Called getChildren.....");
			}
		}
		//console.info('_updateParent ---------- END');
	}, 
	
	_updateParentRecursive : function (children, queryObj, size) {
		//Summary:
		//updates parent item when expanded
		//tags: private
		//console.info('_updateParentRecursive ---------- BEGIN');
		//console.info("children:"+children);
		//console.info("queryObj:"+queryObj);
		//console.info("size:"+size);		
		var item = this.grid.getItem(queryObj.parentRowIndex);
		var selStatus = false;
		//var indimgid="treeimgid"+id;
		var numSel = 0;		
		for (j = 0; j < children.length; j++) {
			var cId = this.grid.store.getIdentity(children[j]);
			var selStatus = this.getSelectedStatusById(cId);
			//console.debug('updateparent: selStatus of children: '+ selStatus);
			if (selStatus === true) {
				numSel++;
			}
			else if (selStatus === 'partial'){
				selStatus = 'partial';
				break;
			}
		}
		
		//console.info("numSel:"+numSel);
		//console.info("children.length:"+children.length);
		if (numSel > 0) {
			if (children.length == numSel) { // all children selected 
				this._updateCacheSelect(queryObj.parentRowIndex, item, true);
			} else {
				this._updateCacheSelect(queryObj.parentRowIndex, item, 'partial');
			}
		} else {
			if (selStatus == 'partial') {
				this._updateCacheSelect(queryObj.parentRowIndex,item, 'partial');
			}
			else {
				this._updateCacheSelect(queryObj.parentRowIndex,item, false);
			}
			//this._updateCacheSelect(queryObj.parentRowIndex, item, false);
		}
		this._updateSelectionByCache();
		//console.info('_updateParentRecursive ---------- END');
	}, 
	
	_isRowSelected : function (idx) {
		//Summary:
		// check the cache before checkbox, works like toggle
		//tags:private
		var sel = this.isItemSelectedInCacheByIdx(idx);
		var item = this.grid.getItem(idx);
		var id = this.grid.store.getIdentity(item);
		var indimgid = "treeimgid" + id;
		var rowimage = dojo.byId(indimgid);
		
		if (sel == undefined) {
			// checkbox.value hasn't not updated yet, only checked reflect the correct state
			if (dojo.hasClass(rowimage, "treeTableToggleButtonChecked")) {
				return true;
			} else {
				return false;
			}
		} else {
			//if (sel === true || sel === false) 
				return sel;
		}
	}, 
	
	_updateSelection : function (item, id, rowIndex) {
		//Summary:
		//update selection in cache on toggle
		//console.info('_updateSelection ------ BEGIN');
		var selectFlag;
		//console.dir(item);
		if (this.getSelectedStatusById(id) === false) {
			this._updateCacheSelect(rowIndex, item, true);
			selectFlag = true;
		} else if (this.getSelectedStatusById(id) === true) {
			this._updateCacheSelect(rowIndex, item, false);
			selectFlag = false;
		} else if (this.getSelectedStatusById(id) == 'partial') {
			this._updateCacheSelect(rowIndex, item, true);
			selectFlag = true;
		} else {
			this._updateCacheSelect(rowIndex, item, true);
			selectFlag = true;
		}
		//console.info('_updateSelection ------ END');
		return selectFlag;
	}, 
	
	_selectChildren : function (item, rowIndex, selectflag) {
		//console.info('_selectChildren ------ BEGIN');
		//this.parentItem = item;
		//this.parentRowIndex = rowIndex;
		//this.parentSelect = selectflag;
		/*if(!this.count){
		this.count = rowIndex + childItems.length;
		}*/		
		//console.dir(item);		
		var parentId = this.grid.store.getIdentity(item);
		var queryObj = {
			start : 0, 
			count : this.grid.keepRows, 
			parentId : parentId, 
			sort : this.grid.getSortProps(), 
			parentRowIndex : rowIndex, 
			parentSelectFlag : selectflag
		};
		if(this.grid.treeModel.serverStore){
			this.grid.treeModel.getChildren(item, dojo.hitch(this, "_recursiveChildSelect"), dojo.hitch(this, "_onError"), queryObj);
		}else{
			//for clientstore treemodel does not set queryobj to callback
			var onComplete = dojo.hitch(this, "_recursiveChildSelect");
			this.grid.treeModel.getChildren(item, 
											function(childItems){
												onComplete(childItems,queryObj);
											}, 
											dojo.hitch(this, "_onError"),
											queryObj
											);
		}
		//console.info('_selectChildren ------ END');
	}, 
	
	_getChildren : function (item) {
		var parentId = this.grid.store.getIdentity(item);
		var queryObj = {
			start : 0, 
			count : this.grid.keepRows, 
			parentId : parentId, 
			sort : this.grid.getSortProps() 
		};
		this.grid.treeModel.getChildren(item, dojo.hitch(this, "_setChildren"), dojo.hitch(this, "_onError"), queryObj);	
	}, 
	
	_setChildren : function (childItems, request, size) {
		this.children = childItems;
	}, 
	
	_onError : function (e) {
		//console.error('Fetch Children error: '+ e);
	}, 
	
	_recursiveChildSelect : function (childItems, request, size) {
		//Summary:
		//recursively select children if a parent is selected or deselected , expanded/collapsed
		//tag:private
		//console.info("_recursiveChildSelect ---------  BEGIN");
		//console.info("childItems:"+childItems);
		//console.info("request:"+request);
		//console.info("size:"+size);	
		
		var rowIndex = request.parentRowIndex;
		var selectflag = request.parentSelectFlag;
		var expand = this.grid.cache.getExpandoStatusByRowIndex(rowIndex);
		var childSelect = dojo.hitch(this, function (childItems, expand, rowIndex, selectflag) {
				if (childItems && expand === true) {
					for (var i =rowIndex+1, j=0; j < childItems.length; j++) {
						var item = childItems[j];
						var id = this.grid.store.getIdentity(item);
						var children = this.grid.treeModel.mayHaveChildren(item);
						var childExpand = this.grid.cache.getExpandoStatusByRowIndex(i);
						if (children && childExpand) {
							//var childSelStatus = selectflag;
							//childSelect(gchildren,childExpand,i,childSelStatus);
							this._selectChildren(item,i, selectflag);
							i= i+j;
							
						}else{
							i++;
						}
						if (selectflag === false) {
							this._updateCacheSelect(i,item, false);
						} else if (selectflag === true) {
							this._updateCacheSelect(i, item, true);
						}
					}
				}
				return;
			});
		//recursively call to select children if expandoStatus is true
		if (childItems && expand === true) {
			childSelect(childItems, expand, rowIndex, selectflag);
		}
		this._updateParent();
		this._updateSelectionByCache();
		//console.info("_recursiveChildSelect ---------  END");
	},
	
	destroy: function(){
		// summary:  Destroys the toolbar.
		// tags: public	
		//memory leak issue: custom destroy method to take care of removing all widgets					
		try{
			dojo.forEach(this._connectArr, dojo.disconnect);
			this._connectArr = [];
		}catch(ex){
			console.warn("Destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
		}
	}
});
 

}
