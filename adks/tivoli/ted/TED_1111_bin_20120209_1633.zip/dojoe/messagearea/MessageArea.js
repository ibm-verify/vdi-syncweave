/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.messagearea.MessageArea"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.messagearea.MessageArea"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

dojo.require("dijit._Templated");
dojo.require("dijit._Widget");
dojo.require("dojo.fx");
dojo.require("dojox.html.ellipsis");
dojo.require("dijit.Tooltip");

dojo.require("dojo.i18n");
// NLS
dojo.requireLocalization("dojoe.messagearea", "MessageArea", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");

dojo.provide("dojoe.messagearea.MessageArea");
dojo.provide("dojoe.messagearea.MessageAreaManager");
/******************************************************************************
* Collapsable Message Area (Info, Warning, Error)
*
* The purpose of this widget is to be placed into dialogs and forms to aid in
* providing feedback on form errors.
*
* Author: Bobby Joseph
*
* 14Feb2011		Bobby Joseph	Migrating to TED 1.1 from Tip Dojo Widgets
* 20Feb2011		Bobby Joseph	Adding new type "error", same as "critical". Adding width.
* 21Feb2011		Bobby Joseph	Changing default width to 100% from 80%. It was always 100% before.
* 04Mar2011		Bobby Joseph	Enabling internationalization
******************************************************************************/
dojo.declare("dojoe.messagearea.MessageArea", [dijit._Widget, dijit._Templated],
{
	//the message box type: critical/error, info, warning
	type: "critical",
	
	//the message in the are -- can be HTML string
	message: "",
	
	//if you provide a message id then it will use bigger message images
	messageId: null,

	//the duration of time to play the wipe fx on show and close	
	duration: 200,
	
	// url: String: a URL that links the message to an InfoCenter page	
	url: null,
	
	// boolean: create the message area already open?
	isShowing: false,
	
	//width of messagearea
	width: "100%",
	
	//23096: As a consumer of MessageArea widget, we need for long messages to truncate with ellipsis if the msg is too long to fit within the container instead of wrapping
	//set true to avoid wrap and show ellipsis for long messages
	ellipsis: false,
	
	//This variable controls the position of tooltip (before, after, above, below)
	//if null dojo is supposed to position automatically in viewport
	tooltipPosition: null,
	
	//the HTML template for the label placement and null value checkbox
	templateString:"<div>\r\n\t<div dojoAttachPoint=\"wipeNode\" role=\"status\" tabindex=\"0\" aria-relevant=\"all\" aria-label=\"message area\">\r\n\t<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" dojoAttachPoint=\"styleArea\" role=\"presentation\">\r\n\t<tr>\r\n\t\t<td dojoAttachPoint=\"messageIconNode\" width=\"17\" valign=\"top\">\r\n\t\t\t<img dojoAttachPoint=\"messageIcon\" src=\"${criticalIcon}\" \r\n\t\t\tborder=\"0\" style=\"padding-right:7px\" role=\"img\"/ tabindex=\"0\">\r\n\t\t</td>\r\n\t\t<td>\r\n\t\t\t<div dojoAttachPoint=\"messageNodeContainer\"  tabindex=\"0\" role=\"presentation\" aria-describedby=\"${id}_content\" class=\"message-description\">\r\n\t\t\t\t<div id=\"${id}_content\" dojoAttachPoint=\"messageNode\"></div>\r\n\t\t\t</div>\t\r\n\t\t</td>\r\n\t\t<td width=\"18\" valign=\"top\">\r\n\t\t\t<img dojoAttachPoint=\"closeBtn\" class=\"messageAreaCloseIcon\" src=\"${closeIcon}\" alt=\"${_resources.DIALOG_BUTTON_CLOSE}\" \r\n\t\t\tborder=\"0\" dojoAttachEvent=\"onclick:_onClose,onkeydown:_onClose\" tabindex=\"0\" title=\"${_resources.DIALOG_BUTTON_CLOSE}\" role=\"button\"/>\r\n\t\t</td>\r\n\t</tr>\r\n\t</table>\r\n\t</div>\r\n</div>\r\n",
	
	closeIcon: dojo.moduleUrl("dojoe.common","themes/images/message_close.gif"),
	criticalIcon: dojo.moduleUrl("dojoe.common","themes/images/i_message_critical_10.png"),	

	// _resources:  Object
	//		Reference to the resources
	_resources:null,	
	
	constructor: function () 
	{
		//this._resources = dojo.i18n.getLocalization("dojoe.messagearea", "MessageArea");	
		//Bobby: 04Mar2011
		//Following change is required to load the bundle corresponding to the locale
		this._resources = dojo.i18n.getLocalization("dojoe.messagearea", "MessageArea", this.lang);
	}, 			
	/**************************************************************************
	* Setup the widget
	**************************************************************************/	
	postCreate: function()
	{
		//call super
		this.inherited( "postCreate", arguments );
		
		//initialize message
		this.setMessageId( this.messageId );
		
		//initialize message
		this.setMessage( this.message );

		//initialize type
		this.setType( this.type );		
		
		//create a WipeIn Effect Object
		this._wipeIn = dojo.fx.wipeIn(
		{
			node: this.wipeNode,
			duration: this.duration
		});
		
		//create a WipeOut Effect Object
		this._wipeOut = dojo.fx.wipeOut(
		{
			node: this.wipeNode,
			duration: this.duration			
		});
		
		if ( !this.isShowing ) 
		{
			this.wipeNode.style.display="none";
		}
		
		this.wipeNode.style.width= this.width;
	},
	
	/**************************************************************************
	* Sets the type of the message box (critical/error, warning, info)
	**************************************************************************/		
	setType: function( type )
	{
		//Bobby 20Feb2011, mapping error to critical 
		//for better guideline compliance & backward compatibility
		if(type == 'error') type = 'critical';
		this.type = type;		
		this._updateClass();
	},
	
	/**************************************************************************
	* Sets the message ( can be HTML string )
	**************************************************************************/		
	setMessage: function( message )
	{
		this.messageNode.innerHTML = message;
		this.message = message;
	},
	
	/**************************************************************************
	* Sets the width ( can be % or px/em)
	**************************************************************************/		
	setWidth: function( width )
	{
		this.width = width;
	},	
	
	/**************************************************************************
	* Sets the messageId ( can be HTML string )
	**************************************************************************/		
	setMessageId: function( messageId )
	{
	   this.messageId = messageId;
	   
	   var suffix = "_30.png";
	   	   
	   //if ( messageId === undefined || messageId === null || messageId == "" )
	   if(!messageId)
	   {
	     suffix = "_10.png";
	     
	     if( this.messageIdNode )
	     {
	     	this.messageIdNode.parentNode.removeChild( this.messageIdNode );
	     	delete this.messageIdNode;
	     }
	   }
	   else
	   {
	     if( !this.messageIdNode )
	     {
		   	 this.messageIdNode = dojo.doc.createElement( 'DIV' );
		   	 this.messageIdNode.className = "message-id";
		     dojo.place( this.messageIdNode, this.messageNode, "before" );
		 }
		   	 
	   	 var innerHTML = "";
	   	 
	   	 //if infocenter URL set then create hyperlink
	   	 if ( this.url ) 
	   	 {
	   	   innerHTML += '<a href="javascript:void(0)" onclick="window.open(\'' + this.url + '\')">';
		   innerHTML += this.messageId;
		   innerHTML += "</a>";
		 }
		 else 
		 {
		   innerHTML += this.messageId;
	     }
	   	 
	     this.messageIdNode.innerHTML = innerHTML;		     
	   }
	   
	   
	   this.criticalIcon = dojo.moduleUrl("dojoe.common","themes/images/i_message_critical" + suffix);
           this.infoIcon = dojo.moduleUrl("dojoe.common","themes/images/i_message_info"  + suffix);
	   this. warningIcon = dojo.moduleUrl("dojoe.common","themes/images/i_message_warning"  + suffix);	    
	   
	   this._updateClass();	    
	   if(messageId) this.messageIconNode.width = "35"; 	
	},
	
	/**************************************************************************
	* Show a info message
	* messageID is optional
	**************************************************************************/		
	showInfoMessage: function( message, messageID )
	{
		this.setMessage( message );
		if (messageID)
		{
			this.setMessageId( messageID );
		}
		else
		{
			this.setMessageId( null );
		}
		this.setType( "info" );
		
		this.show();
	},

	/**************************************************************************
	* Show a warning message
	* messageID is optional
	**************************************************************************/		
	showWarningMessage: function( message, messageID )
	{
		this.setMessage( message );
		
		if (messageID)
		{
			this.setMessageId( messageID );
		}
		else
		{
			this.setMessageId( null );
		}
		
		this.setType( "warning" );
		
		this.show();
	},

	/**************************************************************************
	* Show an error message
	* messageID is optional
	**************************************************************************/		
	showErrorMessage: function( message, messageID )
	{
		this.setMessage( message );
		
		if (messageID)
		{
			this.setMessageId( messageID );
		}
		else
		{
			this.setMessageId( null );
		}
		
		this.setType( "critical" );
		
		this.show();
	},
	
	/**************************************************************************
	* Show the message area -- ensures message area not already visible for you
	**************************************************************************/		
	show: function(){
		if ( !this.isShowing ){
			this.wipeNode.style.width= this.width;
			this.isShowing = true;
			this._wipeIn.play();					
		}
		if(this.ellipsis){
			//If the CSS style property is hyphenated, the JavaScript property is camelCased 
			//eg: table-layout -> tableLayout		
			dojo.style(this.styleArea, "tableLayout", "fixed");
			dojo.addClass(this.messageNode, "dojoxEllipsis");		
			new dijit.Tooltip({
				 connectId: [this.messageNodeContainer],
				 label: this.message,
				 position: this.tooltipPosition
			});
		}		
	},
	
	/**************************************************************************
	* Hide the message area -- ensures message area not already hidden for you
	**************************************************************************/		
	hide: function(){
		if ( this.isShowing ){
			this.isShowing = false;
			this._wipeOut.play();
		}
	},
	
	/**************************************************************************
	* updates the CSS styling and icon based on current type setting
	**************************************************************************/		
	_updateClass: function(){
		var type = this.type.toLowerCase();
		
		dojo.removeClass( this.styleArea, "critical" );
		dojo.removeClass( this.styleArea, "info" );
		dojo.removeClass( this.styleArea, "warning" );
		
		if( type == "critical")
		{
			this.messageIcon.src = this.criticalIcon;
			this.messageIcon.title = this._resources.DIALOG_ERROR;
			this.messageIcon.alt = this._resources.DIALOG_ERROR;
		}
		else if ( type == "info" )
		{
			this.messageIcon.src = this.infoIcon;
			this.messageIcon.title = this._resources.DIALOG_INFO;
			this.messageIcon.alt = this._resources.DIALOG_INFO;
		}
		else
		{
			this.messageIcon.src = this.warningIcon;
			this.messageIcon.title = this._resources.DIALOG_WARNING;
			this.messageIcon.alt = this._resources.DIALOG_WARNING;
		}
		
		dojo.addClass( this.styleArea, type );
		//overload the stylesheet (because it was written for a dialog)
		this.styleArea.style.padding="2px";
	},
		
	/**************************************************************************
	* Called when the close button is clicked
	**************************************************************************/				
	_onClose: function(event){
		//22732: In MessageArea, close icon is closing the messagearea on any key press action.
		//Bobby:27Jun2011, close only on Space or Enter
		if(event.keyCode && event.keyCode!==dojo.keys.ENTER && event.keyCode!=dojo.keys.SPACE){
			return;
		}else{
			this.domNode.style.display = 'none';
			this.destroyRecursive();
		}
	},
	
	destroy : function () {
		// summary:  Destroys the widget.
		// tags: public
		try{
			delete this._resources;
			//this is for destroying child templated widgets 
			//this should happen by itself but need to figure out why dijit._Templated is not taking care of it...
			var widgets = dijit.findWidgets(this.domNode);
			dojo.forEach(widgets, function(w) {
				if(w){
					if(w.destroyRecursive){
						w.destroyRecursive();
					} else if(w.destroy){
						w.destroy();
					}
				}
			});
			// this is for widgets added as child to this widget and their children..
			//not present in template
			var widgetArr = this.getChildren();
			dojo.forEach(widgetArr, function (child) {
				if(child){
					if(child.destroyRecursive){
						child.destroyRecursive();
					} else if(child.destroy){
						child.destroy();
					}
				}
			});
			this.inherited(arguments);
		}catch(ex){
			console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
		}
	}	
});

}
