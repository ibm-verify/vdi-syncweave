/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"DIALOG_ERROR":"Erreur","DIALOG_WARNING":"Avertissement","DIALOG_INFO":"Information","DIALOG_BUTTON_CLOSE":"Fermer"})