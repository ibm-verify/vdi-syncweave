/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"DIALOG_ERROR":"오류","DIALOG_WARNING":"경고","DIALOG_INFO":"정보","DIALOG_BUTTON_CLOSE":"닫기"})