/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"DIALOG_ERROR":"Napaka","DIALOG_WARNING":"Opozorilo","DIALOG_INFO":"Informacije","DIALOG_BUTTON_CLOSE":"Zapri"})