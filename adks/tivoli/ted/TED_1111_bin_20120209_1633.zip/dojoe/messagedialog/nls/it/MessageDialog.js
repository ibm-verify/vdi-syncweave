/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"MESSAGE_TITLE":"${0} - ${1}","DIALOG_BUTTON_OK":"OK","DIALOG_BUTTON_CLOSE":"Chiudi","DIALOG_VALIDATION":"Convalida","DIALOG_CONFIRM":"Conferma","NEVER_SHOW":"Non visualizzare più","DIALOG_WARNING":"Avvertenza","DIALOG_ERROR":"Errore","DIALOG_INFO":"Informazioni"})