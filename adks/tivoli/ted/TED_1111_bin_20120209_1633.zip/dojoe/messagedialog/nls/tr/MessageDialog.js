/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"MESSAGE_TITLE":"${0} - ${1}","DIALOG_BUTTON_OK":"Tamam","DIALOG_BUTTON_CLOSE":"Kapat","DIALOG_VALIDATION":"Doğrulama","DIALOG_CONFIRM":"Doğrula","NEVER_SHOW":"Bir Daha Gösterme","DIALOG_WARNING":"Uyarı","DIALOG_ERROR":"Hata","DIALOG_INFO":"Bilgi"})