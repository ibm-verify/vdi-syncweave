/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"MESSAGE_TITLE":"${0} - ${1}","DIALOG_BUTTON_OK":"OK","DIALOG_BUTTON_CLOSE":"Fermer","DIALOG_VALIDATION":"Validation","DIALOG_CONFIRM":"Confirmer","NEVER_SHOW":"Ne plus afficher","DIALOG_WARNING":"Avertissement","DIALOG_ERROR":"Erreur","DIALOG_INFO":"Information"})