/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"MESSAGE_TITLE":"${0} - ${1}","DIALOG_BUTTON_OK":"אישור","DIALOG_BUTTON_CLOSE":"סגירה","DIALOG_VALIDATION":"תיקוף","DIALOG_CONFIRM":"אישור","NEVER_SHOW":"אין להציג שוב","DIALOG_WARNING":"אזהרה","DIALOG_ERROR":"שגיאה","DIALOG_INFO":"מידע"})