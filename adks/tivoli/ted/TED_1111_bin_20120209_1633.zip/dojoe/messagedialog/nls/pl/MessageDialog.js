/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"MESSAGE_TITLE":"${0} - ${1}","DIALOG_BUTTON_OK":"OK","DIALOG_BUTTON_CLOSE":"Zamknij","DIALOG_VALIDATION":"Sprawdzenie poprawności","DIALOG_CONFIRM":"Potwierdź","NEVER_SHOW":"Nie pokazuj tego więcej","DIALOG_WARNING":"Ostrzeżenie","DIALOG_ERROR":"Błąd","DIALOG_INFO":"Informacja"})