/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"MESSAGE_TITLE":"${0} - ${1}","DIALOG_BUTTON_OK":"OK","DIALOG_BUTTON_CLOSE":"Sulje","DIALOG_VALIDATION":"Tarkistus","DIALOG_CONFIRM":"Vahvista","NEVER_SHOW":"Älä näytä uudelleen","DIALOG_WARNING":"Varoitus","DIALOG_ERROR":"Virhe","DIALOG_INFO":"Ilmoitus"})