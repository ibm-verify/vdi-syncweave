/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"MESSAGE_TITLE":"${0} - ${1}","DIALOG_BUTTON_OK":"V redu","DIALOG_BUTTON_CLOSE":"Zapri","DIALOG_VALIDATION":"Preverjanje","DIALOG_CONFIRM":"Potrdi","NEVER_SHOW":"Ne pokaži nikoli več","DIALOG_WARNING":"Opozorilo","DIALOG_ERROR":"Napaka","DIALOG_INFO":"Informacije"})