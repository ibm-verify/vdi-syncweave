/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"MESSAGE_TITLE":"${0} - ${1}","DIALOG_BUTTON_OK":"OK","DIALOG_BUTTON_CLOSE":"Close","DIALOG_VALIDATION":"Validation","DIALOG_CONFIRM":"Confirm","NEVER_SHOW":"Never Show Again","DIALOG_WARNING":"Warning","DIALOG_ERROR":"Error","DIALOG_INFO":"Information"})