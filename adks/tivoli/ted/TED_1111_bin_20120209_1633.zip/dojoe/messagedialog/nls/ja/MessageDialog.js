/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"MESSAGE_TITLE":"${0} - ${1}","DIALOG_BUTTON_OK":"OK","DIALOG_BUTTON_CLOSE":"クローズ","DIALOG_VALIDATION":"検証","DIALOG_CONFIRM":"確認","NEVER_SHOW":"再表示しない","DIALOG_WARNING":"警告","DIALOG_ERROR":"エラー","DIALOG_INFO":"情報"})