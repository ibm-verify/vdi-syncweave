/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"MESSAGE_TITLE":"${0} - ${1}","DIALOG_BUTTON_OK":"确定","DIALOG_BUTTON_CLOSE":"关闭","DIALOG_VALIDATION":"验证","DIALOG_CONFIRM":"确认","NEVER_SHOW":"不再显示","DIALOG_WARNING":"警告","DIALOG_ERROR":"错误","DIALOG_INFO":"参考"})