/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"MESSAGE_TITLE":"${0} - ${1}","DIALOG_BUTTON_OK":"حسنا","DIALOG_BUTTON_CLOSE":"اغلاق","DIALOG_VALIDATION":"التحقق من الصلاحية","DIALOG_CONFIRM":"تأكيد","NEVER_SHOW":"عدم عرضه مرة أخرى","DIALOG_WARNING":"تحذير","DIALOG_ERROR":"خطأ","DIALOG_INFO":"معلومات"})