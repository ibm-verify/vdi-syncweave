/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"MESSAGE_TITLE":"${0} - ${1}","DIALOG_BUTTON_OK":"確定","DIALOG_BUTTON_CLOSE":"關閉","DIALOG_VALIDATION":"驗證","DIALOG_CONFIRM":"確認","NEVER_SHOW":"不要再顯示","DIALOG_WARNING":"警告","DIALOG_ERROR":"錯誤","DIALOG_INFO":"資訊"})