/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"MESSAGE_TITLE":"${0} - ${1}","DIALOG_BUTTON_OK":"확인","DIALOG_BUTTON_CLOSE":"닫기","DIALOG_VALIDATION":"유효성 검증","DIALOG_CONFIRM":"확인","NEVER_SHOW":"다시 표시하지 않음","DIALOG_WARNING":"경고","DIALOG_ERROR":"오류","DIALOG_INFO":"정보"})