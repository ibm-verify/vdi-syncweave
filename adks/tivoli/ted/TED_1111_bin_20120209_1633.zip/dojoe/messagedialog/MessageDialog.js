/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.messagedialog.MessageDialog"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.messagedialog.MessageDialog"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.messagedialog.MessageDialog");

dojo.require("dijit._Widget");
dojo.require("dijit.Dialog"); 
dojo.require("dijit.form.CheckBox");
dojo.require("dijit.form.Button");
dojo.require("dojo.i18n");
dojo.require("dojox.layout.ResizeHandle");
dojo.require("dojoe.Util");

//Localization of resource bundles
dojo.requireLocalization("dojoe.messagedialog", "MessageDialog", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");


dojo.declare("dojoe.messagedialog.MessageDialog",[ dijit._Widget ],
{
	// summary:  MessageDialog is a widget to show message dialogs of type error,warning,info,confirm. 
	// description: MessageDialog widget uses the dijit.Dialog for its implementation.
	
	//theme: String
	// defined the theme for Message Dialog
	theme:null,	
	
	//resources:object
	//Reference to the resources
	resources_:null,
	 
    // resizeAxis: String
    //  x | xy | y to limit pane's sizing direction.
    resizeAxis: "xy",

	// type: String
    // defines the type of message dialog ("Error","Critical", "Warning", "Info", "Confirm").
	type: "Error",
	
	// portlet title associated w/ this message
	portletTitle: null,

	// message: String
	//the displayable translated message
	message: null,

	// messageId: String
	//the displayable translated message's unique identifier
	messageId: null,
	
	// width: String
	//gives the pixel width of the dialog (Default: 500px)
	width: "380px",
	
	// height: String
	//gives the pixel height of the dialog (Default: 200px)
	height: "225px",
	
	// buttons: String Array
	//a list of buttons to display (Default: OK)
	buttons: [],
	
	// callback: Function
	//a callback function when the dialog is closed
	callback: null,
	
	// parameters to pass on callback when dialog closes
	callbackParms: null,
	
	// url: String
	//a URL that links the message to an InfoCenter page
	url: null,
	
	// show "Never show again checkbox"
	showCheckbox: false,
	
	// contentIsolation: boolean parameter to open PopupUtil in content isolation mode in portlets
	contentIsolation: false,
	
	// Destroy the dialog on close
	destroyOnClose: true,

	// enableResizeHandle: boolean
	//a flag to enable/disable the resize handle, default is true
	enableResizeHandle: true,
	
	// namespace: user defined namespace for widget
	namespace :"",
	
	dir : "",

	constructor: function() {
		// summary: An extension to the Dojo Dialog widget that supports 
		//      advanced features.
		// resourceMessages_: JSON
		//		Resource bundle.
		// dialog_: dojo.widget.FloatingPane
		//		An instance of the Dialog widget.
		// title_: String
		//		Title bar string.
		// icon_: String
		//		The dialog icon's uri.
		// buttonPressedId_: String
		//		The ID of the button pressed; this value is passed to the callback function.

	    this.resources_ = dojo.i18n.getLocalization("dojoe.messagedialog", "MessageDialog",this.lang);
		
		if (this.contentIsolation == true) {
			var statusAr = startsWith(djConfig.locale,"ar");
			var statusHe = startsWith(djConfig.locale,"he");
			if (statusAr == true || statusHe == true) {
				this.dir = "rtl";
			}
		}
	    
	    this.dialog_ = null;

	    this.title_ = null;
	    this.icon_ = null;
	    this.buttonPressedId_ = -1;
	},


	postCreate: function() { 
		// summary:  Creates and initialises the message Dialog as per its type.
		// tags: public
	    if (this.buttons.length === 0) {
	        this.buttons.push(this.resources_.DIALOG_BUTTON_OK);
	    }

		var className = null;
		//Bobby:20Dec11 - changing all images to use latest in guidelines - BEGIN		
	    if (this.type.toLowerCase() == "error" ||this.type.toLowerCase() == "critical") {
	    	if (this.portletTitle) {
		    	this.title_ = dojo.string.substitute(this.resources_.MESSAGE_TITLE, { 0: this.resources_.DIALOG_ERROR, 1: this.portletTitle });
	    	} else {
		        this.title_ = this.resources_.DIALOG_ERROR;
		    }
	        this.icon_ = dojo.moduleUrl("dojoe.common", "themes/images/st34critical_shad.png");
	        className = "critical";
	    }
	    else if (this.type.toLowerCase() == "warning") {
	    	if (this.portletTitle) {
		    	this.title_ = dojo.string.substitute(this.resources_.MESSAGE_TITLE, { 0: this.resources_.DIALOG_WARNING, 1: this.portletTitle });
	    	} else {
		        this.title_ = this.resources_.DIALOG_WARNING;
		    }
	        this.icon_ = dojo.moduleUrl("dojoe.common", "themes/images/st34minorwarning_shad.png");
	        className = "warning";
	    }
	    else if (this.type.toLowerCase() == "confirm") {
	    	if (this.portletTitle) {
		    	this.title_ = dojo.string.substitute(this.resources_.MESSAGE_TITLE, { 0: this.resources_.DIALOG_CONFIRM, 1: this.portletTitle });
	    	} else {
		        this.title_ = this.resources_.DIALOG_CONFIRM;
		    }
	        this.icon_ = dojo.moduleUrl("dojoe.common", "themes/images/st34unknown_shad.png");
	        className = "confirm";
	    }
	    else if (this.type.toLowerCase() == "validation") {
	    	if (this.portletTitle) {
		    	this.title_ = dojo.string.substitute(this.resources_.MESSAGE_TITLE, { 0: this.resources_.DIALOG_VALIDATION, 1: this.portletTitle });
	    	} else {
		        this.title_ = this.resources_.DIALOG_VALIDATION;
		    }
	        this.icon_ = dojo.moduleUrl("dojoe.common", "themes/images/st34success_shad.png");
	        className = "validation";
	    }
	    else { // if (this.type.toLowerCase() == "info") {
	    	if (this.portletTitle) {
		    	this.title_ = dojo.string.substitute(this.resources_.MESSAGE_TITLE, { 0: this.resources_.DIALOG_INFO, 1: this.portletTitle });
	    	} else {
		        this.title_ = this.resources_.DIALOG_INFO;
		    }
	        this.icon_ = dojo.moduleUrl("dojoe.common", "themes/images/st34informational_shad.png");
	        className = "info";
	    }
	    //Bobby:20Dec11 - changing all images to use latest in guidelines - END
		
		var div = document.createElement('div'); 
		document.body.appendChild(div);
		var theme=this.theme;
		var dir = this.dir;
        this.dialog_ = new dijit.Dialog (
			                             { title: this.title_,
											dir: dir
		                                 },
		                                 div); 

		var dojoAttachpoint = this.dialog_.containerNode;
		this.dialog_.closeButtonNode.setAttribute("title", this.resources_.DIALOG_BUTTON_CLOSE);
		this.dialog_.closeButtonNode.setAttribute("tabIndex", 0);
		dojo.connect(this.dialog_.closeButtonNode,'onkeypress',this,'onKeyPress');
		dojo.style(div,'class',theme);
		dojoAttachpoint.innerHTML = this.getContent(className,theme);
		// dojo.connect(dijit.Dialog.prototype, "postMixInProperties", function(){ this.buttonCancel="Close" });
    
		if(this.enableResizeHandle == true){
			//Build and place resize handle       
			var resizeHandleDOM = dojo.doc.createElement( 'span' );
			resizeHandleDOM.className = "dojoxFloatingResizeHandle";    
			dojo.place( resizeHandleDOM, this.dialog_.domNode, "last" );		
			this.resizeHandle = new dojox.layout.ResizeHandle(
			{ 
				targetId: this.dialog_.id, 
				resizeAxis: this.resizeAxis 
			}, resizeHandleDOM );  
			this.onResizeListener = dojo.connect( this.dialog_, "resize", this, "customLayout" );			
		}
	
        this.dialog_.domNode.style.width = this.width;	
        this.dialog_.domNode.style.height = this.height;	
        //this.dialog_.containerNode.style.overflow="auto";
        this.dialog_.domNode.style.overflow = "hidden";        
    
		for (var i = 0; i < this.buttons.length; i++) {
			var button = dojo.byId(this.id + "mmd_button_" + i);
			dojo.connect(button, 'onclick', this, 'onClick');    
		}
    
        this.onCloseListener  = dojo.connect( this.dialog_, "hide", this, "_onHide" );
	    
	},
	
    /**************************************************************************
    * The dialog has been hidden.  Wait 500 miliseconds to destroy the dialog.
    *
    * HACK -- Can't figure out a better way to destroy the dialog on close.
    **************************************************************************/
    _onHide:function()
    {// summary: Closes the MessageDialog .
		// tags: private
      setTimeout( dojo.hitch( this, "destroy" ), 500 );
    },  
	
	onKeyPress: function (e) {
		if (e.keyCode == 13 || e.keyCode == 32 || e.keyCode == 0) { //  Space keycode is 32 on IE8 and 0 on mozilla.  Enter keycode is 13 for both. 
			this.dialog_.hide();
		}
	},
	
	onClick: function(/* HTMLEvent */e) {
    	// summary:  Calls the callback on click of Ok else destroys.
		// tags: public
		var index = this.id.length + "mmd_button_".length;
		this.buttonPressedId_ = parseInt(e.target.id.substring(index), 0);
	    //console.log ("MessageDialog.onClick: buttonPressedId_: " + this.buttonPressedId_);
	    var checkbox = dojo.byId (this.id + "neverShowAgain");
	    var checked = checkbox ? checkbox.checked : false;

	    this.dialog_.hide();
	    
	    if (this.callback) {
	    	this.callback(this.buttonPressedId_, this.messageId, checked, this.callbackParms);
	    }
    },

	show: function() {
    	// summary:  Displays the messageDialog.
		// tags: public
	    if( this.contentIsolation == true ){
			// Get the namespace identifying the content that launched the context menu
			//console.info("Inside Show if PopupUtil Undefined");
			var namespace="";
			if(this.namespace != null)
			 namespace = this.namespace;
			
			//Close (just in case) and then open the popup covering the whole page
			//console.info("Opening Popup namespace "+namespace);
			var xcord=100;
			var ycord=100;
			var dialogNamespace=namespace+'dojoe.messagedialog.MessageDialog';
			var old_popup_iframe = PopupUtil.ClosePopup( namespace+'dojoe.messagedialog.MessageDialog' );
			//Changes for fixing Content Isolation issue with Claro theme
			//var theme = dojo.body().className;
			var theme=this.theme;
			this.baseUrl=dojo.baseUrl;
			
			var index = this.baseUrl.lastIndexOf("dojo/dojo/");
			
				if (index != -1) {
				
			this.baseUrl=this.baseUrl.substring(0,index);
			
			}
				 
			
			//Changes to fix CSBUG #158121
			//var popupUrl =dojo.baseUrl+'../html/MessageDialogPopUp.html?PopupID='+dialogNamespace+'&eLeft='+xcord+'&eTop='+ycord+'&locale='+djConfig.locale+"&theme="+theme;
			var popupUrl =this.baseUrl+'sample/jsp/html/MessageDialogPopUp.html?PopupID='+dialogNamespace+'&eLeft='+xcord+'&eTop='+ycord+'&locale='+djConfig.locale+"&theme="+theme;
			//console.info("url "+popupUrl);
			var popup_iframe = PopupUtil.OpenPopup( 
				namespace, 
				namespace+'dojoe.messagedialog.MessageDialog', 
				true, 
				null, 
				null, 
				null, 
				null, 
				popupUrl, 
				null
			);
			//console.info("after popup opening code");
			//Initialize the contextMenu when the iframe popup is finished loading
			var tThis = this;
			if( popup_iframe.addEventListener ){
				popup_iframe.addEventListener(
					"load", 
					function(){
						popup_iframe.contentWindow.makeMessageDialog( tThis );
					}, 
					false
				);
			}
			else if (popup_iframe.attachEvent){
				popup_iframe.attachEvent(
					"onload", 
					function(){ 
						popup_iframe.contentWindow.makeMessageDialog( tThis);
					}
				);
			}
		}
		else{
			this.dialog_.show();
			this.customLayout();
			this.correctPNG();
        }
	},

      customLayout: function() 
      {
		// summary: Resizes the Message Dialog.
		// tags: public
		//console.debug( dojo.byId( this.id + '_messagediv' ) );
		//console.debug( dojo.contentBox( this.dialog_.domNode ) );
		
		var messageDiv = dojo.byId( this.id + '_messagediv' );
		var dialogSize = dojo.contentBox( this.dialog_.domNode );

		var titleBarSize = dojo.contentBox( this.dialog_.titleBar );

		var newSize = {w:0,h:0};

		newSize.w = dialogSize.w - 75;
		if (this.showCheckbox === true) {
			var neverShowCoords = dojo.coords (this.id + "neverShowAgain");
			//Background issue fix for IE
			if(dojo.isIE < 8) {
				newSize.h = dialogSize.h - titleBarSize.h - neverShowCoords.h - 65;
			} else	if(dojo.isIE >= 8) {
				newSize.h = dialogSize.h - titleBarSize.h - neverShowCoords.h - 95;
			}else if(dojo.isSafari >= 3) {
				newSize.h = dialogSize.h - titleBarSize.h - neverShowCoords.h - 75;
			}  
			else {
				newSize.h = dialogSize.h - titleBarSize.h - neverShowCoords.h - 90;
			}
		} else {
			//Defect Fix for Locales with Long translations
			//newSize.h = dialogSize.h - titleBarSize.h - 90;
			//Background issue fix for IE
			if(dojo.isIE < 8) {
				newSize.h = dialogSize.h - titleBarSize.h - 65;
			} else if(dojo.isIE >= 8) {
				newSize.h = dialogSize.h - titleBarSize.h - 95;
			}else if(dojo.isSafari >= 3) {
				newSize.h = dialogSize.h - titleBarSize.h - 75;
			} else {
				newSize.h = dialogSize.h - titleBarSize.h - 100;
			}
		}

	    dojo.contentBox( messageDiv, newSize );
	},
	
	getContent: function(className,theme) {
		// summary:  gets the content to show inside messageDialog.
		// tags: public
		var innerHTML = "";
		if (theme == null) {
		theme = "claro";
		}
		//innerHTML += "<table style=\"width: 100%;\" class=\"" + className + "\">";
		
		innerHTML += "<div class=\"" + theme + "\">";
		if (this.showCheckbox === true) {
			innerHTML += "<table class=\"" + className + "checkbox\" >";
		}else innerHTML += "<table class=\"" + className + "\" >";
		innerHTML += "<tr valign=\"top\">";
		innerHTML += "<td>";
		innerHTML += "<img role='img'  align=\"top\" src=\"" + this.icon_ + "\" tabIndex=0 title=\"" + this.title_ + "\">";
		innerHTML += "</img>"		
		innerHTML += "</td>";
		innerHTML += "<td>";		

		innerHTML += "<table>";
		innerHTML += "<tr >";
		
		/*innerHTML += "<td rowspan=\"2\">";
		innerHTML += "&nbsp;";
		innerHTML += "<img align=\"middle\" src=\"" + this.icon_ + "\"/>";
		innerHTML += "&nbsp;&nbsp;";
		innerHTML += "</td>";*/

		
		//Bobby:31Oct11, making messageId optional as per request from TPM
		if (this.messageId) {		
			innerHTML += "<td>";
			innerHTML += "&nbsp;";		
			innerHTML += "&nbsp;&nbsp;";
			innerHTML += "</td>";		
			innerHTML += "<td class=\"message-id\" style='font-size: 11px;' tabIndex=0 aria-label=\"" + this.messageId + "\">";		
		
			// add URL to infocenter
			if (this.url) {
				innerHTML += '<a href="javascript:void(0)" onclick="window.open(\'' + this.url + "\')\">";
				innerHTML += this.messageId;
				innerHTML += "</a>";
			}
			else {
				innerHTML += this.messageId;
			}			
			innerHTML += "</td>";
		}
		innerHTML += "</tr>";
		innerHTML += "<tr>";
		innerHTML += "<td valign=\"top\">";
		innerHTML += "&nbsp;";
		//innerHTML += "<img role='img'  align=\"top\" src=\"" + this.icon_ + "\" tabIndex=0 title=\"" + this.title_ + "\">";
		//innerHTML += "</img>"
		innerHTML += "&nbsp;&nbsp;";
		innerHTML += "</td>";
		innerHTML += "<td class=\"message-description\" >";
		innerHTML += "<div id='" + this.id + "_messagediv" + "' style='overflow:auto; width:100%;font-size: 11px;' tabIndex=0 aria-label=\"" + this.message + "\">";
		//innerHTML += "<p>";
		innerHTML += this.message;
		//innerHTML += "</p>";
		innerHTML += "</div>";
		innerHTML += "</td>";
		innerHTML += "</tr>";
		if (!this.messageId) {	
			innerHTML += "<tr>";
			innerHTML += "<td>";
			innerHTML += "&nbsp;";		
			innerHTML += "</td>";
			innerHTML += "</tr>";			
		}	
		innerHTML += "</table>";

		innerHTML += "</td>";
		innerHTML += "</tr>";

		if (this.showCheckbox === true) {
			innerHTML += "<tr>";
			innerHTML += "<td>";	
			innerHTML += "</td>";			
			innerHTML += "<td class=\"checkbox\" style=\"font-size: 11px\" valign=\"bottom\">";
			
			innerHTML += "<table>";
			innerHTML += "<tr valign='bottom'>";
			innerHTML += "<td>";
			innerHTML += "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"checkbox\" dojoType=\"dijit.form.CheckBox\" id=\"" + this.id + "neverShowAgain\"/>&nbsp;";
			innerHTML += "</td>";
			innerHTML += "<td valign='middle'>";
			innerHTML += "<label for=\"" + this.id + "neverShowAgain\">" + this.resources_.NEVER_SHOW + "</label>";
			innerHTML += "</td>";
			innerHTML += "</tr>";	
			innerHTML += "</table>";		
			
			innerHTML += "</td>";
			innerHTML += "</tr>";
		}

		innerHTML += "<tr>";
		//innerHTML += "<td valign=\"bottom\" style=\"background-color: rgb(247, 247, 247);\">";
		innerHTML += "<td>";
		innerHTML += "</td>";
		//innerHTML += "</tr>";		
		//innerHTML += "</table>";		
		innerHTML += "<td>";		
		
		//innerHTML += "<div style='background-color:#F0F0F5'>"; //Footer
		innerHTML += "<table width='100%' class=\"" + this.theme+ "\">";
		innerHTML += "<tr>";
		
		innerHTML += "<td valign=\"bottom\">";
		innerHTML += "<div class=\"dialogButtons\">";
		for (var i = 0; i < this.buttons.length; i++) {
			innerHTML += "&nbsp; <span class=\"dijit dijitReset dijitInline dijitButton\"> &nbsp;<button  dojoType=\"dijit.form.Button\"  type=\"button\" role=\"button\" style=\"font-size: 11px\" id=\"" + this.id + "mmd_button_" + i + "\" value=\"" + this.buttons[i] + "\" class=\"dijitReset dijitInline dijitButtonNode\"> &nbsp;";
			innerHTML += this.buttons[i] + "&nbsp;</button> </span>";
		}
		innerHTML += "</td>";
		innerHTML += "</tr>";
		innerHTML += "</table>";
		innerHTML += "</div>";
		
		innerHTML += "</td>";
		innerHTML += "</tr>";		
		innerHTML += "</table>";
		
		//innerHTML += "</div>";
		
		return innerHTML;
	},
	
	// correctly handle PNG transparency in Win IE 5.5 & 6.
	correctPNG: function() {
		var arVersion = navigator.appVersion.split("MSIE");
		var version = parseFloat(arVersion[1]);
		if ((version >= 5.5) && document.body.filters) {
			for (var i = 0; i < document.images.length; i++) {
				var img = document.images[i];
				var imgName = img.src.toUpperCase();
				if (imgName.substring(imgName.length-3, imgName.length) == "PNG") {
					var imgID = img.id ? "id='" + img.id + "' " : "";
					var imgClass = img.className ? "class='" + img.className + "' " : "";
					var imgTitle = img.title ? "title='" + img.title + "' " : "title='" + img.alt + "' ";
					var imgStyle = "display:inline-block;" + img.style.cssText;
					if (img.align == "left") {
						imgStyle = "float:left;" + imgStyle;
					}
					if (img.align == "right") {
						imgStyle = "float:right;" + imgStyle;
					}
					if (img.parentElement.href) {
						imgStyle = "cursor:hand;" + imgStyle;
					}
					var strNewHTML = "<span " + imgID + imgClass + imgTitle +
									 " style=\"" + "width:" + img.width + "px; height:" + img.height + "px;" + imgStyle + ";" +
									 "filter:progid:DXImageTransform.Microsoft.AlphaImageLoader" +
									 "(src=\'" + img.src + "\', sizingMethod='scale');\"></span>";
					img.outerHTML = strNewHTML;
					i = i - 1;
				}
			}
		}    
	},
	
	destroy: function () {
		// summary:  destroys the message Dialog.
		// tags: public
        dojo.disconnect( this.onCloseListener );
		if(this.onResizeListener){
			dojo.disconnect( this.onResizeListener );
		}
        
        //TODO:  The fact this can NOT be called means we have not created the widget correctly
        //       This widget should directly extend dialog to be created correctly
        //this.inherited( "destroy", arguments );
        
        if ( this.dialog_ ) { this.dialog_.destroy(); dijit.registry.remove (this.dialog_.id); delete this.dialog_; }
        
		if (dijit.byId (this.id + "neverShowAgain")) {
			dijit.registry.remove (this.id + "neverShowAgain");
		}

		for (var i = 0; i < this.buttons.length; i++) {
			dijit.registry.remove (this.id + "mmd_button_" + i);
		}

		delete this.type;
		delete this.message;
		delete this.messageId;
		delete this.width;
		delete this.height;
		delete this.buttons;
		delete this.callbackParms;
		delete this.url;
		delete this.showCheckbox;
		delete this.destroyOnClose;
		delete this.title_;
		delete this.icon_;
		delete this.resources_;

		dijit.registry.remove (this.id);
	}

});



}
