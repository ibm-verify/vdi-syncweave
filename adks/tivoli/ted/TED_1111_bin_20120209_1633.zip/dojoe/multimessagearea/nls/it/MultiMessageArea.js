/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Fare clic per ordinare in base alla Severità","VALID_IMAGE":"Convalida","CONTAINER_CONTENT":"Messaggio","WARNING_IMAGE":"Avvertenza","ERROR_IMAGE":"Errore","CONTAINER_CONTENTS":"Messaggi","CLEAR_TIME_SORT_IMAGE":"Fare clic per cancellare l'ordine per Orario","EXP_IMAGE":"Fare clic per espandere","CLEAR_SEV_SORT_IMAGE":"Fare clic per cancellare l'ordine per Severità","TIME_SORT_IMAGE":"Fare clic per ordinare in base all'Orario","CLOSE_BUTTON":"Chiudi","INFO_IMAGE":"Informazioni","COL_IMAGE":"Fare clic per comprimere"})