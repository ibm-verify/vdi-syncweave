/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Click to sort by Severity","VALID_IMAGE":"Validation","CONTAINER_CONTENT":"Message","WARNING_IMAGE":"Warning","ERROR_IMAGE":"Error","CONTAINER_CONTENTS":"Messages","CLEAR_TIME_SORT_IMAGE":"Click to clear sort by Time","EXP_IMAGE":"Click to Expand","CLEAR_SEV_SORT_IMAGE":"Click to clear sort by Severity","TIME_SORT_IMAGE":"Click to sort by Time","CLOSE_BUTTON":"Close","INFO_IMAGE":"Information","COL_IMAGE":"Click to Collapse"})