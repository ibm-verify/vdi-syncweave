/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Kliknite, če želite razvrstiti po resnosti","VALID_IMAGE":"Preverjanje","CONTAINER_CONTENT":"Sporočilo","WARNING_IMAGE":"Opozorilo","ERROR_IMAGE":"Napaka","CONTAINER_CONTENTS":"Sporočila","CLEAR_TIME_SORT_IMAGE":"Kliknite, če želite počistiti razvrstitev po času","EXP_IMAGE":"Kliknite, če želite razširiti","CLEAR_SEV_SORT_IMAGE":"Kliknite, če želite počistiti razvrstitev po resnosti","TIME_SORT_IMAGE":"Kliknite, če želite razvrstiti po času","CLOSE_BUTTON":"Zapri","INFO_IMAGE":"Informacije","COL_IMAGE":"Kliknite, če želite strniti"})