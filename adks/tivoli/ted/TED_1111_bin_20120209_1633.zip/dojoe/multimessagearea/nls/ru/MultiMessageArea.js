/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Нажмите, чтобы отсортировать по серьезности","VALID_IMAGE":"Проверка","CONTAINER_CONTENT":"Сообщение","WARNING_IMAGE":"Предупреждение","ERROR_IMAGE":"Ошибка","CONTAINER_CONTENTS":"Сообщения","CLEAR_TIME_SORT_IMAGE":"Нажмите, чтобы отменить сортировку по времени","EXP_IMAGE":"Нажмите, чтобы раскрыть","CLEAR_SEV_SORT_IMAGE":"Нажмите, чтобы отменить сортировку по серьезности","TIME_SORT_IMAGE":"Нажмите, чтобы отсортировать по времени","CLOSE_BUTTON":"Закрыть","INFO_IMAGE":"Информация","COL_IMAGE":"Нажмите, чтобы свернуть"})