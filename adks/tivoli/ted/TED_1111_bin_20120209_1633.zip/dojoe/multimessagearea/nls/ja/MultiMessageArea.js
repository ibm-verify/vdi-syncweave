/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"重大度でソートする場合にクリック","VALID_IMAGE":"検証","CONTAINER_CONTENT":"メッセージ","WARNING_IMAGE":"警告","ERROR_IMAGE":"エラー","CONTAINER_CONTENTS":"メッセージ","CLEAR_TIME_SORT_IMAGE":"時刻でのソートをクリアする場合にクリック","EXP_IMAGE":"クリックして展開","CLEAR_SEV_SORT_IMAGE":"重大度でのソートをクリアする場合にクリック","TIME_SORT_IMAGE":"時刻でソートする場合にクリック","CLOSE_BUTTON":"クローズ","INFO_IMAGE":"情報","COL_IMAGE":"クリックして縮小"})