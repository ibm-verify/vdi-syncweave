/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Cliquez pour trier par Gravité","VALID_IMAGE":"Validation","CONTAINER_CONTENT":"Message","WARNING_IMAGE":"Avertissement","ERROR_IMAGE":"Erreur","CONTAINER_CONTENTS":"Messages","CLEAR_TIME_SORT_IMAGE":"Cliquez pour effacer le tri par Durée","EXP_IMAGE":"Cliquez pour Développer","CLEAR_SEV_SORT_IMAGE":"Cliquez pour effacer le tri par Gravité","TIME_SORT_IMAGE":"Cliquez pour trier par Durée","CLOSE_BUTTON":"Fermer","INFO_IMAGE":"Information","COL_IMAGE":"Cliquez pour Réduire"})