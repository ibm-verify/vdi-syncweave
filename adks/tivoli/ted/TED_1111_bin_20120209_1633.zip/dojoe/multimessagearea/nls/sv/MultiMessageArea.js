/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Klicka för att sortera efter allvarlighetsgrad","VALID_IMAGE":"Validering","CONTAINER_CONTENT":"Meddelande","WARNING_IMAGE":"Varning","ERROR_IMAGE":"Fel","CONTAINER_CONTENTS":"Meddelanden","CLEAR_TIME_SORT_IMAGE":"Klicka för att ta bort sortering efter tid","EXP_IMAGE":"Klicka för att expandera","CLEAR_SEV_SORT_IMAGE":"Klicka för att ta bort sortering efter allvarlighetsgrad","TIME_SORT_IMAGE":"Klicka för att sortera efter tid","CLOSE_BUTTON":"Stäng","INFO_IMAGE":"Information","COL_IMAGE":"Klicka för att komprimera"})