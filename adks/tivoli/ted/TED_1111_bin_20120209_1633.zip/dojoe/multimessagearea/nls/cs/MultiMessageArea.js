/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Klepnutím seřadit podle závažnosti","VALID_IMAGE":"Ověření","CONTAINER_CONTENT":"Zpráva","WARNING_IMAGE":"Varování","ERROR_IMAGE":"Chyba","CONTAINER_CONTENTS":"Zprávy","CLEAR_TIME_SORT_IMAGE":"Klepnutím zrušit řazení podle času","EXP_IMAGE":"Klepnutím rozbalit","CLEAR_SEV_SORT_IMAGE":"Klepnutím zrušit řazení podle závažnosti","TIME_SORT_IMAGE":"Klepnutím seřadit podle času","CLOSE_BUTTON":"Zavřít","INFO_IMAGE":"Informace","COL_IMAGE":"Klepnutím sbalit"})