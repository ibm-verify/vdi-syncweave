/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Kattintson ide a rendezéshez súlyosság szerint","VALID_IMAGE":"Érvényesítés","CONTAINER_CONTENT":"Üzenet","WARNING_IMAGE":"Figyelmeztetés","ERROR_IMAGE":"Hiba","CONTAINER_CONTENTS":"Üzenetek","CLEAR_TIME_SORT_IMAGE":"Kattintson ide az időpont szerinti rendezés törléséhez","EXP_IMAGE":"Kattintson ide a kibontáshoz","CLEAR_SEV_SORT_IMAGE":"Kattintson ide a súlyosság szerinti rendezés törléséhez","TIME_SORT_IMAGE":"Kattintson ide a rendezéshez időpont szerint","CLOSE_BUTTON":"Bezárás","INFO_IMAGE":"Információ","COL_IMAGE":"Kattintson ide az összezáráshoz"})