/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Kliknij, aby posortować według istotności","VALID_IMAGE":"Sprawdzenie poprawności","CONTAINER_CONTENT":"Komunikat","WARNING_IMAGE":"Ostrzeżenie","ERROR_IMAGE":"Błąd","CONTAINER_CONTENTS":"Komunikaty","CLEAR_TIME_SORT_IMAGE":"Kliknij, aby wyczyścić sortowanie według czasu","EXP_IMAGE":"Kliknij, aby rozwinąć","CLEAR_SEV_SORT_IMAGE":"Kliknij, aby wyczyścić sortowanie według istotności","TIME_SORT_IMAGE":"Kliknij, aby posortować według czasu","CLOSE_BUTTON":"Zamknij","INFO_IMAGE":"Informacja","COL_IMAGE":"Kliknij, aby zwinąć"})