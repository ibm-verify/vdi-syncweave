/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"اضغط للفرز بواسطة درجة الأهمية","VALID_IMAGE":"التحقق من الصلاحية","CONTAINER_CONTENT":"رسالة","WARNING_IMAGE":"تحذير","ERROR_IMAGE":"خطأ","CONTAINER_CONTENTS":"رسائل","CLEAR_TIME_SORT_IMAGE":"اضغط لمحو الفرز بواسطة الوقت","EXP_IMAGE":"اضغط للعرض","CLEAR_SEV_SORT_IMAGE":"اضغط لمحو الفرز بواسطة درجة الأهمية","TIME_SORT_IMAGE":"اضغط للفرز بواسطة الوقت","CLOSE_BUTTON":"اغلاق","INFO_IMAGE":"معلومات","COL_IMAGE":"اضغط للطي"})