/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"לחיצה למיון לפי דרגת חומרה","VALID_IMAGE":"תיקוף","CONTAINER_CONTENT":"הודעה","WARNING_IMAGE":"אזהרה","ERROR_IMAGE":"שגיאה","CONTAINER_CONTENTS":"הודעות","CLEAR_TIME_SORT_IMAGE":"לחיצה לניקוי מיון לפי שעה","EXP_IMAGE":"לחיצה להרחבה","CLEAR_SEV_SORT_IMAGE":"לחיצה לניקוי מיון לפי דרגת חומרה","TIME_SORT_IMAGE":"לחיצה למיון לפי שעה","CLOSE_BUTTON":"סגירה","INFO_IMAGE":"מידע","COL_IMAGE":"לחיצה לצמצום"})