/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Clicar para classificar por Gravidade","VALID_IMAGE":"Validação","CONTAINER_CONTENT":"Mensagem","WARNING_IMAGE":"Aviso","ERROR_IMAGE":"Erro","CONTAINER_CONTENTS":"Mensagens","CLEAR_TIME_SORT_IMAGE":"Clicar para limpar a classificação por Horário","EXP_IMAGE":"Clicar para Expandir","CLEAR_SEV_SORT_IMAGE":"Clicar para limpar a classificação por Gravidade","TIME_SORT_IMAGE":"Clicar para classificar por Horário","CLOSE_BUTTON":"Fechar","INFO_IMAGE":"Informações","COL_IMAGE":"Clicar para Reduzir"})