/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"单击此项以便按严重性进行排序","VALID_IMAGE":"验证","CONTAINER_CONTENT":"消息","WARNING_IMAGE":"警告","ERROR_IMAGE":"错误","CONTAINER_CONTENTS":"消息","CLEAR_TIME_SORT_IMAGE":"单击此项以清除按时间进行的排序","EXP_IMAGE":"单击此项以展开","CLEAR_SEV_SORT_IMAGE":"单击此项以清除按严重性进行的排序","TIME_SORT_IMAGE":"单击此项以便按时间进行排序","CLOSE_BUTTON":"关闭","INFO_IMAGE":"参考","COL_IMAGE":"单击此项以折叠"})