/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Klik om te sorteren op severity","VALID_IMAGE":"Validatie","CONTAINER_CONTENT":"Bericht","WARNING_IMAGE":"Waarschuwing","ERROR_IMAGE":"Fout","CONTAINER_CONTENTS":"Berichten","CLEAR_TIME_SORT_IMAGE":"Klik om sorteren op tijd te annuleren","EXP_IMAGE":"Klik om uit te vouwen","CLEAR_SEV_SORT_IMAGE":"Klik om sorteren op severity te annuleren","TIME_SORT_IMAGE":"Klik om te sorteren op tijd","CLOSE_BUTTON":"Sluiten","INFO_IMAGE":"Informatie","COL_IMAGE":"Klik om samen te vouwen"})