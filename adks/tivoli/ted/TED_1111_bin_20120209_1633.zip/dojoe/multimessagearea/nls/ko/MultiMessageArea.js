/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"심각도를 기준으로 정렬하려면 클릭","VALID_IMAGE":"유효성 검증","CONTAINER_CONTENT":"메시지","WARNING_IMAGE":"경고","ERROR_IMAGE":"오류","CONTAINER_CONTENTS":"메시지","CLEAR_TIME_SORT_IMAGE":"시간 기준 정렬을 지우려면 클릭","EXP_IMAGE":"펼치려면 클릭","CLEAR_SEV_SORT_IMAGE":"심각도 기준 정렬을 지우려면 클릭","TIME_SORT_IMAGE":"시간을 기준으로 정렬하려면 클릭","CLOSE_BUTTON":"닫기","INFO_IMAGE":"정보","COL_IMAGE":"접으려면 클릭"})