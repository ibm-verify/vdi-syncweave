/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Lajittele vakavuuden mukaan napsauttamalla","VALID_IMAGE":"Tarkistus","CONTAINER_CONTENT":"Sanoma","WARNING_IMAGE":"Varoitus","ERROR_IMAGE":"Virhe","CONTAINER_CONTENTS":"Sanomat","CLEAR_TIME_SORT_IMAGE":"Poista lajittelu ajan mukaan napsauttamalla","EXP_IMAGE":"Laajenna napsauttamalla","CLEAR_SEV_SORT_IMAGE":"Poista lajittelu vakavuuden mukaan napsauttamalla","TIME_SORT_IMAGE":"Lajittele ajan mukaan napsauttamalla","CLOSE_BUTTON":"Sulje","INFO_IMAGE":"Ilmoitus","COL_IMAGE":"Pienennä napsauttamalla"})