/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Zum Sortieren nach Bewertung klicken","VALID_IMAGE":"Überprüfung","CONTAINER_CONTENT":"Nachricht","WARNING_IMAGE":"Warnung","ERROR_IMAGE":"Fehler","CONTAINER_CONTENTS":"Nachrichten","CLEAR_TIME_SORT_IMAGE":"Zum Aufheben der Sortierung nach Uhrzeit klicken","EXP_IMAGE":"Zum Einblenden klicken","CLEAR_SEV_SORT_IMAGE":"Zum Aufheben der Sortierung nach Bewertung klicken","TIME_SORT_IMAGE":"Zum Sortieren nach Uhrzeit klicken","CLOSE_BUTTON":"Schließen","INFO_IMAGE":"Information","COL_IMAGE":"Zum Ausblenden klicken"})