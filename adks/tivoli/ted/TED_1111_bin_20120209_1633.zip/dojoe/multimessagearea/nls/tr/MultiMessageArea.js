/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Önem derecesine göre sıralamak için tıklatın","VALID_IMAGE":"Doğrulama","CONTAINER_CONTENT":"İleti","WARNING_IMAGE":"Uyarı","ERROR_IMAGE":"Hata","CONTAINER_CONTENTS":"İletiler","CLEAR_TIME_SORT_IMAGE":"Saate göre sıralamayı kaldırmak için tıklatın","EXP_IMAGE":"Genişletmek için tıklatın","CLEAR_SEV_SORT_IMAGE":"Önem derecesine göre sıralamayı kaldırmak için tıklatın","TIME_SORT_IMAGE":"Saate göre sıralamak için tıklatın","CLOSE_BUTTON":"Kapat","INFO_IMAGE":"Bilgi","COL_IMAGE":"Daraltmak için tıklatın"})