/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Klik za sort po ozbiljnosti","VALID_IMAGE":"Provjera","CONTAINER_CONTENT":"Poruka","WARNING_IMAGE":"Upozorenje","ERROR_IMAGE":"Greška","CONTAINER_CONTENTS":"Poruke","CLEAR_TIME_SORT_IMAGE":"Klik za brisanje sorta po vremenu","EXP_IMAGE":"Klik za proširenje","CLEAR_SEV_SORT_IMAGE":"Klik za brisanje sorta po ozbiljnosti","TIME_SORT_IMAGE":"Klik za sort po vremenu","CLOSE_BUTTON":"Zatvori","INFO_IMAGE":"Informacije","COL_IMAGE":"Klik za rušenje"})