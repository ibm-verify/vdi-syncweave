/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Klik for at sortere efter alvorlighed","VALID_IMAGE":"Validering","CONTAINER_CONTENT":"Meddelelse","WARNING_IMAGE":"Advarsel","ERROR_IMAGE":"Fejl","CONTAINER_CONTENTS":"Meddelelser","CLEAR_TIME_SORT_IMAGE":"Klik for at fjerne sortering efter klokkeslæt","EXP_IMAGE":"Klik for at udvide","CLEAR_SEV_SORT_IMAGE":"Klik for at fjerne sortering efter alvorlighed","TIME_SORT_IMAGE":"Klik for at sortere efter klokkeslæt","CLOSE_BUTTON":"Luk","INFO_IMAGE":"Oplysninger","COL_IMAGE":"Klik for at skjule"})