/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"按一下以依嚴重性排序","VALID_IMAGE":"驗證","CONTAINER_CONTENT":"訊息","WARNING_IMAGE":"警告","ERROR_IMAGE":"錯誤","CONTAINER_CONTENTS":"訊息","CLEAR_TIME_SORT_IMAGE":"按一下以清除依時間排序","EXP_IMAGE":"按一下以展開","CLEAR_SEV_SORT_IMAGE":"按一下以清除依嚴重性排序","TIME_SORT_IMAGE":"按一下以依時間排序","CLOSE_BUTTON":"關閉","INFO_IMAGE":"資訊","COL_IMAGE":"按一下以收合"})