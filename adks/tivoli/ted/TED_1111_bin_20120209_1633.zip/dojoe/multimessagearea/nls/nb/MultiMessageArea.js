/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"SEV_SORT_IMAGE":"Klikk for å sortere etter alvorsgrad","VALID_IMAGE":"Validering","CONTAINER_CONTENT":"Melding","WARNING_IMAGE":"Advarsel","ERROR_IMAGE":"Feil","CONTAINER_CONTENTS":"Meldinger","CLEAR_TIME_SORT_IMAGE":"Klikk for å fjerne sortering etter klokkeslett","EXP_IMAGE":"Klikk for å utvide","CLEAR_SEV_SORT_IMAGE":"Klikk for å fjerne sortering etter alvorsgrad","TIME_SORT_IMAGE":"Klikk for å sortere etter klokkeslett","CLOSE_BUTTON":"Lukk","INFO_IMAGE":"Informasjon","COL_IMAGE":"Klikk for å komprimere"})