/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.multimessagearea.Images"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.multimessagearea.Images"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.multimessagearea.Images");

// images cache
dojoe.multimessagearea.Images._images = 
{
    IMAGE_EXPAND:         dojo.moduleUrl("dojoe.common.themes.images", "plusButton.gif"),
    IMAGE_COLLAPSE:		  dojo.moduleUrl("dojoe.common.themes.images", "minusButton.gif"),	
	IMAGE_ERROR:		  dojo.moduleUrl("dojoe.common.themes.images", "critical.png"),	
	IMAGE_WARNING:		  dojo.moduleUrl("dojoe.common.themes.images", "warningMinor.png"),	
	IMAGE_INFO:		  	  dojo.moduleUrl("dojoe.common.themes.images", "info.png"),	
	IMAGE_CONFIRM:		  dojo.moduleUrl("dojoe.common.themes.images", "unknown.png"),	
	IMAGE_VALID:		  dojo.moduleUrl("dojoe.common.themes.images", "normal.png"),	
	IMAGE_SEVSORT:		  dojo.moduleUrl("dojoe.common.themes.images", "warningMajor.png"),
	IMAGE_TIMESORT:		  dojo.moduleUrl("dojoe.common.themes.images", "tc2.gif"),
	IMAGE_UPARROW:		  dojo.moduleUrl("dojoe.common.themes.images", "tbl23.gif"),
	IMAGE_DOWNARROW:      dojo.moduleUrl("dojoe.common.themes.images", "tbl29.gif"),
	////Bobby Joseph: 25Feb2011, adding close icon
	IMAGE_CLOSE:	      dojo.moduleUrl("dojoe.common.themes.images", "message_close.gif")	
};

dojoe.multimessagearea.Images.get = function() 
{
    return dojoe.multimessagearea.Images._images; 
};

}
