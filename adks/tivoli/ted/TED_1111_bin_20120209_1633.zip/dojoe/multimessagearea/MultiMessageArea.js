/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.multimessagearea.MultiMessageArea"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.multimessagearea.MultiMessageArea"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

dojo.provide("dojoe.multimessagearea.MultiMessageArea");

dojo.require("dojo.fx");
dojo.require("dojo.number");
dojo.require("dijit._Widget");
dojo.require("dijit._Templated");
dojo.require("dijit.layout.ContentPane");
dojo.require("dojox.json.query");
dojo.require("dojo.i18n");
dojo.require("dojoe.multimessagearea.Images");

//NLS
dojo.requireLocalization("dojoe.multimessagearea", "MultiMessageArea", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");
dojo.declare("dojoe.multimessagearea.MultiMessageArea",
		[dijit._Widget, dijit._Templated],
		{		
			/*Stores the JSON Array containing all the messages to be displayed*/
			message: "",		
			
			/*Flags used to determine if the sorting is to be done by Time/Severity*/
			timeSort: false,
			severitySort: false,		
			
			/*Variable to store the width of the container, default value : 100%*/
			containerWidth: "100%",		
			
			/*Flag used to determine if the container is expanded or collapsed on rendering*/
			open: false,	
			
		
			/********** PRIVATE *************/			
			/*Stores the Message Description*/
			_msgDesc: [],
			/*Stores the Message Id*/
			_msgId: [],

			
			//Bobby:02Mar2011, I don't see any use of this, the div will always have an Id
			/*Stores the ID of the MultiMessageArea Widget*/
			//_messageId: "multiMessageArea",
			
			/*Stores value of a SPAN element to be displayed*/
			_desc: null,
			/*Stores the Message Type*/
			_msgType: [],
			/*Variables used to store the relative path of Images to be used*/
			_imageSrcExp: dojoe.multimessagearea.Images.get()["IMAGE_EXPAND"],
			_imageSrcCon: dojoe.multimessagearea.Images.get()["IMAGE_COLLAPSE"],
			_imageError: dojoe.multimessagearea.Images.get()["IMAGE_ERROR"],
			_imageWarn: dojoe.multimessagearea.Images.get()["IMAGE_WARNING"],
			_imageInfo: dojoe.multimessagearea.Images.get()["IMAGE_INFO"],
			//_imageConf: dojoe.multimessagearea.Images.get()["IMAGE_CONFIRM"],
			_imageVal: dojoe.multimessagearea.Images.get()["IMAGE_VALID"],
			_imageSevSort: dojoe.multimessagearea.Images.get()["IMAGE_SEVSORT"],
			_imageTimeSort: dojoe.multimessagearea.Images.get()["IMAGE_TIMESORT"],
			_imageClose: dojoe.multimessagearea.Images.get()["IMAGE_CLOSE"],
			/*Stores the path to the template string*/
			templateString:"<div style=\"position:relative\" tabindex=\"0\">\r\n  <div class=\"dijitAccordionInnerContainer dijitAccordionInnerContainerSelected dijitSelected msgContainer\" \r\n\t\tid=\"${id}divElement\" dojoAttachPoint=\"divElement\" >\r\n    <div class=\"dijitAccordionTitle dijitAccordionTitleSelected dijitSelected msgAccordionText\">\r\n      <div scr=\"templates/images/blank.gif\" id=\"${id}imageSrc\" dojoAttachPoint=\"imageSrc\" \r\n\t\t\tclass=\"dijitTreeExpando dijitTreeExpandoClosed msgExpando\" \r\n\t\t\tdojoAttachEvent=\"onclick: _toggle,onkeydown:_toggle\" tabindex=\"0\" ></div>\r\n      <span dojoAttachPoint=\"msgContainer\" style=\"\" id=\"${id}msgContainer\" tabindex=\"0\" role=\"presentation\">\r\n        <span dojoAttachPoint=\"dupContainer\" style=\"\" id=\"${id}dupContainer\"> </span>\r\n      </span>\r\n      <div class=\"msgSorterBox\">\r\n        <img src=\"${_imageTimeSort}\" dojoAttachEvent=\"onclick: _timeSort,onkeydown:_timeSort\" tabindex=\"0\" id=\"${id}imageTime\" \r\n\t\t\tdojoAttachPoint=\"imageTime\" width=\"15px\" height=\"15px\" style=\"margin:0px\" role=\"button\"/>\r\n        <img src=\"${_imageSevSort}\" dojoAttachEvent=\"onclick: _sevSort,onkeydown:_sevSort\" tabindex=\"0\" id=\"${id}imageSev\" \r\n\t\t\tdojoAttachPoint=\"imageSev\" width=\"15px\" height=\"15px\" style=\"margin:0px\" role=\"button\"/> \r\n\t\t<!--Bobby Joseph: 25Feb2011, adding close icon -->\r\n\t\t<img src=\"${_imageClose}\" dojoAttachEvent=\"onclick: _close,onkeydown:_close\" tabindex=\"0\" id=\"${id}imageClose\" \r\n\t\t\tdojoAttachPoint=\"imageClose\" width=\"15px\" height=\"15px\" style=\"margin:0px\" title=\"${resources_.CLOSE_BUTTON}\" \r\n\t\t\talt=\"${resources_.CLOSE_BUTTON}\" role=\"button\"/> \r\n\t  </div>\t\t\r\n    </div>\r\n  </div>\r\n  <div dojoAttachPoint=\"hideNode\" id=\"${id}hideNode\">\r\n    <div dojoAttachPoint=\"wipeNode\" class=\"msg\" id=\"${id}msg\">\r\n      <div dojoAttachPoint=\"messagesAttach\" id=\"${id}message\"> </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n",
			/*Counters to determine count of each of the types of messages*/
			_err: 0,
			_warn: 0,
			_info: 0,
			//_conf: 0,
			_val: 0,
			/*Regular Expressions to match the inputs passed for message type*/
			_errMsg: "",
			_warnMsg: "",
			_infoMsg: "",
			//_confMsg: "",
			_valMsg: "",

			_toSort: false,
			_sortedSev: 0,
			
			// anurag : this holds the summary of all the messages or header information
			_summaryMsg:"",
			/*Flag used to determine if the expand/collapse image is clicked*/
			_oneClick: false,
			/*Determines the duration of the animation wipe in/wipe out element, Time in milliseconds*/
			_duration: 500,
			/*resourceMessages_: JSON Resource bundle*/
			resources_: "",
			/*Flag to determine if there are any messages*/
			_isEmpty: false,

			constructor: function()
			{
				//Regular Expressions to match message type for a given message
				this._errMsg = new RegExp('(^| )' + "(e|E)(r|R)(r|R)(o|O)(r|R)" + '( |$)');
				this._warnMsg = new RegExp('(^| )' + "(w|W)(a|A)(r|R)(n|N)" + '( |$)'); 
				this._infoMsg = new RegExp('(^| )' + "(i|I)(n|N)(f|F)(o|O)" + '( |$)');
				//this._confMsg = new RegExp('(^| )' + "(c|C)(o|O)(n|N)(f|F)" + '( |$)');
				this._valMsg = new RegExp('(^| )' + "(v|V)(a|A)(l|L)" + '( |$)');
				//NLS
				this.resources_ = dojo.i18n.getLocalization("dojoe.multimessagearea", "MultiMessageArea",this.lang);
			},
			
			/* Setup initial styles and state of the widget *
			 * Create and save all animations *
			 * Determine the type of sorting */
			postCreate: function()
			{					
				if( !this.open)
				{
					this.hideNode.style.display = this.wipeNode.style.display = "none";
					this._updateClass();
					this._oneClick = true;
				}else{
					this._updateClass();
					this._oneClick = true;					
				}
				
				this.inherited("postCreate",arguments);				    
				
			    // setup open/close animations
				var hideNode = this.hideNode, 
					wipeNode = this.wipeNode;
					
				this._wipeIn = dojo.fx.wipeIn({
				  node: this.wipeNode,
				  duration: this._duration,
				  beforeBegin: function(){
					hideNode.style.display="";
				  }
				});
				
				this._wipeOut = dojo.fx.wipeOut({
				  node: this.wipeNode,
				  duration: this._duration,
				  onEnd: function(){
					hideNode.style.display="";
				  }
				});
				
				//To Validate the Messages
				this._validateMessages();
				
				//Setting Container Width for the Widget
				this.domNode.style.width = this.containerWidth;
				
				//Setting the titles for the images in the container
				/*if(this.open){
					this.imageSrc.setAttribute("title", this.resources_.COL_IMAGE);
				}else{
					this.imageSrc.setAttribute("title", this.resources_.EXP_IMAGE);
				}*/
				
				//this.imageSev.setAttribute("title", this.resources_.SEV_SORT_IMAGE);
				//this.imageTime.setAttribute("title", this.resources_.TIME_SORT_IMAGE);
				
				//Bobby:06Jul11, following will be set via template
				//this.imageClose.setAttribute("alt", this.resources_.CLOSE_BUTTON);
				
				/*Checks to determine if sorting needs to be done based on Time/Severity of the widget must be destroyed*/
				if(this.timeSort && this.message != ""){
					//this.domNode.style.display = 'inline';
					this.sortByTime();
				} else if(this.severitySort && this.message != ""){
					//this.domNode.style.display = 'inline';
					this.sortBySeverity();
				} else {
					//this.domNode.style.display = 'none';
					
					//Bobby: 03Mar2011
					//First sorting by sev, temp fix, should be removed later.
					//else getting an exception, if initially noSort and then sorted by Time (sev works)
					this.sortBySeverity();
					this._toSort = true;				
					
					this._noSort();
					this.severitySort = false;
					this.timeSort = false;
				}
				this._updateHeader();
			},

			/* This method will set the aria-label attribute for the header.*/
			_updateHeader: function(){
				var list = dojox.json.query("=$.[?msgType='*']", this.message);
				var summaryMessage = this.resources_.CONTAINER_CONTENT + ": " + dojo.number.format(list.length)
				console.log("summaryMessage_uh : " + summaryMessage);
				console.debug(list);
				if(this.open)
					this.msgContainer.setAttribute("aria-label", summaryMessage);
				else 
					this.msgContainer.setAttribute("aria-label", summaryMessage + " - " + this._summaryMsg);
			},
			
			_noSort: function(){
			 this._summaryMsg = "";
				if(this._toSort)
				{
					node = this.wipeNode;
					container = this.msgContainer;
					replaceNode = dojo.doc.createElement('div');
					replaceContainer = dojo.doc.createElement('span');
					replaceNode.setAttribute("id", this.id + "replaceNode");
					replaceContainer.setAttribute("id", this.id + "replaceContainer");
					if(this.severitySort && this._sortedSev == 0){
						node.replaceChild(replaceNode, this.messagesAttach);
						container.replaceChild(replaceContainer, this.dupContainer);
						this._sortedSev = 1;
					} else {
						node.replaceChild(replaceNode, dojo.byId(this.id + 'replaceNode'));
						container.replaceChild(replaceContainer, dojo.byId(this.id + 'replaceContainer'));
					}
				}
				
				var list = dojox.json.query("=$.[?msgType='*']", this.message);
				for(var i=0 ; i < list.length ; i++){
					this._msgDesc[i] = dojox.json.query("[" + i + "].msgDesc", list);
					this._msgType[i] = dojox.json.query("[" + i + "].msgType", list);
					this._msgId[i] = dojox.json.query("[" + i + "].msgId", list);
				}
				/*Appending text into 'msgContainer' element*/
				spanChild = dojo.doc.createElement('span');
				if(list.length == 1)
					//spanChild.innerHTML = this.resources_.CONTAINER_CONTENT + " : " + list.length + "&nbsp";	
					spanChild.innerHTML = this.resources_.CONTAINER_CONTENT + ": " + dojo.number.format(list.length) + "&nbsp";	
				else
					//spanChild.innerHTML = this.resources_.CONTAINER_CONTENTS + " : " + list.length + "&nbsp";	
					spanChild.innerHTML = this.resources_.CONTAINER_CONTENTS + ": " + dojo.number.format(list.length) + "&nbsp";	
				if(this._toSort)
					replaceContainer.appendChild(spanChild);
				else
					this.dupContainer.appendChild(spanChild);
				spanChild.style.verticalAlign="middle";
				spanContainer = dojo.doc.createElement('span');
				spanContainer.setAttribute("id", this.id + "spanContainer");
				if(!this.open)
					spanContainer.setAttribute("style", "display:inline;");
				else
					spanContainer.setAttribute("style", "display:none");
				msgCount = dojo.doc.createElement('span');
				msgCount.innerHTML = "&nbsp - &nbsp";
				spanContainer.appendChild(msgCount);
				msgCount.style.verticalAlign="middle";
				/*Rendering each of the types of messages to the expand/collapse element 'wipeNode'*/
				for(var i=0; i < list.length; i++){
					newNode = dojo.doc.createElement('div');
					newNode.dojoType = "dijit.layout.ContentPane";
					if(this._errMsg.test(this._msgType[i])) {
						/*Error Messages*/
						this._err++;
						//newNode.setAttribute("class", "msgerr");
						dojo.addClass(newNode, "msgerr");
						newNode.setAttribute("id", this.id+"_msgerr_" + i);
						if ( this._imageError !== null )
						{
							var image = dojo.doc.createElement( 'img' );
							image.src = this._imageError;
							image.border = "0";
							image.width = "15";
							image.height = "15";
							image.style.marginTop="3px";
							image.setAttribute("id", this.id+"_msgerr_img_" + i);
							image.setAttribute("alt", this.resources_.ERROR_IMAGE);
							image.setAttribute("title", this.resources_.ERROR_IMAGE);
						}
						desc = dojo.doc.createElement( 'span' );
						desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
						if(this._toSort)
							replaceNode.appendChild(newNode);
						else
							this.messagesAttach.appendChild(newNode);
						newNode.appendChild(desc);						
						newNode.appendChild(image);
						desc = dojo.doc.createElement( 'span' );
						desc.setAttribute("tabindex","0");
						desc.setAttribute("role","presentation");
						desc.setAttribute("aria-label", this.resources_.ERROR_IMAGE + " " + this._msgId[i] + ": " + this._msgDesc[i]);
						//desc.innerHTML = "&nbsp  " + this._msgId[i] + " &nbsp : &nbsp " + this._msgDesc[i];
						desc.innerHTML = "&nbsp  " + this._msgId[i] + ": " + this._msgDesc[i];
						newNode.appendChild(desc);
					} else if(this._warnMsg.test(this._msgType[i])) {
						/*Warning Messages*/
						this._warn++;
						//newNode.setAttribute("class", "msgwarn");
						dojo.addClass(newNode, "msgwarn");
						newNode.setAttribute("id", this.id+"_msgwarn_" + i);
						if ( this._imageWarn !== null )
						{
							var image = dojo.doc.createElement( 'img' );
							image.src = this._imageWarn;
							image.border = "0";
							image.width = "15";
							image.height = "15";
							image.style.marginTop="3px";
							image.setAttribute("id", this.id+"_msgwarn_img_" + i);
							image.setAttribute("alt", this.resources_.WARNING_IMAGE);
							image.setAttribute("title", this.resources_.WARNING_IMAGE);
						}
						desc = dojo.doc.createElement( 'span' );
						desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
						if(this._toSort)
							replaceNode.appendChild(newNode);
						else
							this.messagesAttach.appendChild(newNode);
						newNode.appendChild(desc);						
						newNode.appendChild(image);
						desc = dojo.doc.createElement( 'span' );
						// anurag : setting the tabindex to make it keyboard accessible 
						// aria-label informs user about the type of message and content.
						// These changes are done for all message types.
						desc.setAttribute("tabindex","0");
						desc.setAttribute("role","presentation");
						desc.setAttribute("aria-label", this.resources_.WARNING_IMAGE + " " + this._msgId[i] + ": " + this._msgDesc[i]);
						desc.innerHTML = "&nbsp  " + this._msgId[i] + ": " +this._msgDesc[i];
						newNode.appendChild(desc);
					} else if(this._infoMsg.test(this._msgType[i])) {
						/*Information Messages*/
						this._info++;
						//newNode.setAttribute("class", "msginfo");
						dojo.addClass(newNode, "msginfo");
						newNode.setAttribute("id", this.id+"_msginfo_" + i);
						if ( this._imageInfo !== null )
						{
							var image = dojo.doc.createElement( 'img' );
							image.src = this._imageInfo;
							image.border = "0";
							image.width = "15";
							image.height = "15";
							image.style.marginTop="3px";
							image.setAttribute("id", this.id+"_msginfo_img_" + i);
							image.setAttribute("alt", this.resources_.INFO_IMAGE);
							image.setAttribute("title", this.resources_.INFO_IMAGE);
						}
						desc = dojo.doc.createElement( 'span' );
						desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
						if(this._toSort)
							replaceNode.appendChild(newNode);
						else
							this.messagesAttach.appendChild(newNode);
						newNode.appendChild(desc);						
						newNode.appendChild(image);
						desc = dojo.doc.createElement( 'span' );
						desc.setAttribute("tabindex","0");
						desc.setAttribute("role","presentation");
						desc.setAttribute("aria-label", this.resources_.INFO_IMAGE + " " + this._msgId[i] + ": " + this._msgDesc[i]);
						desc.innerHTML = "&nbsp  " + this._msgId[i] + ": " +this._msgDesc[i];
						newNode.appendChild(desc);
					} /*else if(this._confMsg.test(this._msgType[i])) {
						//Confirmation Messages
						this._conf++;
						//newNode.setAttribute("class", "msgconf");
						dojo.addClass(newNode, "msgconf");
						newNode.setAttribute("id", "msgconf" + i);
						if ( this._imageConf !== null )
						{
						    var image = dojo.doc.createElement( 'img' );
						    image.src = this._imageConf;
						    image.border = "0";
						    image.width = "15";
						    image.height = "15";
							image.style.marginTop="3px";
							image.setAttribute("id", "msgconf" + i);
							image.setAttribute("title", this.resources_.CONFIRM_IMAGE);
						}
						desc = dojo.doc.createElement( 'span' );
						desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
						if(this._toSort)
							replaceNode.appendChild(newNode);
						else
							this.messagesAttach.appendChild(newNode);
						newNode.appendChild(desc);						
						newNode.appendChild(image);
						desc = dojo.doc.createElement( 'span' );
						desc.innerHTML = "&nbsp  " + this._msgId[i] + " &nbsp : &nbsp " + this._msgDesc[i];
						newNode.appendChild(desc);
					}*/ else if(this._valMsg.test(this._msgType[i])) {
						/*Validation Messages*/
						this._val++;
						//newNode.setAttribute("class", "msgval");
						dojo.addClass(newNode, "msgval");
						newNode.setAttribute("id", this.id+"_msgval_" + i);
						if ( this._imageVal !== null )
						{
							var image = dojo.doc.createElement( 'img' );
							image.src = this._imageVal;
							image.border = "0";
							image.width = "15";
							image.height = "15";
							image.style.marginTop="3px";
							image.setAttribute("id", this.id+"_msgval_img_" + i);
							image.setAttribute("alt", this.resources_.VALID_IMAGE);
							image.setAttribute("title", this.resources_.VALID_IMAGE);
						}
						desc = dojo.doc.createElement( 'span' );
						desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
						if(this._toSort)
							replaceNode.appendChild(newNode);
						else
							this.messagesAttach.appendChild(newNode);
						newNode.appendChild(desc);						
						newNode.appendChild(image);
						desc = dojo.doc.createElement( 'span' );
						desc.setAttribute("tabindex","0");
						desc.setAttribute("role","presentation");
						desc.setAttribute("aria-label", this.resources_.VALID_IMAGE + " " + this._msgId[i] + ": " + this._msgDesc[i]);
						desc.innerHTML = "&nbsp  " + this._msgId[i] + ": " +this._msgDesc[i];
						newNode.appendChild(desc);
					}
				}
				/*Rendering the image based on type of message and providing details about number of messages of that type*/
				if( this._err > 0 ){
					/*error messages*/
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageError;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", this.id+"_msgerr");
					imageContainer.setAttribute("alt", this.resources_.ERROR_IMAGE);
					imageContainer.setAttribute("title", this.resources_.ERROR_IMAGE);
					//msgCount.innerHTML = "&nbsp : &nbsp " + this._err + " &nbsp";
					msgCount.innerHTML = ":" + this._err + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(!this.open)
						spanContainer.setAttribute("style", "display:inline");
					else
						spanContainer.setAttribute("style", "display:none");
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
				}
				if( this._warn > 0 ){
					/*warning messages*/
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageWarn;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", this.id+"_msgwarn");
					imageContainer.setAttribute("alt", this.resources_.WARNING_IMAGE);
					imageContainer.setAttribute("title", this.resources_.WARNING_IMAGE);
					msgCount.innerHTML = ":" + this._warn + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(!this.open)
						spanContainer.setAttribute("style", "display:inline");
					else
						spanContainer.setAttribute("style", "display:none");
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
				}
				if( this._info > 0 ){
					/*information messages*/
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageInfo;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", this.id+"_msginfo");
					imageContainer.setAttribute("alt", this.resources_.INFO_IMAGE);
					imageContainer.setAttribute("title", this.resources_.INFO_IMAGE);
					msgCount.innerHTML = ":" + this._info + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(!this.open)
						spanContainer.setAttribute("style", "display:inline");
					else
						spanContainer.setAttribute("style", "display:none");
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
				}
				/*if( this._conf > 0 ){
					//confirmation messages
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageConf;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", "msgconf");
					imageContainer.setAttribute("title", this.resources_.CONFIRM_IMAGE);
					msgCount.innerHTML = "&nbsp : &nbsp " + this._conf + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(!this.open)
						spanContainer.setAttribute("style", "display:inline");
					else
						spanContainer.setAttribute("style", "display:none");
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
				}*/
				if( this._val > 0 ){
					/*validation messages*/
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageVal;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", this.id+"_msgval");
					imageContainer.setAttribute("alt", this.resources_.VALID_IMAGE);
					imageContainer.setAttribute("title", this.resources_.VALID_IMAGE);
					msgCount.innerHTML = ":" + this._val + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(!this.open)
						spanContainer.setAttribute("style", "display:inline");
					else
						spanContainer.setAttribute("style", "display:none");
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
				}
				msgCount = dojo.doc.createElement('span');
				msgCount.innerHTML = "";
				spanContainer.appendChild(msgCount);
				msgCount.style.verticalAlign="middle";
				this._summaryMsg = this.resources_.ERROR_IMAGE + ":" + this._err + 
								  this.resources_.WARNING_IMAGE + ":" + this._warn + 
								  this.resources_.INFO_IMAGE + ":" + this._info + 
								  this.resources_.VALID_IMAGE + ":" + this._val;
				                
				if(this._toSort)
					this.wipeNode.appendChild(replaceNode);
				this._err = 0;
				this._warn = 0;
				this._info = 0;
				this._conf = 0;
				this._val = 0;
				
				this.timeSort = false;
				this.severitySort = false;
				this.imageSev.setAttribute("alt", this.resources_.SEV_SORT_IMAGE);				
				this.imageSev.setAttribute("title", this.resources_.SEV_SORT_IMAGE);				
				this.imageTime.setAttribute("alt", this.resources_.TIME_SORT_IMAGE);				
				this.imageTime.setAttribute("title", this.resources_.TIME_SORT_IMAGE);			
			},			
			
			sortByTime: function(){
				this_summaryMsg="";
				/*To alter contents of 'wipeNode' by sorting by Time*/
				//if(this.timeSort && this._toSort)
				if(this._toSort)
				{
					node = this.wipeNode;
					container = this.msgContainer;
					replaceNode = dojo.doc.createElement('div');
					replaceContainer = dojo.doc.createElement('span');
					replaceNode.setAttribute("id", this.id + "replaceNode");
					replaceContainer.setAttribute("id", this.id + "replaceContainer");
					if(this.severitySort && this._sortedSev == 0){
						node.replaceChild(replaceNode, this.messagesAttach);
						container.replaceChild(replaceContainer, this.dupContainer);
						this._sortedSev = 1;
					} else {
						node.replaceChild(replaceNode, dojo.byId(this.id + 'replaceNode'));
						container.replaceChild(replaceContainer, dojo.byId(this.id + 'replaceContainer'));
					}
				}
				/*Sorting Message based on Time field from JSON Array*/
				var list = dojox.json.query("=$.[?msgType='*'][/time]", this.message);
				for(var i=0 ; i < list.length ; i++){
					this._msgDesc[i] = dojox.json.query("[" + i + "].msgDesc", list);
					this._msgType[i] = dojox.json.query("[" + i + "].msgType", list);
					this._msgId[i] = dojox.json.query("[" + i + "].msgId", list);
				}
				/*Appending text into 'msgContainer' element*/
				spanChild = dojo.doc.createElement('span');
				if(list.length == 1)
					//spanChild.innerHTML = this.resources_.CONTAINER_CONTENT + " : " + list.length + "&nbsp";	
					spanChild.innerHTML = this.resources_.CONTAINER_CONTENT + ": " + dojo.number.format(list.length) + "&nbsp";	
				else
					//spanChild.innerHTML = this.resources_.CONTAINER_CONTENTS + " : " + list.length + "&nbsp";	
					spanChild.innerHTML = this.resources_.CONTAINER_CONTENTS + ": " + dojo.number.format(list.length) + "&nbsp";	
				if(this._toSort)
					replaceContainer.appendChild(spanChild);
				else
					this.dupContainer.appendChild(spanChild);
				spanChild.style.verticalAlign="middle";
				spanContainer = dojo.doc.createElement('span');
				spanContainer.setAttribute("id", this.id + "spanContainer");
				if(!this.open)
					spanContainer.setAttribute("style", "display:inline;");
				else
					spanContainer.setAttribute("style", "display:none");
				msgCount = dojo.doc.createElement('span');
				msgCount.innerHTML = "&nbsp - &nbsp";
				spanContainer.appendChild(msgCount);
				msgCount.style.verticalAlign="middle";
				/*Rendering each of the types of messages to the expand/collapse element 'wipeNode'*/
				for(var i=0; i < list.length; i++){
					newNode = dojo.doc.createElement('div');
					newNode.dojoType = "dijit.layout.ContentPane";
					if(this._errMsg.test(this._msgType[i])) {
						/*Error Messages*/
						this._err++;
						//newNode.setAttribute("class", "msgerr");
						dojo.addClass(newNode, "msgerr");
						newNode.setAttribute("id", this.id+"_msgerr_" + i);
						if ( this._imageError !== null )
						{
							var image = dojo.doc.createElement( 'img' );
							image.src = this._imageError;
							image.border = "0";
							image.width = "15";
							image.height = "15";
							image.style.marginTop="3px";
							image.setAttribute("id", this.id+"_msgerr_img_" + i);
							image.setAttribute("alt", this.resources_.ERROR_IMAGE);
							image.setAttribute("title", this.resources_.ERROR_IMAGE);
						}
						desc = dojo.doc.createElement( 'span' );
						desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
						if(this._toSort)
							replaceNode.appendChild(newNode);
						else
							this.messagesAttach.appendChild(newNode);
						newNode.appendChild(desc);						
						newNode.appendChild(image);
						desc = dojo.doc.createElement( 'span' );
						//desc.innerHTML = "&nbsp  " + this._msgId[i] + " &nbsp : &nbsp " + this._msgDesc[i];
						desc.setAttribute("tabindex","0");
						desc.setAttribute("role","presentation");
						desc.setAttribute("aria-label", this.resources_.ERROR_IMAGE + " " + this._msgId[i] + ": " + this._msgDesc[i]);
						desc.innerHTML = "&nbsp  " + this._msgId[i] + ": " + this._msgDesc[i];
						newNode.appendChild(desc);
					} else if(this._warnMsg.test(this._msgType[i])) {
						/*Warning Messages*/
						this._warn++;
						//newNode.setAttribute("class", "msgwarn");
						dojo.addClass(newNode, "msgwarn");
						newNode.setAttribute("id", this.id+"_msgwarn_" + i);
						if ( this._imageWarn !== null )
						{
							var image = dojo.doc.createElement( 'img' );
							image.src = this._imageWarn;
							image.border = "0";
							image.width = "15";
							image.height = "15";
							image.style.marginTop="3px";
							image.setAttribute("id", this.id+"_msgwarn_img_" + i);
							image.setAttribute("alt", this.resources_.WARNING_IMAGE);
							image.setAttribute("title", this.resources_.WARNING_IMAGE);
						}
						desc = dojo.doc.createElement( 'span' );
						desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
						if(this._toSort)
							replaceNode.appendChild(newNode);
						else
							this.messagesAttach.appendChild(newNode);
						newNode.appendChild(desc);						
						newNode.appendChild(image);
						desc = dojo.doc.createElement( 'span' );
						desc.setAttribute("tabindex","0");
						desc.setAttribute("role","presentation");
						desc.setAttribute("aria-label", this.resources_.WARNING_IMAGE + " " + this._msgId[i] + ": " + this._msgDesc[i]);
						desc.innerHTML = "&nbsp  " + this._msgId[i] + ": " +this._msgDesc[i];
						newNode.appendChild(desc);
					} else if(this._infoMsg.test(this._msgType[i])) {
						/*Information Messages*/
						this._info++;
						//newNode.setAttribute("class", "msginfo");
						dojo.addClass(newNode, "msginfo");
						newNode.setAttribute("id", this.id+"_msginfo_" + i);
						if ( this._imageInfo !== null )
						{
							var image = dojo.doc.createElement( 'img' );
							image.src = this._imageInfo;
							image.border = "0";
							image.width = "15";
							image.height = "15";
							image.style.marginTop="3px";
							image.setAttribute("id", this.id+"_msginfo_img_" + i);
							image.setAttribute("alt", this.resources_.INFO_IMAGE);
							image.setAttribute("title", this.resources_.INFO_IMAGE);
						}
						desc = dojo.doc.createElement( 'span' );
						desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
						if(this._toSort)
							replaceNode.appendChild(newNode);
						else
							this.messagesAttach.appendChild(newNode);
						newNode.appendChild(desc);						
						newNode.appendChild(image);
						desc = dojo.doc.createElement( 'span' );
						desc.setAttribute("tabindex","0");
						desc.setAttribute("role","presentation");
						desc.setAttribute("aria-label", this.resources_.INFO_IMAGE + " " + this._msgId[i] + ": " + this._msgDesc[i]);
						desc.innerHTML = "&nbsp  " + this._msgId[i] + ": " +this._msgDesc[i];
						newNode.appendChild(desc);
					} /*else if(this._confMsg.test(this._msgType[i])) {
						//Confirmation Messages
						this._conf++;
						//newNode.setAttribute("class", "msgconf");
						dojo.addClass(newNode, "msgconf");
						newNode.setAttribute("id", "msgconf" + i);
						if ( this._imageConf !== null )
						{
						    var image = dojo.doc.createElement( 'img' );
						    image.src = this._imageConf;
						    image.border = "0";
						    image.width = "15";
						    image.height = "15";
							image.style.marginTop="3px";
							image.setAttribute("id", "msgconf" + i);
							image.setAttribute("title", this.resources_.CONFIRM_IMAGE);
						}
						desc = dojo.doc.createElement( 'span' );
						desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
						if(this._toSort)
							replaceNode.appendChild(newNode);
						else
							this.messagesAttach.appendChild(newNode);
						newNode.appendChild(desc);						
						newNode.appendChild(image);
						desc = dojo.doc.createElement( 'span' );
						desc.innerHTML = "&nbsp  " + this._msgId[i] + " &nbsp : &nbsp " + this._msgDesc[i];
						newNode.appendChild(desc);
					}*/ else if(this._valMsg.test(this._msgType[i])) {
						/*Validation Messages*/
						this._val++;
						//newNode.setAttribute("class", "msgval");
						dojo.addClass(newNode, "msgval");
						newNode.setAttribute("id", this.id+"_msgval_" + i);
						if ( this._imageVal !== null )
						{
							var image = dojo.doc.createElement( 'img' );
							image.src = this._imageVal;
							image.border = "0";
							image.width = "15";
							image.height = "15";
							image.style.marginTop="3px";
							image.setAttribute("id", this.id+"_msgval_img_" + i);
							image.setAttribute("alt", this.resources_.VALID_IMAGE);
							image.setAttribute("title", this.resources_.VALID_IMAGE);
						}
						desc = dojo.doc.createElement( 'span' );
						desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
						if(this._toSort)
							replaceNode.appendChild(newNode);
						else
							this.messagesAttach.appendChild(newNode);
						newNode.appendChild(desc);						
						newNode.appendChild(image);
						desc = dojo.doc.createElement( 'span' );
						desc.setAttribute("tabindex","0");
						desc.setAttribute("role","presentation");
						desc.setAttribute("aria-label", this.resources_.VALID_IMAGE +  " " + this._msgId[i] + ": " + this._msgDesc[i]);
						desc.innerHTML = "&nbsp  " + this._msgId[i] + ": " +this._msgDesc[i];
						newNode.appendChild(desc);
					}
				}
				/*Rendering the image based on type of message and providing details about number of messages of that type*/
				if( this._err > 0 ){
					/*error messages*/
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageError;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", this.id+"_msgerr");
					imageContainer.setAttribute("alt", this.resources_.ERROR_IMAGE);
					imageContainer.setAttribute("title", this.resources_.ERROR_IMAGE);
					//msgCount.innerHTML = "&nbsp : &nbsp " + this._err + " &nbsp";
					msgCount.innerHTML = ":" + this._err + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(!this.open)
						spanContainer.setAttribute("style", "display:inline");
					else
						spanContainer.setAttribute("style", "display:none");
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
				}
				if( this._warn > 0 ){
					/*warning messages*/
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageWarn;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", this.id+"_msgwarn");
					imageContainer.setAttribute("alt", this.resources_.WARNING_IMAGE);
					imageContainer.setAttribute("title", this.resources_.WARNING_IMAGE);
					msgCount.innerHTML = ":" + this._warn + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(!this.open)
						spanContainer.setAttribute("style", "display:inline");
					else
						spanContainer.setAttribute("style", "display:none");
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
				}
				if( this._info > 0 ){
					/*information messages*/
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageInfo;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", this.id+"_msginfo");
					imageContainer.setAttribute("alt", this.resources_.INFO_IMAGE);
					imageContainer.setAttribute("title", this.resources_.INFO_IMAGE);
					msgCount.innerHTML = ":" + this._info + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(!this.open)
						spanContainer.setAttribute("style", "display:inline");
					else
						spanContainer.setAttribute("style", "display:none");
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
				}
				/*if( this._conf > 0 ){
					//confirmation messages
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageConf;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", "msgconf");
					imageContainer.setAttribute("title", this.resources_.CONFIRM_IMAGE);
					msgCount.innerHTML = "&nbsp : &nbsp " + this._conf + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(!this.open)
						spanContainer.setAttribute("style", "display:inline");
					else
						spanContainer.setAttribute("style", "display:none");
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
				}*/
				if( this._val > 0 ){
					/*validation messages*/
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageVal;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", this.id+"_msgval");
					imageContainer.setAttribute("alt", this.resources_.VALID_IMAGE);
					imageContainer.setAttribute("title", this.resources_.VALID_IMAGE);
					msgCount.innerHTML = ":" + this._val + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(!this.open)
						spanContainer.setAttribute("style", "display:inline");
					else
						spanContainer.setAttribute("style", "display:none");
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
				}
				msgCount = dojo.doc.createElement('span');
				msgCount.innerHTML = "";
				spanContainer.appendChild(msgCount);
				msgCount.style.verticalAlign="middle";
				if(this._toSort)
					this.wipeNode.appendChild(replaceNode);
				
				// anurag :  JAWS wasn't reading the details when multiMessageArea was collapsed.
				this._summaryMsg = this.resources_.ERROR_IMAGE + ":" + this._err + 
								  this.resources_.WARNING_IMAGE + ":" + this._warn + 
								  this.resources_.INFO_IMAGE + ":" + this._info + 
								  this.resources_.VALID_IMAGE + ":" + this._val;		
				
				this._err = 0;
				this._warn = 0;
				this._info = 0;
				this._conf = 0;
				this._val = 0;
				
				this.timeSort = true;
				this.severitySort = false;
				this.imageTime.setAttribute("alt", this.resources_.CLEAR_TIME_SORT_IMAGE);	
				this.imageTime.setAttribute("title", this.resources_.CLEAR_TIME_SORT_IMAGE);	
				this.imageSev.setAttribute("alt", this.resources_.SEV_SORT_IMAGE);
				this.imageSev.setAttribute("title", this.resources_.SEV_SORT_IMAGE);
			},
			
			sortBySeverity: function(){
				this._summaryMsg="";
				/*To alter contents of 'wipeNode' by sorting by Time*/
				//if(!this.timeSort && this._toSort)
				if(this._toSort)
				{
					node = this.wipeNode;
					container = this.msgContainer;
					replaceNode = dojo.doc.createElement('div');
					replaceContainer = dojo.doc.createElement('span');
					replaceNode.setAttribute("id", this.id + "replaceNode");
					replaceContainer.setAttribute("id", this.id + "replaceContainer");
					if(this._sortedSev == 0){
						node.replaceChild(replaceNode, this.messagesAttach);
						container.replaceChild(replaceContainer, this.dupContainer);
						this._sortedSev = 1;
					} else {
						node.replaceChild(replaceNode, dojo.byId(this.id + 'replaceNode'));
						container.replaceChild(replaceContainer, dojo.byId(this.id + 'replaceContainer'));
					}
				}
				/*Sorting Message based on Severity field from JSON Array*/
				var list = dojox.json.query("=$.[?msgType='*']", this.message);
				spanChild = dojo.doc.createElement('span');
				/*Appending text into 'msgContainer' element*/
				if(list.length == 1)
					spanChild.innerHTML = this.resources_.CONTAINER_CONTENT + ": " + dojo.number.format(list.length) + "&nbsp";	
				else
					spanChild.innerHTML = this.resources_.CONTAINER_CONTENTS + ": " + dojo.number.format(list.length) + "&nbsp";
				if(this._toSort)
					replaceContainer.appendChild(spanChild);
				else
					this.dupContainer.appendChild(spanChild);
				spanChild.style.verticalAlign="middle";
				spanContainer = dojo.doc.createElement('span');
				spanContainer.setAttribute("id", this.id + "spanContainer");
				if(!this.open)
					spanContainer.setAttribute("style", "display:inline;");
				else
					spanContainer.setAttribute("style", "display:none;");
				msgCount = dojo.doc.createElement('span');
				msgCount.innerHTML = "&nbsp - &nbsp";
				spanContainer.appendChild(msgCount);
				msgCount.style.verticalAlign="middle";
				/*Rendering each of the types of messages to the expand/collapse element 'wipeNode'*/
				/*Rendering the image based on type of message and providing details about number of messages of that type*/
				
				/*Error Messages*/
				var list = dojox.json.query("=$.[?msgType~'error'][/severity][/msgId]", this.message);
				for(var i=0 ; i < list.length ; i++){
					this._msgDesc[i] = dojox.json.query("[" + i  + "].msgDesc", list);
					this._msgId[i] = dojox.json.query("[" + i + "].msgId", list);
				}
				if( list.length > 0 ){
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageError;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", this.id+"_msgerr");
					imageContainer.setAttribute("alt", this.resources_.ERROR_IMAGE);
					imageContainer.setAttribute("title", this.resources_.ERROR_IMAGE);
					msgCount.innerHTML = ":" + dojo.number.format(list.length) + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
					this._summaryMsg = this._summaryMsg + this.resources_.ERROR_IMAGE + ":" + dojo.number.format(list.length);
				}
				for(var i=0; i < list.length; i++){											
					newNode = dojo.doc.createElement('div');
					newNode.dojoType = "dijit.layout.ContentPane";
					//newNode.setAttribute("class", "msgerr");
					dojo.addClass(newNode, "msgerr");
					newNode.setAttribute("id", this.id+"_msgerr_" + i);
					if ( this._imageError !== null )
					{
						var image = dojo.doc.createElement( 'img' );
						image.src = this._imageError;
						image.border = "0";
						image.width = "15";
						image.height = "15";
						image.style.marginTop="3px";
						image.setAttribute("id", this.id+"_msgerr_img_" + i);
						image.setAttribute("alt", this.resources_.ERROR_IMAGE);
						image.setAttribute("title", this.resources_.ERROR_IMAGE);
					}
					desc = dojo.doc.createElement( 'span' );
					desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
					if(this._toSort)
						replaceNode.appendChild(newNode);
					else
						this.messagesAttach.appendChild(newNode);
					newNode.appendChild(desc);						
					newNode.appendChild(image);
					desc = dojo.doc.createElement( 'span' );
					desc.setAttribute("tabindex","0");
					desc.setAttribute("role","presentation");
					desc.setAttribute("aria-label",this.resources_.ERROR_IMAGE + " " + this._msgId[i] + ": " +this._msgDesc[i]);
					desc.innerHTML = "&nbsp  " + this._msgId[i] + ": " +this._msgDesc[i];
					newNode.appendChild(desc);
				}
				
				/*Warning Messages*/				
				var list = dojox.json.query("=$.[?msgType~'warn'][/severity][/msgId]", this.message);
				for(var i=0 ; i < list.length ; i++){
					this._msgDesc[i] = dojox.json.query("[" + i + "].msgDesc", list);
					this._msgId[i] = dojox.json.query("[" + i + "].msgId", list);
				}
				if( list.length > 0 ){
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageWarn;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", this.id+"_msgwarn");
					imageContainer.setAttribute("alt", this.resources_.WARNING_IMAGE);
					imageContainer.setAttribute("title", this.resources_.WARNING_IMAGE);
					msgCount.innerHTML = ":" + dojo.number.format(list.length) + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
					this._summaryMsg = this._summaryMsg + this.resources_.WARNING_IMAGE + ":" + dojo.number.format(list.length);
				}
				for(var i=0; i < list.length; i++){											
					newNode = dojo.doc.createElement('div');
					newNode.dojoType = "dijit.layout.ContentPane";
					//newNode.setAttribute("class", "msgwarn");
					dojo.addClass(newNode, "msgwarn");
					newNode.setAttribute("id", this.id+"_msgwarn_" + i);
					if ( this._imageWarn !== null )
					{
						var image = dojo.doc.createElement( 'img' );
						image.src = this._imageWarn;
						image.border = "0";
						image.width = "15";
						image.height = "15";
						image.style.marginTop="3px";
						image.setAttribute("id", this.id+"_msgwarn_img_" + i);
						image.setAttribute("alt", this.resources_.WARNING_IMAGE);
						image.setAttribute("title", this.resources_.WARNING_IMAGE);
					}
					desc = dojo.doc.createElement( 'span' );
					desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
					if(this._toSort)
						replaceNode.appendChild(newNode);
					else
						this.messagesAttach.appendChild(newNode);
					newNode.appendChild(desc);						
					newNode.appendChild(image);
					desc = dojo.doc.createElement( 'span' );
					desc.setAttribute("tabindex","0");
					desc.setAttribute("role","presentation");
					desc.setAttribute("aria-label",this.resources_.WARNING_IMAGE + " " + this._msgId[i] + ": " +this._msgDesc[i]);
					desc.innerHTML = "&nbsp  " + this._msgId[i] + ": " +this._msgDesc[i];
					newNode.appendChild(desc);
				}
				
				/*Information Messages*/				
				var list = dojox.json.query("=$.[?msgType~'info'][/severity][/msgId]", this.message);
				for(var i=0 ; i < list.length ; i++){
					this._msgDesc[i] = dojox.json.query("[" + i  + "].msgDesc", list);
					this._msgId[i] = dojox.json.query("[" + i + "].msgId", list);
				}
				if( list.length > 0 ){
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageInfo;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", this.id+"_msginfo");
					imageContainer.setAttribute("alt", this.resources_.INFO_IMAGE);
					imageContainer.setAttribute("title", this.resources_.INFO_IMAGE);
					msgCount.innerHTML = ":" + dojo.number.format(list.length) + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
					this._summaryMsg = this._summaryMsg + this.resources_.INFO_IMAGE + ":" + dojo.number.format(list.length)
				}
				for(var i=0; i < list.length; i++){											
					newNode = dojo.doc.createElement('div');
					newNode.dojoType = "dijit.layout.ContentPane";
					//newNode.setAttribute("class", "msginfo");
					dojo.addClass(newNode, "msginfo");
					newNode.setAttribute("id", this.id+"_msginfo_" + i);
					if ( this._imageInfo !== null )
					{
						var image = dojo.doc.createElement( 'img' );
						image.src = this._imageInfo;
						image.border = "0";
						image.width = "15";
						image.height = "15";
						image.style.marginTop="3px";
						image.setAttribute("id", this.id+"_msginfo_img_" + i);
						image.setAttribute("alt", this.resources_.INFO_IMAGE);
						image.setAttribute("title", this.resources_.INFO_IMAGE);
					}
					desc = dojo.doc.createElement( 'span' );
					desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
					if(this._toSort)
						replaceNode.appendChild(newNode);
					else
						this.messagesAttach.appendChild(newNode);	
					newNode.appendChild(desc);						
					newNode.appendChild(image);
					desc = dojo.doc.createElement( 'span' );
					desc.setAttribute("tabindex","0");
					desc.setAttribute("role","presentation");
					desc.setAttribute("aria-label",this.resources_.INFO_IMAGE + " " + this._msgId[i] + ": " +this._msgDesc[i]);
					desc.innerHTML = "&nbsp  " + this._msgId[i] + ": " +this._msgDesc[i];
					newNode.appendChild(desc);
				}
				
				/*Confirmation Messages*/				
				/*var list = dojox.json.query("=$.[?msgType~'conf'][/severity][/msgId]", this.message);
				for(var i=0 ; i < list.length ; i++){
					this._msgDesc[i] = dojox.json.query("[" + i  + "].msgDesc", list);
					this._msgId[i] = dojox.json.query("[" + i + "].msgId", list);
				}
				if( list.length > 0 ){
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageConf;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", "msgconf");
					imageContainer.setAttribute("title", this.resources_.CONFIRM_IMAGE);
					msgCount.innerHTML = "&nbsp : &nbsp " + list.length + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
				}
				for(var i=0; i < list.length; i++){											
					newNode = dojo.doc.createElement('div');
					newNode.dojoType = "dijit.layout.ContentPane";
					//newNode.setAttribute("class", "msgconf");
					dojo.addClass(newNode, "msgconf");
					newNode.setAttribute("id", "msgconf" + i);
					if ( this._imageConf !== null )
					{
						var image = dojo.doc.createElement( 'img' );
						image.src = this._imageConf;
						image.border = "0";
						image.width = "15";
						image.height = "15";
						image.style.marginTop="3px";
						image.setAttribute("id", "msgconf" + i);
						image.setAttribute("title", this.resources_.CONFIRM_IMAGE);
					}
					desc = dojo.doc.createElement( 'span' );
					desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
					if(this._toSort)
						replaceNode.appendChild(newNode);
					else
						this.messagesAttach.appendChild(newNode);
					newNode.appendChild(desc);						
					newNode.appendChild(image);
					desc = dojo.doc.createElement( 'span' );
					desc.innerHTML = "&nbsp  " + this._msgId[i] + "&nbsp : &nbsp " +this._msgDesc[i];
					newNode.appendChild(desc);
				}*/
				
				/*Validation Messages*/				
				var list = dojox.json.query("=$.[?msgType~'val'][/severity][/msgId]", this.message);
				for(var i=0 ; i < list.length ; i++){
					this._msgDesc[i] = dojox.json.query("[" + i  + "].msgDesc", list);
					this._msgId[i] = dojox.json.query("[" + i + "].msgId", list);
				}
				if( list.length > 0 ){
					imageContainer = dojo.doc.createElement('img');
					msgCount = dojo.doc.createElement('span');
					imageContainer.src = this._imageVal;
					imageContainer.border = "0";
					imageContainer.width = "15";
					imageContainer.height = "15";
					imageContainer.setAttribute("id", this.id+"_msgval");
					imageContainer.setAttribute("alt", this.resources_.VALID_IMAGE);
					imageContainer.setAttribute("title", this.resources_.VALID_IMAGE);
					msgCount.innerHTML = ":" + dojo.number.format(list.length) + " &nbsp";
					spanContainer.appendChild(imageContainer);
					spanContainer.appendChild(msgCount);
					if(this._toSort)
						replaceContainer.appendChild(spanContainer);
					else
						this.dupContainer.appendChild(spanContainer);
					imageContainer.style.verticalAlign="middle";
					msgCount.style.verticalAlign="middle";
					this._summaryMsg = this._summaryMsg + this.resources_.VALID_IMAGE + ":" + dojo.number.format(list.length)
				}
				for(var i=0; i < list.length; i++){											
					newNode = dojo.doc.createElement('div');
					newNode.dojoType = "dijit.layout.ContentPane";
					//newNode.setAttribute("class", "msgval");
					dojo.addClass(newNode, "msgval");
					newNode.setAttribute("id", this.id+"_msgval_" + i);
					if ( this._imageVal !== null )
					{
						var image = dojo.doc.createElement( 'img' );
						image.src = this._imageVal;
						image.border = "0";
						image.width = "15";
						image.height = "15";
						image.style.marginTop="3px";
						image.setAttribute("id", this.id+"_msgval_img_" + i);
						image.setAttribute("alt", this.resources_.VALID_IMAGE);
						image.setAttribute("title", this.resources_.VALID_IMAGE);
					}
					desc = dojo.doc.createElement( 'span' );
					desc.innerHTML = "&nbsp" + "&nbsp" + "&nbsp" + "&nbsp";
					if(this._toSort)
						replaceNode.appendChild(newNode);
					else
						this.messagesAttach.appendChild(newNode);	
					newNode.appendChild(desc);						
					newNode.appendChild(image);
					desc = dojo.doc.createElement( 'span' );
					desc.setAttribute("tabindex","0");
					desc.setAttribute("role","presentation");
					desc.setAttribute("aria-label",this.resources_.VALID_IMAGE + " " + this._msgId[i] + ": " +this._msgDesc[i]);
					desc.innerHTML = "&nbsp  " + this._msgId[i] + ": " +this._msgDesc[i];
					newNode.appendChild(desc);
				}
				msgCount = dojo.doc.createElement('span');
				msgCount.innerHTML = "";
				spanContainer.appendChild(msgCount);
				msgCount.style.verticalAlign="middle";
				if(this._toSort)
					this.wipeNode.appendChild(replaceNode);
						
				this.severitySort = true;
				this.timeSort = false;
				this.imageSev.setAttribute("alt", this.resources_.CLEAR_SEV_SORT_IMAGE);				
				this.imageSev.setAttribute("title", this.resources_.CLEAR_SEV_SORT_IMAGE);				
				this.imageTime.setAttribute("alt", this.resources_.TIME_SORT_IMAGE);				
				this.imageTime.setAttribute("title", this.resources_.TIME_SORT_IMAGE);				
			},	  
						
			/*************************************************************
			* Adds the messages to the MultiMessageArea that will be shown 
			* when MultiMessageArea renders
			* @param messageId, messageDescription, messageType, 
			* messageSeverity, messageTime of the message object
			**************************************************************/
			addMessages: function(/*messageId*/ _id,/*messageDescription*/  _desc,/*messageType*/ _type,/*messageSeverity*/ _sev,/*messageTime*/ _time)
			{
				//NLS
				this.resources_ = dojo.i18n.getLocalization("dojoe.multimessagearea", "MultiMessageArea");
				if( _id == null || _id == "" ){
					//console.info(this.resources_.INFO_LOG_MSG1 + _id + this.resources_.INFO_LOG_MSG2);
				}
				else {
					var message = {msgId: _id, msgDesc: _desc, msgType: _type, severity: _sev, time: _time};
					this.message.push(message);
					this._toSort = true;
					this.severitySort = true;
					if(this.timeSort){
						//this.domNode.style.display = "inline";
						this.sortByTime();
					} else {
						//this.domNode.style.display = "inline";
						this.sortBySeverity();
					}
				}
				this._updateHeader();
			},
			
			/*******************************************
			* Removes messages from the MultiMessageArea
			* @param messageId of the message object
			********************************************/
			removeMessage: function(/*messageId*/ _id)
			{
				//NLS
				this.resources_ = dojo.i18n.getLocalization("dojoe.multimessagearea", "MultiMessageArea");
				if( _id == null || _id == "" ){
					//console.info(this.resources_.INFO_LOG_MSG1 + _id + this.resources_.INFO_LOG_MSG3);
				}
				var list = dojox.json.query("=$.[?msgId='*']", this.message);
				var messageList = [];
				var message = [];
				this._isEmpty = true;
				for(var i=0; i < list.length; i++)
				{
					idValue = dojox.json.query("[" + i + "].msgId", list);
					addMessage = dojox.json.query("=$.[?msgId='" + idValue + "']", list);
					if( idValue != _id ){
						message = {msgId: idValue, msgDesc: dojox.json.query("[0].msgDesc", addMessage), msgType: dojox.json.query("[0].msgType", addMessage), severity: dojox.json.query("[0].severity", addMessage), time: dojox.json.query("[0].time", addMessage)};
						messageList.push(message);
					}
					else
						this._isEmpty = false;
				}
				if(!this._isEmpty){
					this.message = messageList;
					this._toSort = true;
					this.severitySort = true;
					if(this.timeSort){
						//this.domNode.style.display = "inline";
						this.sortByTime();
					} else {
						//this.domNode.style.display = "inline";
						this.sortBySeverity();
					}
				} else {
					//console.info(this.resources_.INFO_LOG_MSG4 + _id + this.resources_.INFO_LOG_MSG5);
					this._isEmpty = false;
				}
			},
			
			/*********************************************
			* Returns the message type of a message object
			* @param messageId of the message object
			**********************************************/
			getMessageType: function(/*messageId*/ _id)
			{
				//NLS
				this.resources_ = dojo.i18n.getLocalization("dojoe.multimessagearea", "MultiMessageArea");
				if( _id == null || _id == "" ){
					//console.info(this.resources_.INFO_LOG_MSG1 + _id + this.resources_.INFO_LOG_MSG6);
				}
				else{
					var list = dojox.json.query("=$.[?msgType][?msgId='" + _id + "']", this.message);
					if(list)
						return dojox.json.query("[0].msgType", list);
					else{
						//console.info(this.resources_.INFO_LOG_MSG4 + _id + this.resources_.INFO_LOG_MSG5);
					}
				}
			},
			
			/****************************************************
			* Sets the message type for a message object
			* @param messageId, messageType of the message object
			*****************************************************/
			setMessageType: function(/*messageId*/ _id,/*messageType*/ _type)
			{
				//NLS
				this.resources_ = dojo.i18n.getLocalization("dojoe.multimessagearea", "MultiMessageArea");
				if( _id == null || _id == "" || _type == null || _type == "" ){
					//console.info(this.resources_.INFO_LOG_MSG1 + _id + this.resources_.INFO_LOG_MSG7 + _type + this.resources_.INFO_LOG_MSG8);
				}
				else{
					var list = dojox.json.query("=$.[?msgId='" + _id + "']", this.message);
					if(list != "" || list != undefined || list != null || list != []){
						var message = {msgId: _id, msgDesc: dojox.json.query("[0].msgDesc", list), msgType: _type, severity: dojox.json.query("[0].severity", list), time: dojox.json.query("[0].time", list)};
						this.removeMessage(_id);
						this.message.push(message);
						this._toSort = true;
						this.severitySort = true;
						if(this.timeSort){
							//this.domNode.style.display = "inline";
							this.sortByTime();
						} else {
							//this.domNode.style.display = "inline";
							this.sortBySeverity();
						}
					} else {
						//console.info(this.resources_.INFO_LOG_MSG4 + _id + this.resources_.INFO_LOG_MSG5);
					}
				}
				this._updateHeader();
			},
			
			/**************************************************
			* Returns the containerWidth of the multimessagearea
			***************************************************/
			getContainerWidth: function()
			{
				return this.containerWidth;
			},
			
			/************************************************
			* Sets the containerWidth for the multimessagearea
			*************************************************/
			setContainerWidth: function(/*containerWidth*/ containerWidth)
			{
				this.containerWidth = containerWidth;
				this.domNode.style.width = containerWidth;
				//this.resize();
			},
			/*******************************************************************
			* Determines if the multimessagearea has messages and returns boolean
			********************************************************************/
			hasMessages: function()
			{
				var list = dojox.json.query("=$.[?msgId='*']", this.message);
				if( list.length == 0 )
					this._isEmpty = true;				
				return !this._isEmpty;
			},
			
			/**********************************************
			* Returns the messageType of the message object
			***********************************************/
			getMessages: function(/*messageType*/ _type)
			{
				//NLS
				this.resources_ = dojo.i18n.getLocalization("dojoe.multimessagearea", "MultiMessageArea");
				if( _type == null || _type == "" ){
					//console.info(this.resources_.INFO_LOG_MSG9 + _type + this.resources_.INFO_LOG_MSG5);
				}
				else
					return dojox.json.query("=$.[?msgType~'" + _type + "']", this.message);
			},
			
			/*********************************************
			* Returns the ID of the multimessagearea widget
			**********************************************/
			/*getMessageId: function()
			{
				return this._messageId;
			},*/
			
			/*****************************************
			* Sets an ID of the multimessagearea widget
			******************************************/
			//setMessageId: function(/*multimessageareaId*/ messageId)
			/*{
				//NLS
				this.resources_ = dojo.i18n.getLocalization("dojoe.multimessagearea", "MultiMessageArea");
				if( messageId == null || messageId == "" ){
					//console.log(this.resources_.INFO_LOG_MSG10 + messageId + this.resources_.INFO_LOG_MSG11);
				}
				this._messageId = messageId;
				this.domNode.setAttribute("id", this._messageId);
			},*/
			
			/*Toggle open/close button state of the div when button is  clicked*/
			_toggle: function(event)
			{
				if(event.keyCode == undefined || event.keyCode==0 || event.keyCode==13 || event.keyCode==32){
					dojo.forEach([this._wipeIn, this._wipeOut], function(animation){
					  if(animation.status() == "playing"){
						animation.stop();
					  }
					});
					
					this[this.open ? "_wipeOut" : "_wipeIn"].play();
					

					
					//this.open =! this.open;    
  
					this.open = !this.open;	
					this._updateClass();  					
				}
			},
			
			/*Sorting the messages according to Severity on clicking the Severity Sorting Image*/
			_sevSort: function(event)
			{
				if(event.keyCode == undefined || event.keyCode==0 || event.keyCode==13 || event.keyCode==32){
					if(!this.severitySort){
						this.timeSort = false;
						this.severitySort = true;
						this._toSort = true;
						this.postCreate();
						//this.timeSort = true;
						this._updateClass();
						this.imageSev.setAttribute("alt", this.resources_.CLEAR_SEV_SORT_IMAGE);
						this.imageSev.setAttribute("title", this.resources_.CLEAR_SEV_SORT_IMAGE);
					}else{
						this.timeSort = false;
						this.severitySort = false;					
						this._toSort = true;
						this.postCreate();
						this._updateClass();
						this.imageSev.setAttribute("alt", this.resources_.SEV_SORT_IMAGE);
						this.imageSev.setAttribute("title", this.resources_.SEV_SORT_IMAGE);
					}
				}
			},
			
			/*Sorting the messages according to Time on clicking the Time Sorting Image*/
			_timeSort: function(event)
			{
				if(event.keyCode == undefined || event.keyCode==0 || event.keyCode==13 || event.keyCode==32){
					if(!this.timeSort){
						this._toSort = true;
						this.timeSort = true;
						this.severitySort = false;
						this.postCreate();
						this._updateClass();
						this.imageTime.setAttribute("alt", this.resources_.CLEAR_TIME_SORT_IMAGE);
						this.imageTime.setAttribute("title", this.resources_.CLEAR_TIME_SORT_IMAGE);
					}else{
						this.timeSort = false;
						this.severitySort = false;					
						this._toSort = true;
						this.postCreate();
						this._updateClass();
						this.imageTime.setAttribute("alt", this.resources_.TIME_SORT_IMAGE);
						this.imageTime.setAttribute("title", this.resources_.TIME_SORT_IMAGE);
					}
				}
			},
			
			//Bobby Joseph: 25Feb2011
			/*Closes the MultiMessageArea*/
			_close: function(event)
			{
				//Bobby Joseph: 02Mar2011
				//ignore tab and shift
				if(event.keyCode == 9 || event.keyCode == 16){
					return;
				}
				this._wipeOut.play();
				this.domNode.style.display = 'none';
				this.destroyRecursive();				
			},			

			/*To update the state of the div element between open/close and to toggle the display of the element 'spanContainer'*/
			_updateClass: function()
			{
				//console.info("this.open="+this.open);
				var list = dojox.json.query("=$.[?msgType='*']", this.message);
				var summaryMessage = this.resources_.CONTAINER_CONTENT + ": " + dojo.number.format(list.length)
				if ( this.open == true )
				{
					dojo.removeClass( this.domNode, "close"  );
					dojo.addClass( this.domNode, "open" );
					//console.info("this._oneClick="+this._oneClick);
					if(this._oneClick){
						if(this.imageSrc != null)
						{
							dojo.removeClass( this.imageSrc, "dijitTreeExpandoClosed")
							dojo.addClass( this.imageSrc, "dijitTreeExpandoOpened" ); //.src = this._imageSrcCon;
						}
						dojo.byId(this.id + "spanContainer").style.display = 'none';
					}else{
						//console.info("this.imageSrc="+this.imageSrc);
						if(this.imageSrc != null)
						{
							dojo.removeClass( this.imageSrc, "dijitTreeExpandoClosed")
							dojo.addClass( this.imageSrc, "dijitTreeExpandoOpened" ); //.src = this._imageSrcCon;
						}
					}
					this.msgContainer.setAttribute("aria-label", summaryMessage);
				}
				else
				{
					dojo.removeClass( this.domNode, "open" );
					dojo.addClass( this.domNode, "close"  );
					if(this._oneClick){
						if(this.imageSrc != null)
						{
							dojo.removeClass( this.imageSrc, "dijitTreeExpandoOpened");
							dojo.addClass( this.imageSrc, "dijitTreeExpandoClosed" ); //this.imageSrc.src = this._imageSrcExp;
						}
						dojo.byId(this.id + "spanContainer").style.display = 'inline';
					}
					this.msgContainer.setAttribute("aria-label", summaryMessage + " - " + this._summaryMsg);
				}  
				
				if(this.open){
					this.imageSrc.setAttribute("alt", this.resources_.COL_IMAGE);
					this.imageSrc.setAttribute("title", this.resources_.COL_IMAGE);
					this.imageSrc.setAttribute("role", "button");
					this.imageSrc.setAttribute("aria-expanded", "true");
				}else{
					this.imageSrc.setAttribute("alt", this.resources_.EXP_IMAGE);
					this.imageSrc.setAttribute("title", this.resources_.EXP_IMAGE);
					this.imageSrc.setAttribute("role", "button");
					this.imageSrc.setAttribute("aria-expanded", "false");
				}
			},

			/*To determin if each of the messages has a valid Id*/
			_validateMessages: function()
			{
				if(Object.prototype.toString.call(this.message) !== '[object Array]'){
					//var list = eval('(' + this.message + ')');
					var list = dojo.fromJson(this.message);
					this.message = list;
					var list = dojox.json.query("=$.[?msgId='*']", this.message);
				}
				else{
					var list = dojox.json.query("=$.[?msgId='*']", this.message);
				}
				var messageList = [];
				var message = [];
				for(var i=0; i < list.length; i++)
				{
					msgId = dojox.json.query("[" + i + "].msgId", list);
					addMessage = dojox.json.query("=$.[?msgId='" + msgId + "']", list);
					if(msgId == null || msgId == ""){
						//console.info(this.resources_.INFO_LOG_MSG1 + msgId + this.resources_.INFO_LOG_MSG2);
					}
					else {
						message = {msgId: dojox.json.query("[0].msgId", addMessage), msgDesc: dojox.json.query("[0].msgDesc", addMessage), msgType: dojox.json.query("[0].msgType", addMessage), severity: dojox.json.query("[0].severity", addMessage), time: dojox.json.query("[0].time", addMessage)};
						messageList.push(message);
					}
				}
				this.message = messageList;
			},
					
			destroy : function () {
				// summary:  Destroys the widget.
				// tags: public
				try{
					delete this.resources_;
					//this is for destroying child templated widgets 
					//this should happen by itself but need to figure out why dijit._Templated is not taking care of it...
					var widgets = dijit.findWidgets(this.domNode);
					dojo.forEach(widgets, function(w) {
						if(w){
							if(w.destroyRecursive){
								w.destroyRecursive();
							} else if(w.destroy){
								w.destroy();
							}
						}
					});
					// this is for widgets added as child to this widget and their children..
					//not present in template
					var widgetArr = this.getChildren();
					dojo.forEach(widgetArr, function (child) {
						if(child){
							if(child.destroyRecursive){
								child.destroyRecursive();
							} else if(child.destroy){
								child.destroy();
							}
						}
					});
					this.inherited(arguments);
				}catch(ex){
					console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
				}
			},

			//Bobby, 17Jul2011: overrriding destroyRecursive as it throws error - byId(node) is null 	
			destroyRecursive : function (){
				this.destroy();
			}					
			
		}
	);



}
