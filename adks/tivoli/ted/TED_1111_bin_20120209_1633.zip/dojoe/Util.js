/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.Util"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.Util"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.Util");

/*Common utility functions for all*/

isNumber = function(value){
	return (typeof value === 'number' && isFinite(value));
}

startsWith = function(all, part){
	return (all.indexOf(part) === 0);
}

endsWith = function(all, part){
	return (all.lastIndexOf(part) === all.length - part.length);
}

contains = function(all, part){
	return (all.lastIndexOf(part) >= 0);
}

trim = function(stringToTrim) {
	return stringToTrim.replace(/^\s+|\s+$/g,"");
}

ltrim = function(stringToTrim) {
	return stringToTrim.replace(/^\s+/,"");
}

rtrim = function(stringToTrim) {
	return stringToTrim.replace(/\s+$/,"");
}

}
