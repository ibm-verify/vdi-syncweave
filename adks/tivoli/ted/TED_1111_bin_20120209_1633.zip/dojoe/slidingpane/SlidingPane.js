/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.slidingpane.SlidingPane"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.slidingpane.SlidingPane"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide( "dojoe.slidingpane.SlidingPane" );

dojo.require( "dojo.fx" );
dojo.require( "dijit._Templated" );
dojo.require( "dijit.layout.ContentPane" );
dojo.require("dojo.i18n");
dojo.requireLocalization("dojoe.slidingpane", "SlidingPane", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");

dojo.declare("dojoe.slidingpane.SlidingPane", [dijit._Widget, dijit._Templated],
	{
		// summary:  The SlidingPane provides collapsible interface to the user. It is possible to add any widget or content within the sliding pane. 
		// description: SlidingPane widget uses the dojo animation features for its implementation. Use InnerDiv attachpoint to add graphics to the slidingpane. can be opened and closed.
	
		// widgetsInTemplate: [public]Boolean
		//		Set this to true if the widget contains other widgets
		widgetsInTemplate: true,
		
 		// templatePath:  [private]String
		//		Path to the template
		templateString : dojo.cache("dojoe.slidingpane", "templates/SlidingPane.html", "<div class='slidingPane open' tabIndex=0 aria-label=\"slidingpane\" >\r\n\t<div dojoAttachPoint='innerDIV' aria-label=\"content inside slidingpane\">\r\n\t\t<div dojoAttachPoint='hideNode'>\r\n\t\t\t<div class='dijitReset' dojoAttachPoint='wipeNode'>\r\n\t\t\t\t<div dojoAttachPoint='containerNode'></div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n\t<div class='slidingPaneClose' dojoAttachPoint='closeNode' dojoAttachEvent=\"onclick:_toggle, onkeypress:_keyEvent\" tabIndex=0>\r\n\t</div>\r\n</div>\r\n\t\r\n"),
		
		// backgroundClass:  [private]String
		//		Class set to the inner div.
		backgroundClass: null,
		
		closeNodeClass: null,
		
		// open: Boolean
		//		Whether description is opened or closed on first render.
		open: true,
		
		// duration: Integer
		//		Time in milliseconds to wipe in/wipe out.
		duration: 500,
		
		constructor: function () {
			this._resources = dojo.i18n.getLocalization("dojoe.slidingpane", "SlidingPane",this.lang);
		},
  
		postCreate: function () {
			// summary:  Creates  and initialises the SlidingPane and  sets open/close animations.
			// tags: private
			
			if (!this.open ) {
				this.hideNode.style.display = this.wipeNode.style.display = "none";
			}
			this._updateClass(); 
			this.inherited("postCreate",arguments);
			this.wipeNode.containerNode = this.containerNode;
			if (this.backgroundClass !== null ) {
				this.innerDIV.className = this.backgroundClass;
			}
			if (this.closeNodeClass !== null ) {
				this.closeNode.className = this.closeNodeClass;
			}
			// setup open/close animations
			var hideNode = this.hideNode, 
			wipeNode = this.wipeNode;
			this._wipeIn = dojo.fx.wipeIn({
				node: this.wipeNode,
				duration: this.duration,
				beforeBegin: function () {
					hideNode.style.display="";
				}
			});
    		this._wipeOut = dojo.fx.wipeOut({
				node: this.wipeNode,
				duration: this.duration,
				onEnd: function () {
					hideNode.style.display="none";
				}
			});
    
		},
		
		_keyEvent: function (evt) {
			if (evt!=null) {
				var charCode = evt.keyCode;
				if (charCode == 13) {
					this._toggle();
				}
			}
		},
  
		_toggle: function () {
			// summary:  Changes the animation effect for open/close state of slidingpane choosen by the user.
			// tags: private
			
			dojo.forEach([this._wipeIn, this._wipeOut], function (animation){
				if (animation.status() == "playing") {
					animation.stop();
				}
			});
			this[this.open ? "_wipeOut" : "_wipeIn"].play();
			this.open =! this.open;    
			this._updateClass(); 
			this.onClick();	
		},
  
		_updateClass: function () {
			// summary:  Updates the necessary class when  open/close state of the slidingpane choosen by the user.
			// tags: private
			
			if (this.open) {
				dojo.removeClass( this.domNode, "close"  );
				dojo.addClass( this.domNode, "open" );   
				this.closeNode.setAttribute("title", this._resources.CLOSE);
			} else {
				dojo.removeClass( this.domNode, "open" );
				dojo.addClass( this.domNode, "close"  );
				this.closeNode.setAttribute("title", this._resources.EXPAND);
			}  
		},

		onClick: function () {
			// summary:  Event gets fired when slidingpane is clicked
			// tags: public
			
			console.log("Sliding pane clicked from widget");
		},
		
		//Latha:06May2011: updating destroy for complete cleanup
		destroy : function () {
			// summary:  Destroys the sliding pane.
			// tags: public
			try {
				delete this._resources;
				var widgetArr = this.getChildren();
				dojo.forEach(widgetArr, function (child) {
					if(child){
						if(child.destroyRecursive){
							child.destroyRecursive();
						} else if(child.destroy){
							child.destroy();
						}
					}
				});
				this.inherited(arguments);
			} catch (ex) {
				console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
			}
		}
	});

}
