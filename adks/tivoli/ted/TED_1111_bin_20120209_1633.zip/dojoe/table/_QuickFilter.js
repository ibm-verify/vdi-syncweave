/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.table._QuickFilter"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.table._QuickFilter"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
// dojo.provide allows pages to use all of the types declared in this resource.
dojo.provide("dojoe.table._QuickFilter");

//dojo.require the necessary dijit hierarchy
dojo.require("dijit._Widget");
dojo.require("dijit._Templated");

//NLS
dojo.requireLocalization("dojoe.table", "Table", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");

dojo.declare("dojoe.table._QuickFilter", [ dijit._Widget, dijit._Templated ], {
	// Path to the template
	templateString : dojo.cache("dojoe.table", "templates/QuickFilter.html", "<div class=\"dijitReset  dijitTextBox quickFilter\" dojoAttachEvent='onmouseover:_onHover,mouseleave:_onUnHover,onblur:_onBlur,onclick: _onClick'>\r\n\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" role=\"presentation\">\r\n\t\t<tbody>\r\n\t\t\t<tr valign=\"center\">\r\n\t\t\t\t<td width=\"98%\" height=\"100%\">\r\n\t\t\t\t  <div>\t\t    \r\n\t\t\t\t\t\t<input dojoAttachPoint=\"searchField\" title=\"${resources_.QUICK_FILTER}\" class=\"dijitInputInner qf-textfield\" type=\"text\" \r\n\t\t\t\t\t\t\tvalue=\"${resources_.QF_DEFAULT_TEXT}\" valign=\"middle\" tabindex=\"0\" role=\"textbox\" \r\n\t\t\t\t\t\t\tdojoAttachEvent='onfocus:_onFocus,onkeyup:_onKeyUp,onpaste:_onKeyUp,oncut:_onKeyUp'/>\t\r\n\t\t\t\t  </div>\r\n\t\t\t\t</td>\t\r\n\t\t\t\t<td width=\"2%\" height=\"100%\">\r\n\t\t\t\t  <div class=\"dijitReset  dijitArrowButtonContainer \">\r\n\t\t\t\t\t\t<button title=\"${resources_.CLEAR_FILTER}\" class=\"dijitReset dijitInline dijitIcon quickFilterClearInner\" type=\"button\" tabindex=\"0\" \r\n\t\t\t\t\t\t\tvalign=\"middle\" dojoAttachPoint='clearFilterNode' dojoAttachEvent='onclick:_onCancel,onkeypress:_onCancel' role=\"button\"></button>\t\t\r\n\t\t\t\t  </div>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t</tbody>\t\t\r\n\t</table>\r\n</div>\r\n"),
	// Set this to true if your widget contains other widgets
	widgetsInTemplate : false,	
	grid:null,	
	timer:null,
	filterOptions: null,
	_quickFilterDelay: 700,	//delay in ms before quick filter is applied as typed
	_quickFilterButton: false, //change filter on type based on this
	/*#22195: 29/06/11 Using Quick Filter in table replaces an existing advanced filter*/
	//adding a private variable to keep track of previous QF string if any
	_savedCriteria: null,
	//LS - #24957 - 22/07/2011 - Problems with ruleCountToConfirmClearFilter - retaining the value set by user if any
	_ruleCntClearFilter: null,
	_retainSelection: false,//if true selection won't be cleared on filter
	
	// Override this method to perform custom behavior during dijit construction.
	// Common operations for constructor:
	// 1) Initialize non-primitive types (i.e. objects and arrays)
	// 2) Add additional properties needed by succeeding lifecycle methods
	constructor : function() {
	   this.resources_ = dojo.i18n.getLocalization("dojoe.table", "Table", this.lang);   
	},
	
	postCreate : function () {
	    //console.dir(this.filterOptions);
		if(this.filterOptions){
			if(this.filterOptions.showQuickFilterButton !== undefined) this._quickFilterButton = this.filterOptions.showQuickFilterButton;
			if(this.filterOptions.quickFilterDelay) this._quickFilterDelay = this.filterOptions.quickFilterDelay;
			if(this.filterOptions.retainSelection) this._retainSelection = this.filterOptions.retainSelection;
		}
		/*LS - 2/08/2011 - 25076 - Treetable - when clicking clear filter 'x' button few times, data is not re-fetched (server-side store) */
		//disabling clear filter icon when there is no filter applied to avoid above confusion, to have same behavior in table QF
		var filterText = this.searchField.value;
	   	if(this.filterText !== null && this.filterText !== "" && filterText !== this.resources_.QF_DEFAULT_TEXT  )	{
			dojo.style(this.clearFilterNode, "display", "block");
		}else{
			dojo.style(this.clearFilterNode, "display", "none");
		}				
	}, 		
	
	// When this method is called, all variables inherited from superclasses are 'mixed in'.
	// Common operations for postMixInProperties
	// 1) Modify or assign values for widget property variables defined in the template HTML file
	postMixInProperties : function() {	    
	    this.connect(this.grid, "onFilterDefined",  "_onFilterDefined");
	    /*#22195: 29/06/11 Using Quick Filter in table replaces an existing advanced filter*/
		if(this.grid.pluginMgr.getPlugin("Filter")){
			//clearing quick filter text (not filter)when advanced filter is opened..
		   	this.connect(this.grid.pluginMgr.getPlugin("Filter").filterDefDialog, "showDialog", "_onShowDialog");
	    }
	},
	
	_onFocus : function() {
		dojo.addClass(this.domNode, 'dijitTextBoxFocused');
		if (this.searchField.value == this.resources_.QF_DEFAULT_TEXT) {
			this.searchField.style.color = "#000000";
			this.searchField.value = "";
		}
	},
	
	//Latha : 14Mar2011 Fix for defect 5523. Setting Focus to filter box
	_onClick : function () {		
		dojo.addClass(this.domNode, 'dijitTextBoxFocused');
		this.searchField.focus();
		this.searchField.style.color = "#000000";
	},

	_onBlur : function() {
		dojo.removeClass( this.domNode, 'dijitTextBoxFocused' );
		dojo.removeClass( this.domNode, 'dijitTextBoxHover' );
		if (this.searchField.value === "") {
			this.searchField.style.color = "#999999";
			this.searchField.value = this.resources_.QF_DEFAULT_TEXT;
		}
	},

    _onHover : function() {
		dojo.addClass(this.domNode, 'dijitTextBoxHover');
	},

	_onUnHover : function(){
		dojo.removeClass( this.domNode, 'dijitTextBoxHover' );
	},

	_onKeyUp: function(event){		
		//enter key
		if (event.keyCode == 13) {
			//event.cancelBubble = true;
			//event.returnValue = false;        				
			dojo.stopEvent(event);
			this._setFilter();
			return;
		}//Bobby: 23Feb2011, don't do filter when tabbed thru
		//tab & shift keys
		else if(event.keyCode == 9 || event.keyCode == 16) {
			//event.cancelBubble = true;
			//event.returnValue = false; 
			//Bobby:17Apr2011, tab may get stuck if stopped
			//dojo.stopEvent(event);			
			//console.info("tab key -"+ event.keyCode);
			//clearTimeout(this.timer);
			//this.timer = null;
			return;
		}else if(this._quickFilterButton){
			return;
		}
		//Reset the timer since a key was pressed!
		else if(this.timer){
			clearTimeout(this.timer);
			this.timer = null;
		}		
		//Add delay before setting filter. 
		this.timer = setTimeout(dojo.hitch(this, "_setFilter"), this._quickFilterDelay);		
	},	
	
	_onShowDialog: function() {
		 /*#22195: 29/06/11 Using Quick Filter in table replaces an existing advanced filter*/
		 //clearing quick filter text (not filter)when advanced filter dialog is opened..
		this._clearText();
	},
        	
	_setFilter: function(){
	    var input = this.searchField.value;
	    /*#22195: 29/06/11 Using Quick Filter in table replaces an existing advanced filter*/
	    //connecting clear text and enter/afbutton press to clear QF criteria
		if (input == this.resources_.QF_DEFAULT_TEXT || input == "") {
			input = "";
			this._clearQuickFilter();
			return;
		}
		var rule = {
	      "type": "string",
		  "column": "anycolumn",
		  "condition": "contains",
		  "value": input,
		  "colTxt": "Any Column",
		  "condTxt": "contains",
		  "formattedVal": input
		  };
		//taking previous criteria to check if filter has to be added or replaced  
		if(this._savedCriteria){
			var previousCriteria = this._savedCriteria;}
		this._savedCriteria = rule;
		if(this.grid.getFilter().length > 0){
			var filterSet = false;
			var filterObjArr = this.grid.getFilter();
			if(previousCriteria){
				for(var i=0; i< filterObjArr.length; i++){
					if(filterObjArr[i].column === "anycolumn" && (previousCriteria.value === filterObjArr[i].value) ){
						filterObjArr[i].value = rule.value;
						filterSet = true;
						break;
					}
				}
			}
			if(!filterSet){
				filterObjArr.push(rule); 
			}
			rule  = filterObjArr;
		}
		//setting ruleCountToConfirmClearFilter to infinity so that AF clearFilter confirm popup never shows while setting filter
		//dojo has this attribute default as 2 and when fitler rules exceeds 2, on setFilter also this pop up starts showing up instead of clear filter 
		//LS - #24957 - 22/07/2011 - Problems with ruleCountToConfirmClearFilter - retaining the value set by user if any
		this._ruleCntClearFilter = this.grid.pluginMgr.getPlugin("Filter").ruleCountToConfirmClearFilter;
	    this.grid.pluginMgr.getPlugin("Filter").ruleCountToConfirmClearFilter = 'Infinity';
        this.grid.setFilter(rule);	
        /*LS - 2/08/2011 - 25076 - Treetable - when clicking clear filter 'x' button few times, data is not re-fetched (server-side store) */
		//disabling clear filter icon when there is no filter applied to avoid above confusion, applying to table also to maintain similar behavior	
		dojo.style(this.clearFilterNode, "display", "block");	
	},
	
	_onFilterDefined: function(rules){
		//Bobby:18Aug2011, adding option to prevent clearing selection on Filter
		//27171: Need option to allow selection after filtering
		if(this._retainSelection == false){
			//Bobby:31Mar2011, clearing selection on Filter
			//13285: DOJO:Allow for selection to be cleared when filter occurs
			this.grid.selection.clear();
		}
	

		/*#22195: 29/06/11 Using Quick Filter in table replaces an existing advanced filter*/
		//commenting following lines as this would set QF with anycolumn value even if defined by advanced filter
		//also commenting timer fix, because focus should not go to QF after filterdefined, becuase filter defined can be from AF
	    //if(rules.length == 1 && rules[0].column == "anycolumn" && rules[0].condition == "contains"){
		//			this.searchField.value = rules[0].value;
		//}
		//Latha : 29Mar2011 Fix for defect 7284. Table Quick Filter focus changes while typing into the filter box.
		//var timer = setTimeout(dojo.hitch(this, "_setFocus"), 700);
		//Now the confirm dialog will show
		//this has to be done since clearfilter is called upon setFilter in dojo Grid, causes unnecessary popup's
		//LS - #24957 - 22/07/2011 - Problems with ruleCountToConfirmClearFilter - retaining the value set by user if any
		if(this._ruleCntClearFilter)
			this.grid.pluginMgr.getPlugin("Filter").ruleCountToConfirmClearFilter = this._ruleCntClearFilter;
	},
	
	_setFocus: function(){
	    this.searchField.focus();
	},
		
	_onCancel: function(event){
		//Bobby: 23Feb2011, don't do anything when tabbed thru
		//tab & shift keys	
		if(event.keyCode == 9 || event.keyCode == 16) {
			//event.cancelBubble = true;
			//event.returnValue = false;
			//Bobby:17Apr2011, tab gets stuck if stopped
			//dojo.stopEvent(event);
			//console.info("tab key -"+ event.keyCode);
			return;
		}else{
			/*this.searchField.style.color = "#999999";
			this.searchField.value = this.resources_.QF_DEFAULT_TEXT;	  
			this.grid.setFilter(null);*/
			this._clearQuickFilter();			
		}		
	},
	
	//Bobby:04Mar2011
	//QuickFilter textbox also needs to be cleared	
	_clearQuickFilter: function(){
		/*#22195: 29/06/11 Using Quick Filter in table replaces an existing advanced filter*/
		if(this.grid.getFilter().length > 0 && this._savedCriteria) {
			 var filterArr = this.grid.getFilter();
			 for(var i=0;i<filterArr.length;i++){
				if(filterArr[i].column === "anycolumn" && (this._savedCriteria.value === filterArr[i].value) ){
					filterArr.splice(i,1);
					break;
			 	}
	 		 }
	 		 this.grid.setFilter(filterArr);	
		}	
		this.searchField.style.color = "#999999";
		this.searchField.value = this.resources_.QF_DEFAULT_TEXT;
		/*LS - 2/08/2011 - 25076 - Treetable - when clicking clear filter 'x' button few times, data is not re-fetched (server-side store) */
		//disabling clear filter icon when there is no filter applied to avoid above confusion, applying to table also to maintain similar behavior	
		dojo.style(this.clearFilterNode, "display", "none");
	},
	
    _clearText: function() {
    	/*#22195: 29/06/11 Using Quick Filter in table replaces an existing advanced filter*/
    	//adding to just clear text of QF and not filter as such
		this.searchField.style.color = "#999999";
		this.searchField.value = this.resources_.QF_DEFAULT_TEXT;
		this._savedCriteria = null;
		/*LS - 2/08/2011 - 25076 - Treetable - when clicking clear filter 'x' button few times, data is not re-fetched (server-side store) */
		//disabling clear filter icon when there is no filter applied to avoid above confusion, applying to table also to maintain similar behavior	
		dojo.style(this.clearFilterNode, "display", "none");	
	},
	
	
	destroy: function(){
		//memory leak issue: custom destroy method to take care of removing all widgets					
		try{
			delete this.resources_;
			//this is for destroying child templated widgets 
			//this should happen by itself but need to figure out why dijit._Templated is not taking care of it...
			var widgets = dijit.findWidgets(this.domNode);
			dojo.forEach(widgets, function(w) {
				if(w){
					if(w.destroyRecursive){
						w.destroyRecursive();
					} else if(w.destroy){
						w.destroy();
					}
				}
			});
			// this is for widgets added as child to this widget and their children..
			//not present in template
			var widgetArr = this.getChildren();
			dojo.forEach(widgetArr, function (child) {
				if(child){
					if(child.destroyRecursive){
						child.destroyRecursive();
					} else if(child.destroy){
						child.destroy();
					}
				}
			});
			this.inherited(arguments);
		}catch(ex){
			console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
		}
	}
	
});

}
