/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.table.Table"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.table.Table"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.table.Table");

dojo.require("dijit._Widget");
dojo.require("dijit._Templated");
dojo.require("dojox.grid.EnhancedGrid");
//Bobby:22May2011, doesn't seem to be reqd
//dojo.require("dijit.Tooltip");
dojo.require("dojoe.table._Toolbar");
dojo.require("dojo.i18n");
dojo.require("dojox.collections.ArrayList");
dojo.require("dojoe.slidingpane.SlidingPane");

/* Parameters that could be defined for gridparams.plugins
filter:true, for grid filter
dnd:true, for drag and drop - cell,row and column
nestedSorting:true, for nested sorting feature
indirectSelection:true, for checkboxes column
menus:{headerMenu:"headerMenu", rowMenu:"rowMenu",  selectedRegionMenu:"selectedRegionMenu"}, for cell,row,header and selected region menu
printer:true, for print feature
exporter:true, for export data feature
sortfields:[{ attribute:field name,ascending/descending:boolean...}]
For pagination, by default pagination will be enabled, if it needs to be disabled please set "pagination:false" on this widget

selector: true by default, set false to disable selector plugin.. else default selector config will be applied
enableResize : true, to enable the table resize when the window resizes
enableResize : false, to disable table resize on window resize event.
To resize the table on a particular event, connect the event to table's resize() function
*/

//Localization of resource bundles
dojo.requireLocalization("dojoe.table", "Table", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");

dojo.declare("dojoe.table.Table", [dijit._Widget, dijit._Templated], {
		
		// summary:  Table is a widget to render data in a tabular format. 
		// description: Table widget uses the dojox.grid.EnhancedGrid for its implementation.
		//		 It also has a customizable toolbar with multiple default actions and icons.
		
		// templateString:  String
		// Path to the template
		templateString : dojo.cache("dojoe.table", "templates/Table.html", "\r\n<div class=\"tivTable\" tabIndex=0 aria-label=\"table\" role=\"application\">\r\n\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" height=\"100%\" \r\n\t\tstyle=\"width:100%;height:100%;\" role=\"presentation\">\t\t\r\n\t\t<tr valign=\"center\">\r\n\t\t\t<td width=\"100%\" role=\"toolbar\">\r\n\t\t\t\t<div dojoAttachPoint=\"wipeNode\">\r\n\t\t\t\t<div dojoAttachPoint=\"toolbarNode\"></div>\r\n\t\t\t\t</div>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t<tr valign=\"center\"><td width=\"100%\" role=\"grid\">\r\n\t\t\t<div  dojoAttachPoint=\"enhancedGridNode\"></div></td></tr>\t\t\r\n\t</table>\r\n</div>\t\r\n"), 
		
		// widgetsInTemplate: Boolean
		//		Set this to true if the widget contains other widgets
		widgetsInTemplate : true, 
		
		// toolbarVisible: Boolean
		//		Controls the visibility of the toolbar.
		toolbarVisible : true, 
		
		// toolbarOptions:  Object
		//		Holds the  information about the toolbar options passed by the user.
		toolbarOptions : null, 
		
		// filterOptions:  Object
		//		Holds all the filter information passed by the user.
		filterOptions : null, 
		
		// enableResize: Boolean
		//		Controls the grid resize  on window resize event. 
		//		If true enables the table resize when the window resizes ,if false disable table resize on window resize event.
		//17266: dojoe.table.Table connect to browser window resize that lock up TIP UI.
		//enableResize : true, 
		enableResize : false,
		
		// gridParams:  Object
		//		Holds  information about the grid parameters passed by the user.	
		gridParams : null, 
		
		// grid: Object
		//		Reference to the dojox.grid.EnhancedGrid used.
		grid : null, 
		
		//Bobby 20Mar2011
		//defaultExportFormatter:  boolean
		//Enabled by default, set false to disable the default exportFormatter and set yours
		defaultExportFormatter : true, 
		
		// pageSizeArr:  array
		//		An array holds the size of the page.
		pageSizeArr : null, 
		
		// width: number  
		//		Holds the width of the grid set by user.  It can be set in px,percentage or em like '50px','50%' or '50em'.
		width : '', 
		
		// height: number
		//		Holds the height of the grid set by user. It can be set in px,percentage or em like '150px','150%' or '150em'.
		height : '', 
		
		//Satanik, 17Jan2011
		//Setting cell selection disabled as default - as per note from BJ	
		//_selector:  Object
		//		Holds the selection information for the row,column,cell of the grid interms of single,multi,disabled.
		// tags: private	
		//_selector: {row: "multi", col: "multi", cell: "disabled"},
		
		// _toolbar: Object
		//		Reference to the toolbar
		// tags: private
		_toolbar : null, 
		
		// _defaultHeight:  number
		//		Holds the default height of the grid. 
		// tags: private	
		_defaultHeight : '70%', 
		
		// _defaultWidth: number
		//		Holds the default width of the grid
		// tags: private	
		_defaultWidth : '80%', 
		//Satanik:19Apr2011: 17375 defect fix
		//footerdescription: boolean
		//Holds the description of the grid footer 
		footerDescription: true,
		//Satanik:21Apr2011: 17375 defect fix
		//footerVisible: boolean
		//Holds the visibility status of the footer
		footerVisible:true,
		// resources_:  Object
		//		Reference to the resources
		resources_ : null, 
		
		_previousSize : null,
		
		_resizing : false,
		
		//enableCollapsibleToolbar: boolean
		//To add collapsible toolbar  to the table
		enableCollapsibleToolbar : false,
		
		//toolbarExpand: boolean
		//To make the toolbar expand/collapse on first render
		toolbarExpand : true,
		
		constructor : function () {
			this.filterOptions = {};
			this.resources_ = dojo.i18n.getLocalization("dojoe.table", "Table", this.lang);
			this.pageSizeArr = ["5", "10", "25", "50", "100", "All"];
		}, 
		
		postCreate : function () {
			// summary:  Creates and initialises the table.
			// tags: public
			/*supporting autoWidth feature of grid*/
			if (this.width === '' && !this.gridParams.autoWidth) {
				this.width = this._defaultWidth;
			}
			if (this.height === '') {
				this.height = this._defaultHeight;
			}
			
			var size = dijit.getViewport();
			var heightPx = this.height;
			var sizeType = this.height.substring(this.height.length - 1, this.height.length);
			if (sizeType == "%") {
				//convert to px
				heightPx = size.h * ((parseInt(this.height.slice(0, -1))) / 100);
				heightPx = heightPx + "px";
			}
			if (!this.gridParams.autoWidth) {
				dojo.style(this.domNode, "width", this.width);
			}
			dojo.style(this.domNode, "height", heightPx);
			this._makeGrid();
			if (this.toolbarVisible) {
				this._toolbar = new dojoe.table._Toolbar({
						tivTable : this
					}, this.toolbarNode);
					
			if (this.enableCollapsibleToolbar) {
				this.slidingPane = new dojoe.slidingpane.SlidingPane({closeNodeClass: "slidingPaneClose", open: this.toolbarExpand}, this.wipeNode);
				dojo.connect(this.slidingPane, "onClick", dojo.hitch(this, "slidingPaneClicked"));	//Connecting event onClick to sliding pane.
			}
			
			}
			/*#8414 - height issue - call resize regardless of enableResize is true/false
			then if enableResize is true connect resize to window resize*/
			this.resize();
			if (this.enableResize === true) {
				this.connect(window, "onresize", "resize");
			}
			//Bobby,13Apr2011: adding listener functions for the notification of action list open/close.	
			//Bobby,14Apr2011: Adding check for toolbar and actionListWidget
			if(this._toolbar && this._toolbar.actionListWidget){	
				//dojo.connect(this._toolbar.actionListWidget, 'onClick', dojo.hitch(this,"onActionListOpen"));
				//dojo.connect(this._toolbar.actionListWidget, 'onKeyDown', dojo.hitch(this,"onActionListOpen")); 
				//replacing dojo.connect with this.connect to reduce cleanup effort 
				this.connect(this._toolbar.actionListWidget, 'openDropDown', dojo.hitch(this,"onActionListOpen")); 
				this.connect(this._toolbar.actionListWidget, 'closeDropDown', dojo.hitch(this,"onActionListClose")); 			
			}
			
			//Bobby: 01Mar11
			//Event generated on completion of Table load
			setTimeout(dojo.hitch(this, "onTableLoad", this), 1000);
			//this.onTableLoad(this);
		}, 
		
		//Connect to this to monitor Table load complete.
		onTableLoad : function (table) {
			console.info("Table load complete....." + table.id);
		}, 
		
		//Connect to this to monitor Opening of actionList
		onActionListOpen : function(){
			//console.info("actionListOpen.....");
		},
		
		//Connect to this to monitor Closing of actionList
		onActionListClose : function(){
			//console.info("actionListClosed.....");
		},		
		
		_makeGrid : function () {
			// summary:  Creates grid with the specified plugins and parameters.
			// tags: private	
			
			this._mapGridParams(); // this function is used to map ted plugins params with EnhancedGrid plugin params which may change frequently.
			
			//setting the Printer plugin when the Exporter plugin is set to make the Export to HTML work with css
			if (this.gridParams.plugins.exporter === true && !this.gridParams.plugins.printer) {
				var tempParams = this.gridParams;
				tempParams.plugins.printer = true;
				this.grid = new dojox.grid.EnhancedGrid(tempParams, this.enhancedGridNode);
				delete tempParams.plugins.printer;
			} else {
				this.grid = new dojox.grid.EnhancedGrid(this.gridParams, this.enhancedGridNode);
			}
			//startup and resize has problems when grid is added to a custom widget _widget
			//so set appropriate height and width to grid domNode, update and parse the domNode after resize
			//dojo.connect(this.grid,"_resize",this,"parseGrid");
			if (this.gridParams.preFilter) {				
				this.setFilter(this.gridParams.preFilter, this.gridParams.preFilter.hideFilterBar);
			}
			//this.resize();
			//#8414: table height is not proper with px/em  
			//do not resize grid before building the toolbar since toolbar height is not fixed anymore
			//if(this.enableResize === true) {
			//     dojo.connect(window, "onresize", this, "resize");
			//}
			
			//Bobby:18Mar2011.
			//to display the default message when grid is empty or filter result is none
			if (!this.gridParams.noDataMessage) {
				this.grid.noDataMessage = this.resources_.NO_DATA;
			} else {
				this.grid.noDataMessage = this.gridParams.noDataMessage;
			}
			
			//Bobby:31Mar2011, enabling text selection (similar to WCL Table)
			if (this.gridParams.selectable == undefined && this.gridParams.plugins.selector && this.gridParams.plugins.selector.cell !== 'disabled'){
				this.grid.selectable = true;
			}else this.grid.selectable = this.gridParams.selectable;
				
			this.grid.startup();
			this.grid.plugins && dojo.mixin(this.grid, this.grid.plugins);
			
			//Bobby:31Mar2011, disabling cell move by DnD	
			//if(!this.grid.plugin('dnd').copyOnly()){
			//Bobby:05Apr2011, fixing the blocker below
			//16408: Getting errors in Table.js
			if(this.grid.plugin('dnd')){
				this.grid.plugin('dnd').copyOnly(true);			
				this.grid.plugin('dnd').setupConfig({
					"within": true,
					"in": true,
					"out": true						
				});
			}			
		}, 
		
		resize : function (event) {
			// summary:  Resizes the table with the specified width and height
			// tags:  public
			
			//Bobby:29Jun11, preventing unwanted resize triggered by IE in TIP
			//console.dir(resizeEvent);
			var resizeEvent = false;
			if(event && event.currentTarget){
				resizeEvent = true;
			}
			
			var size = dijit.getViewport();
			if(this._previousSize && this._previousSize.h == size.h && this._previousSize.w == size.w && resizeEvent == true){
				//console.warn(this.id+":Not resizing since there is no change in viewport size, wrong resize event!!!");
				return;				
			}else{
				//console.info(this.id+":resizing...");
				this._previousSize =  size;
			}			
			
			//17074: Javascript error in resize( ) sometimes on IE8
			//if we have set up everything except the DOM, we cannot resize
			//if (!this.domNode.parentNode || this.domNode.parentNode.nodeType != 1) {
			if (!this.grid || !this.domNode || !this.domNode.parentNode || this.domNode.parentNode.nodeType != 1) {
				return;
			}
			/*supporting autoWidth feature of grid*/
			if (!this.grid.autoWidth) {
				dojo.style(this.domNode, "width", this.width);				
			} else {
				dojo.style(this.domNode, "width", dojo.marginBox(this.grid.domNode).w + 'px');
			}
			
			var heightPx = this.height;
			if (!(this.domNode.parentNode.style && this.domNode.parentNode.style.height)) {
				var sizeType = this.height.substring(this.height.length - 1, this.height.length);
				//if the height is given in % then translate it to pixel
				if (sizeType == "%") {
					//convert to px
					heightPx = size.h * ((parseInt(this.height.slice(0, -1))) / 100);
					heightPx = heightPx + "px";
				}
			}
			
			dojo.style(this.domNode, "height", heightPx);
			/*LS-29/09/2011 - #22273,#22274,#27221 - resize issues*/
			setTimeout(dojo.hitch(this, function(){this._delayResize(resizeEvent);}), 100);
		}, 
		
		_delayResize: function (resizeEvent) {
		// summary:  invoked with dealy for grid resize.
		///*LS-29/09/2011 - #22273,#22274,#27221 - resize issues*/
		// tags: private
			
			/*using marginBox to include margins/borders of the domNode*/
			var tableSize = dojo.marginBox(this.domNode);
			/*grid height is total grid height - margins/padding calculating actual grid height for resize*/
			var gridPadBorder = this.grid._getPadBorder().h;
			if (this._toolbar) {
				/*calculating toolbarsize including margins and borders as they contibute to some height*/
				var toolbarSize = dojo.marginBox(this._toolbar.domNode);
				//removing grid padding height which will be later added when pagination bar is placed and grid view node is resized.
				tableSize.h = tableSize.h - toolbarSize.h - (2 * gridPadBorder);				
			}
			/*LS - 06 Jan 2012 - 14602 - Resize issue with tables in multiple tabs, 
				15999 - TED table should not attempt to resize when hidden 
				-31008 - also removed this._resizing flag since the height and width of the viewport 
				is checked against previous numbers and if different then only resize happens - hence not required..*/
			if((tableSize.h <= 0 || tableSize.w <= 0 )){
				return;
			}
			
			/*LS - 18 Aug 2011 - 22072: Table resize issue*/
			//IWidget resize issue- grid was not getting proper width on window resize so on resizEvent(window resize) setting table width explicitly to grid
			if(resizeEvent){
				this.grid.resize({
					h : tableSize.h,
					w : tableSize.w
				});
			}else{
				//Latha : 23/11/2011
				//This check has been added for rendering issue of table inside wizard.In IE7 resize is happening only on passing both height and width. 
				if(dojo.isIE == 7) {
					this.grid.resize({
						h : tableSize.h,
						w : tableSize.w
					});
				} else { 
					this.grid.resize({
						h : tableSize.h
					});
				}
			}
			var heightPx = this.height;
			if(this.enableCollapsibleToolbar) {
				if(this.slidingPane!=null && !this.slidingPane.open) {
					tableSize.h = parseInt(heightPx) - 8;
					this.grid.resize({
						h : tableSize.h
					});
				}
			}
			this._resizing = false;  		
		},
		
		_mapGridParams : function () {
			// summary:   Maps ted plugins params with EnhancedGrid plugin params which may change frequently.
			// tags: private
			//Bobby:31Mar2011, the following shouldn't be set!
			//13285: DOJO:Allow for selection to be cleared when filter occurs
			//turning back to true, else selection goes by row index instead of row id :-)
			this.gridParams.keepSelection = true;
			
			if (this.gridParams.plugins.pagination) {
				this.gridParams.plugins.pagination = {
					pageSizes : this.pageSizeArr, // Array, custom the items per page button
					// itemTitle: "entrys", 	// String, custom the item title of description
					description : this.footerDescription, // boolean, custom whether or not the discription will be displayed
					sizeSwitch : true, // boolean, custom whether or not the page size switch will be displayed
					pageStepper : true, // boolean, custom whether or not the page step will be displayed
					gotoButton : true, 
					maxPageStep : 10, // Integer, custom how many page step will be displayed
					position : "bottom"// String, custom the position of the paginator bar
					// there're three options: top, bottom, both
				};
			} else {
				if(this.footerVisible){ // checking if the footer need to be displayed
					this.gridParams.plugins.pagination = {
						description : this.footerDescription, // boolean, custom whether or not the description will be displayed
						sizeSwitch : false, // boolean, custom whether or not the page size switch will be displayed
						pageStepper : false, // boolean, custom whether or not the page step will be displayed
						gotoButton : false, // boolean, custom whether or not the goto page button will be displayed
						position : "bottom", // String, custom the position of the pagination bar
						// there're three options: top, bottom, both
						descTemplate : "${1} ${0}"// A template of the current position description.
					};
				}
			}
			
			//Satanik, 17Jan2011
			//Setting cell selection disabled as default - as per note from BJ
			//Bobby:What is the point of this?
			//if(this.gridParams.plugins.selector !== undefined){
			//	this.gridParams.plugins.selector = this.gridParams.plugins.selector;    	
			//}
			//Bobby:24Feb2011
			//This is problematic if someone doesn't want to use selector (eg: no indirect selection)
			/*else{
			this.gridParams.plugins.selector = this.selector;    
			}*/
			
			//Bobby:28Feb2011, will disable cell selection if not enabled/disabled currently.
			//console.info("gridParams.plugins.selector -"+ this.gridParams.plugins.selector);
			//Bobby:31Mar2011, enabling cell selection for now as this is creating many issues
			/*if (this.gridParams.plugins.selector) {
				if (this.gridParams.plugins.selector.cell == undefined) {
					this.gridParams.plugins.selector.cell = "disabled";
				}
			}*/
			
			//22077: Possibility to set headerSelector flag in table grid
			//Bobby: 20Jun2011, letting deployers disable headerSelector
			if (this.gridParams.plugins.indirectSelection && this.gridParams.plugins.indirectSelection.headerSelector == undefined) {
				//always display the "select all" check box by default
				//Bobby:24Mar11
				//14962: Unable to top align checkboxes
				//this.gridParams.plugins.indirectSelection = {"headerSelector" : true};
				if (this.gridParams.plugins.indirectSelection instanceof Object){ 
					dojo.mixin(this.gridParams.plugins.indirectSelection, {
						"headerSelector" : true
					});
				}else{ //15299: Select all not visible in Firefox on TIP and WAS
					this.gridParams.plugins.indirectSelection = {"headerSelector" : true};
				}
			}
			
			if (this.gridParams.plugins.filter !== undefined) {
				//always display the closeFilterBarButton
				this.gridParams.plugins.filter.closeFilterbarButton = true;
				//hide the filter bar by default
				if (this.gridParams.preFilter) {
					this.filterOptions.hideFilterBar = false;
				} else {
					this.filterOptions.hideFilterBar = true;
				}				
				if (this.gridParams.plugins.filter.advancedFilter !== undefined) {
					this.filterOptions.showAdvancedFilter = this.gridParams.plugins.filter.advancedFilter;
					delete this.gridParams.plugins.filter.advancedFilter;
				}
				if (this.gridParams.plugins.filter.quickFilter !== undefined) {
					this.filterOptions.showQuickFilter = this.gridParams.plugins.filter.quickFilter;
					delete this.gridParams.plugins.filter.quickFilter;
				}
				if (this.gridParams.plugins.filter.showQuickFilterButton !== undefined) {
					this.filterOptions.showQuickFilterButton = this.gridParams.plugins.filter.showQuickFilterButton;
					delete this.gridParams.plugins.filter.showQuickFilterButton;
				}	
				if (this.gridParams.plugins.filter.searchDelay !== undefined) {
					this.filterOptions.searchDelay = this.gridParams.plugins.filter.searchDelay;
				}	
				if (this.gridParams.plugins.filter.retainSelection !== undefined) {
					this.filterOptions.retainSelection = this.gridParams.plugins.filter.retainSelection;
				}					
				//remove the extra filter params and set Filter
				this.gridParams.plugins.filter = this.gridParams.plugins.filter;				
			}
			if (this.gridParams.plugins.printer) {
				this.gridParams.plugins.printer = this.gridParams.plugins.printer;
			} else {
				delete this.gridParams.plugins.printer;
			}
			if (this.gridParams.plugins.exporter !== undefined) {
				this.gridParams.plugins.exporter = this.gridParams.plugins.exporter;
			}
			
		}, 
		
		getRowCount : function () {
			// summary:   Returns the total number of rows present in the grid.
			// tags:  public	
			// returns: total number of rows.
			return this.grid.rowCount;
		}, 
		
		getSelectedRowCount : function () {
			// summary:   Returns the number of selected rows in the grid.
			// tags: public	
			// returns: total number of selected rows.
			return this.grid.selection.getSelectedCount();
		}, 
		
		getSelectedRows : function () {
			// summary:   Returns the selected rows from the grid.
			// tags: public
			// returns: selected rows.
			return this.grid.selection.getSelected();
		}, 
		
		getFilter : function (columnFields) {
			// summary:   Returns an array of filter objects and filter rules relation logicall or  logicany
			// tags: public
			// columnFields: boolean   if true, returns the filter rules with value of column as the column field instead of column index.default is true.
			// returns:    an array of filter objects and filter rules relation "logicall" or "logicany"
			
			var filterObjArray = this.grid.getFilter();
			if (columnFields) {
				for (var i = 0; i < filterObjArray.length; i++) {
					if (this._isInt(filterObjArray[i].column)) {
						filterObjArray[i].column = this._getColumnField(filterObjArray[i].column);
					}
				}
			}
			var ruleRelation = this.getFilterRelation();
			filterObjArray.ruleRelation = ruleRelation;
			return filterObjArray;
		}, 
		
		getFilterRelation : function () {
			// summary:  Returns  the relationship between filter rules specified.
			// tags: public
			if (this.grid) {
				return this.grid.getFilterRelation();
			}
		}, 
		
		_getColumnName : function (index) {
			// summary:  Returns the column name for the specified column index
			// tags: private
			// index: number
			// returns:  Name of the column
			return this.grid.layout.cells[index].name;
		}, 
		
		_getColumnField : function (index) {
			// summary:  Returns the column field for the specified column index
			// tags: private
			// index: number
			// returns: Field of the column
			return this.grid.layout.cells[index].field;
		}, 
		
		_isInt : function (value) {
			// summary:   Returns whether the passed value is int or not
			// tags: private
			// returns: boolean
			if ((parseFloat(value) == parseInt(value)) && !isNaN(value)) {
				return true;
			} else {
				return false;
			}
		}, 
		
		_getColumnIndex : function (colField) {
			// summary: Returns the column index for the column field.
			// tags: private
			// returns: Index of the column
			var cells = this.grid.layout.cells;
			for (var i = cells.length - 1; i >= 0; --i) {
				var cell = cells[i];
				if (cell.field == colField) {
					return i;
				}
			}
			return null;
		}, 
		
		setFilter : function (filterObjArray, hideFilterBar) {
			// summary:  Sets the filter for the grid.
			// tags: public
			// filterObjArray:  an array of filter objects
			if (this.grid.setFilter) {
				var toFilterList = new dojox.collections.ArrayList();
				if (filterObjArray) {
					for (var i = 0; i < filterObjArray.length; i++) {
						var filterObj = filterObjArray[i];
						if (filterObj.value) {
							if ((filterObj.column) && (this._isInt(filterObj.column) == false)) {
								filterObj.column = this._getColumnIndex(filterObj.column);
							}							
							var objToSet = {
								"type" : filterObj.type ? filterObj.type : "string", 
								"column" : filterObj.column ? filterObj.column : "anycolumn", 
								"value" : filterObj.value, 
								"condition" : filterObj.condition ? filterObj.condition : "contains"
							};
							toFilterList.add(objToSet);
						}
					}
					var toFilterArray = toFilterList.toArray();
					var ruleRelation = filterObjArray.ruleRelation;
					if (ruleRelation) {
						this.grid.setFilter(toFilterArray, ruleRelation);
					} else {
						this.grid.setFilter(toFilterArray);
					}
				} else {
					//Bobby:02Dec2011, calling clearFilter instead of direct access
					//this.grid.setFilter(null);
					this.clearFilter()
				}
				//Bobby:02Dec2011, adding flag hideFilterBar
				//35784: [TWL] table.clearFilter() does not clear and hide filter bar	]
				//console.warn("hideFilterBar:"+hideFilterBar);	
				if(hideFilterBar == true){
					this.grid.showFilterBar(false);
				}else this.grid.showFilterBar(true);
			}
		}, 
		
		clearFilter : function (hideFilterBar) {
			// summary:   Clears the filter applied 	
			// tags: public
			/*if(this.grid.getFilter().length > 0) {
			     this.grid.setFilter(null);
			}*/
			//Bobby:04Mar2011
			//QuickFilter textbox also needs to be cleared		
			//if (this._toolbar._quickFilter) {
			//Bobby:07Dec2011			
			//35981: [TWL] Issues with setFilter when no toolbar exists
			if (this._toolbar && this._toolbar._quickFilter) {
				//console.warn('clearing quick filter....');
				this._toolbar._quickFilter._clearQuickFilter();
			} 
			//Bobby:02Dec2011, fixing clear adv filter and adding flag hideFilterBar
			//35784: [TWL] table.clearFilter() does not clear and hide filter bar
			if (this.grid.getFilter().length > 0) {
				//console.warn('clearing grid filter....');
				this.grid.setFilter(null);				
			}
			if(hideFilterBar == true){
				this.grid.showFilterBar(false);
			}
		},
		
		removeSelectedRows : function () {
			// summary:   Removes the selected rows from the grid
			// tags: public
			this.grid.removeSelectedRows();
		}, 
		
		deleteAllRows : function () {
			// summary:   Deletes all rows from the grid.
			// tags: public
			var rowCount = this.grid.rowCount;
			for (var i = 0; i < rowCount; i++) {
				this.deleteRow(i);
			}
		}, 
		
		deleteRow : function (rowIndex) {
			// summary:  Delete a row with the  rowindex  specified.
			// tags: public
			// rowIndex: number
			var jsonStore = this.grid.store;
			var gridRef = this.grid;
			jsonStore.fetch({
				query : {},
				onComplete : function (items, request) {
					for (i = 0; i < items.length; i++) {
						var item = items[i];
						
						if (item) {
							jsonStore.deleteItem(item);
						}
					}
					gridRef._refresh(0, true);
				}
			});
		}, 
		
		addToActionList : function (item) {
			// summary:  Add a new item to the toolbar action menu
			// tags: public
			// item: 
			if (this._toolbar) {
				this._toolbar._addToActionList(item);
			}
		}, 
		
		//20470: Tivtable: Table load takes significant amount of time to load
		//Bobby:24May11, adding noResize to control Table resize
		//resize is very costly in iWidgets
		addToToolbar : function (item, position, row, noResize) {
			// summary:  Add an item to the toolbar
			// tags: public
			// item:  object   The item that needs to be added
			// position:  number The position of the item in number
			// row:  number The row number to which the item needs to be added
			// noResize: boolean To control whether a table resize should be done or not
			if (this._toolbar) {
				if (row && row == 2) {
					this._toolbar._addToToolbarSecondRow(item, position);
				} else {
					this._toolbar._addToToolbarFirstRow(item, position);
				}
				/* #8414: height issue - call resize on this widget whenever toolbar layout is modified, 
				this way new toolbar height can be calculated and grid can be resized accordingly*/
				//20May2011: Bobby
				//performance issue when multiple items are added to toolbar (Sunset/Analytics)
				if(noResize == false){}
				else this.resize();						
			}
		}, 
		
		//20470: Tivtable: Table load takes significant amount of time to load
		//Bobby:24May11, new API to add multiple toolbar items together		
		addItemsToToolbar : function (items, position, row, noResize) {
			// summary:  Add an item to the toolbar
			// tags: public
			// items:  array   The items that needs to be added
			// position:  number The position of the item in number
			// row:  number The row number to which the item needs to be added
			// noResize: boolean To control whether a table resize should be done or not
			if (this._toolbar) {
				for (var i = 0; i < items.length; i++) {		
					if (row && row == 2) {
						this._toolbar._addToToolbarSecondRow(items[i], position + i);
					} else {
						this._toolbar._addToToolbarFirstRow(items[i], position + i);
					}
				}
				/* #8414: height issue - call resize on this widget whenever toolbar layout is modified, 
				this way new toolbar height can be calculated and grid can be resized accordingly*/
				//20May2011: Bobby
				//performance issue when multiple items are added to toolbar (Sunset/Analytics)
				if(noResize == false){}
				else this.resize();				
			}
		}, 		
		
		addCustomMenuToTable : function (position, customMenu) {
			// summary:  Add custom menu to the table
			// tags: public
			// position: number The position of the menu in number
			// customMenu: object  menu
			if (position == "headerMenu") {
				var prevMenu = this.grid.headerMenu;
				if (prevMenu) {
					prevMenu.destroyRecursive();
				}
				this.grid.plugins.menus.headerMenu = customMenu.id;
				this.grid.headerMenu = customMenu;
			} else if (position == "rowMenu") {
				var prevMenu = this.grid.rowMenu;
				if (prevMenu) {
					prevMenu.destroyRecursive();
				}
				this.grid.plugins.menus.rowMenu = customMenu.id;
				this.grid.rowMenu = customMenu;
			} else if (position == "cellMenu") {
				var prevMenu = this.grid.cellMenu;
				if (prevMenu) {
					prevMenu.destroyRecursive();
				}
				this.grid.plugins.menus.cellMenu = customMenu.id;
				this.grid.cellMenu = customMenu;
			} else if (position == "selectedRegionMenu") {
				var prevMenu = this.grid.selectedRegionMenu;
				if (prevMenu) {
					prevMenu.destroyRecursive();
				}
				this.grid.plugins.menus.selectedRegionMenu = customMenu.id;
				this.grid.selectedRegionMenu = customMenu;
			}
		}, 
		
		removeFromActionList : function (menuItemId) {
			// summary:    Removes the given menu item from the action list
			//tags: public
			if (this._toolbar) {
				this._toolbar._removeFromActionList(menuItemId);
			}
		}, 
		
		enableMenuItem : function (menuItemId) {
			// summary:	Enables the given menu item
			//tags: public
			if (this._toolbar) {
				this._toolbar._enableMenuItem(menuItemId);
			}
		}, 
		
		disableMenuItem : function (menuItemId) {
			// summary:	Disables the given menu item
			//tags: public
			if (this._toolbar) {
				this._toolbar._disableMenuItem(menuItemId);
			}
		}, 
		
		removeItemFromToolbar : function (itemId) {
			// summary:	Removes an item  with the given item id from the toolbar
			//tags: public
			//itemId: number  id of the item
			if (this._toolbar) {
				this._toolbar._removeItem(itemId);
			}
		}, 
		
		refresh : function () {
			// summary:	Calls in Grid refresh
			// tags: public
			if (this.grid) {
				//Satanik: 5Apr2011: added for CURI store notification of refresh in progress
    			if (this.grid.store.CURIRefresh) {
					this.grid.store.CURIRefresh();
				}
				
				var scrollpos = this.grid.scrollTop;
				//filter should be applied only if previously applied
				if(this.grid.getFilter){
					//console.log("Grid has filter applied");
					//20610: Refresh on Table prompt for clear filters dialog when there are more than 2 filters set
					//Bobby:25May11, using new Grid API to suppress the Clear Filter warning on refresh 
					//LS - #24957 - 22/07/2011 - Problems with ruleCountToConfirmClearFilter - retaining the value set by user if any
					var preVal = this.grid.pluginMgr.getPlugin('filter').ruleCountToConfirmClearFilter;
					this.grid.pluginMgr.getPlugin('filter').ruleCountToConfirmClearFilter = Infinity; //Now the confirm dialog will never show
					var filterArray = this.getFilter();
					var ruleRelation = this.getFilterRelation();
					this.grid.setFilter(filterArray, ruleRelation);
					//LS - #24957 - 22/07/2011 - Problems with ruleCountToConfirmClearFilter - retaining the value set by user if any
					this.grid.pluginMgr.getPlugin('filter').ruleCountToConfirmClearFilter = preVal; //Now the confirm dialog will show
				}else {//as filter calls the grid refresh so adding the _refresh if filter is not there
					//console.log("Grid has NO filter applied");
					this.grid._refresh(true);
				}
				this.grid.setScrollTop(scrollpos);
			}
		}, 
		
		addRow : function (item) {
			// summary:  Adds a row to the table and scroll to it
			// tags:   public
			
			if (this.grid) {
				this.clearSort();
				this.clearFilter();
				//this.grid.layer("filter").filterDef(null);
				var g = this.grid;
				//Latha: 18Jan2012 - 36387
				//Moved delay to before inserting an item to the store, as grid refresh is an asynchronous and takes time to return correct total row count. 
				setTimeout(function () {
					var itemAdded = g.store.newItem(item);
					var rowIndex = g.getTotalRowCount ? g.getTotalRowCount() - 1 : g.getItemIndex(itemAdded);
					/* 13/07/2011 - 24428: Add new row - creates node is null error - so commenting scrollToRow call as it is made with timeout*/
					//g.scrollToRow(rowIndex);
					
					g.scrollToRow(rowIndex);
					//Bobby:28Jan2011, adding selection of added row.
					//g.selection.setSelected(rowIndex,true);
				}, 10);
			}
		}, 
		
		clearSort : function () {
			// summary:  Clears  the sort applied.
			// tags: public
			this.grid.setSortIndex([]);
		}, 
		
		slidingPaneClicked : function () {
			this.resize();
			
		},
		//Satanik:5May2011: destroy method is changed for mem leak issue 
		destroy : function () {
			// summary:  Destroys the grid.
			// tags: public
			try{
				delete this.resources_;
				//this is for destroying child templated widgets 
				//this should happen by itself but need to figure out why dijit._Templated is not taking care of it...
				var widgets = dijit.findWidgets(this.domNode);
				dojo.forEach(widgets, function(w) {
					if(w){
						if(w.destroyRecursive){
							w.destroyRecursive();
						} else if(w.destroy){
							w.destroy();
						}
					}
				});
				// this is for widgets added as child to this widget and their children..
				//not present in template
				var widgetArr = this.getChildren();
				dojo.forEach(widgetArr, function (child) {
					if(child){
						if(child.destroyRecursive){
							child.destroyRecursive();
						} else if(child.destroy){
							child.destroy();
						}
					}
				});
				this.inherited(arguments);
			}catch(ex){
				console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
			}
		}
	});
 

}
