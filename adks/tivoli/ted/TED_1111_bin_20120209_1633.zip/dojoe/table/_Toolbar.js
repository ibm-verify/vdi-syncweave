/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.table._Toolbar"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.table._Toolbar"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
// dojo.provide allows pages to use all of the types declared in this resource.
dojo.provide("dojoe.table._Toolbar");

//dojo.require("dijit.Toolbar");
dojo.require("dijit.form.Button");
dojo.require("dijit.ToolbarSeparator");
dojo.require("dijit.form.DropDownButton");
//dojo.require("dijit.form.TextBox");
dojo.require("dijit.Menu");
dojo.require("dijit.Dialog");
dojo.require("dijit.form.SimpleTextarea");
dojo.require("dojo.i18n");

dojo.require("dojoe.table._ConfigureColumnsDialog");
dojo.require("dojoe.table._QuickFilter");

dojo.requireLocalization("dojoe.table", "Table", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");

dojo.declare("dojoe.table._Toolbar", [ dijit._Widget, dijit._Templated], {
		// Place comma-separated class attributes here. Note, instance attributes 
		// should be initialized in the constructor. Variables initialized here
		// will be treated as 'static' class variables.	
		templateString:dojo.cache("dojoe.table", "templates/Toolbar.html", "<div  dojoAttachEvent='oncontextmenu:_stopEvent' class=\"tivTable dijitToolbar\" width=\"100%\">\r\n<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" role=\"presentation\">\r\n\t<tbody>\r\n\t\t<tr valign=\"center\">\r\n\t\t\t<td width=\"80%\" height=\"100%\">\r\n\t\t\t\t<span dojoAttachPoint=\"toolbarFirstRow\"><span dojoAttachPoint=\"refreshNode\" role=\"button\"></span><span dojoAttachPoint=\"refSeperator\" role=\"separator\"></span><span dojoAttachPoint=\"toolbarFirstRow_userItems\"></span><span dojoAttachPoint=\"exportDataNode\" role=\"button\"></span><span dojoAttachPoint=\"printNode\" role=\"button\"></span><span dojoAttachPoint=\"configureColNode\" role=\"button\"></span><span dojoAttachPoint=\"actionListNode\" role=\"button\"></span></span>\r\n\t\t\t</td>\r\n\t\t\t<td width=\"20%\" height=\"100%\" align=\"right\"><div dojoAttachPoint=\"quickFilterNode\" role=\"search\"></div></td>\r\n\t\t\t<td><div dojoAttachPoint=\"filterNode\" role=\"button\"></div></td>\t\t\t\r\n\t\t</tr>\r\n\t\t<tr valign=\"center\">\r\n\t\t\t<td width=\"100%\">\r\n\t\t\t\t<span dojoAttachPoint=\"toolbarSecondRow\">\r\n\t\t\t\t</span>\t\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t</tbody>\t\t\r\n</table>\r\n</div>\r\n"),
		widgetsInTemplate:true,
		//toolbar:null,
		plugins:null,
		inGrid:null,
		actionListWidget:null,
		resources_:null,
		toolbarOptions:null,
		filterOptions:null,
		refreshIcon:true,
		refreshMenu:true,
		actionMenu:true,
		configTableIcon:true,
		configTableMenu:true,
		tivTable:null,
		configureTableDialog:null,
		_quickFilter:null,	
		
		// Constructor function. Called when instance of this class is created
		constructor : function() {
			this.resources_ = dojo.i18n.getLocalization("dojoe.table", "Table", this.lang);			
		},
 		
		postCreate:function(){		
			this.inGrid = this.tivTable.grid;
			this.plugins = this.tivTable.gridParams.plugins;
			this.toolbarOptions = this.tivTable.toolbarOptions;
			this.filterOptions = this.tivTable.filterOptions;
			
			//commenting as this not required
			//this.toolbar = new dijit.Toolbar({id: "toolbar"+this.id});			
			
			//setting the toolbar options passed from UI
			this._mapToolbarOptions();
			
			//adding the refresh icon
			this._addRefreshIcon();			
			
			//adding the export icon
			this._addExporterIcon();
						
			//adding the printer icon
			this._addPrintIcon();				
			
			//adding the configure settings icon
			this._addConfigTableIcon();				
			
			//Action List Menu
			this._addActionMenu();			

			//adding filters
			this._addFilters();
		},
		
		//16716: table toolbar has browser popup menu on right click
		_stopEvent: function(e){
			//Since event is oncontextmenu, just stop it!
			dojo.stopEvent(e);
		},
		
		
		_addRefreshIcon: function() {
			if(this.refreshIcon) {
				var refreshTableIcon = new dijit.form.Button({
						showLabel: false,
						id: "refreshIcon"+this.id,
						iconClass: "refreshIcon",
						label: this.resources_.REFRESH,
						title: this.resources_.REFRESH
					},this.refreshNode);
					
				refreshTableIcon.onClick = dojo.hitch (this, "_refreshTable");
				refreshTableIcon.onKeypress = dojo.hitch (this, "_refreshTable");
				
				var seperator = new dijit.ToolbarSeparator({id: "refSeperator"+this.id},this.refSeperator);
			}
			else
			{
				dojo.style(this.refreshNode.parentNode, "width", "0px");
				dojo.style(this.refSeperator.parentNode, "width", "0px");
			}
			
		},
		_addExporterIcon: function() {
			if(this.plugins.exporter && this.toolbarOptions.exporterIcon) {
				var exportDataMenu = new dijit.Menu({ style: "display: none;"});
				var exportHTMLMenuItem = new dijit.MenuItem({
					title: this.resources_.EXPORT_HTML,
					label: this.resources_.EXPORT_HTML
				});
				exportHTMLMenuItem.onClick = dojo.hitch (this, "_exportHTML");
				exportHTMLMenuItem.onKeypress = dojo.hitch (this, "_exportHTML");
				exportDataMenu.addChild(exportHTMLMenuItem);	
				
				//Bobby: 07Jan2011, adding CSV Export 
				var exportCSVMenuItem = new dijit.MenuItem({
					title: this.resources_.EXPORT_ALL_CSV,
					label: this.resources_.EXPORT_ALL_CSV
				});
				exportCSVMenuItem.onClick = dojo.hitch (this, "_exportCSV");
				exportCSVMenuItem.onKeypress = dojo.hitch (this, "_exportCSV");
				exportDataMenu.addChild(exportCSVMenuItem);				
			
				//Combo Button for All Export Related Actions
				var exportDataCombo = new dijit.form.DropDownButton({
					showLabel: false,
					iconClass: "exportDataIcon",
					id: "exportDataIcon"+this.id,
					label: this.resources_.EXPORT,
					title: this.resources_.EXPORT,
					dropDown: exportDataMenu
				}, this.exportDataNode);
			}
			else
			{				
				dojo.style(this.exportDataNode.parentNode, "width", "0px");
			}
		},
		_addPrintIcon: function() {
			//Check whether we need to show the print icon or not
			if(this.plugins.printer && this.toolbarOptions.printerIcon) {
				var printDataMenu = new dijit.Menu({ style: "display: none;"});		    
				var printAllItem = new dijit.MenuItem({
					title: this.resources_.PRINT_ALL,
					label: this.resources_.PRINT_ALL
				});
				printAllItem.onClick = dojo.hitch (this, "_printAll");
				printAllItem.onKeypress = dojo.hitch (this, "_printAll");			     
				printDataMenu.addChild(printAllItem);
				var printSelectedMenuItem = new dijit.MenuItem({
					title: this.resources_.PRINT_SELECTED,
					label: this.resources_.PRINT_SELECTED
				});
				printSelectedMenuItem.onClick = dojo.hitch (this, "_printSelected");
				printSelectedMenuItem.onKeypress = dojo.hitch (this, "_printSelected");
				printDataMenu.addChild(printSelectedMenuItem);		     
				var printPreviewMenuItem = new dijit.MenuItem({
					title: this.resources_.PRINT_PREVIEW,
					label: this.resources_.PRINT_PREVIEW
				});
				printPreviewMenuItem.onClick = dojo.hitch (this, "_printPreview");
				printPreviewMenuItem.onKeypress = dojo.hitch (this, "_printPreview");
				
				printDataMenu.addChild(printPreviewMenuItem);		     
				//Combo Button for All Print Related Actions
				var printDataCombo = new dijit.form.DropDownButton({
					showLabel: false,
					iconClass: "printIcon",
					id: "printIcon"+this.id,
					label: this.resources_.PRINT,
					title: this.resources_.PRINT,
					dropDown: printDataMenu
				},this.printNode);
			}
			else
			{				
				dojo.style(this.printNode.parentNode, "width", "0px");
			}			
		},
		_addConfigTableIcon: function() {
			if(this.configTableIcon) {
				var configTableIcon = new dijit.form.Button({
						showLabel: false,
						iconClass: "configureColIcon",
						id: "configureColIcon"+this.id,
						label: this.resources_.CONFIGURE_SETTINGS,
						title: this.resources_.CONFIGURE_SETTINGS
					},this.configureColNode);
					
				configTableIcon.onClick = dojo.hitch (this, "_configureTable");
				configTableIcon.onKeypress = dojo.hitch (this, "_configureTable");
			}
			else
			{				
				dojo.style(this.configureColNode.parentNode, "width", "0px");
			}
		},
		_addActionMenu: function() {
			//Action List Menu
			if(this.actionMenu) {			
				//var seperator = new dijit.ToolbarSeparator({id: "actionMenuSeperator"+this.id},this.actionSeperator);
				var menu = new dijit.Menu({ style: "display: none;"});
				//menu.addChild(new dijit.MenuSeparator());
				
				//23789: Refresh should be part of Actions Menu also - OID
				//Bobby:29Jun11				
				if(this.refreshMenu) {
					//Menu Item for Configure Columns action
					var refreshMenuItem = new dijit.MenuItem({
						//Bobby:19Jul11, title is reqd by JAWS to anounce the menu item.					
						//24709: JAWS does not read the items in the Actions, Export or Print menus.
						title: this.resources_.REFRESH,
						label: this.resources_.REFRESH,
						iconClass: "refreshIcon"
					});
					refreshMenuItem.onClick = dojo.hitch (this, "_refreshTable");
					refreshMenuItem.onKeypress = dojo.hitch (this, "_refreshTable");					 
					menu.addChild(refreshMenuItem);
				}

				if(this.filterOptions.showAdvancedFilter){
					//Menu Item for Advanced Filter action
					var filterMenuItem = new dijit.MenuItem({
						title: this.resources_.ADVANCED_FILTER,
						label: this.resources_.ADVANCED_FILTER,
						//20508: Advanced Filter menu item on Actions menu has tooltip while other menu items do not
						//Bobby:25May11, removing unnecessary title, not reqd for Menu
						//title: this.resources_.ADVANCED_FILTER,
						iconClass: "filterIcon"
					});
					filterMenuItem.onClick = dojo.hitch (this, "_advancedFilter");
					filterMenuItem.onKeypress = dojo.hitch (this, "_advancedFilter");					 
					menu.addChild(filterMenuItem);
				}				
				
				
				if(this.plugins.exporter && this.toolbarOptions.exporterMenu) {
					//Sub-menu item for All Export Related Actions
					var exportDataSubMenu = new dijit.Menu();
					exportDataSubMenu.addChild(new dijit.MenuItem({
						title: this.resources_.EXPORT_HTML,
						label: this.resources_.EXPORT_HTML,
						onClick: dojo.hitch (this, this._exportHTML),
						onKeypress: dojo.hitch (this, this._exportHTML)
					}));	
					
					//Bobby: 07Jan2011, Adding export as CSV
					exportDataSubMenu.addChild(new dijit.MenuItem({
						title: this.resources_.EXPORT_ALL_CSV,
						label: this.resources_.EXPORT_ALL_CSV,
						onClick: dojo.hitch (this, this._exportCSV),
						onKeypress: dojo.hitch (this, this._exportCSV)
					}));					
						
					var exportDataItem = new dijit.PopupMenuItem({
						title: this.resources_.EXPORT,
						label: this.resources_.EXPORT,
						iconClass: "exportDataIcon",
						popup: exportDataSubMenu
					});
				    menu.addChild(exportDataItem);
				}
				
				if(this.plugins.printer && this.toolbarOptions.printerMenu) {
					//Sub-menu items for All Print Related Actions
					var printDataSubMenu = new dijit.Menu();
					printDataSubMenu.addChild(new dijit.MenuItem({
						title: this.resources_.PRINT_ALL,
						label: this.resources_.PRINT_ALL,
						onClick: dojo.hitch (this, this._printAll),
						onKeypress: dojo.hitch (this, this._printAll)
					}));
					printDataSubMenu.addChild(new dijit.MenuItem({
						title: this.resources_.PRINT_SELECTED,
						label: this.resources_.PRINT_SELECTED,
						onClick: dojo.hitch (this, this._printSelected),
						onKeypress: dojo.hitch (this, this._printSelected)
					}));
					printDataSubMenu.addChild(new dijit.MenuItem({
						title: this.resources_.PRINT_PREVIEW,
						label: this.resources_.PRINT_PREVIEW,
						onClick: dojo.hitch (this, this._printPreview),
						onKeypress: dojo.hitch (this, this._printPreview)
					}));
					var printMenuItem = new dijit.PopupMenuItem({
						title: this.resources_.PRINT,
						label: this.resources_.PRINT,
						iconClass: "printIcon",
						popup: printDataSubMenu
					});
					menu.addChild(printMenuItem);
				}
				
				if(this.configTableMenu) {
					//Menu Item for Configure Columns action
					var configureColMenuItem = new dijit.MenuItem({
						title: this.resources_.CONFIGURE_SETTINGS,
						label: this.resources_.CONFIGURE_SETTINGS,
						iconClass: "configureColIcon"
					});
					configureColMenuItem.onClick = dojo.hitch (this, "_configureTable");
					configureColMenuItem.onKeypress = dojo.hitch (this, "_configureTable");					 
					menu.addChild(configureColMenuItem);
				}				
				
			    menu.startup();
				//Initializing the Action List
			    var actionListMenu = new dijit.form.DropDownButton({
					optionsTitle : this.resources_.ACTIONS,
			        label: this.resources_.ACTIONS,
					title: this.resources_.ACTIONS,
					id: "actionListMenu"+this.id,
			        dropDown: menu
			    },this.actionListNode);				
				this.actionListWidget = actionListMenu;
			}
			else{				
				dojo.style(this.actionListNode.parentNode, "width", "0px");
			}
		},
		
		_addFilters: function() {
			//adding filters
			if(this.filterOptions.hideFilterBar == true && this.inGrid.showFilterBar !== undefined){
				//hide Advanced Filter bar
				this.inGrid.showFilterBar(false);
			}
			else if(this.filterOptions.hideFilterBar == false){
				//show Advanced Filter bar
				this.inGrid.showFilterBar(true);
			}			
			
			/*If 
				quickFilter 		- YES
				quickFilterButton 	- YES
				advancedFilter		- NO
			  then show only quickFilterButton
			*/
			if(this.filterOptions.showQuickFilter && this.filterOptions.showQuickFilterButton && !this.filterOptions.showAdvancedFilter){
				this._quickFilter = new dojoe.table._QuickFilter({
			        grid:this.inGrid,
					id: "quickFilter"+this.id,
					filterOptions: this.filterOptions,
					placeHolder: this.resources_.QF_DEFAULT_TEXT,
					clearIconText:this.resources_.CLEAR_FILTER
			    }, this.quickFilterNode);
				var quickFilterIcon = new dijit.form.Button({
						showLabel: false,
						iconClass: "filterIcon",
						id: "filterIcon"+this.id,
						//label: this.resources_.QUICK_FILTER,
						title: this.resources_.QUICK_FILTER
					},this.filterNode);				
				quickFilterIcon.onClick = dojo.hitch (this, "_setQuickFilter");
				quickFilterIcon.onKeypress = dojo.hitch (this, "_setQuickFilter");
				quickFilterIcon.domNode.title = this.resources_.QUICK_FILTER;				
			}			
			/*If 
				quickFilter 		- YES
				quickFilterButton 	- YES
				advancedFilter		- YES
			  then show filter combobutton
			*/			
			else if(this.filterOptions.showQuickFilter && this.filterOptions.showQuickFilterButton && this.filterOptions.showAdvancedFilter){
				this._quickFilter = new dojoe.table._QuickFilter({
			        grid:this.inGrid,
					id: "quickFilter"+this.id,
					filterOptions: this.filterOptions,
					clearIconText:this.resources_.CLEAR_FILTER,
					placeHolder: this.resources_.QF_DEFAULT_TEXT
			    }, this.quickFilterNode);
								
				var menu = new dijit.Menu({ });
				menu.domNode.style.display="none";
				var qfMenuItem = new dijit.MenuItem({
					label: this.resources_.QF_DEFAULT_TEXT,
					//iconClass: "filterIcon",
					onClick: dojo.hitch (this, "_setQuickFilter"),
					onKeypress: dojo.hitch (this, "_setQuickFilter")
				});
				var afMenuItem = new dijit.MenuItem({
					label: this.resources_.ADVANCED_FILTER,
					//iconClass: "filterIcon",
					onClick: dojo.hitch (this, "_advancedFilter"),
					onKeypress: dojo.hitch (this, "_advancedFilter")
				});				
				menu.addChild(qfMenuItem);
				menu.addChild(afMenuItem);
				
				var comboFilterIcon = new dijit.form.ComboButton({
						showLabel: false,
						iconClass: "filterIcon",
						id: "comboFilterIcon"+this.id,
						label: this.resources_.QUICK_FILTER,
						title: this.resources_.QUICK_FILTER,
						dropDown: menu,
						onClick: dojo.hitch (this, "_setQuickFilter"),
						onKeypress: dojo.hitch (this, "_setQuickFilter")
					},this.filterNode);
			}
			/*If 
				quickFilter 		- YES
				quickFilterButton 	- NO
				advancedFilter		- NO
			  then show filter textbox only
			*/				
			else if(this.filterOptions.showQuickFilter && !this.filterOptions.showQuickFilterButton && !this.filterOptions.showAdvancedFilter){
				this._quickFilter = new dojoe.table._QuickFilter({
			        grid:this.inGrid,
					id: "quickFilter"+this.id,
					filterOptions: this.filterOptions,
					clearIconText:this.resources_.CLEAR_FILTER,
					placeHolder: this.resources_.QF_DEFAULT_TEXT
			    }, this.quickFilterNode);
			}
			/*If 
				quickFilter 		- YES
				quickFilterButton 	- NO
				advancedFilter		- YES
			  then show filter textbox and AdvancedFilter button
			*/			
			
			else if(this.filterOptions.showAdvancedFilter && !this.filterOptions.showQuickFilterButton && this.filterOptions.showAdvancedFilter){
				this._quickFilter = new dojoe.table._QuickFilter({
			        grid:this.inGrid,
					id: "quickFilter"+this.id,
					filterOptions: this.filterOptions,
					clearIconText:this.resources_.CLEAR_FILTER,
					placeHolder: this.resources_.QF_DEFAULT_TEXT
			    }, this.quickFilterNode);
				
				var advancedFilterIcon = new dijit.form.Button({
						showLabel: false,
						iconClass: "filterIcon",
						id: "advancedFilterIcon"+this.id,
						//label: this.resources_.ADVANCED_FILTER,
						title: this.resources_.ADVANCED_FILTER
					},this.filterNode);				
				advancedFilterIcon.onClick = dojo.hitch (this, "_advancedFilter");
				advancedFilterIcon.onKeypress = dojo.hitch (this, "_advancedFilter");
				//advancedFilterIcon.domNode.title = this.resources_.ADVANCED_FILTER;
			}
			/*If 
				quickFilter 		- NO
				quickFilterButton 	- NO
				advancedFilter		- YES
			  then show AdvancedFilter button only
			*/				
			else if(!this.filterOptions.showAdvancedFilter && this.filterOptions.showAdvancedFilter) {
				var advancedFilterIcon = new dijit.form.Button({
						showLabel: false,
						iconClass: "filterIcon",
						id: "advancedFilterIcon"+this.id,
						//label: this.resources_.ADVANCED_FILTER,
						title: this.resources_.ADVANCED_FILTER
					},this.filterNode);				
				advancedFilterIcon.onClick = dojo.hitch (this, "_advancedFilter");
				advancedFilterIcon.onKeypress = dojo.hitch (this, "_advancedFilter");
				//advancedFilterIcon.domNode.title = this.resources_.ADVANCED_FILTER;						
			}//else don't show qf or af.
		},
		
		
		_refreshTable: function(){
			this.tivTable.refresh();
		},
		
		//default formatter for print/export output.
		_customizeData: function(){
			//set only if default formatter is reqd
			if (this.tivTable.defaultExportFormatter){
				this.inGrid.setExportFormatter(function(data, cell, rowIndex, rowItem){
					return data;
				});
			}
		},
		
		_exportHTML: function(){
			this._customizeData();
			var grid = this.inGrid;
			/*this.inGrid.exportGrid("table",function(str){
				var win = window.open();
				win.document.open();
				win.document.write(str);
				win.document.close();
			});*/
			/*#24000 - 11 Jul 2011 -dojo grid is now accepting only string uri for loading .css, now sure why */
			var url = dojo.moduleUrl("dojoe", "table/themes/print_style.css");
			var urlStr = url.toString();
			var printArgs = {title: this.resources_.EXPORT_HTML, cssFiles: [urlStr]};
			if(this.inGrid.selection.getSelectedCount() > 0) {
				this.inGrid.exportSelectedToHTML(printArgs,function(exportedString) {
					var win = window.open();
					win.document.open();
					win.document.write(exportedString);
					//Do adjustments to fix the problems of preview here.					
					grid.normalizePrintedGrid(win.document);
					win.document.close();
				});
			}
			else {			
				this.inGrid.exportToHTML(printArgs,
					function(str){
						var win = window.open();
						win.document.open();
						win.document.write(str);
						//Do adjustments to fix the problems of preview here.
						grid.normalizePrintedGrid(win.document);
						win.document.close();
					}
				);
			}
		},		
		
	   //Bobby: 07Jan2011, adding CSV Export 
		_exportCSV: function(){
		  this._customizeData();	
		  this.inGrid.exportGrid("csv",
			function(str){
				//Bobby:16Apr2011. Browser messes up the format of CSV
			    //16850: TBSM: Table CSV Export not usable by Excel
				//var win = window.open();
				//win.document.open();
				//win.document.write(str);
				//win.document.close();
				resources_ = dojo.i18n.getLocalization("dojoe.table", "Table", this.lang);		
				var exportTextArea = new dijit.form.SimpleTextarea({
					value: str,
					rows: 20,
					cols: 100,
					//style: "width:80%; height:80%",
					selectOnClick: true
				});
				exportTextArea.selected = true;
				var exportDialog = new dijit.Dialog({
					title: resources_.EXPORT_ALL_CSV+ " - " + resources_.EXPORT_ALL_CSV_SAVE
				});	
                exportDialog.attr("content",exportTextArea);
				exportDialog.show();				
			}
		  );
		},			
		
		_printAll: function(){
			this._customizeData();
			/*#24000 - 11 Jul 2011 -dojo grid is now accepting only string uri for loading .css, now sure why */
			var url = dojo.moduleUrl("dojoe", "table/themes/print_style.css");
			var urlStr = url.toString();
			var printArgs = {title: this.resources_.PRINT_ALL, cssFiles: [urlStr]};
			this.inGrid.printGrid(printArgs);
		},		
		_printSelected: function(){
			this._customizeData();
			/*#24000 - 11 Jul 2011 -dojo grid is now accepting only string uri for loading .css, now sure why */
			var url = dojo.moduleUrl("dojoe", "table/themes/print_style.css");
			var urlStr = url.toString();
			var printArgs = {title: this.resources_.PRINT_SELECTED, cssFiles: [urlStr]};
			this.inGrid.printSelected(printArgs);
		},		
		_printPreview: function(){
			this._customizeData();
			var grid = this.inGrid;
			/*#24000 - 11 Jul 2011 -dojo grid is now accepting only string uri for loading .css, now sure why */
			var url = dojo.moduleUrl("dojoe", "table/themes/print_style.css");
			var urlStr = url.toString();
			var printArgs = {title: this.resources_.PRINT_PREVIEW, cssFiles: [urlStr]};
			if(this.inGrid.selection.getSelectedCount() > 0) {
				this.inGrid.exportSelectedToHTML(printArgs,function(exportedString) {
					var win = window.open();
					win.document.open();
					win.document.write(exportedString);
					//Do adjustments to fix the problems of preview here.					
					grid.normalizePrintedGrid(win.document);
					win.document.close();
				});
			}
			else {			
			this.inGrid.exportToHTML(printArgs,
				function(str){
					var win = window.open();
					win.document.open();
					win.document.write(str);
					//Do adjustments to fix the problems of preview here.					
					grid.normalizePrintedGrid(win.document);
					win.document.close();
				}
			);
			}
		},
		_setQuickFilter: function(){
			//console.info("In _setQuickFilter.....");
			this._quickFilter._setFilter();
		},
		_advancedFilter: function(){
		    //this.inGrid.toggleFilterBar();
			this.inGrid.pluginMgr.getPlugin("Filter").filterDefDialog.showDialog(); 
			this.inGrid.showFilterBar(true, true, {
				duration: 200
			});
		},
		_configureTable: function(){
			this.configureTableDialog = new dojoe.table._ConfigureColumnsDialog(
				{ grid: this.inGrid }
			);	
			this.configureTableDialog.show();
		},
		
		//do not call this method directly, use table.addBeforeDefaultIcons(item) method to add a custom item to the toolbar before default buttons
		_addToToolbarFirstRow: function(item, position){
			var itemTD = dojo.doc.createElement("span"); 
			dojo.style(itemTD, "width", "1px"); 
			//Bobby:24May11, making position optional. If not mentioned, added at last.
			//22853: Table toolbar ordering reversed
			//Bobby:28Jun11, creating a new span area for user items
			//if(position) fails if position is 0
			if(position !== undefined){
				dojo.place(itemTD, this.toolbarFirstRow_userItems, parseInt(position));
			}else dojo.place(itemTD, this.toolbarFirstRow_userItems, 'last');
			itemTD.appendChild(item.domNode);
		},
		
		_addToToolbarSecondRow: function(item, position){
			var itemTD = dojo.doc.createElement("span"); 
			dojo.style(itemTD, "width", "1px"); 
			//Bobby:24May11, making position optional. If not mentioned, added at last.
			if(position !== undefined){
				dojo.place(itemTD, this.toolbarSecondRow, parseInt(position));
			}else dojo.place(itemTD, this.toolbarSecondRow, 'last');
			itemTD.appendChild(item.domNode);
		},		
		
		//do not call this method directly, use table.removeItemFromToolbar(itemId) method to remove a custom item from the toolbar
		_removeItem: function(itemId){
			var button= dijit.byId(itemId);
			if(button !== null && button !== undefined) {		
				if (button.domNode.parentNode) {
					//remove td which is the parent of the button
					buttonParent = button.domNode.parentNode;
					buttonParent.parentNode.removeChild(buttonParent);
				}
				button.destroyRecursive();
			}
		},
			
		_mapToolbarOptions: function(){
			if(this.toolbarOptions) {
				if(this.toolbarOptions.refreshIcon == false){
					this.refreshIcon = this.toolbarOptions.refreshIcon;
				}
				//23789: Refresh should be part of Actions Menu also - OID
				//Bobby:29Jun11
				if(this.toolbarOptions.refreshMenu == false){
					this.refreshMenu = this.toolbarOptions.refreshMenu;
				}				
				if(this.toolbarOptions.configTableIcon == false){
					this.configTableIcon = this.toolbarOptions.configTableIcon;
				}
				if(this.toolbarOptions.configTableMenu == false){
					this.configTableMenu = this.toolbarOptions.configTableMenu;
				}
				if(this.toolbarOptions.actionMenu == false){
					this.actionMenu = this.toolbarOptions.actionMenu;
				}
			}
		},
		
		_addToActionList: function(item) {
			if(this.actionMenu) {
				//always add new menu items to the top of the menu
				this.actionListWidget.dropDown.addChild(item, 0);
			}
		},
		
		_removeFromActionList: function (menuItemId){		
			var menuItem = dijit.byId(menuItemId);
			if(menuItem !== null && menuItem !== undefined) {
				menuItem.destroyRecursive();
			}
		},
		
		_enableMenuItem : function(menuItemId){
			var menuItem= dijit.byId(menuItemId);
			if(menuItem !== null && menuItem !== undefined) {
				menuItem.set('disabled', false);
			}
		},
		
		_disableMenuItem : function(menuItemId){
			var menuItem= dijit.byId(menuItemId);
			if(menuItem !== null && menuItem !== undefined) {
				menuItem.set('disabled', true);
			}
		},
		
		destroy: function(){
			// summary:  Destroys the toolbar.
			// tags: public	
			//memory leak issue: custom destroy method to take care of removing all widgets					
			try{
				delete this.resources_;
				//this is for destroying child templated widgets 
				//this should happen by itself but need to figure out why dijit._Templated is not taking care of it...
				var widgets = dijit.findWidgets(this.domNode);
				dojo.forEach(widgets, function(w) {
					if(w){
						if(w.destroyRecursive){
							w.destroyRecursive();
						} else if(w.destroy){
							w.destroy();
						}
					}
				});
				// this is for widgets added as child to this widget and their children..
				//not present in template
				var widgetArr = this.getChildren();
				dojo.forEach(widgetArr, function (child) {
					if(child){
						if(child.destroyRecursive){
							child.destroyRecursive();
						} else if(child.destroy){
							child.destroy();
						}
					}
				});
				this.inherited(arguments);
			}catch(ex){
				console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
			}
		}
		
	});

}
