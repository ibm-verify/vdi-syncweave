/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.table._ConfigureColumnsDialog"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.table._ConfigureColumnsDialog"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.table._ConfigureColumnsDialog");

dojo.require("dijit._Widget");
dojo.require("dijit._Templated");
dojo.require("dijit.Dialog");
dojo.require("dijit.Toolbar");
dojo.require("dijit.form.Form");
dojo.require("dijit.form.Button");
dojo.require("dijit.form.CheckBox");
dojo.require("dijit.layout.TabContainer");
dojo.require("dijit.layout.LayoutContainer");
dojo.require("dijit.layout.ContentPane");
dojo.require("dijit._Container");

dojo.require("dojoe.table._TableOptions");

// NLS
dojo.requireLocalization("dojoe.table", "Table", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");
// define the widget class
dojo.declare ("dojoe.table._ConfigureColumnsDialog", [ dijit._Widget, dijit._Templated ],{
		widgetsInTemplate: true,
		// Path to the template
		templateString : dojo.cache("dojoe.table", "templates/ConfigureColumnsDialog.html", "\r\n<div>\r\n  <div dojoType=\"dijit.Dialog\" dojoAttachPoint=\"dialog\"\ttitle=\"${resources_.CONFIGURE_SETTINGS}\" tabindex=0 role=\"dialog\" style=\"width:350px;height:260px;overflow:auto;\" >\r\n\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" role=\"presentation\" style=\"width:100%height:100%\">\r\n\t\t\t<tr height=\"20%\" style=\"vertical-align:top;\"><td>\r\n\t\t\t\t<div  style=\"width:100%;height:100%;overflow:auto;\" class=\"tivTable\">\r\n\t\t\t\t\t<label>${resources_.COLUMNS_VISIBLE}</label>\t\t\r\n\t\t\t\t\t \t\r\n\t                  <table border=\"0\" cellspacing=\"7\" cellpadding=\"0\" role=\"presentation\">\r\n\t\t\t\t\t\t<tbody>\r\n\t\t\t\t\t\t\t<tr>\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t<td>\r\n\t\t\t\t\t\t\t\t\t<span dojoAttachPoint=\"selectAllButton\" role=\"button\">\r\n\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t\t<td>\r\n\t\t\t\t\t\t\t\t\t<span dojoAttachPoint=\"deselectAllButton\" role=\"button\">\r\n\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t\t</tbody>\r\n\t\t\t\t\t</table>\r\n\t\t\t\t</div>\r\n\t\t\t</td></tr>\r\n\t\t\t<tr height=\"50%\"><td>\t\t\r\n\t\t\t\t<div tabStrip=\"false\" id=\"${id}tabs\" dojoType=\"dijit.layout.LayoutContainer\"  class=\"dialog\" style=\"vertical-align:top;width:315px;height:110px;overflow-x:hidden;overflow-y:auto;padding:2px 0px 0px 10px;\">\r\n\t\t\t\t \t<div dojoType=\"dijit.layout.ContentPane\" style=\"width:100%;\">\r\n\t\t\t\t\t\t<div id=\"${id}columnsVisibleDivContainer\" >\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t \t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</td></tr>\r\n\t\t\t<tr><td><br/></td></tr>\t\r\n\t\t\t<tr height=\"30%\" style=\"vertical-align:top;\"><td >\t\r\n\t\t\t\t<button value=\"${resources_.OK}\" dojoType=\"dijit.form.Button\" role=\"button\"\r\n\t\t\t\t\tdojoAttachEvent=\"onClick:onOK,onKeypress:onOK\">${resources_.OK}</button>&nbsp;\r\n\t\t\t\t<button value=\"${resources_.CANCEL}\" dojoType=\"dijit.form.Button\" role=\"button\"\r\n\t\t\t\tdojoAttachPoint=\"cancelButton\" dojoAttachEvent=\"onClick:onCancel,onKeypress:onCancel\">${resources_.CANCEL}</button>\t\r\n\t\t\t</td></tr>\r\n\t\t</table>\r\n  </div>\r\n</div>\r\n"),		
		optionsWidget_: null,
		constructor: function() {
			this.resources_ = dojo.i18n.getLocalization("dojoe.table", "Table", this.lang);
		},		
		postCreate: function() { 
			this.inherited ("postCreate", arguments);
			this.optionsWidget_=new dojoe.table._TableOptions({
				grid: this.grid
			}, dojo.byId(this.id + "columnsVisibleDivContainer"));
			this.optionsWidget_.startup();	

			var selectIcon = new dijit.form.Button({
				id: this.id+"selectAllIcon",
				showLabel: false,
				iconClass: "selectAllIcon",
				label: this.resources_.SELECT_ALL
			},this.selectAllButton);
				
			selectIcon.onClick = dojo.hitch (this, "onSelectAll");
			selectIcon.onKeypress = dojo.hitch (this, "onSelectAll");		
			
			var deSelectIcon = new dijit.form.Button({
				id: this.id+"deselectAllIcon",
				showLabel: false,
				iconClass: "deselectAllIcon",
				label: this.resources_.DESELECT_ALL
			},this.deselectAllButton);
				
			deSelectIcon.onClick = dojo.hitch (this, "onDeselectAll");
			deSelectIcon.onKeypress = dojo.hitch (this, "onDeselectAll");
						
		},		
		onSelectAll: function(){		
			this.optionsWidget_.onSelectAll();
		},		
		onDeselectAll: function(){		
			this.optionsWidget_.onDeselectAll();
		},		
		onOK: function () {
		/*Ls - 17/01/2012 - 30956 - showing cursor busy when saving the column configuration*/
			window.document.body.style.cursor = 'wait';
			this.optionsWidget_.onSave();
			this.hide();
			window.document.body.style.cursor = 'default';
		},		
		onCancel: function () {
			this.hide();
		},		
		show: function () {
			this.dialog.show();
			dijit.byId (this.id + "tabs").resize();
		},		
		hide: function () {
			this.dialog.hide();
			setTimeout (dojo.hitch (this, this.kill), 100);
		},		
		kill: function () {
			var id = this.id;
			this.destroyRecursive();
			dijit.registry.remove (id);
		},		
		getTableOptions: function () {
			return this.optionsWidget_;
		},
		destroy: function () {
			//memory leak issue: custom destroy method to take care of removing all widgets					
			try{
				delete this.resources_;
				//this is for destroying child templated widgets 
				//this should happen by itself but need to figure out why dijit._Templated is not taking care of it...
				var widgets = dijit.findWidgets(this.domNode);
				dojo.forEach(widgets, function(w) {
					if(w){
						if(w.destroyRecursive){
							w.destroyRecursive();
						} else if(w.destroy){
							w.destroy();
						}
					}
				});
				// this is for widgets added as child to this widget and their children..
				//not present in template
				var widgetArr = this.getChildren();
				dojo.forEach(widgetArr, function (child) {
					if(child){
						if(child.destroyRecursive){
							child.destroyRecursive();
						} else if(child.destroy){
							child.destroy();
						}
					}
				});
				this.inherited(arguments);
			}catch(ex){
				console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
			}
		}
	}
);

}
