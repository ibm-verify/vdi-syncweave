/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Vie valitut CSV-tiedostoksi","QUICK_FILTER":"Pikasuodatin","PRINT_SELECTED":"Tulosta valitut","EXPORT_ALL_CSV":"Vie kaikki CSV-tiedostoksi","CONFIGURE_SETTINGS":"Määritä asetukset","EXPORT":"Vie","DESELECT_ALL":"Poista kaikkien valinta","COLUMNS_VISIBLE":"Määritä, mitkä sarakkeet ovat näkyvissä:","PRINT_ALL":"Tulosta kaikki","REFRESH":"Päivitä","ADVANCED_FILTER":"Erikoissuodatin","PRINT":"Tulosta","COLUMNS":"Sarakkeet","PRINT_PREVIEW":"Tulostuksen esikatselu","PROCESSING":"Käsittely meneillään...","NO_DATA":"Ei tietoja esitettäväksi","SELECT_ALL":"Valitse kaikki","CLEAR_FILTER":"Tyhjennä suodatin","EXPORT_HTML":"Vie HTML-tiedostoksi","OK":"OK","QF_DEFAULT_TEXT":"Suodatin","CANCEL":"Peruuta","EXPORT_ALL_CSV_SAVE":"Kopioi ja tallenna sisältö CSV-tiedostoksi","ACTIONS":"Toiminnot"})