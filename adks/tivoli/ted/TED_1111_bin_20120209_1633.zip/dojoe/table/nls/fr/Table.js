/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Exporter la sélection vers un CSV","QUICK_FILTER":"Filtre rapide","PRINT_SELECTED":"Imprimer la sélection","EXPORT_ALL_CSV":"Exporter tout vers un CSV","CONFIGURE_SETTINGS":"Configurer les options","EXPORT":"Exporter","DESELECT_ALL":"Tout désélectionner","COLUMNS_VISIBLE":"Indiquer les colonnes visibles :","PRINT_ALL":"Tout imprimer","REFRESH":"Actualiser","ADVANCED_FILTER":"Filtre avancé","PRINT":"Imprimer","COLUMNS":"Colonnes","PRINT_PREVIEW":"Aperçu avant impression","PROCESSING":"Traitement en cours...","NO_DATA":"Pas de données à afficher","SELECT_ALL":"Tout sélectionner","CLEAR_FILTER":"Effacer le filtre","EXPORT_HTML":"Exporter en HTML","OK":"OK","QF_DEFAULT_TEXT":"Filtrer","CANCEL":"Annuler","EXPORT_ALL_CSV_SAVE":"Copier et enregistrer le contenu en tant que fichier CSV","ACTIONS":"Actions"})