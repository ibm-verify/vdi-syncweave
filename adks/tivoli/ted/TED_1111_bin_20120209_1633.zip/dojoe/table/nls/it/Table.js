/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Esporta selezione in CSV","QUICK_FILTER":"Filtro rapido","PRINT_SELECTED":"Stampa selezione","EXPORT_ALL_CSV":"Esporta tutto in CSV","CONFIGURE_SETTINGS":"Configura opzioni","EXPORT":"Esporta","DESELECT_ALL":"Deseleziona tutto","COLUMNS_VISIBLE":"Indicare quali colonne sono visibili:","PRINT_ALL":"Stampa tutto","REFRESH":"Aggiorna","ADVANCED_FILTER":"Filtro avanzato","PRINT":"Stampa","COLUMNS":"Colonne","PRINT_PREVIEW":"Anteprima di stampa","PROCESSING":"Elaborazione in corso...","NO_DATA":"Nessun dato da visualizzare","SELECT_ALL":"Seleziona tutto","CLEAR_FILTER":"Cancella filtro","EXPORT_HTML":"Esporta come HTML","OK":"OK","QF_DEFAULT_TEXT":"Filtro","CANCEL":"Annulla","EXPORT_ALL_CSV_SAVE":"Copia e salva il contenuto come file CSV","ACTIONS":"Azioni"})