/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Export Selected to CSV","QUICK_FILTER":"Quick Filter","PRINT_SELECTED":"Print Selected","EXPORT_ALL_CSV":"Export All to CSV","CONFIGURE_SETTINGS":"Configure Options","EXPORT":"Export","DESELECT_ALL":"Deselect All","COLUMNS_VISIBLE":"Indicate which columns are visible:","PRINT_ALL":"Print All","REFRESH":"Refresh","ADVANCED_FILTER":"Advanced Filter","PRINT":"Print","COLUMNS":"Columns","PRINT_PREVIEW":"Print Preview","PROCESSING":"Processing...","NO_DATA":"No data to display","SELECT_ALL":"Select All","CLEAR_FILTER":"Clear Filter","EXPORT_HTML":"Export as HTML","OK":"OK","QF_DEFAULT_TEXT":"Filter","CANCEL":"Cancel","EXPORT_ALL_CSV_SAVE":"Copy and Save the content as a CSV file","ACTIONS":"Actions"})