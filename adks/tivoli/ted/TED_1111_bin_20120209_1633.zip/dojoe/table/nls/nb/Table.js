/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Eksporter valgte til CSV","QUICK_FILTER":"Hurtigfilter","PRINT_SELECTED":"Skriv ut valgte","EXPORT_ALL_CSV":"Eksporter alle til CSV","CONFIGURE_SETTINGS":"Konfigurer alternativer","EXPORT":"Eksporter","DESELECT_ALL":"Opphev valg av alle","COLUMNS_VISIBLE":"Oppgi hvilke kolonner som er synlige:","PRINT_ALL":"Skriv ut alle","REFRESH":"Oppdater","ADVANCED_FILTER":"Avansert filter","PRINT":"Skriv ut","COLUMNS":"Kolonner","PRINT_PREVIEW":"Forhåndsvisning","PROCESSING":"Behandler...","NO_DATA":"Ingen data å vise","SELECT_ALL":"Velg alle","CLEAR_FILTER":"Tøm filter","EXPORT_HTML":"Eksporter som HTML","OK":"OK","QF_DEFAULT_TEXT":"Filter","CANCEL":"Avbryt","EXPORT_ALL_CSV_SAVE":"Kopier og lagre innholdet som en CSV-fil","ACTIONS":"Handlinger"})