/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Auswahl in CSV exportieren","QUICK_FILTER":"Schnellfilter","PRINT_SELECTED":"Auswahl drucken","EXPORT_ALL_CSV":"Alles in CSV exportieren","CONFIGURE_SETTINGS":"Konfigurationsoptionen","EXPORT":"Exportieren","DESELECT_ALL":"Alles abwählen","COLUMNS_VISIBLE":"Angeben, welche Spalten sichtbar sind:","PRINT_ALL":"Alles drucken","REFRESH":"Aktualisieren","ADVANCED_FILTER":"Erweiterter Filter","PRINT":"Drucken","COLUMNS":"Spalten","PRINT_PREVIEW":"Druckvorschau","PROCESSING":"Verarbeitung läuft...","NO_DATA":"Keine Daten zum Anzeigen vorhanden","SELECT_ALL":"Alles auswählen","CLEAR_FILTER":"Filter aufheben","EXPORT_HTML":"Als HTML exportieren","OK":"OK","QF_DEFAULT_TEXT":"Filtern","CANCEL":"Abbrechen","EXPORT_ALL_CSV_SAVE":"Inhalt kopieren und als CSV-Datei speichern","ACTIONS":"Aktionen"})