/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Izvozi izbrano v datoteko CSV","QUICK_FILTER":"Hitri filter","PRINT_SELECTED":"Natisni izbrano","EXPORT_ALL_CSV":"Izvozi vse v datoteko CSV","CONFIGURE_SETTINGS":"Konfiguriraj možnosti","EXPORT":"Izvoz","DESELECT_ALL":"Razveljavi izbiro vseh","COLUMNS_VISIBLE":"Navedite katere so vidne kolone:","PRINT_ALL":"Natisni vse","REFRESH":"Osveži","ADVANCED_FILTER":"Zahtevnejši filter","PRINT":"Natisni","COLUMNS":"Stolpci","PRINT_PREVIEW":"Predogled tiskanja","PROCESSING":"Obdelava...","NO_DATA":"Ni podatkov za prikaz","SELECT_ALL":"Izberi vse","CLEAR_FILTER":"Počisti filter","EXPORT_HTML":"Izvozi kot HTML","OK":"V redu","QF_DEFAULT_TEXT":"Filter","CANCEL":"Prekliči","EXPORT_ALL_CSV_SAVE":"Kopiraj in shrani vsebino kot datoteko CSV","ACTIONS":"Dejanja"})