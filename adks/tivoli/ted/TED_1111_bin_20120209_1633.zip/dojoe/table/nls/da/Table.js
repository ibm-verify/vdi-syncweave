/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Eksportér markeret til CSV","QUICK_FILTER":"Kvikfilter","PRINT_SELECTED":"Udskriv markeret","EXPORT_ALL_CSV":"Eksportér alt til CSV","CONFIGURE_SETTINGS":"Konfigurér indstillinger","EXPORT":"Eksportér","DESELECT_ALL":"Ophæv markering af alle","COLUMNS_VISIBLE":"Angiv, hvilke kolonner der er synlige:","PRINT_ALL":"Udskriv alle","REFRESH":"Opfrisk","ADVANCED_FILTER":"Avanceret filter","PRINT":"Udskriv","COLUMNS":"Kolonner","PRINT_PREVIEW":"Udskriv eksempel","PROCESSING":"Behandler...","NO_DATA":"Ingen data at vise","SELECT_ALL":"Markér alle","CLEAR_FILTER":"Ryd filter","EXPORT_HTML":"Eksportér som HTML","OK":"OK","QF_DEFAULT_TEXT":"Filter","CANCEL":"Annullér","EXPORT_ALL_CSV_SAVE":"Kopiér og gem indholdet som en CSV-fil","ACTIONS":"Handlinger"})