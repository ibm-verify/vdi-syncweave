/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Eksportuj zaznaczone do CSV","QUICK_FILTER":"Szybki filtr","PRINT_SELECTED":"Drukuj zaznaczone","EXPORT_ALL_CSV":"Eksportuj wszystko do CSV","CONFIGURE_SETTINGS":"Konfigurowanie opcji","EXPORT":"Eksportuj","DESELECT_ALL":"Anuluj wybór wszystkiego","COLUMNS_VISIBLE":"Określ, które kolumny mają być widoczne:","PRINT_ALL":"Drukuj wszystko","REFRESH":"Odśwież","ADVANCED_FILTER":"Filtr zaawansowany","PRINT":"Drukuj","COLUMNS":"Kolumny","PRINT_PREVIEW":"Podgląd wydruku","PROCESSING":"Przetwarzanie...","NO_DATA":"Brak danych do wyświetlenia","SELECT_ALL":"Wybierz wszystko","CLEAR_FILTER":"Wyczyść filtr","EXPORT_HTML":"Eksportuj jako HTML","OK":"OK","QF_DEFAULT_TEXT":"Filtr","CANCEL":"Anuluj","EXPORT_ALL_CSV_SAVE":"Skopiuj i zapisz zawartość jako plik CSV","ACTIONS":"Działania"})