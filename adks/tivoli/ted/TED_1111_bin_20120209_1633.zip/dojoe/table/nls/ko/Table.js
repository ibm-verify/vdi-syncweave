/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"CSV로 선택 항목 내보내기","QUICK_FILTER":"빠른 필터","PRINT_SELECTED":"선택 인쇄","EXPORT_ALL_CSV":"CSV에 모두 내보내기","CONFIGURE_SETTINGS":"선택사항 구성","EXPORT":"내보내기","DESELECT_ALL":"모두 선택 취소","COLUMNS_VISIBLE":"볼 수 있는 컬럼 표시:","PRINT_ALL":"모두 인쇄","REFRESH":"새로 고치기","ADVANCED_FILTER":"고급 필터","PRINT":"인쇄","COLUMNS":"컬럼","PRINT_PREVIEW":"인쇄 미리보기","PROCESSING":"처리 중...","NO_DATA":"표시할 데이터 없음","SELECT_ALL":"모두 선택","CLEAR_FILTER":"필터 지우기","EXPORT_HTML":"HTML 유형으로 내보내기","OK":"확인","QF_DEFAULT_TEXT":"필터","CANCEL":"취소","EXPORT_ALL_CSV_SAVE":"내용을 복사하고 CSV 파일로 저장","ACTIONS":"조치"})