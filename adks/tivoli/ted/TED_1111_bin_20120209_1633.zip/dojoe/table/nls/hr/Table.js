/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Eksportiraj izabrano u CSV","QUICK_FILTER":"Brzi filter","PRINT_SELECTED":"Ispiši izabrano","EXPORT_ALL_CSV":"Eksportiraj sve u CSV","CONFIGURE_SETTINGS":"Konfiguriraj opcije","EXPORT":"Eksportiraj","DESELECT_ALL":"Odznači sve","COLUMNS_VISIBLE":"Označi vidljive stupce:","PRINT_ALL":"Ispiši sve","REFRESH":"Osvježi","ADVANCED_FILTER":"Napredni filter","PRINT":"Ispis","COLUMNS":"Stupci","PRINT_PREVIEW":"Pregled ispisa","PROCESSING":"Obrada...","NO_DATA":"Nema podataka za prikaz","SELECT_ALL":"Izaberi sve","CLEAR_FILTER":"Brisanje filtera","EXPORT_HTML":"Eksportiraj kao HTML","OK":"OK","QF_DEFAULT_TEXT":"Filter","CANCEL":"Opoziv","EXPORT_ALL_CSV_SAVE":"Kopiraj i spremi sadržaj kao CSV datoteku","ACTIONS":"Akcije"})