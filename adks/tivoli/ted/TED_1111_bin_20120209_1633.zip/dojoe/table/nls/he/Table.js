/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"יצוא פריטים נבחרים ל-CSV","QUICK_FILTER":"סינון מהיר","PRINT_SELECTED":"הדפסת פריטים נבחרים","EXPORT_ALL_CSV":"יצוא הכל ל-CSV","CONFIGURE_SETTINGS":"אפשרויות קביעת תצורה","EXPORT":"יצוא","DESELECT_ALL":"ביטול בחירת הכל","COLUMNS_VISIBLE":"ציון עמודות גלויות:","PRINT_ALL":"הדפסת הכל","REFRESH":"רענון","ADVANCED_FILTER":"סינון מתקדם","PRINT":"הדפסה","COLUMNS":"עמודות","PRINT_PREVIEW":"תצוגה מקדימה של הדפסה","PROCESSING":"מעבד...","NO_DATA":"אין נתונים להצגה","SELECT_ALL":"בחירת הכל","CLEAR_FILTER":"ניקוי מסנן","EXPORT_HTML":"יצוא בתור HTML","OK":"אישור","QF_DEFAULT_TEXT":"מסנן","CANCEL":"ביטול","EXPORT_ALL_CSV_SAVE":"העתקה ושמירה של התוכן כקובץ CSV","ACTIONS":"פעולות"})