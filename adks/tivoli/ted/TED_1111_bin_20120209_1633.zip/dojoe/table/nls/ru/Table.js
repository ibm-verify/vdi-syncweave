/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Экспортировать выбранное в CSV","QUICK_FILTER":"Экспресс-фильтр","PRINT_SELECTED":"Напечатать выбранное","EXPORT_ALL_CSV":"Экспортировать все в CSV","CONFIGURE_SETTINGS":"Конфигурировать опции","EXPORT":"Экспорт","DESELECT_ALL":"Отменить выбор всех","COLUMNS_VISIBLE":"Указать, какие столбцы будут видимы","PRINT_ALL":"Напечатать все","REFRESH":"Обновить","ADVANCED_FILTER":"Расширенный фильтр","PRINT":"Печать","COLUMNS":"Столбцы","PRINT_PREVIEW":"Предварительный просмотр печати","PROCESSING":"Обрабатывается...","NO_DATA":"Нет данных для показа","SELECT_ALL":"Выбрать все","CLEAR_FILTER":"Удалить фильтр","EXPORT_HTML":"Экспортировать в HTML","OK":"ОК","QF_DEFAULT_TEXT":"Фильтр","CANCEL":"Отмена","EXPORT_ALL_CSV_SAVE":"Скопировать и сохранить содержимое в виде CSV-файла","ACTIONS":"Действия"})