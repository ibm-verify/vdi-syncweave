/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"匯出選定頁面至 CSV","QUICK_FILTER":"快速過濾器","PRINT_SELECTED":"列印選定頁面","EXPORT_ALL_CSV":"全部匯出至 CSV","CONFIGURE_SETTINGS":"配置選項","EXPORT":"匯出","DESELECT_ALL":"取消全選","COLUMNS_VISIBLE":"指出要顯示的直欄：","PRINT_ALL":"全部列印","REFRESH":"重新整理","ADVANCED_FILTER":"進階過濾器","PRINT":"列印","COLUMNS":"直欄","PRINT_PREVIEW":"預覽列印","PROCESSING":"處理中...","NO_DATA":"沒有資料可供顯示","SELECT_ALL":"全選","CLEAR_FILTER":"清除過濾器","EXPORT_HTML":"匯出為 HTML","OK":"確定","QF_DEFAULT_TEXT":"過濾器","CANCEL":"取消","EXPORT_ALL_CSV_SAVE":"將內容複製及儲存為 CSV 檔案。","ACTIONS":"動作"})