/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Kijelölés exportálása CSV formátumba","QUICK_FILTER":"Gyorsszűrő","PRINT_SELECTED":"Kijelölés nyomtatása","EXPORT_ALL_CSV":"Összes exportálása CSV formátumba","CONFIGURE_SETTINGS":"Beállítások megadása","EXPORT":"Exportálás","DESELECT_ALL":"Kijelölések megszüntetése","COLUMNS_VISIBLE":"Adja meg, hogy mely oszlopok legyenek láthatók:","PRINT_ALL":"Összes nyomtatása","REFRESH":"Frissítés","ADVANCED_FILTER":"Összetett szűrő","PRINT":"Nyomtatás","COLUMNS":"Oszlopok","PRINT_PREVIEW":"Nyomtatási kép","PROCESSING":"Feldolgozás...","NO_DATA":"Nincsenek megjeleníthető adatok.","SELECT_ALL":"Mindent kijelöl","CLEAR_FILTER":"Szűrő törlése","EXPORT_HTML":"Exportálás HTML formátumba","OK":"OK","QF_DEFAULT_TEXT":"Szűrő","CANCEL":"Mégse","EXPORT_ALL_CSV_SAVE":"Tartalom másolása és mentése CVS fájlként","ACTIONS":"Műveletek"})