/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Geselecteerde items naar CSV exporteren","QUICK_FILTER":"Snelfilter","PRINT_SELECTED":"Geselecteerde afdrukken","EXPORT_ALL_CSV":"Alles naar CSV exporteren","CONFIGURE_SETTINGS":"Opties configureren","EXPORT":"Exporteren","DESELECT_ALL":"Alle selecties opheffen","COLUMNS_VISIBLE":"Geef aan welke kolommen zichtbaar zijn:","PRINT_ALL":"Alles afdrukken","REFRESH":"Vernieuwen","ADVANCED_FILTER":"Geavanceerd filter","PRINT":"Afdrukken","COLUMNS":"Kolommen","PRINT_PREVIEW":"Afdrukvoorbeeld","PROCESSING":"Verwerken...","NO_DATA":"Geen gegevens om af te beelden","SELECT_ALL":"Alles selecteren","CLEAR_FILTER":"Filter wissen","EXPORT_HTML":"Exporteren als HTML","OK":"OK","QF_DEFAULT_TEXT":"Filter","CANCEL":"Annuleren","EXPORT_ALL_CSV_SAVE":"De inhoud kopiëren en opslaan als CSV-bestand","ACTIONS":"Acties"})