/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Seçileni CVS Olarak Dışa Aktar","QUICK_FILTER":"Hızlı Süzgeç","PRINT_SELECTED":"Seçileni Yazdır","EXPORT_ALL_CSV":"Tümünü CVS Olarak Dışa Aktar","CONFIGURE_SETTINGS":"Seçenekleri Yapılandır","EXPORT":"Dışa Aktar","DESELECT_ALL":"Tüm Seçimi Kaldır","COLUMNS_VISIBLE":"Hangi sütunlarının görünür olacağını belirtin:","PRINT_ALL":"Tümünü Yazdır","REFRESH":"Yenile","ADVANCED_FILTER":"Gelişmiş Süzgeç","PRINT":"Yazdır","COLUMNS":"Sütunlar","PRINT_PREVIEW":"Baskı Önizleme","PROCESSING":"İşleniyor...","NO_DATA":"Görüntülenecek veri yok.","SELECT_ALL":"Tümünü Seç","CLEAR_FILTER":"Süzgeci Kaldır","EXPORT_HTML":"HTML Olarak Dışa Aktar","OK":"Tamam","QF_DEFAULT_TEXT":"Süzgeç","CANCEL":"İptal","EXPORT_ALL_CSV_SAVE":"İçeriği CSV Dosyası Olarak Kopyala ve Kaydet","ACTIONS":"İşlemler"})