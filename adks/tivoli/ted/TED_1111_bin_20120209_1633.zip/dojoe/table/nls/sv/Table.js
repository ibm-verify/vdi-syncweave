/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Exportera valda till CSV","QUICK_FILTER":"Snabbfilter","PRINT_SELECTED":"Skriv ut valda","EXPORT_ALL_CSV":"Exportera alla till CSV","CONFIGURE_SETTINGS":"Konfigurera alternativ","EXPORT":"Exportera","DESELECT_ALL":"Avmarkera alla","COLUMNS_VISIBLE":"Ange vilka kolumner som ska vara synliga:","PRINT_ALL":"Skriv ut alla","REFRESH":"Uppdatera","ADVANCED_FILTER":"Avancerat filter","PRINT":"Skriv ut","COLUMNS":"Kolumner","PRINT_PREVIEW":"Förhandsgranskning","PROCESSING":"Bearbetar...","NO_DATA":"Det finns inga data att visa","SELECT_ALL":"Markera alla","CLEAR_FILTER":"Rensa filter","EXPORT_HTML":"Exportera som HTML","OK":"OK","QF_DEFAULT_TEXT":"Filter","CANCEL":"Avbryt","EXPORT_ALL_CSV_SAVE":"Kopiera och spara innehållet som en CSV-fil","ACTIONS":"Åtgärder"})