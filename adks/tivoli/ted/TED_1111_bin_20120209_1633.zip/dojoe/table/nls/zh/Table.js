/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"将选中的导出到 CSV","QUICK_FILTER":"快速过滤器","PRINT_SELECTED":"打印所选项","EXPORT_ALL_CSV":"将全部导出到 CSV","CONFIGURE_SETTINGS":"配置选项","EXPORT":"导出","DESELECT_ALL":"取消所有选择","COLUMNS_VISIBLE":"表明哪些列是可见的：","PRINT_ALL":"全部打印","REFRESH":"刷新","ADVANCED_FILTER":"高级过滤器","PRINT":"打印","COLUMNS":"列","PRINT_PREVIEW":"打印预览","PROCESSING":"正在处理...","NO_DATA":"没有要显示的数据","SELECT_ALL":"选择全部","CLEAR_FILTER":"清除过滤器","EXPORT_HTML":"导出为 HTML","OK":"确定","QF_DEFAULT_TEXT":"过滤器","CANCEL":"取消","EXPORT_ALL_CSV_SAVE":"复制内容并将其另存为 CSV 文件","ACTIONS":"操作"})