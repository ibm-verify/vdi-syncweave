/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"تصدير ما هو محدد الى CSV","QUICK_FILTER":"ترشيح بيانات سريع","PRINT_SELECTED":"طباعة ما هو محدد","EXPORT_ALL_CSV":"تصدير كل الى CSV","CONFIGURE_SETTINGS":"توصيف الاختيارات","EXPORT":"تصدير","DESELECT_ALL":"الغاء تحديد كل","COLUMNS_VISIBLE":"الاشارة الى الأعمدة المرئية:","PRINT_ALL":"طباعة كل","REFRESH":"تجديد","ADVANCED_FILTER":"ترشيح بيانات متقدم","PRINT":"طباعة","COLUMNS":"أعمدة","PRINT_PREVIEW":"معاينة الطباعة","PROCESSING":"تشغيل...","NO_DATA":"لا توجد بيانات ليتم عرضها","SELECT_ALL":"تحديد كل","CLEAR_FILTER":"محو ترشيح البيانات","EXPORT_HTML":"تصدير كملف HTML","OK":"حسنا","QF_DEFAULT_TEXT":"ترشيح البيانات","CANCEL":"الغاء","EXPORT_ALL_CSV_SAVE":"نسخ وحفظ المحتويات كملف CSV  ","ACTIONS":"التصرفات"})