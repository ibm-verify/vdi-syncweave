/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Exportovat vybrané do souboru CSV","QUICK_FILTER":"Rychlý filtr","PRINT_SELECTED":"Tisknout vybrané","EXPORT_ALL_CSV":"Exportovat vše do souboru CSV","CONFIGURE_SETTINGS":"Konfigurovat volby","EXPORT":"Exportovat","DESELECT_ALL":"Zrušit veškerý výběr","COLUMNS_VISIBLE":"Označte, které sloupce jsou viditelné:","PRINT_ALL":"Tisknout vše","REFRESH":"Obnovit","ADVANCED_FILTER":"Rozšířený filtr","PRINT":"Tisk","COLUMNS":"Sloupce","PRINT_PREVIEW":"Náhled tisku","PROCESSING":"Probíhá zpracování...","NO_DATA":"Nejsou žádná data k zobrazení.","SELECT_ALL":"Vybrat vše","CLEAR_FILTER":"Vymazat filtr","EXPORT_HTML":"Exportovat jako soubor HTML","OK":"OK","QF_DEFAULT_TEXT":"Filtr","CANCEL":"Storno","EXPORT_ALL_CSV_SAVE":"Kopírovat a uložit obsah jako soubor CSV","ACTIONS":"Akce"})