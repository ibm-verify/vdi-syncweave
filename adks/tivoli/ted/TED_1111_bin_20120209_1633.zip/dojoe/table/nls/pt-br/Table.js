/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"Exportar Selecionado para CSV","QUICK_FILTER":"Filtro Rápido","PRINT_SELECTED":"Imprimir Selecionado","EXPORT_ALL_CSV":"Exportar Todos para o CSV","CONFIGURE_SETTINGS":"Configurar Opções","EXPORT":"Exportar","DESELECT_ALL":"Desmarcar Tudo","COLUMNS_VISIBLE":"Indicar quais colunas são visíveis:","PRINT_ALL":"Imprimir Todos","REFRESH":"Atualizar","ADVANCED_FILTER":"Filtro Avançado","PRINT":"Imprimir","COLUMNS":"Colunas","PRINT_PREVIEW":"Visualização de Impressão","PROCESSING":"Processando...","NO_DATA":"Nenhum dado para exibir","SELECT_ALL":"Selecionar Tudo","CLEAR_FILTER":"Limpar Filtro","EXPORT_HTML":"Exportar como HTML","OK":"OK","QF_DEFAULT_TEXT":"Filtrar","CANCEL":"Cancelar","EXPORT_ALL_CSV_SAVE":"Copiar e Salvar o conteúdo como um arquivo CSV","ACTIONS":"Ações"})