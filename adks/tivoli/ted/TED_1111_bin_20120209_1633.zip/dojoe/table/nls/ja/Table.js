/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"EXPORT_SELECTED_CSV":"選択内容を CSV にエクスポート","QUICK_FILTER":"クイック・フィルター","PRINT_SELECTED":"選択内容を印刷","EXPORT_ALL_CSV":"すべてを CSV にエクスポート","CONFIGURE_SETTINGS":"オプションの構成","EXPORT":"エクスポート","DESELECT_ALL":"選択をすべて解除","COLUMNS_VISIBLE":"表示される列を指定します:","PRINT_ALL":"すべてを印刷","REFRESH":"リフレッシュ","ADVANCED_FILTER":"拡張フィルター","PRINT":"印刷","COLUMNS":"列","PRINT_PREVIEW":"印刷プレビュー","PROCESSING":"処理中...","NO_DATA":"表示するデータがありません","SELECT_ALL":"すべて選択","CLEAR_FILTER":"フィルターのクリア","EXPORT_HTML":"HTML としてエクスポート","OK":"OK","QF_DEFAULT_TEXT":"フィルター","CANCEL":"キャンセル","EXPORT_ALL_CSV_SAVE":"内容をコピーして CSV ファイルとして保存","ACTIONS":"アクション"})