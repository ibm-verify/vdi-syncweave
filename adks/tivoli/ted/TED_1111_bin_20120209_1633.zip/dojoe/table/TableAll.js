/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*
	This is an optimized version of Dojo, built for deployment and not for
	development. To get sources and documentation, please visit:

		http://dojotoolkit.org
*/

if(!dojo._hasResource["dojo.window"]){
dojo._hasResource["dojo.window"]=true;
dojo.provide("dojo.window");
dojo.getObject("window",true,dojo);
dojo.window.getBox=function(){
var _1=(dojo.doc.compatMode=="BackCompat")?dojo.body():dojo.doc.documentElement;
var _2=dojo._docScroll();
return {w:_1.clientWidth,h:_1.clientHeight,l:_2.x,t:_2.y};
};
dojo.window.get=function(_3){
if(dojo.isIE&&window!==document.parentWindow){
_3.parentWindow.execScript("document._parentWindow = window;","Javascript");
var _4=_3._parentWindow;
_3._parentWindow=null;
return _4;
}
return _3.parentWindow||_3.defaultView;
};
dojo.window.scrollIntoView=function(_5,_6){
try{
_5=dojo.byId(_5);
var _7=_5.ownerDocument||dojo.doc,_8=_7.body||dojo.body(),_9=_7.documentElement||_8.parentNode,_a=dojo.isIE,_b=dojo.isWebKit;
if((!(dojo.isMoz||_a||_b||dojo.isOpera)||_5==_8||_5==_9)&&(typeof _5.scrollIntoView!="undefined")){
_5.scrollIntoView(false);
return;
}
var _c=_7.compatMode=="BackCompat",_d=(_a>=9&&_5.ownerDocument.parentWindow.frameElement)?((_9.clientHeight>0&&_9.clientWidth>0&&(_8.clientHeight==0||_8.clientWidth==0||_8.clientHeight>_9.clientHeight||_8.clientWidth>_9.clientWidth))?_9:_8):(_c?_8:_9),_e=_b?_8:_d,_f=_d.clientWidth,_10=_d.clientHeight,rtl=!dojo._isBodyLtr(),_11=_6||dojo.position(_5),el=_5.parentNode,_12=function(el){
return ((_a<=6||(_a&&_c))?false:(dojo.style(el,"position").toLowerCase()=="fixed"));
};
if(_12(_5)){
return;
}
while(el){
if(el==_8){
el=_e;
}
var _13=dojo.position(el),_14=_12(el);
if(el==_e){
_13.w=_f;
_13.h=_10;
if(_e==_9&&_a&&rtl){
_13.x+=_e.offsetWidth-_13.w;
}
if(_13.x<0||!_a){
_13.x=0;
}
if(_13.y<0||!_a){
_13.y=0;
}
}else{
var pb=dojo._getPadBorderExtents(el);
_13.w-=pb.w;
_13.h-=pb.h;
_13.x+=pb.l;
_13.y+=pb.t;
var _15=el.clientWidth,_16=_13.w-_15;
if(_15>0&&_16>0){
_13.w=_15;
_13.x+=(rtl&&(_a||el.clientLeft>pb.l))?_16:0;
}
_15=el.clientHeight;
_16=_13.h-_15;
if(_15>0&&_16>0){
_13.h=_15;
}
}
if(_14){
if(_13.y<0){
_13.h+=_13.y;
_13.y=0;
}
if(_13.x<0){
_13.w+=_13.x;
_13.x=0;
}
if(_13.y+_13.h>_10){
_13.h=_10-_13.y;
}
if(_13.x+_13.w>_f){
_13.w=_f-_13.x;
}
}
var l=_11.x-_13.x,t=_11.y-Math.max(_13.y,0),r=l+_11.w-_13.w,bot=t+_11.h-_13.h;
if(r*l>0){
var s=Math[l<0?"max":"min"](l,r);
if(rtl&&((_a==8&&!_c)||_a>=9)){
s=-s;
}
_11.x+=el.scrollLeft;
el.scrollLeft+=s;
_11.x-=el.scrollLeft;
}
if(bot*t>0){
_11.y+=el.scrollTop;
el.scrollTop+=Math[t<0?"max":"min"](t,bot);
_11.y-=el.scrollTop;
}
el=(el!=_e)&&!_14&&el.parentNode;
}
}
catch(error){
console.error("scrollIntoView: "+error);
_5.scrollIntoView(false);
}
};
}
if(!dojo._hasResource["dijit._base.manager"]){
dojo._hasResource["dijit._base.manager"]=true;
dojo.provide("dijit._base.manager");
dojo.declare("dijit.WidgetSet",null,{constructor:function(){
this._hash={};
this.length=0;
},add:function(_17){
if(this._hash[_17.id]){
throw new Error("Tried to register widget with id=="+_17.id+" but that id is already registered");
}
this._hash[_17.id]=_17;
this.length++;
},remove:function(id){
if(this._hash[id]){
delete this._hash[id];
this.length--;
}
},forEach:function(_18,_19){
_19=_19||dojo.global;
var i=0,id;
for(id in this._hash){
_18.call(_19,this._hash[id],i++,this._hash);
}
return this;
},filter:function(_1a,_1b){
_1b=_1b||dojo.global;
var res=new dijit.WidgetSet(),i=0,id;
for(id in this._hash){
var w=this._hash[id];
if(_1a.call(_1b,w,i++,this._hash)){
res.add(w);
}
}
return res;
},byId:function(id){
return this._hash[id];
},byClass:function(cls){
var res=new dijit.WidgetSet(),id,_1c;
for(id in this._hash){
_1c=this._hash[id];
if(_1c.declaredClass==cls){
res.add(_1c);
}
}
return res;
},toArray:function(){
var ar=[];
for(var id in this._hash){
ar.push(this._hash[id]);
}
return ar;
},map:function(_1d,_1e){
return dojo.map(this.toArray(),_1d,_1e);
},every:function(_1f,_20){
_20=_20||dojo.global;
var x=0,i;
for(i in this._hash){
if(!_1f.call(_20,this._hash[i],x++,this._hash)){
return false;
}
}
return true;
},some:function(_21,_22){
_22=_22||dojo.global;
var x=0,i;
for(i in this._hash){
if(_21.call(_22,this._hash[i],x++,this._hash)){
return true;
}
}
return false;
}});
(function(){
dijit.registry=new dijit.WidgetSet();
var _23=dijit.registry._hash,_24=dojo.attr,_25=dojo.hasAttr,_26=dojo.style;
dijit.byId=function(id){
return typeof id=="string"?_23[id]:id;
};
var _27={};
dijit.getUniqueId=function(_28){
var id;
do{
id=_28+"_"+(_28 in _27?++_27[_28]:_27[_28]=0);
}while(_23[id]);
return dijit._scopeName=="dijit"?id:dijit._scopeName+"_"+id;
};
dijit.findWidgets=function(_29){
var _2a=[];
function _2b(_2c){
for(var _2d=_2c.firstChild;_2d;_2d=_2d.nextSibling){
if(_2d.nodeType==1){
var _2e=_2d.getAttribute("widgetId");
if(_2e){
var _2f=_23[_2e];
if(_2f){
_2a.push(_2f);
}
}else{
_2b(_2d);
}
}
}
};
_2b(_29);
return _2a;
};
dijit._destroyAll=function(){
dijit._curFocus=null;
dijit._prevFocus=null;
dijit._activeStack=[];
dojo.forEach(dijit.findWidgets(dojo.body()),function(_30){
if(!_30._destroyed){
if(_30.destroyRecursive){
_30.destroyRecursive();
}else{
if(_30.destroy){
_30.destroy();
}
}
}
});
};
if(dojo.isIE){
dojo.addOnWindowUnload(function(){
dijit._destroyAll();
});
}
dijit.byNode=function(_31){
return _23[_31.getAttribute("widgetId")];
};
dijit.getEnclosingWidget=function(_32){
while(_32){
var id=_32.getAttribute&&_32.getAttribute("widgetId");
if(id){
return _23[id];
}
_32=_32.parentNode;
}
return null;
};
var _33=(dijit._isElementShown=function(_34){
var s=_26(_34);
return (s.visibility!="hidden")&&(s.visibility!="collapsed")&&(s.display!="none")&&(_24(_34,"type")!="hidden");
});
dijit.hasDefaultTabStop=function(_35){
switch(_35.nodeName.toLowerCase()){
case "a":
return _25(_35,"href");
case "area":
case "button":
case "input":
case "object":
case "select":
case "textarea":
return true;
case "iframe":
var _36;
try{
var _37=_35.contentDocument;
if("designMode" in _37&&_37.designMode=="on"){
return true;
}
_36=_37.body;
}
catch(e1){
try{
_36=_35.contentWindow.document.body;
}
catch(e2){
return false;
}
}
return _36.contentEditable=="true"||(_36.firstChild&&_36.firstChild.contentEditable=="true");
default:
return _35.contentEditable=="true";
}
};
var _38=(dijit.isTabNavigable=function(_39){
if(_24(_39,"disabled")){
return false;
}else{
if(_25(_39,"tabIndex")){
return _24(_39,"tabIndex")>=0;
}else{
return dijit.hasDefaultTabStop(_39);
}
}
});
dijit._getTabNavigable=function(_3a){
var _3b,_3c,_3d,_3e,_3f,_40,_41={};
function _42(_43){
return _43&&_43.tagName.toLowerCase()=="input"&&_43.type&&_43.type.toLowerCase()=="radio"&&_43.name&&_43.name.toLowerCase();
};
var _44=function(_45){
dojo.query("> *",_45).forEach(function(_46){
if((dojo.isIE&&_46.scopeName!=="HTML")||!_33(_46)){
return;
}
if(_38(_46)){
var _47=_24(_46,"tabIndex");
if(!_25(_46,"tabIndex")||_47==0){
if(!_3b){
_3b=_46;
}
_3c=_46;
}else{
if(_47>0){
if(!_3d||_47<_3e){
_3e=_47;
_3d=_46;
}
if(!_3f||_47>=_40){
_40=_47;
_3f=_46;
}
}
}
var rn=_42(_46);
if(dojo.attr(_46,"checked")&&rn){
_41[rn]=_46;
}
}
if(_46.nodeName.toUpperCase()!="SELECT"){
_44(_46);
}
});
};
if(_33(_3a)){
_44(_3a);
}
function rs(_48){
return _41[_42(_48)]||_48;
};
return {first:rs(_3b),last:rs(_3c),lowest:rs(_3d),highest:rs(_3f)};
};
dijit.getFirstInTabbingOrder=function(_49){
var _4a=dijit._getTabNavigable(dojo.byId(_49));
return _4a.lowest?_4a.lowest:_4a.first;
};
dijit.getLastInTabbingOrder=function(_4b){
var _4c=dijit._getTabNavigable(dojo.byId(_4b));
return _4c.last?_4c.last:_4c.highest;
};
dijit.defaultDuration=dojo.config["defaultDuration"]||200;
})();
}
if(!dojo._hasResource["dijit._base.focus"]){
dojo._hasResource["dijit._base.focus"]=true;
dojo.provide("dijit._base.focus");
dojo.mixin(dijit,{_curFocus:null,_prevFocus:null,isCollapsed:function(){
return dijit.getBookmark().isCollapsed;
},getBookmark:function(){
var bm,rg,tg,sel=dojo.doc.selection,cf=dijit._curFocus;
if(dojo.global.getSelection){
sel=dojo.global.getSelection();
if(sel){
if(sel.isCollapsed){
tg=cf?cf.tagName:"";
if(tg){
tg=tg.toLowerCase();
if(tg=="textarea"||(tg=="input"&&(!cf.type||cf.type.toLowerCase()=="text"))){
sel={start:cf.selectionStart,end:cf.selectionEnd,node:cf,pRange:true};
return {isCollapsed:(sel.end<=sel.start),mark:sel};
}
}
bm={isCollapsed:true};
if(sel.rangeCount){
bm.mark=sel.getRangeAt(0).cloneRange();
}
}else{
rg=sel.getRangeAt(0);
bm={isCollapsed:false,mark:rg.cloneRange()};
}
}
}else{
if(sel){
tg=cf?cf.tagName:"";
tg=tg.toLowerCase();
if(cf&&tg&&(tg=="button"||tg=="textarea"||tg=="input")){
if(sel.type&&sel.type.toLowerCase()=="none"){
return {isCollapsed:true,mark:null};
}else{
rg=sel.createRange();
return {isCollapsed:rg.text&&rg.text.length?false:true,mark:{range:rg,pRange:true}};
}
}
bm={};
try{
rg=sel.createRange();
bm.isCollapsed=!(sel.type=="Text"?rg.htmlText.length:rg.length);
}
catch(e){
bm.isCollapsed=true;
return bm;
}
if(sel.type.toUpperCase()=="CONTROL"){
if(rg.length){
bm.mark=[];
var i=0,len=rg.length;
while(i<len){
bm.mark.push(rg.item(i++));
}
}else{
bm.isCollapsed=true;
bm.mark=null;
}
}else{
bm.mark=rg.getBookmark();
}
}else{
console.warn("No idea how to store the current selection for this browser!");
}
}
return bm;
},moveToBookmark:function(_4d){
var _4e=dojo.doc,_4f=_4d.mark;
if(_4f){
if(dojo.global.getSelection){
var sel=dojo.global.getSelection();
if(sel&&sel.removeAllRanges){
if(_4f.pRange){
var r=_4f;
var n=r.node;
n.selectionStart=r.start;
n.selectionEnd=r.end;
}else{
sel.removeAllRanges();
sel.addRange(_4f);
}
}else{
console.warn("No idea how to restore selection for this browser!");
}
}else{
if(_4e.selection&&_4f){
var rg;
if(_4f.pRange){
rg=_4f.range;
}else{
if(dojo.isArray(_4f)){
rg=_4e.body.createControlRange();
dojo.forEach(_4f,function(n){
rg.addElement(n);
});
}else{
rg=_4e.body.createTextRange();
rg.moveToBookmark(_4f);
}
}
rg.select();
}
}
}
},getFocus:function(_50,_51){
var _52=!dijit._curFocus||(_50&&dojo.isDescendant(dijit._curFocus,_50.domNode))?dijit._prevFocus:dijit._curFocus;
return {node:_52,bookmark:(_52==dijit._curFocus)&&dojo.withGlobal(_51||dojo.global,dijit.getBookmark),openedForWindow:_51};
},focus:function(_53){
if(!_53){
return;
}
var _54="node" in _53?_53.node:_53,_55=_53.bookmark,_56=_53.openedForWindow,_57=_55?_55.isCollapsed:false;
if(_54){
var _58=(_54.tagName.toLowerCase()=="iframe")?_54.contentWindow:_54;
if(_58&&_58.focus){
try{
_58.focus();
}
catch(e){
}
}
dijit._onFocusNode(_54);
}
if(_55&&dojo.withGlobal(_56||dojo.global,dijit.isCollapsed)&&!_57){
if(_56){
_56.focus();
}
try{
dojo.withGlobal(_56||dojo.global,dijit.moveToBookmark,null,[_55]);
}
catch(e2){
}
}
},_activeStack:[],registerIframe:function(_59){
return dijit.registerWin(_59.contentWindow,_59);
},unregisterIframe:function(_5a){
dijit.unregisterWin(_5a);
},registerWin:function(_5b,_5c){
var _5d=function(evt){
dijit._justMouseDowned=true;
setTimeout(function(){
dijit._justMouseDowned=false;
},0);
if(dojo.isIE&&evt&&evt.srcElement&&evt.srcElement.parentNode==null){
return;
}
dijit._onTouchNode(_5c||evt.target||evt.srcElement,"mouse");
};
var doc=dojo.isIE?_5b.document.documentElement:_5b.document;
if(doc){
if(dojo.isIE){
_5b.document.body.attachEvent("onmousedown",_5d);
var _5e=function(evt){
if(evt.srcElement.tagName.toLowerCase()!="#document"&&dijit.isTabNavigable(evt.srcElement)){
dijit._onFocusNode(_5c||evt.srcElement);
}else{
dijit._onTouchNode(_5c||evt.srcElement);
}
};
doc.attachEvent("onactivate",_5e);
var _5f=function(evt){
dijit._onBlurNode(_5c||evt.srcElement);
};
doc.attachEvent("ondeactivate",_5f);
return function(){
_5b.document.detachEvent("onmousedown",_5d);
doc.detachEvent("onactivate",_5e);
doc.detachEvent("ondeactivate",_5f);
doc=null;
};
}else{
doc.body.addEventListener("mousedown",_5d,true);
var _60=function(evt){
dijit._onFocusNode(_5c||evt.target);
};
doc.addEventListener("focus",_60,true);
var _61=function(evt){
dijit._onBlurNode(_5c||evt.target);
};
doc.addEventListener("blur",_61,true);
return function(){
doc.body.removeEventListener("mousedown",_5d,true);
doc.removeEventListener("focus",_60,true);
doc.removeEventListener("blur",_61,true);
doc=null;
};
}
}
},unregisterWin:function(_62){
_62&&_62();
},_onBlurNode:function(_63){
dijit._prevFocus=dijit._curFocus;
dijit._curFocus=null;
if(dijit._justMouseDowned){
return;
}
if(dijit._clearActiveWidgetsTimer){
clearTimeout(dijit._clearActiveWidgetsTimer);
}
dijit._clearActiveWidgetsTimer=setTimeout(function(){
delete dijit._clearActiveWidgetsTimer;
dijit._setStack([]);
dijit._prevFocus=null;
},100);
},_onTouchNode:function(_64,by){
if(dijit._clearActiveWidgetsTimer){
clearTimeout(dijit._clearActiveWidgetsTimer);
delete dijit._clearActiveWidgetsTimer;
}
var _65=[];
try{
while(_64){
var _66=dojo.attr(_64,"dijitPopupParent");
if(_66){
_64=dijit.byId(_66).domNode;
}else{
if(_64.tagName&&_64.tagName.toLowerCase()=="body"){
if(_64===dojo.body()){
break;
}
_64=dojo.window.get(_64.ownerDocument).frameElement;
}else{
var id=_64.getAttribute&&_64.getAttribute("widgetId"),_67=id&&dijit.byId(id);
if(_67&&!(by=="mouse"&&_67.get("disabled"))){
_65.unshift(id);
}
_64=_64.parentNode;
}
}
}
}
catch(e){
}
dijit._setStack(_65,by);
},_onFocusNode:function(_68){
if(!_68){
return;
}
if(_68.nodeType==9){
return;
}
dijit._onTouchNode(_68);
if(_68==dijit._curFocus){
return;
}
if(dijit._curFocus){
dijit._prevFocus=dijit._curFocus;
}
dijit._curFocus=_68;
dojo.publish("focusNode",[_68]);
},_setStack:function(_69,by){
var _6a=dijit._activeStack;
dijit._activeStack=_69;
for(var _6b=0;_6b<Math.min(_6a.length,_69.length);_6b++){
if(_6a[_6b]!=_69[_6b]){
break;
}
}
var _6c;
for(var i=_6a.length-1;i>=_6b;i--){
_6c=dijit.byId(_6a[i]);
if(_6c){
_6c._focused=false;
_6c.set("focused",false);
_6c._hasBeenBlurred=true;
if(_6c._onBlur){
_6c._onBlur(by);
}
dojo.publish("widgetBlur",[_6c,by]);
}
}
for(i=_6b;i<_69.length;i++){
_6c=dijit.byId(_69[i]);
if(_6c){
_6c._focused=true;
_6c.set("focused",true);
if(_6c._onFocus){
_6c._onFocus(by);
}
dojo.publish("widgetFocus",[_6c,by]);
}
}
}});
dojo.addOnLoad(function(){
var _6d=dijit.registerWin(window);
if(dojo.isIE){
dojo.addOnWindowUnload(function(){
dijit.unregisterWin(_6d);
_6d=null;
});
}
});
}
if(!dojo._hasResource["dojo.AdapterRegistry"]){
dojo._hasResource["dojo.AdapterRegistry"]=true;
dojo.provide("dojo.AdapterRegistry");
dojo.AdapterRegistry=function(_6e){
this.pairs=[];
this.returnWrappers=_6e||false;
};
dojo.extend(dojo.AdapterRegistry,{register:function(_6f,_70,_71,_72,_73){
this.pairs[((_73)?"unshift":"push")]([_6f,_70,_71,_72]);
},match:function(){
for(var i=0;i<this.pairs.length;i++){
var _74=this.pairs[i];
if(_74[1].apply(this,arguments)){
if((_74[3])||(this.returnWrappers)){
return _74[2];
}else{
return _74[2].apply(this,arguments);
}
}
}
throw new Error("No match found");
},unregister:function(_75){
for(var i=0;i<this.pairs.length;i++){
var _76=this.pairs[i];
if(_76[0]==_75){
this.pairs.splice(i,1);
return true;
}
}
return false;
}});
}
if(!dojo._hasResource["dijit._base.place"]){
dojo._hasResource["dijit._base.place"]=true;
dojo.provide("dijit._base.place");
dijit.getViewport=function(){
return dojo.window.getBox();
};
dijit.placeOnScreen=function(_77,pos,_78,_79){
var _7a=dojo.map(_78,function(_7b){
var c={corner:_7b,pos:{x:pos.x,y:pos.y}};
if(_79){
c.pos.x+=_7b.charAt(1)=="L"?_79.x:-_79.x;
c.pos.y+=_7b.charAt(0)=="T"?_79.y:-_79.y;
}
return c;
});
return dijit._place(_77,_7a);
};
dijit._place=function(_7c,_7d,_7e,_7f){
var _80=dojo.window.getBox();
if(!_7c.parentNode||String(_7c.parentNode.tagName).toLowerCase()!="body"){
dojo.body().appendChild(_7c);
}
var _81=null;
dojo.some(_7d,function(_82){
var _83=_82.corner;
var pos=_82.pos;
var _84=0;
var _85={w:_83.charAt(1)=="L"?(_80.l+_80.w)-pos.x:pos.x-_80.l,h:_83.charAt(1)=="T"?(_80.t+_80.h)-pos.y:pos.y-_80.t};
if(_7e){
var res=_7e(_7c,_82.aroundCorner,_83,_85,_7f);
_84=typeof res=="undefined"?0:res;
}
var _86=_7c.style;
var _87=_86.display;
var _88=_86.visibility;
_86.visibility="hidden";
_86.display="";
var mb=dojo.marginBox(_7c);
_86.display=_87;
_86.visibility=_88;
var _89=Math.max(_80.l,_83.charAt(1)=="L"?pos.x:(pos.x-mb.w)),_8a=Math.max(_80.t,_83.charAt(0)=="T"?pos.y:(pos.y-mb.h)),_8b=Math.min(_80.l+_80.w,_83.charAt(1)=="L"?(_89+mb.w):pos.x),_8c=Math.min(_80.t+_80.h,_83.charAt(0)=="T"?(_8a+mb.h):pos.y),_8d=_8b-_89,_8e=_8c-_8a;
_84+=(mb.w-_8d)+(mb.h-_8e);
if(_81==null||_84<_81.overflow){
_81={corner:_83,aroundCorner:_82.aroundCorner,x:_89,y:_8a,w:_8d,h:_8e,overflow:_84,spaceAvailable:_85};
}
return !_84;
});
if(_81.overflow&&_7e){
_7e(_7c,_81.aroundCorner,_81.corner,_81.spaceAvailable,_7f);
}
var l=dojo._isBodyLtr(),s=_7c.style;
s.top=_81.y+"px";
s[l?"left":"right"]=(l?_81.x:_80.w-_81.x-_81.w)+"px";
return _81;
};
dijit.placeOnScreenAroundNode=function(_8f,_90,_91,_92){
_90=dojo.byId(_90);
var _93=dojo.position(_90,true);
return dijit._placeOnScreenAroundRect(_8f,_93.x,_93.y,_93.w,_93.h,_91,_92);
};
dijit.placeOnScreenAroundRectangle=function(_94,_95,_96,_97){
return dijit._placeOnScreenAroundRect(_94,_95.x,_95.y,_95.width,_95.height,_96,_97);
};
dijit._placeOnScreenAroundRect=function(_98,x,y,_99,_9a,_9b,_9c){
var _9d=[];
for(var _9e in _9b){
_9d.push({aroundCorner:_9e,corner:_9b[_9e],pos:{x:x+(_9e.charAt(1)=="L"?0:_99),y:y+(_9e.charAt(0)=="T"?0:_9a)}});
}
return dijit._place(_98,_9d,_9c,{w:_99,h:_9a});
};
dijit.placementRegistry=new dojo.AdapterRegistry();
dijit.placementRegistry.register("node",function(n,x){
return typeof x=="object"&&typeof x.offsetWidth!="undefined"&&typeof x.offsetHeight!="undefined";
},dijit.placeOnScreenAroundNode);
dijit.placementRegistry.register("rect",function(n,x){
return typeof x=="object"&&"x" in x&&"y" in x&&"width" in x&&"height" in x;
},dijit.placeOnScreenAroundRectangle);
dijit.placeOnScreenAroundElement=function(_9f,_a0,_a1,_a2){
return dijit.placementRegistry.match.apply(dijit.placementRegistry,arguments);
};
dijit.getPopupAroundAlignment=function(_a3,_a4){
var _a5={};
dojo.forEach(_a3,function(pos){
switch(pos){
case "after":
_a5[_a4?"BR":"BL"]=_a4?"BL":"BR";
break;
case "before":
_a5[_a4?"BL":"BR"]=_a4?"BR":"BL";
break;
case "below-alt":
_a4=!_a4;
case "below":
_a5[_a4?"BL":"BR"]=_a4?"TL":"TR";
_a5[_a4?"BR":"BL"]=_a4?"TR":"TL";
break;
case "above-alt":
_a4=!_a4;
case "above":
default:
_a5[_a4?"TL":"TR"]=_a4?"BL":"BR";
_a5[_a4?"TR":"TL"]=_a4?"BR":"BL";
break;
}
});
return _a5;
};
}
if(!dojo._hasResource["dijit._base.window"]){
dojo._hasResource["dijit._base.window"]=true;
dojo.provide("dijit._base.window");
dijit.getDocumentWindow=function(doc){
return dojo.window.get(doc);
};
}
if(!dojo._hasResource["dijit._base.popup"]){
dojo._hasResource["dijit._base.popup"]=true;
dojo.provide("dijit._base.popup");
dijit.popup={_stack:[],_beginZIndex:1000,_idGen:1,_createWrapper:function(_a6){
var _a7=_a6.domNode||_a6,_a8=_a6.declaredClass?_a6._popupWrapper:_a7.parentNode&&dojo.hasClass(_a7.parentNode,"dijitPopup")?_a7.parentNode:null;
if(!_a8){
_a8=dojo.create("div",{"class":"dijitPopup",style:{display:"none"},role:"presentation"},dojo.body());
_a8.appendChild(_a7);
var s=_a7.style;
s.display="";
s.visibility="";
s.position="";
s.top="0px";
if(_a6.declaredClass){
_a6._popupWrapper=_a8;
dojo.connect(_a6,"destroy",function(){
dojo.destroy(_a8);
delete _a6._popupWrapper;
});
}
}
return _a8;
},moveOffScreen:function(_a9){
var _aa=this._createWrapper(_a9);
dojo.style(_aa,{visibility:"hidden",top:"-9999px",display:""});
},hide:function(_ab){
var _ac=this._createWrapper(_ab);
dojo.style(_ac,"display","none");
},getTopPopup:function(){
var _ad=this._stack;
for(var pi=_ad.length-1;pi>0&&_ad[pi].parent===_ad[pi-1].widget;pi--){
}
return _ad[pi];
},open:function(_ae){
var _af=this._stack,_b0=_ae.popup,_b1=_ae.orient||((_ae.parent?_ae.parent.isLeftToRight():dojo._isBodyLtr())?{"BL":"TL","BR":"TR","TL":"BL","TR":"BR"}:{"BR":"TR","BL":"TL","TR":"BR","TL":"BL"}),_b2=_ae.around,id=(_ae.around&&_ae.around.id)?(_ae.around.id+"_dropdown"):("popup_"+this._idGen++);
while(_af.length&&(!_ae.parent||!dojo.isDescendant(_ae.parent.domNode,_af[_af.length-1].widget.domNode))){
dijit.popup.close(_af[_af.length-1].widget);
}
var _b3=this._createWrapper(_b0);
dojo.attr(_b3,{id:id,style:{zIndex:this._beginZIndex+_af.length},"class":"dijitPopup "+(_b0.baseClass||_b0["class"]||"").split(" ")[0]+"Popup",dijitPopupParent:_ae.parent?_ae.parent.id:""});
if(dojo.isIE||dojo.isMoz){
if(!_b0.bgIframe){
_b0.bgIframe=new dijit.BackgroundIframe(_b3);
}
}
var _b4=_b2?dijit.placeOnScreenAroundElement(_b3,_b2,_b1,_b0.orient?dojo.hitch(_b0,"orient"):null):dijit.placeOnScreen(_b3,_ae,_b1=="R"?["TR","BR","TL","BL"]:["TL","BL","TR","BR"],_ae.padding);
_b3.style.display="";
_b3.style.visibility="visible";
_b0.domNode.style.visibility="visible";
var _b5=[];
_b5.push(dojo.connect(_b3,"onkeypress",this,function(evt){
if(evt.charOrCode==dojo.keys.ESCAPE&&_ae.onCancel){
dojo.stopEvent(evt);
_ae.onCancel();
}else{
if(evt.charOrCode===dojo.keys.TAB){
dojo.stopEvent(evt);
var _b6=this.getTopPopup();
if(_b6&&_b6.onCancel){
_b6.onCancel();
}
}
}
}));
if(_b0.onCancel){
_b5.push(dojo.connect(_b0,"onCancel",_ae.onCancel));
}
_b5.push(dojo.connect(_b0,_b0.onExecute?"onExecute":"onChange",this,function(){
var _b7=this.getTopPopup();
if(_b7&&_b7.onExecute){
_b7.onExecute();
}
}));
_af.push({widget:_b0,parent:_ae.parent,onExecute:_ae.onExecute,onCancel:_ae.onCancel,onClose:_ae.onClose,handlers:_b5});
if(_b0.onOpen){
_b0.onOpen(_b4);
}
return _b4;
},close:function(_b8){
var _b9=this._stack;
while((_b8&&dojo.some(_b9,function(_ba){
return _ba.widget==_b8;
}))||(!_b8&&_b9.length)){
var top=_b9.pop(),_bb=top.widget,_bc=top.onClose;
if(_bb.onClose){
_bb.onClose();
}
dojo.forEach(top.handlers,dojo.disconnect);
if(_bb&&_bb.domNode){
this.hide(_bb);
}
if(_bc){
_bc();
}
}
}};
dijit._frames=new function(){
var _bd=[];
this.pop=function(){
var _be;
if(_bd.length){
_be=_bd.pop();
_be.style.display="";
}else{
if(dojo.isIE<9){
var _bf=dojo.config["dojoBlankHtmlUrl"]||(dojo.moduleUrl("dojo","resources/blank.html")+"")||"javascript:\"\"";
var _c0="<iframe src='"+_bf+"'"+" style='position: absolute; left: 0px; top: 0px;"+"z-index: -1; filter:Alpha(Opacity=\"0\");'>";
_be=dojo.doc.createElement(_c0);
}else{
_be=dojo.create("iframe");
_be.src="javascript:\"\"";
_be.className="dijitBackgroundIframe";
dojo.style(_be,"opacity",0.1);
}
_be.tabIndex=-1;
dijit.setWaiRole(_be,"presentation");
}
return _be;
};
this.push=function(_c1){
_c1.style.display="none";
_bd.push(_c1);
};
}();
dijit.BackgroundIframe=function(_c2){
if(!_c2.id){
throw new Error("no id");
}
if(dojo.isIE||dojo.isMoz){
var _c3=(this.iframe=dijit._frames.pop());
_c2.appendChild(_c3);
if(dojo.isIE<7||dojo.isQuirks){
this.resize(_c2);
this._conn=dojo.connect(_c2,"onresize",this,function(){
this.resize(_c2);
});
}else{
dojo.style(_c3,{width:"100%",height:"100%"});
}
}
};
dojo.extend(dijit.BackgroundIframe,{resize:function(_c4){
if(this.iframe){
dojo.style(this.iframe,{width:_c4.offsetWidth+"px",height:_c4.offsetHeight+"px"});
}
},destroy:function(){
if(this._conn){
dojo.disconnect(this._conn);
this._conn=null;
}
if(this.iframe){
dijit._frames.push(this.iframe);
delete this.iframe;
}
}});
}
if(!dojo._hasResource["dijit._base.scroll"]){
dojo._hasResource["dijit._base.scroll"]=true;
dojo.provide("dijit._base.scroll");
dijit.scrollIntoView=function(_c5,pos){
dojo.window.scrollIntoView(_c5,pos);
};
}
if(!dojo._hasResource["dojo.uacss"]){
dojo._hasResource["dojo.uacss"]=true;
dojo.provide("dojo.uacss");
(function(){
var d=dojo,_c6=d.doc.documentElement,ie=d.isIE,_c7=d.isOpera,maj=Math.floor,ff=d.isFF,_c8=d.boxModel.replace(/-/,""),_c9={dj_ie:ie,dj_ie6:maj(ie)==6,dj_ie7:maj(ie)==7,dj_ie8:maj(ie)==8,dj_ie9:maj(ie)==9,dj_quirks:d.isQuirks,dj_iequirks:ie&&d.isQuirks,dj_opera:_c7,dj_khtml:d.isKhtml,dj_webkit:d.isWebKit,dj_safari:d.isSafari,dj_chrome:d.isChrome,dj_gecko:d.isMozilla,dj_ff3:maj(ff)==3};
_c9["dj_"+_c8]=true;
var _ca="";
for(var clz in _c9){
if(_c9[clz]){
_ca+=clz+" ";
}
}
_c6.className=d.trim(_c6.className+" "+_ca);
dojo._loaders.unshift(function(){
if(!dojo._isBodyLtr()){
var _cb="dj_rtl dijitRtl "+_ca.replace(/ /g,"-rtl ");
_c6.className=d.trim(_c6.className+" "+_cb);
}
});
})();
}
if(!dojo._hasResource["dijit._base.sniff"]){
dojo._hasResource["dijit._base.sniff"]=true;
dojo.provide("dijit._base.sniff");
}
if(!dojo._hasResource["dijit._base.typematic"]){
dojo._hasResource["dijit._base.typematic"]=true;
dojo.provide("dijit._base.typematic");
dijit.typematic={_fireEventAndReload:function(){
this._timer=null;
this._callback(++this._count,this._node,this._evt);
this._currentTimeout=Math.max(this._currentTimeout<0?this._initialDelay:(this._subsequentDelay>1?this._subsequentDelay:Math.round(this._currentTimeout*this._subsequentDelay)),this._minDelay);
this._timer=setTimeout(dojo.hitch(this,"_fireEventAndReload"),this._currentTimeout);
},trigger:function(evt,_cc,_cd,_ce,obj,_cf,_d0,_d1){
if(obj!=this._obj){
this.stop();
this._initialDelay=_d0||500;
this._subsequentDelay=_cf||0.9;
this._minDelay=_d1||10;
this._obj=obj;
this._evt=evt;
this._node=_cd;
this._currentTimeout=-1;
this._count=-1;
this._callback=dojo.hitch(_cc,_ce);
this._fireEventAndReload();
this._evt=dojo.mixin({faux:true},evt);
}
},stop:function(){
if(this._timer){
clearTimeout(this._timer);
this._timer=null;
}
if(this._obj){
this._callback(-1,this._node,this._evt);
this._obj=null;
}
},addKeyListener:function(_d2,_d3,_d4,_d5,_d6,_d7,_d8){
if(_d3.keyCode){
_d3.charOrCode=_d3.keyCode;
dojo.deprecated("keyCode attribute parameter for dijit.typematic.addKeyListener is deprecated. Use charOrCode instead.","","2.0");
}else{
if(_d3.charCode){
_d3.charOrCode=String.fromCharCode(_d3.charCode);
dojo.deprecated("charCode attribute parameter for dijit.typematic.addKeyListener is deprecated. Use charOrCode instead.","","2.0");
}
}
return [dojo.connect(_d2,"onkeypress",this,function(evt){
if(evt.charOrCode==_d3.charOrCode&&(_d3.ctrlKey===undefined||_d3.ctrlKey==evt.ctrlKey)&&(_d3.altKey===undefined||_d3.altKey==evt.altKey)&&(_d3.metaKey===undefined||_d3.metaKey==(evt.metaKey||false))&&(_d3.shiftKey===undefined||_d3.shiftKey==evt.shiftKey)){
dojo.stopEvent(evt);
dijit.typematic.trigger(evt,_d4,_d2,_d5,_d3,_d6,_d7,_d8);
}else{
if(dijit.typematic._obj==_d3){
dijit.typematic.stop();
}
}
}),dojo.connect(_d2,"onkeyup",this,function(evt){
if(dijit.typematic._obj==_d3){
dijit.typematic.stop();
}
})];
},addMouseListener:function(_d9,_da,_db,_dc,_dd,_de){
var dc=dojo.connect;
return [dc(_d9,"mousedown",this,function(evt){
dojo.stopEvent(evt);
dijit.typematic.trigger(evt,_da,_d9,_db,_d9,_dc,_dd,_de);
}),dc(_d9,"mouseup",this,function(evt){
dojo.stopEvent(evt);
dijit.typematic.stop();
}),dc(_d9,"mouseout",this,function(evt){
dojo.stopEvent(evt);
dijit.typematic.stop();
}),dc(_d9,"mousemove",this,function(evt){
evt.preventDefault();
}),dc(_d9,"dblclick",this,function(evt){
dojo.stopEvent(evt);
if(dojo.isIE){
dijit.typematic.trigger(evt,_da,_d9,_db,_d9,_dc,_dd,_de);
setTimeout(dojo.hitch(this,dijit.typematic.stop),50);
}
})];
},addListener:function(_df,_e0,_e1,_e2,_e3,_e4,_e5,_e6){
return this.addKeyListener(_e0,_e1,_e2,_e3,_e4,_e5,_e6).concat(this.addMouseListener(_df,_e2,_e3,_e4,_e5,_e6));
}};
}
if(!dojo._hasResource["dijit._base.wai"]){
dojo._hasResource["dijit._base.wai"]=true;
dojo.provide("dijit._base.wai");
dijit.wai={onload:function(){
var div=dojo.create("div",{id:"a11yTestNode",style:{cssText:"border: 1px solid;"+"border-color:red green;"+"position: absolute;"+"height: 5px;"+"top: -999px;"+"background-image: url(\""+(dojo.config.blankGif||dojo.moduleUrl("dojo","resources/blank.gif"))+"\");"}},dojo.body());
var cs=dojo.getComputedStyle(div);
if(cs){
var _e7=cs.backgroundImage;
var _e8=(cs.borderTopColor==cs.borderRightColor)||(_e7!=null&&(_e7=="none"||_e7=="url(invalid-url:)"));
dojo[_e8?"addClass":"removeClass"](dojo.body(),"dijit_a11y");
if(dojo.isIE){
div.outerHTML="";
}else{
dojo.body().removeChild(div);
}
}
}};
if(dojo.isIE||dojo.isMoz){
dojo._loaders.unshift(dijit.wai.onload);
}
dojo.mixin(dijit,{hasWaiRole:function(_e9,_ea){
var _eb=this.getWaiRole(_e9);
return _ea?(_eb.indexOf(_ea)>-1):(_eb.length>0);
},getWaiRole:function(_ec){
return dojo.trim((dojo.attr(_ec,"role")||"").replace("wairole:",""));
},setWaiRole:function(_ed,_ee){
dojo.attr(_ed,"role",_ee);
},removeWaiRole:function(_ef,_f0){
var _f1=dojo.attr(_ef,"role");
if(!_f1){
return;
}
if(_f0){
var t=dojo.trim((" "+_f1+" ").replace(" "+_f0+" "," "));
dojo.attr(_ef,"role",t);
}else{
_ef.removeAttribute("role");
}
},hasWaiState:function(_f2,_f3){
return _f2.hasAttribute?_f2.hasAttribute("aria-"+_f3):!!_f2.getAttribute("aria-"+_f3);
},getWaiState:function(_f4,_f5){
return _f4.getAttribute("aria-"+_f5)||"";
},setWaiState:function(_f6,_f7,_f8){
_f6.setAttribute("aria-"+_f7,_f8);
},removeWaiState:function(_f9,_fa){
_f9.removeAttribute("aria-"+_fa);
}});
}
if(!dojo._hasResource["dijit._base"]){
dojo._hasResource["dijit._base"]=true;
dojo.provide("dijit._base");
}
if(!dojo._hasResource["dojo.date.stamp"]){
dojo._hasResource["dojo.date.stamp"]=true;
dojo.provide("dojo.date.stamp");
dojo.getObject("date.stamp",true,dojo);
dojo.date.stamp.fromISOString=function(_fb,_fc){
if(!dojo.date.stamp._isoRegExp){
dojo.date.stamp._isoRegExp=/^(?:(\d{4})(?:-(\d{2})(?:-(\d{2}))?)?)?(?:T(\d{2}):(\d{2})(?::(\d{2})(.\d+)?)?((?:[+-](\d{2}):(\d{2}))|Z)?)?$/;
}
var _fd=dojo.date.stamp._isoRegExp.exec(_fb),_fe=null;
if(_fd){
_fd.shift();
if(_fd[1]){
_fd[1]--;
}
if(_fd[6]){
_fd[6]*=1000;
}
if(_fc){
_fc=new Date(_fc);
dojo.forEach(dojo.map(["FullYear","Month","Date","Hours","Minutes","Seconds","Milliseconds"],function(_ff){
return _fc["get"+_ff]();
}),function(_100,_101){
_fd[_101]=_fd[_101]||_100;
});
}
_fe=new Date(_fd[0]||1970,_fd[1]||0,_fd[2]||1,_fd[3]||0,_fd[4]||0,_fd[5]||0,_fd[6]||0);
if(_fd[0]<100){
_fe.setFullYear(_fd[0]||1970);
}
var _102=0,_103=_fd[7]&&_fd[7].charAt(0);
if(_103!="Z"){
_102=((_fd[8]||0)*60)+(Number(_fd[9])||0);
if(_103!="-"){
_102*=-1;
}
}
if(_103){
_102-=_fe.getTimezoneOffset();
}
if(_102){
_fe.setTime(_fe.getTime()+_102*60000);
}
}
return _fe;
};
dojo.date.stamp.toISOString=function(_104,_105){
var _106=function(n){
return (n<10)?"0"+n:n;
};
_105=_105||{};
var _107=[],_108=_105.zulu?"getUTC":"get",date="";
if(_105.selector!="time"){
var year=_104[_108+"FullYear"]();
date=["0000".substr((year+"").length)+year,_106(_104[_108+"Month"]()+1),_106(_104[_108+"Date"]())].join("-");
}
_107.push(date);
if(_105.selector!="date"){
var time=[_106(_104[_108+"Hours"]()),_106(_104[_108+"Minutes"]()),_106(_104[_108+"Seconds"]())].join(":");
var _109=_104[_108+"Milliseconds"]();
if(_105.milliseconds){
time+="."+(_109<100?"0":"")+_106(_109);
}
if(_105.zulu){
time+="Z";
}else{
if(_105.selector!="time"){
var _10a=_104.getTimezoneOffset();
var _10b=Math.abs(_10a);
time+=(_10a>0?"-":"+")+_106(Math.floor(_10b/60))+":"+_106(_10b%60);
}
}
_107.push(time);
}
return _107.join("T");
};
}
if(!dojo._hasResource["dojo.parser"]){
dojo._hasResource["dojo.parser"]=true;
dojo.provide("dojo.parser");
new Date("X");
dojo.parser=new function(){
var d=dojo;
function _10c(_10d){
if(d.isString(_10d)){
return "string";
}
if(typeof _10d=="number"){
return "number";
}
if(typeof _10d=="boolean"){
return "boolean";
}
if(d.isFunction(_10d)){
return "function";
}
if(d.isArray(_10d)){
return "array";
}
if(_10d instanceof Date){
return "date";
}
if(_10d instanceof d._Url){
return "url";
}
return "object";
};
function _10e(_10f,type){
switch(type){
case "string":
return _10f;
case "number":
return _10f.length?Number(_10f):NaN;
case "boolean":
return typeof _10f=="boolean"?_10f:!(_10f.toLowerCase()=="false");
case "function":
if(d.isFunction(_10f)){
_10f=_10f.toString();
_10f=d.trim(_10f.substring(_10f.indexOf("{")+1,_10f.length-1));
}
try{
if(_10f===""||_10f.search(/[^\w\.]+/i)!=-1){
return new Function(_10f);
}else{
return d.getObject(_10f,false)||new Function(_10f);
}
}
catch(e){
return new Function();
}
case "array":
return _10f?_10f.split(/\s*,\s*/):[];
case "date":
switch(_10f){
case "":
return new Date("");
case "now":
return new Date();
default:
return d.date.stamp.fromISOString(_10f);
}
case "url":
return d.baseUrl+_10f;
default:
return d.fromJson(_10f);
}
};
var _110={},_111={};
d.connect(d,"extend",function(){
_111={};
});
function _112(cls,_113){
for(var name in cls){
if(name.charAt(0)=="_"){
continue;
}
if(name in _110){
continue;
}
_113[name]=_10c(cls[name]);
}
return _113;
};
function _114(_115,_116){
var c=_111[_115];
if(!c){
var cls=d.getObject(_115),_117=null;
if(!cls){
return null;
}
if(!_116){
_117=_112(cls.prototype,{});
}
c={cls:cls,params:_117};
}else{
if(!_116&&!c.params){
c.params=_112(c.cls.prototype,{});
}
}
return c;
};
this._functionFromScript=function(_118,_119){
var _11a="";
var _11b="";
var _11c=(_118.getAttribute(_119+"args")||_118.getAttribute("args"));
if(_11c){
d.forEach(_11c.split(/\s*,\s*/),function(part,idx){
_11a+="var "+part+" = arguments["+idx+"]; ";
});
}
var _11d=_118.getAttribute("with");
if(_11d&&_11d.length){
d.forEach(_11d.split(/\s*,\s*/),function(part){
_11a+="with("+part+"){";
_11b+="}";
});
}
return new Function(_11a+_118.innerHTML+_11b);
};
this.instantiate=function(_11e,_11f,args){
var _120=[],_11f=_11f||{};
args=args||{};
var _121=(args.scope||d._scopeName)+"Type",_122="data-"+(args.scope||d._scopeName)+"-";
d.forEach(_11e,function(obj){
if(!obj){
return;
}
var node,type,_123,_124,_125,_126;
if(obj.node){
node=obj.node;
type=obj.type;
_126=obj.fastpath;
_123=obj.clsInfo||(type&&_114(type,_126));
_124=_123&&_123.cls;
_125=obj.scripts;
}else{
node=obj;
type=_121 in _11f?_11f[_121]:node.getAttribute(_121);
_123=type&&_114(type);
_124=_123&&_123.cls;
_125=(_124&&(_124._noScript||_124.prototype._noScript)?[]:d.query("> script[type^='dojo/']",node));
}
if(!_123){
throw new Error("Could not load class '"+type);
}
var _127={};
if(args.defaults){
d._mixin(_127,args.defaults);
}
if(obj.inherited){
d._mixin(_127,obj.inherited);
}
if(_126){
var _128=node.getAttribute(_122+"props");
if(_128&&_128.length){
try{
_128=d.fromJson.call(args.propsThis,"{"+_128+"}");
d._mixin(_127,_128);
}
catch(e){
throw new Error(e.toString()+" in data-dojo-props='"+_128+"'");
}
}
var _129=node.getAttribute(_122+"attach-point");
if(_129){
_127.dojoAttachPoint=_129;
}
var _12a=node.getAttribute(_122+"attach-event");
if(_12a){
_127.dojoAttachEvent=_12a;
}
dojo.mixin(_127,_11f);
}else{
var _12b=node.attributes;
for(var name in _123.params){
var item=name in _11f?{value:_11f[name],specified:true}:_12b.getNamedItem(name);
if(!item||(!item.specified&&(!dojo.isIE||name.toLowerCase()!="value"))){
continue;
}
var _12c=item.value;
switch(name){
case "class":
_12c="className" in _11f?_11f.className:node.className;
break;
case "style":
_12c="style" in _11f?_11f.style:(node.style&&node.style.cssText);
}
var _12d=_123.params[name];
if(typeof _12c=="string"){
_127[name]=_10e(_12c,_12d);
}else{
_127[name]=_12c;
}
}
}
var _12e=[],_12f=[];
d.forEach(_125,function(_130){
node.removeChild(_130);
var _131=(_130.getAttribute(_122+"event")||_130.getAttribute("event")),type=_130.getAttribute("type"),nf=d.parser._functionFromScript(_130,_122);
if(_131){
if(type=="dojo/connect"){
_12e.push({event:_131,func:nf});
}else{
_127[_131]=nf;
}
}else{
_12f.push(nf);
}
});
var _132=_124.markupFactory||_124.prototype&&_124.prototype.markupFactory;
var _133=_132?_132(_127,node,_124):new _124(_127,node);
_120.push(_133);
var _134=(node.getAttribute(_122+"id")||node.getAttribute("jsId"));
if(_134){
d.setObject(_134,_133);
}
d.forEach(_12e,function(_135){
d.connect(_133,_135.event,null,_135.func);
});
d.forEach(_12f,function(func){
func.call(_133);
});
});
if(!_11f._started){
d.forEach(_120,function(_136){
if(!args.noStart&&_136&&dojo.isFunction(_136.startup)&&!_136._started&&(!_136.getParent||!_136.getParent())){
_136.startup();
}
});
}
return _120;
};
this.parse=function(_137,args){
var root;
if(!args&&_137&&_137.rootNode){
args=_137;
root=args.rootNode;
}else{
root=_137;
}
root=root?dojo.byId(root):dojo.body();
args=args||{};
var _138=(args.scope||d._scopeName)+"Type",_139="data-"+(args.scope||d._scopeName)+"-";
function scan(_13a,list){
var _13b=dojo.clone(_13a.inherited);
dojo.forEach(["dir","lang"],function(name){
var val=_13a.node.getAttribute(name);
if(val){
_13b[name]=val;
}
});
var _13c=_13a.clsInfo&&!_13a.clsInfo.cls.prototype._noScript?_13a.scripts:null;
var _13d=(!_13a.clsInfo||!_13a.clsInfo.cls.prototype.stopParser)||(args&&args.template);
for(var _13e=_13a.node.firstChild;_13e;_13e=_13e.nextSibling){
if(_13e.nodeType==1){
var type,_13f=_13d&&_13e.getAttribute(_139+"type");
if(_13f){
type=_13f;
}else{
type=_13d&&_13e.getAttribute(_138);
}
var _140=_13f==type;
if(type){
var _141={"type":type,fastpath:_140,clsInfo:_114(type,_140),node:_13e,scripts:[],inherited:_13b};
list.push(_141);
scan(_141,list);
}else{
if(_13c&&_13e.nodeName.toLowerCase()=="script"){
type=_13e.getAttribute("type");
if(type&&/^dojo\/\w/i.test(type)){
_13c.push(_13e);
}
}else{
if(_13d){
scan({node:_13e,inherited:_13b},list);
}
}
}
}
}
};
var _142={};
if(args&&args.inherited){
for(var key in args.inherited){
if(args.inherited[key]){
_142[key]=args.inherited[key];
}
}
}
var list=[];
scan({node:root,inherited:_142},list);
var _143=args&&args.template?{template:true}:null;
return this.instantiate(list,_143,args);
};
}();
(function(){
var _144=function(){
if(dojo.config.parseOnLoad){
dojo.parser.parse();
}
};
if(dojo.getObject("dijit.wai.onload")===dojo._loaders[0]){
dojo._loaders.splice(1,0,_144);
}else{
dojo._loaders.unshift(_144);
}
})();
}
if(!dojo._hasResource["dojo.Stateful"]){
dojo._hasResource["dojo.Stateful"]=true;
dojo.provide("dojo.Stateful");
dojo.declare("dojo.Stateful",null,{postscript:function(_145){
if(_145){
dojo.mixin(this,_145);
}
},get:function(name){
return this[name];
},set:function(name,_146){
if(typeof name==="object"){
for(var x in name){
this.set(x,name[x]);
}
return this;
}
var _147=this[name];
this[name]=_146;
if(this._watchCallbacks){
this._watchCallbacks(name,_147,_146);
}
return this;
},watch:function(name,_148){
var _149=this._watchCallbacks;
if(!_149){
var self=this;
_149=this._watchCallbacks=function(name,_14a,_14b,_14c){
var _14d=function(_14e){
if(_14e){
_14e=_14e.slice();
for(var i=0,l=_14e.length;i<l;i++){
try{
_14e[i].call(self,name,_14a,_14b);
}
catch(e){
console.error(e);
}
}
}
};
_14d(_149["_"+name]);
if(!_14c){
_14d(_149["*"]);
}
};
}
if(!_148&&typeof name==="function"){
_148=name;
name="*";
}else{
name="_"+name;
}
var _14f=_149[name];
if(typeof _14f!=="object"){
_14f=_149[name]=[];
}
_14f.push(_148);
return {unwatch:function(){
_14f.splice(dojo.indexOf(_14f,_148),1);
}};
}});
}
if(!dojo._hasResource["dijit._WidgetBase"]){
dojo._hasResource["dijit._WidgetBase"]=true;
dojo.provide("dijit._WidgetBase");
(function(){
dojo.declare("dijit._WidgetBase",dojo.Stateful,{id:"",lang:"",dir:"","class":"",style:"",title:"",tooltip:"",baseClass:"",srcNodeRef:null,domNode:null,containerNode:null,attributeMap:{id:"",dir:"",lang:"","class":"",style:"",title:""},_blankGif:(dojo.config.blankGif||dojo.moduleUrl("dojo","resources/blank.gif")).toString(),postscript:function(_150,_151){
this.create(_150,_151);
},create:function(_152,_153){
this.srcNodeRef=dojo.byId(_153);
this._connects=[];
this._subscribes=[];
if(this.srcNodeRef&&(typeof this.srcNodeRef.id=="string")){
this.id=this.srcNodeRef.id;
}
if(_152){
this.params=_152;
dojo._mixin(this,_152);
}
this.postMixInProperties();
if(!this.id){
this.id=dijit.getUniqueId(this.declaredClass.replace(/\./g,"_"));
}
dijit.registry.add(this);
this.buildRendering();
if(this.domNode){
this._applyAttributes();
var _154=this.srcNodeRef;
if(_154&&_154.parentNode&&this.domNode!==_154){
_154.parentNode.replaceChild(this.domNode,_154);
}
}
if(this.domNode){
this.domNode.setAttribute("widgetId",this.id);
}
this.postCreate();
if(this.srcNodeRef&&!this.srcNodeRef.parentNode){
delete this.srcNodeRef;
}
this._created=true;
},_applyAttributes:function(){
var _155=function(attr,_156){
if((_156.params&&attr in _156.params)||_156[attr]){
_156.set(attr,_156[attr]);
}
};
for(var attr in this.attributeMap){
_155(attr,this);
}
dojo.forEach(this._getSetterAttributes(),function(a){
if(!(a in this.attributeMap)){
_155(a,this);
}
},this);
},_getSetterAttributes:function(){
var ctor=this.constructor;
if(!ctor._setterAttrs){
var r=(ctor._setterAttrs=[]),_157,_158=ctor.prototype;
for(var _159 in _158){
if(dojo.isFunction(_158[_159])&&(_157=_159.match(/^_set([a-zA-Z]*)Attr$/))&&_157[1]){
r.push(_157[1].charAt(0).toLowerCase()+_157[1].substr(1));
}
}
}
return ctor._setterAttrs;
},postMixInProperties:function(){
},buildRendering:function(){
if(!this.domNode){
this.domNode=this.srcNodeRef||dojo.create("div");
}
if(this.baseClass){
var _15a=this.baseClass.split(" ");
if(!this.isLeftToRight()){
_15a=_15a.concat(dojo.map(_15a,function(name){
return name+"Rtl";
}));
}
dojo.addClass(this.domNode,_15a);
}
},postCreate:function(){
},startup:function(){
this._started=true;
},destroyRecursive:function(_15b){
this._beingDestroyed=true;
this.destroyDescendants(_15b);
this.destroy(_15b);
},destroy:function(_15c){
this._beingDestroyed=true;
this.uninitialize();
var d=dojo,dfe=d.forEach,dun=d.unsubscribe;
dfe(this._connects,function(_15d){
dfe(_15d,d.disconnect);
});
dfe(this._subscribes,function(_15e){
dun(_15e);
});
dfe(this._supportingWidgets||[],function(w){
if(w.destroyRecursive){
w.destroyRecursive();
}else{
if(w.destroy){
w.destroy();
}
}
});
this.destroyRendering(_15c);
dijit.registry.remove(this.id);
this._destroyed=true;
},destroyRendering:function(_15f){
if(this.bgIframe){
this.bgIframe.destroy(_15f);
delete this.bgIframe;
}
if(this.domNode){
if(_15f){
dojo.removeAttr(this.domNode,"widgetId");
}else{
dojo.destroy(this.domNode);
}
delete this.domNode;
}
if(this.srcNodeRef){
if(!_15f){
dojo.destroy(this.srcNodeRef);
}
delete this.srcNodeRef;
}
},destroyDescendants:function(_160){
dojo.forEach(this.getChildren(),function(_161){
if(_161.destroyRecursive){
_161.destroyRecursive(_160);
}
});
},uninitialize:function(){
return false;
},_setClassAttr:function(_162){
var _163=this[this.attributeMap["class"]||"domNode"];
dojo.replaceClass(_163,_162,this["class"]);
this._set("class",_162);
},_setStyleAttr:function(_164){
var _165=this[this.attributeMap.style||"domNode"];
if(dojo.isObject(_164)){
dojo.style(_165,_164);
}else{
if(_165.style.cssText){
_165.style.cssText+="; "+_164;
}else{
_165.style.cssText=_164;
}
}
this._set("style",_164);
},_attrToDom:function(attr,_166){
var _167=this.attributeMap[attr];
dojo.forEach(dojo.isArray(_167)?_167:[_167],function(_168){
var _169=this[_168.node||_168||"domNode"];
var type=_168.type||"attribute";
switch(type){
case "attribute":
if(dojo.isFunction(_166)){
_166=dojo.hitch(this,_166);
}
var _16a=_168.attribute?_168.attribute:(/^on[A-Z][a-zA-Z]*$/.test(attr)?attr.toLowerCase():attr);
dojo.attr(_169,_16a,_166);
break;
case "innerText":
_169.innerHTML="";
_169.appendChild(dojo.doc.createTextNode(_166));
break;
case "innerHTML":
_169.innerHTML=_166;
break;
case "class":
dojo.replaceClass(_169,_166,this[attr]);
break;
}
},this);
},get:function(name){
var _16b=this._getAttrNames(name);
return this[_16b.g]?this[_16b.g]():this[name];
},set:function(name,_16c){
if(typeof name==="object"){
for(var x in name){
this.set(x,name[x]);
}
return this;
}
var _16d=this._getAttrNames(name);
if(this[_16d.s]){
var _16e=this[_16d.s].apply(this,Array.prototype.slice.call(arguments,1));
}else{
if(name in this.attributeMap){
this._attrToDom(name,_16c);
}
this._set(name,_16c);
}
return _16e||this;
},_attrPairNames:{},_getAttrNames:function(name){
var apn=this._attrPairNames;
if(apn[name]){
return apn[name];
}
var uc=name.charAt(0).toUpperCase()+name.substr(1);
return (apn[name]={n:name+"Node",s:"_set"+uc+"Attr",g:"_get"+uc+"Attr"});
},_set:function(name,_16f){
var _170=this[name];
this[name]=_16f;
if(this._watchCallbacks&&this._created&&_16f!==_170){
this._watchCallbacks(name,_170,_16f);
}
},toString:function(){
return "[Widget "+this.declaredClass+", "+(this.id||"NO ID")+"]";
},getDescendants:function(){
return this.containerNode?dojo.query("[widgetId]",this.containerNode).map(dijit.byNode):[];
},getChildren:function(){
return this.containerNode?dijit.findWidgets(this.containerNode):[];
},connect:function(obj,_171,_172){
var _173=[dojo._connect(obj,_171,this,_172)];
this._connects.push(_173);
return _173;
},disconnect:function(_174){
for(var i=0;i<this._connects.length;i++){
if(this._connects[i]==_174){
dojo.forEach(_174,dojo.disconnect);
this._connects.splice(i,1);
return;
}
}
},subscribe:function(_175,_176){
var _177=dojo.subscribe(_175,this,_176);
this._subscribes.push(_177);
return _177;
},unsubscribe:function(_178){
for(var i=0;i<this._subscribes.length;i++){
if(this._subscribes[i]==_178){
dojo.unsubscribe(_178);
this._subscribes.splice(i,1);
return;
}
}
},isLeftToRight:function(){
return this.dir?(this.dir=="ltr"):dojo._isBodyLtr();
},placeAt:function(_179,_17a){
if(_179.declaredClass&&_179.addChild){
_179.addChild(this,_17a);
}else{
dojo.place(this.domNode,_179,_17a);
}
return this;
}});
})();
}
if(!dojo._hasResource["dijit._Widget"]){
dojo._hasResource["dijit._Widget"]=true;
dojo.provide("dijit._Widget");
dojo.connect(dojo,"_connect",function(_17b,_17c){
if(_17b&&dojo.isFunction(_17b._onConnect)){
_17b._onConnect(_17c);
}
});
dijit._connectOnUseEventHandler=function(_17d){
};
dijit._lastKeyDownNode=null;
if(dojo.isIE){
(function(){
var _17e=function(evt){
dijit._lastKeyDownNode=evt.srcElement;
};
dojo.doc.attachEvent("onkeydown",_17e);
dojo.addOnWindowUnload(function(){
dojo.doc.detachEvent("onkeydown",_17e);
});
})();
}else{
dojo.doc.addEventListener("keydown",function(evt){
dijit._lastKeyDownNode=evt.target;
},true);
}
(function(){
dojo.declare("dijit._Widget",dijit._WidgetBase,{_deferredConnects:{onClick:"",onDblClick:"",onKeyDown:"",onKeyPress:"",onKeyUp:"",onMouseMove:"",onMouseDown:"",onMouseOut:"",onMouseOver:"",onMouseLeave:"",onMouseEnter:"",onMouseUp:""},onClick:dijit._connectOnUseEventHandler,onDblClick:dijit._connectOnUseEventHandler,onKeyDown:dijit._connectOnUseEventHandler,onKeyPress:dijit._connectOnUseEventHandler,onKeyUp:dijit._connectOnUseEventHandler,onMouseDown:dijit._connectOnUseEventHandler,onMouseMove:dijit._connectOnUseEventHandler,onMouseOut:dijit._connectOnUseEventHandler,onMouseOver:dijit._connectOnUseEventHandler,onMouseLeave:dijit._connectOnUseEventHandler,onMouseEnter:dijit._connectOnUseEventHandler,onMouseUp:dijit._connectOnUseEventHandler,create:function(_17f,_180){
this._deferredConnects=dojo.clone(this._deferredConnects);
for(var attr in this.attributeMap){
delete this._deferredConnects[attr];
}
for(attr in this._deferredConnects){
if(this[attr]!==dijit._connectOnUseEventHandler){
delete this._deferredConnects[attr];
}
}
this.inherited(arguments);
if(this.domNode){
for(attr in this.params){
this._onConnect(attr);
}
}
},_onConnect:function(_181){
if(_181 in this._deferredConnects){
var _182=this[this._deferredConnects[_181]||"domNode"];
this.connect(_182,_181.toLowerCase(),_181);
delete this._deferredConnects[_181];
}
},focused:false,isFocusable:function(){
return this.focus&&(dojo.style(this.domNode,"display")!="none");
},onFocus:function(){
},onBlur:function(){
},_onFocus:function(e){
this.onFocus();
},_onBlur:function(){
this.onBlur();
},setAttribute:function(attr,_183){
dojo.deprecated(this.declaredClass+"::setAttribute(attr, value) is deprecated. Use set() instead.","","2.0");
this.set(attr,_183);
},attr:function(name,_184){
if(dojo.config.isDebug){
var _185=arguments.callee._ach||(arguments.callee._ach={}),_186=(arguments.callee.caller||"unknown caller").toString();
if(!_185[_186]){
dojo.deprecated(this.declaredClass+"::attr() is deprecated. Use get() or set() instead, called from "+_186,"","2.0");
_185[_186]=true;
}
}
var args=arguments.length;
if(args>=2||typeof name==="object"){
return this.set.apply(this,arguments);
}else{
return this.get(name);
}
},nodesWithKeyClick:["input","button"],connect:function(obj,_187,_188){
var d=dojo,dc=d._connect,_189=this.inherited(arguments,[obj,_187=="ondijitclick"?"onclick":_187,_188]);
if(_187=="ondijitclick"){
if(d.indexOf(this.nodesWithKeyClick,obj.nodeName.toLowerCase())==-1){
var m=d.hitch(this,_188);
_189.push(dc(obj,"onkeydown",this,function(e){
if((e.keyCode==d.keys.ENTER||e.keyCode==d.keys.SPACE)&&!e.ctrlKey&&!e.shiftKey&&!e.altKey&&!e.metaKey){
dijit._lastKeyDownNode=e.target;
if(!("openDropDown" in this&&obj==this._buttonNode)){
e.preventDefault();
}
}
}),dc(obj,"onkeyup",this,function(e){
if((e.keyCode==d.keys.ENTER||e.keyCode==d.keys.SPACE)&&e.target==dijit._lastKeyDownNode&&!e.ctrlKey&&!e.shiftKey&&!e.altKey&&!e.metaKey){
dijit._lastKeyDownNode=null;
return m(e);
}
}));
}
}
return _189;
},_onShow:function(){
this.onShow();
},onShow:function(){
},onHide:function(){
},onClose:function(){
return true;
}});
})();
}
if(!dojo._hasResource["dojo.string"]){
dojo._hasResource["dojo.string"]=true;
dojo.provide("dojo.string");
dojo.getObject("string",true,dojo);
dojo.string.rep=function(str,num){
if(num<=0||!str){
return "";
}
var buf=[];
for(;;){
if(num&1){
buf.push(str);
}
if(!(num>>=1)){
break;
}
str+=str;
}
return buf.join("");
};
dojo.string.pad=function(text,size,ch,end){
if(!ch){
ch="0";
}
var out=String(text),pad=dojo.string.rep(ch,Math.ceil((size-out.length)/ch.length));
return end?out+pad:pad+out;
};
dojo.string.substitute=function(_18a,map,_18b,_18c){
_18c=_18c||dojo.global;
_18b=_18b?dojo.hitch(_18c,_18b):function(v){
return v;
};
return _18a.replace(/\$\{([^\s\:\}]+)(?:\:([^\s\:\}]+))?\}/g,function(_18d,key,_18e){
var _18f=dojo.getObject(key,false,map);
if(_18e){
_18f=dojo.getObject(_18e,false,_18c).call(_18c,_18f,key);
}
return _18b(_18f,key).toString();
});
};
dojo.string.trim=String.prototype.trim?dojo.trim:function(str){
str=str.replace(/^\s+/,"");
for(var i=str.length-1;i>=0;i--){
if(/\S/.test(str.charAt(i))){
str=str.substring(0,i+1);
break;
}
}
return str;
};
}
if(!dojo._hasResource["dojo.cache"]){
dojo._hasResource["dojo.cache"]=true;
dojo.provide("dojo.cache");
var cache={};
dojo.cache=function(_190,url,_191){
if(typeof _190=="string"){
var _192=dojo.moduleUrl(_190,url);
}else{
_192=_190;
_191=url;
}
var key=_192.toString();
var val=_191;
if(_191!=undefined&&!dojo.isString(_191)){
val=("value" in _191?_191.value:undefined);
}
var _193=_191&&_191.sanitize?true:false;
if(typeof val=="string"){
val=cache[key]=_193?dojo.cache._sanitize(val):val;
}else{
if(val===null){
delete cache[key];
}else{
if(!(key in cache)){
val=dojo._getText(key);
cache[key]=_193?dojo.cache._sanitize(val):val;
}
val=cache[key];
}
}
return val;
};
dojo.cache._sanitize=function(val){
if(val){
val=val.replace(/^\s*<\?xml(\s)+version=[\'\"](\d)*.(\d)*[\'\"](\s)*\?>/im,"");
var _194=val.match(/<body[^>]*>\s*([\s\S]+)\s*<\/body>/im);
if(_194){
val=_194[1];
}
}else{
val="";
}
return val;
};
}
if(!dojo._hasResource["dijit._Templated"]){
dojo._hasResource["dijit._Templated"]=true;
dojo.provide("dijit._Templated");
dojo.declare("dijit._Templated",null,{templateString:null,templatePath:null,widgetsInTemplate:false,_skipNodeCache:false,_earlyTemplatedStartup:false,constructor:function(){
this._attachPoints=[];
this._attachEvents=[];
},_stringRepl:function(tmpl){
var _195=this.declaredClass,_196=this;
return dojo.string.substitute(tmpl,this,function(_197,key){
if(key.charAt(0)=="!"){
_197=dojo.getObject(key.substr(1),false,_196);
}
if(typeof _197=="undefined"){
throw new Error(_195+" template:"+key);
}
if(_197==null){
return "";
}
return key.charAt(0)=="!"?_197:_197.toString().replace(/"/g,"&quot;");
},this);
},buildRendering:function(){
var _198=dijit._Templated.getCachedTemplate(this.templatePath,this.templateString,this._skipNodeCache);
var node;
if(dojo.isString(_198)){
node=dojo._toDom(this._stringRepl(_198));
if(node.nodeType!=1){
throw new Error("Invalid template: "+_198);
}
}else{
node=_198.cloneNode(true);
}
this.domNode=node;
this.inherited(arguments);
this._attachTemplateNodes(node);
if(this.widgetsInTemplate){
var cw=(this._startupWidgets=dojo.parser.parse(node,{noStart:!this._earlyTemplatedStartup,template:true,inherited:{dir:this.dir,lang:this.lang},propsThis:this,scope:"dojo"}));
this._supportingWidgets=dijit.findWidgets(node);
this._attachTemplateNodes(cw,function(n,p){
return n[p];
});
}
this._fillContent(this.srcNodeRef);
},_fillContent:function(_199){
var dest=this.containerNode;
if(_199&&dest){
while(_199.hasChildNodes()){
dest.appendChild(_199.firstChild);
}
}
},_attachTemplateNodes:function(_19a,_19b){
_19b=_19b||function(n,p){
return n.getAttribute(p);
};
var _19c=dojo.isArray(_19a)?_19a:(_19a.all||_19a.getElementsByTagName("*"));
var x=dojo.isArray(_19a)?0:-1;
for(;x<_19c.length;x++){
var _19d=(x==-1)?_19a:_19c[x];
if(this.widgetsInTemplate&&(_19b(_19d,"dojoType")||_19b(_19d,"data-dojo-type"))){
continue;
}
var _19e=_19b(_19d,"dojoAttachPoint")||_19b(_19d,"data-dojo-attach-point");
if(_19e){
var _19f,_1a0=_19e.split(/\s*,\s*/);
while((_19f=_1a0.shift())){
if(dojo.isArray(this[_19f])){
this[_19f].push(_19d);
}else{
this[_19f]=_19d;
}
this._attachPoints.push(_19f);
}
}
var _1a1=_19b(_19d,"dojoAttachEvent")||_19b(_19d,"data-dojo-attach-event");
if(_1a1){
var _1a2,_1a3=_1a1.split(/\s*,\s*/);
var trim=dojo.trim;
while((_1a2=_1a3.shift())){
if(_1a2){
var _1a4=null;
if(_1a2.indexOf(":")!=-1){
var _1a5=_1a2.split(":");
_1a2=trim(_1a5[0]);
_1a4=trim(_1a5[1]);
}else{
_1a2=trim(_1a2);
}
if(!_1a4){
_1a4=_1a2;
}
this._attachEvents.push(this.connect(_19d,_1a2,_1a4));
}
}
}
var role=_19b(_19d,"waiRole");
if(role){
dijit.setWaiRole(_19d,role);
}
var _1a6=_19b(_19d,"waiState");
if(_1a6){
dojo.forEach(_1a6.split(/\s*,\s*/),function(_1a7){
if(_1a7.indexOf("-")!=-1){
var pair=_1a7.split("-");
dijit.setWaiState(_19d,pair[0],pair[1]);
}
});
}
}
},startup:function(){
dojo.forEach(this._startupWidgets,function(w){
if(w&&!w._started&&w.startup){
w.startup();
}
});
this.inherited(arguments);
},destroyRendering:function(){
dojo.forEach(this._attachPoints,function(_1a8){
delete this[_1a8];
},this);
this._attachPoints=[];
dojo.forEach(this._attachEvents,this.disconnect,this);
this._attachEvents=[];
this.inherited(arguments);
}});
dijit._Templated._templateCache={};
dijit._Templated.getCachedTemplate=function(_1a9,_1aa,_1ab){
var _1ac=dijit._Templated._templateCache;
var key=_1aa||_1a9;
var _1ad=_1ac[key];
if(_1ad){
try{
if(!_1ad.ownerDocument||_1ad.ownerDocument==dojo.doc){
return _1ad;
}
}
catch(e){
}
dojo.destroy(_1ad);
}
if(!_1aa){
_1aa=dojo.cache(_1a9,{sanitize:true});
}
_1aa=dojo.string.trim(_1aa);
if(_1ab||_1aa.match(/\$\{([^\}]+)\}/g)){
return (_1ac[key]=_1aa);
}else{
var node=dojo._toDom(_1aa);
if(node.nodeType!=1){
throw new Error("Invalid template: "+_1aa);
}
return (_1ac[key]=node);
}
};
if(dojo.isIE){
dojo.addOnWindowUnload(function(){
var _1ae=dijit._Templated._templateCache;
for(var key in _1ae){
var _1af=_1ae[key];
if(typeof _1af=="object"){
dojo.destroy(_1af);
}
delete _1ae[key];
}
});
}
dojo.extend(dijit._Widget,{dojoAttachEvent:"",dojoAttachPoint:"",waiRole:"",waiState:""});
}
if(!dojo._hasResource["dijit._Container"]){
dojo._hasResource["dijit._Container"]=true;
dojo.provide("dijit._Container");
dojo.declare("dijit._Container",null,{isContainer:true,buildRendering:function(){
this.inherited(arguments);
if(!this.containerNode){
this.containerNode=this.domNode;
}
},addChild:function(_1b0,_1b1){
var _1b2=this.containerNode;
if(_1b1&&typeof _1b1=="number"){
var _1b3=this.getChildren();
if(_1b3&&_1b3.length>=_1b1){
_1b2=_1b3[_1b1-1].domNode;
_1b1="after";
}
}
dojo.place(_1b0.domNode,_1b2,_1b1);
if(this._started&&!_1b0._started){
_1b0.startup();
}
},removeChild:function(_1b4){
if(typeof _1b4=="number"){
_1b4=this.getChildren()[_1b4];
}
if(_1b4){
var node=_1b4.domNode;
if(node&&node.parentNode){
node.parentNode.removeChild(node);
}
}
},hasChildren:function(){
return this.getChildren().length>0;
},destroyDescendants:function(_1b5){
dojo.forEach(this.getChildren(),function(_1b6){
_1b6.destroyRecursive(_1b5);
});
},_getSiblingOfChild:function(_1b7,dir){
var node=_1b7.domNode,_1b8=(dir>0?"nextSibling":"previousSibling");
do{
node=node[_1b8];
}while(node&&(node.nodeType!=1||!dijit.byNode(node)));
return node&&dijit.byNode(node);
},getIndexOfChild:function(_1b9){
return dojo.indexOf(this.getChildren(),_1b9);
},startup:function(){
if(this._started){
return;
}
dojo.forEach(this.getChildren(),function(_1ba){
_1ba.startup();
});
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit._Contained"]){
dojo._hasResource["dijit._Contained"]=true;
dojo.provide("dijit._Contained");
dojo.declare("dijit._Contained",null,{getParent:function(){
var _1bb=dijit.getEnclosingWidget(this.domNode.parentNode);
return _1bb&&_1bb.isContainer?_1bb:null;
},_getSibling:function(_1bc){
var node=this.domNode;
do{
node=node[_1bc+"Sibling"];
}while(node&&node.nodeType!=1);
return node&&dijit.byNode(node);
},getPreviousSibling:function(){
return this._getSibling("previous");
},getNextSibling:function(){
return this._getSibling("next");
},getIndexInParent:function(){
var p=this.getParent();
if(!p||!p.getIndexOfChild){
return -1;
}
return p.getIndexOfChild(this);
}});
}
if(!dojo._hasResource["dijit.layout._LayoutWidget"]){
dojo._hasResource["dijit.layout._LayoutWidget"]=true;
dojo.provide("dijit.layout._LayoutWidget");
dojo.declare("dijit.layout._LayoutWidget",[dijit._Widget,dijit._Container,dijit._Contained],{baseClass:"dijitLayoutContainer",isLayoutContainer:true,buildRendering:function(){
this.inherited(arguments);
dojo.addClass(this.domNode,"dijitContainer");
},startup:function(){
if(this._started){
return;
}
this.inherited(arguments);
var _1bd=this.getParent&&this.getParent();
if(!(_1bd&&_1bd.isLayoutContainer)){
this.resize();
this.connect(dojo.isIE?this.domNode:dojo.global,"onresize",function(){
this.resize();
});
}
},resize:function(_1be,_1bf){
var node=this.domNode;
if(_1be){
dojo.marginBox(node,_1be);
if(_1be.t){
node.style.top=_1be.t+"px";
}
if(_1be.l){
node.style.left=_1be.l+"px";
}
}
var mb=_1bf||{};
dojo.mixin(mb,_1be||{});
if(!("h" in mb)||!("w" in mb)){
mb=dojo.mixin(dojo.marginBox(node),mb);
}
var cs=dojo.getComputedStyle(node);
var me=dojo._getMarginExtents(node,cs);
var be=dojo._getBorderExtents(node,cs);
var bb=(this._borderBox={w:mb.w-(me.w+be.w),h:mb.h-(me.h+be.h)});
var pe=dojo._getPadExtents(node,cs);
this._contentBox={l:dojo._toPixelValue(node,cs.paddingLeft),t:dojo._toPixelValue(node,cs.paddingTop),w:bb.w-pe.w,h:bb.h-pe.h};
this.layout();
},layout:function(){
},_setupChild:function(_1c0){
var cls=this.baseClass+"-child "+(_1c0.baseClass?this.baseClass+"-"+_1c0.baseClass:"");
dojo.addClass(_1c0.domNode,cls);
},addChild:function(_1c1,_1c2){
this.inherited(arguments);
if(this._started){
this._setupChild(_1c1);
}
},removeChild:function(_1c3){
var cls=this.baseClass+"-child"+(_1c3.baseClass?" "+this.baseClass+"-"+_1c3.baseClass:"");
dojo.removeClass(_1c3.domNode,cls);
this.inherited(arguments);
}});
dijit.layout.marginBox2contentBox=function(node,mb){
var cs=dojo.getComputedStyle(node);
var me=dojo._getMarginExtents(node,cs);
var pb=dojo._getPadBorderExtents(node,cs);
return {l:dojo._toPixelValue(node,cs.paddingLeft),t:dojo._toPixelValue(node,cs.paddingTop),w:mb.w-(me.w+pb.w),h:mb.h-(me.h+pb.h)};
};
(function(){
var _1c4=function(word){
return word.substring(0,1).toUpperCase()+word.substring(1);
};
var size=function(_1c5,dim){
var _1c6=_1c5.resize?_1c5.resize(dim):dojo.marginBox(_1c5.domNode,dim);
if(_1c6){
dojo.mixin(_1c5,_1c6);
}else{
dojo.mixin(_1c5,dojo.marginBox(_1c5.domNode));
dojo.mixin(_1c5,dim);
}
};
dijit.layout.layoutChildren=function(_1c7,dim,_1c8,_1c9,_1ca){
dim=dojo.mixin({},dim);
dojo.addClass(_1c7,"dijitLayoutContainer");
_1c8=dojo.filter(_1c8,function(item){
return item.region!="center"&&item.layoutAlign!="client";
}).concat(dojo.filter(_1c8,function(item){
return item.region=="center"||item.layoutAlign=="client";
}));
dojo.forEach(_1c8,function(_1cb){
var elm=_1cb.domNode,pos=(_1cb.region||_1cb.layoutAlign);
var _1cc=elm.style;
_1cc.left=dim.l+"px";
_1cc.top=dim.t+"px";
_1cc.position="absolute";
dojo.addClass(elm,"dijitAlign"+_1c4(pos));
var _1cd={};
if(_1c9&&_1c9==_1cb.id){
_1cd[_1cb.region=="top"||_1cb.region=="bottom"?"h":"w"]=_1ca;
}
if(pos=="top"||pos=="bottom"){
_1cd.w=dim.w;
size(_1cb,_1cd);
dim.h-=_1cb.h;
if(pos=="top"){
dim.t+=_1cb.h;
}else{
_1cc.top=dim.t+dim.h+"px";
}
}else{
if(pos=="left"||pos=="right"){
_1cd.h=dim.h;
size(_1cb,_1cd);
dim.w-=_1cb.w;
if(pos=="left"){
dim.l+=_1cb.w;
}else{
_1cc.left=dim.l+dim.w+"px";
}
}else{
if(pos=="client"||pos=="center"){
size(_1cb,dim);
}
}
}
});
};
})();
}
if(!dojo._hasResource["dijit._CssStateMixin"]){
dojo._hasResource["dijit._CssStateMixin"]=true;
dojo.provide("dijit._CssStateMixin");
dojo.declare("dijit._CssStateMixin",[],{cssStateNodes:{},hovering:false,active:false,_applyAttributes:function(){
this.inherited(arguments);
dojo.forEach(["onmouseenter","onmouseleave","onmousedown"],function(e){
this.connect(this.domNode,e,"_cssMouseEvent");
},this);
dojo.forEach(["disabled","readOnly","checked","selected","focused","state","hovering","active"],function(attr){
this.watch(attr,dojo.hitch(this,"_setStateClass"));
},this);
for(var ap in this.cssStateNodes){
this._trackMouseState(this[ap],this.cssStateNodes[ap]);
}
this._setStateClass();
},_cssMouseEvent:function(_1ce){
if(!this.disabled){
switch(_1ce.type){
case "mouseenter":
case "mouseover":
this._set("hovering",true);
this._set("active",this._mouseDown);
break;
case "mouseleave":
case "mouseout":
this._set("hovering",false);
this._set("active",false);
break;
case "mousedown":
this._set("active",true);
this._mouseDown=true;
var _1cf=this.connect(dojo.body(),"onmouseup",function(){
this._mouseDown=false;
this._set("active",false);
this.disconnect(_1cf);
});
break;
}
}
},_setStateClass:function(){
var _1d0=this.baseClass.split(" ");
function _1d1(_1d2){
_1d0=_1d0.concat(dojo.map(_1d0,function(c){
return c+_1d2;
}),"dijit"+_1d2);
};
if(!this.isLeftToRight()){
_1d1("Rtl");
}
if(this.checked){
_1d1("Checked");
}
if(this.state){
_1d1(this.state);
}
if(this.selected){
_1d1("Selected");
}
if(this.disabled){
_1d1("Disabled");
}else{
if(this.readOnly){
_1d1("ReadOnly");
}else{
if(this.active){
_1d1("Active");
}else{
if(this.hovering){
_1d1("Hover");
}
}
}
}
if(this._focused){
_1d1("Focused");
}
var tn=this.stateNode||this.domNode,_1d3={};
dojo.forEach(tn.className.split(" "),function(c){
_1d3[c]=true;
});
if("_stateClasses" in this){
dojo.forEach(this._stateClasses,function(c){
delete _1d3[c];
});
}
dojo.forEach(_1d0,function(c){
_1d3[c]=true;
});
var _1d4=[];
for(var c in _1d3){
_1d4.push(c);
}
tn.className=_1d4.join(" ");
this._stateClasses=_1d0;
},_trackMouseState:function(node,_1d5){
var _1d6=false,_1d7=false,_1d8=false;
var self=this,cn=dojo.hitch(this,"connect",node);
function _1d9(){
var _1da=("disabled" in self&&self.disabled)||("readonly" in self&&self.readonly);
dojo.toggleClass(node,_1d5+"Hover",_1d6&&!_1d7&&!_1da);
dojo.toggleClass(node,_1d5+"Active",_1d7&&!_1da);
dojo.toggleClass(node,_1d5+"Focused",_1d8&&!_1da);
};
cn("onmouseenter",function(){
_1d6=true;
_1d9();
});
cn("onmouseleave",function(){
_1d6=false;
_1d7=false;
_1d9();
});
cn("onmousedown",function(){
_1d7=true;
_1d9();
});
cn("onmouseup",function(){
_1d7=false;
_1d9();
});
cn("onfocus",function(){
_1d8=true;
_1d9();
});
cn("onblur",function(){
_1d8=false;
_1d9();
});
this.watch("disabled",_1d9);
this.watch("readOnly",_1d9);
}});
}
if(!dojo._hasResource["dijit.form._FormWidget"]){
dojo._hasResource["dijit.form._FormWidget"]=true;
dojo.provide("dijit.form._FormWidget");
dojo.declare("dijit.form._FormWidget",[dijit._Widget,dijit._Templated,dijit._CssStateMixin],{name:"",alt:"",value:"",type:"text",tabIndex:"0",disabled:false,intermediateChanges:false,scrollOnFocus:true,attributeMap:dojo.delegate(dijit._Widget.prototype.attributeMap,{value:"focusNode",id:"focusNode",tabIndex:"focusNode",alt:"focusNode",title:"focusNode"}),postMixInProperties:function(){
this.nameAttrSetting=this.name?("name=\""+this.name.replace(/'/g,"&quot;")+"\""):"";
this.inherited(arguments);
},postCreate:function(){
this.inherited(arguments);
this.connect(this.domNode,"onmousedown","_onMouseDown");
},_setDisabledAttr:function(_1db){
this._set("disabled",_1db);
dojo.attr(this.focusNode,"disabled",_1db);
if(this.valueNode){
dojo.attr(this.valueNode,"disabled",_1db);
}
dijit.setWaiState(this.focusNode,"disabled",_1db);
if(_1db){
this._set("hovering",false);
this._set("active",false);
var _1dc="tabIndex" in this.attributeMap?this.attributeMap.tabIndex:"focusNode";
dojo.forEach(dojo.isArray(_1dc)?_1dc:[_1dc],function(_1dd){
var node=this[_1dd];
if(dojo.isWebKit||dijit.hasDefaultTabStop(node)){
node.setAttribute("tabIndex","-1");
}else{
node.removeAttribute("tabIndex");
}
},this);
}else{
if(this.tabIndex!=""){
this.focusNode.setAttribute("tabIndex",this.tabIndex);
}
}
},setDisabled:function(_1de){
dojo.deprecated("setDisabled("+_1de+") is deprecated. Use set('disabled',"+_1de+") instead.","","2.0");
this.set("disabled",_1de);
},_onFocus:function(e){
if(this.scrollOnFocus){
dojo.window.scrollIntoView(this.domNode);
}
this.inherited(arguments);
},isFocusable:function(){
return !this.disabled&&this.focusNode&&(dojo.style(this.domNode,"display")!="none");
},focus:function(){
if(!this.disabled){
dijit.focus(this.focusNode);
}
},compare:function(val1,val2){
if(typeof val1=="number"&&typeof val2=="number"){
return (isNaN(val1)&&isNaN(val2))?0:val1-val2;
}else{
if(val1>val2){
return 1;
}else{
if(val1<val2){
return -1;
}else{
return 0;
}
}
}
},onChange:function(_1df){
},_onChangeActive:false,_handleOnChange:function(_1e0,_1e1){
if(this._lastValueReported==undefined&&(_1e1===null||!this._onChangeActive)){
this._resetValue=this._lastValueReported=_1e0;
}
this._pendingOnChange=this._pendingOnChange||(typeof _1e0!=typeof this._lastValueReported)||(this.compare(_1e0,this._lastValueReported)!=0);
if((this.intermediateChanges||_1e1||_1e1===undefined)&&this._pendingOnChange){
this._lastValueReported=_1e0;
this._pendingOnChange=false;
if(this._onChangeActive){
if(this._onChangeHandle){
clearTimeout(this._onChangeHandle);
}
this._onChangeHandle=setTimeout(dojo.hitch(this,function(){
this._onChangeHandle=null;
this.onChange(_1e0);
}),0);
}
}
},create:function(){
this.inherited(arguments);
this._onChangeActive=true;
},destroy:function(){
if(this._onChangeHandle){
clearTimeout(this._onChangeHandle);
this.onChange(this._lastValueReported);
}
this.inherited(arguments);
},setValue:function(_1e2){
dojo.deprecated("dijit.form._FormWidget:setValue("+_1e2+") is deprecated.  Use set('value',"+_1e2+") instead.","","2.0");
this.set("value",_1e2);
},getValue:function(){
dojo.deprecated(this.declaredClass+"::getValue() is deprecated. Use get('value') instead.","","2.0");
return this.get("value");
},_onMouseDown:function(e){
if(!e.ctrlKey&&dojo.mouseButtons.isLeft(e)&&this.isFocusable()){
var _1e3=this.connect(dojo.body(),"onmouseup",function(){
if(this.isFocusable()){
this.focus();
}
this.disconnect(_1e3);
});
}
}});
dojo.declare("dijit.form._FormValueWidget",dijit.form._FormWidget,{readOnly:false,attributeMap:dojo.delegate(dijit.form._FormWidget.prototype.attributeMap,{value:"",readOnly:"focusNode"}),_setReadOnlyAttr:function(_1e4){
dojo.attr(this.focusNode,"readOnly",_1e4);
dijit.setWaiState(this.focusNode,"readonly",_1e4);
this._set("readOnly",_1e4);
},postCreate:function(){
this.inherited(arguments);
if(dojo.isIE<9||(dojo.isIE&&dojo.isQuirks)){
this.connect(this.focusNode||this.domNode,"onkeydown",this._onKeyDown);
}
if(this._resetValue===undefined){
this._lastValueReported=this._resetValue=this.value;
}
},_setValueAttr:function(_1e5,_1e6){
this._handleOnChange(_1e5,_1e6);
},_handleOnChange:function(_1e7,_1e8){
this._set("value",_1e7);
this.inherited(arguments);
},undo:function(){
this._setValueAttr(this._lastValueReported,false);
},reset:function(){
this._hasBeenBlurred=false;
this._setValueAttr(this._resetValue,true);
},_onKeyDown:function(e){
if(e.keyCode==dojo.keys.ESCAPE&&!(e.ctrlKey||e.altKey||e.metaKey)){
var te;
if(dojo.isIE){
e.preventDefault();
te=document.createEventObject();
te.keyCode=dojo.keys.ESCAPE;
te.shiftKey=e.shiftKey;
e.srcElement.fireEvent("onkeypress",te);
}
}
},_layoutHackIE7:function(){
if(dojo.isIE==7){
var _1e9=this.domNode;
var _1ea=_1e9.parentNode;
var _1eb=_1e9.firstChild||_1e9;
var _1ec=_1eb.style.filter;
var _1ed=this;
while(_1ea&&_1ea.clientHeight==0){
(function ping(){
var _1ee=_1ed.connect(_1ea,"onscroll",function(e){
_1ed.disconnect(_1ee);
_1eb.style.filter=(new Date()).getMilliseconds();
setTimeout(function(){
_1eb.style.filter=_1ec;
},0);
});
})();
_1ea=_1ea.parentNode;
}
}
}});
}
if(!dojo._hasResource["dijit.dijit"]){
dojo._hasResource["dijit.dijit"]=true;
dojo.provide("dijit.dijit");
}
if(!dojo._hasResource["dijit._KeyNavContainer"]){
dojo._hasResource["dijit._KeyNavContainer"]=true;
dojo.provide("dijit._KeyNavContainer");
dojo.declare("dijit._KeyNavContainer",dijit._Container,{tabIndex:"0",_keyNavCodes:{},connectKeyNavHandlers:function(_1ef,_1f0){
var _1f1=(this._keyNavCodes={});
var prev=dojo.hitch(this,this.focusPrev);
var next=dojo.hitch(this,this.focusNext);
dojo.forEach(_1ef,function(code){
_1f1[code]=prev;
});
dojo.forEach(_1f0,function(code){
_1f1[code]=next;
});
_1f1[dojo.keys.HOME]=dojo.hitch(this,"focusFirstChild");
_1f1[dojo.keys.END]=dojo.hitch(this,"focusLastChild");
this.connect(this.domNode,"onkeypress","_onContainerKeypress");
this.connect(this.domNode,"onfocus","_onContainerFocus");
},startupKeyNavChildren:function(){
dojo.forEach(this.getChildren(),dojo.hitch(this,"_startupChild"));
},addChild:function(_1f2,_1f3){
dijit._KeyNavContainer.superclass.addChild.apply(this,arguments);
this._startupChild(_1f2);
},focus:function(){
this.focusFirstChild();
},focusFirstChild:function(){
var _1f4=this._getFirstFocusableChild();
if(_1f4){
this.focusChild(_1f4);
}
},focusLastChild:function(){
var _1f5=this._getLastFocusableChild();
if(_1f5){
this.focusChild(_1f5);
}
},focusNext:function(){
var _1f6=this._getNextFocusableChild(this.focusedChild,1);
this.focusChild(_1f6);
},focusPrev:function(){
var _1f7=this._getNextFocusableChild(this.focusedChild,-1);
this.focusChild(_1f7,true);
},focusChild:function(_1f8,last){
if(this.focusedChild&&_1f8!==this.focusedChild){
this._onChildBlur(this.focusedChild);
}
_1f8.set("tabIndex",this.tabIndex);
_1f8.focus(last?"end":"start");
this._set("focusedChild",_1f8);
},_startupChild:function(_1f9){
_1f9.set("tabIndex","-1");
this.connect(_1f9,"_onFocus",function(){
_1f9.set("tabIndex",this.tabIndex);
});
this.connect(_1f9,"_onBlur",function(){
_1f9.set("tabIndex","-1");
});
},_onContainerFocus:function(evt){
if(evt.target!==this.domNode){
return;
}
this.focusFirstChild();
dojo.attr(this.domNode,"tabIndex","-1");
},_onBlur:function(evt){
if(this.tabIndex){
dojo.attr(this.domNode,"tabIndex",this.tabIndex);
}
this.inherited(arguments);
},_onContainerKeypress:function(evt){
if(evt.ctrlKey||evt.altKey){
return;
}
var func=this._keyNavCodes[evt.charOrCode];
if(func){
func();
dojo.stopEvent(evt);
}
},_onChildBlur:function(_1fa){
},_getFirstFocusableChild:function(){
return this._getNextFocusableChild(null,1);
},_getLastFocusableChild:function(){
return this._getNextFocusableChild(null,-1);
},_getNextFocusableChild:function(_1fb,dir){
if(_1fb){
_1fb=this._getSiblingOfChild(_1fb,dir);
}
var _1fc=this.getChildren();
for(var i=0;i<_1fc.length;i++){
if(!_1fb){
_1fb=_1fc[(dir>0)?0:(_1fc.length-1)];
}
if(_1fb.isFocusable()){
return _1fb;
}
_1fb=this._getSiblingOfChild(_1fb,dir);
}
return null;
}});
}
if(!dojo._hasResource["dijit.MenuItem"]){
dojo._hasResource["dijit.MenuItem"]=true;
dojo.provide("dijit.MenuItem");
dojo.declare("dijit.MenuItem",[dijit._Widget,dijit._Templated,dijit._Contained,dijit._CssStateMixin],{templateString:dojo.cache("dijit","templates/MenuItem.html","<tr class=\"dijitReset dijitMenuItem\" dojoAttachPoint=\"focusNode\" role=\"menuitem\" tabIndex=\"-1\"\r\n\t\tdojoAttachEvent=\"onmouseenter:_onHover,onmouseleave:_onUnhover,ondijitclick:_onClick\">\r\n\t<td class=\"dijitReset dijitMenuItemIconCell\" role=\"presentation\">\r\n\t\t<img src=\"${_blankGif}\" alt=\"\" class=\"dijitIcon dijitMenuItemIcon\" dojoAttachPoint=\"iconNode\"/>\r\n\t</td>\r\n\t<td class=\"dijitReset dijitMenuItemLabel\" colspan=\"2\" dojoAttachPoint=\"containerNode\"></td>\r\n\t<td class=\"dijitReset dijitMenuItemAccelKey\" style=\"display: none\" dojoAttachPoint=\"accelKeyNode\"></td>\r\n\t<td class=\"dijitReset dijitMenuArrowCell\" role=\"presentation\">\r\n\t\t<div dojoAttachPoint=\"arrowWrapper\" style=\"visibility: hidden\">\r\n\t\t\t<img src=\"${_blankGif}\" alt=\"\" class=\"dijitMenuExpand\"/>\r\n\t\t\t<span class=\"dijitMenuExpandA11y\">+</span>\r\n\t\t</div>\r\n\t</td>\r\n</tr>\r\n"),attributeMap:dojo.delegate(dijit._Widget.prototype.attributeMap,{label:{node:"containerNode",type:"innerHTML"},iconClass:{node:"iconNode",type:"class"}}),baseClass:"dijitMenuItem",label:"",iconClass:"",accelKey:"",disabled:false,_fillContent:function(_1fd){
if(_1fd&&!("label" in this.params)){
this.set("label",_1fd.innerHTML);
}
},buildRendering:function(){
this.inherited(arguments);
var _1fe=this.id+"_text";
dojo.attr(this.containerNode,"id",_1fe);
if(this.accelKeyNode){
dojo.attr(this.accelKeyNode,"id",this.id+"_accel");
_1fe+=" "+this.id+"_accel";
}
dijit.setWaiState(this.domNode,"labelledby",_1fe);
dojo.setSelectable(this.domNode,false);
},_onHover:function(){
this.getParent().onItemHover(this);
},_onUnhover:function(){
this.getParent().onItemUnhover(this);
this._set("hovering",false);
},_onClick:function(evt){
this.getParent().onItemClick(this,evt);
dojo.stopEvent(evt);
},onClick:function(evt){
},focus:function(){
try{
if(dojo.isIE==8){
this.containerNode.focus();
}
dijit.focus(this.focusNode);
}
catch(e){
}
},_onFocus:function(){
this._setSelected(true);
this.getParent()._onItemFocus(this);
this.inherited(arguments);
},_setSelected:function(_1ff){
dojo.toggleClass(this.domNode,"dijitMenuItemSelected",_1ff);
},setLabel:function(_200){
dojo.deprecated("dijit.MenuItem.setLabel() is deprecated.  Use set('label', ...) instead.","","2.0");
this.set("label",_200);
},setDisabled:function(_201){
dojo.deprecated("dijit.Menu.setDisabled() is deprecated.  Use set('disabled', bool) instead.","","2.0");
this.set("disabled",_201);
},_setDisabledAttr:function(_202){
dijit.setWaiState(this.focusNode,"disabled",_202?"true":"false");
this._set("disabled",_202);
},_setAccelKeyAttr:function(_203){
this.accelKeyNode.style.display=_203?"":"none";
this.accelKeyNode.innerHTML=_203;
dojo.attr(this.containerNode,"colSpan",_203?"1":"2");
this._set("accelKey",_203);
}});
}
if(!dojo._hasResource["dijit.PopupMenuItem"]){
dojo._hasResource["dijit.PopupMenuItem"]=true;
dojo.provide("dijit.PopupMenuItem");
dojo.declare("dijit.PopupMenuItem",dijit.MenuItem,{_fillContent:function(){
if(this.srcNodeRef){
var _204=dojo.query("*",this.srcNodeRef);
dijit.PopupMenuItem.superclass._fillContent.call(this,_204[0]);
this.dropDownContainer=this.srcNodeRef;
}
},startup:function(){
if(this._started){
return;
}
this.inherited(arguments);
if(!this.popup){
var node=dojo.query("[widgetId]",this.dropDownContainer)[0];
this.popup=dijit.byNode(node);
}
dojo.body().appendChild(this.popup.domNode);
this.popup.startup();
this.popup.domNode.style.display="none";
if(this.arrowWrapper){
dojo.style(this.arrowWrapper,"visibility","");
}
dijit.setWaiState(this.focusNode,"haspopup","true");
},destroyDescendants:function(){
if(this.popup){
if(!this.popup._destroyed){
this.popup.destroyRecursive();
}
delete this.popup;
}
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.CheckedMenuItem"]){
dojo._hasResource["dijit.CheckedMenuItem"]=true;
dojo.provide("dijit.CheckedMenuItem");
dojo.declare("dijit.CheckedMenuItem",dijit.MenuItem,{templateString:dojo.cache("dijit","templates/CheckedMenuItem.html","<tr class=\"dijitReset dijitMenuItem\" dojoAttachPoint=\"focusNode\" role=\"menuitemcheckbox\" tabIndex=\"-1\"\r\n\t\tdojoAttachEvent=\"onmouseenter:_onHover,onmouseleave:_onUnhover,ondijitclick:_onClick\">\r\n\t<td class=\"dijitReset dijitMenuItemIconCell\" role=\"presentation\">\r\n\t\t<img src=\"${_blankGif}\" alt=\"\" class=\"dijitMenuItemIcon dijitCheckedMenuItemIcon\" dojoAttachPoint=\"iconNode\"/>\r\n\t\t<span class=\"dijitCheckedMenuItemIconChar\">&#10003;</span>\r\n\t</td>\r\n\t<td class=\"dijitReset dijitMenuItemLabel\" colspan=\"2\" dojoAttachPoint=\"containerNode,labelNode\"></td>\r\n\t<td class=\"dijitReset dijitMenuItemAccelKey\" style=\"display: none\" dojoAttachPoint=\"accelKeyNode\"></td>\r\n\t<td class=\"dijitReset dijitMenuArrowCell\" role=\"presentation\">&nbsp;</td>\r\n</tr>\r\n"),checked:false,_setCheckedAttr:function(_205){
dojo.toggleClass(this.domNode,"dijitCheckedMenuItemChecked",_205);
dijit.setWaiState(this.domNode,"checked",_205);
this._set("checked",_205);
},onChange:function(_206){
},_onClick:function(e){
if(!this.disabled){
this.set("checked",!this.checked);
this.onChange(this.checked);
}
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.MenuSeparator"]){
dojo._hasResource["dijit.MenuSeparator"]=true;
dojo.provide("dijit.MenuSeparator");
dojo.declare("dijit.MenuSeparator",[dijit._Widget,dijit._Templated,dijit._Contained],{templateString:dojo.cache("dijit","templates/MenuSeparator.html","<tr class=\"dijitMenuSeparator\">\r\n\t<td class=\"dijitMenuSeparatorIconCell\">\r\n\t\t<div class=\"dijitMenuSeparatorTop\"></div>\r\n\t\t<div class=\"dijitMenuSeparatorBottom\"></div>\r\n\t</td>\r\n\t<td colspan=\"3\" class=\"dijitMenuSeparatorLabelCell\">\r\n\t\t<div class=\"dijitMenuSeparatorTop dijitMenuSeparatorLabel\"></div>\r\n\t\t<div class=\"dijitMenuSeparatorBottom\"></div>\r\n\t</td>\r\n</tr>\r\n"),buildRendering:function(){
this.inherited(arguments);
dojo.setSelectable(this.domNode,false);
},isFocusable:function(){
return false;
}});
}
if(!dojo._hasResource["dijit.Menu"]){
dojo._hasResource["dijit.Menu"]=true;
dojo.provide("dijit.Menu");
dojo.declare("dijit._MenuBase",[dijit._Widget,dijit._Templated,dijit._KeyNavContainer],{parentMenu:null,popupDelay:500,startup:function(){
if(this._started){
return;
}
dojo.forEach(this.getChildren(),function(_207){
_207.startup();
});
this.startupKeyNavChildren();
this.inherited(arguments);
},onExecute:function(){
},onCancel:function(_208){
},_moveToPopup:function(evt){
if(this.focusedChild&&this.focusedChild.popup&&!this.focusedChild.disabled){
this.focusedChild._onClick(evt);
}else{
var _209=this._getTopMenu();
if(_209&&_209._isMenuBar){
_209.focusNext();
}
}
},_onPopupHover:function(evt){
if(this.currentPopup&&this.currentPopup._pendingClose_timer){
var _20a=this.currentPopup.parentMenu;
if(_20a.focusedChild){
_20a.focusedChild._setSelected(false);
}
_20a.focusedChild=this.currentPopup.from_item;
_20a.focusedChild._setSelected(true);
this._stopPendingCloseTimer(this.currentPopup);
}
},onItemHover:function(item){
if(this.isActive){
this.focusChild(item);
if(this.focusedChild.popup&&!this.focusedChild.disabled&&!this.hover_timer){
this.hover_timer=setTimeout(dojo.hitch(this,"_openPopup"),this.popupDelay);
}
}
if(this.focusedChild){
this.focusChild(item);
}
this._hoveredChild=item;
},_onChildBlur:function(item){
this._stopPopupTimer();
item._setSelected(false);
var _20b=item.popup;
if(_20b){
this._stopPendingCloseTimer(_20b);
_20b._pendingClose_timer=setTimeout(function(){
_20b._pendingClose_timer=null;
if(_20b.parentMenu){
_20b.parentMenu.currentPopup=null;
}
dijit.popup.close(_20b);
},this.popupDelay);
}
},onItemUnhover:function(item){
if(this.isActive){
this._stopPopupTimer();
}
if(this._hoveredChild==item){
this._hoveredChild=null;
}
},_stopPopupTimer:function(){
if(this.hover_timer){
clearTimeout(this.hover_timer);
this.hover_timer=null;
}
},_stopPendingCloseTimer:function(_20c){
if(_20c._pendingClose_timer){
clearTimeout(_20c._pendingClose_timer);
_20c._pendingClose_timer=null;
}
},_stopFocusTimer:function(){
if(this._focus_timer){
clearTimeout(this._focus_timer);
this._focus_timer=null;
}
},_getTopMenu:function(){
for(var top=this;top.parentMenu;top=top.parentMenu){
}
return top;
},onItemClick:function(item,evt){
if(typeof this.isShowingNow=="undefined"){
this._markActive();
}
this.focusChild(item);
if(item.disabled){
return false;
}
if(item.popup){
this._openPopup();
}else{
this.onExecute();
item.onClick(evt);
}
},_openPopup:function(){
this._stopPopupTimer();
var _20d=this.focusedChild;
if(!_20d){
return;
}
var _20e=_20d.popup;
if(_20e.isShowingNow){
return;
}
if(this.currentPopup){
this._stopPendingCloseTimer(this.currentPopup);
dijit.popup.close(this.currentPopup);
}
_20e.parentMenu=this;
_20e.from_item=_20d;
var self=this;
dijit.popup.open({parent:this,popup:_20e,around:_20d.domNode,orient:this._orient||(this.isLeftToRight()?{"TR":"TL","TL":"TR","BR":"BL","BL":"BR"}:{"TL":"TR","TR":"TL","BL":"BR","BR":"BL"}),onCancel:function(){
self.focusChild(_20d);
self._cleanUp();
_20d._setSelected(true);
self.focusedChild=_20d;
},onExecute:dojo.hitch(this,"_cleanUp")});
this.currentPopup=_20e;
_20e.connect(_20e.domNode,"onmouseenter",dojo.hitch(self,"_onPopupHover"));
if(_20e.focus){
_20e._focus_timer=setTimeout(dojo.hitch(_20e,function(){
this._focus_timer=null;
this.focus();
}),0);
}
},_markActive:function(){
this.isActive=true;
dojo.replaceClass(this.domNode,"dijitMenuActive","dijitMenuPassive");
},onOpen:function(e){
this.isShowingNow=true;
this._markActive();
},_markInactive:function(){
this.isActive=false;
dojo.replaceClass(this.domNode,"dijitMenuPassive","dijitMenuActive");
},onClose:function(){
this._stopFocusTimer();
this._markInactive();
this.isShowingNow=false;
this.parentMenu=null;
},_closeChild:function(){
this._stopPopupTimer();
var _20f=this.focusedChild&&this.focusedChild.from_item;
if(this.currentPopup){
if(dijit._curFocus&&dojo.isDescendant(dijit._curFocus,this.currentPopup.domNode)){
this.focusedChild.focusNode.focus();
}
dijit.popup.close(this.currentPopup);
this.currentPopup=null;
}
if(this.focusedChild){
this.focusedChild._setSelected(false);
this.focusedChild._onUnhover();
this.focusedChild=null;
}
},_onItemFocus:function(item){
if(this._hoveredChild&&this._hoveredChild!=item){
this._hoveredChild._onUnhover();
}
},_onBlur:function(){
this._cleanUp();
this.inherited(arguments);
},_cleanUp:function(){
this._closeChild();
if(typeof this.isShowingNow=="undefined"){
this._markInactive();
}
}});
dojo.declare("dijit.Menu",dijit._MenuBase,{constructor:function(){
this._bindings=[];
},templateString:dojo.cache("dijit","templates/Menu.html","<table class=\"dijit dijitMenu dijitMenuPassive dijitReset dijitMenuTable\" role=\"menu\" tabIndex=\"${tabIndex}\" dojoAttachEvent=\"onkeypress:_onKeyPress\" cellspacing=\"0\">\r\n\t<tbody class=\"dijitReset\" dojoAttachPoint=\"containerNode\"></tbody>\r\n</table>\r\n"),baseClass:"dijitMenu",targetNodeIds:[],contextMenuForWindow:false,leftClickToOpen:false,refocus:true,postCreate:function(){
if(this.contextMenuForWindow){
this.bindDomNode(dojo.body());
}else{
dojo.forEach(this.targetNodeIds,this.bindDomNode,this);
}
var k=dojo.keys,l=this.isLeftToRight();
this._openSubMenuKey=l?k.RIGHT_ARROW:k.LEFT_ARROW;
this._closeSubMenuKey=l?k.LEFT_ARROW:k.RIGHT_ARROW;
this.connectKeyNavHandlers([k.UP_ARROW],[k.DOWN_ARROW]);
},_onKeyPress:function(evt){
if(evt.ctrlKey||evt.altKey){
return;
}
switch(evt.charOrCode){
case this._openSubMenuKey:
this._moveToPopup(evt);
dojo.stopEvent(evt);
break;
case this._closeSubMenuKey:
if(this.parentMenu){
if(this.parentMenu._isMenuBar){
this.parentMenu.focusPrev();
}else{
this.onCancel(false);
}
}else{
dojo.stopEvent(evt);
}
break;
}
},_iframeContentWindow:function(_210){
var win=dojo.window.get(this._iframeContentDocument(_210))||this._iframeContentDocument(_210)["__parent__"]||(_210.name&&dojo.doc.frames[_210.name])||null;
return win;
},_iframeContentDocument:function(_211){
var doc=_211.contentDocument||(_211.contentWindow&&_211.contentWindow.document)||(_211.name&&dojo.doc.frames[_211.name]&&dojo.doc.frames[_211.name].document)||null;
return doc;
},bindDomNode:function(node){
node=dojo.byId(node);
var cn;
if(node.tagName.toLowerCase()=="iframe"){
var _212=node,win=this._iframeContentWindow(_212);
cn=dojo.withGlobal(win,dojo.body);
}else{
cn=(node==dojo.body()?dojo.doc.documentElement:node);
}
var _213={node:node,iframe:_212};
dojo.attr(node,"_dijitMenu"+this.id,this._bindings.push(_213));
var _214=dojo.hitch(this,function(cn){
return [dojo.connect(cn,this.leftClickToOpen?"onclick":"oncontextmenu",this,function(evt){
dojo.stopEvent(evt);
this._scheduleOpen(evt.target,_212,{x:evt.pageX,y:evt.pageY});
}),dojo.connect(cn,"onkeydown",this,function(evt){
if(evt.shiftKey&&evt.keyCode==dojo.keys.F10){
dojo.stopEvent(evt);
this._scheduleOpen(evt.target,_212);
}
})];
});
_213.connects=cn?_214(cn):[];
if(_212){
_213.onloadHandler=dojo.hitch(this,function(){
var win=this._iframeContentWindow(_212);
cn=dojo.withGlobal(win,dojo.body);
_213.connects=_214(cn);
});
if(_212.addEventListener){
_212.addEventListener("load",_213.onloadHandler,false);
}else{
_212.attachEvent("onload",_213.onloadHandler);
}
}
},unBindDomNode:function(_215){
var node;
try{
node=dojo.byId(_215);
}
catch(e){
return;
}
var _216="_dijitMenu"+this.id;
if(node&&dojo.hasAttr(node,_216)){
var bid=dojo.attr(node,_216)-1,b=this._bindings[bid];
dojo.forEach(b.connects,dojo.disconnect);
var _217=b.iframe;
if(_217){
if(_217.removeEventListener){
_217.removeEventListener("load",b.onloadHandler,false);
}else{
_217.detachEvent("onload",b.onloadHandler);
}
}
dojo.removeAttr(node,_216);
delete this._bindings[bid];
}
},_scheduleOpen:function(_218,_219,_21a){
if(!this._openTimer){
this._openTimer=setTimeout(dojo.hitch(this,function(){
delete this._openTimer;
this._openMyself({target:_218,iframe:_219,coords:_21a});
}),1);
}
},_openMyself:function(args){
var _21b=args.target,_21c=args.iframe,_21d=args.coords;
if(_21d){
if(_21c){
var od=_21b.ownerDocument,ifc=dojo.position(_21c,true),win=this._iframeContentWindow(_21c),_21e=dojo.withGlobal(win,"_docScroll",dojo);
var cs=dojo.getComputedStyle(_21c),tp=dojo._toPixelValue,left=(dojo.isIE&&dojo.isQuirks?0:tp(_21c,cs.paddingLeft))+(dojo.isIE&&dojo.isQuirks?tp(_21c,cs.borderLeftWidth):0),top=(dojo.isIE&&dojo.isQuirks?0:tp(_21c,cs.paddingTop))+(dojo.isIE&&dojo.isQuirks?tp(_21c,cs.borderTopWidth):0);
_21d.x+=ifc.x+left-_21e.x;
_21d.y+=ifc.y+top-_21e.y;
}
}else{
_21d=dojo.position(_21b,true);
_21d.x+=10;
_21d.y+=10;
}
var self=this;
var _21f=dijit.getFocus(this);
function _220(){
if(self.refocus){
dijit.focus(_21f);
}
dijit.popup.close(self);
};
dijit.popup.open({popup:this,x:_21d.x,y:_21d.y,onExecute:_220,onCancel:_220,orient:this.isLeftToRight()?"L":"R"});
this.focus();
this._onBlur=function(){
this.inherited("_onBlur",arguments);
dijit.popup.close(this);
};
},uninitialize:function(){
dojo.forEach(this._bindings,function(b){
if(b){
this.unBindDomNode(b.node);
}
},this);
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dojox.html.metrics"]){
dojo._hasResource["dojox.html.metrics"]=true;
dojo.provide("dojox.html.metrics");
(function(){
var dhm=dojox.html.metrics;
dhm.getFontMeasurements=function(){
var _221={"1em":0,"1ex":0,"100%":0,"12pt":0,"16px":0,"xx-small":0,"x-small":0,"small":0,"medium":0,"large":0,"x-large":0,"xx-large":0};
if(dojo.isIE){
dojo.doc.documentElement.style.fontSize="100%";
}
var div=dojo.doc.createElement("div");
var ds=div.style;
ds.position="absolute";
ds.left="-100px";
ds.top="0";
ds.width="30px";
ds.height="1000em";
ds.borderWidth="0";
ds.margin="0";
ds.padding="0";
ds.outline="0";
ds.lineHeight="1";
ds.overflow="hidden";
dojo.body().appendChild(div);
for(var p in _221){
ds.fontSize=p;
_221[p]=Math.round(div.offsetHeight*12/16)*16/12/1000;
}
dojo.body().removeChild(div);
div=null;
return _221;
};
var _222=null;
dhm.getCachedFontMeasurements=function(_223){
if(_223||!_222){
_222=dhm.getFontMeasurements();
}
return _222;
};
var _224=null,_225={};
dhm.getTextBox=function(text,_226,_227){
var m,s;
if(!_224){
m=_224=dojo.doc.createElement("div");
var c=dojo.doc.createElement("div");
c.appendChild(m);
s=c.style;
s.overflow="scroll";
s.position="absolute";
s.left="0px";
s.top="-10000px";
s.width="1px";
s.height="1px";
s.visibility="hidden";
s.borderWidth="0";
s.margin="0";
s.padding="0";
s.outline="0";
dojo.body().appendChild(c);
}else{
m=_224;
}
m.className="";
s=m.style;
s.borderWidth="0";
s.margin="0";
s.padding="0";
s.outline="0";
if(arguments.length>1&&_226){
for(var i in _226){
if(i in _225){
continue;
}
s[i]=_226[i];
}
}
if(arguments.length>2&&_227){
m.className=_227;
}
m.innerHTML=text;
var box=dojo.position(m);
box.w=m.parentNode.scrollWidth;
return box;
};
var _228={w:16,h:16};
dhm.getScrollbar=function(){
return {w:_228.w,h:_228.h};
};
dhm._fontResizeNode=null;
dhm.initOnFontResize=function(_229){
var f=dhm._fontResizeNode=dojo.doc.createElement("iframe");
var fs=f.style;
fs.position="absolute";
fs.width="5em";
fs.height="10em";
fs.top="-10000px";
if(dojo.isIE){
f.onreadystatechange=function(){
if(f.contentWindow.document.readyState=="complete"){
f.onresize=f.contentWindow.parent[dojox._scopeName].html.metrics._fontresize;
}
};
}else{
f.onload=function(){
f.contentWindow.onresize=f.contentWindow.parent[dojox._scopeName].html.metrics._fontresize;
};
}
f.setAttribute("src","javascript:'<html><head><script>if(\"loadFirebugConsole\" in window){window.loadFirebugConsole();}</script></head><body></body></html>'");
dojo.body().appendChild(f);
dhm.initOnFontResize=function(){
};
};
dhm.onFontResize=function(){
};
dhm._fontresize=function(){
dhm.onFontResize();
};
dojo.addOnUnload(function(){
var f=dhm._fontResizeNode;
if(f){
if(dojo.isIE&&f.onresize){
f.onresize=null;
}else{
if(f.contentWindow&&f.contentWindow.onresize){
f.contentWindow.onresize=null;
}
}
dhm._fontResizeNode=null;
}
});
dojo.addOnLoad(function(){
try{
var n=dojo.doc.createElement("div");
n.style.cssText="top:0;left:0;width:100px;height:100px;overflow:scroll;position:absolute;visibility:hidden;";
dojo.body().appendChild(n);
_228.w=n.offsetWidth-n.clientWidth;
_228.h=n.offsetHeight-n.clientHeight;
dojo.body().removeChild(n);
delete n;
}
catch(e){
}
if("fontSizeWatch" in dojo.config&&!!dojo.config.fontSizeWatch){
dhm.initOnFontResize();
}
});
})();
}
if(!dojo._hasResource["dojox.grid.util"]){
dojo._hasResource["dojox.grid.util"]=true;
dojo.provide("dojox.grid.util");
(function(){
var dgu=dojox.grid.util;
dgu.na="...";
dgu.rowIndexTag="gridRowIndex";
dgu.gridViewTag="gridView";
dgu.fire=function(ob,ev,args){
var fn=ob&&ev&&ob[ev];
return fn&&(args?fn.apply(ob,args):ob[ev]());
};
dgu.setStyleHeightPx=function(_22a,_22b){
if(_22b>=0){
var s=_22a.style;
var v=_22b+"px";
if(_22a&&s["height"]!=v){
s["height"]=v;
}
}
};
dgu.mouseEvents=["mouseover","mouseout","mousedown","mouseup","click","dblclick","contextmenu"];
dgu.keyEvents=["keyup","keydown","keypress"];
dgu.funnelEvents=function(_22c,_22d,_22e,_22f){
var evts=(_22f?_22f:dgu.mouseEvents.concat(dgu.keyEvents));
for(var i=0,l=evts.length;i<l;i++){
_22d.connect(_22c,"on"+evts[i],_22e);
}
};
dgu.removeNode=function(_230){
_230=dojo.byId(_230);
_230&&_230.parentNode&&_230.parentNode.removeChild(_230);
return _230;
};
dgu.arrayCompare=function(inA,inB){
for(var i=0,l=inA.length;i<l;i++){
if(inA[i]!=inB[i]){
return false;
}
}
return (inA.length==inB.length);
};
dgu.arrayInsert=function(_231,_232,_233){
if(_231.length<=_232){
_231[_232]=_233;
}else{
_231.splice(_232,0,_233);
}
};
dgu.arrayRemove=function(_234,_235){
_234.splice(_235,1);
};
dgu.arraySwap=function(_236,inI,inJ){
var _237=_236[inI];
_236[inI]=_236[inJ];
_236[inJ]=_237;
};
dgu.fixIEEmptyCell=function(_238){
if((dojo.isIE<8||(dojo.isIE&&dojo.isQuirks))&&(_238===null||_238===""||/^\s+$/.test(_238))){
return "&nbsp;";
}else{
return _238;
}
};
})();
}
if(!dojo._hasResource["dojox.grid._Scroller"]){
dojo._hasResource["dojox.grid._Scroller"]=true;
dojo.provide("dojox.grid._Scroller");
(function(){
var _239=function(_23a){
var i=0,n,p=_23a.parentNode;
while((n=p.childNodes[i++])){
if(n==_23a){
return i-1;
}
}
return -1;
};
var _23b=function(_23c){
if(!_23c){
return;
}
var _23d=function(inW){
return inW.domNode&&dojo.isDescendant(inW.domNode,_23c,true);
};
var ws=dijit.registry.filter(_23d);
ws.forEach(function(w){
w.destroy();
});
delete ws;
};
var _23e=function(_23f){
var node=dojo.byId(_23f);
return (node&&node.tagName?node.tagName.toLowerCase():"");
};
var _240=function(_241,_242){
var _243=[];
var i=0,n;
while((n=_241.childNodes[i])){
i++;
if(_23e(n)==_242){
_243.push(n);
}
}
return _243;
};
var _244=function(_245){
return _240(_245,"div");
};
dojo.declare("dojox.grid._Scroller",null,{constructor:function(_246){
this.setContentNodes(_246);
this.pageHeights=[];
this.pageNodes=[];
this.stack=[];
},rowCount:0,defaultRowHeight:32,keepRows:100,contentNode:null,scrollboxNode:null,defaultPageHeight:0,keepPages:10,pageCount:0,windowHeight:0,firstVisibleRow:0,lastVisibleRow:0,averageRowHeight:0,page:0,pageTop:0,init:function(_247,_248,_249){
switch(arguments.length){
case 3:
this.rowsPerPage=_249;
case 2:
this.keepRows=_248;
case 1:
this.rowCount=_247;
default:
break;
}
this.defaultPageHeight=this.defaultRowHeight*this.rowsPerPage;
this.pageCount=this._getPageCount(this.rowCount,this.rowsPerPage);
this.setKeepInfo(this.keepRows);
this.invalidate();
if(this.scrollboxNode){
this.scrollboxNode.scrollTop=0;
this.scroll(0);
this.scrollboxNode.onscroll=dojo.hitch(this,"onscroll");
}
},_getPageCount:function(_24a,_24b){
return _24a?(Math.ceil(_24a/_24b)||1):0;
},destroy:function(){
this.invalidateNodes();
delete this.contentNodes;
delete this.contentNode;
delete this.scrollboxNode;
},setKeepInfo:function(_24c){
this.keepRows=_24c;
this.keepPages=!this.keepRows?this.keepPages:Math.max(Math.ceil(this.keepRows/this.rowsPerPage),2);
},setContentNodes:function(_24d){
this.contentNodes=_24d;
this.colCount=(this.contentNodes?this.contentNodes.length:0);
this.pageNodes=[];
for(var i=0;i<this.colCount;i++){
this.pageNodes[i]=[];
}
},getDefaultNodes:function(){
return this.pageNodes[0]||[];
},invalidate:function(){
this._invalidating=true;
this.invalidateNodes();
this.pageHeights=[];
this.height=(this.pageCount?(this.pageCount-1)*this.defaultPageHeight+this.calcLastPageHeight():0);
this.resize();
this._invalidating=false;
},updateRowCount:function(_24e){
this.invalidateNodes();
this.rowCount=_24e;
var _24f=this.pageCount;
if(_24f===0){
this.height=1;
}
this.pageCount=this._getPageCount(this.rowCount,this.rowsPerPage);
if(this.pageCount<_24f){
for(var i=_24f-1;i>=this.pageCount;i--){
this.height-=this.getPageHeight(i);
delete this.pageHeights[i];
}
}else{
if(this.pageCount>_24f){
this.height+=this.defaultPageHeight*(this.pageCount-_24f-1)+this.calcLastPageHeight();
}
}
this.resize();
},pageExists:function(_250){
return Boolean(this.getDefaultPageNode(_250));
},measurePage:function(_251){
if(this.grid.rowHeight){
var _252=this.grid.rowHeight+1;
return ((_251+1)*this.rowsPerPage>this.rowCount?this.rowCount-_251*this.rowsPerPage:this.rowsPerPage)*_252;
}
var n=this.getDefaultPageNode(_251);
return (n&&n.innerHTML)?n.offsetHeight:undefined;
},positionPage:function(_253,_254){
for(var i=0;i<this.colCount;i++){
this.pageNodes[i][_253].style.top=_254+"px";
}
},repositionPages:function(_255){
var _256=this.getDefaultNodes();
var last=0;
for(var i=0;i<this.stack.length;i++){
last=Math.max(this.stack[i],last);
}
var n=_256[_255];
var y=(n?this.getPageNodePosition(n)+this.getPageHeight(_255):0);
for(var p=_255+1;p<=last;p++){
n=_256[p];
if(n){
if(this.getPageNodePosition(n)==y){
return;
}
this.positionPage(p,y);
}
y+=this.getPageHeight(p);
}
},installPage:function(_257){
for(var i=0;i<this.colCount;i++){
this.contentNodes[i].appendChild(this.pageNodes[i][_257]);
}
},preparePage:function(_258,_259){
var p=(_259?this.popPage():null);
for(var i=0;i<this.colCount;i++){
var _25a=this.pageNodes[i];
var _25b=(p===null?this.createPageNode():this.invalidatePageNode(p,_25a));
_25b.pageIndex=_258;
_25a[_258]=_25b;
}
},renderPage:function(_25c){
var _25d=[];
var i,j;
for(i=0;i<this.colCount;i++){
_25d[i]=this.pageNodes[i][_25c];
}
for(i=0,j=_25c*this.rowsPerPage;(i<this.rowsPerPage)&&(j<this.rowCount);i++,j++){
this.renderRow(j,_25d);
}
},removePage:function(_25e){
for(var i=0,j=_25e*this.rowsPerPage;i<this.rowsPerPage;i++,j++){
this.removeRow(j);
}
},destroyPage:function(_25f){
for(var i=0;i<this.colCount;i++){
var n=this.invalidatePageNode(_25f,this.pageNodes[i]);
if(n){
dojo.destroy(n);
}
}
},pacify:function(_260){
},pacifying:false,pacifyTicks:200,setPacifying:function(_261){
if(this.pacifying!=_261){
this.pacifying=_261;
this.pacify(this.pacifying);
}
},startPacify:function(){
this.startPacifyTicks=new Date().getTime();
},doPacify:function(){
var _262=(new Date().getTime()-this.startPacifyTicks)>this.pacifyTicks;
this.setPacifying(true);
this.startPacify();
return _262;
},endPacify:function(){
this.setPacifying(false);
},resize:function(){
if(this.scrollboxNode){
this.windowHeight=this.scrollboxNode.clientHeight;
}
for(var i=0;i<this.colCount;i++){
dojox.grid.util.setStyleHeightPx(this.contentNodes[i],Math.max(1,this.height));
}
var _263=(!this._invalidating);
if(!_263){
var ah=this.grid.get("autoHeight");
if(typeof ah=="number"&&ah<=Math.min(this.rowsPerPage,this.rowCount)){
_263=true;
}
}
if(_263){
this.needPage(this.page,this.pageTop);
}
var _264=(this.page<this.pageCount-1)?this.rowsPerPage:((this.rowCount%this.rowsPerPage)||this.rowsPerPage);
var _265=this.getPageHeight(this.page);
this.averageRowHeight=(_265>0&&_264>0)?(_265/_264):0;
},calcLastPageHeight:function(){
if(!this.pageCount){
return 0;
}
var _266=this.pageCount-1;
var _267=((this.rowCount%this.rowsPerPage)||(this.rowsPerPage))*this.defaultRowHeight;
this.pageHeights[_266]=_267;
return _267;
},updateContentHeight:function(inDh){
this.height+=inDh;
this.resize();
},updatePageHeight:function(_268,_269,_26a){
if(this.pageExists(_268)){
var oh=this.getPageHeight(_268);
var h=(this.measurePage(_268));
if(h===undefined){
h=oh;
}
this.pageHeights[_268]=h;
if(oh!=h){
this.updateContentHeight(h-oh);
var ah=this.grid.get("autoHeight");
if((typeof ah=="number"&&ah>this.rowCount)||(ah===true&&!_269)){
if(!_26a){
this.grid.sizeChange();
}else{
var ns=this.grid.viewsNode.style;
ns.height=parseInt(ns.height)+h-oh+"px";
this.repositionPages(_268);
}
}else{
this.repositionPages(_268);
}
}
return h;
}
return 0;
},rowHeightChanged:function(_26b,_26c){
this.updatePageHeight(Math.floor(_26b/this.rowsPerPage),false,_26c);
},invalidateNodes:function(){
while(this.stack.length){
this.destroyPage(this.popPage());
}
},createPageNode:function(){
var p=document.createElement("div");
dojo.attr(p,"role","presentation");
p.style.position="absolute";
p.style[dojo._isBodyLtr()?"left":"right"]="0";
return p;
},getPageHeight:function(_26d){
var ph=this.pageHeights[_26d];
return (ph!==undefined?ph:this.defaultPageHeight);
},pushPage:function(_26e){
return this.stack.push(_26e);
},popPage:function(){
return this.stack.shift();
},findPage:function(_26f){
var i=0,h=0;
for(var ph=0;i<this.pageCount;i++,h+=ph){
ph=this.getPageHeight(i);
if(h+ph>=_26f){
break;
}
}
this.page=i;
this.pageTop=h;
},buildPage:function(_270,_271,_272){
this.preparePage(_270,_271);
this.positionPage(_270,_272);
this.installPage(_270);
this.renderPage(_270);
this.pushPage(_270);
},needPage:function(_273,_274){
var h=this.getPageHeight(_273),oh=h;
if(!this.pageExists(_273)){
this.buildPage(_273,(!this.grid._autoHeight&&this.keepPages&&(this.stack.length>=this.keepPages)),_274);
h=this.updatePageHeight(_273,true);
}else{
this.positionPage(_273,_274);
}
return h;
},onscroll:function(){
this.scroll(this.scrollboxNode.scrollTop);
},scroll:function(_275){
this.grid.scrollTop=_275;
if(this.colCount){
this.startPacify();
this.findPage(_275);
var h=this.height;
var b=this.getScrollBottom(_275);
for(var p=this.page,y=this.pageTop;(p<this.pageCount)&&((b<0)||(y<b));p++){
y+=this.needPage(p,y);
}
this.firstVisibleRow=this.getFirstVisibleRow(this.page,this.pageTop,_275);
this.lastVisibleRow=this.getLastVisibleRow(p-1,y,b);
if(h!=this.height){
this.repositionPages(p-1);
}
this.endPacify();
}
},getScrollBottom:function(_276){
return (this.windowHeight>=0?_276+this.windowHeight:-1);
},processNodeEvent:function(e,_277){
var t=e.target;
while(t&&(t!=_277)&&t.parentNode&&(t.parentNode.parentNode!=_277)){
t=t.parentNode;
}
if(!t||!t.parentNode||(t.parentNode.parentNode!=_277)){
return false;
}
var page=t.parentNode;
e.topRowIndex=page.pageIndex*this.rowsPerPage;
e.rowIndex=e.topRowIndex+_239(t);
e.rowTarget=t;
return true;
},processEvent:function(e){
return this.processNodeEvent(e,this.contentNode);
},renderRow:function(_278,_279){
},removeRow:function(_27a){
},getDefaultPageNode:function(_27b){
return this.getDefaultNodes()[_27b];
},positionPageNode:function(_27c,_27d){
},getPageNodePosition:function(_27e){
return _27e.offsetTop;
},invalidatePageNode:function(_27f,_280){
var p=_280[_27f];
if(p){
delete _280[_27f];
this.removePage(_27f,p);
_23b(p);
p.innerHTML="";
}
return p;
},getPageRow:function(_281){
return _281*this.rowsPerPage;
},getLastPageRow:function(_282){
return Math.min(this.rowCount,this.getPageRow(_282+1))-1;
},getFirstVisibleRow:function(_283,_284,_285){
if(!this.pageExists(_283)){
return 0;
}
var row=this.getPageRow(_283);
var _286=this.getDefaultNodes();
var rows=_244(_286[_283]);
for(var i=0,l=rows.length;i<l&&_284<_285;i++,row++){
_284+=rows[i].offsetHeight;
}
return (row?row-1:row);
},getLastVisibleRow:function(_287,_288,_289){
if(!this.pageExists(_287)){
return 0;
}
var _28a=this.getDefaultNodes();
var row=this.getLastPageRow(_287);
var rows=_244(_28a[_287]);
for(var i=rows.length-1;i>=0&&_288>_289;i--,row--){
_288-=rows[i].offsetHeight;
}
return row+1;
},findTopRow:function(_28b){
var _28c=this.getDefaultNodes();
var rows=_244(_28c[this.page]);
for(var i=0,l=rows.length,t=this.pageTop,h;i<l;i++){
h=rows[i].offsetHeight;
t+=h;
if(t>=_28b){
this.offset=h-(t-_28b);
return i+this.page*this.rowsPerPage;
}
}
return -1;
},findScrollTop:function(_28d){
var _28e=Math.floor(_28d/this.rowsPerPage);
var t=0;
var i,l;
for(i=0;i<_28e;i++){
t+=this.getPageHeight(i);
}
this.pageTop=t;
this.page=_28e;
this.needPage(_28e,this.pageTop);
var _28f=this.getDefaultNodes();
var rows=_244(_28f[_28e]);
var r=_28d-this.rowsPerPage*_28e;
for(i=0,l=rows.length;i<l&&i<r;i++){
t+=rows[i].offsetHeight;
}
return t;
},dummy:0});
})();
}
if(!dojo._hasResource["dojox.grid.cells._base"]){
dojo._hasResource["dojox.grid.cells._base"]=true;
dojo.provide("dojox.grid.cells._base");
dojo.declare("dojox.grid._DeferredTextWidget",dijit._Widget,{deferred:null,_destroyOnRemove:true,postCreate:function(){
if(this.deferred){
this.deferred.addBoth(dojo.hitch(this,function(text){
if(this.domNode){
this.domNode.innerHTML=text;
}
}));
}
}});
(function(){
var _290=function(_291){
try{
dojox.grid.util.fire(_291,"focus");
dojox.grid.util.fire(_291,"select");
}
catch(e){
}
};
var _292=function(){
setTimeout(dojo.hitch.apply(dojo,arguments),0);
};
var dgc=dojox.grid.cells;
dojo.declare("dojox.grid.cells._Base",null,{styles:"",classes:"",editable:false,alwaysEditing:false,formatter:null,defaultValue:"...",value:null,hidden:false,noresize:false,draggable:true,_valueProp:"value",_formatPending:false,constructor:function(_293){
this._props=_293||{};
dojo.mixin(this,_293);
if(this.draggable===undefined){
this.draggable=true;
}
},_defaultFormat:function(_294,_295){
var s=this.grid.formatterScope||this;
var f=this.formatter;
if(f&&s&&typeof f=="string"){
f=this.formatter=s[f];
}
var v=(_294!=this.defaultValue&&f)?f.apply(s,_295):_294;
if(typeof v=="undefined"){
return this.defaultValue;
}
if(v&&v.addBoth){
v=new dojox.grid._DeferredTextWidget({deferred:v},dojo.create("span",{innerHTML:this.defaultValue}));
}
if(v&&v.declaredClass&&v.startup){
return "<div class='dojoxGridStubNode' linkWidget='"+v.id+"' cellIdx='"+this.index+"'>"+this.defaultValue+"</div>";
}
return v;
},format:function(_296,_297){
var f,i=this.grid.edit.info,d=this.get?this.get(_296,_297):(this.value||this.defaultValue);
d=(d&&d.replace&&this.grid.escapeHTMLInData)?d.replace(/&/g,"&amp;").replace(/</g,"&lt;"):d;
if(this.editable&&(this.alwaysEditing||(i.rowIndex==_296&&i.cell==this))){
return this.formatEditing(d,_296);
}else{
return this._defaultFormat(d,[d,_296,this]);
}
},formatEditing:function(_298,_299){
},getNode:function(_29a){
return this.view.getCellNode(_29a,this.index);
},getHeaderNode:function(){
return this.view.getHeaderCellNode(this.index);
},getEditNode:function(_29b){
return (this.getNode(_29b)||0).firstChild||0;
},canResize:function(){
var uw=this.unitWidth;
return uw&&(uw!=="auto");
},isFlex:function(){
var uw=this.unitWidth;
return uw&&dojo.isString(uw)&&(uw=="auto"||uw.slice(-1)=="%");
},applyEdit:function(_29c,_29d){
this.grid.edit.applyCellEdit(_29c,this,_29d);
},cancelEdit:function(_29e){
this.grid.doCancelEdit(_29e);
},_onEditBlur:function(_29f){
if(this.grid.edit.isEditCell(_29f,this.index)){
this.grid.edit.apply();
}
},registerOnBlur:function(_2a0,_2a1){
if(this.commitOnBlur){
dojo.connect(_2a0,"onblur",function(e){
setTimeout(dojo.hitch(this,"_onEditBlur",_2a1),250);
});
}
},needFormatNode:function(_2a2,_2a3){
this._formatPending=true;
_292(this,"_formatNode",_2a2,_2a3);
},cancelFormatNode:function(){
this._formatPending=false;
},_formatNode:function(_2a4,_2a5){
if(this._formatPending){
this._formatPending=false;
if(!dojo.isIE){
dojo.setSelectable(this.grid.domNode,true);
}
this.formatNode(this.getEditNode(_2a5),_2a4,_2a5);
}
},formatNode:function(_2a6,_2a7,_2a8){
if(dojo.isIE){
_292(this,"focus",_2a8,_2a6);
}else{
this.focus(_2a8,_2a6);
}
},dispatchEvent:function(m,e){
if(m in this){
return this[m](e);
}
},getValue:function(_2a9){
return this.getEditNode(_2a9)[this._valueProp];
},setValue:function(_2aa,_2ab){
var n=this.getEditNode(_2aa);
if(n){
n[this._valueProp]=_2ab;
}
},focus:function(_2ac,_2ad){
_290(_2ad||this.getEditNode(_2ac));
},save:function(_2ae){
this.value=this.value||this.getValue(_2ae);
},restore:function(_2af){
this.setValue(_2af,this.value);
},_finish:function(_2b0){
dojo.setSelectable(this.grid.domNode,false);
this.cancelFormatNode();
},apply:function(_2b1){
this.applyEdit(this.getValue(_2b1),_2b1);
this._finish(_2b1);
},cancel:function(_2b2){
this.cancelEdit(_2b2);
this._finish(_2b2);
}});
dgc._Base.markupFactory=function(node,_2b3){
var d=dojo;
var _2b4=d.trim(d.attr(node,"formatter")||"");
if(_2b4){
_2b3.formatter=dojo.getObject(_2b4)||_2b4;
}
var get=d.trim(d.attr(node,"get")||"");
if(get){
_2b3.get=dojo.getObject(get);
}
var _2b5=function(attr,cell,_2b6){
var _2b7=d.trim(d.attr(node,attr)||"");
if(_2b7){
cell[_2b6||attr]=!(_2b7.toLowerCase()=="false");
}
};
_2b5("sortDesc",_2b3);
_2b5("editable",_2b3);
_2b5("alwaysEditing",_2b3);
_2b5("noresize",_2b3);
_2b5("draggable",_2b3);
var _2b8=d.trim(d.attr(node,"loadingText")||d.attr(node,"defaultValue")||"");
if(_2b8){
_2b3.defaultValue=_2b8;
}
var _2b9=function(attr,cell,_2ba){
var _2bb=d.trim(d.attr(node,attr)||"")||undefined;
if(_2bb){
cell[_2ba||attr]=_2bb;
}
};
_2b9("styles",_2b3);
_2b9("headerStyles",_2b3);
_2b9("cellStyles",_2b3);
_2b9("classes",_2b3);
_2b9("headerClasses",_2b3);
_2b9("cellClasses",_2b3);
};
dojo.declare("dojox.grid.cells.Cell",dgc._Base,{constructor:function(){
this.keyFilter=this.keyFilter;
},keyFilter:null,formatEditing:function(_2bc,_2bd){
this.needFormatNode(_2bc,_2bd);
return "<input class=\"dojoxGridInput\" type=\"text\" value=\""+_2bc+"\">";
},formatNode:function(_2be,_2bf,_2c0){
this.inherited(arguments);
this.registerOnBlur(_2be,_2c0);
},doKey:function(e){
if(this.keyFilter){
var key=String.fromCharCode(e.charCode);
if(key.search(this.keyFilter)==-1){
dojo.stopEvent(e);
}
}
},_finish:function(_2c1){
this.inherited(arguments);
var n=this.getEditNode(_2c1);
try{
dojox.grid.util.fire(n,"blur");
}
catch(e){
}
}});
dgc.Cell.markupFactory=function(node,_2c2){
dgc._Base.markupFactory(node,_2c2);
var d=dojo;
var _2c3=d.trim(d.attr(node,"keyFilter")||"");
if(_2c3){
_2c2.keyFilter=new RegExp(_2c3);
}
};
dojo.declare("dojox.grid.cells.RowIndex",dgc.Cell,{name:"Row",postscript:function(){
this.editable=false;
},get:function(_2c4){
return _2c4+1;
}});
dgc.RowIndex.markupFactory=function(node,_2c5){
dgc.Cell.markupFactory(node,_2c5);
};
dojo.declare("dojox.grid.cells.Select",dgc.Cell,{options:null,values:null,returnIndex:-1,constructor:function(_2c6){
this.values=this.values||this.options;
},formatEditing:function(_2c7,_2c8){
this.needFormatNode(_2c7,_2c8);
var h=["<select class=\"dojoxGridSelect\">"];
for(var i=0,o,v;((o=this.options[i])!==undefined)&&((v=this.values[i])!==undefined);i++){
h.push("<option",(_2c7==v?" selected":"")," value=\""+v+"\"",">",o,"</option>");
}
h.push("</select>");
return h.join("");
},getValue:function(_2c9){
var n=this.getEditNode(_2c9);
if(n){
var i=n.selectedIndex,o=n.options[i];
return this.returnIndex>-1?i:o.value||o.innerHTML;
}
}});
dgc.Select.markupFactory=function(node,cell){
dgc.Cell.markupFactory(node,cell);
var d=dojo;
var _2ca=d.trim(d.attr(node,"options")||"");
if(_2ca){
var o=_2ca.split(",");
if(o[0]!=_2ca){
cell.options=o;
}
}
var _2cb=d.trim(d.attr(node,"values")||"");
if(_2cb){
var v=_2cb.split(",");
if(v[0]!=_2cb){
cell.values=v;
}
}
};
dojo.declare("dojox.grid.cells.AlwaysEdit",dgc.Cell,{alwaysEditing:true,_formatNode:function(_2cc,_2cd){
this.formatNode(this.getEditNode(_2cd),_2cc,_2cd);
},applyStaticValue:function(_2ce){
var e=this.grid.edit;
e.applyCellEdit(this.getValue(_2ce),this,_2ce);
e.start(this,_2ce,true);
}});
dgc.AlwaysEdit.markupFactory=function(node,cell){
dgc.Cell.markupFactory(node,cell);
};
dojo.declare("dojox.grid.cells.Bool",dgc.AlwaysEdit,{_valueProp:"checked",formatEditing:function(_2cf,_2d0){
return "<input class=\"dojoxGridInput\" type=\"checkbox\""+(_2cf?" checked=\"checked\"":"")+" style=\"width: auto\" />";
},doclick:function(e){
if(e.target.tagName=="INPUT"){
this.applyStaticValue(e.rowIndex);
}
}});
dgc.Bool.markupFactory=function(node,cell){
dgc.AlwaysEdit.markupFactory(node,cell);
};
})();
}
if(!dojo._hasResource["dojox.grid.cells"]){
dojo._hasResource["dojox.grid.cells"]=true;
dojo.provide("dojox.grid.cells");
}
if(!dojo._hasResource["dojo.dnd.common"]){
dojo._hasResource["dojo.dnd.common"]=true;
dojo.provide("dojo.dnd.common");
dojo.getObject("dnd",true,dojo);
dojo.dnd.getCopyKeyState=dojo.isCopyKey;
dojo.dnd._uniqueId=0;
dojo.dnd.getUniqueId=function(){
var id;
do{
id=dojo._scopeName+"Unique"+(++dojo.dnd._uniqueId);
}while(dojo.byId(id));
return id;
};
dojo.dnd._empty={};
dojo.dnd.isFormElement=function(e){
var t=e.target;
if(t.nodeType==3){
t=t.parentNode;
}
return " button textarea input select option ".indexOf(" "+t.tagName.toLowerCase()+" ")>=0;
};
}
if(!dojo._hasResource["dojo.dnd.autoscroll"]){
dojo._hasResource["dojo.dnd.autoscroll"]=true;
dojo.provide("dojo.dnd.autoscroll");
dojo.getObject("dnd",true,dojo);
dojo.dnd.getViewport=dojo.window.getBox;
dojo.dnd.V_TRIGGER_AUTOSCROLL=32;
dojo.dnd.H_TRIGGER_AUTOSCROLL=32;
dojo.dnd.V_AUTOSCROLL_VALUE=16;
dojo.dnd.H_AUTOSCROLL_VALUE=16;
dojo.dnd.autoScroll=function(e){
var v=dojo.window.getBox(),dx=0,dy=0;
if(e.clientX<dojo.dnd.H_TRIGGER_AUTOSCROLL){
dx=-dojo.dnd.H_AUTOSCROLL_VALUE;
}else{
if(e.clientX>v.w-dojo.dnd.H_TRIGGER_AUTOSCROLL){
dx=dojo.dnd.H_AUTOSCROLL_VALUE;
}
}
if(e.clientY<dojo.dnd.V_TRIGGER_AUTOSCROLL){
dy=-dojo.dnd.V_AUTOSCROLL_VALUE;
}else{
if(e.clientY>v.h-dojo.dnd.V_TRIGGER_AUTOSCROLL){
dy=dojo.dnd.V_AUTOSCROLL_VALUE;
}
}
window.scrollBy(dx,dy);
};
dojo.dnd._validNodes={"div":1,"p":1,"td":1};
dojo.dnd._validOverflow={"auto":1,"scroll":1};
dojo.dnd.autoScrollNodes=function(e){
for(var n=e.target;n;){
if(n.nodeType==1&&(n.tagName.toLowerCase() in dojo.dnd._validNodes)){
var s=dojo.getComputedStyle(n);
if(s.overflow.toLowerCase() in dojo.dnd._validOverflow){
var b=dojo._getContentBox(n,s),t=dojo.position(n,true);
var w=Math.min(dojo.dnd.H_TRIGGER_AUTOSCROLL,b.w/2),h=Math.min(dojo.dnd.V_TRIGGER_AUTOSCROLL,b.h/2),rx=e.pageX-t.x,ry=e.pageY-t.y,dx=0,dy=0;
if(dojo.isWebKit||dojo.isOpera){
rx+=dojo.body().scrollLeft;
ry+=dojo.body().scrollTop;
}
if(rx>0&&rx<b.w){
if(rx<w){
dx=-w;
}else{
if(rx>b.w-w){
dx=w;
}
}
}
if(ry>0&&ry<b.h){
if(ry<h){
dy=-h;
}else{
if(ry>b.h-h){
dy=h;
}
}
}
var _2d1=n.scrollLeft,_2d2=n.scrollTop;
n.scrollLeft=n.scrollLeft+dx;
n.scrollTop=n.scrollTop+dy;
if(_2d1!=n.scrollLeft||_2d2!=n.scrollTop){
return;
}
}
}
try{
n=n.parentNode;
}
catch(x){
n=null;
}
}
dojo.dnd.autoScroll(e);
};
}
if(!dojo._hasResource["dojo.dnd.Mover"]){
dojo._hasResource["dojo.dnd.Mover"]=true;
dojo.provide("dojo.dnd.Mover");
dojo.declare("dojo.dnd.Mover",null,{constructor:function(node,e,host){
this.node=dojo.byId(node);
var pos=e.touches?e.touches[0]:e;
this.marginBox={l:pos.pageX,t:pos.pageY};
this.mouseButton=e.button;
var h=(this.host=host),d=node.ownerDocument;
this.events=[dojo.connect(d,"onmousemove",this,"onFirstMove"),dojo.connect(d,"ontouchmove",this,"onFirstMove"),dojo.connect(d,"onmousemove",this,"onMouseMove"),dojo.connect(d,"ontouchmove",this,"onMouseMove"),dojo.connect(d,"onmouseup",this,"onMouseUp"),dojo.connect(d,"ontouchend",this,"onMouseUp"),dojo.connect(d,"ondragstart",dojo.stopEvent),dojo.connect(d.body,"onselectstart",dojo.stopEvent)];
if(h&&h.onMoveStart){
h.onMoveStart(this);
}
},onMouseMove:function(e){
dojo.dnd.autoScroll(e);
var m=this.marginBox,pos=e.touches?e.touches[0]:e;
this.host.onMove(this,{l:m.l+pos.pageX,t:m.t+pos.pageY},e);
dojo.stopEvent(e);
},onMouseUp:function(e){
if(dojo.isWebKit&&dojo.isMac&&this.mouseButton==2?e.button==0:this.mouseButton==e.button){
this.destroy();
}
dojo.stopEvent(e);
},onFirstMove:function(e){
var s=this.node.style,l,t,h=this.host;
switch(s.position){
case "relative":
case "absolute":
l=Math.round(parseFloat(s.left))||0;
t=Math.round(parseFloat(s.top))||0;
break;
default:
s.position="absolute";
var m=dojo.marginBox(this.node);
var b=dojo.doc.body;
var bs=dojo.getComputedStyle(b);
var bm=dojo._getMarginBox(b,bs);
var bc=dojo._getContentBox(b,bs);
l=m.l-(bc.l-bm.l);
t=m.t-(bc.t-bm.t);
break;
}
this.marginBox.l=l-this.marginBox.l;
this.marginBox.t=t-this.marginBox.t;
if(h&&h.onFirstMove){
h.onFirstMove(this,e);
}
dojo.disconnect(this.events.shift());
dojo.disconnect(this.events.shift());
},destroy:function(){
dojo.forEach(this.events,dojo.disconnect);
var h=this.host;
if(h&&h.onMoveStop){
h.onMoveStop(this);
}
this.events=this.node=this.host=null;
}});
}
if(!dojo._hasResource["dojo.dnd.Moveable"]){
dojo._hasResource["dojo.dnd.Moveable"]=true;
dojo.provide("dojo.dnd.Moveable");
dojo.declare("dojo.dnd.Moveable",null,{handle:"",delay:0,skip:false,constructor:function(node,_2d3){
this.node=dojo.byId(node);
if(!_2d3){
_2d3={};
}
this.handle=_2d3.handle?dojo.byId(_2d3.handle):null;
if(!this.handle){
this.handle=this.node;
}
this.delay=_2d3.delay>0?_2d3.delay:0;
this.skip=_2d3.skip;
this.mover=_2d3.mover?_2d3.mover:dojo.dnd.Mover;
this.events=[dojo.connect(this.handle,"onmousedown",this,"onMouseDown"),dojo.connect(this.handle,"ontouchstart",this,"onMouseDown"),dojo.connect(this.handle,"ondragstart",this,"onSelectStart"),dojo.connect(this.handle,"onselectstart",this,"onSelectStart")];
},markupFactory:function(_2d4,node){
return new dojo.dnd.Moveable(node,_2d4);
},destroy:function(){
dojo.forEach(this.events,dojo.disconnect);
this.events=this.node=this.handle=null;
},onMouseDown:function(e){
if(this.skip&&dojo.dnd.isFormElement(e)){
return;
}
if(this.delay){
this.events.push(dojo.connect(this.handle,"onmousemove",this,"onMouseMove"),dojo.connect(this.handle,"ontouchmove",this,"onMouseMove"),dojo.connect(this.handle,"onmouseup",this,"onMouseUp"),dojo.connect(this.handle,"ontouchend",this,"onMouseUp"));
var pos=e.touches?e.touches[0]:e;
this._lastX=pos.pageX;
this._lastY=pos.pageY;
}else{
this.onDragDetected(e);
}
dojo.stopEvent(e);
},onMouseMove:function(e){
var pos=e.touches?e.touches[0]:e;
if(Math.abs(pos.pageX-this._lastX)>this.delay||Math.abs(pos.pageY-this._lastY)>this.delay){
this.onMouseUp(e);
this.onDragDetected(e);
}
dojo.stopEvent(e);
},onMouseUp:function(e){
for(var i=0;i<2;++i){
dojo.disconnect(this.events.pop());
}
dojo.stopEvent(e);
},onSelectStart:function(e){
if(!this.skip||!dojo.dnd.isFormElement(e)){
dojo.stopEvent(e);
}
},onDragDetected:function(e){
new this.mover(this.node,e,this);
},onMoveStart:function(_2d5){
dojo.publish("/dnd/move/start",[_2d5]);
dojo.addClass(dojo.body(),"dojoMove");
dojo.addClass(this.node,"dojoMoveItem");
},onMoveStop:function(_2d6){
dojo.publish("/dnd/move/stop",[_2d6]);
dojo.removeClass(dojo.body(),"dojoMove");
dojo.removeClass(this.node,"dojoMoveItem");
},onFirstMove:function(_2d7,e){
},onMove:function(_2d8,_2d9,e){
this.onMoving(_2d8,_2d9);
var s=_2d8.node.style;
s.left=_2d9.l+"px";
s.top=_2d9.t+"px";
this.onMoved(_2d8,_2d9);
},onMoving:function(_2da,_2db){
},onMoved:function(_2dc,_2dd){
}});
}
if(!dojo._hasResource["dojox.grid._Builder"]){
dojo._hasResource["dojox.grid._Builder"]=true;
dojo.provide("dojox.grid._Builder");
(function(){
var dg=dojox.grid;
var _2de=function(td){
return td.cellIndex>=0?td.cellIndex:dojo.indexOf(td.parentNode.cells,td);
};
var _2df=function(tr){
return tr.rowIndex>=0?tr.rowIndex:dojo.indexOf(tr.parentNode.childNodes,tr);
};
var _2e0=function(_2e1,_2e2){
return _2e1&&((_2e1.rows||0)[_2e2]||_2e1.childNodes[_2e2]);
};
var _2e3=function(node){
for(var n=node;n&&n.tagName!="TABLE";n=n.parentNode){
}
return n;
};
var _2e4=function(_2e5,_2e6){
for(var n=_2e5;n&&_2e6(n);n=n.parentNode){
}
return n;
};
var _2e7=function(_2e8){
var name=_2e8.toUpperCase();
return function(node){
return node.tagName!=name;
};
};
var _2e9=dojox.grid.util.rowIndexTag;
var _2ea=dojox.grid.util.gridViewTag;
dg._Builder=dojo.extend(function(view){
if(view){
this.view=view;
this.grid=view.grid;
}
},{view:null,_table:"<table class=\"dojoxGridRowTable\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" role=\"presentation\"",getTableArray:function(){
var html=[this._table];
if(this.view.viewWidth){
html.push([" style=\"width:",this.view.viewWidth,";\""].join(""));
}
html.push(">");
return html;
},generateCellMarkup:function(_2eb,_2ec,_2ed,_2ee){
var _2ef=[],html;
if(_2ee){
var _2f0=_2eb.index!=_2eb.grid.getSortIndex()?"":_2eb.grid.sortInfo>0?"aria-sort=\"ascending\"":"aria-sort=\"descending\"";
if(!_2eb.id){
_2eb.id=this.grid.id+"Hdr"+_2eb.index;
}
html=["<th tabIndex=\"-1\" aria-readonly=\"true\" role=\"columnheader\"",_2f0,"id=\"",_2eb.id,"\""];
}else{
var _2f1=this.grid.editable&&!_2eb.editable?"aria-readonly=\"true\"":"";
html=["<td tabIndex=\"-1\" role=\"gridcell\" ",_2f1," aria-describedby=\"",this.grid.id,"Hdr",_2eb.index,"\""];
}
if(_2eb.colSpan){
html.push(" colspan=\"",_2eb.colSpan,"\"");
}
if(_2eb.rowSpan){
html.push(" rowspan=\"",_2eb.rowSpan,"\"");
}
html.push(" class=\"dojoxGridCell ");
if(_2eb.classes){
html.push(_2eb.classes," ");
}
if(_2ed){
html.push(_2ed," ");
}
_2ef.push(html.join(""));
_2ef.push("");
html=["\" idx=\"",_2eb.index,"\" style=\""];
if(_2ec&&_2ec[_2ec.length-1]!=";"){
_2ec+=";";
}
html.push(_2eb.styles,_2ec||"",_2eb.hidden?"display:none;":"");
if(_2eb.unitWidth){
html.push("width:",_2eb.unitWidth,";");
}
_2ef.push(html.join(""));
_2ef.push("");
html=["\""];
if(_2eb.attrs){
html.push(" ",_2eb.attrs);
}
html.push(">");
_2ef.push(html.join(""));
_2ef.push("");
_2ef.push(_2ee?"</th>":"</td>");
return _2ef;
},isCellNode:function(_2f2){
return Boolean(_2f2&&_2f2!=dojo.doc&&dojo.attr(_2f2,"idx"));
},getCellNodeIndex:function(_2f3){
return _2f3?Number(dojo.attr(_2f3,"idx")):-1;
},getCellNode:function(_2f4,_2f5){
for(var i=0,row;((row=_2e0(_2f4.firstChild,i))&&row.cells);i++){
for(var j=0,cell;(cell=row.cells[j]);j++){
if(this.getCellNodeIndex(cell)==_2f5){
return cell;
}
}
}
return null;
},findCellTarget:function(_2f6,_2f7){
var n=_2f6;
while(n&&(!this.isCellNode(n)||(n.offsetParent&&_2ea in n.offsetParent.parentNode&&n.offsetParent.parentNode[_2ea]!=this.view.id))&&(n!=_2f7)){
n=n.parentNode;
}
return n!=_2f7?n:null;
},baseDecorateEvent:function(e){
e.dispatch="do"+e.type;
e.grid=this.grid;
e.sourceView=this.view;
e.cellNode=this.findCellTarget(e.target,e.rowNode);
e.cellIndex=this.getCellNodeIndex(e.cellNode);
e.cell=(e.cellIndex>=0?this.grid.getCell(e.cellIndex):null);
},findTarget:function(_2f8,_2f9){
var n=_2f8;
while(n&&(n!=this.domNode)&&(!(_2f9 in n)||(_2ea in n&&n[_2ea]!=this.view.id))){
n=n.parentNode;
}
return (n!=this.domNode)?n:null;
},findRowTarget:function(_2fa){
return this.findTarget(_2fa,_2e9);
},isIntraNodeEvent:function(e){
try{
return (e.cellNode&&e.relatedTarget&&dojo.isDescendant(e.relatedTarget,e.cellNode));
}
catch(x){
return false;
}
},isIntraRowEvent:function(e){
try{
var row=e.relatedTarget&&this.findRowTarget(e.relatedTarget);
return !row&&(e.rowIndex==-1)||row&&(e.rowIndex==row.gridRowIndex);
}
catch(x){
return false;
}
},dispatchEvent:function(e){
if(e.dispatch in this){
return this[e.dispatch](e);
}
return false;
},domouseover:function(e){
if(e.cellNode&&(e.cellNode!=this.lastOverCellNode)){
this.lastOverCellNode=e.cellNode;
this.grid.onMouseOver(e);
}
this.grid.onMouseOverRow(e);
},domouseout:function(e){
if(e.cellNode&&(e.cellNode==this.lastOverCellNode)&&!this.isIntraNodeEvent(e,this.lastOverCellNode)){
this.lastOverCellNode=null;
this.grid.onMouseOut(e);
if(!this.isIntraRowEvent(e)){
this.grid.onMouseOutRow(e);
}
}
},domousedown:function(e){
if(e.cellNode){
this.grid.onMouseDown(e);
}
this.grid.onMouseDownRow(e);
}});
dg._ContentBuilder=dojo.extend(function(view){
dg._Builder.call(this,view);
},dg._Builder.prototype,{update:function(){
this.prepareHtml();
},prepareHtml:function(){
var _2fb=this.grid.get,_2fc=this.view.structure.cells;
for(var j=0,row;(row=_2fc[j]);j++){
for(var i=0,cell;(cell=row[i]);i++){
cell.get=cell.get||(cell.value==undefined)&&_2fb;
cell.markup=this.generateCellMarkup(cell,cell.cellStyles,cell.cellClasses,false);
if(!this.grid.editable&&cell.editable){
this.grid.editable=true;
}
}
}
},generateHtml:function(_2fd,_2fe){
var html=this.getTableArray(),v=this.view,_2ff=v.structure.cells,item=this.grid.getItem(_2fe);
dojox.grid.util.fire(this.view,"onBeforeRow",[_2fe,_2ff]);
for(var j=0,row;(row=_2ff[j]);j++){
if(row.hidden||row.header){
continue;
}
html.push(!row.invisible?"<tr>":"<tr class=\"dojoxGridInvisible\">");
for(var i=0,cell,m,cc,cs;(cell=row[i]);i++){
m=cell.markup;
cc=cell.customClasses=[];
cs=cell.customStyles=[];
m[5]=cell.format(_2fe,item);
m[5]=dojox.grid.util.fixIEEmptyCell(m[5]);
m[1]=cc.join(" ");
m[3]=cs.join(";");
html.push.apply(html,m);
}
html.push("</tr>");
}
html.push("</table>");
return html.join("");
},decorateEvent:function(e,_300){
e.rowNode=_300||this.findRowTarget(e.target);
if(!e.rowNode){
return false;
}
e.rowIndex=e.rowNode[_2e9];
this.baseDecorateEvent(e);
e.cell=this.grid.getCell(e.cellIndex);
return true;
}});
dg._HeaderBuilder=dojo.extend(function(view){
this.moveable=null;
dg._Builder.call(this,view);
},dg._Builder.prototype,{_skipBogusClicks:false,overResizeWidth:4,minColWidth:1,update:function(){
if(this.tableMap){
this.tableMap.mapRows(this.view.structure.cells);
}else{
this.tableMap=new dg._TableMap(this.view.structure.cells);
}
},generateHtml:function(_301,_302){
var html=this.getTableArray(),_303=this.view.structure.cells;
dojox.grid.util.fire(this.view,"onBeforeRow",[-1,_303]);
for(var j=0,row;(row=_303[j]);j++){
if(row.hidden){
continue;
}
html.push(!row.invisible?"<tr>":"<tr class=\"dojoxGridInvisible\">");
for(var i=0,cell,_304;(cell=row[i]);i++){
cell.customClasses=[];
cell.customStyles=[];
if(this.view.simpleStructure){
if(cell.draggable){
if(cell.headerClasses){
if(cell.headerClasses.indexOf("dojoDndItem")==-1){
cell.headerClasses+=" dojoDndItem";
}
}else{
cell.headerClasses="dojoDndItem";
}
}
if(cell.attrs){
if(cell.attrs.indexOf("dndType='gridColumn_")==-1){
cell.attrs+=" dndType='gridColumn_"+this.grid.id+"'";
}
}else{
cell.attrs="dndType='gridColumn_"+this.grid.id+"'";
}
}
_304=this.generateCellMarkup(cell,cell.headerStyles,cell.headerClasses,true);
_304[5]=(_302!=undefined?_302:_301(cell));
_304[3]=cell.customStyles.join(";");
_304[1]=cell.customClasses.join(" ");
html.push(_304.join(""));
}
html.push("</tr>");
}
html.push("</table>");
return html.join("");
},getCellX:function(e){
var n,x=e.layerX;
if(dojo.isMoz||dojo.isIE>=9){
n=_2e4(e.target,_2e7("th"));
x-=(n&&n.offsetLeft)||0;
var t=e.sourceView.getScrollbarWidth();
if(!dojo._isBodyLtr()){
table=_2e4(n,_2e7("table"));
x-=(table&&table.offsetLeft)||0;
}
}
n=_2e4(e.target,function(){
if(!n||n==e.cellNode){
return false;
}
x+=(n.offsetLeft<0?0:n.offsetLeft);
return true;
});
return x;
},decorateEvent:function(e){
this.baseDecorateEvent(e);
e.rowIndex=-1;
e.cellX=this.getCellX(e);
return true;
},prepareResize:function(e,mod){
do{
var i=e.cellIndex;
e.cellNode=(i?e.cellNode.parentNode.cells[i+mod]:null);
e.cellIndex=(e.cellNode?this.getCellNodeIndex(e.cellNode):-1);
}while(e.cellNode&&e.cellNode.style.display=="none");
return Boolean(e.cellNode);
},canResize:function(e){
if(!e.cellNode||e.cellNode.colSpan>1){
return false;
}
var cell=this.grid.getCell(e.cellIndex);
return !cell.noresize&&cell.canResize();
},overLeftResizeArea:function(e){
if(dojo.hasClass(dojo.body(),"dojoDndMove")){
return false;
}
if(dojo.isIE){
var tN=e.target;
if(dojo.hasClass(tN,"dojoxGridArrowButtonNode")||dojo.hasClass(tN,"dojoxGridArrowButtonChar")){
return false;
}
}
if(dojo._isBodyLtr()){
return (e.cellIndex>0)&&(e.cellX>0&&e.cellX<this.overResizeWidth)&&this.prepareResize(e,-1);
}
var t=e.cellNode&&(e.cellX>0&&e.cellX<this.overResizeWidth);
return t;
},overRightResizeArea:function(e){
if(dojo.hasClass(dojo.body(),"dojoDndMove")){
return false;
}
if(dojo.isIE){
var tN=e.target;
if(dojo.hasClass(tN,"dojoxGridArrowButtonNode")||dojo.hasClass(tN,"dojoxGridArrowButtonChar")){
return false;
}
}
if(dojo._isBodyLtr()){
return e.cellNode&&(e.cellX>=e.cellNode.offsetWidth-this.overResizeWidth);
}
return (e.cellIndex>0)&&(e.cellX>=e.cellNode.offsetWidth-this.overResizeWidth)&&this.prepareResize(e,-1);
},domousemove:function(e){
if(!this.moveable){
var c=(this.overRightResizeArea(e)?"dojoxGridColResize":(this.overLeftResizeArea(e)?"dojoxGridColResize":""));
if(c&&!this.canResize(e)){
c="dojoxGridColNoResize";
}
dojo.toggleClass(e.sourceView.headerNode,"dojoxGridColNoResize",(c=="dojoxGridColNoResize"));
dojo.toggleClass(e.sourceView.headerNode,"dojoxGridColResize",(c=="dojoxGridColResize"));
if(dojo.isIE){
var t=e.sourceView.headerNode.scrollLeft;
e.sourceView.headerNode.scrollLeft=t;
}
if(c){
dojo.stopEvent(e);
}
}
},domousedown:function(e){
if(!this.moveable){
if((this.overRightResizeArea(e)||this.overLeftResizeArea(e))&&this.canResize(e)){
this.beginColumnResize(e);
}else{
this.grid.onMouseDown(e);
this.grid.onMouseOverRow(e);
}
}
},doclick:function(e){
if(this._skipBogusClicks){
dojo.stopEvent(e);
return true;
}
return false;
},colResizeSetup:function(e,_305){
var _306=dojo.contentBox(e.sourceView.headerNode);
if(_305){
this.lineDiv=document.createElement("div");
var vw=(dojo.position||dojo._abs)(e.sourceView.headerNode,true);
var _307=dojo.contentBox(e.sourceView.domNode);
var l=e.pageX;
if(!dojo._isBodyLtr()&&dojo.isIE<8){
l-=dojox.html.metrics.getScrollbar().w;
}
dojo.style(this.lineDiv,{top:vw.y+"px",left:l+"px",height:(_307.h+_306.h)+"px"});
dojo.addClass(this.lineDiv,"dojoxGridResizeColLine");
this.lineDiv._origLeft=l;
dojo.body().appendChild(this.lineDiv);
}
var _308=[],_309=this.tableMap.findOverlappingNodes(e.cellNode);
for(var i=0,cell;(cell=_309[i]);i++){
_308.push({node:cell,index:this.getCellNodeIndex(cell),width:dojo.contentBox(cell).w});
}
var view=e.sourceView;
var adj=dojo._isBodyLtr()?1:-1;
var _30a=e.grid.views.views;
var _30b=[];
for(var j=view.idx+adj,_30c;(_30c=_30a[j]);j=j+adj){
_30b.push({node:_30c.headerNode,left:window.parseInt(_30c.headerNode.style.left)});
}
var _30d=view.headerContentNode.firstChild;
var drag={scrollLeft:e.sourceView.headerNode.scrollLeft,view:view,node:e.cellNode,index:e.cellIndex,w:dojo.contentBox(e.cellNode).w,vw:_306.w,table:_30d,tw:dojo.contentBox(_30d).w,spanners:_308,followers:_30b};
return drag;
},beginColumnResize:function(e){
this.moverDiv=document.createElement("div");
dojo.style(this.moverDiv,{position:"absolute",left:0});
dojo.body().appendChild(this.moverDiv);
dojo.addClass(this.grid.domNode,"dojoxGridColumnResizing");
var m=(this.moveable=new dojo.dnd.Moveable(this.moverDiv));
var drag=this.colResizeSetup(e,true);
m.onMove=dojo.hitch(this,"doResizeColumn",drag);
dojo.connect(m,"onMoveStop",dojo.hitch(this,function(){
this.endResizeColumn(drag);
if(drag.node.releaseCapture){
drag.node.releaseCapture();
}
this.moveable.destroy();
delete this.moveable;
this.moveable=null;
dojo.removeClass(this.grid.domNode,"dojoxGridColumnResizing");
}));
if(e.cellNode.setCapture){
e.cellNode.setCapture();
}
m.onMouseDown(e);
},doResizeColumn:function(_30e,_30f,_310){
var _311=_310.l;
var data={deltaX:_311,w:_30e.w+(dojo._isBodyLtr()?_311:-_311),vw:_30e.vw+_311,tw:_30e.tw+_311};
this.dragRecord={inDrag:_30e,mover:_30f,leftTop:_310};
if(data.w>=this.minColWidth){
if(!_30f){
this.doResizeNow(_30e,data);
}else{
dojo.style(this.lineDiv,"left",(this.lineDiv._origLeft+data.deltaX)+"px");
}
}
},endResizeColumn:function(_312){
if(this.dragRecord){
var _313=this.dragRecord.leftTop;
var _314=dojo._isBodyLtr()?_313.l:-_313.l;
_314+=Math.max(_312.w+_314,this.minColWidth)-(_312.w+_314);
if(dojo.isWebKit&&_312.spanners.length){
_314+=dojo._getPadBorderExtents(_312.spanners[0].node).w;
}
var data={deltaX:_314,w:_312.w+_314,vw:_312.vw+_314,tw:_312.tw+_314};
this.doResizeNow(_312,data);
delete this.dragRecord;
}
dojo.destroy(this.lineDiv);
dojo.destroy(this.moverDiv);
dojo.destroy(this.moverDiv);
delete this.moverDiv;
this._skipBogusClicks=true;
_312.view.update();
this._skipBogusClicks=false;
this.grid.onResizeColumn(_312.index);
},doResizeNow:function(_315,data){
_315.view.convertColPctToFixed();
if(_315.view.flexCells&&!_315.view.testFlexCells()){
var t=_2e3(_315.node);
if(t){
(t.style.width="");
}
}
var i,s,sw,f,fl;
for(i=0;(s=_315.spanners[i]);i++){
sw=s.width+data.deltaX;
if(sw>0){
s.node.style.width=sw+"px";
_315.view.setColWidth(s.index,sw);
}
}
if(dojo._isBodyLtr()||!dojo.isIE){
for(i=0;(f=_315.followers[i]);i++){
fl=f.left+data.deltaX;
f.node.style.left=fl+"px";
}
}
_315.node.style.width=data.w+"px";
_315.view.setColWidth(_315.index,data.w);
_315.view.headerNode.style.width=data.vw+"px";
_315.view.setColumnsWidth(data.tw);
if(!dojo._isBodyLtr()){
_315.view.headerNode.scrollLeft=_315.scrollLeft+data.deltaX;
}
}});
dg._TableMap=dojo.extend(function(rows){
this.mapRows(rows);
},{map:null,mapRows:function(_316){
var _317=_316.length;
if(!_317){
return;
}
this.map=[];
var row;
for(var k=0;(row=_316[k]);k++){
this.map[k]=[];
}
for(var j=0;(row=_316[j]);j++){
for(var i=0,x=0,cell,_318,_319;(cell=row[i]);i++){
while(this.map[j][x]){
x++;
}
this.map[j][x]={c:i,r:j};
_319=cell.rowSpan||1;
_318=cell.colSpan||1;
for(var y=0;y<_319;y++){
for(var s=0;s<_318;s++){
this.map[j+y][x+s]=this.map[j][x];
}
}
x+=_318;
}
}
},dumpMap:function(){
for(var j=0,row,h="";(row=this.map[j]);j++,h=""){
for(var i=0,cell;(cell=row[i]);i++){
h+=cell.r+","+cell.c+"   ";
}
}
},getMapCoords:function(_31a,_31b){
for(var j=0,row;(row=this.map[j]);j++){
for(var i=0,cell;(cell=row[i]);i++){
if(cell.c==_31b&&cell.r==_31a){
return {j:j,i:i};
}
}
}
return {j:-1,i:-1};
},getNode:function(_31c,_31d,_31e){
var row=_31c&&_31c.rows[_31d];
return row&&row.cells[_31e];
},_findOverlappingNodes:function(_31f,_320,_321){
var _322=[];
var m=this.getMapCoords(_320,_321);
for(var j=0,row;(row=this.map[j]);j++){
if(j==m.j){
continue;
}
var rw=row[m.i];
var n=(rw?this.getNode(_31f,rw.r,rw.c):null);
if(n){
_322.push(n);
}
}
return _322;
},findOverlappingNodes:function(_323){
return this._findOverlappingNodes(_2e3(_323),_2df(_323.parentNode),_2de(_323));
}});
})();
}
if(!dojo._hasResource["dojo.dnd.Container"]){
dojo._hasResource["dojo.dnd.Container"]=true;
dojo.provide("dojo.dnd.Container");
dojo.declare("dojo.dnd.Container",null,{skipForm:false,constructor:function(node,_324){
this.node=dojo.byId(node);
if(!_324){
_324={};
}
this.creator=_324.creator||null;
this.skipForm=_324.skipForm;
this.parent=_324.dropParent&&dojo.byId(_324.dropParent);
this.map={};
this.current=null;
this.containerState="";
dojo.addClass(this.node,"dojoDndContainer");
if(!(_324&&_324._skipStartup)){
this.startup();
}
this.events=[dojo.connect(this.node,"onmouseover",this,"onMouseOver"),dojo.connect(this.node,"onmouseout",this,"onMouseOut"),dojo.connect(this.node,"ondragstart",this,"onSelectStart"),dojo.connect(this.node,"onselectstart",this,"onSelectStart")];
},creator:function(){
},getItem:function(key){
return this.map[key];
},setItem:function(key,data){
this.map[key]=data;
},delItem:function(key){
delete this.map[key];
},forInItems:function(f,o){
o=o||dojo.global;
var m=this.map,e=dojo.dnd._empty;
for(var i in m){
if(i in e){
continue;
}
f.call(o,m[i],i,this);
}
return o;
},clearItems:function(){
this.map={};
},getAllNodes:function(){
return dojo.query("> .dojoDndItem",this.parent);
},sync:function(){
var map={};
this.getAllNodes().forEach(function(node){
if(node.id){
var item=this.getItem(node.id);
if(item){
map[node.id]=item;
return;
}
}else{
node.id=dojo.dnd.getUniqueId();
}
var type=node.getAttribute("dndType"),data=node.getAttribute("dndData");
map[node.id]={data:data||node.innerHTML,type:type?type.split(/\s*,\s*/):["text"]};
},this);
this.map=map;
return this;
},insertNodes:function(data,_325,_326){
if(!this.parent.firstChild){
_326=null;
}else{
if(_325){
if(!_326){
_326=this.parent.firstChild;
}
}else{
if(_326){
_326=_326.nextSibling;
}
}
}
if(_326){
for(var i=0;i<data.length;++i){
var t=this._normalizedCreator(data[i]);
this.setItem(t.node.id,{data:t.data,type:t.type});
this.parent.insertBefore(t.node,_326);
}
}else{
for(var i=0;i<data.length;++i){
var t=this._normalizedCreator(data[i]);
this.setItem(t.node.id,{data:t.data,type:t.type});
this.parent.appendChild(t.node);
}
}
return this;
},destroy:function(){
dojo.forEach(this.events,dojo.disconnect);
this.clearItems();
this.node=this.parent=this.current=null;
},markupFactory:function(_327,node){
_327._skipStartup=true;
return new dojo.dnd.Container(node,_327);
},startup:function(){
if(!this.parent){
this.parent=this.node;
if(this.parent.tagName.toLowerCase()=="table"){
var c=this.parent.getElementsByTagName("tbody");
if(c&&c.length){
this.parent=c[0];
}
}
}
this.defaultCreator=dojo.dnd._defaultCreator(this.parent);
this.sync();
},onMouseOver:function(e){
var n=e.relatedTarget;
while(n){
if(n==this.node){
break;
}
try{
n=n.parentNode;
}
catch(x){
n=null;
}
}
if(!n){
this._changeState("Container","Over");
this.onOverEvent();
}
n=this._getChildByEvent(e);
if(this.current==n){
return;
}
if(this.current){
this._removeItemClass(this.current,"Over");
}
if(n){
this._addItemClass(n,"Over");
}
this.current=n;
},onMouseOut:function(e){
for(var n=e.relatedTarget;n;){
if(n==this.node){
return;
}
try{
n=n.parentNode;
}
catch(x){
n=null;
}
}
if(this.current){
this._removeItemClass(this.current,"Over");
this.current=null;
}
this._changeState("Container","");
this.onOutEvent();
},onSelectStart:function(e){
if(!this.skipForm||!dojo.dnd.isFormElement(e)){
dojo.stopEvent(e);
}
},onOverEvent:function(){
},onOutEvent:function(){
},_changeState:function(type,_328){
var _329="dojoDnd"+type;
var _32a=type.toLowerCase()+"State";
dojo.replaceClass(this.node,_329+_328,_329+this[_32a]);
this[_32a]=_328;
},_addItemClass:function(node,type){
dojo.addClass(node,"dojoDndItem"+type);
},_removeItemClass:function(node,type){
dojo.removeClass(node,"dojoDndItem"+type);
},_getChildByEvent:function(e){
var node=e.target;
if(node){
for(var _32b=node.parentNode;_32b;node=_32b,_32b=node.parentNode){
if(_32b==this.parent&&dojo.hasClass(node,"dojoDndItem")){
return node;
}
}
}
return null;
},_normalizedCreator:function(item,hint){
var t=(this.creator||this.defaultCreator).call(this,item,hint);
if(!dojo.isArray(t.type)){
t.type=["text"];
}
if(!t.node.id){
t.node.id=dojo.dnd.getUniqueId();
}
dojo.addClass(t.node,"dojoDndItem");
return t;
}});
dojo.dnd._createNode=function(tag){
if(!tag){
return dojo.dnd._createSpan;
}
return function(text){
return dojo.create(tag,{innerHTML:text});
};
};
dojo.dnd._createTrTd=function(text){
var tr=dojo.create("tr");
dojo.create("td",{innerHTML:text},tr);
return tr;
};
dojo.dnd._createSpan=function(text){
return dojo.create("span",{innerHTML:text});
};
dojo.dnd._defaultCreatorNodes={ul:"li",ol:"li",div:"div",p:"div"};
dojo.dnd._defaultCreator=function(node){
var tag=node.tagName.toLowerCase();
var c=tag=="tbody"||tag=="thead"?dojo.dnd._createTrTd:dojo.dnd._createNode(dojo.dnd._defaultCreatorNodes[tag]);
return function(item,hint){
var _32c=item&&dojo.isObject(item),data,type,n;
if(_32c&&item.tagName&&item.nodeType&&item.getAttribute){
data=item.getAttribute("dndData")||item.innerHTML;
type=item.getAttribute("dndType");
type=type?type.split(/\s*,\s*/):["text"];
n=item;
}else{
data=(_32c&&item.data)?item.data:item;
type=(_32c&&item.type)?item.type:["text"];
n=(hint=="avatar"?dojo.dnd._createSpan:c)(String(data));
}
if(!n.id){
n.id=dojo.dnd.getUniqueId();
}
return {node:n,data:data,type:type};
};
};
}
if(!dojo._hasResource["dojo.dnd.Selector"]){
dojo._hasResource["dojo.dnd.Selector"]=true;
dojo.provide("dojo.dnd.Selector");
dojo.declare("dojo.dnd.Selector",dojo.dnd.Container,{constructor:function(node,_32d){
if(!_32d){
_32d={};
}
this.singular=_32d.singular;
this.autoSync=_32d.autoSync;
this.selection={};
this.anchor=null;
this.simpleSelection=false;
this.events.push(dojo.connect(this.node,"onmousedown",this,"onMouseDown"),dojo.connect(this.node,"onmouseup",this,"onMouseUp"));
},singular:false,getSelectedNodes:function(){
var t=new dojo.NodeList();
var e=dojo.dnd._empty;
for(var i in this.selection){
if(i in e){
continue;
}
t.push(dojo.byId(i));
}
return t;
},selectNone:function(){
return this._removeSelection()._removeAnchor();
},selectAll:function(){
this.forInItems(function(data,id){
this._addItemClass(dojo.byId(id),"Selected");
this.selection[id]=1;
},this);
return this._removeAnchor();
},deleteSelectedNodes:function(){
var e=dojo.dnd._empty;
for(var i in this.selection){
if(i in e){
continue;
}
var n=dojo.byId(i);
this.delItem(i);
dojo.destroy(n);
}
this.anchor=null;
this.selection={};
return this;
},forInSelectedItems:function(f,o){
o=o||dojo.global;
var s=this.selection,e=dojo.dnd._empty;
for(var i in s){
if(i in e){
continue;
}
f.call(o,this.getItem(i),i,this);
}
},sync:function(){
dojo.dnd.Selector.superclass.sync.call(this);
if(this.anchor){
if(!this.getItem(this.anchor.id)){
this.anchor=null;
}
}
var t=[],e=dojo.dnd._empty;
for(var i in this.selection){
if(i in e){
continue;
}
if(!this.getItem(i)){
t.push(i);
}
}
dojo.forEach(t,function(i){
delete this.selection[i];
},this);
return this;
},insertNodes:function(_32e,data,_32f,_330){
var _331=this._normalizedCreator;
this._normalizedCreator=function(item,hint){
var t=_331.call(this,item,hint);
if(_32e){
if(!this.anchor){
this.anchor=t.node;
this._removeItemClass(t.node,"Selected");
this._addItemClass(this.anchor,"Anchor");
}else{
if(this.anchor!=t.node){
this._removeItemClass(t.node,"Anchor");
this._addItemClass(t.node,"Selected");
}
}
this.selection[t.node.id]=1;
}else{
this._removeItemClass(t.node,"Selected");
this._removeItemClass(t.node,"Anchor");
}
return t;
};
dojo.dnd.Selector.superclass.insertNodes.call(this,data,_32f,_330);
this._normalizedCreator=_331;
return this;
},destroy:function(){
dojo.dnd.Selector.superclass.destroy.call(this);
this.selection=this.anchor=null;
},markupFactory:function(_332,node){
_332._skipStartup=true;
return new dojo.dnd.Selector(node,_332);
},onMouseDown:function(e){
if(this.autoSync){
this.sync();
}
if(!this.current){
return;
}
if(!this.singular&&!dojo.isCopyKey(e)&&!e.shiftKey&&(this.current.id in this.selection)){
this.simpleSelection=true;
if(e.button===dojo.mouseButtons.LEFT){
dojo.stopEvent(e);
}
return;
}
if(!this.singular&&e.shiftKey){
if(!dojo.isCopyKey(e)){
this._removeSelection();
}
var c=this.getAllNodes();
if(c.length){
if(!this.anchor){
this.anchor=c[0];
this._addItemClass(this.anchor,"Anchor");
}
this.selection[this.anchor.id]=1;
if(this.anchor!=this.current){
var i=0;
for(;i<c.length;++i){
var node=c[i];
if(node==this.anchor||node==this.current){
break;
}
}
for(++i;i<c.length;++i){
var node=c[i];
if(node==this.anchor||node==this.current){
break;
}
this._addItemClass(node,"Selected");
this.selection[node.id]=1;
}
this._addItemClass(this.current,"Selected");
this.selection[this.current.id]=1;
}
}
}else{
if(this.singular){
if(this.anchor==this.current){
if(dojo.isCopyKey(e)){
this.selectNone();
}
}else{
this.selectNone();
this.anchor=this.current;
this._addItemClass(this.anchor,"Anchor");
this.selection[this.current.id]=1;
}
}else{
if(dojo.isCopyKey(e)){
if(this.anchor==this.current){
delete this.selection[this.anchor.id];
this._removeAnchor();
}else{
if(this.current.id in this.selection){
this._removeItemClass(this.current,"Selected");
delete this.selection[this.current.id];
}else{
if(this.anchor){
this._removeItemClass(this.anchor,"Anchor");
this._addItemClass(this.anchor,"Selected");
}
this.anchor=this.current;
this._addItemClass(this.current,"Anchor");
this.selection[this.current.id]=1;
}
}
}else{
if(!(this.current.id in this.selection)){
this.selectNone();
this.anchor=this.current;
this._addItemClass(this.current,"Anchor");
this.selection[this.current.id]=1;
}
}
}
}
dojo.stopEvent(e);
},onMouseUp:function(e){
if(!this.simpleSelection){
return;
}
this.simpleSelection=false;
this.selectNone();
if(this.current){
this.anchor=this.current;
this._addItemClass(this.anchor,"Anchor");
this.selection[this.current.id]=1;
}
},onMouseMove:function(e){
this.simpleSelection=false;
},onOverEvent:function(){
this.onmousemoveEvent=dojo.connect(this.node,"onmousemove",this,"onMouseMove");
},onOutEvent:function(){
dojo.disconnect(this.onmousemoveEvent);
delete this.onmousemoveEvent;
},_removeSelection:function(){
var e=dojo.dnd._empty;
for(var i in this.selection){
if(i in e){
continue;
}
var node=dojo.byId(i);
if(node){
this._removeItemClass(node,"Selected");
}
}
this.selection={};
return this;
},_removeAnchor:function(){
if(this.anchor){
this._removeItemClass(this.anchor,"Anchor");
this.anchor=null;
}
return this;
}});
}
if(!dojo._hasResource["dojo.dnd.Avatar"]){
dojo._hasResource["dojo.dnd.Avatar"]=true;
dojo.provide("dojo.dnd.Avatar");
dojo.declare("dojo.dnd.Avatar",null,{constructor:function(_333){
this.manager=_333;
this.construct();
},construct:function(){
this.isA11y=dojo.hasClass(dojo.body(),"dijit_a11y");
var a=dojo.create("table",{"class":"dojoDndAvatar",style:{position:"absolute",zIndex:"1999",margin:"0px"}}),_334=this.manager.source,node,b=dojo.create("tbody",null,a),tr=dojo.create("tr",null,b),td=dojo.create("td",null,tr),icon=this.isA11y?dojo.create("span",{id:"a11yIcon",innerHTML:this.manager.copy?"+":"<"},td):null,span=dojo.create("span",{innerHTML:_334.generateText?this._generateText():""},td),k=Math.min(5,this.manager.nodes.length),i=0;
dojo.attr(tr,{"class":"dojoDndAvatarHeader",style:{opacity:0.9}});
for(;i<k;++i){
if(_334.creator){
node=_334._normalizedCreator(_334.getItem(this.manager.nodes[i].id).data,"avatar").node;
}else{
node=this.manager.nodes[i].cloneNode(true);
if(node.tagName.toLowerCase()=="tr"){
var _335=dojo.create("table"),_336=dojo.create("tbody",null,_335);
_336.appendChild(node);
node=_335;
}
}
node.id="";
tr=dojo.create("tr",null,b);
td=dojo.create("td",null,tr);
td.appendChild(node);
dojo.attr(tr,{"class":"dojoDndAvatarItem",style:{opacity:(9-i)/10}});
}
this.node=a;
},destroy:function(){
dojo.destroy(this.node);
this.node=false;
},update:function(){
dojo[(this.manager.canDropFlag?"add":"remove")+"Class"](this.node,"dojoDndAvatarCanDrop");
if(this.isA11y){
var icon=dojo.byId("a11yIcon");
var text="+";
if(this.manager.canDropFlag&&!this.manager.copy){
text="< ";
}else{
if(!this.manager.canDropFlag&&!this.manager.copy){
text="o";
}else{
if(!this.manager.canDropFlag){
text="x";
}
}
}
icon.innerHTML=text;
}
dojo.query(("tr.dojoDndAvatarHeader td span"+(this.isA11y?" span":"")),this.node).forEach(function(node){
node.innerHTML=this._generateText();
},this);
},_generateText:function(){
return this.manager.nodes.length.toString();
}});
}
if(!dojo._hasResource["dojo.dnd.Manager"]){
dojo._hasResource["dojo.dnd.Manager"]=true;
dojo.provide("dojo.dnd.Manager");
dojo.declare("dojo.dnd.Manager",null,{constructor:function(){
this.avatar=null;
this.source=null;
this.nodes=[];
this.copy=true;
this.target=null;
this.canDropFlag=false;
this.events=[];
},OFFSET_X:16,OFFSET_Y:16,overSource:function(_337){
if(this.avatar){
this.target=(_337&&_337.targetState!="Disabled")?_337:null;
this.canDropFlag=Boolean(this.target);
this.avatar.update();
}
dojo.publish("/dnd/source/over",[_337]);
},outSource:function(_338){
if(this.avatar){
if(this.target==_338){
this.target=null;
this.canDropFlag=false;
this.avatar.update();
dojo.publish("/dnd/source/over",[null]);
}
}else{
dojo.publish("/dnd/source/over",[null]);
}
},startDrag:function(_339,_33a,copy){
this.source=_339;
this.nodes=_33a;
this.copy=Boolean(copy);
this.avatar=this.makeAvatar();
dojo.body().appendChild(this.avatar.node);
dojo.publish("/dnd/start",[_339,_33a,this.copy]);
this.events=[dojo.connect(dojo.doc,"onmousemove",this,"onMouseMove"),dojo.connect(dojo.doc,"onmouseup",this,"onMouseUp"),dojo.connect(dojo.doc,"onkeydown",this,"onKeyDown"),dojo.connect(dojo.doc,"onkeyup",this,"onKeyUp"),dojo.connect(dojo.doc,"ondragstart",dojo.stopEvent),dojo.connect(dojo.body(),"onselectstart",dojo.stopEvent)];
var c="dojoDnd"+(copy?"Copy":"Move");
dojo.addClass(dojo.body(),c);
},canDrop:function(flag){
var _33b=Boolean(this.target&&flag);
if(this.canDropFlag!=_33b){
this.canDropFlag=_33b;
this.avatar.update();
}
},stopDrag:function(){
dojo.removeClass(dojo.body(),["dojoDndCopy","dojoDndMove"]);
dojo.forEach(this.events,dojo.disconnect);
this.events=[];
this.avatar.destroy();
this.avatar=null;
this.source=this.target=null;
this.nodes=[];
},makeAvatar:function(){
return new dojo.dnd.Avatar(this);
},updateAvatar:function(){
this.avatar.update();
},onMouseMove:function(e){
var a=this.avatar;
if(a){
dojo.dnd.autoScrollNodes(e);
var s=a.node.style;
s.left=(e.pageX+this.OFFSET_X)+"px";
s.top=(e.pageY+this.OFFSET_Y)+"px";
var copy=Boolean(this.source.copyState(dojo.isCopyKey(e)));
if(this.copy!=copy){
this._setCopyStatus(copy);
}
}
},onMouseUp:function(e){
if(this.avatar){
if(this.target&&this.canDropFlag){
var copy=Boolean(this.source.copyState(dojo.isCopyKey(e))),_33c=[this.source,this.nodes,copy,this.target,e];
dojo.publish("/dnd/drop/before",_33c);
dojo.publish("/dnd/drop",_33c);
}else{
dojo.publish("/dnd/cancel");
}
this.stopDrag();
}
},onKeyDown:function(e){
if(this.avatar){
switch(e.keyCode){
case dojo.keys.CTRL:
var copy=Boolean(this.source.copyState(true));
if(this.copy!=copy){
this._setCopyStatus(copy);
}
break;
case dojo.keys.ESCAPE:
dojo.publish("/dnd/cancel");
this.stopDrag();
break;
}
}
},onKeyUp:function(e){
if(this.avatar&&e.keyCode==dojo.keys.CTRL){
var copy=Boolean(this.source.copyState(false));
if(this.copy!=copy){
this._setCopyStatus(copy);
}
}
},_setCopyStatus:function(copy){
this.copy=copy;
this.source._markDndStatus(this.copy);
this.updateAvatar();
dojo.replaceClass(dojo.body(),"dojoDnd"+(this.copy?"Copy":"Move"),"dojoDnd"+(this.copy?"Move":"Copy"));
}});
dojo.dnd._manager=null;
dojo.dnd.manager=function(){
if(!dojo.dnd._manager){
dojo.dnd._manager=new dojo.dnd.Manager();
}
return dojo.dnd._manager;
};
}
if(!dojo._hasResource["dojo.dnd.Source"]){
dojo._hasResource["dojo.dnd.Source"]=true;
dojo.provide("dojo.dnd.Source");
dojo.declare("dojo.dnd.Source",dojo.dnd.Selector,{isSource:true,horizontal:false,copyOnly:false,selfCopy:false,selfAccept:true,skipForm:false,withHandles:false,autoSync:false,delay:0,accept:["text"],generateText:true,constructor:function(node,_33d){
dojo.mixin(this,dojo.mixin({},_33d));
var type=this.accept;
if(type.length){
this.accept={};
for(var i=0;i<type.length;++i){
this.accept[type[i]]=1;
}
}
this.isDragging=false;
this.mouseDown=false;
this.targetAnchor=null;
this.targetBox=null;
this.before=true;
this._lastX=0;
this._lastY=0;
this.sourceState="";
if(this.isSource){
dojo.addClass(this.node,"dojoDndSource");
}
this.targetState="";
if(this.accept){
dojo.addClass(this.node,"dojoDndTarget");
}
if(this.horizontal){
dojo.addClass(this.node,"dojoDndHorizontal");
}
this.topics=[dojo.subscribe("/dnd/source/over",this,"onDndSourceOver"),dojo.subscribe("/dnd/start",this,"onDndStart"),dojo.subscribe("/dnd/drop",this,"onDndDrop"),dojo.subscribe("/dnd/cancel",this,"onDndCancel")];
},checkAcceptance:function(_33e,_33f){
if(this==_33e){
return !this.copyOnly||this.selfAccept;
}
for(var i=0;i<_33f.length;++i){
var type=_33e.getItem(_33f[i].id).type;
var flag=false;
for(var j=0;j<type.length;++j){
if(type[j] in this.accept){
flag=true;
break;
}
}
if(!flag){
return false;
}
}
return true;
},copyState:function(_340,self){
if(_340){
return true;
}
if(arguments.length<2){
self=this==dojo.dnd.manager().target;
}
if(self){
if(this.copyOnly){
return this.selfCopy;
}
}else{
return this.copyOnly;
}
return false;
},destroy:function(){
dojo.dnd.Source.superclass.destroy.call(this);
dojo.forEach(this.topics,dojo.unsubscribe);
this.targetAnchor=null;
},markupFactory:function(_341,node){
_341._skipStartup=true;
return new dojo.dnd.Source(node,_341);
},onMouseMove:function(e){
if(this.isDragging&&this.targetState=="Disabled"){
return;
}
dojo.dnd.Source.superclass.onMouseMove.call(this,e);
var m=dojo.dnd.manager();
if(!this.isDragging){
if(this.mouseDown&&this.isSource&&(Math.abs(e.pageX-this._lastX)>this.delay||Math.abs(e.pageY-this._lastY)>this.delay)){
var _342=this.getSelectedNodes();
if(_342.length){
m.startDrag(this,_342,this.copyState(dojo.isCopyKey(e),true));
}
}
}
if(this.isDragging){
var _343=false;
if(this.current){
if(!this.targetBox||this.targetAnchor!=this.current){
this.targetBox=dojo.position(this.current,true);
}
if(this.horizontal){
_343=(e.pageX-this.targetBox.x)<(this.targetBox.w/2);
}else{
_343=(e.pageY-this.targetBox.y)<(this.targetBox.h/2);
}
}
if(this.current!=this.targetAnchor||_343!=this.before){
this._markTargetAnchor(_343);
m.canDrop(!this.current||m.source!=this||!(this.current.id in this.selection));
}
}
},onMouseDown:function(e){
if(!this.mouseDown&&this._legalMouseDown(e)&&(!this.skipForm||!dojo.dnd.isFormElement(e))){
this.mouseDown=true;
this._lastX=e.pageX;
this._lastY=e.pageY;
dojo.dnd.Source.superclass.onMouseDown.call(this,e);
}
},onMouseUp:function(e){
if(this.mouseDown){
this.mouseDown=false;
dojo.dnd.Source.superclass.onMouseUp.call(this,e);
}
},onDndSourceOver:function(_344){
if(this!=_344){
this.mouseDown=false;
if(this.targetAnchor){
this._unmarkTargetAnchor();
}
}else{
if(this.isDragging){
var m=dojo.dnd.manager();
m.canDrop(this.targetState!="Disabled"&&(!this.current||m.source!=this||!(this.current.id in this.selection)));
}
}
},onDndStart:function(_345,_346,copy){
if(this.autoSync){
this.sync();
}
if(this.isSource){
this._changeState("Source",this==_345?(copy?"Copied":"Moved"):"");
}
var _347=this.accept&&this.checkAcceptance(_345,_346);
this._changeState("Target",_347?"":"Disabled");
if(this==_345){
dojo.dnd.manager().overSource(this);
}
this.isDragging=true;
},onDndDrop:function(_348,_349,copy,_34a){
if(this==_34a){
this.onDrop(_348,_349,copy);
}
this.onDndCancel();
},onDndCancel:function(){
if(this.targetAnchor){
this._unmarkTargetAnchor();
this.targetAnchor=null;
}
this.before=true;
this.isDragging=false;
this.mouseDown=false;
this._changeState("Source","");
this._changeState("Target","");
},onDrop:function(_34b,_34c,copy){
if(this!=_34b){
this.onDropExternal(_34b,_34c,copy);
}else{
this.onDropInternal(_34c,copy);
}
},onDropExternal:function(_34d,_34e,copy){
var _34f=this._normalizedCreator;
if(this.creator){
this._normalizedCreator=function(node,hint){
return _34f.call(this,_34d.getItem(node.id).data,hint);
};
}else{
if(copy){
this._normalizedCreator=function(node,hint){
var t=_34d.getItem(node.id);
var n=node.cloneNode(true);
n.id=dojo.dnd.getUniqueId();
return {node:n,data:t.data,type:t.type};
};
}else{
this._normalizedCreator=function(node,hint){
var t=_34d.getItem(node.id);
_34d.delItem(node.id);
return {node:node,data:t.data,type:t.type};
};
}
}
this.selectNone();
if(!copy&&!this.creator){
_34d.selectNone();
}
this.insertNodes(true,_34e,this.before,this.current);
if(!copy&&this.creator){
_34d.deleteSelectedNodes();
}
this._normalizedCreator=_34f;
},onDropInternal:function(_350,copy){
var _351=this._normalizedCreator;
if(this.current&&this.current.id in this.selection){
return;
}
if(copy){
if(this.creator){
this._normalizedCreator=function(node,hint){
return _351.call(this,this.getItem(node.id).data,hint);
};
}else{
this._normalizedCreator=function(node,hint){
var t=this.getItem(node.id);
var n=node.cloneNode(true);
n.id=dojo.dnd.getUniqueId();
return {node:n,data:t.data,type:t.type};
};
}
}else{
if(!this.current){
return;
}
this._normalizedCreator=function(node,hint){
var t=this.getItem(node.id);
return {node:node,data:t.data,type:t.type};
};
}
this._removeSelection();
this.insertNodes(true,_350,this.before,this.current);
this._normalizedCreator=_351;
},onDraggingOver:function(){
},onDraggingOut:function(){
},onOverEvent:function(){
dojo.dnd.Source.superclass.onOverEvent.call(this);
dojo.dnd.manager().overSource(this);
if(this.isDragging&&this.targetState!="Disabled"){
this.onDraggingOver();
}
},onOutEvent:function(){
dojo.dnd.Source.superclass.onOutEvent.call(this);
dojo.dnd.manager().outSource(this);
if(this.isDragging&&this.targetState!="Disabled"){
this.onDraggingOut();
}
},_markTargetAnchor:function(_352){
if(this.current==this.targetAnchor&&this.before==_352){
return;
}
if(this.targetAnchor){
this._removeItemClass(this.targetAnchor,this.before?"Before":"After");
}
this.targetAnchor=this.current;
this.targetBox=null;
this.before=_352;
if(this.targetAnchor){
this._addItemClass(this.targetAnchor,this.before?"Before":"After");
}
},_unmarkTargetAnchor:function(){
if(!this.targetAnchor){
return;
}
this._removeItemClass(this.targetAnchor,this.before?"Before":"After");
this.targetAnchor=null;
this.targetBox=null;
this.before=true;
},_markDndStatus:function(copy){
this._changeState("Source",copy?"Copied":"Moved");
},_legalMouseDown:function(e){
if(!dojo.mouseButtons.isLeft(e)){
return false;
}
if(!this.withHandles){
return true;
}
for(var node=e.target;node&&node!==this.node;node=node.parentNode){
if(dojo.hasClass(node,"dojoDndHandle")){
return true;
}
if(dojo.hasClass(node,"dojoDndItem")||dojo.hasClass(node,"dojoDndIgnore")){
break;
}
}
return false;
}});
dojo.declare("dojo.dnd.Target",dojo.dnd.Source,{constructor:function(node,_353){
this.isSource=false;
dojo.removeClass(this.node,"dojoDndSource");
},markupFactory:function(_354,node){
_354._skipStartup=true;
return new dojo.dnd.Target(node,_354);
}});
dojo.declare("dojo.dnd.AutoSource",dojo.dnd.Source,{constructor:function(node,_355){
this.autoSync=true;
},markupFactory:function(_356,node){
_356._skipStartup=true;
return new dojo.dnd.AutoSource(node,_356);
}});
}
if(!dojo._hasResource["dojox.grid._View"]){
dojo._hasResource["dojox.grid._View"]=true;
dojo.provide("dojox.grid._View");
(function(){
var _357=function(_358,_359){
return _358.style.cssText==undefined?_358.getAttribute("style"):_358.style.cssText;
};
dojo.declare("dojox.grid._View",[dijit._Widget,dijit._Templated],{defaultWidth:"18em",viewWidth:"",templateString:"<div class=\"dojoxGridView\" role=\"presentation\">\r\n\t<div class=\"dojoxGridHeader\" dojoAttachPoint=\"headerNode\" role=\"presentation\">\r\n\t\t<div dojoAttachPoint=\"headerNodeContainer\" style=\"width:9000em\" role=\"presentation\">\r\n\t\t\t<div dojoAttachPoint=\"headerContentNode\" role=\"row\"></div>\r\n\t\t</div>\r\n\t</div>\r\n\t<input type=\"checkbox\" class=\"dojoxGridHiddenFocus\" dojoAttachPoint=\"hiddenFocusNode\" role=\"presentation\" />\r\n\t<input type=\"checkbox\" class=\"dojoxGridHiddenFocus\" role=\"presentation\" />\r\n\t<div class=\"dojoxGridScrollbox\" dojoAttachPoint=\"scrollboxNode\" role=\"presentation\">\r\n\t\t<div class=\"dojoxGridContent\" dojoAttachPoint=\"contentNode\" hidefocus=\"hidefocus\" role=\"presentation\"></div>\r\n\t</div>\r\n</div>\r\n",themeable:false,classTag:"dojoxGrid",marginBottom:0,rowPad:2,_togglingColumn:-1,_headerBuilderClass:dojox.grid._HeaderBuilder,_contentBuilderClass:dojox.grid._ContentBuilder,postMixInProperties:function(){
this.rowNodes={};
},postCreate:function(){
this.connect(this.scrollboxNode,"onscroll","doscroll");
dojox.grid.util.funnelEvents(this.contentNode,this,"doContentEvent",["mouseover","mouseout","click","dblclick","contextmenu","mousedown"]);
dojox.grid.util.funnelEvents(this.headerNode,this,"doHeaderEvent",["dblclick","mouseover","mouseout","mousemove","mousedown","click","contextmenu"]);
this.content=new this._contentBuilderClass(this);
this.header=new this._headerBuilderClass(this);
if(!dojo._isBodyLtr()){
this.headerNodeContainer.style.width="";
}
},destroy:function(){
dojo.destroy(this.headerNode);
delete this.headerNode;
for(var i in this.rowNodes){
this._cleanupRowWidgets(this.rowNodes[i]);
dojo.destroy(this.rowNodes[i]);
}
this.rowNodes={};
if(this.source){
this.source.destroy();
}
this.inherited(arguments);
},focus:function(){
if(dojo.isIE||dojo.isWebKit||dojo.isOpera){
this.hiddenFocusNode.focus();
}else{
this.scrollboxNode.focus();
}
},setStructure:function(_35a){
var vs=(this.structure=_35a);
if(vs.width&&!isNaN(vs.width)){
this.viewWidth=vs.width+"em";
}else{
this.viewWidth=vs.width||(vs.noscroll?"":this.viewWidth);
}
this._onBeforeRow=vs.onBeforeRow||function(){
};
this._onAfterRow=vs.onAfterRow||function(){
};
this.noscroll=vs.noscroll;
if(this.noscroll){
this.scrollboxNode.style.overflow="hidden";
}
this.simpleStructure=Boolean(vs.cells.length==1);
this.testFlexCells();
this.updateStructure();
},_cleanupRowWidgets:function(_35b){
if(_35b){
dojo.forEach(dojo.query("[widgetId]",_35b).map(dijit.byNode),function(w){
if(w._destroyOnRemove){
w.destroy();
delete w;
}else{
if(w.domNode&&w.domNode.parentNode){
w.domNode.parentNode.removeChild(w.domNode);
}
}
});
}
},onBeforeRow:function(_35c,_35d){
this._onBeforeRow(_35c,_35d);
if(_35c>=0){
this._cleanupRowWidgets(this.getRowNode(_35c));
}
},onAfterRow:function(_35e,_35f,_360){
this._onAfterRow(_35e,_35f,_360);
var g=this.grid;
dojo.forEach(dojo.query(".dojoxGridStubNode",_360),function(n){
if(n&&n.parentNode){
var lw=n.getAttribute("linkWidget");
var _361=window.parseInt(dojo.attr(n,"cellIdx"),10);
var _362=g.getCell(_361);
var w=dijit.byId(lw);
if(w){
n.parentNode.replaceChild(w.domNode,n);
if(!w._started){
w.startup();
}
dojo.destroy(n);
}else{
n.innerHTML="";
}
}
},this);
},testFlexCells:function(){
this.flexCells=false;
for(var j=0,row;(row=this.structure.cells[j]);j++){
for(var i=0,cell;(cell=row[i]);i++){
cell.view=this;
this.flexCells=this.flexCells||cell.isFlex();
}
}
return this.flexCells;
},updateStructure:function(){
this.header.update();
this.content.update();
},getScrollbarWidth:function(){
var _363=this.hasVScrollbar();
var _364=dojo.style(this.scrollboxNode,"overflow");
if(this.noscroll||!_364||_364=="hidden"){
_363=false;
}else{
if(_364=="scroll"){
_363=true;
}
}
return (_363?dojox.html.metrics.getScrollbar().w:0);
},getColumnsWidth:function(){
var h=this.headerContentNode;
return h&&h.firstChild?h.firstChild.offsetWidth:0;
},setColumnsWidth:function(_365){
this.headerContentNode.firstChild.style.width=_365+"px";
if(this.viewWidth){
this.viewWidth=_365+"px";
}
},getWidth:function(){
return this.viewWidth||(this.getColumnsWidth()+this.getScrollbarWidth())+"px";
},getContentWidth:function(){
return Math.max(0,dojo._getContentBox(this.domNode).w-this.getScrollbarWidth())+"px";
},render:function(){
this.scrollboxNode.style.height="";
this.renderHeader();
if(this._togglingColumn>=0){
this.setColumnsWidth(this.getColumnsWidth()-this._togglingColumn);
this._togglingColumn=-1;
}
var _366=this.grid.layout.cells;
var _367=dojo.hitch(this,function(node,_368){
!dojo._isBodyLtr()&&(_368=!_368);
var inc=_368?-1:1;
var idx=this.header.getCellNodeIndex(node)+inc;
var cell=_366[idx];
while(cell&&cell.getHeaderNode()&&cell.getHeaderNode().style.display=="none"){
idx+=inc;
cell=_366[idx];
}
if(cell){
return cell.getHeaderNode();
}
return null;
});
if(this.grid.columnReordering&&this.simpleStructure){
if(this.source){
this.source.destroy();
}
var _369="dojoxGrid_bottomMarker";
var _36a="dojoxGrid_topMarker";
if(this.bottomMarker){
dojo.destroy(this.bottomMarker);
}
this.bottomMarker=dojo.byId(_369);
if(this.topMarker){
dojo.destroy(this.topMarker);
}
this.topMarker=dojo.byId(_36a);
if(!this.bottomMarker){
this.bottomMarker=dojo.create("div",{"id":_369,"class":"dojoxGridColPlaceBottom"},dojo.body());
this._hide(this.bottomMarker);
this.topMarker=dojo.create("div",{"id":_36a,"class":"dojoxGridColPlaceTop"},dojo.body());
this._hide(this.topMarker);
}
this.arrowDim=dojo.contentBox(this.bottomMarker);
var _36b=dojo.contentBox(this.headerContentNode.firstChild.rows[0]).h;
this.source=new dojo.dnd.Source(this.headerContentNode.firstChild.rows[0],{horizontal:true,accept:["gridColumn_"+this.grid.id],viewIndex:this.index,generateText:false,onMouseDown:dojo.hitch(this,function(e){
this.header.decorateEvent(e);
if((this.header.overRightResizeArea(e)||this.header.overLeftResizeArea(e))&&this.header.canResize(e)&&!this.header.moveable){
this.header.beginColumnResize(e);
}else{
if(this.grid.headerMenu){
this.grid.headerMenu.onCancel(true);
}
if(e.button===(dojo.isIE?1:0)){
dojo.dnd.Source.prototype.onMouseDown.call(this.source,e);
}
}
}),onMouseOver:dojo.hitch(this,function(e){
var src=this.source;
if(src._getChildByEvent(e)){
dojo.dnd.Source.prototype.onMouseOver.apply(src,arguments);
}
}),_markTargetAnchor:dojo.hitch(this,function(_36c){
var src=this.source;
if(src.current==src.targetAnchor&&src.before==_36c){
return;
}
if(src.targetAnchor&&_367(src.targetAnchor,src.before)){
src._removeItemClass(_367(src.targetAnchor,src.before),src.before?"After":"Before");
}
dojo.dnd.Source.prototype._markTargetAnchor.call(src,_36c);
var _36d=_36c?src.targetAnchor:_367(src.targetAnchor,src.before);
var _36e=0;
if(!_36d){
_36d=src.targetAnchor;
_36e=dojo.contentBox(_36d).w+this.arrowDim.w/2+2;
}
var pos=(dojo.position||dojo._abs)(_36d,true);
var left=Math.floor(pos.x-this.arrowDim.w/2+_36e);
dojo.style(this.bottomMarker,"visibility","visible");
dojo.style(this.topMarker,"visibility","visible");
dojo.style(this.bottomMarker,{"left":left+"px","top":(_36b+pos.y)+"px"});
dojo.style(this.topMarker,{"left":left+"px","top":(pos.y-this.arrowDim.h)+"px"});
if(src.targetAnchor&&_367(src.targetAnchor,src.before)){
src._addItemClass(_367(src.targetAnchor,src.before),src.before?"After":"Before");
}
}),_unmarkTargetAnchor:dojo.hitch(this,function(){
var src=this.source;
if(!src.targetAnchor){
return;
}
if(src.targetAnchor&&_367(src.targetAnchor,src.before)){
src._removeItemClass(_367(src.targetAnchor,src.before),src.before?"After":"Before");
}
this._hide(this.bottomMarker);
this._hide(this.topMarker);
dojo.dnd.Source.prototype._unmarkTargetAnchor.call(src);
}),destroy:dojo.hitch(this,function(){
dojo.disconnect(this._source_conn);
dojo.unsubscribe(this._source_sub);
dojo.dnd.Source.prototype.destroy.call(this.source);
if(this.bottomMarker){
dojo.destroy(this.bottomMarker);
delete this.bottomMarker;
}
if(this.topMarker){
dojo.destroy(this.topMarker);
delete this.topMarker;
}
}),onDndCancel:dojo.hitch(this,function(){
dojo.dnd.Source.prototype.onDndCancel.call(this.source);
this._hide(this.bottomMarker);
this._hide(this.topMarker);
})});
this._source_conn=dojo.connect(this.source,"onDndDrop",this,"_onDndDrop");
this._source_sub=dojo.subscribe("/dnd/drop/before",this,"_onDndDropBefore");
this.source.startup();
}
},_hide:function(node){
dojo.style(node,{left:"-10000px",top:"-10000px","visibility":"hidden"});
},_onDndDropBefore:function(_36f,_370,copy){
if(dojo.dnd.manager().target!==this.source){
return;
}
this.source._targetNode=this.source.targetAnchor;
this.source._beforeTarget=this.source.before;
var _371=this.grid.views.views;
var _372=_371[_36f.viewIndex];
var _373=_371[this.index];
if(_373!=_372){
_372.convertColPctToFixed();
_373.convertColPctToFixed();
}
},_onDndDrop:function(_374,_375,copy){
if(dojo.dnd.manager().target!==this.source){
if(dojo.dnd.manager().source===this.source){
this._removingColumn=true;
}
return;
}
this._hide(this.bottomMarker);
this._hide(this.topMarker);
var _376=function(n){
return n?dojo.attr(n,"idx"):null;
};
var w=dojo.marginBox(_375[0]).w;
if(_374.viewIndex!==this.index){
var _377=this.grid.views.views;
var _378=_377[_374.viewIndex];
var _379=_377[this.index];
if(_378.viewWidth&&_378.viewWidth!="auto"){
_378.setColumnsWidth(_378.getColumnsWidth()-w);
}
if(_379.viewWidth&&_379.viewWidth!="auto"){
_379.setColumnsWidth(_379.getColumnsWidth());
}
}
var stn=this.source._targetNode;
var stb=this.source._beforeTarget;
!dojo._isBodyLtr()&&(stb=!stb);
var _37a=this.grid.layout;
var idx=this.index;
delete this.source._targetNode;
delete this.source._beforeTarget;
_37a.moveColumn(_374.viewIndex,idx,_376(_375[0]),_376(stn),stb);
},renderHeader:function(){
this.headerContentNode.innerHTML=this.header.generateHtml(this._getHeaderContent);
if(this.flexCells){
this.contentWidth=this.getContentWidth();
this.headerContentNode.firstChild.style.width=this.contentWidth;
}
dojox.grid.util.fire(this,"onAfterRow",[-1,this.structure.cells,this.headerContentNode]);
},_getHeaderContent:function(_37b){
var n=_37b.name||_37b.grid.getCellName(_37b);
if(/^\s+$/.test(n)){
n="&nbsp;";
}
var ret=["<div class=\"dojoxGridSortNode"];
if(_37b.index!=_37b.grid.getSortIndex()){
ret.push("\">");
}else{
ret=ret.concat([" ",_37b.grid.sortInfo>0?"dojoxGridSortUp":"dojoxGridSortDown","\"><div class=\"dojoxGridArrowButtonChar\">",_37b.grid.sortInfo>0?"&#9650;":"&#9660;","</div><div class=\"dojoxGridArrowButtonNode\" role=\"presentation\"></div>","<div class=\"dojoxGridColCaption\">"]);
}
ret=ret.concat([n,"</div></div>"]);
return ret.join("");
},resize:function(){
this.adaptHeight();
this.adaptWidth();
},hasHScrollbar:function(_37c){
var _37d=this._hasHScroll||false;
if(this._hasHScroll==undefined||_37c){
if(this.noscroll){
this._hasHScroll=false;
}else{
var _37e=dojo.style(this.scrollboxNode,"overflow");
if(_37e=="hidden"){
this._hasHScroll=false;
}else{
if(_37e=="scroll"){
this._hasHScroll=true;
}else{
this._hasHScroll=(this.scrollboxNode.offsetWidth-this.getScrollbarWidth()<this.contentNode.offsetWidth);
}
}
}
}
if(_37d!==this._hasHScroll){
this.grid.update();
}
return this._hasHScroll;
},hasVScrollbar:function(_37f){
var _380=this._hasVScroll||false;
if(this._hasVScroll==undefined||_37f){
if(this.noscroll){
this._hasVScroll=false;
}else{
var _381=dojo.style(this.scrollboxNode,"overflow");
if(_381=="hidden"){
this._hasVScroll=false;
}else{
if(_381=="scroll"){
this._hasVScroll=true;
}else{
this._hasVScroll=(this.scrollboxNode.scrollHeight>this.scrollboxNode.clientHeight);
}
}
}
}
if(_380!==this._hasVScroll){
this.grid.update();
}
return this._hasVScroll;
},convertColPctToFixed:function(){
var _382=false;
this.grid.initialWidth="";
var _383=dojo.query("th",this.headerContentNode);
var _384=dojo.map(_383,function(c,vIdx){
var w=c.style.width;
dojo.attr(c,"vIdx",vIdx);
if(w&&w.slice(-1)=="%"){
_382=true;
}else{
if(w&&w.slice(-2)=="px"){
return window.parseInt(w,10);
}
}
return dojo.contentBox(c).w;
});
if(_382){
dojo.forEach(this.grid.layout.cells,function(cell,idx){
if(cell.view==this){
var _385=cell.view.getHeaderCellNode(cell.index);
if(_385&&dojo.hasAttr(_385,"vIdx")){
var vIdx=window.parseInt(dojo.attr(_385,"vIdx"));
this.setColWidth(idx,_384[vIdx]);
dojo.removeAttr(_385,"vIdx");
}
}
},this);
return true;
}
return false;
},adaptHeight:function(_386){
if(!this.grid._autoHeight){
var h=(this.domNode.style.height&&parseInt(this.domNode.style.height.replace(/px/,""),10))||this.domNode.clientHeight;
var self=this;
var _387=function(){
var v;
for(var i in self.grid.views.views){
v=self.grid.views.views[i];
if(v!==self&&v.hasHScrollbar()){
return true;
}
}
return false;
};
if(_386||(this.noscroll&&_387())){
h-=dojox.html.metrics.getScrollbar().h;
}
dojox.grid.util.setStyleHeightPx(this.scrollboxNode,h);
}
this.hasVScrollbar(true);
},adaptWidth:function(){
if(this.flexCells){
this.contentWidth=this.getContentWidth();
this.headerContentNode.firstChild.style.width=this.contentWidth;
}
var w=this.scrollboxNode.offsetWidth-this.getScrollbarWidth();
if(!this._removingColumn){
w=Math.max(w,this.getColumnsWidth())+"px";
}else{
w=Math.min(w,this.getColumnsWidth())+"px";
this._removingColumn=false;
}
var cn=this.contentNode;
cn.style.width=w;
this.hasHScrollbar(true);
},setSize:function(w,h){
var ds=this.domNode.style;
var hs=this.headerNode.style;
if(w){
ds.width=w;
hs.width=w;
}
ds.height=(h>=0?h+"px":"");
},renderRow:function(_388){
var _389=this.createRowNode(_388);
this.buildRow(_388,_389);
return _389;
},createRowNode:function(_38a){
var node=document.createElement("div");
node.className=this.classTag+"Row";
if(this instanceof dojox.grid._RowSelector){
dojo.attr(node,"role","presentation");
}else{
dojo.attr(node,"role","row");
if(this.grid.selectionMode!="none"){
node.setAttribute("aria-selected","false");
}
}
node[dojox.grid.util.gridViewTag]=this.id;
node[dojox.grid.util.rowIndexTag]=_38a;
this.rowNodes[_38a]=node;
return node;
},buildRow:function(_38b,_38c){
this.buildRowContent(_38b,_38c);
this.styleRow(_38b,_38c);
},buildRowContent:function(_38d,_38e){
_38e.innerHTML=this.content.generateHtml(_38d,_38d);
if(this.flexCells&&this.contentWidth){
_38e.firstChild.style.width=this.contentWidth;
}
dojox.grid.util.fire(this,"onAfterRow",[_38d,this.structure.cells,_38e]);
},rowRemoved:function(_38f){
if(_38f>=0){
this._cleanupRowWidgets(this.getRowNode(_38f));
}
this.grid.edit.save(this,_38f);
delete this.rowNodes[_38f];
},getRowNode:function(_390){
return this.rowNodes[_390];
},getCellNode:function(_391,_392){
var row=this.getRowNode(_391);
if(row){
return this.content.getCellNode(row,_392);
}
},getHeaderCellNode:function(_393){
if(this.headerContentNode){
return this.header.getCellNode(this.headerContentNode,_393);
}
},styleRow:function(_394,_395){
_395._style=_357(_395);
this.styleRowNode(_394,_395);
},styleRowNode:function(_396,_397){
if(_397){
this.doStyleRowNode(_396,_397);
}
},doStyleRowNode:function(_398,_399){
this.grid.styleRowNode(_398,_399);
},updateRow:function(_39a){
var _39b=this.getRowNode(_39a);
if(_39b){
_39b.style.height="";
this.buildRow(_39a,_39b);
}
return _39b;
},updateRowStyles:function(_39c){
this.styleRowNode(_39c,this.getRowNode(_39c));
},lastTop:0,firstScroll:0,doscroll:function(_39d){
var _39e=dojo._isBodyLtr();
if(this.firstScroll<2){
if((!_39e&&this.firstScroll==1)||(_39e&&this.firstScroll===0)){
var s=dojo.marginBox(this.headerNodeContainer);
if(dojo.isIE){
this.headerNodeContainer.style.width=s.w+this.getScrollbarWidth()+"px";
}else{
if(dojo.isMoz){
this.headerNodeContainer.style.width=s.w-this.getScrollbarWidth()+"px";
this.scrollboxNode.scrollLeft=_39e?this.scrollboxNode.clientWidth-this.scrollboxNode.scrollWidth:this.scrollboxNode.scrollWidth-this.scrollboxNode.clientWidth;
}
}
}
this.firstScroll++;
}
this.headerNode.scrollLeft=this.scrollboxNode.scrollLeft;
var top=this.scrollboxNode.scrollTop;
if(top!==this.lastTop){
this.grid.scrollTo(top);
}
},setScrollTop:function(_39f){
this.lastTop=_39f;
this.scrollboxNode.scrollTop=_39f;
return this.scrollboxNode.scrollTop;
},doContentEvent:function(e){
if(this.content.decorateEvent(e)){
this.grid.onContentEvent(e);
}
},doHeaderEvent:function(e){
if(this.header.decorateEvent(e)){
this.grid.onHeaderEvent(e);
}
},dispatchContentEvent:function(e){
return this.content.dispatchEvent(e);
},dispatchHeaderEvent:function(e){
return this.header.dispatchEvent(e);
},setColWidth:function(_3a0,_3a1){
this.grid.setCellWidth(_3a0,_3a1+"px");
},update:function(){
if(!this.domNode){
return;
}
this.content.update();
this.grid.update();
var left=this.scrollboxNode.scrollLeft;
this.scrollboxNode.scrollLeft=left;
this.headerNode.scrollLeft=left;
}});
dojo.declare("dojox.grid._GridAvatar",dojo.dnd.Avatar,{construct:function(){
var dd=dojo.doc;
var a=dd.createElement("table");
a.cellPadding=a.cellSpacing="0";
a.className="dojoxGridDndAvatar";
a.style.position="absolute";
a.style.zIndex=1999;
a.style.margin="0px";
var b=dd.createElement("tbody");
var tr=dd.createElement("tr");
var td=dd.createElement("td");
var img=dd.createElement("td");
tr.className="dojoxGridDndAvatarItem";
img.className="dojoxGridDndAvatarItemImage";
img.style.width="16px";
var _3a2=this.manager.source,node;
if(_3a2.creator){
node=_3a2._normalizedCreator(_3a2.getItem(this.manager.nodes[0].id).data,"avatar").node;
}else{
node=this.manager.nodes[0].cloneNode(true);
var _3a3,_3a4;
if(node.tagName.toLowerCase()=="tr"){
_3a3=dd.createElement("table");
_3a4=dd.createElement("tbody");
_3a4.appendChild(node);
_3a3.appendChild(_3a4);
node=_3a3;
}else{
if(node.tagName.toLowerCase()=="th"){
_3a3=dd.createElement("table");
_3a4=dd.createElement("tbody");
var r=dd.createElement("tr");
_3a3.cellPadding=_3a3.cellSpacing="0";
r.appendChild(node);
_3a4.appendChild(r);
_3a3.appendChild(_3a4);
node=_3a3;
}
}
}
node.id="";
td.appendChild(node);
tr.appendChild(img);
tr.appendChild(td);
dojo.style(tr,"opacity",0.9);
b.appendChild(tr);
a.appendChild(b);
this.node=a;
var m=dojo.dnd.manager();
this.oldOffsetY=m.OFFSET_Y;
m.OFFSET_Y=1;
},destroy:function(){
dojo.dnd.manager().OFFSET_Y=this.oldOffsetY;
this.inherited(arguments);
}});
var _3a5=dojo.dnd.manager().makeAvatar;
dojo.dnd.manager().makeAvatar=function(){
var src=this.source;
if(src.viewIndex!==undefined&&!dojo.hasClass(dojo.body(),"dijit_a11y")){
return new dojox.grid._GridAvatar(this);
}
return _3a5.call(dojo.dnd.manager());
};
})();
}
if(!dojo._hasResource["dojox.grid._RowSelector"]){
dojo._hasResource["dojox.grid._RowSelector"]=true;
dojo.provide("dojox.grid._RowSelector");
dojo.declare("dojox.grid._RowSelector",dojox.grid._View,{defaultWidth:"2em",noscroll:true,padBorderWidth:2,buildRendering:function(){
this.inherited("buildRendering",arguments);
this.scrollboxNode.style.overflow="hidden";
this.headerNode.style.visibility="hidden";
},getWidth:function(){
return this.viewWidth||this.defaultWidth;
},buildRowContent:function(_3a6,_3a7){
var w=this.contentWidth||0;
_3a7.innerHTML="<table class=\"dojoxGridRowbarTable\" style=\"width:"+w+"px;height:1px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" role=\"presentation\"><tr><td class=\"dojoxGridRowbarInner\" tabindex=\"-1\">&nbsp;</td></tr></table>";
},renderHeader:function(){
},updateRow:function(){
},resize:function(){
this.adaptHeight();
},adaptWidth:function(){
if(!("contentWidth" in this)&&this.contentNode){
this.contentWidth=this.contentNode.offsetWidth-this.padBorderWidth;
}
},doStyleRowNode:function(_3a8,_3a9){
var n=["dojoxGridRowbar dojoxGridNonNormalizedCell"];
if(this.grid.rows.isOver(_3a8)){
n.push("dojoxGridRowbarOver");
}
if(this.grid.selection.isSelected(_3a8)){
n.push("dojoxGridRowbarSelected");
}
_3a9.className=n.join(" ");
},domouseover:function(e){
this.grid.onMouseOverRow(e);
},domouseout:function(e){
if(!this.isIntraRowEvent(e)){
this.grid.onMouseOutRow(e);
}
}});
}
if(!dojo._hasResource["dojox.grid._Layout"]){
dojo._hasResource["dojox.grid._Layout"]=true;
dojo.provide("dojox.grid._Layout");
dojo.declare("dojox.grid._Layout",null,{constructor:function(_3aa){
this.grid=_3aa;
},cells:[],structure:null,defaultWidth:"6em",moveColumn:function(_3ab,_3ac,_3ad,_3ae,_3af){
var _3b0=this.structure[_3ab].cells[0];
var _3b1=this.structure[_3ac].cells[0];
var cell=null;
var _3b2=0;
var _3b3=0;
for(var i=0,c;c=_3b0[i];i++){
if(c.index==_3ad){
_3b2=i;
break;
}
}
cell=_3b0.splice(_3b2,1)[0];
cell.view=this.grid.views.views[_3ac];
for(i=0,c=null;c=_3b1[i];i++){
if(c.index==_3ae){
_3b3=i;
break;
}
}
if(!_3af){
_3b3+=1;
}
_3b1.splice(_3b3,0,cell);
var _3b4=this.grid.getCell(this.grid.getSortIndex());
if(_3b4){
_3b4._currentlySorted=this.grid.getSortAsc();
}
this.cells=[];
_3ad=0;
var v;
for(i=0;v=this.structure[i];i++){
for(var j=0,cs;cs=v.cells[j];j++){
for(var k=0;c=cs[k];k++){
c.index=_3ad;
this.cells.push(c);
if("_currentlySorted" in c){
var si=_3ad+1;
si*=c._currentlySorted?1:-1;
this.grid.sortInfo=si;
delete c._currentlySorted;
}
_3ad++;
}
}
}
dojo.forEach(this.cells,function(c){
var _3b5=c.markup[2].split(" ");
var _3b6=parseInt(_3b5[1].substring(5));
if(_3b6!=c.index){
_3b5[1]="idx=\""+c.index+"\"";
c.markup[2]=_3b5.join(" ");
}
});
this.grid.setupHeaderMenu();
},setColumnVisibility:function(_3b7,_3b8){
var cell=this.cells[_3b7];
if(cell.hidden==_3b8){
cell.hidden=!_3b8;
var v=cell.view,w=v.viewWidth;
if(w&&w!="auto"){
v._togglingColumn=dojo.marginBox(cell.getHeaderNode()).w||0;
}
v.update();
return true;
}else{
return false;
}
},addCellDef:function(_3b9,_3ba,_3bb){
var self=this;
var _3bc=function(_3bd){
var w=0;
if(_3bd.colSpan>1){
w=0;
}else{
w=_3bd.width||self._defaultCellProps.width||self.defaultWidth;
if(!isNaN(w)){
w=w+"em";
}
}
return w;
};
var _3be={grid:this.grid,subrow:_3b9,layoutIndex:_3ba,index:this.cells.length};
if(_3bb&&_3bb instanceof dojox.grid.cells._Base){
var _3bf=dojo.clone(_3bb);
_3be.unitWidth=_3bc(_3bf._props);
_3bf=dojo.mixin(_3bf,this._defaultCellProps,_3bb._props,_3be);
return _3bf;
}
var _3c0=_3bb.type||_3bb.cellType||this._defaultCellProps.type||this._defaultCellProps.cellType||dojox.grid.cells.Cell;
_3be.unitWidth=_3bc(_3bb);
return new _3c0(dojo.mixin({},this._defaultCellProps,_3bb,_3be));
},addRowDef:function(_3c1,_3c2){
var _3c3=[];
var _3c4=0,_3c5=0,_3c6=true;
for(var i=0,def,cell;(def=_3c2[i]);i++){
cell=this.addCellDef(_3c1,i,def);
_3c3.push(cell);
this.cells.push(cell);
if(_3c6&&cell.relWidth){
_3c4+=cell.relWidth;
}else{
if(cell.width){
var w=cell.width;
if(typeof w=="string"&&w.slice(-1)=="%"){
_3c5+=window.parseInt(w,10);
}else{
if(w=="auto"){
_3c6=false;
}
}
}
}
}
if(_3c4&&_3c6){
dojo.forEach(_3c3,function(cell){
if(cell.relWidth){
cell.width=cell.unitWidth=((cell.relWidth/_3c4)*(100-_3c5))+"%";
}
});
}
return _3c3;
},addRowsDef:function(_3c7){
var _3c8=[];
if(dojo.isArray(_3c7)){
if(dojo.isArray(_3c7[0])){
for(var i=0,row;_3c7&&(row=_3c7[i]);i++){
_3c8.push(this.addRowDef(i,row));
}
}else{
_3c8.push(this.addRowDef(0,_3c7));
}
}
return _3c8;
},addViewDef:function(_3c9){
this._defaultCellProps=_3c9.defaultCell||{};
if(_3c9.width&&_3c9.width=="auto"){
delete _3c9.width;
}
return dojo.mixin({},_3c9,{cells:this.addRowsDef(_3c9.rows||_3c9.cells)});
},setStructure:function(_3ca){
this.fieldIndex=0;
this.cells=[];
var s=this.structure=[];
if(this.grid.rowSelector){
var sel={type:dojox._scopeName+".grid._RowSelector"};
if(dojo.isString(this.grid.rowSelector)){
var _3cb=this.grid.rowSelector;
if(_3cb=="false"){
sel=null;
}else{
if(_3cb!="true"){
sel["width"]=_3cb;
}
}
}else{
if(!this.grid.rowSelector){
sel=null;
}
}
if(sel){
s.push(this.addViewDef(sel));
}
}
var _3cc=function(def){
return ("name" in def||"field" in def||"get" in def);
};
var _3cd=function(def){
if(dojo.isArray(def)){
if(dojo.isArray(def[0])||_3cc(def[0])){
return true;
}
}
return false;
};
var _3ce=function(def){
return (def!==null&&dojo.isObject(def)&&("cells" in def||"rows" in def||("type" in def&&!_3cc(def))));
};
if(dojo.isArray(_3ca)){
var _3cf=false;
for(var i=0,st;(st=_3ca[i]);i++){
if(_3ce(st)){
_3cf=true;
break;
}
}
if(!_3cf){
s.push(this.addViewDef({cells:_3ca}));
}else{
for(i=0;(st=_3ca[i]);i++){
if(_3cd(st)){
s.push(this.addViewDef({cells:st}));
}else{
if(_3ce(st)){
s.push(this.addViewDef(st));
}
}
}
}
}else{
if(_3ce(_3ca)){
s.push(this.addViewDef(_3ca));
}
}
this.cellCount=this.cells.length;
this.grid.setupHeaderMenu();
}});
}
if(!dojo._hasResource["dojox.grid._ViewManager"]){
dojo._hasResource["dojox.grid._ViewManager"]=true;
dojo.provide("dojox.grid._ViewManager");
dojo.declare("dojox.grid._ViewManager",null,{constructor:function(_3d0){
this.grid=_3d0;
},defaultWidth:200,views:[],resize:function(){
this.onEach("resize");
},render:function(){
this.onEach("render");
},addView:function(_3d1){
_3d1.idx=this.views.length;
this.views.push(_3d1);
},destroyViews:function(){
for(var i=0,v;v=this.views[i];i++){
v.destroy();
}
this.views=[];
},getContentNodes:function(){
var _3d2=[];
for(var i=0,v;v=this.views[i];i++){
_3d2.push(v.contentNode);
}
return _3d2;
},forEach:function(_3d3){
for(var i=0,v;v=this.views[i];i++){
_3d3(v,i);
}
},onEach:function(_3d4,_3d5){
_3d5=_3d5||[];
for(var i=0,v;v=this.views[i];i++){
if(_3d4 in v){
v[_3d4].apply(v,_3d5);
}
}
},normalizeHeaderNodeHeight:function(){
var _3d6=[];
for(var i=0,v;(v=this.views[i]);i++){
if(v.headerContentNode.firstChild){
_3d6.push(v.headerContentNode);
}
}
this.normalizeRowNodeHeights(_3d6);
},normalizeRowNodeHeights:function(_3d7){
var h=0;
var _3d8=[];
if(this.grid.rowHeight){
h=this.grid.rowHeight;
}else{
if(_3d7.length<=1){
return;
}
for(var i=0,n;(n=_3d7[i]);i++){
if(!dojo.hasClass(n,"dojoxGridNonNormalizedCell")){
_3d8[i]=n.firstChild.offsetHeight;
h=Math.max(h,_3d8[i]);
}
}
h=(h>=0?h:0);
if(dojo.isMoz&&h){
h++;
}
}
for(i=0;(n=_3d7[i]);i++){
if(_3d8[i]!=h){
n.firstChild.style.height=h+"px";
}
}
},resetHeaderNodeHeight:function(){
for(var i=0,v,n;(v=this.views[i]);i++){
n=v.headerContentNode.firstChild;
if(n){
n.style.height="";
}
}
},renormalizeRow:function(_3d9){
var _3da=[];
for(var i=0,v,n;(v=this.views[i])&&(n=v.getRowNode(_3d9));i++){
n.firstChild.style.height="";
_3da.push(n);
}
this.normalizeRowNodeHeights(_3da);
},getViewWidth:function(_3db){
return this.views[_3db].getWidth()||this.defaultWidth;
},measureHeader:function(){
this.resetHeaderNodeHeight();
this.forEach(function(_3dc){
_3dc.headerContentNode.style.height="";
});
var h=0;
this.forEach(function(_3dd){
h=Math.max(_3dd.headerNode.offsetHeight,h);
});
return h;
},measureContent:function(){
var h=0;
this.forEach(function(_3de){
h=Math.max(_3de.domNode.offsetHeight,h);
});
return h;
},findClient:function(_3df){
var c=this.grid.elasticView||-1;
if(c<0){
for(var i=1,v;(v=this.views[i]);i++){
if(v.viewWidth){
for(i=1;(v=this.views[i]);i++){
if(!v.viewWidth){
c=i;
break;
}
}
break;
}
}
}
if(c<0){
c=Math.floor(this.views.length/2);
}
return c;
},arrange:function(l,w){
var i,v,vw,len=this.views.length;
var c=(w<=0?len:this.findClient());
var _3e0=function(v,l){
var ds=v.domNode.style;
var hs=v.headerNode.style;
if(!dojo._isBodyLtr()){
ds.right=l+"px";
if(dojo.isMoz){
hs.right=l+v.getScrollbarWidth()+"px";
hs.width=parseInt(hs.width,10)-v.getScrollbarWidth()+"px";
}else{
hs.right=l+"px";
}
}else{
ds.left=l+"px";
hs.left=l+"px";
}
ds.top=0+"px";
hs.top=0;
};
for(i=0;(v=this.views[i])&&(i<c);i++){
vw=this.getViewWidth(i);
v.setSize(vw,0);
_3e0(v,l);
if(v.headerContentNode&&v.headerContentNode.firstChild){
vw=v.getColumnsWidth()+v.getScrollbarWidth();
}else{
vw=v.domNode.offsetWidth;
}
l+=vw;
}
i++;
var r=w;
for(var j=len-1;(v=this.views[j])&&(i<=j);j--){
vw=this.getViewWidth(j);
v.setSize(vw,0);
vw=v.domNode.offsetWidth;
r-=vw;
_3e0(v,r);
}
if(c<len){
v=this.views[c];
vw=Math.max(1,r-l);
v.setSize(vw+"px",0);
_3e0(v,l);
}
return l;
},renderRow:function(_3e1,_3e2,_3e3){
var _3e4=[];
for(var i=0,v,n,_3e5;(v=this.views[i])&&(n=_3e2[i]);i++){
_3e5=v.renderRow(_3e1);
n.appendChild(_3e5);
_3e4.push(_3e5);
}
if(!_3e3){
this.normalizeRowNodeHeights(_3e4);
}
},rowRemoved:function(_3e6){
this.onEach("rowRemoved",[_3e6]);
},updateRow:function(_3e7,_3e8){
for(var i=0,v;v=this.views[i];i++){
v.updateRow(_3e7);
}
if(!_3e8){
this.renormalizeRow(_3e7);
}
},updateRowStyles:function(_3e9){
this.onEach("updateRowStyles",[_3e9]);
},setScrollTop:function(_3ea){
var top=_3ea;
for(var i=0,v;v=this.views[i];i++){
top=v.setScrollTop(_3ea);
if(dojo.isIE&&v.headerNode&&v.scrollboxNode){
v.headerNode.scrollLeft=v.scrollboxNode.scrollLeft;
}
}
return top;
},getFirstScrollingView:function(){
for(var i=0,v;(v=this.views[i]);i++){
if(v.hasHScrollbar()||v.hasVScrollbar()){
return v;
}
}
return null;
}});
}
if(!dojo._hasResource["dojox.grid._RowManager"]){
dojo._hasResource["dojox.grid._RowManager"]=true;
dojo.provide("dojox.grid._RowManager");
(function(){
var _3eb=function(_3ec,_3ed){
if(_3ec.style.cssText==undefined){
_3ec.setAttribute("style",_3ed);
}else{
_3ec.style.cssText=_3ed;
}
};
dojo.declare("dojox.grid._RowManager",null,{constructor:function(_3ee){
this.grid=_3ee;
},linesToEms:2,overRow:-2,prepareStylingRow:function(_3ef,_3f0){
return {index:_3ef,node:_3f0,odd:Boolean(_3ef&1),selected:!!this.grid.selection.isSelected(_3ef),over:this.isOver(_3ef),customStyles:"",customClasses:"dojoxGridRow"};
},styleRowNode:function(_3f1,_3f2){
var row=this.prepareStylingRow(_3f1,_3f2);
this.grid.onStyleRow(row);
this.applyStyles(row);
},applyStyles:function(_3f3){
var i=_3f3;
i.node.className=i.customClasses;
var h=i.node.style.height;
_3eb(i.node,i.customStyles+";"+(i.node._style||""));
i.node.style.height=h;
},updateStyles:function(_3f4){
this.grid.updateRowStyles(_3f4);
},setOverRow:function(_3f5){
var last=this.overRow;
this.overRow=_3f5;
if((last!=this.overRow)&&(dojo.isString(last)||last>=0)){
this.updateStyles(last);
}
this.updateStyles(this.overRow);
},isOver:function(_3f6){
return (this.overRow==_3f6&&!dojo.hasClass(this.grid.domNode,"dojoxGridColumnResizing"));
}});
})();
}
if(!dojo._hasResource["dojox.grid._FocusManager"]){
dojo._hasResource["dojox.grid._FocusManager"]=true;
dojo.provide("dojox.grid._FocusManager");
dojo.declare("dojox.grid._FocusManager",null,{constructor:function(_3f7){
this.grid=_3f7;
this.cell=null;
this.rowIndex=-1;
this._connects=[];
this._headerConnects=[];
this.headerMenu=this.grid.headerMenu;
this._connects.push(dojo.connect(this.grid.domNode,"onfocus",this,"doFocus"));
this._connects.push(dojo.connect(this.grid.domNode,"onblur",this,"doBlur"));
this._connects.push(dojo.connect(this.grid.domNode,"oncontextmenu",this,"doContextMenu"));
this._connects.push(dojo.connect(this.grid.lastFocusNode,"onfocus",this,"doLastNodeFocus"));
this._connects.push(dojo.connect(this.grid.lastFocusNode,"onblur",this,"doLastNodeBlur"));
this._connects.push(dojo.connect(this.grid,"_onFetchComplete",this,"_delayedCellFocus"));
this._connects.push(dojo.connect(this.grid,"postrender",this,"_delayedHeaderFocus"));
},destroy:function(){
dojo.forEach(this._connects,dojo.disconnect);
dojo.forEach(this._headerConnects,dojo.disconnect);
delete this.grid;
delete this.cell;
},_colHeadNode:null,_colHeadFocusIdx:null,_contextMenuBindNode:null,tabbingOut:false,focusClass:"dojoxGridCellFocus",focusView:null,initFocusView:function(){
this.focusView=this.grid.views.getFirstScrollingView()||this.focusView||this.grid.views.views[0];
this._initColumnHeaders();
},isFocusCell:function(_3f8,_3f9){
return (this.cell==_3f8)&&(this.rowIndex==_3f9);
},isLastFocusCell:function(){
if(this.cell){
return (this.rowIndex==this.grid.rowCount-1)&&(this.cell.index==this.grid.layout.cellCount-1);
}
return false;
},isFirstFocusCell:function(){
if(this.cell){
return (this.rowIndex===0)&&(this.cell.index===0);
}
return false;
},isNoFocusCell:function(){
return (this.rowIndex<0)||!this.cell;
},isNavHeader:function(){
return (!!this._colHeadNode);
},getHeaderIndex:function(){
if(this._colHeadNode){
return dojo.indexOf(this._findHeaderCells(),this._colHeadNode);
}else{
return -1;
}
},_focusifyCellNode:function(_3fa){
var n=this.cell&&this.cell.getNode(this.rowIndex);
if(n){
dojo.toggleClass(n,this.focusClass,_3fa);
if(_3fa){
var sl=this.scrollIntoView();
try{
if(!this.grid.edit.isEditing()){
dojox.grid.util.fire(n,"focus");
if(sl){
this.cell.view.scrollboxNode.scrollLeft=sl;
}
}
}
catch(e){
}
}
}
},_delayedCellFocus:function(){
if(this.isNavHeader()||!this.grid._focused){
return;
}
var n=this.cell&&this.cell.getNode(this.rowIndex);
if(n){
try{
if(!this.grid.edit.isEditing()){
dojo.toggleClass(n,this.focusClass,true);
if(this._colHeadNode){
this.blurHeader();
}
dojox.grid.util.fire(n,"focus");
}
}
catch(e){
}
}
},_delayedHeaderFocus:function(){
if(this.isNavHeader()){
this.focusHeader();
dijit.focus(this.grid.domNode);
}
},_initColumnHeaders:function(){
dojo.forEach(this._headerConnects,dojo.disconnect);
this._headerConnects=[];
var _3fb=this._findHeaderCells();
for(var i=0;i<_3fb.length;i++){
this._headerConnects.push(dojo.connect(_3fb[i],"onfocus",this,"doColHeaderFocus"));
this._headerConnects.push(dojo.connect(_3fb[i],"onblur",this,"doColHeaderBlur"));
}
},_findHeaderCells:function(){
var _3fc=dojo.query("th",this.grid.viewsHeaderNode);
var _3fd=[];
for(var i=0;i<_3fc.length;i++){
var _3fe=_3fc[i];
var _3ff=dojo.hasAttr(_3fe,"tabIndex");
var _400=dojo.attr(_3fe,"tabIndex");
if(_3ff&&_400<0){
_3fd.push(_3fe);
}
}
return _3fd;
},_setActiveColHeader:function(_401,_402,_403){
this.grid.domNode.setAttribute("aria-activedescendant",_401.id);
if(_403!=null&&_403>=0&&_403!=_402){
dojo.toggleClass(this._findHeaderCells()[_403],this.focusClass,false);
}
dojo.toggleClass(_401,this.focusClass,true);
this._colHeadNode=_401;
this._colHeadFocusIdx=_402;
this._scrollHeader(this._colHeadFocusIdx);
},scrollIntoView:function(){
var info=(this.cell?this._scrollInfo(this.cell):null);
if(!info||!info.s){
return null;
}
var rt=this.grid.scroller.findScrollTop(this.rowIndex);
if(info.n&&info.sr){
if(info.n.offsetLeft+info.n.offsetWidth>info.sr.l+info.sr.w){
info.s.scrollLeft=info.n.offsetLeft+info.n.offsetWidth-info.sr.w;
}else{
if(info.n.offsetLeft<info.sr.l){
info.s.scrollLeft=info.n.offsetLeft;
}
}
}
if(info.r&&info.sr){
if(rt+info.r.offsetHeight>info.sr.t+info.sr.h){
this.grid.setScrollTop(rt+info.r.offsetHeight-info.sr.h);
}else{
if(rt<info.sr.t){
this.grid.setScrollTop(rt);
}
}
}
return info.s.scrollLeft;
},_scrollInfo:function(cell,_404){
if(cell){
var cl=cell,sbn=cl.view.scrollboxNode,sbnr={w:sbn.clientWidth,l:sbn.scrollLeft,t:sbn.scrollTop,h:sbn.clientHeight},rn=cl.view.getRowNode(this.rowIndex);
return {c:cl,s:sbn,sr:sbnr,n:(_404?_404:cell.getNode(this.rowIndex)),r:rn};
}
return null;
},_scrollHeader:function(_405){
var info=null;
if(this._colHeadNode){
var cell=this.grid.getCell(_405);
if(!cell){
return;
}
info=this._scrollInfo(cell,cell.getNode(0));
}
if(info&&info.s&&info.sr&&info.n){
var _406=info.sr.l+info.sr.w;
if(info.n.offsetLeft+info.n.offsetWidth>_406){
info.s.scrollLeft=info.n.offsetLeft+info.n.offsetWidth-info.sr.w;
}else{
if(info.n.offsetLeft<info.sr.l){
info.s.scrollLeft=info.n.offsetLeft;
}else{
if(dojo.isIE<=7&&cell&&cell.view.headerNode){
cell.view.headerNode.scrollLeft=info.s.scrollLeft;
}
}
}
}
},_isHeaderHidden:function(){
var _407=this.focusView;
if(!_407){
for(var i=0,_408;(_408=this.grid.views.views[i]);i++){
if(_408.headerNode){
_407=_408;
break;
}
}
}
return (_407&&dojo.getComputedStyle(_407.headerNode).display=="none");
},colSizeAdjust:function(e,_409,_40a){
var _40b=this._findHeaderCells();
var view=this.focusView;
if(!view){
for(var i=0,_40c;(_40c=this.grid.views.views[i]);i++){
if(_40c.header.tableMap.map){
view=_40c;
break;
}
}
}
var _40d=_40b[_409];
if(!view||(_409==_40b.length-1&&_409===0)){
return;
}
view.content.baseDecorateEvent(e);
e.cellNode=_40d;
e.cellIndex=view.content.getCellNodeIndex(e.cellNode);
e.cell=(e.cellIndex>=0?this.grid.getCell(e.cellIndex):null);
if(view.header.canResize(e)){
var _40e={l:_40a};
var drag=view.header.colResizeSetup(e,false);
view.header.doResizeColumn(drag,null,_40e);
view.update();
}
},styleRow:function(_40f){
return;
},setFocusIndex:function(_410,_411){
this.setFocusCell(this.grid.getCell(_411),_410);
},setFocusCell:function(_412,_413){
if(_412&&!this.isFocusCell(_412,_413)){
this.tabbingOut=false;
if(this._colHeadNode){
this.blurHeader();
}
this._colHeadNode=this._colHeadFocusIdx=null;
this.focusView=_412.view;
this.focusGridView();
this._focusifyCellNode(false);
this.cell=_412;
this.rowIndex=_413;
this._focusifyCellNode(true);
}
if(dojo.isOpera){
setTimeout(dojo.hitch(this.grid,"onCellFocus",this.cell,this.rowIndex),1);
}else{
this.grid.onCellFocus(this.cell,this.rowIndex);
}
},next:function(){
if(this.cell){
var row=this.rowIndex,col=this.cell.index+1,cc=this.grid.layout.cellCount-1,rc=this.grid.rowCount-1;
if(col>cc){
col=0;
row++;
}
if(row>rc){
col=cc;
row=rc;
}
if(this.grid.edit.isEditing()){
var _414=this.grid.getCell(col);
if(!this.isLastFocusCell()&&(!_414.editable||this.grid.canEdit&&!this.grid.canEdit(_414,row))){
this.cell=_414;
this.rowIndex=row;
this.next();
return;
}
}
this.setFocusIndex(row,col);
}
},previous:function(){
if(this.cell){
var row=(this.rowIndex||0),col=(this.cell.index||0)-1;
if(col<0){
col=this.grid.layout.cellCount-1;
row--;
}
if(row<0){
row=0;
col=0;
}
if(this.grid.edit.isEditing()){
var _415=this.grid.getCell(col);
if(!this.isFirstFocusCell()&&!_415.editable){
this.cell=_415;
this.rowIndex=row;
this.previous();
return;
}
}
this.setFocusIndex(row,col);
}
},move:function(_416,_417){
var _418=_417<0?-1:1;
if(this.isNavHeader()){
var _419=this._findHeaderCells();
var _41a=currentIdx=dojo.indexOf(_419,this._colHeadNode);
currentIdx+=_417;
while(currentIdx>=0&&currentIdx<_419.length&&_419[currentIdx].style.display=="none"){
currentIdx+=_418;
}
if((currentIdx>=0)&&(currentIdx<_419.length)){
this._setActiveColHeader(_419[currentIdx],currentIdx,_41a);
}
}else{
if(this.cell){
var sc=this.grid.scroller,r=this.rowIndex,rc=this.grid.rowCount-1,row=Math.min(rc,Math.max(0,r+_416));
if(_416){
if(_416>0){
if(row>sc.getLastPageRow(sc.page)){
this.grid.setScrollTop(this.grid.scrollTop+sc.findScrollTop(row)-sc.findScrollTop(r));
}
}else{
if(_416<0){
if(row<=sc.getPageRow(sc.page)){
this.grid.setScrollTop(this.grid.scrollTop-sc.findScrollTop(r)-sc.findScrollTop(row));
}
}
}
}
var cc=this.grid.layout.cellCount-1,i=this.cell.index,col=Math.min(cc,Math.max(0,i+_417));
var cell=this.grid.getCell(col);
while(col>=0&&col<cc&&cell&&cell.hidden===true){
col+=_418;
cell=this.grid.getCell(col);
}
if(!cell||cell.hidden===true){
col=i;
}
var n=cell.getNode(row);
if(!n&&_416){
if((row+_416)>=0&&(row+_416)<=rc){
this.move(_416>0?++_416:--_416,_417);
}
return;
}else{
if((!n||dojo.style(n,"display")==="none")&&_417){
if((col+_416)>=0&&(col+_416)<=cc){
this.move(_416,_417>0?++_417:--_417);
}
return;
}
}
this.setFocusIndex(row,col);
}
}
},previousKey:function(e){
if(this.grid.edit.isEditing()){
dojo.stopEvent(e);
this.previous();
}else{
if(!this.isNavHeader()&&!this._isHeaderHidden()){
this.grid.domNode.focus();
dojo.stopEvent(e);
}else{
this.tabOut(this.grid.domNode);
if(this._colHeadFocusIdx!=null){
dojo.toggleClass(this._findHeaderCells()[this._colHeadFocusIdx],this.focusClass,false);
this._colHeadFocusIdx=null;
}
this._focusifyCellNode(false);
}
}
},nextKey:function(e){
var _41b=(this.grid.rowCount===0);
if(e.target===this.grid.domNode&&this._colHeadFocusIdx==null){
this.focusHeader();
dojo.stopEvent(e);
}else{
if(this.isNavHeader()){
this.blurHeader();
if(!this.findAndFocusGridCell()){
this.tabOut(this.grid.lastFocusNode);
}
this._colHeadNode=this._colHeadFocusIdx=null;
}else{
if(this.grid.edit.isEditing()){
dojo.stopEvent(e);
this.next();
}else{
this.tabOut(this.grid.lastFocusNode);
}
}
}
},tabOut:function(_41c){
this.tabbingOut=true;
_41c.focus();
},focusGridView:function(){
dojox.grid.util.fire(this.focusView,"focus");
},focusGrid:function(_41d){
this.focusGridView();
this._focusifyCellNode(true);
},findAndFocusGridCell:function(){
var _41e=true;
var _41f=(this.grid.rowCount===0);
if(this.isNoFocusCell()&&!_41f){
var _420=0;
var cell=this.grid.getCell(_420);
if(cell.hidden){
_420=this.isNavHeader()?this._colHeadFocusIdx:0;
}
this.setFocusIndex(0,_420);
}else{
if(this.cell&&!_41f){
if(this.focusView&&!this.focusView.rowNodes[this.rowIndex]){
this.grid.scrollToRow(this.rowIndex);
}
this.focusGrid();
}else{
_41e=false;
}
}
this._colHeadNode=this._colHeadFocusIdx=null;
return _41e;
},focusHeader:function(){
var _421=this._findHeaderCells();
var _422=this._colHeadFocusIdx;
if(this._isHeaderHidden()){
this.findAndFocusGridCell();
}else{
if(!this._colHeadFocusIdx){
if(this.isNoFocusCell()){
this._colHeadFocusIdx=0;
}else{
this._colHeadFocusIdx=this.cell.index;
}
}
}
this._colHeadNode=_421[this._colHeadFocusIdx];
while(this._colHeadNode&&this._colHeadFocusIdx>=0&&this._colHeadFocusIdx<_421.length&&this._colHeadNode.style.display=="none"){
this._colHeadFocusIdx++;
this._colHeadNode=_421[this._colHeadFocusIdx];
}
if(this._colHeadNode&&this._colHeadNode.style.display!="none"){
this.focusView=this.grid.getCell(this._colHeadFocusIdx).view;
if(this.headerMenu&&this._contextMenuBindNode!=this.grid.domNode){
this.headerMenu.unBindDomNode(this.grid.viewsHeaderNode);
this.headerMenu.bindDomNode(this.grid.domNode);
this._contextMenuBindNode=this.grid.domNode;
}
this._setActiveColHeader(this._colHeadNode,this._colHeadFocusIdx,_422);
this._scrollHeader(this._colHeadFocusIdx);
this._focusifyCellNode(false);
}else{
this.findAndFocusGridCell();
}
},blurHeader:function(){
dojo.removeClass(this._colHeadNode,this.focusClass);
dojo.removeAttr(this.grid.domNode,"aria-activedescendant");
if(this.headerMenu&&this._contextMenuBindNode==this.grid.domNode){
var _423=this.grid.viewsHeaderNode;
this.headerMenu.unBindDomNode(this.grid.domNode);
this.headerMenu.bindDomNode(_423);
this._contextMenuBindNode=_423;
}
},doFocus:function(e){
if(e&&e.target!=e.currentTarget){
dojo.stopEvent(e);
return;
}
if(!this.tabbingOut){
this.focusHeader();
}
this.tabbingOut=false;
dojo.stopEvent(e);
},doBlur:function(e){
dojo.stopEvent(e);
},doContextMenu:function(e){
if(!this.headerMenu){
dojo.stopEvent(e);
}
},doLastNodeFocus:function(e){
if(this.tabbingOut){
this._focusifyCellNode(false);
}else{
if(this.grid.rowCount>0){
if(this.isNoFocusCell()){
this.setFocusIndex(0,0);
}
this._focusifyCellNode(true);
}else{
this.focusHeader();
}
}
this.tabbingOut=false;
dojo.stopEvent(e);
},doLastNodeBlur:function(e){
dojo.stopEvent(e);
},doColHeaderFocus:function(e){
this._setActiveColHeader(e.target,dojo.attr(e.target,"idx"),this._colHeadFocusIdx);
this._scrollHeader(this.getHeaderIndex());
dojo.stopEvent(e);
},doColHeaderBlur:function(e){
dojo.toggleClass(e.target,this.focusClass,false);
}});
}
if(!dojo._hasResource["dojox.grid._EditManager"]){
dojo._hasResource["dojox.grid._EditManager"]=true;
dojo.provide("dojox.grid._EditManager");
dojo.declare("dojox.grid._EditManager",null,{constructor:function(_424){
this.grid=_424;
if(dojo.isIE){
this.connections=[dojo.connect(document.body,"onfocus",dojo.hitch(this,"_boomerangFocus"))];
}else{
this.connections=[dojo.connect(this.grid,"onBlur",this,"apply")];
}
},info:{},destroy:function(){
dojo.forEach(this.connections,dojo.disconnect);
},cellFocus:function(_425,_426){
if(this.grid.singleClickEdit||this.isEditRow(_426)){
this.setEditCell(_425,_426);
}else{
this.apply();
}
if(this.isEditing()||(_425&&_425.editable&&_425.alwaysEditing)){
this._focusEditor(_425,_426);
}
},rowClick:function(e){
if(this.isEditing()&&!this.isEditRow(e.rowIndex)){
this.apply();
}
},styleRow:function(_427){
if(_427.index==this.info.rowIndex){
_427.customClasses+=" dojoxGridRowEditing";
}
},dispatchEvent:function(e){
var c=e.cell,ed=(c&&c["editable"])?c:0;
return ed&&ed.dispatchEvent(e.dispatch,e);
},isEditing:function(){
return this.info.rowIndex!==undefined;
},isEditCell:function(_428,_429){
return (this.info.rowIndex===_428)&&(this.info.cell.index==_429);
},isEditRow:function(_42a){
return this.info.rowIndex===_42a;
},setEditCell:function(_42b,_42c){
if(!this.isEditCell(_42c,_42b.index)&&this.grid.canEdit&&this.grid.canEdit(_42b,_42c)){
this.start(_42b,_42c,this.isEditRow(_42c)||_42b.editable);
}
},_focusEditor:function(_42d,_42e){
dojox.grid.util.fire(_42d,"focus",[_42e]);
},focusEditor:function(){
if(this.isEditing()){
this._focusEditor(this.info.cell,this.info.rowIndex);
}
},_boomerangWindow:500,_shouldCatchBoomerang:function(){
return this._catchBoomerang>new Date().getTime();
},_boomerangFocus:function(){
if(this._shouldCatchBoomerang()){
this.grid.focus.focusGrid();
this.focusEditor();
this._catchBoomerang=0;
}
},_doCatchBoomerang:function(){
if(dojo.isIE){
this._catchBoomerang=new Date().getTime()+this._boomerangWindow;
}
},start:function(_42f,_430,_431){
if(!this._isValidInput()){
return;
}
this.grid.beginUpdate();
try{
this.editorApply();
}
catch(e){
console.warn("_base.start:",e);
}
if(this.isEditing()&&!this.isEditRow(_430)){
this.applyRowEdit();
this.grid.updateRow(_430);
}
if(_431){
this.info={cell:_42f,rowIndex:_430};
this.grid.doStartEdit(_42f,_430);
this.grid.updateRow(_430);
}else{
this.info={};
}
this.grid.endUpdate();
this.grid.focus.focusGrid();
this._focusEditor(_42f,_430);
this._doCatchBoomerang();
},_editorDo:function(_432){
var c=this.info.cell;
if(c&&c.editable){
c[_432](this.info.rowIndex);
}
},editorApply:function(){
this._editorDo("apply");
},editorCancel:function(){
this._editorDo("cancel");
},applyCellEdit:function(_433,_434,_435){
if(this.grid.canEdit(_434,_435)){
this.grid.doApplyCellEdit(_433,_435,_434.field);
}
},applyRowEdit:function(){
this.grid.doApplyEdit(this.info.rowIndex,this.info.cell.field);
},apply:function(){
if(this.isEditing()&&this._isValidInput()){
this.grid.beginUpdate();
this.editorApply();
this.applyRowEdit();
this.info={};
this.grid.endUpdate();
this.grid.focus.focusGrid();
this._doCatchBoomerang();
}
},cancel:function(){
if(this.isEditing()){
this.grid.beginUpdate();
this.editorCancel();
this.info={};
this.grid.endUpdate();
this.grid.focus.focusGrid();
this._doCatchBoomerang();
}
},save:function(_436,_437){
var c=this.info.cell;
if(this.isEditRow(_436)&&(!_437||c.view==_437)&&c.editable){
c.save(c,this.info.rowIndex);
}
},restore:function(_438,_439){
var c=this.info.cell;
if(this.isEditRow(_439)&&c.view==_438&&c.editable){
c.restore(c,this.info.rowIndex);
}
},_isValidInput:function(){
var w=(this.info.cell||{}).widget;
if(!w||!w.isValid){
return true;
}
w.focused=true;
return w.isValid(true);
}});
}
if(!dojo._hasResource["dojox.grid.Selection"]){
dojo._hasResource["dojox.grid.Selection"]=true;
dojo.provide("dojox.grid.Selection");
dojo.declare("dojox.grid.Selection",null,{constructor:function(_43a){
this.grid=_43a;
this.selected=[];
this.setMode(_43a.selectionMode);
},mode:"extended",selected:null,updating:0,selectedIndex:-1,setMode:function(mode){
if(this.selected.length){
this.deselectAll();
}
if(mode!="extended"&&mode!="multiple"&&mode!="single"&&mode!="none"){
this.mode="extended";
}else{
this.mode=mode;
}
},onCanSelect:function(_43b){
return this.grid.onCanSelect(_43b);
},onCanDeselect:function(_43c){
return this.grid.onCanDeselect(_43c);
},onSelected:function(_43d){
},onDeselected:function(_43e){
},onChanging:function(){
},onChanged:function(){
},isSelected:function(_43f){
if(this.mode=="none"){
return false;
}
return this.selected[_43f];
},getFirstSelected:function(){
if(!this.selected.length||this.mode=="none"){
return -1;
}
for(var i=0,l=this.selected.length;i<l;i++){
if(this.selected[i]){
return i;
}
}
return -1;
},getNextSelected:function(_440){
if(this.mode=="none"){
return -1;
}
for(var i=_440+1,l=this.selected.length;i<l;i++){
if(this.selected[i]){
return i;
}
}
return -1;
},getSelected:function(){
var _441=[];
for(var i=0,l=this.selected.length;i<l;i++){
if(this.selected[i]){
_441.push(i);
}
}
return _441;
},getSelectedCount:function(){
var c=0;
for(var i=0;i<this.selected.length;i++){
if(this.selected[i]){
c++;
}
}
return c;
},_beginUpdate:function(){
if(this.updating===0){
this.onChanging();
}
this.updating++;
},_endUpdate:function(){
this.updating--;
if(this.updating===0){
this.onChanged();
}
},select:function(_442){
if(this.mode=="none"){
return;
}
if(this.mode!="multiple"){
this.deselectAll(_442);
this.addToSelection(_442);
}else{
this.toggleSelect(_442);
}
},addToSelection:function(_443){
if(this.mode=="none"){
return;
}
if(dojo.isArray(_443)){
dojo.forEach(_443,this.addToSelection,this);
return;
}
_443=Number(_443);
if(this.selected[_443]){
this.selectedIndex=_443;
}else{
if(this.onCanSelect(_443)!==false){
this.selectedIndex=_443;
var _444=this.grid.getRowNode(_443);
if(_444){
dojo.attr(_444,"aria-selected","true");
}
this._beginUpdate();
this.selected[_443]=true;
this.onSelected(_443);
this._endUpdate();
}
}
},deselect:function(_445){
if(this.mode=="none"){
return;
}
if(dojo.isArray(_445)){
dojo.forEach(_445,this.deselect,this);
return;
}
_445=Number(_445);
if(this.selectedIndex==_445){
this.selectedIndex=-1;
}
if(this.selected[_445]){
if(this.onCanDeselect(_445)===false){
return;
}
var _446=this.grid.getRowNode(_445);
if(_446){
dojo.attr(_446,"aria-selected","false");
}
this._beginUpdate();
delete this.selected[_445];
this.onDeselected(_445);
this._endUpdate();
}
},setSelected:function(_447,_448){
this[(_448?"addToSelection":"deselect")](_447);
},toggleSelect:function(_449){
if(dojo.isArray(_449)){
dojo.forEach(_449,this.toggleSelect,this);
return;
}
this.setSelected(_449,!this.selected[_449]);
},_range:function(_44a,inTo,func){
var s=(_44a>=0?_44a:inTo),e=inTo;
if(s>e){
e=s;
s=inTo;
}
for(var i=s;i<=e;i++){
func(i);
}
},selectRange:function(_44b,inTo){
this._range(_44b,inTo,dojo.hitch(this,"addToSelection"));
},deselectRange:function(_44c,inTo){
this._range(_44c,inTo,dojo.hitch(this,"deselect"));
},insert:function(_44d){
this.selected.splice(_44d,0,false);
if(this.selectedIndex>=_44d){
this.selectedIndex++;
}
},remove:function(_44e){
this.selected.splice(_44e,1);
if(this.selectedIndex>=_44e){
this.selectedIndex--;
}
},deselectAll:function(_44f){
for(var i in this.selected){
if((i!=_44f)&&(this.selected[i]===true)){
this.deselect(i);
}
}
},clickSelect:function(_450,_451,_452){
if(this.mode=="none"){
return;
}
this._beginUpdate();
if(this.mode!="extended"){
this.select(_450);
}else{
var _453=this.selectedIndex;
if(!_451){
this.deselectAll(_450);
}
if(_452){
this.selectRange(_453,_450);
}else{
if(_451){
this.toggleSelect(_450);
}else{
this.addToSelection(_450);
}
}
}
this._endUpdate();
},clickSelectEvent:function(e){
this.clickSelect(e.rowIndex,dojo.isCopyKey(e),e.shiftKey);
},clear:function(){
this._beginUpdate();
this.deselectAll();
this._endUpdate();
}});
}
if(!dojo._hasResource["dojox.grid._Events"]){
dojo._hasResource["dojox.grid._Events"]=true;
dojo.provide("dojox.grid._Events");
dojo.declare("dojox.grid._Events",null,{cellOverClass:"dojoxGridCellOver",onKeyEvent:function(e){
this.dispatchKeyEvent(e);
},onContentEvent:function(e){
this.dispatchContentEvent(e);
},onHeaderEvent:function(e){
this.dispatchHeaderEvent(e);
},onStyleRow:function(_454){
var i=_454;
i.customClasses+=(i.odd?" dojoxGridRowOdd":"")+(i.selected?" dojoxGridRowSelected":"")+(i.over?" dojoxGridRowOver":"");
this.focus.styleRow(_454);
this.edit.styleRow(_454);
},onKeyDown:function(e){
if(e.altKey||e.metaKey){
return;
}
var dk=dojo.keys;
var _455;
switch(e.keyCode){
case dk.ESCAPE:
this.edit.cancel();
break;
case dk.ENTER:
if(!this.edit.isEditing()){
_455=this.focus.getHeaderIndex();
if(_455>=0){
this.setSortIndex(_455);
break;
}else{
this.selection.clickSelect(this.focus.rowIndex,dojo.isCopyKey(e),e.shiftKey);
}
dojo.stopEvent(e);
}
if(!e.shiftKey){
var _456=this.edit.isEditing();
this.edit.apply();
if(!_456){
this.edit.setEditCell(this.focus.cell,this.focus.rowIndex);
}
}
if(!this.edit.isEditing()){
var _457=this.focus.focusView||this.views.views[0];
_457.content.decorateEvent(e,_457.rowNodes[this.focus.rowIndex]);
this.onRowClick(e);
dojo.stopEvent(e);
}
break;
case dk.SPACE:
if(!this.edit.isEditing()){
_455=this.focus.getHeaderIndex();
if(_455>=0){
this.setSortIndex(_455);
break;
}else{
this.selection.clickSelect(this.focus.rowIndex,dojo.isCopyKey(e),e.shiftKey);
}
}
break;
case dk.TAB:
this.focus[e.shiftKey?"previousKey":"nextKey"](e);
break;
case dk.LEFT_ARROW:
case dk.RIGHT_ARROW:
if(!this.edit.isEditing()){
var _458=e.keyCode;
dojo.stopEvent(e);
_455=this.focus.getHeaderIndex();
if(_455>=0&&(e.shiftKey&&e.ctrlKey)){
this.focus.colSizeAdjust(e,_455,(_458==dk.LEFT_ARROW?-1:1)*5);
}else{
var _459=(_458==dk.LEFT_ARROW)?1:-1;
if(dojo._isBodyLtr()){
_459*=-1;
}
this.focus.move(0,_459);
}
}
break;
case dk.UP_ARROW:
if(!this.edit.isEditing()&&this.focus.rowIndex!==0){
dojo.stopEvent(e);
this.focus.move(-1,0);
}
break;
case dk.DOWN_ARROW:
if(!this.edit.isEditing()&&this.focus.rowIndex+1!=this.rowCount){
dojo.stopEvent(e);
this.focus.move(1,0);
}
break;
case dk.PAGE_UP:
if(!this.edit.isEditing()&&this.focus.rowIndex!==0){
dojo.stopEvent(e);
if(this.focus.rowIndex!=this.scroller.firstVisibleRow+1){
this.focus.move(this.scroller.firstVisibleRow-this.focus.rowIndex,0);
}else{
this.setScrollTop(this.scroller.findScrollTop(this.focus.rowIndex-1));
this.focus.move(this.scroller.firstVisibleRow-this.scroller.lastVisibleRow+1,0);
}
}
break;
case dk.PAGE_DOWN:
if(!this.edit.isEditing()&&this.focus.rowIndex+1!=this.rowCount){
dojo.stopEvent(e);
if(this.focus.rowIndex!=this.scroller.lastVisibleRow-1){
this.focus.move(this.scroller.lastVisibleRow-this.focus.rowIndex-1,0);
}else{
this.setScrollTop(this.scroller.findScrollTop(this.focus.rowIndex+1));
this.focus.move(this.scroller.lastVisibleRow-this.scroller.firstVisibleRow-1,0);
}
}
break;
default:
break;
}
},onMouseOver:function(e){
e.rowIndex==-1?this.onHeaderCellMouseOver(e):this.onCellMouseOver(e);
},onMouseOut:function(e){
e.rowIndex==-1?this.onHeaderCellMouseOut(e):this.onCellMouseOut(e);
},onMouseDown:function(e){
e.rowIndex==-1?this.onHeaderCellMouseDown(e):this.onCellMouseDown(e);
},onMouseOverRow:function(e){
if(!this.rows.isOver(e.rowIndex)){
this.rows.setOverRow(e.rowIndex);
e.rowIndex==-1?this.onHeaderMouseOver(e):this.onRowMouseOver(e);
}
},onMouseOutRow:function(e){
if(this.rows.isOver(-1)){
this.onHeaderMouseOut(e);
}else{
if(!this.rows.isOver(-2)){
this.rows.setOverRow(-2);
this.onRowMouseOut(e);
}
}
},onMouseDownRow:function(e){
if(e.rowIndex!=-1){
this.onRowMouseDown(e);
}
},onCellMouseOver:function(e){
if(e.cellNode){
dojo.addClass(e.cellNode,this.cellOverClass);
}
},onCellMouseOut:function(e){
if(e.cellNode){
dojo.removeClass(e.cellNode,this.cellOverClass);
}
},onCellMouseDown:function(e){
},onCellClick:function(e){
this._click[0]=this._click[1];
this._click[1]=e;
if(!this.edit.isEditCell(e.rowIndex,e.cellIndex)){
this.focus.setFocusCell(e.cell,e.rowIndex);
}
if(this._click.length>1&&this._click[0]==null){
this._click.shift();
}
this.onRowClick(e);
},onCellDblClick:function(e){
var _45a;
if(this._click.length>1&&dojo.isIE){
_45a=this._click[1];
}else{
if(this._click.length>1&&this._click[0].rowIndex!=this._click[1].rowIndex){
_45a=this._click[0];
}else{
_45a=e;
}
}
this.focus.setFocusCell(_45a.cell,_45a.rowIndex);
this.onRowClick(_45a);
this.edit.setEditCell(_45a.cell,_45a.rowIndex);
this.onRowDblClick(e);
},onCellContextMenu:function(e){
this.onRowContextMenu(e);
},onCellFocus:function(_45b,_45c){
this.edit.cellFocus(_45b,_45c);
},onRowClick:function(e){
this.edit.rowClick(e);
this.selection.clickSelectEvent(e);
},onRowDblClick:function(e){
},onRowMouseOver:function(e){
},onRowMouseOut:function(e){
},onRowMouseDown:function(e){
},onRowContextMenu:function(e){
dojo.stopEvent(e);
},onHeaderMouseOver:function(e){
},onHeaderMouseOut:function(e){
},onHeaderCellMouseOver:function(e){
if(e.cellNode){
dojo.addClass(e.cellNode,this.cellOverClass);
}
},onHeaderCellMouseOut:function(e){
if(e.cellNode){
dojo.removeClass(e.cellNode,this.cellOverClass);
}
},onHeaderCellMouseDown:function(e){
},onHeaderClick:function(e){
},onHeaderCellClick:function(e){
this.setSortIndex(e.cell.index);
this.onHeaderClick(e);
},onHeaderDblClick:function(e){
},onHeaderCellDblClick:function(e){
this.onHeaderDblClick(e);
},onHeaderCellContextMenu:function(e){
this.onHeaderContextMenu(e);
},onHeaderContextMenu:function(e){
if(!this.headerMenu){
dojo.stopEvent(e);
}
},onStartEdit:function(_45d,_45e){
},onApplyCellEdit:function(_45f,_460,_461){
},onCancelEdit:function(_462){
},onApplyEdit:function(_463){
},onCanSelect:function(_464){
return true;
},onCanDeselect:function(_465){
return true;
},onSelected:function(_466){
this.updateRowStyles(_466);
},onDeselected:function(_467){
this.updateRowStyles(_467);
},onSelectionChanged:function(){
}});
}
if(!dojo._hasResource["dojo.i18n"]){
dojo._hasResource["dojo.i18n"]=true;
dojo.provide("dojo.i18n");
dojo.getObject("i18n",true,dojo);
dojo.i18n.getLocalization=dojo.i18n.getLocalization||function(_468,_469,_46a){
_46a=dojo.i18n.normalizeLocale(_46a);
var _46b=_46a.split("-");
var _46c=[_468,"nls",_469].join(".");
var _46d=dojo._loadedModules[_46c];
if(_46d){
var _46e;
for(var i=_46b.length;i>0;i--){
var loc=_46b.slice(0,i).join("_");
if(_46d[loc]){
_46e=_46d[loc];
break;
}
}
if(!_46e){
_46e=_46d.ROOT;
}
if(_46e){
var _46f=function(){
};
_46f.prototype=_46e;
return new _46f();
}
}
throw new Error("Bundle not found: "+_469+" in "+_468+" , locale="+_46a);
};
dojo.i18n.normalizeLocale=function(_470){
var _471=_470?_470.toLowerCase():dojo.locale;
if(_471=="root"){
_471="ROOT";
}
return _471;
};
dojo.i18n._requireLocalization=function(_472,_473,_474,_475){
var _476=dojo.i18n.normalizeLocale(_474);
var _477=[_472,"nls",_473].join(".");
var _478="";
if(_475){
var _479=_475.split(",");
for(var i=0;i<_479.length;i++){
if(_476["indexOf"](_479[i])==0){
if(_479[i].length>_478.length){
_478=_479[i];
}
}
}
if(!_478){
_478="ROOT";
}
}
var _47a=_475?_478:_476;
var _47b=dojo._loadedModules[_477];
var _47c=null;
if(_47b){
if(dojo.config.localizationComplete&&_47b._built){
return;
}
var _47d=_47a.replace(/-/g,"_");
var _47e=_477+"."+_47d;
_47c=dojo._loadedModules[_47e];
}
if(!_47c){
_47b=dojo["provide"](_477);
var syms=dojo._getModuleSymbols(_472);
var _47f=syms.concat("nls").join("/");
var _480;
dojo.i18n._searchLocalePath(_47a,_475,function(loc){
var _481=loc.replace(/-/g,"_");
var _482=_477+"."+_481;
var _483=false;
if(!dojo._loadedModules[_482]){
dojo["provide"](_482);
var _484=[_47f];
if(loc!="ROOT"){
_484.push(loc);
}
_484.push(_473);
var _485=_484.join("/")+".js";
_483=dojo._loadPath(_485,null,function(hash){
hash=hash.root||hash;
var _486=function(){
};
_486.prototype=_480;
_47b[_481]=new _486();
for(var j in hash){
_47b[_481][j]=hash[j];
}
});
}else{
_483=true;
}
if(_483&&_47b[_481]){
_480=_47b[_481];
}else{
_47b[_481]=_480;
}
if(_475){
return true;
}
});
}
if(_475&&_476!=_478){
_47b[_476.replace(/-/g,"_")]=_47b[_478.replace(/-/g,"_")];
}
};
(function(){
var _487=dojo.config.extraLocale;
if(_487){
if(!_487 instanceof Array){
_487=[_487];
}
var req=dojo.i18n._requireLocalization;
dojo.i18n._requireLocalization=function(m,b,_488,_489){
req(m,b,_488,_489);
if(_488){
return;
}
for(var i=0;i<_487.length;i++){
req(m,b,_487[i],_489);
}
};
}
})();
dojo.i18n._searchLocalePath=function(_48a,down,_48b){
_48a=dojo.i18n.normalizeLocale(_48a);
var _48c=_48a.split("-");
var _48d=[];
for(var i=_48c.length;i>0;i--){
_48d.push(_48c.slice(0,i).join("-"));
}
_48d.push(false);
if(down){
_48d.reverse();
}
for(var j=_48d.length-1;j>=0;j--){
var loc=_48d[j]||"ROOT";
var stop=_48b(loc);
if(stop){
break;
}
}
};
dojo.i18n._preloadLocalizations=function(_48e,_48f){
function _490(_491){
_491=dojo.i18n.normalizeLocale(_491);
dojo.i18n._searchLocalePath(_491,true,function(loc){
for(var i=0;i<_48f.length;i++){
if(_48f[i]==loc){
dojo["require"](_48e+"_"+loc);
return true;
}
}
return false;
});
};
_490();
var _492=dojo.config.extraLocale||[];
for(var i=0;i<_492.length;i++){
_490(_492[i]);
}
};
}
if(!dojo._hasResource["dojox.grid._Grid"]){
dojo._hasResource["dojox.grid._Grid"]=true;
dojo.provide("dojox.grid._Grid");
(function(){
if(!dojo.isCopyKey){
dojo.isCopyKey=dojo.dnd.getCopyKeyState;
}
dojo.declare("dojox.grid._Grid",[dijit._Widget,dijit._Templated,dojox.grid._Events],{templateString:"<div hidefocus=\"hidefocus\" role=\"grid\" dojoAttachEvent=\"onmouseout:_mouseOut\">\r\n\t<div class=\"dojoxGridMasterHeader\" dojoAttachPoint=\"viewsHeaderNode\" role=\"presentation\"></div>\r\n\t<div class=\"dojoxGridMasterView\" dojoAttachPoint=\"viewsNode\" role=\"presentation\"></div>\r\n\t<div class=\"dojoxGridMasterMessages\" style=\"display: none;\" dojoAttachPoint=\"messagesNode\"></div>\r\n\t<span dojoAttachPoint=\"lastFocusNode\" tabindex=\"0\"></span>\r\n</div>\r\n",classTag:"dojoxGrid",rowCount:5,keepRows:75,rowsPerPage:25,autoWidth:false,initialWidth:"",autoHeight:"",rowHeight:0,autoRender:true,defaultHeight:"15em",height:"",structure:null,elasticView:-1,singleClickEdit:false,selectionMode:"extended",rowSelector:"",columnReordering:false,headerMenu:null,placeholderLabel:"GridColumns",selectable:false,_click:null,loadingMessage:"<span class='dojoxGridLoading'>${loadingState}</span>",errorMessage:"<span class='dojoxGridError'>${errorState}</span>",noDataMessage:"",escapeHTMLInData:true,formatterScope:null,editable:false,sortInfo:0,themeable:true,_placeholders:null,_layoutClass:dojox.grid._Layout,buildRendering:function(){
this.inherited(arguments);
if(!this.domNode.getAttribute("tabIndex")){
this.domNode.tabIndex="0";
}
this.createScroller();
this.createLayout();
this.createViews();
this.createManagers();
this.createSelection();
this.connect(this.selection,"onSelected","onSelected");
this.connect(this.selection,"onDeselected","onDeselected");
this.connect(this.selection,"onChanged","onSelectionChanged");
dojox.html.metrics.initOnFontResize();
this.connect(dojox.html.metrics,"onFontResize","textSizeChanged");
dojox.grid.util.funnelEvents(this.domNode,this,"doKeyEvent",dojox.grid.util.keyEvents);
if(this.selectionMode!="none"){
this.domNode.setAttribute("aria-multiselectable",this.selectionMode=="single"?"false":"true");
}
dojo.addClass(this.domNode,this.classTag);
if(!this.isLeftToRight()){
dojo.addClass(this.domNode,this.classTag+"Rtl");
}
},postMixInProperties:function(){
this.inherited(arguments);
var _493=dojo.i18n.getLocalization("dijit","loading",this.lang);
this.loadingMessage=dojo.string.substitute(this.loadingMessage,_493);
this.errorMessage=dojo.string.substitute(this.errorMessage,_493);
if(this.srcNodeRef&&this.srcNodeRef.style.height){
this.height=this.srcNodeRef.style.height;
}
this._setAutoHeightAttr(this.autoHeight,true);
this.lastScrollTop=this.scrollTop=0;
},postCreate:function(){
this._placeholders=[];
this._setHeaderMenuAttr(this.headerMenu);
this._setStructureAttr(this.structure);
this._click=[];
this.inherited(arguments);
if(this.domNode&&this.autoWidth&&this.initialWidth){
this.domNode.style.width=this.initialWidth;
}
if(this.domNode&&!this.editable){
dojo.attr(this.domNode,"aria-readonly","true");
}
},destroy:function(){
this.domNode.onReveal=null;
this.domNode.onSizeChange=null;
delete this._click;
if(this.scroller){
this.scroller.destroy();
delete this.scroller;
}
this.edit.destroy();
delete this.edit;
this.views.destroyViews();
if(this.focus){
this.focus.destroy();
delete this.focus;
}
if(this.headerMenu&&this._placeholders.length){
dojo.forEach(this._placeholders,function(p){
p.unReplace(true);
});
this.headerMenu.unBindDomNode(this.viewsHeaderNode);
}
this.inherited(arguments);
},_setAutoHeightAttr:function(ah,_494){
if(typeof ah=="string"){
if(!ah||ah=="false"){
ah=false;
}else{
if(ah=="true"){
ah=true;
}else{
ah=window.parseInt(ah,10);
}
}
}
if(typeof ah=="number"){
if(isNaN(ah)){
ah=false;
}
if(ah<0){
ah=true;
}else{
if(ah===0){
ah=false;
}
}
}
this.autoHeight=ah;
if(typeof ah=="boolean"){
this._autoHeight=ah;
}else{
if(typeof ah=="number"){
this._autoHeight=(ah>=this.get("rowCount"));
}else{
this._autoHeight=false;
}
}
if(this._started&&!_494){
this.render();
}
},_getRowCountAttr:function(){
return this.updating&&this.invalidated&&this.invalidated.rowCount!=undefined?this.invalidated.rowCount:this.rowCount;
},textSizeChanged:function(){
this.render();
},sizeChange:function(){
this.update();
},createManagers:function(){
this.rows=new dojox.grid._RowManager(this);
this.focus=new dojox.grid._FocusManager(this);
this.edit=new dojox.grid._EditManager(this);
},createSelection:function(){
this.selection=new dojox.grid.Selection(this);
},createScroller:function(){
this.scroller=new dojox.grid._Scroller();
this.scroller.grid=this;
this.scroller.renderRow=dojo.hitch(this,"renderRow");
this.scroller.removeRow=dojo.hitch(this,"rowRemoved");
},createLayout:function(){
this.layout=new this._layoutClass(this);
this.connect(this.layout,"moveColumn","onMoveColumn");
},onMoveColumn:function(){
this.render();
},onResizeColumn:function(_495){
},createViews:function(){
this.views=new dojox.grid._ViewManager(this);
this.views.createView=dojo.hitch(this,"createView");
},createView:function(_496,idx){
var c=dojo.getObject(_496);
var view=new c({grid:this,index:idx});
this.viewsNode.appendChild(view.domNode);
this.viewsHeaderNode.appendChild(view.headerNode);
this.views.addView(view);
dojo.attr(this.domNode,"align",dojo._isBodyLtr()?"left":"right");
return view;
},buildViews:function(){
for(var i=0,vs;(vs=this.layout.structure[i]);i++){
this.createView(vs.type||dojox._scopeName+".grid._View",i).setStructure(vs);
}
this.scroller.setContentNodes(this.views.getContentNodes());
},_setStructureAttr:function(_497){
var s=_497;
if(s&&dojo.isString(s)){
dojo.deprecated("dojox.grid._Grid.set('structure', 'objVar')","use dojox.grid._Grid.set('structure', objVar) instead","2.0");
s=dojo.getObject(s);
}
this.structure=s;
if(!s){
if(this.layout.structure){
s=this.layout.structure;
}else{
return;
}
}
this.views.destroyViews();
this.focus.focusView=null;
if(s!==this.layout.structure){
this.layout.setStructure(s);
}
this._structureChanged();
},setStructure:function(_498){
dojo.deprecated("dojox.grid._Grid.setStructure(obj)","use dojox.grid._Grid.set('structure', obj) instead.","2.0");
this._setStructureAttr(_498);
},getColumnTogglingItems:function(){
return dojo.map(this.layout.cells,function(cell){
if(!cell.menuItems){
cell.menuItems=[];
}
var self=this;
var item=new dijit.CheckedMenuItem({label:cell.name,checked:!cell.hidden,_gridCell:cell,onChange:function(_499){
if(self.layout.setColumnVisibility(this._gridCell.index,_499)){
var _49a=this._gridCell.menuItems;
if(_49a.length>1){
dojo.forEach(_49a,function(item){
if(item!==this){
item.setAttribute("checked",_499);
}
},this);
}
_499=dojo.filter(self.layout.cells,function(c){
if(c.menuItems.length>1){
dojo.forEach(c.menuItems,"item.set('disabled', false);");
}else{
c.menuItems[0].set("disabled",false);
}
return !c.hidden;
});
if(_499.length==1){
dojo.forEach(_499[0].menuItems,"item.set('disabled', true);");
}
}
},destroy:function(){
var _49b=dojo.indexOf(this._gridCell.menuItems,this);
this._gridCell.menuItems.splice(_49b,1);
delete this._gridCell;
dijit.CheckedMenuItem.prototype.destroy.apply(this,arguments);
}});
cell.menuItems.push(item);
return item;
},this);
},_setHeaderMenuAttr:function(menu){
if(this._placeholders&&this._placeholders.length){
dojo.forEach(this._placeholders,function(p){
p.unReplace(true);
});
this._placeholders=[];
}
if(this.headerMenu){
this.headerMenu.unBindDomNode(this.viewsHeaderNode);
}
this.headerMenu=menu;
if(!menu){
return;
}
this.headerMenu.bindDomNode(this.viewsHeaderNode);
if(this.headerMenu.getPlaceholders){
this._placeholders=this.headerMenu.getPlaceholders(this.placeholderLabel);
}
},setHeaderMenu:function(menu){
dojo.deprecated("dojox.grid._Grid.setHeaderMenu(obj)","use dojox.grid._Grid.set('headerMenu', obj) instead.","2.0");
this._setHeaderMenuAttr(menu);
},setupHeaderMenu:function(){
if(this._placeholders&&this._placeholders.length){
dojo.forEach(this._placeholders,function(p){
if(p._replaced){
p.unReplace(true);
}
p.replace(this.getColumnTogglingItems());
},this);
}
},_fetch:function(_49c){
this.setScrollTop(0);
},getItem:function(_49d){
return null;
},showMessage:function(_49e){
if(_49e){
this.messagesNode.innerHTML=_49e;
this.messagesNode.style.display="";
}else{
this.messagesNode.innerHTML="";
this.messagesNode.style.display="none";
}
},_structureChanged:function(){
this.buildViews();
if(this.autoRender&&this._started){
this.render();
}
},hasLayout:function(){
return this.layout.cells.length;
},resize:function(_49f,_4a0){
this._pendingChangeSize=_49f;
this._pendingResultSize=_4a0;
this.sizeChange();
},_getPadBorder:function(){
this._padBorder=this._padBorder||dojo._getPadBorderExtents(this.domNode);
return this._padBorder;
},_getHeaderHeight:function(){
var vns=this.viewsHeaderNode.style,t=vns.display=="none"?0:this.views.measureHeader();
vns.height=t+"px";
this.views.normalizeHeaderNodeHeight();
return t;
},_resize:function(_4a1,_4a2){
_4a1=_4a1||this._pendingChangeSize;
_4a2=_4a2||this._pendingResultSize;
delete this._pendingChangeSize;
delete this._pendingResultSize;
if(!this.domNode){
return;
}
var pn=this.domNode.parentNode;
if(!pn||pn.nodeType!=1||!this.hasLayout()||pn.style.visibility=="hidden"||pn.style.display=="none"){
return;
}
var _4a3=this._getPadBorder();
var hh=undefined;
var h;
if(this._autoHeight){
this.domNode.style.height="auto";
}else{
if(typeof this.autoHeight=="number"){
h=hh=this._getHeaderHeight();
h+=(this.scroller.averageRowHeight*this.autoHeight);
this.domNode.style.height=h+"px";
}else{
if(this.domNode.clientHeight<=_4a3.h){
if(pn==document.body){
this.domNode.style.height=this.defaultHeight;
}else{
if(this.height){
this.domNode.style.height=this.height;
}else{
if(dojo.style(this.domNode,"height")>0){
this.domNode.style.height=dojo.style(this.domNode,"height");
}else{
this.fitTo="parent";
}
}
}
}
}
}
if(_4a2){
_4a1=_4a2;
}
if(!this._autoHeight&&_4a1){
dojo.marginBox(this.domNode,_4a1);
this.height=this.domNode.style.height;
delete this.fitTo;
}else{
if(this.fitTo=="parent"){
h=this._parentContentBoxHeight=this._parentContentBoxHeight||dojo._getContentBox(pn).h;
this.domNode.style.height=Math.max(0,h)+"px";
}
}
var _4a4=dojo.some(this.views.views,function(v){
return v.flexCells;
});
if(!this._autoHeight&&(h||dojo._getContentBox(this.domNode).h)===0){
this.viewsHeaderNode.style.display="none";
}else{
this.viewsHeaderNode.style.display="block";
if(!_4a4&&hh===undefined){
hh=this._getHeaderHeight();
}
}
if(_4a4){
hh=undefined;
}
this.adaptWidth();
this.adaptHeight(hh);
this.postresize();
},adaptWidth:function(){
var _4a5=(!this.initialWidth&&this.autoWidth);
var w=_4a5?0:this.domNode.clientWidth||(this.domNode.offsetWidth-this._getPadBorder().w),vw=this.views.arrange(1,w);
this.views.onEach("adaptWidth");
if(_4a5){
this.domNode.style.width=vw+"px";
}
},adaptHeight:function(_4a6){
var t=_4a6===undefined?this._getHeaderHeight():_4a6;
var h=(this._autoHeight?-1:Math.max(this.domNode.clientHeight-t,0)||0);
this.views.onEach("setSize",[0,h]);
this.views.onEach("adaptHeight");
if(!this._autoHeight){
var _4a7=0,_4a8=0;
var _4a9=dojo.filter(this.views.views,function(v){
var has=v.hasHScrollbar();
if(has){
_4a7++;
}else{
_4a8++;
}
return (!has);
});
if(_4a7>0&&_4a8>0){
dojo.forEach(_4a9,function(v){
v.adaptHeight(true);
});
}
}
if(this.autoHeight===true||h!=-1||(typeof this.autoHeight=="number"&&this.autoHeight>=this.get("rowCount"))){
this.scroller.windowHeight=h;
}else{
this.scroller.windowHeight=Math.max(this.domNode.clientHeight-t,0);
}
},startup:function(){
if(this._started){
return;
}
this.inherited(arguments);
if(this.autoRender){
this.render();
}
},render:function(){
if(!this.domNode){
return;
}
if(!this._started){
return;
}
if(!this.hasLayout()){
this.scroller.init(0,this.keepRows,this.rowsPerPage);
return;
}
this.update=this.defaultUpdate;
this._render();
},_render:function(){
this.scroller.init(this.get("rowCount"),this.keepRows,this.rowsPerPage);
this.prerender();
this.setScrollTop(0);
this.postrender();
},prerender:function(){
this.keepRows=this._autoHeight?0:this.keepRows;
this.scroller.setKeepInfo(this.keepRows);
this.views.render();
this._resize();
},postrender:function(){
this.postresize();
this.focus.initFocusView();
dojo.setSelectable(this.domNode,this.selectable);
if(dojo.isIE){
dojo.query("th.dojoxGridCell",this.viewsHeaderNode).forEach(function(node){
dojo.setSelectable(node,true);
});
}
},postresize:function(){
if(this._autoHeight){
var size=Math.max(this.views.measureContent())+"px";
this.viewsNode.style.height=size;
}
},renderRow:function(_4aa,_4ab){
this.views.renderRow(_4aa,_4ab,this._skipRowRenormalize);
},rowRemoved:function(_4ac){
this.views.rowRemoved(_4ac);
},invalidated:null,updating:false,beginUpdate:function(){
this.invalidated=[];
this.updating=true;
},endUpdate:function(){
this.updating=false;
var i=this.invalidated,r;
if(i.all){
this.update();
}else{
if(i.rowCount!=undefined){
this.updateRowCount(i.rowCount);
}else{
for(r in i){
this.updateRow(Number(r));
}
}
}
this.invalidated=[];
},defaultUpdate:function(){
if(!this.domNode){
return;
}
if(this.updating){
this.invalidated.all=true;
return;
}
this.lastScrollTop=this.scrollTop;
this.prerender();
this.scroller.invalidateNodes();
this.setScrollTop(this.lastScrollTop);
this.postrender();
},update:function(){
this.render();
},updateRow:function(_4ad){
_4ad=Number(_4ad);
if(this.updating){
this.invalidated[_4ad]=true;
}else{
this.views.updateRow(_4ad);
this.scroller.rowHeightChanged(_4ad);
}
},updateRows:function(_4ae,_4af){
_4ae=Number(_4ae);
_4af=Number(_4af);
var i;
if(this.updating){
for(i=0;i<_4af;i++){
this.invalidated[i+_4ae]=true;
}
}else{
for(i=0;i<_4af;i++){
this.views.updateRow(i+_4ae,this._skipRowRenormalize);
}
this.scroller.rowHeightChanged(_4ae);
}
},updateRowCount:function(_4b0){
if(this.updating){
this.invalidated.rowCount=_4b0;
}else{
this.rowCount=_4b0;
this._setAutoHeightAttr(this.autoHeight,true);
if(this.layout.cells.length){
this.scroller.updateRowCount(_4b0);
}
this._resize();
if(this.layout.cells.length){
this.setScrollTop(this.scrollTop);
}
}
},updateRowStyles:function(_4b1){
this.views.updateRowStyles(_4b1);
},getRowNode:function(_4b2){
if(this.focus.focusView&&!(this.focus.focusView instanceof dojox.grid._RowSelector)){
return this.focus.focusView.rowNodes[_4b2];
}else{
for(var i=0,_4b3;(_4b3=this.views.views[i]);i++){
if(!(_4b3 instanceof dojox.grid._RowSelector)){
return _4b3.rowNodes[_4b2];
}
}
}
return null;
},rowHeightChanged:function(_4b4){
this.views.renormalizeRow(_4b4);
this.scroller.rowHeightChanged(_4b4);
},fastScroll:true,delayScroll:false,scrollRedrawThreshold:(dojo.isIE?100:50),scrollTo:function(_4b5){
if(!this.fastScroll){
this.setScrollTop(_4b5);
return;
}
var _4b6=Math.abs(this.lastScrollTop-_4b5);
this.lastScrollTop=_4b5;
if(_4b6>this.scrollRedrawThreshold||this.delayScroll){
this.delayScroll=true;
this.scrollTop=_4b5;
this.views.setScrollTop(_4b5);
if(this._pendingScroll){
window.clearTimeout(this._pendingScroll);
}
var _4b7=this;
this._pendingScroll=window.setTimeout(function(){
delete _4b7._pendingScroll;
_4b7.finishScrollJob();
},200);
}else{
this.setScrollTop(_4b5);
}
},finishScrollJob:function(){
this.delayScroll=false;
this.setScrollTop(this.scrollTop);
},setScrollTop:function(_4b8){
this.scroller.scroll(this.views.setScrollTop(_4b8));
},scrollToRow:function(_4b9){
this.setScrollTop(this.scroller.findScrollTop(_4b9)+1);
},styleRowNode:function(_4ba,_4bb){
if(_4bb){
this.rows.styleRowNode(_4ba,_4bb);
}
},_mouseOut:function(e){
this.rows.setOverRow(-2);
},getCell:function(_4bc){
return this.layout.cells[_4bc];
},setCellWidth:function(_4bd,_4be){
this.getCell(_4bd).unitWidth=_4be;
},getCellName:function(_4bf){
return "Cell "+_4bf.index;
},canSort:function(_4c0){
},sort:function(){
},getSortAsc:function(_4c1){
_4c1=_4c1==undefined?this.sortInfo:_4c1;
return Boolean(_4c1>0);
},getSortIndex:function(_4c2){
if(this.sortInfo===0&&this.sortFields){
var _4c3=this.sortFields[0].attribute;
var _4c4;
dojo.some(this.layout.cells,function(c,idx){
if(c.field===_4c3){
_4c4=idx+1;
return true;
}
return false;
});
this.sortInfo=this.sortFields[0].descending?-_4c4:_4c4;
}
_4c2=_4c2==undefined?this.sortInfo:_4c2;
return Math.abs(_4c2)-1;
},setSortIndex:function(_4c5,_4c6){
var si=_4c5+1;
if(_4c6!=undefined){
si*=(_4c6?1:-1);
}else{
if(this.getSortIndex()==_4c5){
si=-this.sortInfo;
}
}
this.setSortInfo(si);
},setSortInfo:function(_4c7){
if(this.canSort(_4c7)){
this.sortInfo=_4c7;
this.sort();
this.update();
}
},doKeyEvent:function(e){
e.dispatch="do"+e.type;
this.onKeyEvent(e);
},_dispatch:function(m,e){
if(m in this){
return this[m](e);
}
return false;
},dispatchKeyEvent:function(e){
this._dispatch(e.dispatch,e);
},dispatchContentEvent:function(e){
this.edit.dispatchEvent(e)||e.sourceView.dispatchContentEvent(e)||this._dispatch(e.dispatch,e);
},dispatchHeaderEvent:function(e){
e.sourceView.dispatchHeaderEvent(e)||this._dispatch("doheader"+e.type,e);
},dokeydown:function(e){
this.onKeyDown(e);
},doclick:function(e){
if(e.cellNode){
this.onCellClick(e);
}else{
this.onRowClick(e);
}
},dodblclick:function(e){
if(e.cellNode){
this.onCellDblClick(e);
}else{
this.onRowDblClick(e);
}
},docontextmenu:function(e){
if(e.cellNode){
this.onCellContextMenu(e);
}else{
this.onRowContextMenu(e);
}
},doheaderclick:function(e){
if(e.cellNode){
this.onHeaderCellClick(e);
}else{
this.onHeaderClick(e);
}
},doheaderdblclick:function(e){
if(e.cellNode){
this.onHeaderCellDblClick(e);
}else{
this.onHeaderDblClick(e);
}
},doheadercontextmenu:function(e){
if(e.cellNode){
this.onHeaderCellContextMenu(e);
}else{
this.onHeaderContextMenu(e);
}
},doStartEdit:function(_4c8,_4c9){
this.onStartEdit(_4c8,_4c9);
},doApplyCellEdit:function(_4ca,_4cb,_4cc){
this.onApplyCellEdit(_4ca,_4cb,_4cc);
},doCancelEdit:function(_4cd){
this.onCancelEdit(_4cd);
},doApplyEdit:function(_4ce){
this.onApplyEdit(_4ce);
},addRow:function(){
this.updateRowCount(this.get("rowCount")+1);
},removeSelectedRows:function(){
if(this.allItemsSelected){
this.updateRowCount(0);
}else{
this.updateRowCount(Math.max(0,this.get("rowCount")-this.selection.getSelected().length));
}
this.selection.clear();
}});
dojox.grid._Grid.markupFactory=function(_4cf,node,ctor,_4d0){
var d=dojo;
var _4d1=function(n){
var w=d.attr(n,"width")||"auto";
if((w!="auto")&&(w.slice(-2)!="em")&&(w.slice(-1)!="%")){
w=parseInt(w,10)+"px";
}
return w;
};
if(!_4cf.structure&&node.nodeName.toLowerCase()=="table"){
_4cf.structure=d.query("> colgroup",node).map(function(cg){
var sv=d.attr(cg,"span");
var v={noscroll:(d.attr(cg,"noscroll")=="true")?true:false,__span:(!!sv?parseInt(sv,10):1),cells:[]};
if(d.hasAttr(cg,"width")){
v.width=_4d1(cg);
}
return v;
});
if(!_4cf.structure.length){
_4cf.structure.push({__span:Infinity,cells:[]});
}
d.query("thead > tr",node).forEach(function(tr,_4d2){
var _4d3=0;
var _4d4=0;
var _4d5;
var _4d6=null;
d.query("> th",tr).map(function(th){
if(!_4d6){
_4d5=0;
_4d6=_4cf.structure[0];
}else{
if(_4d3>=(_4d5+_4d6.__span)){
_4d4++;
_4d5+=_4d6.__span;
var _4d7=_4d6;
_4d6=_4cf.structure[_4d4];
}
}
var cell={name:d.trim(d.attr(th,"name")||th.innerHTML),colSpan:parseInt(d.attr(th,"colspan")||1,10),type:d.trim(d.attr(th,"cellType")||""),id:d.trim(d.attr(th,"id")||"")};
_4d3+=cell.colSpan;
var _4d8=d.attr(th,"rowspan");
if(_4d8){
cell.rowSpan=_4d8;
}
if(d.hasAttr(th,"width")){
cell.width=_4d1(th);
}
if(d.hasAttr(th,"relWidth")){
cell.relWidth=window.parseInt(dojo.attr(th,"relWidth"),10);
}
if(d.hasAttr(th,"hidden")){
cell.hidden=(d.attr(th,"hidden")=="true"||d.attr(th,"hidden")===true);
}
if(_4d0){
_4d0(th,cell);
}
cell.type=cell.type?dojo.getObject(cell.type):dojox.grid.cells.Cell;
if(cell.type&&cell.type.markupFactory){
cell.type.markupFactory(th,cell);
}
if(!_4d6.cells[_4d2]){
_4d6.cells[_4d2]=[];
}
_4d6.cells[_4d2].push(cell);
});
});
}
return new ctor(_4cf,node);
};
})();
}
if(!dojo._hasResource["dojo.DeferredList"]){
dojo._hasResource["dojo.DeferredList"]=true;
dojo.provide("dojo.DeferredList");
dojo.DeferredList=function(list,_4d9,_4da,_4db,_4dc){
var _4dd=[];
dojo.Deferred.call(this);
var self=this;
if(list.length===0&&!_4d9){
this.resolve([0,[]]);
}
var _4de=0;
dojo.forEach(list,function(item,i){
item.then(function(_4df){
if(_4d9){
self.resolve([i,_4df]);
}else{
_4e0(true,_4df);
}
},function(_4e1){
if(_4da){
self.reject(_4e1);
}else{
_4e0(false,_4e1);
}
if(_4db){
return null;
}
throw _4e1;
});
function _4e0(_4e2,_4e3){
_4dd[i]=[_4e2,_4e3];
_4de++;
if(_4de===list.length){
self.resolve(_4dd);
}
};
});
};
dojo.DeferredList.prototype=new dojo.Deferred();
dojo.DeferredList.prototype.gatherResults=function(_4e4){
var d=new dojo.DeferredList(_4e4,false,true,false);
d.addCallback(function(_4e5){
var ret=[];
dojo.forEach(_4e5,function(_4e6){
ret.push(_4e6[1]);
});
return ret;
});
return d;
};
}
if(!dojo._hasResource["dojox.grid._SelectionPreserver"]){
dojo._hasResource["dojox.grid._SelectionPreserver"]=true;
dojo.provide("dojox.grid._SelectionPreserver");
dojo.declare("dojox.grid._SelectionPreserver",null,{constructor:function(_4e7){
this.selection=_4e7;
var grid=this.grid=_4e7.grid;
this.reset();
this._connects=[dojo.connect(grid,"_setStore",this,"reset"),dojo.connect(grid,"_addItem",this,"_reSelectById"),dojo.connect(_4e7,"addToSelection",dojo.hitch(this,"_selectById",true)),dojo.connect(_4e7,"deselect",dojo.hitch(this,"_selectById",false)),dojo.connect(_4e7,"deselectAll",this,"reset")];
},destroy:function(){
this.reset();
dojo.forEach(this._connects,dojo.disconnect);
delete this._connects;
},reset:function(){
this._selectedById={};
},_reSelectById:function(item,_4e8){
if(item&&this.grid._hasIdentity){
this.selection.selected[_4e8]=this._selectedById[this.grid.store.getIdentity(item)];
}
},_selectById:function(_4e9,_4ea){
if(this.selection.mode=="none"||!this.grid._hasIdentity){
return;
}
var item=_4ea,g=this.grid;
if(typeof _4ea=="number"||typeof _4ea=="string"){
var _4eb=g._by_idx[_4ea];
item=_4eb&&_4eb.item;
}
if(item){
this._selectedById[g.store.getIdentity(item)]=!!_4e9;
}
return item;
}});
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins._SelectionPreserver"]){
dojo._hasResource["dojox.grid.enhanced.plugins._SelectionPreserver"]=true;
dojo.provide("dojox.grid.enhanced.plugins._SelectionPreserver");
dojo.declare("dojox.grid.enhanced.plugins._SelectionPreserver",dojox.grid._SelectionPreserver,{constructor:function(_4ec){
var grid=this.grid;
grid.onSelectedById=this.onSelectedById;
this._oldClearData=grid._clearData;
var self=this;
grid._clearData=function(){
self._updateMapping(!grid._noInternalMapping);
self._trustSelection=[];
self._oldClearData.apply(grid,arguments);
};
this._connects.push(dojo.connect(_4ec,"selectRange",dojo.hitch(this,"_updateMapping",true,true,false)),dojo.connect(_4ec,"deselectRange",dojo.hitch(this,"_updateMapping",true,false,false)),dojo.connect(_4ec,"deselectAll",dojo.hitch(this,"_updateMapping",true,false,true)));
},destroy:function(){
this.inherited(arguments);
this.grid._clearData=this._oldClearData;
},reset:function(){
this.inherited(arguments);
this._idMap=[];
this._trustSelection=[];
this._defaultSelected=false;
},_reSelectById:function(item,_4ed){
var s=this.selection,g=this.grid;
if(item&&g._hasIdentity){
var id=g.store.getIdentity(item);
if(this._selectedById[id]===undefined){
if(!this._trustSelection[_4ed]){
s.selected[_4ed]=this._defaultSelected;
}
}else{
s.selected[_4ed]=this._selectedById[id];
}
this._idMap.push(id);
g.onSelectedById(id,_4ed,s.selected[_4ed]);
}
},_selectById:function(_4ee,_4ef){
if(!this.inherited(arguments)){
this._trustSelection[_4ef]=true;
}
},onSelectedById:function(id,_4f0,_4f1){
},_updateMapping:function(_4f2,_4f3,_4f4,from,to){
var s=this.selection,g=this.grid,flag=0,_4f5=0,i,id;
for(i=g.rowCount-1;i>=0;--i){
if(!g._by_idx[i]){
++_4f5;
flag+=s.selected[i]?1:-1;
}else{
id=g._by_idx[i].idty;
if(id&&(_4f2||this._selectedById[id]===undefined)){
this._selectedById[id]=!!s.selected[i];
}
}
}
if(_4f5){
this._defaultSelected=flag>0;
}
if(!_4f4&&from!==undefined&&to!==undefined){
_4f4=!g.usingPagination&&Math.abs(to-from+1)===g.rowCount;
}
if(_4f4&&(!g.usingPagination||g.selectionMode==="single")){
for(i=this._idMap.length-1;i>=0;--i){
this._selectedById[this._idMap[i]]=_4f3;
}
}
}});
}
if(!dojo._hasResource["dojox.grid.DataSelection"]){
dojo._hasResource["dojox.grid.DataSelection"]=true;
dojo.provide("dojox.grid.DataSelection");
dojo.declare("dojox.grid.DataSelection",dojox.grid.Selection,{constructor:function(grid){
if(grid.keepSelection){
this.preserver=new dojox.grid.enhanced.plugins._SelectionPreserver(this);
}
},destroy:function(){
if(this.preserver){
this.preserver.destroy();
}
},getFirstSelected:function(){
var idx=dojox.grid.Selection.prototype.getFirstSelected.call(this);
if(idx==-1){
return null;
}
return this.grid.getItem(idx);
},getNextSelected:function(_4f6){
var _4f7=this.grid.getItemIndex(_4f6);
var idx=dojox.grid.Selection.prototype.getNextSelected.call(this,_4f7);
if(idx==-1){
return null;
}
return this.grid.getItem(idx);
},getSelected:function(){
var _4f8=[];
for(var i=0,l=this.selected.length;i<l;i++){
if(this.selected[i]){
_4f8.push(this.grid.getItem(i));
}
}
return _4f8;
},getSelectedItems:function(_4f9){
var res=[],d=new dojo.Deferred(),defs=[],_4fa,i,len,item,_4fb=[],grid=this.grid,_4fc=this,ps=_4f9||grid.rowsPerPage,_4fd={query:grid.query,sort:grid.getSortProps(),queryOptions:grid.queryOptions,onError:dojo.hitch(d,d.errback)},_4fe=function(def,_4ff,_500){
for(var i=0,len=_500.length;i<len;++i){
res[_4fb[_4ff]+i]=_500[i];
}
def.callback();
};
for(i=0,len=this.selected.length;i<len;++i){
if(this.selected[i]){
item=grid._by_idx[i];
res[i]=item&&item.item;
if(!item){
_4fb.push(i);
}
}
}
for(_4fa=0,len=_4fb.length;_4fa<len;_4fa=i){
for(i=_4fa+1;i<len&&_4fb[i]===_4fb[i-1]+1&&ps<0||i-_4fa<ps;++i){
}
var def=new dojo.Deferred();
var req=dojo.mixin({start:_4fb[_4fa],count:i-_4fa,onComplete:dojo.partial(_4fe,def,_4fa)},_4fd);
defs.push(def);
if(grid._storeLayerFetch){
grid._storeLayerFetch(req);
}else{
grid.store.fetch(req);
}
}
(new dojo.DeferredList(defs)).then(function(){
res=dojo.filter(res,function(item){
return item;
});
if(_4fc.preserver){
var id,dl=[],_501=function(_502,item){
res.push(item);
_502.callback();
},_503=dojo.map(res,function(item){
return grid.store.getIdentity(item);
});
for(id in _4fc.preserver._selectedById){
if(_4fc.preserver._selectedById[id]===true&&dojo.indexOf(_503,id)<0){
var dd=new dojo.Deferred();
grid.store.fetchItemByIdentity({identity:id,onItem:dojo.partial(_501,dd)});
dl.push(dd);
}
}
if(dl.length){
(new dojo.DeferredList(dl)).then(function(){
d.callback(res);
});
return;
}
}
d.callback(res);
},dojo.hitch(d,d.errback));
return d;
},addToSelection:function(_504){
if(this.mode=="none"){
return;
}
var idx=null;
if(typeof _504=="number"||typeof _504=="string"){
idx=_504;
}else{
idx=this.grid.getItemIndex(_504);
}
dojox.grid.Selection.prototype.addToSelection.call(this,idx);
},deselect:function(_505){
if(this.mode=="none"){
return;
}
var idx=null;
if(typeof _505=="number"||typeof _505=="string"){
idx=_505;
}else{
idx=this.grid.getItemIndex(_505);
}
dojox.grid.Selection.prototype.deselect.call(this,idx);
},deselectAll:function(_506){
var idx=null;
if(_506||typeof _506=="number"){
if(typeof _506=="number"||typeof _506=="string"){
idx=_506;
}else{
idx=this.grid.getItemIndex(_506);
}
dojox.grid.Selection.prototype.deselectAll.call(this,idx);
}else{
this.inherited(arguments);
}
}});
}
if(!dojo._hasResource["dojox.grid.DataGrid"]){
dojo._hasResource["dojox.grid.DataGrid"]=true;
dojo.provide("dojox.grid.DataGrid");
dojo.declare("dojox.grid.DataGrid",dojox.grid._Grid,{store:null,query:null,queryOptions:null,fetchText:"...",sortFields:null,updateDelay:1,items:null,_store_connects:null,_by_idty:null,_by_idx:null,_cache:null,_pages:null,_pending_requests:null,_bop:-1,_eop:-1,_requests:0,rowCount:0,_isLoaded:false,_isLoading:false,keepSelection:false,postCreate:function(){
this._pages=[];
this._store_connects=[];
this._by_idty={};
this._by_idx=[];
this._cache=[];
this._pending_requests={};
this._setStore(this.store);
this.inherited(arguments);
},destroy:function(){
this.selection.destroy();
this.inherited(arguments);
},createSelection:function(){
this.selection=new dojox.grid.DataSelection(this);
},get:function(_507,_508){
if(_508&&this.field=="_item"&&!this.fields){
return _508;
}else{
if(_508&&this.fields){
var ret=[];
var s=this.grid.store;
dojo.forEach(this.fields,function(f){
ret=ret.concat(s.getValues(_508,f));
});
return ret;
}else{
if(!_508&&typeof _507==="string"){
return this.inherited(arguments);
}
}
}
return (!_508?this.defaultValue:(!this.field?this.value:(this.field=="_item"?_508:this.grid.store.getValue(_508,this.field))));
},_checkUpdateStatus:function(){
if(this.updateDelay>0){
var _509=false;
if(this._endUpdateDelay){
clearTimeout(this._endUpdateDelay);
delete this._endUpdateDelay;
_509=true;
}
if(!this.updating){
this.beginUpdate();
_509=true;
}
if(_509){
var _50a=this;
this._endUpdateDelay=setTimeout(function(){
delete _50a._endUpdateDelay;
_50a.endUpdate();
},this.updateDelay);
}
}
},_onSet:function(item,_50b,_50c,_50d){
this._checkUpdateStatus();
var idx=this.getItemIndex(item);
if(idx>-1){
this.updateRow(idx);
}
},_createItem:function(item,_50e){
var idty=this._hasIdentity?this.store.getIdentity(item):dojo.toJson(this.query)+":idx:"+_50e+":sort:"+dojo.toJson(this.getSortProps());
var o=this._by_idty[idty]={idty:idty,item:item};
return o;
},_addItem:function(item,_50f,_510){
this._by_idx[_50f]=this._createItem(item,_50f);
if(!_510){
this.updateRow(_50f);
}
},_onNew:function(item,_511){
this._checkUpdateStatus();
var _512=this.get("rowCount");
this._addingItem=true;
this.updateRowCount(_512+1);
this._addingItem=false;
this._addItem(item,_512);
this.showMessage();
},_onDelete:function(item){
this._checkUpdateStatus();
var idx=this._getItemIndex(item,true);
if(idx>=0){
if(this.selection.isSelected(idx)){
this.selection.deselect(idx);
this.selection.selected.splice(idx,1);
}
this._pages=[];
this._bop=-1;
this._eop=-1;
var o=this._by_idx[idx];
this._by_idx.splice(idx,1);
delete this._by_idty[o.idty];
this.updateRowCount(this.get("rowCount")-1);
if(this.get("rowCount")===0){
this.showMessage(this.noDataMessage);
}
}
},_onRevert:function(){
this._refresh();
},setStore:function(_513,_514,_515){
this._setQuery(_514,_515);
this._setStore(_513);
this._refresh(true);
},setQuery:function(_516,_517){
this._setQuery(_516,_517);
this._refresh(true);
},setItems:function(_518){
this.items=_518;
this._setStore(this.store);
this._refresh(true);
},_setQuery:function(_519,_51a){
this.query=_519;
this.queryOptions=_51a||this.queryOptions;
},_setStore:function(_51b){
if(this.store&&this._store_connects){
dojo.forEach(this._store_connects,this.disconnect,this);
}
this.store=_51b;
if(this.store){
var f=this.store.getFeatures();
var h=[];
this._canEdit=!!f["dojo.data.api.Write"]&&!!f["dojo.data.api.Identity"];
this._hasIdentity=!!f["dojo.data.api.Identity"];
if(!!f["dojo.data.api.Notification"]&&!this.items){
h.push(this.connect(this.store,"onSet","_onSet"));
h.push(this.connect(this.store,"onNew","_onNew"));
h.push(this.connect(this.store,"onDelete","_onDelete"));
}
if(this._canEdit){
h.push(this.connect(this.store,"revert","_onRevert"));
}
this._store_connects=h;
}
},_onFetchBegin:function(size,req){
if(!this.scroller){
return;
}
if(this.rowCount!=size){
if(req.isRender){
this.scroller.init(size,this.keepRows,this.rowsPerPage);
this.rowCount=size;
this._setAutoHeightAttr(this.autoHeight,true);
this._skipRowRenormalize=true;
this.prerender();
this._skipRowRenormalize=false;
}else{
this.updateRowCount(size);
}
}
if(!size){
this.views.render();
this._resize();
this.showMessage(this.noDataMessage);
this.focus.initFocusView();
}else{
this.showMessage();
}
},_onFetchComplete:function(_51c,req){
if(!this.scroller){
return;
}
if(_51c&&_51c.length>0){
dojo.forEach(_51c,function(item,idx){
this._addItem(item,req.start+idx,true);
},this);
this.updateRows(req.start,_51c.length);
if(req.isRender){
this.setScrollTop(0);
this.postrender();
}else{
if(this._lastScrollTop){
this.setScrollTop(this._lastScrollTop);
}
}
if(dojo.isIE){
dojo.setSelectable(this.domNode,this.selectable);
dojo.query("th.dojoxGridCell",this.viewsHeaderNode).forEach(function(node){
dojo.setSelectable(node,true);
});
}
}
delete this._lastScrollTop;
if(!this._isLoaded){
this._isLoading=false;
this._isLoaded=true;
}
this._pending_requests[req.start]=false;
},_onFetchError:function(err,req){
delete this._lastScrollTop;
if(!this._isLoaded){
this._isLoading=false;
this._isLoaded=true;
this.showMessage(this.errorMessage);
}
this._pending_requests[req.start]=false;
this.onFetchError(err,req);
},onFetchError:function(err,req){
},_fetch:function(_51d,_51e){
_51d=_51d||0;
if(this.store&&!this._pending_requests[_51d]){
if(!this._isLoaded&&!this._isLoading){
this._isLoading=true;
this.showMessage(this.loadingMessage);
}
this._pending_requests[_51d]=true;
try{
if(this.items){
var _51f=this.items;
var _520=this.store;
this.rowsPerPage=_51f.length;
var req={start:_51d,count:this.rowsPerPage,isRender:_51e};
this._onFetchBegin(_51f.length,req);
var _521=0;
dojo.forEach(_51f,function(i){
if(!_520.isItemLoaded(i)){
_521++;
}
});
if(_521===0){
this._onFetchComplete(_51f,req);
}else{
var _522=function(item){
_521--;
if(_521===0){
this._onFetchComplete(_51f,req);
}
};
dojo.forEach(_51f,function(i){
if(!_520.isItemLoaded(i)){
_520.loadItem({item:i,onItem:_522,scope:this});
}
},this);
}
}else{
this.store.fetch({start:_51d,count:this.rowsPerPage,query:this.query,sort:this.getSortProps(),queryOptions:this.queryOptions,isRender:_51e,onBegin:dojo.hitch(this,"_onFetchBegin"),onComplete:dojo.hitch(this,"_onFetchComplete"),onError:dojo.hitch(this,"_onFetchError")});
}
}
catch(e){
this._onFetchError(e,{start:_51d,count:this.rowsPerPage});
}
}
},_clearData:function(){
this.updateRowCount(0);
this._by_idty={};
this._by_idx=[];
this._pages=[];
this._bop=this._eop=-1;
this._isLoaded=false;
this._isLoading=false;
},getItem:function(idx){
var data=this._by_idx[idx];
if(!data||(data&&!data.item)){
this._preparePage(idx);
return null;
}
return data.item;
},getItemIndex:function(item){
return this._getItemIndex(item,false);
},_getItemIndex:function(item,_523){
if(!_523&&!this.store.isItem(item)){
return -1;
}
var idty=this._hasIdentity?this.store.getIdentity(item):null;
for(var i=0,l=this._by_idx.length;i<l;i++){
var d=this._by_idx[i];
if(d&&((idty&&d.idty==idty)||(d.item===item))){
return i;
}
}
return -1;
},filter:function(_524,_525){
this.query=_524;
if(_525){
this._clearData();
}
this._fetch();
},_getItemAttr:function(idx,attr){
var item=this.getItem(idx);
return (!item?this.fetchText:this.store.getValue(item,attr));
},_render:function(){
if(this.domNode.parentNode){
this.scroller.init(this.get("rowCount"),this.keepRows,this.rowsPerPage);
this.prerender();
this._fetch(0,true);
}
},_requestsPending:function(_526){
return this._pending_requests[_526];
},_rowToPage:function(_527){
return (this.rowsPerPage?Math.floor(_527/this.rowsPerPage):_527);
},_pageToRow:function(_528){
return (this.rowsPerPage?this.rowsPerPage*_528:_528);
},_preparePage:function(_529){
if((_529<this._bop||_529>=this._eop)&&!this._addingItem){
var _52a=this._rowToPage(_529);
this._needPage(_52a);
this._bop=_52a*this.rowsPerPage;
this._eop=this._bop+(this.rowsPerPage||this.get("rowCount"));
}
},_needPage:function(_52b){
if(!this._pages[_52b]){
this._pages[_52b]=true;
this._requestPage(_52b);
}
},_requestPage:function(_52c){
var row=this._pageToRow(_52c);
var _52d=Math.min(this.rowsPerPage,this.get("rowCount")-row);
if(_52d>0){
this._requests++;
if(!this._requestsPending(row)){
setTimeout(dojo.hitch(this,"_fetch",row,false),1);
}
}
},getCellName:function(_52e){
return _52e.field;
},_refresh:function(_52f){
this._clearData();
this._fetch(0,_52f);
},sort:function(){
this.edit.apply();
this._lastScrollTop=this.scrollTop;
this._refresh();
},canSort:function(){
return (!this._isLoading);
},getSortProps:function(){
var c=this.getCell(this.getSortIndex());
if(!c){
if(this.sortFields){
return this.sortFields;
}
return null;
}else{
var desc=c["sortDesc"];
var si=!(this.sortInfo>0);
if(typeof desc=="undefined"){
desc=si;
}else{
desc=si?!desc:desc;
}
return [{attribute:c.field,descending:desc}];
}
},styleRowState:function(_530){
if(this.store&&this.store.getState){
var _531=this.store.getState(_530.index),c="";
for(var i=0,ss=["inflight","error","inserting"],s;s=ss[i];i++){
if(_531[s]){
c=" dojoxGridRow-"+s;
break;
}
}
_530.customClasses+=c;
}
},onStyleRow:function(_532){
this.styleRowState(_532);
this.inherited(arguments);
},scrollToRow:function(_533){
var d=new dojo.Deferred(),_534=this,reqs=this._pending_requests,_535=function(){
_534.setScrollTop(_534.scroller.findScrollTop(_533)+1);
},_536=function(){
for(var i in reqs){
if(reqs[i]){
setTimeout(_536,10);
return;
}
}
_535();
d.callback();
};
_535();
setTimeout(_536,10);
return d;
},canEdit:function(_537,_538){
return this._canEdit;
},_copyAttr:function(idx,attr){
var row={};
var _539={};
var src=this.getItem(idx);
return this.store.getValue(src,attr);
},doStartEdit:function(_53a,_53b){
if(!this._cache[_53b]){
this._cache[_53b]=this._copyAttr(_53b,_53a.field);
}
this.onStartEdit(_53a,_53b);
},doApplyCellEdit:function(_53c,_53d,_53e){
this.store.fetchItemByIdentity({identity:this._by_idx[_53d].idty,onItem:dojo.hitch(this,function(item){
var _53f=this.store.getValue(item,_53e);
if(typeof _53f=="number"){
_53c=isNaN(_53c)?_53c:parseFloat(_53c);
}else{
if(typeof _53f=="boolean"){
_53c=_53c=="true"?true:_53c=="false"?false:_53c;
}else{
if(_53f instanceof Date){
var _540=new Date(_53c);
_53c=isNaN(_540.getTime())?_53c:_540;
}
}
}
this.store.setValue(item,_53e,_53c);
this.onApplyCellEdit(_53c,_53d,_53e);
})});
},doCancelEdit:function(_541){
var _542=this._cache[_541];
if(_542){
this.updateRow(_541);
delete this._cache[_541];
}
this.onCancelEdit.apply(this,arguments);
},doApplyEdit:function(_543,_544){
var _545=this._cache[_543];
this.onApplyEdit(_543);
},removeSelectedRows:function(){
if(this._canEdit){
this.edit.apply();
var fx=dojo.hitch(this,function(_546){
if(_546.length){
dojo.forEach(_546,this.store.deleteItem,this.store);
this.selection.clear();
}
});
if(this.allItemsSelected){
this.store.fetch({query:this.query,queryOptions:this.queryOptions,onComplete:fx});
}else{
fx(this.selection.getSelected());
}
}
}});
dojox.grid.DataGrid.cell_markupFactory=function(_547,node,_548){
var _549=dojo.trim(dojo.attr(node,"field")||"");
if(_549){
_548.field=_549;
}
_548.field=_548.field||_548.name;
var _54a=dojo.trim(dojo.attr(node,"fields")||"");
if(_54a){
_548.fields=_54a.split(",");
}
if(_547){
_547(node,_548);
}
};
dojox.grid.DataGrid.markupFactory=function(_54b,node,ctor,_54c){
return dojox.grid._Grid.markupFactory(_54b,node,ctor,dojo.partial(dojox.grid.DataGrid.cell_markupFactory,_54c));
};
}
if(!dojo._hasResource["dojox.grid.enhanced._Events"]){
dojo._hasResource["dojox.grid.enhanced._Events"]=true;
dojo.provide("dojox.grid.enhanced._Events");
dojo.declare("dojox.grid.enhanced._Events",null,{_events:null,headerCellActiveClass:"dojoxGridHeaderActive",cellActiveClass:"dojoxGridCellActive",rowActiveClass:"dojoxGridRowActive",constructor:function(_54d){
this._events=new dojox.grid._Events();
_54d.mixin(_54d,this);
},dokeyup:function(e){
this.focus.currentArea().keyup(e);
},onKeyDown:function(e){
if(e.altKey||e.metaKey){
return;
}
var dk=dojo.keys;
var _54e=this.focus;
var _54f=this.edit.isEditing();
switch(e.keyCode){
case dk.TAB:
if(e.ctrlKey){
return;
}
_54e.tab(e.shiftKey?-1:1,e);
break;
case dk.UP_ARROW:
case dk.DOWN_ARROW:
if(_54f){
return;
}
_54e.currentArea().move(e.keyCode==dk.UP_ARROW?-1:1,0,e);
break;
case dk.LEFT_ARROW:
case dk.RIGHT_ARROW:
if(_54f){
return;
}
var _550=(e.keyCode==dk.LEFT_ARROW)?1:-1;
if(dojo._isBodyLtr()){
_550*=-1;
}
_54e.currentArea().move(0,_550,e);
break;
case dk.F10:
if(this.menus&&e.shiftKey){
this.onRowContextMenu(e);
}
break;
default:
_54e.currentArea().keydown(e);
break;
}
},domouseup:function(e){
if(e.cellNode){
this.onMouseUp(e);
}else{
this.onRowSelectorMouseUp(e);
}
},domousedown:function(e){
if(!e.cellNode){
this.onRowSelectorMouseDown(e);
}
},onMouseUp:function(e){
this[e.rowIndex==-1?"onHeaderCellMouseUp":"onCellMouseUp"](e);
},onCellMouseDown:function(e){
dojo.addClass(e.cellNode,this.cellActiveClass);
dojo.addClass(e.rowNode,this.rowActiveClass);
},onCellMouseUp:function(e){
dojo.removeClass(e.cellNode,this.cellActiveClass);
dojo.removeClass(e.rowNode,this.rowActiveClass);
},onCellClick:function(e){
this._events.onCellClick.call(this,e);
this.focus.contentMouseEvent(e);
},onCellDblClick:function(e){
if(this.pluginMgr.isFixedCell(e.cell)){
return;
}
if(this._click.length>1&&(!this._click[0]||!this._click[1])){
this._click[0]=this._click[1]=e;
}
this._events.onCellDblClick.call(this,e);
},onRowClick:function(e){
this.edit.rowClick(e);
if(!e.cell||!this.plugin("indirectSelection")){
this.selection.clickSelectEvent(e);
}
},onRowContextMenu:function(e){
if(!this.edit.isEditing()&&this.menus){
this.showMenu(e);
}
},onSelectedRegionContextMenu:function(e){
if(this.selectedRegionMenu){
this.selectedRegionMenu._openMyself({target:e.target,coords:e.keyCode!==dojo.keys.F10&&"pageX" in e?{x:e.pageX,y:e.pageY}:null});
dojo.stopEvent(e);
}
},onHeaderCellMouseOut:function(e){
if(e.cellNode){
dojo.removeClass(e.cellNode,this.cellOverClass);
dojo.removeClass(e.cellNode,this.headerCellActiveClass);
}
},onHeaderCellMouseDown:function(e){
if(e.cellNode){
dojo.addClass(e.cellNode,this.headerCellActiveClass);
}
},onHeaderCellMouseUp:function(e){
if(e.cellNode){
dojo.removeClass(e.cellNode,this.headerCellActiveClass);
}
},onHeaderCellClick:function(e){
this.focus.currentArea("header");
if(!e.cell.isRowSelector){
this._events.onHeaderCellClick.call(this,e);
}
this.focus.headerMouseEvent(e);
},onRowSelectorMouseDown:function(e){
this.focus.focusArea("rowHeader",e);
},onRowSelectorMouseUp:function(e){
},onMouseUpRow:function(e){
if(e.rowIndex!=-1){
this.onRowMouseUp(e);
}
},onRowMouseUp:function(e){
}});
}
if(!dojo._hasResource["dojox.grid.enhanced._FocusManager"]){
dojo._hasResource["dojox.grid.enhanced._FocusManager"]=true;
dojo.provide("dojox.grid.enhanced._FocusManager");
dojo.declare("dojox.grid.enhanced._FocusArea",null,{constructor:function(area,_551){
this._fm=_551;
this._evtStack=[area.name];
var _552=function(){
return true;
};
area.onFocus=area.onFocus||_552;
area.onBlur=area.onBlur||_552;
area.onMove=area.onMove||_552;
area.onKeyUp=area.onKeyUp||_552;
area.onKeyDown=area.onKeyDown||_552;
dojo.mixin(this,area);
},move:function(_553,_554,evt){
if(this.name){
var i,len=this._evtStack.length;
for(i=len-1;i>=0;--i){
if(this._fm._areas[this._evtStack[i]].onMove(_553,_554,evt)===false){
return false;
}
}
}
return true;
},_onKeyEvent:function(evt,_555){
if(this.name){
var i,len=this._evtStack.length;
for(i=len-1;i>=0;--i){
if(this._fm._areas[this._evtStack[i]][_555](evt,false)===false){
return false;
}
}
for(i=0;i<len;++i){
if(this._fm._areas[this._evtStack[i]][_555](evt,true)===false){
return false;
}
}
}
return true;
},keydown:function(evt){
return this._onKeyEvent(evt,"onKeyDown");
},keyup:function(evt){
return this._onKeyEvent(evt,"onKeyUp");
},contentMouseEventPlanner:function(){
return 0;
},headerMouseEventPlanner:function(){
return 0;
}});
dojo.declare("dojox.grid.enhanced._FocusManager",dojox.grid._FocusManager,{_stopEvent:function(evt){
try{
if(evt&&evt.preventDefault){
dojo.stopEvent(evt);
}
}
catch(e){
}
},constructor:function(grid){
this.grid=grid;
this._areas={};
this._areaQueue=[];
this._contentMouseEventHandlers=[];
this._headerMouseEventHandlers=[];
this._currentAreaIdx=-1;
this._gridBlured=true;
this._connects.push(dojo.connect(grid,"onBlur",this,"_doBlur"));
this._connects.push(dojo.connect(grid.scroller,"renderPage",this,"_delayedCellFocus"));
this.addArea({name:"header",onFocus:dojo.hitch(this,this.focusHeader),onBlur:dojo.hitch(this,this._blurHeader),onMove:dojo.hitch(this,this._navHeader),getRegions:dojo.hitch(this,this._findHeaderCells),onRegionFocus:dojo.hitch(this,this.doColHeaderFocus),onRegionBlur:dojo.hitch(this,this.doColHeaderBlur),onKeyDown:dojo.hitch(this,this._onHeaderKeyDown)});
this.addArea({name:"content",onFocus:dojo.hitch(this,this._focusContent),onBlur:dojo.hitch(this,this._blurContent),onMove:dojo.hitch(this,this._navContent),onKeyDown:dojo.hitch(this,this._onContentKeyDown)});
this.addArea({name:"editableCell",onFocus:dojo.hitch(this,this._focusEditableCell),onBlur:dojo.hitch(this,this._blurEditableCell),onKeyDown:dojo.hitch(this,this._onEditableCellKeyDown),onContentMouseEvent:dojo.hitch(this,this._onEditableCellMouseEvent),contentMouseEventPlanner:function(evt,_556){
return -1;
}});
this.placeArea("header");
this.placeArea("content");
this.placeArea("editableCell");
this.placeArea("editableCell","above","content");
},destroy:function(){
for(var name in this._areas){
var area=this._areas[name];
dojo.forEach(area._connects,dojo.disconnect);
area._connects=null;
if(area.uninitialize){
area.uninitialize();
}
}
this.inherited(arguments);
},addArea:function(area){
if(area.name&&dojo.isString(area.name)){
if(this._areas[area.name]){
dojo.forEach(area._connects,dojo.disconnect);
}
this._areas[area.name]=new dojox.grid.enhanced._FocusArea(area,this);
if(area.onHeaderMouseEvent){
this._headerMouseEventHandlers.push(area.name);
}
if(area.onContentMouseEvent){
this._contentMouseEventHandlers.push(area.name);
}
}
},getArea:function(_557){
return this._areas[_557];
},_bindAreaEvents:function(){
var area,hdl,_558=this._areas;
dojo.forEach(this._areaQueue,function(name){
area=_558[name];
if(!area._initialized&&dojo.isFunction(area.initialize)){
area.initialize();
area._initialized=true;
}
if(area.getRegions){
area._regions=area.getRegions()||[];
dojo.forEach(area._connects||[],dojo.disconnect);
area._connects=[];
dojo.forEach(area._regions,function(r){
if(area.onRegionFocus){
hdl=dojo.connect(r,"onfocus",area.onRegionFocus);
area._connects.push(hdl);
}
if(area.onRegionBlur){
hdl=dojo.connect(r,"onblur",area.onRegionBlur);
area._connects.push(hdl);
}
});
}
});
},removeArea:function(_559){
var area=this._areas[_559];
if(area){
this.ignoreArea(_559);
var i=dojo.indexOf(this._contentMouseEventHandlers,_559);
if(i>=0){
this._contentMouseEventHandlers.splice(i,1);
}
i=dojo.indexOf(this._headerMouseEventHandlers,_559);
if(i>=0){
this._headerMouseEventHandlers.splice(i,1);
}
dojo.forEach(area._connects,dojo.disconnect);
if(area.uninitialize){
area.uninitialize();
}
delete this._areas[_559];
}
},currentArea:function(_55a,_55b){
var idx,cai=this._currentAreaIdx;
if(dojo.isString(_55a)&&(idx=dojo.indexOf(this._areaQueue,_55a))>=0){
if(cai!=idx){
this.tabbingOut=false;
if(_55b&&cai>=0&&cai<this._areaQueue.length){
this._areas[this._areaQueue[cai]].onBlur();
}
this._currentAreaIdx=idx;
}
}else{
return (cai<0||cai>=this._areaQueue.length)?new dojox.grid.enhanced._FocusArea({},this):this._areas[this._areaQueue[this._currentAreaIdx]];
}
return null;
},placeArea:function(name,pos,_55c){
if(!this._areas[name]){
return;
}
var idx=dojo.indexOf(this._areaQueue,_55c);
switch(pos){
case "after":
if(idx>=0){
++idx;
}
case "before":
if(idx>=0){
this._areaQueue.splice(idx,0,name);
break;
}
default:
this._areaQueue.push(name);
break;
case "above":
var _55d=true;
case "below":
var _55e=this._areas[_55c];
if(_55e){
if(_55d){
_55e._evtStack.push(name);
}else{
_55e._evtStack.splice(0,0,name);
}
}
}
},ignoreArea:function(name){
this._areaQueue=dojo.filter(this._areaQueue,function(_55f){
return _55f!=name;
});
},focusArea:function(_560,evt){
var idx;
if(typeof _560=="number"){
idx=_560<0?this._areaQueue.length+_560:_560;
}else{
idx=dojo.indexOf(this._areaQueue,dojo.isString(_560)?_560:(_560&&_560.name));
}
if(idx<0){
idx=0;
}
var step=idx-this._currentAreaIdx;
this._gridBlured=false;
if(step){
this.tab(step,evt);
}else{
this.currentArea().onFocus(evt,step);
}
},tab:function(step,evt){
this._gridBlured=false;
this.tabbingOut=false;
if(step===0){
return;
}
var cai=this._currentAreaIdx;
var dir=step>0?1:-1;
if(cai<0||cai>=this._areaQueue.length){
cai=(this._currentAreaIdx+=step);
}else{
var _561=this._areas[this._areaQueue[cai]].onBlur(evt,step);
if(_561===true){
cai=(this._currentAreaIdx+=step);
}else{
if(dojo.isString(_561)&&this._areas[_561]){
cai=this._currentAreaIdx=dojo.indexOf(this._areaQueue,_561);
}
}
}
for(;cai>=0&&cai<this._areaQueue.length;cai+=dir){
this._currentAreaIdx=cai;
if(this._areaQueue[cai]&&this._areas[this._areaQueue[cai]].onFocus(evt,step)){
return;
}
}
this.tabbingOut=true;
if(step<0){
this._currentAreaIdx=-1;
dijit.focus(this.grid.domNode);
}else{
this._currentAreaIdx=this._areaQueue.length;
dijit.focus(this.grid.lastFocusNode);
}
},_onMouseEvent:function(type,evt){
var _562=type.toLowerCase(),_563=this["_"+_562+"MouseEventHandlers"],res=dojo.map(_563,function(_564){
return {"area":_564,"idx":this._areas[_564][_562+"MouseEventPlanner"](evt,_563)};
},this).sort(function(a,b){
return b.idx-a.idx;
}),_565=dojo.map(res,function(_566){
return res.area;
}),i=res.length;
while(--i>=0){
if(this._areas[res[i].area]["on"+type+"MouseEvent"](evt,_565)===false){
return;
}
}
},contentMouseEvent:function(evt){
this._onMouseEvent("Content",evt);
},headerMouseEvent:function(evt){
this._onMouseEvent("Header",evt);
},initFocusView:function(){
this.focusView=this.grid.views.getFirstScrollingView()||this.focusView||this.grid.views.views[0];
this._bindAreaEvents();
},isNavHeader:function(){
return this._areaQueue[this._currentAreaIdx]=="header";
},previousKey:function(e){
this.tab(-1,e);
},nextKey:function(e){
this.tab(1,e);
},setFocusCell:function(_567,_568){
if(_567){
this.currentArea(this.grid.edit.isEditing()?"editableCell":"content",true);
this.focusView=_567.view;
this._focusifyCellNode(false);
this.cell=_567;
this.rowIndex=_568;
this._focusifyCellNode(true);
}
this.grid.onCellFocus(this.cell,this.rowIndex);
},doFocus:function(e){
if(e&&e.target==e.currentTarget&&!this.tabbingOut){
if(this._gridBlured){
this._gridBlured=false;
if(this._currentAreaIdx<0||this._currentAreaIdx>=this._areaQueue.length){
this.focusArea(0,e);
}else{
this.focusArea(this._currentAreaIdx,e);
}
}
}else{
this.tabbingOut=false;
}
dojo.stopEvent(e);
},_doBlur:function(){
this._gridBlured=true;
},doLastNodeFocus:function(e){
if(this.tabbingOut){
this.tabbingOut=false;
}else{
this.focusArea(-1,e);
}
},_delayedHeaderFocus:function(){
if(this.isNavHeader()){
this.focusHeader();
}
},_delayedCellFocus:function(){
},_changeMenuBindNode:function(_569,_56a){
var hm=this.grid.headerMenu;
if(hm&&this._contextMenuBindNode==_569){
hm.unBindDomNode(_569);
hm.bindDomNode(_56a);
this._contextMenuBindNode=_56a;
}
},focusHeader:function(evt,step){
var _56b=false;
this.inherited(arguments);
if(this._colHeadNode&&dojo.style(this._colHeadNode,"display")!="none"){
dijit.focus(this._colHeadNode);
this._stopEvent(evt);
_56b=true;
}
return _56b;
},_blurHeader:function(evt,step){
if(this._colHeadNode){
dojo.removeClass(this._colHeadNode,this.focusClass);
}
dojo.removeAttr(this.grid.domNode,"aria-activedescendant");
this._changeMenuBindNode(this.grid.domNode,this.grid.viewsHeaderNode);
this._colHeadNode=this._colHeadFocusIdx=null;
return true;
},_navHeader:function(_56c,_56d,evt){
var _56e=_56d<0?-1:1,_56f=dojo.indexOf(this._findHeaderCells(),this._colHeadNode);
if(_56f>=0&&(evt.shiftKey&&evt.ctrlKey)){
this.colSizeAdjust(evt,_56f,_56e*5);
return;
}
this.move(_56c,_56d);
},_onHeaderKeyDown:function(e,_570){
if(_570){
var dk=dojo.keys;
switch(e.keyCode){
case dk.ENTER:
case dk.SPACE:
var _571=this.getHeaderIndex();
if(_571>=0&&!this.grid.pluginMgr.isFixedCell(e.cell)){
this.grid.setSortIndex(_571,null,e);
dojo.stopEvent(e);
}
break;
}
}
return true;
},_setActiveColHeader:function(){
this.inherited(arguments);
dijit.focus(this._colHeadNode);
},findAndFocusGridCell:function(){
this._focusContent();
},_focusContent:function(evt,step){
var _572=true;
var _573=(this.grid.rowCount===0);
if(this.isNoFocusCell()&&!_573){
for(var i=0,cell=this.grid.getCell(0);cell&&cell.hidden;cell=this.grid.getCell(++i)){
}
this.setFocusIndex(0,cell?i:0);
}else{
if(this.cell&&!_573){
if(this.focusView&&!this.focusView.rowNodes[this.rowIndex]){
this.grid.scrollToRow(this.rowIndex);
this.focusGrid();
}else{
this.setFocusIndex(this.rowIndex,this.cell.index);
}
}else{
_572=false;
}
}
if(_572){
this._stopEvent(evt);
}
return _572;
},_blurContent:function(evt,step){
this._focusifyCellNode(false);
return true;
},_navContent:function(_574,_575,evt){
if((this.rowIndex===0&&_574<0)||(this.rowIndex===this.grid.rowCount-1&&_574>0)){
return;
}
this._colHeadNode=null;
this.move(_574,_575,evt);
if(evt){
dojo.stopEvent(evt);
}
},_onContentKeyDown:function(e,_576){
if(_576){
var dk=dojo.keys,s=this.grid.scroller;
switch(e.keyCode){
case dk.ENTER:
case dk.SPACE:
var g=this.grid;
if(g.indirectSelection){
break;
}
g.selection.clickSelect(this.rowIndex,dojo.isCopyKey(e),e.shiftKey);
g.onRowClick(e);
dojo.stopEvent(e);
break;
case dk.PAGE_UP:
if(this.rowIndex!==0){
if(this.rowIndex!=s.firstVisibleRow+1){
this._navContent(s.firstVisibleRow-this.rowIndex,0);
}else{
this.grid.setScrollTop(s.findScrollTop(this.rowIndex-1));
this._navContent(s.firstVisibleRow-s.lastVisibleRow+1,0);
}
dojo.stopEvent(e);
}
break;
case dk.PAGE_DOWN:
if(this.rowIndex+1!=this.grid.rowCount){
dojo.stopEvent(e);
if(this.rowIndex!=s.lastVisibleRow-1){
this._navContent(s.lastVisibleRow-this.rowIndex-1,0);
}else{
this.grid.setScrollTop(s.findScrollTop(this.rowIndex+1));
this._navContent(s.lastVisibleRow-s.firstVisibleRow-1,0);
}
dojo.stopEvent(e);
}
break;
}
}
return true;
},_blurFromEditableCell:false,_isNavigating:false,_navElems:null,_focusEditableCell:function(evt,step){
var _577=false;
if(this._isNavigating){
_577=true;
}else{
if(this.grid.edit.isEditing()&&this.cell){
if(this._blurFromEditableCell||!this._blurEditableCell(evt,step)){
this.setFocusIndex(this.rowIndex,this.cell.index);
_577=true;
}
this._stopEvent(evt);
}
}
return _577;
},_applyEditableCell:function(){
try{
this.grid.edit.apply();
}
catch(e){
console.warn("_FocusManager._applyEditableCell() error:",e);
}
},_blurEditableCell:function(evt,step){
this._blurFromEditableCell=false;
if(this._isNavigating){
var _578=true;
if(evt){
var _579=this._navElems;
var _57a=_579.lowest||_579.first;
var _57b=_579.last||_579.highest||_57a;
var _57c=dojo.isIE?evt.srcElement:evt.target;
_578=_57c==(step>0?_57b:_57a);
}
if(_578){
this._isNavigating=false;
dojo.setSelectable(this.cell.getNode(this.rowIndex),false);
return "content";
}
return false;
}else{
if(this.grid.edit.isEditing()&&this.cell){
if(!step||typeof step!="number"){
return false;
}
var dir=step>0?1:-1;
var cc=this.grid.layout.cellCount;
for(var cell,col=this.cell.index+dir;col>=0&&col<cc;col+=dir){
cell=this.grid.getCell(col);
if(cell.editable){
this.cell=cell;
this._blurFromEditableCell=true;
return false;
}
}
if((this.rowIndex>0||dir==1)&&(this.rowIndex<this.grid.rowCount||dir==-1)){
this.rowIndex+=dir;
for(col=dir>0?0:cc-1;col>=0&&col<cc;col+=dir){
cell=this.grid.getCell(col);
if(cell.editable){
this.cell=cell;
break;
}
}
this._applyEditableCell();
return "content";
}
}
}
return true;
},_initNavigatableElems:function(){
this._navElems=dijit._getTabNavigable(this.cell.getNode(this.rowIndex));
},_onEditableCellKeyDown:function(e,_57d){
var dk=dojo.keys,g=this.grid,edit=g.edit,_57e=false,_57f=true;
switch(e.keyCode){
case dk.ENTER:
if(_57d&&edit.isEditing()){
this._applyEditableCell();
_57e=true;
dojo.stopEvent(e);
}
case dk.SPACE:
if(!_57d&&this._isNavigating){
_57f=false;
break;
}
if(_57d){
if(!this.cell.editable&&this.cell.navigatable){
this._initNavigatableElems();
var _580=this._navElems.lowest||this._navElems.first;
if(_580){
this._isNavigating=true;
dojo.setSelectable(this.cell.getNode(this.rowIndex),true);
dijit.focus(_580);
dojo.stopEvent(e);
this.currentArea("editableCell",true);
break;
}
}
if(!_57e&&!edit.isEditing()&&!g.pluginMgr.isFixedCell(this.cell)){
edit.setEditCell(this.cell,this.rowIndex);
}
if(_57e){
this.currentArea("content",true);
}else{
if(this.cell.editable&&g.canEdit()){
this.currentArea("editableCell",true);
}
}
}
break;
case dk.PAGE_UP:
case dk.PAGE_DOWN:
if(!_57d&&edit.isEditing()){
_57f=false;
}
break;
case dk.ESCAPE:
if(!_57d){
edit.cancel();
this.currentArea("content",true);
}
}
return _57f;
},_onEditableCellMouseEvent:function(evt){
if(evt.type=="click"){
var cell=this.cell||evt.cell;
if(cell&&!cell.editable&&cell.navigatable){
this._initNavigatableElems();
if(this._navElems.lowest||this._navElems.first){
var _581=dojo.isIE?evt.srcElement:evt.target;
if(_581!=cell.getNode(evt.rowIndex)){
this._isNavigating=true;
this.focusArea("editableCell",evt);
dojo.setSelectable(cell.getNode(evt.rowIndex),true);
dijit.focus(_581);
return false;
}
}
}else{
if(this.grid.singleClickEdit){
this.currentArea("editableCell");
return false;
}
}
}
return true;
}});
}
if(!dojo._hasResource["dojox.grid.enhanced._PluginManager"]){
dojo._hasResource["dojox.grid.enhanced._PluginManager"]=true;
dojo.provide("dojox.grid.enhanced._PluginManager");
dojo.declare("dojox.grid.enhanced._PluginManager",null,{_options:null,_plugins:null,_connects:null,constructor:function(_582){
this.grid=_582;
this._store=_582.store;
this._options={};
this._plugins=[];
this._connects=[];
this._parseProps(this.grid.plugins);
_582.connect(_582,"_setStore",dojo.hitch(this,function(_583){
if(this._store!==_583){
this.forEach("onSetStore",[_583,this._store]);
this._store=_583;
}
}));
},startup:function(){
this.forEach("onStartUp");
},preInit:function(){
this.grid.focus.destroy();
this.grid.focus=new dojox.grid.enhanced._FocusManager(this.grid);
new dojox.grid.enhanced._Events(this.grid);
this._init(true);
this.forEach("onPreInit");
},postInit:function(){
this._init(false);
dojo.forEach(this.grid.views.views,this._initView,this);
this._connects.push(dojo.connect(this.grid.views,"addView",dojo.hitch(this,this._initView)));
if(this._plugins.length>0){
var edit=this.grid.edit;
if(edit){
edit.styleRow=function(_584){
};
}
}
this.forEach("onPostInit");
},forEach:function(func,args){
dojo.forEach(this._plugins,function(p){
if(!p||!p[func]){
return;
}
p[func].apply(p,args?args:[]);
});
},_parseProps:function(_585){
if(!_585){
return;
}
var p,_586={},_587=this._options,grid=this.grid;
var _588=dojox.grid.enhanced._PluginManager.registry;
for(p in _585){
if(_585[p]){
this._normalize(p,_585,_588,_586);
}
}
if(_587.dnd||_587.indirectSelection){
_587.columnReordering=false;
}
dojo.mixin(grid,_587);
},_normalize:function(p,_589,_58a,_58b){
if(!_58a[p]){
throw new Error("Plugin "+p+" is required.");
}
if(_58b[p]){
throw new Error("Recursive cycle dependency is not supported.");
}
var _58c=this._options;
if(_58c[p]){
return _58c[p];
}
_58b[p]=true;
_58c[p]=dojo.mixin({},_58a[p],dojo.isObject(_589[p])?_589[p]:{});
var _58d=_58c[p]["dependency"];
if(_58d){
if(!dojo.isArray(_58d)){
_58d=_58c[p]["dependency"]=[_58d];
}
dojo.forEach(_58d,function(_58e){
if(!this._normalize(_58e,_589,_58a,_58b)){
throw new Error("Plugin "+_58e+" is required.");
}
},this);
}
delete _58b[p];
return _58c[p];
},_init:function(pre){
var p,_58f,_590=this._options;
for(p in _590){
_58f=_590[p]["preInit"];
if((pre?_58f:!_58f)&&_590[p]["class"]&&!this.pluginExisted(p)){
this.loadPlugin(p);
}
}
},loadPlugin:function(name){
var _591=this._options[name];
if(!_591){
return null;
}
var _592=this.getPlugin(name);
if(_592){
return _592;
}
var _593=_591["dependency"];
dojo.forEach(_593,function(_594){
if(!this.loadPlugin(_594)){
throw new Error("Plugin "+_594+" is required.");
}
},this);
var cls=_591["class"];
delete _591["class"];
_592=new this.getPluginClazz(cls)(this.grid,_591);
this._plugins.push(_592);
return _592;
},_initView:function(view){
if(!view){
return;
}
dojox.grid.util.funnelEvents(view.contentNode,view,"doContentEvent",["mouseup","mousemove"]);
dojox.grid.util.funnelEvents(view.headerNode,view,"doHeaderEvent",["mouseup"]);
},pluginExisted:function(name){
return !!this.getPlugin(name);
},getPlugin:function(name){
var _595=this._plugins;
name=name.toLowerCase();
for(var i=0,len=_595.length;i<len;i++){
if(name==_595[i]["name"].toLowerCase()){
return _595[i];
}
}
return null;
},getPluginClazz:function(_596){
if(dojo.isFunction(_596)){
return _596;
}
var _597="Please make sure Plugin \""+_596+"\" is existed.";
try{
var cls=dojo.getObject(_596);
if(!cls){
throw new Error(_597);
}
return cls;
}
catch(e){
throw new Error(_597);
}
},isFixedCell:function(cell){
return cell&&(cell.isRowSelector||cell.fixedPos);
},destroy:function(){
dojo.forEach(this._connects,dojo.disconnect);
this.forEach("destroy");
if(this.grid.unwrap){
this.grid.unwrap();
}
delete this._connects;
delete this._plugins;
delete this._options;
}});
dojox.grid.enhanced._PluginManager.registerPlugin=function(_598,_599){
if(!_598){
console.warn("Failed to register plugin, class missed!");
return;
}
var cls=dojox.grid.enhanced._PluginManager;
cls.registry=cls.registry||{};
cls.registry[_598.prototype.name]=dojo.mixin({"class":_598},(_599?_599:{}));
};
}
if(!dojo._hasResource["dojox.grid.EnhancedGrid"]){
dojo._hasResource["dojox.grid.EnhancedGrid"]=true;
dojo.provide("dojox.grid.EnhancedGrid");
dojo.experimental("dojox.grid.EnhancedGrid");
dojo.declare("dojox.grid.EnhancedGrid",dojox.grid.DataGrid,{plugins:null,pluginMgr:null,_pluginMgrClass:dojox.grid.enhanced._PluginManager,postMixInProperties:function(){
this._nls=dojo.i18n.getLocalization("dojox.grid.enhanced","EnhancedGrid",this.lang);
this.inherited(arguments);
},postCreate:function(){
this.pluginMgr=new this._pluginMgrClass(this);
this.pluginMgr.preInit();
this.inherited(arguments);
this.pluginMgr.postInit();
},plugin:function(name){
return this.pluginMgr.getPlugin(name);
},startup:function(){
this.inherited(arguments);
this.pluginMgr.startup();
},createSelection:function(){
this.selection=new dojox.grid.enhanced.DataSelection(this);
},canSort:function(_59a,_59b){
return true;
},doKeyEvent:function(e){
try{
var view=this.focus.focusView;
view.content.decorateEvent(e);
if(!e.cell){
view.header.decorateEvent(e);
}
}
catch(e){
}
this.inherited(arguments);
},doApplyCellEdit:function(_59c,_59d,_59e){
if(!_59e){
this.invalidated[_59d]=true;
return;
}
this.inherited(arguments);
},mixin:function(_59f,_5a0){
var _5a1={};
for(var p in _5a0){
if(p=="_inherited"||p=="declaredClass"||p=="constructor"||_5a0["privates"]&&_5a0["privates"][p]){
continue;
}
_5a1[p]=_5a0[p];
}
dojo.mixin(_59f,_5a1);
},_copyAttr:function(idx,attr){
if(!attr){
return;
}
return this.inherited(arguments);
},_getHeaderHeight:function(){
this.inherited(arguments);
return dojo.marginBox(this.viewsHeaderNode).h;
},_fetch:function(_5a2,_5a3){
if(this.items){
return this.inherited(arguments);
}
_5a2=_5a2||0;
if(this.store&&!this._pending_requests[_5a2]){
if(!this._isLoaded&&!this._isLoading){
this._isLoading=true;
this.showMessage(this.loadingMessage);
}
this._pending_requests[_5a2]=true;
try{
var req={start:_5a2,count:this.rowsPerPage,query:this.query,sort:this.getSortProps(),queryOptions:this.queryOptions,isRender:_5a3,onBegin:dojo.hitch(this,"_onFetchBegin"),onComplete:dojo.hitch(this,"_onFetchComplete"),onError:dojo.hitch(this,"_onFetchError")};
this._storeLayerFetch(req);
}
catch(e){
this._onFetchError(e,{start:_5a2,count:this.rowsPerPage});
}
}
return 0;
},_storeLayerFetch:function(req){
this.store.fetch(req);
},getCellByField:function(_5a4){
return dojo.filter(this.layout.cells,function(cell){
return cell.field==_5a4;
})[0];
},onMouseUp:function(e){
},createView:function(){
var view=this.inherited(arguments);
if(dojo.isMoz){
var _5a5=function(_5a6,_5a7){
for(var n=_5a6;n&&_5a7(n);n=n.parentNode){
}
return n;
};
var _5a8=function(_5a9){
var name=_5a9.toUpperCase();
return function(node){
return node.tagName!=name;
};
};
var func=view.header.getCellX;
view.header.getCellX=function(e){
var x=func.call(view.header,e);
var n=_5a5(e.target,_5a8("th"));
if(n&&n!==e.target&&dojo.isDescendant(e.target,n)){
x+=n.firstChild.offsetLeft;
}
return x;
};
}
return view;
},destroy:function(){
delete this._nls;
this.pluginMgr.destroy();
this.inherited(arguments);
}});
dojo.provide("dojox.grid.enhanced.DataSelection");
dojo.declare("dojox.grid.enhanced.DataSelection",dojox.grid.DataSelection,{constructor:function(grid){
if(grid.keepSelection){
if(this.preserver){
this.preserver.destroy();
}
this.preserver=new dojox.grid.enhanced.plugins._SelectionPreserver(this);
}
},_range:function(_5aa,inTo){
this.grid._selectingRange=true;
this.inherited(arguments);
this.grid._selectingRange=false;
this.onChanged();
},deselectAll:function(_5ab){
this.grid._selectingRange=true;
this.inherited(arguments);
this.grid._selectingRange=false;
this.onChanged();
}});
dojox.grid.EnhancedGrid.markupFactory=function(_5ac,node,ctor,_5ad){
return dojox.grid._Grid.markupFactory(_5ac,node,ctor,dojo.partial(dojox.grid.DataGrid.cell_markupFactory,_5ad));
};
dojox.grid.EnhancedGrid.registerPlugin=function(_5ae,_5af){
dojox.grid.enhanced._PluginManager.registerPlugin(_5ae,_5af);
};
}
if(!dojo._hasResource["dojox.grid.enhanced._Plugin"]){
dojo._hasResource["dojox.grid.enhanced._Plugin"]=true;
dojo.provide("dojox.grid.enhanced._Plugin");
dojo.declare("dojox.grid.enhanced._Plugin",null,{name:"plugin",grid:null,option:{},_connects:[],_subscribes:[],privates:{},constructor:function(_5b0,_5b1){
this.grid=_5b0;
this.option=_5b1;
this._connects=[];
this._subscribes=[];
this.privates=dojo.mixin({},dojox.grid.enhanced._Plugin.prototype);
this.init();
},init:function(){
},onPreInit:function(){
},onPostInit:function(){
},onStartUp:function(){
},connect:function(obj,_5b2,_5b3){
var conn=dojo.connect(obj,_5b2,this,_5b3);
this._connects.push(conn);
return conn;
},disconnect:function(_5b4){
dojo.some(this._connects,function(conn,i,_5b5){
if(conn==_5b4){
dojo.disconnect(_5b4);
_5b5.splice(i,1);
return true;
}
return false;
});
},subscribe:function(_5b6,_5b7){
var _5b8=dojo.subscribe(_5b6,this,_5b7);
this._subscribes.push(_5b8);
return _5b8;
},unsubscribe:function(_5b9){
dojo.some(this._subscribes,function(_5ba,i,_5bb){
if(_5ba==_5b9){
dojo.unsubscribe(_5b9);
_5bb.splice(i,1);
return true;
}
return false;
});
},onSetStore:function(_5bc){
},destroy:function(){
dojo.forEach(this._connects,dojo.disconnect);
dojo.forEach(this._subscribes,dojo.unsubscribe);
delete this._connects;
delete this._subscribes;
delete this.option;
delete this.privates;
}});
}
if(!dojo._hasResource["dojo.dnd.move"]){
dojo._hasResource["dojo.dnd.move"]=true;
dojo.provide("dojo.dnd.move");
dojo.declare("dojo.dnd.move.constrainedMoveable",dojo.dnd.Moveable,{constraints:function(){
},within:false,markupFactory:function(_5bd,node){
return new dojo.dnd.move.constrainedMoveable(node,_5bd);
},constructor:function(node,_5be){
if(!_5be){
_5be={};
}
this.constraints=_5be.constraints;
this.within=_5be.within;
},onFirstMove:function(_5bf){
var c=this.constraintBox=this.constraints.call(this,_5bf);
c.r=c.l+c.w;
c.b=c.t+c.h;
if(this.within){
var mb=dojo._getMarginSize(_5bf.node);
c.r-=mb.w;
c.b-=mb.h;
}
},onMove:function(_5c0,_5c1){
var c=this.constraintBox,s=_5c0.node.style;
this.onMoving(_5c0,_5c1);
_5c1.l=_5c1.l<c.l?c.l:c.r<_5c1.l?c.r:_5c1.l;
_5c1.t=_5c1.t<c.t?c.t:c.b<_5c1.t?c.b:_5c1.t;
s.left=_5c1.l+"px";
s.top=_5c1.t+"px";
this.onMoved(_5c0,_5c1);
}});
dojo.declare("dojo.dnd.move.boxConstrainedMoveable",dojo.dnd.move.constrainedMoveable,{box:{},markupFactory:function(_5c2,node){
return new dojo.dnd.move.boxConstrainedMoveable(node,_5c2);
},constructor:function(node,_5c3){
var box=_5c3&&_5c3.box;
this.constraints=function(){
return box;
};
}});
dojo.declare("dojo.dnd.move.parentConstrainedMoveable",dojo.dnd.move.constrainedMoveable,{area:"content",markupFactory:function(_5c4,node){
return new dojo.dnd.move.parentConstrainedMoveable(node,_5c4);
},constructor:function(node,_5c5){
var area=_5c5&&_5c5.area;
this.constraints=function(){
var n=this.node.parentNode,s=dojo.getComputedStyle(n),mb=dojo._getMarginBox(n,s);
if(area=="margin"){
return mb;
}
var t=dojo._getMarginExtents(n,s);
mb.l+=t.l,mb.t+=t.t,mb.w-=t.w,mb.h-=t.h;
if(area=="border"){
return mb;
}
t=dojo._getBorderExtents(n,s);
mb.l+=t.l,mb.t+=t.t,mb.w-=t.w,mb.h-=t.h;
if(area=="padding"){
return mb;
}
t=dojo._getPadExtents(n,s);
mb.l+=t.l,mb.t+=t.t,mb.w-=t.w,mb.h-=t.h;
return mb;
};
}});
dojo.dnd.constrainedMover=dojo.dnd.move.constrainedMover;
dojo.dnd.boxConstrainedMover=dojo.dnd.move.boxConstrainedMover;
dojo.dnd.parentConstrainedMover=dojo.dnd.move.parentConstrainedMover;
}
if(!dojo._hasResource["dojo.dnd.TimedMoveable"]){
dojo._hasResource["dojo.dnd.TimedMoveable"]=true;
dojo.provide("dojo.dnd.TimedMoveable");
(function(){
var _5c6=dojo.dnd.Moveable.prototype.onMove;
dojo.declare("dojo.dnd.TimedMoveable",dojo.dnd.Moveable,{timeout:40,constructor:function(node,_5c7){
if(!_5c7){
_5c7={};
}
if(_5c7.timeout&&typeof _5c7.timeout=="number"&&_5c7.timeout>=0){
this.timeout=_5c7.timeout;
}
},markupFactory:function(_5c8,node){
return new dojo.dnd.TimedMoveable(node,_5c8);
},onMoveStop:function(_5c9){
if(_5c9._timer){
clearTimeout(_5c9._timer);
_5c6.call(this,_5c9,_5c9._leftTop);
}
dojo.dnd.Moveable.prototype.onMoveStop.apply(this,arguments);
},onMove:function(_5ca,_5cb){
_5ca._leftTop=_5cb;
if(!_5ca._timer){
var _5cc=this;
_5ca._timer=setTimeout(function(){
_5ca._timer=null;
_5c6.call(_5cc,_5ca,_5ca._leftTop);
},this.timeout);
}
}});
})();
}
if(!dojo._hasResource["dojo.fx.Toggler"]){
dojo._hasResource["dojo.fx.Toggler"]=true;
dojo.provide("dojo.fx.Toggler");
dojo.declare("dojo.fx.Toggler",null,{node:null,showFunc:dojo.fadeIn,hideFunc:dojo.fadeOut,showDuration:200,hideDuration:200,constructor:function(args){
var _5cd=this;
dojo.mixin(_5cd,args);
_5cd.node=args.node;
_5cd._showArgs=dojo.mixin({},args);
_5cd._showArgs.node=_5cd.node;
_5cd._showArgs.duration=_5cd.showDuration;
_5cd.showAnim=_5cd.showFunc(_5cd._showArgs);
_5cd._hideArgs=dojo.mixin({},args);
_5cd._hideArgs.node=_5cd.node;
_5cd._hideArgs.duration=_5cd.hideDuration;
_5cd.hideAnim=_5cd.hideFunc(_5cd._hideArgs);
dojo.connect(_5cd.showAnim,"beforeBegin",dojo.hitch(_5cd.hideAnim,"stop",true));
dojo.connect(_5cd.hideAnim,"beforeBegin",dojo.hitch(_5cd.showAnim,"stop",true));
},show:function(_5ce){
return this.showAnim.play(_5ce||0);
},hide:function(_5cf){
return this.hideAnim.play(_5cf||0);
}});
}
if(!dojo._hasResource["dojo.fx"]){
dojo._hasResource["dojo.fx"]=true;
dojo.provide("dojo.fx");
(function(){
var d=dojo,_5d0={_fire:function(evt,args){
if(this[evt]){
this[evt].apply(this,args||[]);
}
return this;
}};
var _5d1=function(_5d2){
this._index=-1;
this._animations=_5d2||[];
this._current=this._onAnimateCtx=this._onEndCtx=null;
this.duration=0;
d.forEach(this._animations,function(a){
this.duration+=a.duration;
if(a.delay){
this.duration+=a.delay;
}
},this);
};
d.extend(_5d1,{_onAnimate:function(){
this._fire("onAnimate",arguments);
},_onEnd:function(){
d.disconnect(this._onAnimateCtx);
d.disconnect(this._onEndCtx);
this._onAnimateCtx=this._onEndCtx=null;
if(this._index+1==this._animations.length){
this._fire("onEnd");
}else{
this._current=this._animations[++this._index];
this._onAnimateCtx=d.connect(this._current,"onAnimate",this,"_onAnimate");
this._onEndCtx=d.connect(this._current,"onEnd",this,"_onEnd");
this._current.play(0,true);
}
},play:function(_5d3,_5d4){
if(!this._current){
this._current=this._animations[this._index=0];
}
if(!_5d4&&this._current.status()=="playing"){
return this;
}
var _5d5=d.connect(this._current,"beforeBegin",this,function(){
this._fire("beforeBegin");
}),_5d6=d.connect(this._current,"onBegin",this,function(arg){
this._fire("onBegin",arguments);
}),_5d7=d.connect(this._current,"onPlay",this,function(arg){
this._fire("onPlay",arguments);
d.disconnect(_5d5);
d.disconnect(_5d6);
d.disconnect(_5d7);
});
if(this._onAnimateCtx){
d.disconnect(this._onAnimateCtx);
}
this._onAnimateCtx=d.connect(this._current,"onAnimate",this,"_onAnimate");
if(this._onEndCtx){
d.disconnect(this._onEndCtx);
}
this._onEndCtx=d.connect(this._current,"onEnd",this,"_onEnd");
this._current.play.apply(this._current,arguments);
return this;
},pause:function(){
if(this._current){
var e=d.connect(this._current,"onPause",this,function(arg){
this._fire("onPause",arguments);
d.disconnect(e);
});
this._current.pause();
}
return this;
},gotoPercent:function(_5d8,_5d9){
this.pause();
var _5da=this.duration*_5d8;
this._current=null;
d.some(this._animations,function(a){
if(a.duration<=_5da){
this._current=a;
return true;
}
_5da-=a.duration;
return false;
});
if(this._current){
this._current.gotoPercent(_5da/this._current.duration,_5d9);
}
return this;
},stop:function(_5db){
if(this._current){
if(_5db){
for(;this._index+1<this._animations.length;++this._index){
this._animations[this._index].stop(true);
}
this._current=this._animations[this._index];
}
var e=d.connect(this._current,"onStop",this,function(arg){
this._fire("onStop",arguments);
d.disconnect(e);
});
this._current.stop();
}
return this;
},status:function(){
return this._current?this._current.status():"stopped";
},destroy:function(){
if(this._onAnimateCtx){
d.disconnect(this._onAnimateCtx);
}
if(this._onEndCtx){
d.disconnect(this._onEndCtx);
}
}});
d.extend(_5d1,_5d0);
dojo.fx.chain=function(_5dc){
return new _5d1(_5dc);
};
var _5dd=function(_5de){
this._animations=_5de||[];
this._connects=[];
this._finished=0;
this.duration=0;
d.forEach(_5de,function(a){
var _5df=a.duration;
if(a.delay){
_5df+=a.delay;
}
if(this.duration<_5df){
this.duration=_5df;
}
this._connects.push(d.connect(a,"onEnd",this,"_onEnd"));
},this);
this._pseudoAnimation=new d.Animation({curve:[0,1],duration:this.duration});
var self=this;
d.forEach(["beforeBegin","onBegin","onPlay","onAnimate","onPause","onStop","onEnd"],function(evt){
self._connects.push(d.connect(self._pseudoAnimation,evt,function(){
self._fire(evt,arguments);
}));
});
};
d.extend(_5dd,{_doAction:function(_5e0,args){
d.forEach(this._animations,function(a){
a[_5e0].apply(a,args);
});
return this;
},_onEnd:function(){
if(++this._finished>this._animations.length){
this._fire("onEnd");
}
},_call:function(_5e1,args){
var t=this._pseudoAnimation;
t[_5e1].apply(t,args);
},play:function(_5e2,_5e3){
this._finished=0;
this._doAction("play",arguments);
this._call("play",arguments);
return this;
},pause:function(){
this._doAction("pause",arguments);
this._call("pause",arguments);
return this;
},gotoPercent:function(_5e4,_5e5){
var ms=this.duration*_5e4;
d.forEach(this._animations,function(a){
a.gotoPercent(a.duration<ms?1:(ms/a.duration),_5e5);
});
this._call("gotoPercent",arguments);
return this;
},stop:function(_5e6){
this._doAction("stop",arguments);
this._call("stop",arguments);
return this;
},status:function(){
return this._pseudoAnimation.status();
},destroy:function(){
d.forEach(this._connects,dojo.disconnect);
}});
d.extend(_5dd,_5d0);
dojo.fx.combine=function(_5e7){
return new _5dd(_5e7);
};
dojo.fx.wipeIn=function(args){
var node=args.node=d.byId(args.node),s=node.style,o;
var anim=d.animateProperty(d.mixin({properties:{height:{start:function(){
o=s.overflow;
s.overflow="hidden";
if(s.visibility=="hidden"||s.display=="none"){
s.height="1px";
s.display="";
s.visibility="";
return 1;
}else{
var _5e8=d.style(node,"height");
return Math.max(_5e8,1);
}
},end:function(){
return node.scrollHeight;
}}}},args));
d.connect(anim,"onEnd",function(){
s.height="auto";
s.overflow=o;
});
return anim;
};
dojo.fx.wipeOut=function(args){
var node=args.node=d.byId(args.node),s=node.style,o;
var anim=d.animateProperty(d.mixin({properties:{height:{end:1}}},args));
d.connect(anim,"beforeBegin",function(){
o=s.overflow;
s.overflow="hidden";
s.display="";
});
d.connect(anim,"onEnd",function(){
s.overflow=o;
s.height="auto";
s.display="none";
});
return anim;
};
dojo.fx.slideTo=function(args){
var node=args.node=d.byId(args.node),top=null,left=null;
var init=(function(n){
return function(){
var cs=d.getComputedStyle(n);
var pos=cs.position;
top=(pos=="absolute"?n.offsetTop:parseInt(cs.top)||0);
left=(pos=="absolute"?n.offsetLeft:parseInt(cs.left)||0);
if(pos!="absolute"&&pos!="relative"){
var ret=d.position(n,true);
top=ret.y;
left=ret.x;
n.style.position="absolute";
n.style.top=top+"px";
n.style.left=left+"px";
}
};
})(node);
init();
var anim=d.animateProperty(d.mixin({properties:{top:args.top||0,left:args.left||0}},args));
d.connect(anim,"beforeBegin",anim,init);
return anim;
};
})();
}
if(!dojo._hasResource["dijit.form._FormMixin"]){
dojo._hasResource["dijit.form._FormMixin"]=true;
dojo.provide("dijit.form._FormMixin");
dojo.declare("dijit.form._FormMixin",null,{state:"",reset:function(){
dojo.forEach(this.getDescendants(),function(_5e9){
if(_5e9.reset){
_5e9.reset();
}
});
},validate:function(){
var _5ea=false;
return dojo.every(dojo.map(this.getDescendants(),function(_5eb){
_5eb._hasBeenBlurred=true;
var _5ec=_5eb.disabled||!_5eb.validate||_5eb.validate();
if(!_5ec&&!_5ea){
dojo.window.scrollIntoView(_5eb.containerNode||_5eb.domNode);
_5eb.focus();
_5ea=true;
}
return _5ec;
}),function(item){
return item;
});
},setValues:function(val){
dojo.deprecated(this.declaredClass+"::setValues() is deprecated. Use set('value', val) instead.","","2.0");
return this.set("value",val);
},_setValueAttr:function(obj){
var map={};
dojo.forEach(this.getDescendants(),function(_5ed){
if(!_5ed.name){
return;
}
var _5ee=map[_5ed.name]||(map[_5ed.name]=[]);
_5ee.push(_5ed);
});
for(var name in map){
if(!map.hasOwnProperty(name)){
continue;
}
var _5ef=map[name],_5f0=dojo.getObject(name,false,obj);
if(_5f0===undefined){
continue;
}
if(!dojo.isArray(_5f0)){
_5f0=[_5f0];
}
if(typeof _5ef[0].checked=="boolean"){
dojo.forEach(_5ef,function(w,i){
w.set("value",dojo.indexOf(_5f0,w.value)!=-1);
});
}else{
if(_5ef[0].multiple){
_5ef[0].set("value",_5f0);
}else{
dojo.forEach(_5ef,function(w,i){
w.set("value",_5f0[i]);
});
}
}
}
},getValues:function(){
dojo.deprecated(this.declaredClass+"::getValues() is deprecated. Use get('value') instead.","","2.0");
return this.get("value");
},_getValueAttr:function(){
var obj={};
dojo.forEach(this.getDescendants(),function(_5f1){
var name=_5f1.name;
if(!name||_5f1.disabled){
return;
}
var _5f2=_5f1.get("value");
if(typeof _5f1.checked=="boolean"){
if(/Radio/.test(_5f1.declaredClass)){
if(_5f2!==false){
dojo.setObject(name,_5f2,obj);
}else{
_5f2=dojo.getObject(name,false,obj);
if(_5f2===undefined){
dojo.setObject(name,null,obj);
}
}
}else{
var ary=dojo.getObject(name,false,obj);
if(!ary){
ary=[];
dojo.setObject(name,ary,obj);
}
if(_5f2!==false){
ary.push(_5f2);
}
}
}else{
var prev=dojo.getObject(name,false,obj);
if(typeof prev!="undefined"){
if(dojo.isArray(prev)){
prev.push(_5f2);
}else{
dojo.setObject(name,[prev,_5f2],obj);
}
}else{
dojo.setObject(name,_5f2,obj);
}
}
});
return obj;
},isValid:function(){
return this.state=="";
},onValidStateChange:function(_5f3){
},_getState:function(){
var _5f4=dojo.map(this._descendants,function(w){
return w.get("state")||"";
});
return dojo.indexOf(_5f4,"Error")>=0?"Error":dojo.indexOf(_5f4,"Incomplete")>=0?"Incomplete":"";
},disconnectChildren:function(){
dojo.forEach(this._childConnections||[],dojo.hitch(this,"disconnect"));
dojo.forEach(this._childWatches||[],function(w){
w.unwatch();
});
},connectChildren:function(_5f5){
var _5f6=this;
this.disconnectChildren();
this._descendants=this.getDescendants();
var set=_5f5?function(name,val){
_5f6[name]=val;
}:dojo.hitch(this,"_set");
set("value",this.get("value"));
set("state",this._getState());
var _5f7=(this._childConnections=[]),_5f8=(this._childWatches=[]);
dojo.forEach(dojo.filter(this._descendants,function(item){
return item.validate;
}),function(_5f9){
dojo.forEach(["state","disabled"],function(attr){
_5f8.push(_5f9.watch(attr,function(attr,_5fa,_5fb){
_5f6.set("state",_5f6._getState());
}));
});
});
var _5fc=function(){
if(_5f6._onChangeDelayTimer){
clearTimeout(_5f6._onChangeDelayTimer);
}
_5f6._onChangeDelayTimer=setTimeout(function(){
delete _5f6._onChangeDelayTimer;
_5f6._set("value",_5f6.get("value"));
},10);
};
dojo.forEach(dojo.filter(this._descendants,function(item){
return item.onChange;
}),function(_5fd){
_5f7.push(_5f6.connect(_5fd,"onChange",_5fc));
_5f8.push(_5fd.watch("disabled",_5fc));
});
},startup:function(){
this.inherited(arguments);
this.connectChildren(true);
this.watch("state",function(attr,_5fe,_5ff){
this.onValidStateChange(_5ff=="");
});
},destroy:function(){
this.disconnectChildren();
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit._DialogMixin"]){
dojo._hasResource["dijit._DialogMixin"]=true;
dojo.provide("dijit._DialogMixin");
dojo.declare("dijit._DialogMixin",null,{attributeMap:dijit._Widget.prototype.attributeMap,execute:function(_600){
},onCancel:function(){
},onExecute:function(){
},_onSubmit:function(){
this.onExecute();
this.execute(this.get("value"));
},_getFocusItems:function(){
var _601=dijit._getTabNavigable(this.containerNode);
this._firstFocusItem=_601.lowest||_601.first||this.closeButtonNode||this.domNode;
this._lastFocusItem=_601.last||_601.highest||this._firstFocusItem;
}});
}
if(!dojo._hasResource["dijit.DialogUnderlay"]){
dojo._hasResource["dijit.DialogUnderlay"]=true;
dojo.provide("dijit.DialogUnderlay");
dojo.declare("dijit.DialogUnderlay",[dijit._Widget,dijit._Templated],{templateString:"<div class='dijitDialogUnderlayWrapper'><div class='dijitDialogUnderlay' dojoAttachPoint='node'></div></div>",dialogId:"","class":"",attributeMap:{id:"domNode"},_setDialogIdAttr:function(id){
dojo.attr(this.node,"id",id+"_underlay");
this._set("dialogId",id);
},_setClassAttr:function(_602){
this.node.className="dijitDialogUnderlay "+_602;
this._set("class",_602);
},postCreate:function(){
dojo.body().appendChild(this.domNode);
},layout:function(){
var is=this.node.style,os=this.domNode.style;
os.display="none";
var _603=dojo.window.getBox();
os.top=_603.t+"px";
os.left=_603.l+"px";
is.width=_603.w+"px";
is.height=_603.h+"px";
os.display="block";
},show:function(){
this.domNode.style.display="block";
this.layout();
this.bgIframe=new dijit.BackgroundIframe(this.domNode);
},hide:function(){
this.bgIframe.destroy();
delete this.bgIframe;
this.domNode.style.display="none";
}});
}
if(!dojo._hasResource["dijit.layout._ContentPaneResizeMixin"]){
dojo._hasResource["dijit.layout._ContentPaneResizeMixin"]=true;
dojo.provide("dijit.layout._ContentPaneResizeMixin");
dojo.declare("dijit.layout._ContentPaneResizeMixin",null,{doLayout:true,isContainer:true,isLayoutContainer:true,_startChildren:function(){
dojo.forEach(this.getChildren(),function(_604){
_604.startup();
_604._started=true;
});
},startup:function(){
if(this._started){
return;
}
var _605=dijit._Contained.prototype.getParent.call(this);
this._childOfLayoutWidget=_605&&_605.isLayoutContainer;
this._needLayout=!this._childOfLayoutWidget;
this.inherited(arguments);
this._startChildren();
if(this._isShown()){
this._onShow();
}
if(!this._childOfLayoutWidget){
this.connect(dojo.isIE?this.domNode:dojo.global,"onresize",function(){
this._needLayout=!this._childOfLayoutWidget;
this.resize();
});
}
},_checkIfSingleChild:function(){
var _606=dojo.query("> *",this.containerNode).filter(function(node){
return node.tagName!=="SCRIPT";
}),_607=_606.filter(function(node){
return dojo.hasAttr(node,"data-dojo-type")||dojo.hasAttr(node,"dojoType")||dojo.hasAttr(node,"widgetId");
}),_608=dojo.filter(_607.map(dijit.byNode),function(_609){
return _609&&_609.domNode&&_609.resize;
});
if(_606.length==_607.length&&_608.length==1){
this._singleChild=_608[0];
}else{
delete this._singleChild;
}
dojo.toggleClass(this.containerNode,this.baseClass+"SingleChild",!!this._singleChild);
},resize:function(_60a,_60b){
if(!this._wasShown&&this.open!==false){
this._onShow();
}
this._resizeCalled=true;
this._scheduleLayout(_60a,_60b);
},_scheduleLayout:function(_60c,_60d){
if(this._isShown()){
this._layout(_60c,_60d);
}else{
this._needLayout=true;
this._changeSize=_60c;
this._resultSize=_60d;
}
},_layout:function(_60e,_60f){
if(_60e){
dojo.marginBox(this.domNode,_60e);
}
var cn=this.containerNode;
if(cn===this.domNode){
var mb=_60f||{};
dojo.mixin(mb,_60e||{});
if(!("h" in mb)||!("w" in mb)){
mb=dojo.mixin(dojo.marginBox(cn),mb);
}
this._contentBox=dijit.layout.marginBox2contentBox(cn,mb);
}else{
this._contentBox=dojo.contentBox(cn);
}
this._layoutChildren();
delete this._needLayout;
},_layoutChildren:function(){
if(this.doLayout){
this._checkIfSingleChild();
}
if(this._singleChild&&this._singleChild.resize){
var cb=this._contentBox||dojo.contentBox(this.containerNode);
this._singleChild.resize({w:cb.w,h:cb.h});
}else{
dojo.forEach(this.getChildren(),function(_610){
if(_610.resize){
_610.resize();
}
});
}
},_isShown:function(){
if(this._childOfLayoutWidget){
if(this._resizeCalled&&"open" in this){
return this.open;
}
return this._resizeCalled;
}else{
if("open" in this){
return this.open;
}else{
var node=this.domNode,_611=this.domNode.parentNode;
return (node.style.display!="none")&&(node.style.visibility!="hidden")&&!dojo.hasClass(node,"dijitHidden")&&_611&&_611.style&&(_611.style.display!="none");
}
}
},_onShow:function(){
if(this._needLayout){
this._layout(this._changeSize,this._resultSize);
}
this.inherited(arguments);
this._wasShown=true;
}});
}
if(!dojo._hasResource["dojo.html"]){
dojo._hasResource["dojo.html"]=true;
dojo.provide("dojo.html");
dojo.getObject("html",true,dojo);
(function(){
var _612=0,d=dojo;
dojo.html._secureForInnerHtml=function(cont){
return cont.replace(/(?:\s*<!DOCTYPE\s[^>]+>|<title[^>]*>[\s\S]*?<\/title>)/ig,"");
};
dojo.html._emptyNode=dojo.empty;
dojo.html._setNodeContent=function(node,cont){
d.empty(node);
if(cont){
if(typeof cont=="string"){
cont=d._toDom(cont,node.ownerDocument);
}
if(!cont.nodeType&&d.isArrayLike(cont)){
for(var _613=cont.length,i=0;i<cont.length;i=_613==cont.length?i+1:0){
d.place(cont[i],node,"last");
}
}else{
d.place(cont,node,"last");
}
}
return node;
};
dojo.declare("dojo.html._ContentSetter",null,{node:"",content:"",id:"",cleanContent:false,extractContent:false,parseContent:false,parserScope:dojo._scopeName,startup:true,constructor:function(_614,node){
dojo.mixin(this,_614||{});
node=this.node=dojo.byId(this.node||node);
if(!this.id){
this.id=["Setter",(node)?node.id||node.tagName:"",_612++].join("_");
}
},set:function(cont,_615){
if(undefined!==cont){
this.content=cont;
}
if(_615){
this._mixin(_615);
}
this.onBegin();
this.setContent();
this.onEnd();
return this.node;
},setContent:function(){
var node=this.node;
if(!node){
throw new Error(this.declaredClass+": setContent given no node");
}
try{
node=dojo.html._setNodeContent(node,this.content);
}
catch(e){
var _616=this.onContentError(e);
try{
node.innerHTML=_616;
}
catch(e){
console.error("Fatal "+this.declaredClass+".setContent could not change content due to "+e.message,e);
}
}
this.node=node;
},empty:function(){
if(this.parseResults&&this.parseResults.length){
dojo.forEach(this.parseResults,function(w){
if(w.destroy){
w.destroy();
}
});
delete this.parseResults;
}
dojo.html._emptyNode(this.node);
},onBegin:function(){
var cont=this.content;
if(dojo.isString(cont)){
if(this.cleanContent){
cont=dojo.html._secureForInnerHtml(cont);
}
if(this.extractContent){
var _617=cont.match(/<body[^>]*>\s*([\s\S]+)\s*<\/body>/im);
if(_617){
cont=_617[1];
}
}
}
this.empty();
this.content=cont;
return this.node;
},onEnd:function(){
if(this.parseContent){
this._parse();
}
return this.node;
},tearDown:function(){
delete this.parseResults;
delete this.node;
delete this.content;
},onContentError:function(err){
return "Error occured setting content: "+err;
},_mixin:function(_618){
var _619={},key;
for(key in _618){
if(key in _619){
continue;
}
this[key]=_618[key];
}
},_parse:function(){
var _61a=this.node;
try{
var _61b={};
dojo.forEach(["dir","lang","textDir"],function(name){
if(this[name]){
_61b[name]=this[name];
}
},this);
this.parseResults=dojo.parser.parse({rootNode:_61a,noStart:!this.startup,inherited:_61b,scope:this.parserScope});
}
catch(e){
this._onError("Content",e,"Error parsing in _ContentSetter#"+this.id);
}
},_onError:function(type,err,_61c){
var _61d=this["on"+type+"Error"].call(this,err);
if(_61c){
console.error(_61c,err);
}else{
if(_61d){
dojo.html._setNodeContent(this.node,_61d,true);
}
}
}});
dojo.html.set=function(node,cont,_61e){
if(undefined==cont){
console.warn("dojo.html.set: no cont argument provided, using empty string");
cont="";
}
if(!_61e){
return dojo.html._setNodeContent(node,cont,true);
}else{
var op=new dojo.html._ContentSetter(dojo.mixin(_61e,{content:cont,node:node}));
return op.set();
}
};
})();
}
if(!dojo._hasResource["dijit.layout.ContentPane"]){
dojo._hasResource["dijit.layout.ContentPane"]=true;
dojo.provide("dijit.layout.ContentPane");
dojo.declare("dijit.layout.ContentPane",[dijit._Widget,dijit.layout._ContentPaneResizeMixin],{href:"",extractContent:false,parseOnLoad:true,parserScope:dojo._scopeName,preventCache:false,preload:false,refreshOnShow:false,loadingMessage:"<span class='dijitContentPaneLoading'>${loadingState}</span>",errorMessage:"<span class='dijitContentPaneError'>${errorState}</span>",isLoaded:false,baseClass:"dijitContentPane",ioArgs:{},onLoadDeferred:null,attributeMap:dojo.delegate(dijit._Widget.prototype.attributeMap,{title:[]}),stopParser:true,template:false,create:function(_61f,_620){
if((!_61f||!_61f.template)&&_620&&!("href" in _61f)&&!("content" in _61f)){
var df=dojo.doc.createDocumentFragment();
_620=dojo.byId(_620);
while(_620.firstChild){
df.appendChild(_620.firstChild);
}
_61f=dojo.delegate(_61f,{content:df});
}
this.inherited(arguments,[_61f,_620]);
},postMixInProperties:function(){
this.inherited(arguments);
var _621=dojo.i18n.getLocalization("dijit","loading",this.lang);
this.loadingMessage=dojo.string.substitute(this.loadingMessage,_621);
this.errorMessage=dojo.string.substitute(this.errorMessage,_621);
},buildRendering:function(){
this.inherited(arguments);
if(!this.containerNode){
this.containerNode=this.domNode;
}
this.domNode.title="";
if(!dojo.attr(this.domNode,"role")){
dijit.setWaiRole(this.domNode,"group");
}
},_startChildren:function(){
this.inherited(arguments);
if(this._contentSetter){
dojo.forEach(this._contentSetter.parseResults,function(obj){
if(!obj._started&&!obj._destroyed&&dojo.isFunction(obj.startup)){
obj.startup();
obj._started=true;
}
},this);
}
},setHref:function(href){
dojo.deprecated("dijit.layout.ContentPane.setHref() is deprecated. Use set('href', ...) instead.","","2.0");
return this.set("href",href);
},_setHrefAttr:function(href){
this.cancel();
this.onLoadDeferred=new dojo.Deferred(dojo.hitch(this,"cancel"));
this.onLoadDeferred.addCallback(dojo.hitch(this,"onLoad"));
this._set("href",href);
if(this.preload||(this._created&&this._isShown())){
this._load();
}else{
this._hrefChanged=true;
}
return this.onLoadDeferred;
},setContent:function(data){
dojo.deprecated("dijit.layout.ContentPane.setContent() is deprecated.  Use set('content', ...) instead.","","2.0");
this.set("content",data);
},_setContentAttr:function(data){
this._set("href","");
this.cancel();
this.onLoadDeferred=new dojo.Deferred(dojo.hitch(this,"cancel"));
if(this._created){
this.onLoadDeferred.addCallback(dojo.hitch(this,"onLoad"));
}
this._setContent(data||"");
this._isDownloaded=false;
return this.onLoadDeferred;
},_getContentAttr:function(){
return this.containerNode.innerHTML;
},cancel:function(){
if(this._xhrDfd&&(this._xhrDfd.fired==-1)){
this._xhrDfd.cancel();
}
delete this._xhrDfd;
this.onLoadDeferred=null;
},uninitialize:function(){
if(this._beingDestroyed){
this.cancel();
}
this.inherited(arguments);
},destroyRecursive:function(_622){
if(this._beingDestroyed){
return;
}
this.inherited(arguments);
},_onShow:function(){
this.inherited(arguments);
if(this.href){
if(!this._xhrDfd&&(!this.isLoaded||this._hrefChanged||this.refreshOnShow)){
return this.refresh();
}
}
},refresh:function(){
this.cancel();
this.onLoadDeferred=new dojo.Deferred(dojo.hitch(this,"cancel"));
this.onLoadDeferred.addCallback(dojo.hitch(this,"onLoad"));
this._load();
return this.onLoadDeferred;
},_load:function(){
this._setContent(this.onDownloadStart(),true);
var self=this;
var _623={preventCache:(this.preventCache||this.refreshOnShow),url:this.href,handleAs:"text"};
if(dojo.isObject(this.ioArgs)){
dojo.mixin(_623,this.ioArgs);
}
var hand=(this._xhrDfd=(this.ioMethod||dojo.xhrGet)(_623));
hand.addCallback(function(html){
try{
self._isDownloaded=true;
self._setContent(html,false);
self.onDownloadEnd();
}
catch(err){
self._onError("Content",err);
}
delete self._xhrDfd;
return html;
});
hand.addErrback(function(err){
if(!hand.canceled){
self._onError("Download",err);
}
delete self._xhrDfd;
return err;
});
delete this._hrefChanged;
},_onLoadHandler:function(data){
this._set("isLoaded",true);
try{
this.onLoadDeferred.callback(data);
}
catch(e){
console.error("Error "+this.widgetId+" running custom onLoad code: "+e.message);
}
},_onUnloadHandler:function(){
this._set("isLoaded",false);
try{
this.onUnload();
}
catch(e){
console.error("Error "+this.widgetId+" running custom onUnload code: "+e.message);
}
},destroyDescendants:function(){
if(this.isLoaded){
this._onUnloadHandler();
}
var _624=this._contentSetter;
dojo.forEach(this.getChildren(),function(_625){
if(_625.destroyRecursive){
_625.destroyRecursive();
}
});
if(_624){
dojo.forEach(_624.parseResults,function(_626){
if(_626.destroyRecursive&&_626.domNode&&_626.domNode.parentNode==dojo.body()){
_626.destroyRecursive();
}
});
delete _624.parseResults;
}
dojo.html._emptyNode(this.containerNode);
delete this._singleChild;
},_setContent:function(cont,_627){
this.destroyDescendants();
var _628=this._contentSetter;
if(!(_628&&_628 instanceof dojo.html._ContentSetter)){
_628=this._contentSetter=new dojo.html._ContentSetter({node:this.containerNode,_onError:dojo.hitch(this,this._onError),onContentError:dojo.hitch(this,function(e){
var _629=this.onContentError(e);
try{
this.containerNode.innerHTML=_629;
}
catch(e){
console.error("Fatal "+this.id+" could not change content due to "+e.message,e);
}
})});
}
var _62a=dojo.mixin({cleanContent:this.cleanContent,extractContent:this.extractContent,parseContent:this.parseOnLoad,parserScope:this.parserScope,startup:false,dir:this.dir,lang:this.lang},this._contentSetterParams||{});
_628.set((dojo.isObject(cont)&&cont.domNode)?cont.domNode:cont,_62a);
delete this._contentSetterParams;
if(this.doLayout){
this._checkIfSingleChild();
}
if(!_627){
if(this._started){
this._startChildren();
this._scheduleLayout();
}
this._onLoadHandler(cont);
}
},_onError:function(type,err,_62b){
this.onLoadDeferred.errback(err);
var _62c=this["on"+type+"Error"].call(this,err);
if(_62b){
console.error(_62b,err);
}else{
if(_62c){
this._setContent(_62c,true);
}
}
},onLoad:function(data){
},onUnload:function(){
},onDownloadStart:function(){
return this.loadingMessage;
},onContentError:function(_62d){
},onDownloadError:function(_62e){
return this.errorMessage;
},onDownloadEnd:function(){
}});
}
if(!dojo._hasResource["dijit.TooltipDialog"]){
dojo._hasResource["dijit.TooltipDialog"]=true;
dojo.provide("dijit.TooltipDialog");
dojo.declare("dijit.TooltipDialog",[dijit.layout.ContentPane,dijit._Templated,dijit.form._FormMixin,dijit._DialogMixin],{title:"",doLayout:false,autofocus:true,baseClass:"dijitTooltipDialog",_firstFocusItem:null,_lastFocusItem:null,templateString:dojo.cache("dijit","templates/TooltipDialog.html","<div role=\"presentation\" tabIndex=\"-1\">\r\n\t<div class=\"dijitTooltipContainer\" role=\"presentation\">\r\n\t\t<div class =\"dijitTooltipContents dijitTooltipFocusNode\" dojoAttachPoint=\"containerNode\" role=\"dialog\"></div>\r\n\t</div>\r\n\t<div class=\"dijitTooltipConnector\" role=\"presentation\"></div>\r\n</div>\r\n"),_setTitleAttr:function(_62f){
this.containerNode.title=_62f;
this._set("title",_62f);
},postCreate:function(){
this.inherited(arguments);
this.connect(this.containerNode,"onkeypress","_onKey");
},orient:function(node,_630,_631){
var newC="dijitTooltipAB"+(_631.charAt(1)=="L"?"Left":"Right")+" dijitTooltip"+(_631.charAt(0)=="T"?"Below":"Above");
dojo.replaceClass(this.domNode,newC,this._currentOrientClass||"");
this._currentOrientClass=newC;
},focus:function(){
this._getFocusItems(this.containerNode);
dijit.focus(this._firstFocusItem);
},onOpen:function(pos){
this.orient(this.domNode,pos.aroundCorner,pos.corner);
this._onShow();
},onClose:function(){
this.onHide();
},_onKey:function(evt){
var node=evt.target;
var dk=dojo.keys;
if(evt.charOrCode===dk.TAB){
this._getFocusItems(this.containerNode);
}
var _632=(this._firstFocusItem==this._lastFocusItem);
if(evt.charOrCode==dk.ESCAPE){
setTimeout(dojo.hitch(this,"onCancel"),0);
dojo.stopEvent(evt);
}else{
if(node==this._firstFocusItem&&evt.shiftKey&&evt.charOrCode===dk.TAB){
if(!_632){
dijit.focus(this._lastFocusItem);
}
dojo.stopEvent(evt);
}else{
if(node==this._lastFocusItem&&evt.charOrCode===dk.TAB&&!evt.shiftKey){
if(!_632){
dijit.focus(this._firstFocusItem);
}
dojo.stopEvent(evt);
}else{
if(evt.charOrCode===dk.TAB){
evt.stopPropagation();
}
}
}
}
}});
}
if(!dojo._hasResource["dijit.Dialog"]){
dojo._hasResource["dijit.Dialog"]=true;
dojo.provide("dijit.Dialog");
dojo.declare("dijit._DialogBase",[dijit._Templated,dijit.form._FormMixin,dijit._DialogMixin,dijit._CssStateMixin],{templateString:dojo.cache("dijit","templates/Dialog.html","<div class=\"dijitDialog\" role=\"dialog\" aria-labelledby=\"${id}_title\">\r\n\t<div dojoAttachPoint=\"titleBar\" class=\"dijitDialogTitleBar\">\r\n\t<span dojoAttachPoint=\"titleNode\" class=\"dijitDialogTitle\" id=\"${id}_title\"></span>\r\n\t<span dojoAttachPoint=\"closeButtonNode\" class=\"dijitDialogCloseIcon\" dojoAttachEvent=\"ondijitclick: onCancel\" title=\"${buttonCancel}\" role=\"button\" tabIndex=\"-1\">\r\n\t\t<span dojoAttachPoint=\"closeText\" class=\"closeText\" title=\"${buttonCancel}\">x</span>\r\n\t</span>\r\n\t</div>\r\n\t\t<div dojoAttachPoint=\"containerNode\" class=\"dijitDialogPaneContent\"></div>\r\n</div>\r\n"),baseClass:"dijitDialog",cssStateNodes:{closeButtonNode:"dijitDialogCloseIcon"},attributeMap:dojo.delegate(dijit._Widget.prototype.attributeMap,{title:[{node:"titleNode",type:"innerHTML"},{node:"titleBar",type:"attribute"}],"aria-describedby":""}),open:false,duration:dijit.defaultDuration,refocus:true,autofocus:true,_firstFocusItem:null,_lastFocusItem:null,doLayout:false,draggable:true,"aria-describedby":"",postMixInProperties:function(){
var _633=dojo.i18n.getLocalization("dijit","common");
dojo.mixin(this,_633);
this.inherited(arguments);
},postCreate:function(){
dojo.style(this.domNode,{display:"none",position:"absolute"});
dojo.body().appendChild(this.domNode);
this.inherited(arguments);
this.connect(this,"onExecute","hide");
this.connect(this,"onCancel","hide");
this._modalconnects=[];
},onLoad:function(){
this._position();
if(this.autofocus&&dijit._DialogLevelManager.isTop(this)){
this._getFocusItems(this.domNode);
dijit.focus(this._firstFocusItem);
}
this.inherited(arguments);
},_endDrag:function(){
var _634=dojo.position(this.domNode),_635=dojo.window.getBox();
_634.y=Math.min(Math.max(_634.y,0),(_635.h-_634.h));
_634.x=Math.min(Math.max(_634.x,0),(_635.w-_634.w));
this._relativePosition=_634;
this._position();
},_setup:function(){
var node=this.domNode;
if(this.titleBar&&this.draggable){
this._moveable=(dojo.isIE==6)?new dojo.dnd.TimedMoveable(node,{handle:this.titleBar}):new dojo.dnd.Moveable(node,{handle:this.titleBar,timeout:0});
this.connect(this._moveable,"onMoveStop","_endDrag");
}else{
dojo.addClass(node,"dijitDialogFixed");
}
this.underlayAttrs={dialogId:this.id,"class":dojo.map(this["class"].split(/\s/),function(s){
return s+"_underlay";
}).join(" ")};
},_size:function(){
this._checkIfSingleChild();
if(this._singleChild){
if(this._singleChildOriginalStyle){
this._singleChild.domNode.style.cssText=this._singleChildOriginalStyle;
}
delete this._singleChildOriginalStyle;
}else{
dojo.style(this.containerNode,{width:"auto",height:"auto"});
}
var mb=dojo._getMarginSize(this.domNode);
var _636=dojo.window.getBox();
if(mb.w>=_636.w||mb.h>=_636.h){
var w=Math.min(mb.w,Math.floor(_636.w*0.75)),h=Math.min(mb.h,Math.floor(_636.h*0.75));
if(this._singleChild&&this._singleChild.resize){
this._singleChildOriginalStyle=this._singleChild.domNode.style.cssText;
this._singleChild.resize({w:w,h:h});
}else{
dojo.style(this.containerNode,{width:w+"px",height:h+"px",overflow:"auto",position:"relative"});
}
}else{
if(this._singleChild&&this._singleChild.resize){
this._singleChild.resize();
}
}
},_position:function(){
if(!dojo.hasClass(dojo.body(),"dojoMove")){
var node=this.domNode,_637=dojo.window.getBox(),p=this._relativePosition,bb=p?null:dojo._getBorderBox(node),l=Math.floor(_637.l+(p?p.x:(_637.w-bb.w)/2)),t=Math.floor(_637.t+(p?p.y:(_637.h-bb.h)/2));
dojo.style(node,{left:l+"px",top:t+"px"});
}
},_onKey:function(evt){
if(evt.charOrCode){
var dk=dojo.keys;
var node=evt.target;
if(evt.charOrCode===dk.TAB){
this._getFocusItems(this.domNode);
}
var _638=(this._firstFocusItem==this._lastFocusItem);
if(node==this._firstFocusItem&&evt.shiftKey&&evt.charOrCode===dk.TAB){
if(!_638){
dijit.focus(this._lastFocusItem);
}
dojo.stopEvent(evt);
}else{
if(node==this._lastFocusItem&&evt.charOrCode===dk.TAB&&!evt.shiftKey){
if(!_638){
dijit.focus(this._firstFocusItem);
}
dojo.stopEvent(evt);
}else{
while(node){
if(node==this.domNode||dojo.hasClass(node,"dijitPopup")){
if(evt.charOrCode==dk.ESCAPE){
this.onCancel();
}else{
return;
}
}
node=node.parentNode;
}
if(evt.charOrCode!==dk.TAB){
dojo.stopEvent(evt);
}else{
if(!dojo.isOpera){
try{
this._firstFocusItem.focus();
}
catch(e){
}
}
}
}
}
}
},show:function(){
if(this.open){
return;
}
if(!this._started){
this.startup();
}
if(!this._alreadyInitialized){
this._setup();
this._alreadyInitialized=true;
}
if(this._fadeOutDeferred){
this._fadeOutDeferred.cancel();
}
this._modalconnects.push(dojo.connect(window,"onscroll",this,"layout"));
this._modalconnects.push(dojo.connect(window,"onresize",this,function(){
var _639=dojo.window.getBox();
if(!this._oldViewport||_639.h!=this._oldViewport.h||_639.w!=this._oldViewport.w){
this.layout();
this._oldViewport=_639;
}
}));
this._modalconnects.push(dojo.connect(this.domNode,"onkeypress",this,"_onKey"));
dojo.style(this.domNode,{opacity:0,display:""});
this._set("open",true);
this._onShow();
this._size();
this._position();
var _63a;
this._fadeInDeferred=new dojo.Deferred(dojo.hitch(this,function(){
_63a.stop();
delete this._fadeInDeferred;
}));
_63a=dojo.fadeIn({node:this.domNode,duration:this.duration,beforeBegin:dojo.hitch(this,function(){
dijit._DialogLevelManager.show(this,this.underlayAttrs);
}),onEnd:dojo.hitch(this,function(){
if(this.autofocus&&dijit._DialogLevelManager.isTop(this)){
this._getFocusItems(this.domNode);
dijit.focus(this._firstFocusItem);
}
this._fadeInDeferred.callback(true);
delete this._fadeInDeferred;
})}).play();
return this._fadeInDeferred;
},hide:function(){
if(!this._alreadyInitialized){
return;
}
if(this._fadeInDeferred){
this._fadeInDeferred.cancel();
}
var _63b;
this._fadeOutDeferred=new dojo.Deferred(dojo.hitch(this,function(){
_63b.stop();
delete this._fadeOutDeferred;
}));
_63b=dojo.fadeOut({node:this.domNode,duration:this.duration,onEnd:dojo.hitch(this,function(){
this.domNode.style.display="none";
dijit._DialogLevelManager.hide(this);
this.onHide();
this._fadeOutDeferred.callback(true);
delete this._fadeOutDeferred;
})}).play();
if(this._scrollConnected){
this._scrollConnected=false;
}
dojo.forEach(this._modalconnects,dojo.disconnect);
this._modalconnects=[];
if(this._relativePosition){
delete this._relativePosition;
}
this._set("open",false);
return this._fadeOutDeferred;
},layout:function(){
if(this.domNode.style.display!="none"){
if(dijit._underlay){
dijit._underlay.layout();
}
this._position();
}
},destroy:function(){
if(this._fadeInDeferred){
this._fadeInDeferred.cancel();
}
if(this._fadeOutDeferred){
this._fadeOutDeferred.cancel();
}
if(this._moveable){
this._moveable.destroy();
}
dojo.forEach(this._modalconnects,dojo.disconnect);
dijit._DialogLevelManager.hide(this);
this.inherited(arguments);
}});
dojo.declare("dijit.Dialog",[dijit.layout.ContentPane,dijit._DialogBase],{});
dijit._DialogLevelManager={show:function(_63c,_63d){
var ds=dijit._dialogStack;
ds[ds.length-1].focus=dijit.getFocus(_63c);
var _63e=dijit._underlay;
if(!_63e||_63e._destroyed){
_63e=dijit._underlay=new dijit.DialogUnderlay(_63d);
}else{
_63e.set(_63c.underlayAttrs);
}
var _63f=ds[ds.length-1].dialog?ds[ds.length-1].zIndex+2:950;
if(ds.length==1){
_63e.show();
}
dojo.style(dijit._underlay.domNode,"zIndex",_63f-1);
dojo.style(_63c.domNode,"zIndex",_63f);
ds.push({dialog:_63c,underlayAttrs:_63d,zIndex:_63f});
},hide:function(_640){
var ds=dijit._dialogStack;
if(ds[ds.length-1].dialog==_640){
ds.pop();
var pd=ds[ds.length-1];
if(ds.length==1){
if(!dijit._underlay._destroyed){
dijit._underlay.hide();
}
}else{
dojo.style(dijit._underlay.domNode,"zIndex",pd.zIndex-1);
dijit._underlay.set(pd.underlayAttrs);
}
if(_640.refocus){
var _641=pd.focus;
if(!_641||(pd.dialog&&!dojo.isDescendant(_641.node,pd.dialog.domNode))){
pd.dialog._getFocusItems(pd.dialog.domNode);
_641=pd.dialog._firstFocusItem;
}
try{
dijit.focus(_641);
}
catch(e){
}
}
}else{
var idx=dojo.indexOf(dojo.map(ds,function(elem){
return elem.dialog;
}),_640);
if(idx!=-1){
ds.splice(idx,1);
}
}
},isTop:function(_642){
var ds=dijit._dialogStack;
return ds[ds.length-1].dialog==_642;
}};
dijit._dialogStack=[{dialog:null,focus:null,underlayAttrs:null}];
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.Dialog"]){
dojo._hasResource["dojox.grid.enhanced.plugins.Dialog"]=true;
dojo.provide("dojox.grid.enhanced.plugins.Dialog");
dojo.declare("dojox.grid.enhanced.plugins.Dialog",dijit.Dialog,{refNode:null,_position:function(){
if(this.refNode&&!this._relativePosition){
var _643=dojo.position(dojo.byId(this.refNode)),_644=dojo.position(this.domNode),_645=dojo.window.getBox();
if(_644.w&&_644.h){
if(_643.x<0){
_643.x=0;
}
if(_643.x+_643.w>_645.w){
_643.w=_645.w-_643.x;
}
if(_643.y<0){
_643.y=0;
}
if(_643.y+_643.h>_645.h){
_643.h=_645.h-_643.y;
}
_643.x=_643.x+_643.w/2-_644.w/2;
_643.y=_643.y+_643.h/2-_644.h/2;
if(_643.x>=0&&_643.x+_644.w<=_645.w&&_643.y>=0&&_643.y+_644.h<=_645.h){
this._relativePosition=_643;
}
}
}
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.filter._ConditionExpr"]){
dojo._hasResource["dojox.grid.enhanced.plugins.filter._ConditionExpr"]=true;
dojo.provide("dojox.grid.enhanced.plugins.filter._ConditionExpr");
(function(){
var fns=dojox.grid.enhanced.plugins.filter;
dojo.declare("dojox.grid.enhanced.plugins.filter._ConditionExpr",null,{_name:"expr",applyRow:function(_646,_647){
throw new Error("_ConditionExpr.applyRow: unimplemented interface");
},toObject:function(){
return {};
},getName:function(){
return this._name;
}});
dojo.declare("dojox.grid.enhanced.plugins.filter._DataExpr",fns._ConditionExpr,{_name:"data",constructor:function(_648,_649,_64a){
this._convertArgs=_64a||{};
if(dojo.isFunction(this._convertArgs.convert)){
this._convertData=dojo.hitch(this._convertArgs.scope,this._convertArgs.convert);
}
if(_649){
this._colArg=_648;
}else{
this._value=this._convertData(_648,this._convertArgs);
}
},getValue:function(){
return this._value;
},applyRow:function(_64b,_64c){
return typeof this._colArg=="undefined"?this:new (dojo.getObject(this.declaredClass))(this._convertData(_64c(_64b,this._colArg),this._convertArgs));
},_convertData:function(_64d){
return _64d;
},toObject:function(){
return {op:this.getName(),data:this._colArg===undefined?this._value:this._colArg,isCol:this._colArg!==undefined};
}});
dojo.declare("dojox.grid.enhanced.plugins.filter._OperatorExpr",fns._ConditionExpr,{_name:"operator",constructor:function(){
if(dojo.isArray(arguments[0])){
this._operands=arguments[0];
}else{
this._operands=[];
for(var i=0;i<arguments.length;++i){
this._operands.push(arguments[i]);
}
}
},toObject:function(){
return {op:this.getName(),data:dojo.map(this._operands,function(_64e){
return _64e.toObject();
})};
}});
dojo.declare("dojox.grid.enhanced.plugins.filter._UniOpExpr",fns._OperatorExpr,{_name:"uniOperator",applyRow:function(_64f,_650){
if(!(this._operands[0] instanceof fns._ConditionExpr)){
throw new Error("_UniOpExpr: operand is not expression.");
}
return this._calculate(this._operands[0],_64f,_650);
},_calculate:function(_651,_652,_653){
throw new Error("_UniOpExpr._calculate: unimplemented interface");
}});
dojo.declare("dojox.grid.enhanced.plugins.filter._BiOpExpr",fns._OperatorExpr,{_name:"biOperator",applyRow:function(_654,_655){
if(!(this._operands[0] instanceof fns._ConditionExpr)){
throw new Error("_BiOpExpr: left operand is not expression.");
}else{
if(!(this._operands[1] instanceof fns._ConditionExpr)){
throw new Error("_BiOpExpr: right operand is not expression.");
}
}
return this._calculate(this._operands[0],this._operands[1],_654,_655);
},_calculate:function(_656,_657,_658,_659){
throw new Error("_BiOpExpr._calculate: unimplemented interface");
}});
})();
}
if(!dojo._hasResource["dojo.date"]){
dojo._hasResource["dojo.date"]=true;
dojo.provide("dojo.date");
dojo.getObject("date",true,dojo);
dojo.date.getDaysInMonth=function(_65a){
var _65b=_65a.getMonth();
var days=[31,28,31,30,31,30,31,31,30,31,30,31];
if(_65b==1&&dojo.date.isLeapYear(_65a)){
return 29;
}
return days[_65b];
};
dojo.date.isLeapYear=function(_65c){
var year=_65c.getFullYear();
return !(year%400)||(!(year%4)&&!!(year%100));
};
dojo.date.getTimezoneName=function(_65d){
var str=_65d.toString();
var tz="";
var _65e;
var pos=str.indexOf("(");
if(pos>-1){
tz=str.substring(++pos,str.indexOf(")"));
}else{
var pat=/([A-Z\/]+) \d{4}$/;
if((_65e=str.match(pat))){
tz=_65e[1];
}else{
str=_65d.toLocaleString();
pat=/ ([A-Z\/]+)$/;
if((_65e=str.match(pat))){
tz=_65e[1];
}
}
}
return (tz=="AM"||tz=="PM")?"":tz;
};
dojo.date.compare=function(_65f,_660,_661){
_65f=new Date(+_65f);
_660=new Date(+(_660||new Date()));
if(_661=="date"){
_65f.setHours(0,0,0,0);
_660.setHours(0,0,0,0);
}else{
if(_661=="time"){
_65f.setFullYear(0,0,0);
_660.setFullYear(0,0,0);
}
}
if(_65f>_660){
return 1;
}
if(_65f<_660){
return -1;
}
return 0;
};
dojo.date.add=function(date,_662,_663){
var sum=new Date(+date);
var _664=false;
var _665="Date";
switch(_662){
case "day":
break;
case "weekday":
var days,_666;
var mod=_663%5;
if(!mod){
days=(_663>0)?5:-5;
_666=(_663>0)?((_663-5)/5):((_663+5)/5);
}else{
days=mod;
_666=parseInt(_663/5);
}
var strt=date.getDay();
var adj=0;
if(strt==6&&_663>0){
adj=1;
}else{
if(strt==0&&_663<0){
adj=-1;
}
}
var trgt=strt+days;
if(trgt==0||trgt==6){
adj=(_663>0)?2:-2;
}
_663=(7*_666)+days+adj;
break;
case "year":
_665="FullYear";
_664=true;
break;
case "week":
_663*=7;
break;
case "quarter":
_663*=3;
case "month":
_664=true;
_665="Month";
break;
default:
_665="UTC"+_662.charAt(0).toUpperCase()+_662.substring(1)+"s";
}
if(_665){
sum["set"+_665](sum["get"+_665]()+_663);
}
if(_664&&(sum.getDate()<date.getDate())){
sum.setDate(0);
}
return sum;
};
dojo.date.difference=function(_667,_668,_669){
_668=_668||new Date();
_669=_669||"day";
var _66a=_668.getFullYear()-_667.getFullYear();
var _66b=1;
switch(_669){
case "quarter":
var m1=_667.getMonth();
var m2=_668.getMonth();
var q1=Math.floor(m1/3)+1;
var q2=Math.floor(m2/3)+1;
q2+=(_66a*4);
_66b=q2-q1;
break;
case "weekday":
var days=Math.round(dojo.date.difference(_667,_668,"day"));
var _66c=parseInt(dojo.date.difference(_667,_668,"week"));
var mod=days%7;
if(mod==0){
days=_66c*5;
}else{
var adj=0;
var aDay=_667.getDay();
var bDay=_668.getDay();
_66c=parseInt(days/7);
mod=days%7;
var _66d=new Date(_667);
_66d.setDate(_66d.getDate()+(_66c*7));
var _66e=_66d.getDay();
if(days>0){
switch(true){
case aDay==6:
adj=-1;
break;
case aDay==0:
adj=0;
break;
case bDay==6:
adj=-1;
break;
case bDay==0:
adj=-2;
break;
case (_66e+mod)>5:
adj=-2;
}
}else{
if(days<0){
switch(true){
case aDay==6:
adj=0;
break;
case aDay==0:
adj=1;
break;
case bDay==6:
adj=2;
break;
case bDay==0:
adj=1;
break;
case (_66e+mod)<0:
adj=2;
}
}
}
days+=adj;
days-=(_66c*2);
}
_66b=days;
break;
case "year":
_66b=_66a;
break;
case "month":
_66b=(_668.getMonth()-_667.getMonth())+(_66a*12);
break;
case "week":
_66b=parseInt(dojo.date.difference(_667,_668,"day")/7);
break;
case "day":
_66b/=24;
case "hour":
_66b/=60;
case "minute":
_66b/=60;
case "second":
_66b/=1000;
case "millisecond":
_66b*=_668.getTime()-_667.getTime();
}
return Math.round(_66b);
};
}
if(!dojo._hasResource["dojo.cldr.supplemental"]){
dojo._hasResource["dojo.cldr.supplemental"]=true;
dojo.provide("dojo.cldr.supplemental");
dojo.getObject("cldr.supplemental",true,dojo);
dojo.cldr.supplemental.getFirstDayOfWeek=function(_66f){
var _670={mv:5,ae:6,af:6,bh:6,dj:6,dz:6,eg:6,er:6,et:6,iq:6,ir:6,jo:6,ke:6,kw:6,ly:6,ma:6,om:6,qa:6,sa:6,sd:6,so:6,sy:6,tn:6,ye:6,ar:0,as:0,az:0,bw:0,ca:0,cn:0,fo:0,ge:0,gl:0,gu:0,hk:0,il:0,"in":0,jm:0,jp:0,kg:0,kr:0,la:0,mh:0,mn:0,mo:0,mp:0,mt:0,nz:0,ph:0,pk:0,sg:0,th:0,tt:0,tw:0,um:0,us:0,uz:0,vi:0,zw:0};
var _671=dojo.cldr.supplemental._region(_66f);
var dow=_670[_671];
return (dow===undefined)?1:dow;
};
dojo.cldr.supplemental._region=function(_672){
_672=dojo.i18n.normalizeLocale(_672);
var tags=_672.split("-");
var _673=tags[1];
if(!_673){
_673={de:"de",en:"us",es:"es",fi:"fi",fr:"fr",he:"il",hu:"hu",it:"it",ja:"jp",ko:"kr",nl:"nl",pt:"br",sv:"se",zh:"cn"}[tags[0]];
}else{
if(_673.length==4){
_673=tags[2];
}
}
return _673;
};
dojo.cldr.supplemental.getWeekend=function(_674){
var _675={"in":0,af:4,dz:4,ir:4,om:4,sa:4,ye:4,ae:5,bh:5,eg:5,il:5,iq:5,jo:5,kw:5,ly:5,ma:5,qa:5,sd:5,sy:5,tn:5};
var _676={af:5,dz:5,ir:5,om:5,sa:5,ye:5,ae:6,bh:5,eg:6,il:6,iq:6,jo:6,kw:6,ly:6,ma:6,qa:6,sd:6,sy:6,tn:6};
var _677=dojo.cldr.supplemental._region(_674);
var _678=_675[_677];
var end=_676[_677];
if(_678===undefined){
_678=6;
}
if(end===undefined){
end=0;
}
return {start:_678,end:end};
};
}
if(!dojo._hasResource["dojo.regexp"]){
dojo._hasResource["dojo.regexp"]=true;
dojo.provide("dojo.regexp");
dojo.getObject("regexp",true,dojo);
dojo.regexp.escapeString=function(str,_679){
return str.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g,function(ch){
if(_679&&_679.indexOf(ch)!=-1){
return ch;
}
return "\\"+ch;
});
};
dojo.regexp.buildGroupRE=function(arr,re,_67a){
if(!(arr instanceof Array)){
return re(arr);
}
var b=[];
for(var i=0;i<arr.length;i++){
b.push(re(arr[i]));
}
return dojo.regexp.group(b.join("|"),_67a);
};
dojo.regexp.group=function(_67b,_67c){
return "("+(_67c?"?:":"")+_67b+")";
};
}
if(!dojo._hasResource["dojo.date.locale"]){
dojo._hasResource["dojo.date.locale"]=true;
dojo.provide("dojo.date.locale");
dojo.getObject("date.locale",true,dojo);
(function(){
function _67d(_67e,_67f,_680,_681){
return _681.replace(/([a-z])\1*/ig,function(_682){
var s,pad,c=_682.charAt(0),l=_682.length,_683=["abbr","wide","narrow"];
switch(c){
case "G":
s=_67f[(l<4)?"eraAbbr":"eraNames"][_67e.getFullYear()<0?0:1];
break;
case "y":
s=_67e.getFullYear();
switch(l){
case 1:
break;
case 2:
if(!_680.fullYear){
s=String(s);
s=s.substr(s.length-2);
break;
}
default:
pad=true;
}
break;
case "Q":
case "q":
s=Math.ceil((_67e.getMonth()+1)/3);
pad=true;
break;
case "M":
var m=_67e.getMonth();
if(l<3){
s=m+1;
pad=true;
}else{
var _684=["months","format",_683[l-3]].join("-");
s=_67f[_684][m];
}
break;
case "w":
var _685=0;
s=dojo.date.locale._getWeekOfYear(_67e,_685);
pad=true;
break;
case "d":
s=_67e.getDate();
pad=true;
break;
case "D":
s=dojo.date.locale._getDayOfYear(_67e);
pad=true;
break;
case "E":
var d=_67e.getDay();
if(l<3){
s=d+1;
pad=true;
}else{
var _686=["days","format",_683[l-3]].join("-");
s=_67f[_686][d];
}
break;
case "a":
var _687=(_67e.getHours()<12)?"am":"pm";
s=_680[_687]||_67f["dayPeriods-format-wide-"+_687];
break;
case "h":
case "H":
case "K":
case "k":
var h=_67e.getHours();
switch(c){
case "h":
s=(h%12)||12;
break;
case "H":
s=h;
break;
case "K":
s=(h%12);
break;
case "k":
s=h||24;
break;
}
pad=true;
break;
case "m":
s=_67e.getMinutes();
pad=true;
break;
case "s":
s=_67e.getSeconds();
pad=true;
break;
case "S":
s=Math.round(_67e.getMilliseconds()*Math.pow(10,l-3));
pad=true;
break;
case "v":
case "z":
s=dojo.date.locale._getZone(_67e,true,_680);
if(s){
break;
}
l=4;
case "Z":
var _688=dojo.date.locale._getZone(_67e,false,_680);
var tz=[(_688<=0?"+":"-"),dojo.string.pad(Math.floor(Math.abs(_688)/60),2),dojo.string.pad(Math.abs(_688)%60,2)];
if(l==4){
tz.splice(0,0,"GMT");
tz.splice(3,0,":");
}
s=tz.join("");
break;
default:
throw new Error("dojo.date.locale.format: invalid pattern char: "+_681);
}
if(pad){
s=dojo.string.pad(s,l);
}
return s;
});
};
dojo.date.locale._getZone=function(_689,_68a,_68b){
if(_68a){
return dojo.date.getTimezoneName(_689);
}else{
return _689.getTimezoneOffset();
}
};
dojo.date.locale.format=function(_68c,_68d){
_68d=_68d||{};
var _68e=dojo.i18n.normalizeLocale(_68d.locale),_68f=_68d.formatLength||"short",_690=dojo.date.locale._getGregorianBundle(_68e),str=[],_691=dojo.hitch(this,_67d,_68c,_690,_68d);
if(_68d.selector=="year"){
return _692(_690["dateFormatItem-yyyy"]||"yyyy",_691);
}
var _693;
if(_68d.selector!="date"){
_693=_68d.timePattern||_690["timeFormat-"+_68f];
if(_693){
str.push(_692(_693,_691));
}
}
if(_68d.selector!="time"){
_693=_68d.datePattern||_690["dateFormat-"+_68f];
if(_693){
str.push(_692(_693,_691));
}
}
return str.length==1?str[0]:_690["dateTimeFormat-"+_68f].replace(/\{(\d+)\}/g,function(_694,key){
return str[key];
});
};
dojo.date.locale.regexp=function(_695){
return dojo.date.locale._parseInfo(_695).regexp;
};
dojo.date.locale._parseInfo=function(_696){
_696=_696||{};
var _697=dojo.i18n.normalizeLocale(_696.locale),_698=dojo.date.locale._getGregorianBundle(_697),_699=_696.formatLength||"short",_69a=_696.datePattern||_698["dateFormat-"+_699],_69b=_696.timePattern||_698["timeFormat-"+_699],_69c;
if(_696.selector=="date"){
_69c=_69a;
}else{
if(_696.selector=="time"){
_69c=_69b;
}else{
_69c=_698["dateTimeFormat-"+_699].replace(/\{(\d+)\}/g,function(_69d,key){
return [_69b,_69a][key];
});
}
}
var _69e=[],re=_692(_69c,dojo.hitch(this,_69f,_69e,_698,_696));
return {regexp:re,tokens:_69e,bundle:_698};
};
dojo.date.locale.parse=function(_6a0,_6a1){
var _6a2=/[\u200E\u200F\u202A\u202E]/g,info=dojo.date.locale._parseInfo(_6a1),_6a3=info.tokens,_6a4=info.bundle,re=new RegExp("^"+info.regexp.replace(_6a2,"")+"$",info.strict?"":"i"),_6a5=re.exec(_6a0&&_6a0.replace(_6a2,""));
if(!_6a5){
return null;
}
var _6a6=["abbr","wide","narrow"],_6a7=[1970,0,1,0,0,0,0],amPm="",_6a8=dojo.every(_6a5,function(v,i){
if(!i){
return true;
}
var _6a9=_6a3[i-1];
var l=_6a9.length;
switch(_6a9.charAt(0)){
case "y":
if(l!=2&&_6a1.strict){
_6a7[0]=v;
}else{
if(v<100){
v=Number(v);
var year=""+new Date().getFullYear(),_6aa=year.substring(0,2)*100,_6ab=Math.min(Number(year.substring(2,4))+20,99),num=(v<_6ab)?_6aa+v:_6aa-100+v;
_6a7[0]=num;
}else{
if(_6a1.strict){
return false;
}
_6a7[0]=v;
}
}
break;
case "M":
if(l>2){
var _6ac=_6a4["months-format-"+_6a6[l-3]].concat();
if(!_6a1.strict){
v=v.replace(".","").toLowerCase();
_6ac=dojo.map(_6ac,function(s){
return s.replace(".","").toLowerCase();
});
}
v=dojo.indexOf(_6ac,v);
if(v==-1){
return false;
}
}else{
v--;
}
_6a7[1]=v;
break;
case "E":
case "e":
var days=_6a4["days-format-"+_6a6[l-3]].concat();
if(!_6a1.strict){
v=v.toLowerCase();
days=dojo.map(days,function(d){
return d.toLowerCase();
});
}
v=dojo.indexOf(days,v);
if(v==-1){
return false;
}
break;
case "D":
_6a7[1]=0;
case "d":
_6a7[2]=v;
break;
case "a":
var am=_6a1.am||_6a4["dayPeriods-format-wide-am"],pm=_6a1.pm||_6a4["dayPeriods-format-wide-pm"];
if(!_6a1.strict){
var _6ad=/\./g;
v=v.replace(_6ad,"").toLowerCase();
am=am.replace(_6ad,"").toLowerCase();
pm=pm.replace(_6ad,"").toLowerCase();
}
if(_6a1.strict&&v!=am&&v!=pm){
return false;
}
amPm=(v==pm)?"p":(v==am)?"a":"";
break;
case "K":
if(v==24){
v=0;
}
case "h":
case "H":
case "k":
if(v>23){
return false;
}
_6a7[3]=v;
break;
case "m":
_6a7[4]=v;
break;
case "s":
_6a7[5]=v;
break;
case "S":
_6a7[6]=v;
}
return true;
});
var _6ae=+_6a7[3];
if(amPm==="p"&&_6ae<12){
_6a7[3]=_6ae+12;
}else{
if(amPm==="a"&&_6ae==12){
_6a7[3]=0;
}
}
var _6af=new Date(_6a7[0],_6a7[1],_6a7[2],_6a7[3],_6a7[4],_6a7[5],_6a7[6]);
if(_6a1.strict){
_6af.setFullYear(_6a7[0]);
}
var _6b0=_6a3.join(""),_6b1=_6b0.indexOf("d")!=-1,_6b2=_6b0.indexOf("M")!=-1;
if(!_6a8||(_6b2&&_6af.getMonth()>_6a7[1])||(_6b1&&_6af.getDate()>_6a7[2])){
return null;
}
if((_6b2&&_6af.getMonth()<_6a7[1])||(_6b1&&_6af.getDate()<_6a7[2])){
_6af=dojo.date.add(_6af,"hour",1);
}
return _6af;
};
function _692(_6b3,_6b4,_6b5,_6b6){
var _6b7=function(x){
return x;
};
_6b4=_6b4||_6b7;
_6b5=_6b5||_6b7;
_6b6=_6b6||_6b7;
var _6b8=_6b3.match(/(''|[^'])+/g),_6b9=_6b3.charAt(0)=="'";
dojo.forEach(_6b8,function(_6ba,i){
if(!_6ba){
_6b8[i]="";
}else{
_6b8[i]=(_6b9?_6b5:_6b4)(_6ba.replace(/''/g,"'"));
_6b9=!_6b9;
}
});
return _6b6(_6b8.join(""));
};
function _69f(_6bb,_6bc,_6bd,_6be){
_6be=dojo.regexp.escapeString(_6be);
if(!_6bd.strict){
_6be=_6be.replace(" a"," ?a");
}
return _6be.replace(/([a-z])\1*/ig,function(_6bf){
var s,c=_6bf.charAt(0),l=_6bf.length,p2="",p3="";
if(_6bd.strict){
if(l>1){
p2="0"+"{"+(l-1)+"}";
}
if(l>2){
p3="0"+"{"+(l-2)+"}";
}
}else{
p2="0?";
p3="0{0,2}";
}
switch(c){
case "y":
s="\\d{2,4}";
break;
case "M":
s=(l>2)?"\\S+?":"1[0-2]|"+p2+"[1-9]";
break;
case "D":
s="[12][0-9][0-9]|3[0-5][0-9]|36[0-6]|"+p3+"[1-9][0-9]|"+p2+"[1-9]";
break;
case "d":
s="3[01]|[12]\\d|"+p2+"[1-9]";
break;
case "w":
s="[1-4][0-9]|5[0-3]|"+p2+"[1-9]";
break;
case "E":
s="\\S+";
break;
case "h":
s="1[0-2]|"+p2+"[1-9]";
break;
case "k":
s="1[01]|"+p2+"\\d";
break;
case "H":
s="1\\d|2[0-3]|"+p2+"\\d";
break;
case "K":
s="1\\d|2[0-4]|"+p2+"[1-9]";
break;
case "m":
case "s":
s="[0-5]\\d";
break;
case "S":
s="\\d{"+l+"}";
break;
case "a":
var am=_6bd.am||_6bc["dayPeriods-format-wide-am"],pm=_6bd.pm||_6bc["dayPeriods-format-wide-pm"];
s=am+"|"+pm;
if(!_6bd.strict){
if(am!=am.toLowerCase()){
s+="|"+am.toLowerCase();
}
if(pm!=pm.toLowerCase()){
s+="|"+pm.toLowerCase();
}
if(s.indexOf(".")!=-1){
s+="|"+s.replace(/\./g,"");
}
}
s=s.replace(/\./g,"\\.");
break;
default:
s=".*";
}
if(_6bb){
_6bb.push(_6bf);
}
return "("+s+")";
}).replace(/[\xa0 ]/g,"[\\s\\xa0]");
};
})();
(function(){
var _6c0=[];
dojo.date.locale.addCustomFormats=function(_6c1,_6c2){
_6c0.push({pkg:_6c1,name:_6c2});
};
dojo.date.locale._getGregorianBundle=function(_6c3){
var _6c4={};
dojo.forEach(_6c0,function(desc){
var _6c5=dojo.i18n.getLocalization(desc.pkg,desc.name,_6c3);
_6c4=dojo.mixin(_6c4,_6c5);
},this);
return _6c4;
};
})();
dojo.date.locale.addCustomFormats("dojo.cldr","gregorian");
dojo.date.locale.getNames=function(item,type,_6c6,_6c7){
var _6c8,_6c9=dojo.date.locale._getGregorianBundle(_6c7),_6ca=[item,_6c6,type];
if(_6c6=="standAlone"){
var key=_6ca.join("-");
_6c8=_6c9[key];
if(_6c8[0]==1){
_6c8=undefined;
}
}
_6ca[1]="format";
return (_6c8||_6c9[_6ca.join("-")]).concat();
};
dojo.date.locale.isWeekend=function(_6cb,_6cc){
var _6cd=dojo.cldr.supplemental.getWeekend(_6cc),day=(_6cb||new Date()).getDay();
if(_6cd.end<_6cd.start){
_6cd.end+=7;
if(day<_6cd.start){
day+=7;
}
}
return day>=_6cd.start&&day<=_6cd.end;
};
dojo.date.locale._getDayOfYear=function(_6ce){
return dojo.date.difference(new Date(_6ce.getFullYear(),0,1,_6ce.getHours()),_6ce)+1;
};
dojo.date.locale._getWeekOfYear=function(_6cf,_6d0){
if(arguments.length==1){
_6d0=0;
}
var _6d1=new Date(_6cf.getFullYear(),0,1).getDay(),adj=(_6d1-_6d0+7)%7,week=Math.floor((dojo.date.locale._getDayOfYear(_6cf)+adj-1)/7);
if(_6d1==_6d0){
week++;
}
return week;
};
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.filter._DataExprs"]){
dojo._hasResource["dojox.grid.enhanced.plugins.filter._DataExprs"]=true;
dojo.provide("dojox.grid.enhanced.plugins.filter._DataExprs");
(function(){
var fns=dojox.grid.enhanced.plugins.filter;
dojo.declare("dojox.grid.enhanced.plugins.filter.BooleanExpr",fns._DataExpr,{_name:"bool",_convertData:function(_6d2){
return !!_6d2;
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.StringExpr",fns._DataExpr,{_name:"string",_convertData:function(_6d3){
return String(_6d3);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.NumberExpr",fns._DataExpr,{_name:"number",_convertDataToExpr:function(_6d4){
return parseFloat(_6d4);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.DateExpr",fns._DataExpr,{_name:"date",_convertData:function(_6d5){
if(_6d5 instanceof Date){
return _6d5;
}else{
if(typeof _6d5=="number"){
return new Date(_6d5);
}else{
var res=dojo.date.locale.parse(String(_6d5),dojo.mixin({selector:this._name},this._convertArgs));
if(!res){
throw new Error("Datetime parse failed: "+_6d5);
}
return res;
}
}
},toObject:function(){
if(this._value instanceof Date){
var tmp=this._value;
this._value=this._value.valueOf();
var res=this.inherited(arguments);
this._value=tmp;
return res;
}else{
return this.inherited(arguments);
}
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.TimeExpr",fns.DateExpr,{_name:"time"});
})();
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.filter._FilterExpr"]){
dojo._hasResource["dojox.grid.enhanced.plugins.filter._FilterExpr"]=true;
dojo.provide("dojox.grid.enhanced.plugins.filter._FilterExpr");
(function(){
var fns=dojox.grid.enhanced.plugins.filter;
dojo.declare("dojox.grid.enhanced.plugins.filter.LogicAND",fns._BiOpExpr,{_name:"and",_calculate:function(_6d6,_6d7,_6d8,_6d9){
var res=_6d6.applyRow(_6d8,_6d9).getValue()&&_6d7.applyRow(_6d8,_6d9).getValue();
return new fns.BooleanExpr(res);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.LogicOR",fns._BiOpExpr,{_name:"or",_calculate:function(_6da,_6db,_6dc,_6dd){
var res=_6da.applyRow(_6dc,_6dd).getValue()||_6db.applyRow(_6dc,_6dd).getValue();
return new fns.BooleanExpr(res);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.LogicXOR",fns._BiOpExpr,{_name:"xor",_calculate:function(_6de,_6df,_6e0,_6e1){
var _6e2=_6de.applyRow(_6e0,_6e1).getValue();
var _6e3=_6df.applyRow(_6e0,_6e1).getValue();
return new fns.BooleanExpr((!!_6e2)!=(!!_6e3));
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.LogicNOT",fns._UniOpExpr,{_name:"not",_calculate:function(_6e4,_6e5,_6e6){
return new fns.BooleanExpr(!_6e4.applyRow(_6e5,_6e6).getValue());
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.LogicALL",fns._OperatorExpr,{_name:"all",applyRow:function(_6e7,_6e8){
for(var i=0,res=true;res&&(this._operands[i] instanceof fns._ConditionExpr);++i){
res=this._operands[i].applyRow(_6e7,_6e8).getValue();
}
return new fns.BooleanExpr(res);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.LogicANY",fns._OperatorExpr,{_name:"any",applyRow:function(_6e9,_6ea){
for(var i=0,res=false;!res&&(this._operands[i] instanceof fns._ConditionExpr);++i){
res=this._operands[i].applyRow(_6e9,_6ea).getValue();
}
return new fns.BooleanExpr(res);
}});
function _6eb(left,_6ec,row,_6ed){
left=left.applyRow(row,_6ed);
_6ec=_6ec.applyRow(row,_6ed);
var _6ee=left.getValue();
var _6ef=_6ec.getValue();
if(left instanceof fns.TimeExpr){
return dojo.date.compare(_6ee,_6ef,"time");
}else{
if(left instanceof fns.DateExpr){
return dojo.date.compare(_6ee,_6ef,"date");
}else{
if(left instanceof fns.StringExpr){
_6ee=_6ee.toLowerCase();
_6ef=String(_6ef).toLowerCase();
}
return _6ee==_6ef?0:(_6ee<_6ef?-1:1);
}
}
};
dojo.declare("dojox.grid.enhanced.plugins.filter.EqualTo",fns._BiOpExpr,{_name:"equal",_calculate:function(_6f0,_6f1,_6f2,_6f3){
var res=_6eb(_6f0,_6f1,_6f2,_6f3);
return new fns.BooleanExpr(res===0);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.LessThan",fns._BiOpExpr,{_name:"less",_calculate:function(_6f4,_6f5,_6f6,_6f7){
var res=_6eb(_6f4,_6f5,_6f6,_6f7);
return new fns.BooleanExpr(res<0);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.LessThanOrEqualTo",fns._BiOpExpr,{_name:"lessEqual",_calculate:function(_6f8,_6f9,_6fa,_6fb){
var res=_6eb(_6f8,_6f9,_6fa,_6fb);
return new fns.BooleanExpr(res<=0);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.LargerThan",fns._BiOpExpr,{_name:"larger",_calculate:function(_6fc,_6fd,_6fe,_6ff){
var res=_6eb(_6fc,_6fd,_6fe,_6ff);
return new fns.BooleanExpr(res>0);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.LargerThanOrEqualTo",fns._BiOpExpr,{_name:"largerEqual",_calculate:function(_700,_701,_702,_703){
var res=_6eb(_700,_701,_702,_703);
return new fns.BooleanExpr(res>=0);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.Contains",fns._BiOpExpr,{_name:"contains",_calculate:function(_704,_705,_706,_707){
var _708=String(_704.applyRow(_706,_707).getValue()).toLowerCase();
var _709=String(_705.applyRow(_706,_707).getValue()).toLowerCase();
return new fns.BooleanExpr(_708.indexOf(_709)>=0);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.StartsWith",fns._BiOpExpr,{_name:"startsWith",_calculate:function(_70a,_70b,_70c,_70d){
var _70e=String(_70a.applyRow(_70c,_70d).getValue()).toLowerCase();
var _70f=String(_70b.applyRow(_70c,_70d).getValue()).toLowerCase();
return new fns.BooleanExpr(_70e.substring(0,_70f.length)==_70f);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.EndsWith",fns._BiOpExpr,{_name:"endsWith",_calculate:function(_710,_711,_712,_713){
var _714=String(_710.applyRow(_712,_713).getValue()).toLowerCase();
var _715=String(_711.applyRow(_712,_713).getValue()).toLowerCase();
return new fns.BooleanExpr(_714.substring(_714.length-_715.length)==_715);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.Matches",fns._BiOpExpr,{_name:"matches",_calculate:function(_716,_717,_718,_719){
var _71a=String(_716.applyRow(_718,_719).getValue());
var _71b=new RegExp(_717.applyRow(_718,_719).getValue());
return new fns.BooleanExpr(_71a.search(_71b)>=0);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.IsEmpty",fns._UniOpExpr,{_name:"isEmpty",_calculate:function(_71c,_71d,_71e){
var res=_71c.applyRow(_71d,_71e).getValue();
return new fns.BooleanExpr(res===""||res==null);
}});
})();
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins._StoreLayer"]){
dojo._hasResource["dojox.grid.enhanced.plugins._StoreLayer"]=true;
dojo.provide("dojox.grid.enhanced.plugins._StoreLayer");
(function(){
var ns=dojox.grid.enhanced.plugins,_71f=function(tags){
var _720=["reorder","sizeChange","normal","presentation"];
var idx=_720.length;
for(var i=tags.length-1;i>=0;--i){
var p=dojo.indexOf(_720,tags[i]);
if(p>=0&&p<=idx){
idx=p;
}
}
if(idx<_720.length-1){
return _720.slice(0,idx+1);
}else{
return _720;
}
},_721=function(_722){
var i,_723=this._layers,len=_723.length;
if(_722){
for(i=len-1;i>=0;--i){
if(_723[i].name()==_722){
_723[i]._unwrap(_723[i+1]);
break;
}
}
_723.splice(i,1);
}else{
for(i=len-1;i>=0;--i){
_723[i]._unwrap();
}
}
if(!_723.length){
delete this._layers;
delete this.layer;
delete this.unwrap;
delete this.forEachLayer;
}
return this;
},_724=function(_725){
var i,_726=this._layers;
if(typeof _725=="undefined"){
return _726.length;
}
if(typeof _725=="number"){
return _726[_725];
}
for(i=_726.length-1;i>=0;--i){
if(_726[i].name()==_725){
return _726[i];
}
}
return null;
},_727=function(_728,_729){
var len=this._layers.length,_72a,end,dir;
if(_729){
_72a=0;
end=len;
dir=1;
}else{
_72a=len-1;
end=-1;
dir=-1;
}
for(var i=_72a;i!=end;i+=dir){
if(_728(this._layers[i],i)===false){
return i;
}
}
return end;
};
ns.wrap=function(_72b,_72c,_72d,_72e){
if(!_72b._layers){
_72b._layers=[];
_72b.layer=dojo.hitch(_72b,_724);
_72b.unwrap=dojo.hitch(_72b,_721);
_72b.forEachLayer=dojo.hitch(_72b,_727);
}
var _72f=_71f(_72d.tags);
if(!dojo.some(_72b._layers,function(lyr,i){
if(dojo.some(lyr.tags,function(tag){
return dojo.indexOf(_72f,tag)>=0;
})){
return false;
}else{
_72b._layers.splice(i,0,_72d);
_72d._wrap(_72b,_72c,_72e,lyr);
return true;
}
})){
_72b._layers.push(_72d);
_72d._wrap(_72b,_72c,_72e);
}
return _72b;
};
dojo.declare("dojox.grid.enhanced.plugins._StoreLayer",null,{tags:["normal"],layerFuncName:"_fetch",constructor:function(){
this._store=null;
this._originFetch=null;
this.__enabled=true;
},initialize:function(_730){
},uninitialize:function(_731){
},invalidate:function(){
},_wrap:function(_732,_733,_734,_735){
this._store=_732;
this._funcName=_733;
var _736=dojo.hitch(this,function(){
return (this.enabled()?this[_734||this.layerFuncName]:this.originFetch).apply(this,arguments);
});
if(_735){
this._originFetch=_735._originFetch;
_735._originFetch=_736;
}else{
this._originFetch=_732[_733]||function(){
};
_732[_733]=_736;
}
this.initialize(_732);
},_unwrap:function(_737){
this.uninitialize(this._store);
if(_737){
_737._originFetch=this._originFetch;
}else{
this._store[this._funcName]=this._originFetch;
}
this._originFetch=null;
this._store=null;
},enabled:function(_738){
if(typeof _738!="undefined"){
this.__enabled=!!_738;
}
return this.__enabled;
},name:function(){
if(!this.__name){
var m=this.declaredClass.match(/(?:\.(?:_*)([^\.]+)Layer$)|(?:\.([^\.]+)$)/i);
this.__name=m?(m[1]||m[2]).toLowerCase():this.declaredClass;
}
return this.__name;
},originFetch:function(){
return (dojo.hitch(this._store,this._originFetch)).apply(this,arguments);
}});
dojo.declare("dojox.grid.enhanced.plugins._ServerSideLayer",ns._StoreLayer,{constructor:function(args){
args=args||{};
this._url=args.url||"";
this._isStateful=!!args.isStateful;
this._onUserCommandLoad=args.onCommandLoad||function(){
};
this.__cmds={cmdlayer:this.name(),enable:true};
this.useCommands(this._isStateful);
},enabled:function(_739){
var res=this.inherited(arguments);
this.__cmds.enable=this.__enabled;
return res;
},useCommands:function(_73a){
if(typeof _73a!="undefined"){
this.__cmds.cmdlayer=(_73a&&this._isStateful)?this.name():null;
}
return !!(this.__cmds.cmdlayer);
},_fetch:function(_73b){
if(this.__cmds.cmdlayer){
dojo.xhrPost({url:this._url||this._store.url,content:this.__cmds,load:dojo.hitch(this,function(_73c){
this.onCommandLoad(_73c,_73b);
this.originFetch(_73b);
}),error:dojo.hitch(this,this.onCommandError)});
}else{
this.onCommandLoad("",_73b);
this.originFetch(_73b);
}
return _73b;
},command:function(_73d,_73e){
var cmds=this.__cmds;
if(_73e===null){
delete cmds[_73d];
}else{
if(typeof _73e!=="undefined"){
cmds[_73d]=_73e;
}
}
return cmds[_73d];
},onCommandLoad:function(_73f,_740){
this._onUserCommandLoad(this.__cmds,_740,_73f);
},onCommandError:function(_741){
throw _741;
}});
})();
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.filter.FilterLayer"]){
dojo._hasResource["dojox.grid.enhanced.plugins.filter.FilterLayer"]=true;
dojo.provide("dojox.grid.enhanced.plugins.filter.FilterLayer");
(function(){
var ns=dojox.grid.enhanced.plugins,_742="filter",_743="clear",_744=function(_745,func){
return func?dojo.hitch(_745||dojo.global,func):function(){
};
},_746=function(obj){
var res={};
if(obj&&dojo.isObject(obj)){
for(var name in obj){
res[name]=obj[name];
}
}
return res;
};
dojo.declare("dojox.grid.enhanced.plugins.filter._FilterLayerMixin",null,{tags:["sizeChange"],name:function(){
return "filter";
},onFilterDefined:function(_747){
},onFiltered:function(_748,_749){
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.ServerSideFilterLayer",[ns._ServerSideLayer,ns.filter._FilterLayerMixin],{constructor:function(args){
this._onUserCommandLoad=args.setupFilterQuery||this._onUserCommandLoad;
this.filterDef(null);
},filterDef:function(_74a){
if(_74a){
this._filter=_74a;
var obj=_74a.toObject();
this.command(_742,this._isStateful?dojo.toJson(obj):obj);
this.command(_743,null);
this.useCommands(true);
this.onFilterDefined(_74a);
}else{
if(_74a===null){
this._filter=null;
this.command(_742,null);
this.command(_743,true);
this.useCommands(true);
this.onFilterDefined(null);
}
}
return this._filter;
},onCommandLoad:function(_74b,_74c){
this.inherited(arguments);
var _74d=_74c.onBegin;
if(this._isStateful){
var _74e;
if(_74b){
this.command(_742,null);
this.command(_743,null);
this.useCommands(false);
var _74f=_74b.split(",");
if(_74f.length>=2){
_74e=this._filteredSize=parseInt(_74f[0],10);
this.onFiltered(_74e,parseInt(_74f[1],10));
}else{
return;
}
}else{
_74e=this._filteredSize;
}
if(this.enabled()){
_74c.onBegin=function(size,req){
_744(_74c.scope,_74d)(_74e,req);
};
}
}else{
var _750=this;
_74c.onBegin=function(size,req){
if(!_750._filter){
_750._storeSize=size;
}
_750.onFiltered(size,_750._storeSize||size);
req.onBegin=_74d;
_744(_74c.scope,_74d)(size,req);
};
}
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.ClientSideFilterLayer",[ns._StoreLayer,ns.filter._FilterLayerMixin],{_storeSize:-1,_fetchAll:true,constructor:function(args){
this.filterDef(null);
args=dojo.isObject(args)?args:{};
this.fetchAllOnFirstFilter(args.fetchAll);
this._getter=dojo.isFunction(args.getter)?args.getter:this._defaultGetter;
},_defaultGetter:function(_751,_752,_753,_754){
return _754.getValue(_751,_752);
},filterDef:function(_755){
if(_755!==undefined){
this._filter=_755;
this.invalidate();
this.onFilterDefined(_755);
}
return this._filter;
},setGetter:function(_756){
if(dojo.isFunction(_756)){
this._getter=_756;
}
},fetchAllOnFirstFilter:function(_757){
if(_757!==undefined){
this._fetchAll=!!_757;
}
return this._fetchAll;
},invalidate:function(){
this._items=[];
this._nextUnfetchedIdx=0;
this._result=[];
this._indexMap=[];
this._resultStartIdx=0;
},_fetch:function(_758,_759){
if(!this._filter){
var _75a=_758.onBegin,_75b=this;
_758.onBegin=function(size,r){
_744(_758.scope,_75a)(size,r);
_75b.onFiltered(size,size);
};
this.originFetch(_758);
return _758;
}
try{
var _75c=_759?_759._nextResultItemIdx:_758.start;
_75c=_75c||0;
if(!_759){
this._result=[];
this._resultStartIdx=_75c;
var _75d;
if(dojo.isArray(_758.sort)&&_758.sort.length>0&&(_75d=dojo.toJson(_758.sort))!=this._lastSortInfo){
this.invalidate();
this._lastSortInfo=_75d;
}
}
var end=typeof _758.count=="number"?_75c+_758.count-this._result.length:this._items.length;
if(this._result.length){
this._result=this._result.concat(this._items.slice(_75c,end));
}else{
this._result=this._items.slice(_758.start,typeof _758.count=="number"?_758.start+_758.count:this._items.length);
}
if(this._result.length>=_758.count||this._hasReachedStoreEnd()){
this._completeQuery(_758);
}else{
if(!_759){
_759=_746(_758);
_759.onBegin=dojo.hitch(this,this._onFetchBegin);
_759.onComplete=dojo.hitch(this,function(_75e,req){
this._nextUnfetchedIdx+=_75e.length;
this._doFilter(_75e,req.start,_758);
this._fetch(_758,req);
});
}
_759.start=this._nextUnfetchedIdx;
if(this._fetchAll){
delete _759.count;
}
_759._nextResultItemIdx=end<this._items.length?end:this._items.length;
this.originFetch(_759);
}
}
catch(e){
if(_758.onError){
_744(_758.scope,_758.onError)(e,_758);
}else{
throw e;
}
}
return _758;
},_hasReachedStoreEnd:function(){
return this._storeSize>=0&&this._nextUnfetchedIdx>=this._storeSize;
},_applyFilter:function(_75f,_760){
var g=this._getter,s=this._store;
try{
return !!(this._filter.applyRow(_75f,function(item,arg){
return g(item,arg,_760,s);
}).getValue());
}
catch(e){
console.warn("FilterLayer._applyFilter() error: ",e);
return false;
}
},_doFilter:function(_761,_762,_763){
for(var i=0,cnt=0;i<_761.length;++i){
if(this._applyFilter(_761[i],_762+i)){
_744(_763.scope,_763.onItem)(_761[i],_763);
cnt+=this._addCachedItems(_761[i],this._items.length);
this._indexMap.push(_762+i);
}
}
},_onFetchBegin:function(size,req){
this._storeSize=size;
},_completeQuery:function(_764){
var size=this._items.length;
if(this._nextUnfetchedIdx<this._storeSize){
size++;
}
_744(_764.scope,_764.onBegin)(size,_764);
this.onFiltered(this._items.length,this._storeSize);
_744(_764.scope,_764.onComplete)(this._result,_764);
},_addCachedItems:function(_765,_766){
if(!dojo.isArray(_765)){
_765=[_765];
}
for(var k=0;k<_765.length;++k){
this._items[_766+k]=_765[k];
}
return _765.length;
},onRowMappingChange:function(_767){
if(this._filter){
var m=dojo.clone(_767),_768={};
for(var r in m){
r=parseInt(r,10);
_767[this._indexMap[r]]=this._indexMap[m[r]];
if(!_768[this._indexMap[r]]){
_768[this._indexMap[r]]=true;
}
if(!_768[r]){
_768[r]=true;
delete _767[r];
}
}
}
}});
})();
}
if(!dojo._hasResource["dijit._HasDropDown"]){
dojo._hasResource["dijit._HasDropDown"]=true;
dojo.provide("dijit._HasDropDown");
dojo.declare("dijit._HasDropDown",null,{_buttonNode:null,_arrowWrapperNode:null,_popupStateNode:null,_aroundNode:null,dropDown:null,autoWidth:true,forceWidth:false,maxHeight:0,dropDownPosition:["below","above"],_stopClickEvents:true,_onDropDownMouseDown:function(e){
if(this.disabled||this.readOnly){
return;
}
dojo.stopEvent(e);
this._docHandler=this.connect(dojo.doc,"onmouseup","_onDropDownMouseUp");
this.toggleDropDown();
},_onDropDownMouseUp:function(e){
if(e&&this._docHandler){
this.disconnect(this._docHandler);
}
var _769=this.dropDown,_76a=false;
if(e&&this._opened){
var c=dojo.position(this._buttonNode,true);
if(!(e.pageX>=c.x&&e.pageX<=c.x+c.w)||!(e.pageY>=c.y&&e.pageY<=c.y+c.h)){
var t=e.target;
while(t&&!_76a){
if(dojo.hasClass(t,"dijitPopup")){
_76a=true;
}else{
t=t.parentNode;
}
}
if(_76a){
t=e.target;
if(_769.onItemClick){
var _76b;
while(t&&!(_76b=dijit.byNode(t))){
t=t.parentNode;
}
if(_76b&&_76b.onClick&&_76b.getParent){
_76b.getParent().onItemClick(_76b,e);
}
}
return;
}
}
}
if(this._opened&&_769.focus&&_769.autoFocus!==false){
window.setTimeout(dojo.hitch(_769,"focus"),1);
}
},_onDropDownClick:function(e){
if(this._stopClickEvents){
dojo.stopEvent(e);
}
},buildRendering:function(){
this.inherited(arguments);
this._buttonNode=this._buttonNode||this.focusNode||this.domNode;
this._popupStateNode=this._popupStateNode||this.focusNode||this._buttonNode;
var _76c={"after":this.isLeftToRight()?"Right":"Left","before":this.isLeftToRight()?"Left":"Right","above":"Up","below":"Down","left":"Left","right":"Right"}[this.dropDownPosition[0]]||this.dropDownPosition[0]||"Down";
dojo.addClass(this._arrowWrapperNode||this._buttonNode,"dijit"+_76c+"ArrowButton");
},postCreate:function(){
this.inherited(arguments);
this.connect(this._buttonNode,"onmousedown","_onDropDownMouseDown");
this.connect(this._buttonNode,"onclick","_onDropDownClick");
this.connect(this.focusNode,"onkeypress","_onKey");
this.connect(this.focusNode,"onkeyup","_onKeyUp");
},destroy:function(){
if(this.dropDown){
if(!this.dropDown._destroyed){
this.dropDown.destroyRecursive();
}
delete this.dropDown;
}
this.inherited(arguments);
},_onKey:function(e){
if(this.disabled||this.readOnly){
return;
}
var d=this.dropDown,_76d=e.target;
if(d&&this._opened&&d.handleKey){
if(d.handleKey(e)===false){
dojo.stopEvent(e);
return;
}
}
if(d&&this._opened&&e.charOrCode==dojo.keys.ESCAPE){
this.closeDropDown();
dojo.stopEvent(e);
}else{
if(!this._opened&&(e.charOrCode==dojo.keys.DOWN_ARROW||((e.charOrCode==dojo.keys.ENTER||e.charOrCode==" ")&&((_76d.tagName||"").toLowerCase()!=="input"||(_76d.type&&_76d.type.toLowerCase()!=="text"))))){
this._toggleOnKeyUp=true;
dojo.stopEvent(e);
}
}
},_onKeyUp:function(){
if(this._toggleOnKeyUp){
delete this._toggleOnKeyUp;
this.toggleDropDown();
var d=this.dropDown;
if(d&&d.focus){
setTimeout(dojo.hitch(d,"focus"),1);
}
}
},_onBlur:function(){
var _76e=dijit._curFocus&&this.dropDown&&dojo.isDescendant(dijit._curFocus,this.dropDown.domNode);
this.closeDropDown(_76e);
this.inherited(arguments);
},isLoaded:function(){
return true;
},loadDropDown:function(_76f){
_76f();
},toggleDropDown:function(){
if(this.disabled||this.readOnly){
return;
}
if(!this._opened){
if(!this.isLoaded()){
this.loadDropDown(dojo.hitch(this,"openDropDown"));
return;
}else{
this.openDropDown();
}
}else{
this.closeDropDown();
}
},openDropDown:function(){
var _770=this.dropDown,_771=_770.domNode,_772=this._aroundNode||this.domNode,self=this;
if(!this._preparedNode){
this._preparedNode=true;
if(_771.style.width){
this._explicitDDWidth=true;
}
if(_771.style.height){
this._explicitDDHeight=true;
}
}
if(this.maxHeight||this.forceWidth||this.autoWidth){
var _773={display:"",visibility:"hidden"};
if(!this._explicitDDWidth){
_773.width="";
}
if(!this._explicitDDHeight){
_773.height="";
}
dojo.style(_771,_773);
var _774=this.maxHeight;
if(_774==-1){
var _775=dojo.window.getBox(),_776=dojo.position(_772,false);
_774=Math.floor(Math.max(_776.y,_775.h-(_776.y+_776.h)));
}
if(_770.startup&&!_770._started){
_770.startup();
}
dijit.popup.moveOffScreen(_770);
var mb=dojo._getMarginSize(_771);
var _777=(_774&&mb.h>_774);
dojo.style(_771,{overflowX:"hidden",overflowY:_777?"auto":"hidden"});
if(_777){
mb.h=_774;
if("w" in mb){
mb.w+=16;
}
}else{
delete mb.h;
}
if(this.forceWidth){
mb.w=_772.offsetWidth;
}else{
if(this.autoWidth){
mb.w=Math.max(mb.w,_772.offsetWidth);
}else{
delete mb.w;
}
}
if(dojo.isFunction(_770.resize)){
_770.resize(mb);
}else{
dojo.marginBox(_771,mb);
}
}
var _778=dijit.popup.open({parent:this,popup:_770,around:_772,orient:dijit.getPopupAroundAlignment((this.dropDownPosition&&this.dropDownPosition.length)?this.dropDownPosition:["below"],this.isLeftToRight()),onExecute:function(){
self.closeDropDown(true);
},onCancel:function(){
self.closeDropDown(true);
},onClose:function(){
dojo.attr(self._popupStateNode,"popupActive",false);
dojo.removeClass(self._popupStateNode,"dijitHasDropDownOpen");
self._opened=false;
}});
dojo.attr(this._popupStateNode,"popupActive","true");
dojo.addClass(self._popupStateNode,"dijitHasDropDownOpen");
this._opened=true;
return _778;
},closeDropDown:function(_779){
if(this._opened){
if(_779){
this.focus();
}
dijit.popup.close(this.dropDown);
this._opened=false;
}
}});
}
if(!dojo._hasResource["dijit.form.Button"]){
dojo._hasResource["dijit.form.Button"]=true;
dojo.provide("dijit.form.Button");
dojo.declare("dijit.form.Button",dijit.form._FormWidget,{label:"",showLabel:true,iconClass:"",type:"button",baseClass:"dijitButton",templateString:dojo.cache("dijit.form","templates/Button.html","<span class=\"dijit dijitReset dijitInline\"\r\n\t><span class=\"dijitReset dijitInline dijitButtonNode\"\r\n\t\tdojoAttachEvent=\"ondijitclick:_onButtonClick\"\r\n\t\t><span class=\"dijitReset dijitStretch dijitButtonContents\"\r\n\t\t\tdojoAttachPoint=\"titleNode,focusNode\"\r\n\t\t\trole=\"button\" aria-labelledby=\"${id}_label\"\r\n\t\t\t><span class=\"dijitReset dijitInline dijitIcon\" dojoAttachPoint=\"iconNode\"></span\r\n\t\t\t><span class=\"dijitReset dijitToggleButtonIconChar\">&#x25CF;</span\r\n\t\t\t><span class=\"dijitReset dijitInline dijitButtonText\"\r\n\t\t\t\tid=\"${id}_label\"\r\n\t\t\t\tdojoAttachPoint=\"containerNode\"\r\n\t\t\t></span\r\n\t\t></span\r\n\t></span\r\n\t><input ${!nameAttrSetting} type=\"${type}\" value=\"${value}\" class=\"dijitOffScreen\" tabIndex=\"-1\"\r\n\t\tdojoAttachPoint=\"valueNode\"\r\n/></span>\r\n"),attributeMap:dojo.delegate(dijit.form._FormWidget.prototype.attributeMap,{value:"valueNode"}),_onClick:function(e){
if(this.disabled){
return false;
}
this._clicked();
return this.onClick(e);
},_onButtonClick:function(e){
if(this._onClick(e)===false){
e.preventDefault();
}else{
if(this.type=="submit"&&!(this.valueNode||this.focusNode).form){
for(var node=this.domNode;node.parentNode;node=node.parentNode){
var _77a=dijit.byNode(node);
if(_77a&&typeof _77a._onSubmit=="function"){
_77a._onSubmit(e);
break;
}
}
}else{
if(this.valueNode){
this.valueNode.click();
e.preventDefault();
}
}
}
},buildRendering:function(){
this.inherited(arguments);
dojo.setSelectable(this.focusNode,false);
},_fillContent:function(_77b){
if(_77b&&(!this.params||!("label" in this.params))){
this.set("label",_77b.innerHTML);
}
},_setShowLabelAttr:function(val){
if(this.containerNode){
dojo.toggleClass(this.containerNode,"dijitDisplayNone",!val);
}
this._set("showLabel",val);
},onClick:function(e){
return true;
},_clicked:function(e){
},setLabel:function(_77c){
dojo.deprecated("dijit.form.Button.setLabel() is deprecated.  Use set('label', ...) instead.","","2.0");
this.set("label",_77c);
},_setLabelAttr:function(_77d){
this._set("label",_77d);
this.containerNode.innerHTML=_77d;
if(this.showLabel==false&&!this.params.title){
this.titleNode.title=dojo.trim(this.containerNode.innerText||this.containerNode.textContent||"");
}
},_setIconClassAttr:function(val){
var _77e=this.iconClass||"dijitNoIcon",_77f=val||"dijitNoIcon";
dojo.replaceClass(this.iconNode,_77f,_77e);
this._set("iconClass",val);
}});
dojo.declare("dijit.form.DropDownButton",[dijit.form.Button,dijit._Container,dijit._HasDropDown],{baseClass:"dijitDropDownButton",templateString:dojo.cache("dijit.form","templates/DropDownButton.html","<span class=\"dijit dijitReset dijitInline\"\r\n\t><span class='dijitReset dijitInline dijitButtonNode'\r\n\t\tdojoAttachEvent=\"ondijitclick:_onButtonClick\" dojoAttachPoint=\"_buttonNode\"\r\n\t\t><span class=\"dijitReset dijitStretch dijitButtonContents\"\r\n\t\t\tdojoAttachPoint=\"focusNode,titleNode,_arrowWrapperNode\"\r\n\t\t\trole=\"button\" aria-haspopup=\"true\" aria-labelledby=\"${id}_label\"\r\n\t\t\t><span class=\"dijitReset dijitInline dijitIcon\"\r\n\t\t\t\tdojoAttachPoint=\"iconNode\"\r\n\t\t\t></span\r\n\t\t\t><span class=\"dijitReset dijitInline dijitButtonText\"\r\n\t\t\t\tdojoAttachPoint=\"containerNode,_popupStateNode\"\r\n\t\t\t\tid=\"${id}_label\"\r\n\t\t\t></span\r\n\t\t\t><span class=\"dijitReset dijitInline dijitArrowButtonInner\"></span\r\n\t\t\t><span class=\"dijitReset dijitInline dijitArrowButtonChar\">&#9660;</span\r\n\t\t></span\r\n\t></span\r\n\t><input ${!nameAttrSetting} type=\"${type}\" value=\"${value}\" class=\"dijitOffScreen\" tabIndex=\"-1\"\r\n\t\tdojoAttachPoint=\"valueNode\"\r\n/></span>\r\n"),_fillContent:function(){
if(this.srcNodeRef){
var _780=dojo.query("*",this.srcNodeRef);
dijit.form.DropDownButton.superclass._fillContent.call(this,_780[0]);
this.dropDownContainer=this.srcNodeRef;
}
},startup:function(){
if(this._started){
return;
}
if(!this.dropDown&&this.dropDownContainer){
var _781=dojo.query("[widgetId]",this.dropDownContainer)[0];
this.dropDown=dijit.byNode(_781);
delete this.dropDownContainer;
}
if(this.dropDown){
dijit.popup.hide(this.dropDown);
}
this.inherited(arguments);
},isLoaded:function(){
var _782=this.dropDown;
return (!!_782&&(!_782.href||_782.isLoaded));
},loadDropDown:function(){
var _783=this.dropDown;
if(!_783){
return;
}
if(!this.isLoaded()){
var _784=dojo.connect(_783,"onLoad",this,function(){
dojo.disconnect(_784);
this.openDropDown();
});
_783.refresh();
}else{
this.openDropDown();
}
},isFocusable:function(){
return this.inherited(arguments)&&!this._mouseDown;
},_onDropDownMouseUp:function(e){
if(this.dynamic&&this._onItemClickHandler){
dojo.disconnect(this._onItemClickHandler);
dojo.disconnect(this._buttonClickHandler);
dojo.disconnect(this._onMouseOverHandler);
}
this.inherited(arguments);
},_onDropDownClick:function(e){
if(this.dynamic){
this._onItemClickHandler=dojo.connect(this.dropDown,"onItemClick",this,"_onDropDownMenuChange");
this._onMouseOverHandler=dojo.connect(this.dropDown,"onMouseOver",this,"_onDropDownMouseOver");
}
this.inherited(arguments);
},_onDropDownMouseOver:function(evt){
var t=evt.target;
var _785;
while(t&&!(_785=dijit.byNode(t))){
t=t.parentNode;
}
if(_785.popup){
this._onItemClickHandler=dojo.connect(_785.popup,"onItemClick",this,"_onDropDownMenuChange");
}
},_onDropDownMenuChange:function(item,evt){
if(!item.popup&&!item.disabled){
if(this.showLabel){
this.set("label",item.label);
}
this.set("iconClass",item.iconClass);
this._buttonClickHandler=dojo.connect(this,"onClick",item,"onClick");
}
}});
dojo.declare("dijit.form.ComboButton",dijit.form.DropDownButton,{templateString:dojo.cache("dijit.form","templates/ComboButton.html","<table class=\"dijit dijitReset dijitInline dijitLeft\"\r\n\tcellspacing='0' cellpadding='0' role=\"presentation\"\r\n\t><tbody role=\"presentation\"><tr role=\"presentation\"\r\n\t\t><td class=\"dijitReset dijitStretch dijitButtonNode\" dojoAttachPoint=\"buttonNode\" dojoAttachEvent=\"ondijitclick:_onButtonClick,onkeypress:_onButtonKeyPress\"\r\n\t\t><div id=\"${id}_button\" class=\"dijitReset dijitButtonContents\"\r\n\t\t\tdojoAttachPoint=\"titleNode\"\r\n\t\t\trole=\"button\" aria-labelledby=\"${id}_label\"\r\n\t\t\t><div class=\"dijitReset dijitInline dijitIcon\" dojoAttachPoint=\"iconNode\" role=\"presentation\"></div\r\n\t\t\t><div class=\"dijitReset dijitInline dijitButtonText\" id=\"${id}_label\" dojoAttachPoint=\"containerNode\" role=\"presentation\"></div\r\n\t\t></div\r\n\t\t></td\r\n\t\t><td id=\"${id}_arrow\" class='dijitReset dijitRight dijitButtonNode dijitArrowButton'\r\n\t\t\tdojoAttachPoint=\"_popupStateNode,focusNode,_buttonNode\"\r\n\t\t\tdojoAttachEvent=\"onkeypress:_onArrowKeyPress\"\r\n\t\t\ttitle=\"${optionsTitle}\"\r\n\t\t\trole=\"button\" aria-haspopup=\"true\"\r\n\t\t\t><div class=\"dijitReset dijitArrowButtonInner\" role=\"presentation\"></div\r\n\t\t\t><div class=\"dijitReset dijitArrowButtonChar\" role=\"presentation\">&#9660;</div\r\n\t\t></td\r\n\t\t><td style=\"display:none !important;\"\r\n\t\t\t><input ${!nameAttrSetting} type=\"${type}\" value=\"${value}\" dojoAttachPoint=\"valueNode\"\r\n\t\t/></td></tr></tbody\r\n></table>\r\n"),attributeMap:dojo.mixin(dojo.clone(dijit.form.Button.prototype.attributeMap),{id:"",tabIndex:["focusNode","titleNode"],title:"titleNode"}),optionsTitle:"",baseClass:"dijitComboButton",cssStateNodes:{"buttonNode":"dijitButtonNode","titleNode":"dijitButtonContents","_popupStateNode":"dijitDownArrowButton"},_focusedNode:null,dynamic:false,_onButtonKeyPress:function(evt){
if(evt.charOrCode==dojo.keys[this.isLeftToRight()?"RIGHT_ARROW":"LEFT_ARROW"]){
dijit.focus(this._popupStateNode);
dojo.stopEvent(evt);
}
},_onArrowKeyPress:function(evt){
if(evt.charOrCode==dojo.keys[this.isLeftToRight()?"LEFT_ARROW":"RIGHT_ARROW"]){
dijit.focus(this.titleNode);
dojo.stopEvent(evt);
}
},focus:function(_786){
if(!this.disabled){
dijit.focus(_786=="start"?this.titleNode:this._popupStateNode);
}
}});
dojo.declare("dijit.form.ToggleButton",dijit.form.Button,{baseClass:"dijitToggleButton",checked:false,attributeMap:dojo.mixin(dojo.clone(dijit.form.Button.prototype.attributeMap),{checked:"focusNode"}),_clicked:function(evt){
this.set("checked",!this.checked);
},_setCheckedAttr:function(_787,_788){
this._set("checked",_787);
dojo.attr(this.focusNode||this.domNode,"checked",_787);
dijit.setWaiState(this.focusNode||this.domNode,"pressed",_787);
this._handleOnChange(_787,_788);
},setChecked:function(_789){
dojo.deprecated("setChecked("+_789+") is deprecated. Use set('checked',"+_789+") instead.","","2.0");
this.set("checked",_789);
},reset:function(){
this._hasBeenBlurred=false;
this.set("checked",this.params.checked||false);
}});
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.filter.FilterBar"]){
dojo._hasResource["dojox.grid.enhanced.plugins.filter.FilterBar"]=true;
dojo.provide("dojox.grid.enhanced.plugins.filter.FilterBar");
(function(){
var _78a="dojoxGridFBarHover",_78b="dojoxGridFBarFiltered",_78c=function(evt){
try{
if(evt&&evt.preventDefault){
dojo.stopEvent(evt);
}
}
catch(e){
}
};
dojo.declare("dojox.grid.enhanced.plugins.filter.FilterBar",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dojox.grid","enhanced/templates/FilterBar.html","<table class=\"dojoxGridFBar\" border=\"0\" cellspacing=\"0\" dojoAttachEvent=\"onclick:_onClickFilterBar, onmouseenter:_onMouseEnter, onmouseleave:_onMouseLeave, onmousemove:_onMouseMove\"\r\n\t><tr><td class=\"dojoxGridFBarBtnTD\"\r\n\t\t><span dojoType=\"dijit.form.Button\" class=\"dojoxGridFBarBtn\" dojoAttachPoint=\"defineFilterButton\" label=\"...\" iconClass=\"dojoxGridFBarDefFilterBtnIcon\" showLabel=\"true\" dojoAttachEvent=\"onClick:_showFilterDefDialog, onMouseEnter:_onEnterButton, onMouseLeave:_onLeaveButton, onMouseMove:_onMoveButton\"></span\r\n\t></td><td class=\"dojoxGridFBarInfoTD\"\r\n\t\t><span class=\"dojoxGridFBarInner\"\r\n\t\t\t><span class=\"dojoxGridFBarStatus\" dojoAttachPoint=\"statusBarNode\">${_noFilterMsg}</span\r\n\t\t\t><span dojoType=\"dijit.form.Button\" class=\"dojoxGridFBarClearFilterBtn\" dojoAttachPoint=\"clearFilterButton\" \r\n\t\t\t\tlabel=\"${_filterBarClearBtnLabel}\" iconClass=\"dojoxGridFBarClearFilterBtnIcon\" showLabel=\"true\" \r\n\t\t\t\tdojoAttachEvent=\"onClick:_clearFilterDefDialog, onMouseEnter:_onEnterButton, onMouseLeave:_onLeaveButton, onMouseMove:_onMoveButton\"></span\r\n\t\t\t><span dojotype=\"dijit.form.Button\" class=\"dojoxGridFBarCloseBtn\" dojoAttachPoint=\"closeFilterBarButton\" \r\n\t\t\t\tlabel=\"${_closeFilterBarBtnLabel}\" iconClass=\"dojoxGridFBarCloseBtnIcon\" showLabel=\"false\" \r\n\t\t\t\tdojoAttachEvent=\"onClick:_closeFilterBar, onMouseEnter:_onEnterButton, onMouseLeave:_onLeaveButton, onMouseMove:_onMoveButton\"></span\r\n\t\t></span\r\n\t></td></tr\r\n></table>\r\n"),widgetsInTemplate:true,_timeout_statusTooltip:300,_handle_statusTooltip:null,_curColIdx:-1,plugin:null,postMixInProperties:function(){
var _78d=this.plugin;
var nls=_78d.nls;
this._filterBarDefBtnLabel=nls["filterBarDefButton"];
this._filterBarClearBtnLabel=nls["filterBarClearButton"];
this._closeFilterBarBtnLabel=nls["closeFilterBarBtn"];
var _78e=_78d.args.itemsName||nls["defaultItemsName"];
this._noFilterMsg=dojo.string.substitute(nls["filterBarMsgNoFilterTemplate"],["",_78e]);
var t=this.plugin.args.statusTipTimeout;
if(typeof t=="number"){
this._timeout_statusTooltip=t;
}
var g=_78d.grid;
g.showFilterBar=dojo.hitch(this,"showFilterBar");
g.toggleFilterBar=dojo.hitch(this,"toggleFilterBar");
g.isFilterBarShown=dojo.hitch(this,"isFilterBarShown");
},postCreate:function(){
this.inherited(arguments);
if(!this.plugin.args.closeFilterbarButton){
dojo.style(this.closeFilterBarButton.domNode,"display","none");
}
var _78f=this,g=this.plugin.grid,_790=this.oldGetHeaderHeight=dojo.hitch(g,g._getHeaderHeight);
this.placeAt(g.viewsHeaderNode,"after");
this.connect(this.plugin.filterDefDialog,"showDialog","_onShowFilterDefDialog");
this.connect(this.plugin.filterDefDialog,"closeDialog","_onCloseFilterDefDialog");
this.connect(g.layer("filter"),"onFiltered",this._onFiltered);
this.defineFilterButton.domNode.title=this.plugin.nls["filterBarDefButton"];
if(dojo.hasClass(dojo.body(),"dijit_a11y")){
this.defineFilterButton.set("label",this.plugin.nls["a11yFilterBarDefButton"]);
}
this.connect(this.defineFilterButton.domNode,"click",_78c);
this.connect(this.clearFilterButton.domNode,"click",_78c);
this.connect(this.closeFilterBarButton.domNode,"click",_78c);
this.toggleClearFilterBtn(true);
this._initAriaInfo();
g._getHeaderHeight=function(){
return _790()+dojo.marginBox(_78f.domNode).h;
};
g.focus.addArea({name:"filterbar",onFocus:dojo.hitch(this,this._onFocusFilterBar,false),onBlur:dojo.hitch(this,this._onBlurFilterBar)});
g.focus.placeArea("filterbar","after","header");
},uninitialize:function(){
var g=this.plugin.grid;
g._getHeaderHeight=this.oldGetHeaderHeight;
g.focus.removeArea("filterbar");
this.plugin=null;
},isFilterBarShown:function(){
return dojo.style(this.domNode,"display")!="none";
},showFilterBar:function(_791,_792,_793){
var g=this.plugin.grid;
if(_792){
if(Boolean(_791)==this.isFilterBarShown()){
return;
}
_793=_793||{};
var _794=[],_795=500;
_794.push(dojo.fx[_791?"wipeIn":"wipeOut"](dojo.mixin({"node":this.domNode,"duration":_795},_793)));
var _796=g.views.views[0].domNode.offsetHeight;
var prop={"duration":_795,"properties":{"height":{"end":dojo.hitch(this,function(){
var _797=this.domNode.scrollHeight;
if(dojo.isFF){
_797-=2;
}
return _791?(_796-_797):(_796+_797);
})}}};
dojo.forEach(g.views.views,function(view){
_794.push(dojo.animateProperty(dojo.mixin({"node":view.domNode},prop,_793)),dojo.animateProperty(dojo.mixin({"node":view.scrollboxNode},prop,_793)));
});
_794.push(dojo.animateProperty(dojo.mixin({"node":g.viewsNode},prop,_793)));
dojo.fx.combine(_794).play();
}else{
dojo.style(this.domNode,"display",_791?"":"none");
g.update();
}
},toggleFilterBar:function(_798,_799){
this.showFilterBar(!this.isFilterBarShown(),_798,_799);
},getColumnIdx:function(_79a){
var _79b=dojo.query("[role='columnheader']",this.plugin.grid.viewsHeaderNode);
var idx=-1;
for(var i=_79b.length-1;i>=0;--i){
var _79c=dojo.coords(_79b[i]);
if(_79a>=_79c.x&&_79a<_79c.x+_79c.w){
idx=i;
break;
}
}
if(idx>=0&&this.plugin.grid.layout.cells[idx].filterable!==false){
return idx;
}else{
return -1;
}
},toggleClearFilterBtn:function(_79d){
dojo.style(this.clearFilterButton.domNode,"display",_79d?"none":"");
},_closeFilterBar:function(e){
_78c(e);
var _79e=this.plugin.filterDefDialog.getCriteria();
if(_79e){
var _79f=dojo.connect(this.plugin.filterDefDialog,"clearFilter",this,function(){
this.showFilterBar(false,true);
dojo.disconnect(_79f);
});
this._clearFilterDefDialog(e);
}else{
this.showFilterBar(false,true);
}
},_showFilterDefDialog:function(e){
_78c(e);
this.plugin.filterDefDialog.showDialog(this._curColIdx);
this.plugin.grid.focus.focusArea("filterbar");
},_clearFilterDefDialog:function(e){
_78c(e);
this.plugin.filterDefDialog.onClearFilter();
this.plugin.grid.focus.focusArea("filterbar");
},_onEnterButton:function(e){
this._onBlurFilterBar();
_78c(e);
},_onMoveButton:function(e){
this._onBlurFilterBar();
},_onLeaveButton:function(e){
this._leavingBtn=true;
},_onShowFilterDefDialog:function(_7a0){
if(typeof _7a0=="number"){
this._curColIdx=_7a0;
}
this._defPaneIsShown=true;
},_onCloseFilterDefDialog:function(){
this._defPaneIsShown=false;
this._curColIdx=-1;
dijit.focus(this.defineFilterButton.focusNode);
},_onClickFilterBar:function(e){
_78c(e);
this._clearStatusTipTimeout();
this.plugin.grid.focus.focusArea("filterbar");
this.plugin.filterDefDialog.showDialog(this.getColumnIdx(e.clientX));
},_onMouseEnter:function(e){
this._onFocusFilterBar(true,null);
this._updateTipPosition(e);
this._setStatusTipTimeout();
},_onMouseMove:function(e){
if(this._leavingBtn){
this._onFocusFilterBar(true,null);
this._leavingBtn=false;
}
if(this._isFocused){
this._setStatusTipTimeout();
this._highlightHeader(this.getColumnIdx(e.clientX));
if(this._handle_statusTooltip){
this._updateTipPosition(e);
}
}
},_onMouseLeave:function(e){
this._onBlurFilterBar();
},_updateTipPosition:function(evt){
this._tippos={x:evt.pageX,y:evt.pageY};
},_onFocusFilterBar:function(_7a1,evt,step){
if(!this.isFilterBarShown()){
return false;
}
this._isFocused=true;
dojo.addClass(this.domNode,_78a);
if(!_7a1){
var _7a2=dojo.style(this.clearFilterButton.domNode,"display")!=="none";
var _7a3=dojo.style(this.closeFilterBarButton.domNode,"display")!=="none";
if(typeof this._focusPos=="undefined"){
if(step>0){
this._focusPos=0;
}else{
if(_7a3){
this._focusPos=1;
}else{
this._focusPos=0;
}
if(_7a2){
++this._focusPos;
}
}
}
if(this._focusPos===0){
dijit.focus(this.defineFilterButton.focusNode);
}else{
if(this._focusPos===1&&_7a2){
dijit.focus(this.clearFilterButton.focusNode);
}else{
dijit.focus(this.closeFilterBarButton.focusNode);
}
}
}
_78c(evt);
return true;
},_onBlurFilterBar:function(evt,step){
if(this._isFocused){
this._isFocused=false;
dojo.removeClass(this.domNode,_78a);
this._clearStatusTipTimeout();
this._clearHeaderHighlight();
}
var _7a4=true;
if(step){
var _7a5=3;
if(dojo.style(this.closeFilterBarButton.domNode,"display")==="none"){
--_7a5;
}
if(dojo.style(this.clearFilterButton.domNode,"display")==="none"){
--_7a5;
}
if(_7a5==1){
delete this._focusPos;
}else{
var _7a6=this._focusPos;
for(var next=_7a6+step;next<0;next+=_7a5){
}
next%=_7a5;
if((step>0&&next<_7a6)||(step<0&&next>_7a6)){
delete this._focusPos;
}else{
this._focusPos=next;
_7a4=false;
}
}
}
return _7a4;
},_onFiltered:function(_7a7,_7a8){
var p=this.plugin,_7a9=p.args.itemsName||p.nls["defaultItemsName"],msg="",g=p.grid,_7aa=g.layer("filter");
if(_7aa.filterDef()){
msg=dojo.string.substitute(p.nls["filterBarMsgHasFilterTemplate"],[_7a7,_7a8,_7a9]);
dojo.addClass(this.domNode,_78b);
}else{
msg=dojo.string.substitute(p.nls["filterBarMsgNoFilterTemplate"],[_7a8,_7a9]);
dojo.removeClass(this.domNode,_78b);
}
this.statusBarNode.innerHTML=msg;
this._focusPos=0;
},_initAriaInfo:function(){
var n=this.defineFilterButton.focusNode;
n.setAttribute("aria-label",this.plugin.nls["waiFilterBarDefButton"]);
n.removeAttribute("aria-labelledby");
n=this.clearFilterButton.focusNode;
n.setAttribute("aria-label",this.plugin.nls["waiFilterBarClearButton"]);
n.removeAttribute("aria-labelledby");
},_isInColumn:function(_7ab,_7ac,_7ad){
var _7ae=dojo.coords(_7ac);
return _7ab>=_7ae.x&&_7ab<_7ae.x+_7ae.w;
},_setStatusTipTimeout:function(){
this._clearStatusTipTimeout();
if(!this._defPaneIsShown){
this._handle_statusTooltip=setTimeout(dojo.hitch(this,this._showStatusTooltip),this._timeout_statusTooltip);
}
},_clearStatusTipTimeout:function(){
clearTimeout(this._handle_statusTooltip);
this._handle_statusTooltip=null;
},_showStatusTooltip:function(){
this._handle_statusTooltip=null;
this.plugin.filterStatusTip.showDialog(this._tippos.x,this._tippos.y,this.getColumnIdx(this._tippos.x));
},_highlightHeader:function(_7af){
if(_7af!=this._previousHeaderIdx){
var g=this.plugin.grid,cell=g.getCell(this._previousHeaderIdx);
if(cell){
dojo.removeClass(cell.getHeaderNode(),"dojoxGridCellOver");
}
cell=g.getCell(_7af);
if(cell){
dojo.addClass(cell.getHeaderNode(),"dojoxGridCellOver");
}
this._previousHeaderIdx=_7af;
}
},_clearHeaderHighlight:function(){
if(typeof this._previousHeaderIdx!="undefined"){
var g=this.plugin.grid,cell=g.getCell(this._previousHeaderIdx);
if(cell){
g.onHeaderCellMouseOut({cellNode:cell.getHeaderNode()});
}
delete this._previousHeaderIdx;
}
}});
})();
}
if(!dojo._hasResource["dijit.Tooltip"]){
dojo._hasResource["dijit.Tooltip"]=true;
dojo.provide("dijit.Tooltip");
dojo.declare("dijit._MasterTooltip",[dijit._Widget,dijit._Templated],{duration:dijit.defaultDuration,templateString:dojo.cache("dijit","templates/Tooltip.html","<div class=\"dijitTooltip dijitTooltipLeft\" id=\"dojoTooltip\"\r\n\t><div class=\"dijitTooltipContainer dijitTooltipContents\" dojoAttachPoint=\"containerNode\" role='alert'></div\r\n\t><div class=\"dijitTooltipConnector\" dojoAttachPoint=\"connectorNode\"></div\r\n></div>\r\n"),postCreate:function(){
dojo.body().appendChild(this.domNode);
this.bgIframe=new dijit.BackgroundIframe(this.domNode);
this.fadeIn=dojo.fadeIn({node:this.domNode,duration:this.duration,onEnd:dojo.hitch(this,"_onShow")});
this.fadeOut=dojo.fadeOut({node:this.domNode,duration:this.duration,onEnd:dojo.hitch(this,"_onHide")});
},show:function(_7b0,_7b1,_7b2,rtl){
if(this.aroundNode&&this.aroundNode===_7b1){
return;
}
this.domNode.width="auto";
if(this.fadeOut.status()=="playing"){
this._onDeck=arguments;
return;
}
this.containerNode.innerHTML=_7b0;
var pos=dijit.placeOnScreenAroundElement(this.domNode,_7b1,dijit.getPopupAroundAlignment((_7b2&&_7b2.length)?_7b2:dijit.Tooltip.defaultPosition,!rtl),dojo.hitch(this,"orient"));
dojo.style(this.domNode,"opacity",0);
this.fadeIn.play();
this.isShowingNow=true;
this.aroundNode=_7b1;
},orient:function(node,_7b3,_7b4,_7b5,_7b6){
this.connectorNode.style.top="";
var _7b7=_7b5.w-this.connectorNode.offsetWidth;
node.className="dijitTooltip "+{"BL-TL":"dijitTooltipBelow dijitTooltipABLeft","TL-BL":"dijitTooltipAbove dijitTooltipABLeft","BR-TR":"dijitTooltipBelow dijitTooltipABRight","TR-BR":"dijitTooltipAbove dijitTooltipABRight","BR-BL":"dijitTooltipRight","BL-BR":"dijitTooltipLeft"}[_7b3+"-"+_7b4];
this.domNode.style.width="auto";
var size=dojo.contentBox(this.domNode);
var _7b8=Math.min((Math.max(_7b7,1)),size.w);
var _7b9=_7b8<size.w;
this.domNode.style.width=_7b8+"px";
if(_7b9){
this.containerNode.style.overflow="auto";
var _7ba=this.containerNode.scrollWidth;
this.containerNode.style.overflow="visible";
if(_7ba>_7b8){
_7ba=_7ba+dojo.style(this.domNode,"paddingLeft")+dojo.style(this.domNode,"paddingRight");
this.domNode.style.width=_7ba+"px";
}
}
if(_7b4.charAt(0)=="B"&&_7b3.charAt(0)=="B"){
var mb=dojo.marginBox(node);
var _7bb=this.connectorNode.offsetHeight;
if(mb.h>_7b5.h){
var _7bc=_7b5.h-(_7b6.h/2)-(_7bb/2);
this.connectorNode.style.top=_7bc+"px";
this.connectorNode.style.bottom="";
}else{
this.connectorNode.style.bottom=Math.min(Math.max(_7b6.h/2-_7bb/2,0),mb.h-_7bb)+"px";
this.connectorNode.style.top="";
}
}else{
this.connectorNode.style.top="";
this.connectorNode.style.bottom="";
}
return Math.max(0,size.w-_7b7);
},_onShow:function(){
if(dojo.isIE){
this.domNode.style.filter="";
}
},hide:function(_7bd){
if(this._onDeck&&this._onDeck[1]==_7bd){
this._onDeck=null;
}else{
if(this.aroundNode===_7bd){
this.fadeIn.stop();
this.isShowingNow=false;
this.aroundNode=null;
this.fadeOut.play();
}else{
}
}
},_onHide:function(){
this.domNode.style.cssText="";
this.containerNode.innerHTML="";
if(this._onDeck){
this.show.apply(this,this._onDeck);
this._onDeck=null;
}
}});
dijit.showTooltip=function(_7be,_7bf,_7c0,rtl){
if(!dijit._masterTT){
dijit._masterTT=new dijit._MasterTooltip();
}
return dijit._masterTT.show(_7be,_7bf,_7c0,rtl);
};
dijit.hideTooltip=function(_7c1){
if(!dijit._masterTT){
dijit._masterTT=new dijit._MasterTooltip();
}
return dijit._masterTT.hide(_7c1);
};
dojo.declare("dijit.Tooltip",dijit._Widget,{label:"",showDelay:400,connectId:[],position:[],_setConnectIdAttr:function(_7c2){
dojo.forEach(this._connections||[],function(_7c3){
dojo.forEach(_7c3,dojo.hitch(this,"disconnect"));
},this);
var ary=dojo.isArrayLike(_7c2)?_7c2:(_7c2?[_7c2]:[]);
this._connections=dojo.map(ary,function(id){
var node=dojo.byId(id);
return node?[this.connect(node,"onmouseenter","_onTargetMouseEnter"),this.connect(node,"onmouseleave","_onTargetMouseLeave"),this.connect(node,"onfocus","_onTargetFocus"),this.connect(node,"onblur","_onTargetBlur")]:[];
},this);
this._set("connectId",_7c2);
this._connectIds=ary;
},addTarget:function(node){
var id=node.id||node;
if(dojo.indexOf(this._connectIds,id)==-1){
this.set("connectId",this._connectIds.concat(id));
}
},removeTarget:function(node){
var id=node.id||node,idx=dojo.indexOf(this._connectIds,id);
if(idx>=0){
this._connectIds.splice(idx,1);
this.set("connectId",this._connectIds);
}
},buildRendering:function(){
this.inherited(arguments);
dojo.addClass(this.domNode,"dijitTooltipData");
},startup:function(){
this.inherited(arguments);
var ids=this.connectId;
dojo.forEach(dojo.isArrayLike(ids)?ids:[ids],this.addTarget,this);
},_onTargetMouseEnter:function(e){
this._onHover(e);
},_onTargetMouseLeave:function(e){
this._onUnHover(e);
},_onTargetFocus:function(e){
this._focus=true;
this._onHover(e);
},_onTargetBlur:function(e){
this._focus=false;
this._onUnHover(e);
},_onHover:function(e){
if(!this._showTimer){
var _7c4=e.target;
this._showTimer=setTimeout(dojo.hitch(this,function(){
this.open(_7c4);
}),this.showDelay);
}
},_onUnHover:function(e){
if(this._focus){
return;
}
if(this._showTimer){
clearTimeout(this._showTimer);
delete this._showTimer;
}
this.close();
},open:function(_7c5){
if(this._showTimer){
clearTimeout(this._showTimer);
delete this._showTimer;
}
dijit.showTooltip(this.label||this.domNode.innerHTML,_7c5,this.position,!this.isLeftToRight());
this._connectNode=_7c5;
this.onShow(_7c5,this.position);
},close:function(){
if(this._connectNode){
dijit.hideTooltip(this._connectNode);
delete this._connectNode;
this.onHide();
}
if(this._showTimer){
clearTimeout(this._showTimer);
delete this._showTimer;
}
},onShow:function(_7c6,_7c7){
},onHide:function(){
},uninitialize:function(){
this.close();
this.inherited(arguments);
}});
dijit.Tooltip.defaultPosition=["after","before"];
}
if(!dojo._hasResource["dojo.data.util.filter"]){
dojo._hasResource["dojo.data.util.filter"]=true;
dojo.provide("dojo.data.util.filter");
dojo.getObject("data.util.filter",true,dojo);
dojo.data.util.filter.patternToRegExp=function(_7c8,_7c9){
var rxp="^";
var c=null;
for(var i=0;i<_7c8.length;i++){
c=_7c8.charAt(i);
switch(c){
case "\\":
rxp+=c;
i++;
rxp+=_7c8.charAt(i);
break;
case "*":
rxp+=".*";
break;
case "?":
rxp+=".";
break;
case "$":
case "^":
case "/":
case "+":
case ".":
case "|":
case "(":
case ")":
case "{":
case "}":
case "[":
case "]":
rxp+="\\";
default:
rxp+=c;
}
}
rxp+="$";
if(_7c9){
return new RegExp(rxp,"mi");
}else{
return new RegExp(rxp,"m");
}
};
}
if(!dojo._hasResource["dojo.data.util.sorter"]){
dojo._hasResource["dojo.data.util.sorter"]=true;
dojo.provide("dojo.data.util.sorter");
dojo.getObject("data.util.sorter",true,dojo);
dojo.data.util.sorter.basicComparator=function(a,b){
var r=-1;
if(a===null){
a=undefined;
}
if(b===null){
b=undefined;
}
if(a==b){
r=0;
}else{
if(a>b||a==null){
r=1;
}
}
return r;
};
dojo.data.util.sorter.createSortFunction=function(_7ca,_7cb){
var _7cc=[];
function _7cd(attr,dir,comp,s){
return function(_7ce,_7cf){
var a=s.getValue(_7ce,attr);
var b=s.getValue(_7cf,attr);
return dir*comp(a,b);
};
};
var _7d0;
var map=_7cb.comparatorMap;
var bc=dojo.data.util.sorter.basicComparator;
for(var i=0;i<_7ca.length;i++){
_7d0=_7ca[i];
var attr=_7d0.attribute;
if(attr){
var dir=(_7d0.descending)?-1:1;
var comp=bc;
if(map){
if(typeof attr!=="string"&&("toString" in attr)){
attr=attr.toString();
}
comp=map[attr]||bc;
}
_7cc.push(_7cd(attr,dir,comp,_7cb));
}
}
return function(rowA,rowB){
var i=0;
while(i<_7cc.length){
var ret=_7cc[i++](rowA,rowB);
if(ret!==0){
return ret;
}
}
return 0;
};
};
}
if(!dojo._hasResource["dojo.data.util.simpleFetch"]){
dojo._hasResource["dojo.data.util.simpleFetch"]=true;
dojo.provide("dojo.data.util.simpleFetch");
dojo.getObject("data.util.simpleFetch",true,dojo);
dojo.data.util.simpleFetch.fetch=function(_7d1){
_7d1=_7d1||{};
if(!_7d1.store){
_7d1.store=this;
}
var self=this;
var _7d2=function(_7d3,_7d4){
if(_7d4.onError){
var _7d5=_7d4.scope||dojo.global;
_7d4.onError.call(_7d5,_7d3,_7d4);
}
};
var _7d6=function(_7d7,_7d8){
var _7d9=_7d8.abort||null;
var _7da=false;
var _7db=_7d8.start?_7d8.start:0;
var _7dc=(_7d8.count&&(_7d8.count!==Infinity))?(_7db+_7d8.count):_7d7.length;
_7d8.abort=function(){
_7da=true;
if(_7d9){
_7d9.call(_7d8);
}
};
var _7dd=_7d8.scope||dojo.global;
if(!_7d8.store){
_7d8.store=self;
}
if(_7d8.onBegin){
_7d8.onBegin.call(_7dd,_7d7.length,_7d8);
}
if(_7d8.sort){
_7d7.sort(dojo.data.util.sorter.createSortFunction(_7d8.sort,self));
}
if(_7d8.onItem){
for(var i=_7db;(i<_7d7.length)&&(i<_7dc);++i){
var item=_7d7[i];
if(!_7da){
_7d8.onItem.call(_7dd,item,_7d8);
}
}
}
if(_7d8.onComplete&&!_7da){
var _7de=null;
if(!_7d8.onItem){
_7de=_7d7.slice(_7db,_7dc);
}
_7d8.onComplete.call(_7dd,_7de,_7d8);
}
};
this._fetchItems(_7d1,_7d6,_7d2);
return _7d1;
};
}
if(!dojo._hasResource["dojo.data.ItemFileReadStore"]){
dojo._hasResource["dojo.data.ItemFileReadStore"]=true;
dojo.provide("dojo.data.ItemFileReadStore");
dojo.declare("dojo.data.ItemFileReadStore",null,{constructor:function(_7df){
this._arrayOfAllItems=[];
this._arrayOfTopLevelItems=[];
this._loadFinished=false;
this._jsonFileUrl=_7df.url;
this._ccUrl=_7df.url;
this.url=_7df.url;
this._jsonData=_7df.data;
this.data=null;
this._datatypeMap=_7df.typeMap||{};
if(!this._datatypeMap["Date"]){
this._datatypeMap["Date"]={type:Date,deserialize:function(_7e0){
return dojo.date.stamp.fromISOString(_7e0);
}};
}
this._features={"dojo.data.api.Read":true,"dojo.data.api.Identity":true};
this._itemsByIdentity=null;
this._storeRefPropName="_S";
this._itemNumPropName="_0";
this._rootItemPropName="_RI";
this._reverseRefMap="_RRM";
this._loadInProgress=false;
this._queuedFetches=[];
if(_7df.urlPreventCache!==undefined){
this.urlPreventCache=_7df.urlPreventCache?true:false;
}
if(_7df.hierarchical!==undefined){
this.hierarchical=_7df.hierarchical?true:false;
}
if(_7df.clearOnClose){
this.clearOnClose=true;
}
if("failOk" in _7df){
this.failOk=_7df.failOk?true:false;
}
},url:"",_ccUrl:"",data:null,typeMap:null,clearOnClose:false,urlPreventCache:false,failOk:false,hierarchical:true,_assertIsItem:function(item){
if(!this.isItem(item)){
throw new Error("dojo.data.ItemFileReadStore: Invalid item argument.");
}
},_assertIsAttribute:function(_7e1){
if(typeof _7e1!=="string"){
throw new Error("dojo.data.ItemFileReadStore: Invalid attribute argument.");
}
},getValue:function(item,_7e2,_7e3){
var _7e4=this.getValues(item,_7e2);
return (_7e4.length>0)?_7e4[0]:_7e3;
},getValues:function(item,_7e5){
this._assertIsItem(item);
this._assertIsAttribute(_7e5);
return (item[_7e5]||[]).slice(0);
},getAttributes:function(item){
this._assertIsItem(item);
var _7e6=[];
for(var key in item){
if((key!==this._storeRefPropName)&&(key!==this._itemNumPropName)&&(key!==this._rootItemPropName)&&(key!==this._reverseRefMap)){
_7e6.push(key);
}
}
return _7e6;
},hasAttribute:function(item,_7e7){
this._assertIsItem(item);
this._assertIsAttribute(_7e7);
return (_7e7 in item);
},containsValue:function(item,_7e8,_7e9){
var _7ea=undefined;
if(typeof _7e9==="string"){
_7ea=dojo.data.util.filter.patternToRegExp(_7e9,false);
}
return this._containsValue(item,_7e8,_7e9,_7ea);
},_containsValue:function(item,_7eb,_7ec,_7ed){
return dojo.some(this.getValues(item,_7eb),function(_7ee){
if(_7ee!==null&&!dojo.isObject(_7ee)&&_7ed){
if(_7ee.toString().match(_7ed)){
return true;
}
}else{
if(_7ec===_7ee){
return true;
}
}
});
},isItem:function(_7ef){
if(_7ef&&_7ef[this._storeRefPropName]===this){
if(this._arrayOfAllItems[_7ef[this._itemNumPropName]]===_7ef){
return true;
}
}
return false;
},isItemLoaded:function(_7f0){
return this.isItem(_7f0);
},loadItem:function(_7f1){
this._assertIsItem(_7f1.item);
},getFeatures:function(){
return this._features;
},getLabel:function(item){
if(this._labelAttr&&this.isItem(item)){
return this.getValue(item,this._labelAttr);
}
return undefined;
},getLabelAttributes:function(item){
if(this._labelAttr){
return [this._labelAttr];
}
return null;
},_fetchItems:function(_7f2,_7f3,_7f4){
var self=this,_7f5=function(_7f6,_7f7){
var _7f8=[],i,key;
if(_7f6.query){
var _7f9,_7fa=_7f6.queryOptions?_7f6.queryOptions.ignoreCase:false;
var _7fb={};
for(key in _7f6.query){
_7f9=_7f6.query[key];
if(typeof _7f9==="string"){
_7fb[key]=dojo.data.util.filter.patternToRegExp(_7f9,_7fa);
}else{
if(_7f9 instanceof RegExp){
_7fb[key]=_7f9;
}
}
}
for(i=0;i<_7f7.length;++i){
var _7fc=true;
var _7fd=_7f7[i];
if(_7fd===null){
_7fc=false;
}else{
for(key in _7f6.query){
_7f9=_7f6.query[key];
if(!self._containsValue(_7fd,key,_7f9,_7fb[key])){
_7fc=false;
}
}
}
if(_7fc){
_7f8.push(_7fd);
}
}
_7f3(_7f8,_7f6);
}else{
for(i=0;i<_7f7.length;++i){
var item=_7f7[i];
if(item!==null){
_7f8.push(item);
}
}
_7f3(_7f8,_7f6);
}
};
if(this._loadFinished){
_7f5(_7f2,this._getItemsArray(_7f2.queryOptions));
}else{
if(this._jsonFileUrl!==this._ccUrl){
dojo.deprecated("dojo.data.ItemFileReadStore: ","To change the url, set the url property of the store,"+" not _jsonFileUrl.  _jsonFileUrl support will be removed in 2.0");
this._ccUrl=this._jsonFileUrl;
this.url=this._jsonFileUrl;
}else{
if(this.url!==this._ccUrl){
this._jsonFileUrl=this.url;
this._ccUrl=this.url;
}
}
if(this.data!=null){
this._jsonData=this.data;
this.data=null;
}
if(this._jsonFileUrl){
if(this._loadInProgress){
this._queuedFetches.push({args:_7f2,filter:_7f5});
}else{
this._loadInProgress=true;
var _7fe={url:self._jsonFileUrl,handleAs:"json-comment-optional",preventCache:this.urlPreventCache,failOk:this.failOk};
var _7ff=dojo.xhrGet(_7fe);
_7ff.addCallback(function(data){
try{
self._getItemsFromLoadedData(data);
self._loadFinished=true;
self._loadInProgress=false;
_7f5(_7f2,self._getItemsArray(_7f2.queryOptions));
self._handleQueuedFetches();
}
catch(e){
self._loadFinished=true;
self._loadInProgress=false;
_7f4(e,_7f2);
}
});
_7ff.addErrback(function(_800){
self._loadInProgress=false;
_7f4(_800,_7f2);
});
var _801=null;
if(_7f2.abort){
_801=_7f2.abort;
}
_7f2.abort=function(){
var df=_7ff;
if(df&&df.fired===-1){
df.cancel();
df=null;
}
if(_801){
_801.call(_7f2);
}
};
}
}else{
if(this._jsonData){
try{
this._loadFinished=true;
this._getItemsFromLoadedData(this._jsonData);
this._jsonData=null;
_7f5(_7f2,this._getItemsArray(_7f2.queryOptions));
}
catch(e){
_7f4(e,_7f2);
}
}else{
_7f4(new Error("dojo.data.ItemFileReadStore: No JSON source data was provided as either URL or a nested Javascript object."),_7f2);
}
}
}
},_handleQueuedFetches:function(){
if(this._queuedFetches.length>0){
for(var i=0;i<this._queuedFetches.length;i++){
var _802=this._queuedFetches[i],_803=_802.args,_804=_802.filter;
if(_804){
_804(_803,this._getItemsArray(_803.queryOptions));
}else{
this.fetchItemByIdentity(_803);
}
}
this._queuedFetches=[];
}
},_getItemsArray:function(_805){
if(_805&&_805.deep){
return this._arrayOfAllItems;
}
return this._arrayOfTopLevelItems;
},close:function(_806){
if(this.clearOnClose&&this._loadFinished&&!this._loadInProgress){
if(((this._jsonFileUrl==""||this._jsonFileUrl==null)&&(this.url==""||this.url==null))&&this.data==null){
}
this._arrayOfAllItems=[];
this._arrayOfTopLevelItems=[];
this._loadFinished=false;
this._itemsByIdentity=null;
this._loadInProgress=false;
this._queuedFetches=[];
}
},_getItemsFromLoadedData:function(_807){
var _808=false,self=this;
function _809(_80a){
var _80b=((_80a!==null)&&(typeof _80a==="object")&&(!dojo.isArray(_80a)||_808)&&(!dojo.isFunction(_80a))&&(_80a.constructor==Object||dojo.isArray(_80a))&&(typeof _80a._reference==="undefined")&&(typeof _80a._type==="undefined")&&(typeof _80a._value==="undefined")&&self.hierarchical);
return _80b;
};
function _80c(_80d){
self._arrayOfAllItems.push(_80d);
for(var _80e in _80d){
var _80f=_80d[_80e];
if(_80f){
if(dojo.isArray(_80f)){
var _810=_80f;
for(var k=0;k<_810.length;++k){
var _811=_810[k];
if(_809(_811)){
_80c(_811);
}
}
}else{
if(_809(_80f)){
_80c(_80f);
}
}
}
}
};
this._labelAttr=_807.label;
var i,item;
this._arrayOfAllItems=[];
this._arrayOfTopLevelItems=_807.items;
for(i=0;i<this._arrayOfTopLevelItems.length;++i){
item=this._arrayOfTopLevelItems[i];
if(dojo.isArray(item)){
_808=true;
}
_80c(item);
item[this._rootItemPropName]=true;
}
var _812={},key;
for(i=0;i<this._arrayOfAllItems.length;++i){
item=this._arrayOfAllItems[i];
for(key in item){
if(key!==this._rootItemPropName){
var _813=item[key];
if(_813!==null){
if(!dojo.isArray(_813)){
item[key]=[_813];
}
}else{
item[key]=[null];
}
}
_812[key]=key;
}
}
while(_812[this._storeRefPropName]){
this._storeRefPropName+="_";
}
while(_812[this._itemNumPropName]){
this._itemNumPropName+="_";
}
while(_812[this._reverseRefMap]){
this._reverseRefMap+="_";
}
var _814;
var _815=_807.identifier;
if(_815){
this._itemsByIdentity={};
this._features["dojo.data.api.Identity"]=_815;
for(i=0;i<this._arrayOfAllItems.length;++i){
item=this._arrayOfAllItems[i];
_814=item[_815];
var _816=_814[0];
if(!Object.hasOwnProperty.call(this._itemsByIdentity,_816)){
this._itemsByIdentity[_816]=item;
}else{
if(this._jsonFileUrl){
throw new Error("dojo.data.ItemFileReadStore:  The json data as specified by: ["+this._jsonFileUrl+"] is malformed.  Items within the list have identifier: ["+_815+"].  Value collided: ["+_816+"]");
}else{
if(this._jsonData){
throw new Error("dojo.data.ItemFileReadStore:  The json data provided by the creation arguments is malformed.  Items within the list have identifier: ["+_815+"].  Value collided: ["+_816+"]");
}
}
}
}
}else{
this._features["dojo.data.api.Identity"]=Number;
}
for(i=0;i<this._arrayOfAllItems.length;++i){
item=this._arrayOfAllItems[i];
item[this._storeRefPropName]=this;
item[this._itemNumPropName]=i;
}
for(i=0;i<this._arrayOfAllItems.length;++i){
item=this._arrayOfAllItems[i];
for(key in item){
_814=item[key];
for(var j=0;j<_814.length;++j){
_813=_814[j];
if(_813!==null&&typeof _813=="object"){
if(("_type" in _813)&&("_value" in _813)){
var type=_813._type;
var _817=this._datatypeMap[type];
if(!_817){
throw new Error("dojo.data.ItemFileReadStore: in the typeMap constructor arg, no object class was specified for the datatype '"+type+"'");
}else{
if(dojo.isFunction(_817)){
_814[j]=new _817(_813._value);
}else{
if(dojo.isFunction(_817.deserialize)){
_814[j]=_817.deserialize(_813._value);
}else{
throw new Error("dojo.data.ItemFileReadStore: Value provided in typeMap was neither a constructor, nor a an object with a deserialize function");
}
}
}
}
if(_813._reference){
var _818=_813._reference;
if(!dojo.isObject(_818)){
_814[j]=this._getItemByIdentity(_818);
}else{
for(var k=0;k<this._arrayOfAllItems.length;++k){
var _819=this._arrayOfAllItems[k],_81a=true;
for(var _81b in _818){
if(_819[_81b]!=_818[_81b]){
_81a=false;
}
}
if(_81a){
_814[j]=_819;
}
}
}
if(this.referenceIntegrity){
var _81c=_814[j];
if(this.isItem(_81c)){
this._addReferenceToMap(_81c,item,key);
}
}
}else{
if(this.isItem(_813)){
if(this.referenceIntegrity){
this._addReferenceToMap(_813,item,key);
}
}
}
}
}
}
}
},_addReferenceToMap:function(_81d,_81e,_81f){
},getIdentity:function(item){
var _820=this._features["dojo.data.api.Identity"];
if(_820===Number){
return item[this._itemNumPropName];
}else{
var _821=item[_820];
if(_821){
return _821[0];
}
}
return null;
},fetchItemByIdentity:function(_822){
var item,_823;
if(!this._loadFinished){
var self=this;
if(this._jsonFileUrl!==this._ccUrl){
dojo.deprecated("dojo.data.ItemFileReadStore: ","To change the url, set the url property of the store,"+" not _jsonFileUrl.  _jsonFileUrl support will be removed in 2.0");
this._ccUrl=this._jsonFileUrl;
this.url=this._jsonFileUrl;
}else{
if(this.url!==this._ccUrl){
this._jsonFileUrl=this.url;
this._ccUrl=this.url;
}
}
if(this.data!=null&&this._jsonData==null){
this._jsonData=this.data;
this.data=null;
}
if(this._jsonFileUrl){
if(this._loadInProgress){
this._queuedFetches.push({args:_822});
}else{
this._loadInProgress=true;
var _824={url:self._jsonFileUrl,handleAs:"json-comment-optional",preventCache:this.urlPreventCache,failOk:this.failOk};
var _825=dojo.xhrGet(_824);
_825.addCallback(function(data){
var _826=_822.scope?_822.scope:dojo.global;
try{
self._getItemsFromLoadedData(data);
self._loadFinished=true;
self._loadInProgress=false;
item=self._getItemByIdentity(_822.identity);
if(_822.onItem){
_822.onItem.call(_826,item);
}
self._handleQueuedFetches();
}
catch(error){
self._loadInProgress=false;
if(_822.onError){
_822.onError.call(_826,error);
}
}
});
_825.addErrback(function(_827){
self._loadInProgress=false;
if(_822.onError){
var _828=_822.scope?_822.scope:dojo.global;
_822.onError.call(_828,_827);
}
});
}
}else{
if(this._jsonData){
self._getItemsFromLoadedData(self._jsonData);
self._jsonData=null;
self._loadFinished=true;
item=self._getItemByIdentity(_822.identity);
if(_822.onItem){
_823=_822.scope?_822.scope:dojo.global;
_822.onItem.call(_823,item);
}
}
}
}else{
item=this._getItemByIdentity(_822.identity);
if(_822.onItem){
_823=_822.scope?_822.scope:dojo.global;
_822.onItem.call(_823,item);
}
}
},_getItemByIdentity:function(_829){
var item=null;
if(this._itemsByIdentity&&Object.hasOwnProperty.call(this._itemsByIdentity,_829)){
item=this._itemsByIdentity[_829];
}else{
if(Object.hasOwnProperty.call(this._arrayOfAllItems,_829)){
item=this._arrayOfAllItems[_829];
}
}
if(item===undefined){
item=null;
}
return item;
},getIdentityAttributes:function(item){
var _82a=this._features["dojo.data.api.Identity"];
if(_82a===Number){
return null;
}else{
return [_82a];
}
},_forceLoad:function(){
var self=this;
if(this._jsonFileUrl!==this._ccUrl){
dojo.deprecated("dojo.data.ItemFileReadStore: ","To change the url, set the url property of the store,"+" not _jsonFileUrl.  _jsonFileUrl support will be removed in 2.0");
this._ccUrl=this._jsonFileUrl;
this.url=this._jsonFileUrl;
}else{
if(this.url!==this._ccUrl){
this._jsonFileUrl=this.url;
this._ccUrl=this.url;
}
}
if(this.data!=null){
this._jsonData=this.data;
this.data=null;
}
if(this._jsonFileUrl){
var _82b={url:this._jsonFileUrl,handleAs:"json-comment-optional",preventCache:this.urlPreventCache,failOk:this.failOk,sync:true};
var _82c=dojo.xhrGet(_82b);
_82c.addCallback(function(data){
try{
if(self._loadInProgress!==true&&!self._loadFinished){
self._getItemsFromLoadedData(data);
self._loadFinished=true;
}else{
if(self._loadInProgress){
throw new Error("dojo.data.ItemFileReadStore:  Unable to perform a synchronous load, an async load is in progress.");
}
}
}
catch(e){
throw e;
}
});
_82c.addErrback(function(_82d){
throw _82d;
});
}else{
if(this._jsonData){
self._getItemsFromLoadedData(self._jsonData);
self._jsonData=null;
self._loadFinished=true;
}
}
}});
dojo.extend(dojo.data.ItemFileReadStore,dojo.data.util.simpleFetch);
}
if(!dojo._hasResource["dojo.data.ItemFileWriteStore"]){
dojo._hasResource["dojo.data.ItemFileWriteStore"]=true;
dojo.provide("dojo.data.ItemFileWriteStore");
dojo.declare("dojo.data.ItemFileWriteStore",dojo.data.ItemFileReadStore,{constructor:function(_82e){
this._features["dojo.data.api.Write"]=true;
this._features["dojo.data.api.Notification"]=true;
this._pending={_newItems:{},_modifiedItems:{},_deletedItems:{}};
if(!this._datatypeMap["Date"].serialize){
this._datatypeMap["Date"].serialize=function(obj){
return dojo.date.stamp.toISOString(obj,{zulu:true});
};
}
if(_82e&&(_82e.referenceIntegrity===false)){
this.referenceIntegrity=false;
}
this._saveInProgress=false;
},referenceIntegrity:true,_assert:function(_82f){
if(!_82f){
throw new Error("assertion failed in ItemFileWriteStore");
}
},_getIdentifierAttribute:function(){
var _830=this.getFeatures()["dojo.data.api.Identity"];
return _830;
},newItem:function(_831,_832){
this._assert(!this._saveInProgress);
if(!this._loadFinished){
this._forceLoad();
}
if(typeof _831!="object"&&typeof _831!="undefined"){
throw new Error("newItem() was passed something other than an object");
}
var _833=null;
var _834=this._getIdentifierAttribute();
if(_834===Number){
_833=this._arrayOfAllItems.length;
}else{
_833=_831[_834];
if(typeof _833==="undefined"){
throw new Error("newItem() was not passed an identity for the new item");
}
if(dojo.isArray(_833)){
throw new Error("newItem() was not passed an single-valued identity");
}
}
if(this._itemsByIdentity){
this._assert(typeof this._itemsByIdentity[_833]==="undefined");
}
this._assert(typeof this._pending._newItems[_833]==="undefined");
this._assert(typeof this._pending._deletedItems[_833]==="undefined");
var _835={};
_835[this._storeRefPropName]=this;
_835[this._itemNumPropName]=this._arrayOfAllItems.length;
if(this._itemsByIdentity){
this._itemsByIdentity[_833]=_835;
_835[_834]=[_833];
}
this._arrayOfAllItems.push(_835);
var _836=null;
if(_832&&_832.parent&&_832.attribute){
_836={item:_832.parent,attribute:_832.attribute,oldValue:undefined};
var _837=this.getValues(_832.parent,_832.attribute);
if(_837&&_837.length>0){
var _838=_837.slice(0,_837.length);
if(_837.length===1){
_836.oldValue=_837[0];
}else{
_836.oldValue=_837.slice(0,_837.length);
}
_838.push(_835);
this._setValueOrValues(_832.parent,_832.attribute,_838,false);
_836.newValue=this.getValues(_832.parent,_832.attribute);
}else{
this._setValueOrValues(_832.parent,_832.attribute,_835,false);
_836.newValue=_835;
}
}else{
_835[this._rootItemPropName]=true;
this._arrayOfTopLevelItems.push(_835);
}
this._pending._newItems[_833]=_835;
for(var key in _831){
if(key===this._storeRefPropName||key===this._itemNumPropName){
throw new Error("encountered bug in ItemFileWriteStore.newItem");
}
var _839=_831[key];
if(!dojo.isArray(_839)){
_839=[_839];
}
_835[key]=_839;
if(this.referenceIntegrity){
for(var i=0;i<_839.length;i++){
var val=_839[i];
if(this.isItem(val)){
this._addReferenceToMap(val,_835,key);
}
}
}
}
this.onNew(_835,_836);
return _835;
},_removeArrayElement:function(_83a,_83b){
var _83c=dojo.indexOf(_83a,_83b);
if(_83c!=-1){
_83a.splice(_83c,1);
return true;
}
return false;
},deleteItem:function(item){
this._assert(!this._saveInProgress);
this._assertIsItem(item);
var _83d=item[this._itemNumPropName];
var _83e=this.getIdentity(item);
if(this.referenceIntegrity){
var _83f=this.getAttributes(item);
if(item[this._reverseRefMap]){
item["backup_"+this._reverseRefMap]=dojo.clone(item[this._reverseRefMap]);
}
dojo.forEach(_83f,function(_840){
dojo.forEach(this.getValues(item,_840),function(_841){
if(this.isItem(_841)){
if(!item["backupRefs_"+this._reverseRefMap]){
item["backupRefs_"+this._reverseRefMap]=[];
}
item["backupRefs_"+this._reverseRefMap].push({id:this.getIdentity(_841),attr:_840});
this._removeReferenceFromMap(_841,item,_840);
}
},this);
},this);
var _842=item[this._reverseRefMap];
if(_842){
for(var _843 in _842){
var _844=null;
if(this._itemsByIdentity){
_844=this._itemsByIdentity[_843];
}else{
_844=this._arrayOfAllItems[_843];
}
if(_844){
for(var _845 in _842[_843]){
var _846=this.getValues(_844,_845)||[];
var _847=dojo.filter(_846,function(_848){
return !(this.isItem(_848)&&this.getIdentity(_848)==_83e);
},this);
this._removeReferenceFromMap(item,_844,_845);
if(_847.length<_846.length){
this._setValueOrValues(_844,_845,_847,true);
}
}
}
}
}
}
this._arrayOfAllItems[_83d]=null;
item[this._storeRefPropName]=null;
if(this._itemsByIdentity){
delete this._itemsByIdentity[_83e];
}
this._pending._deletedItems[_83e]=item;
if(item[this._rootItemPropName]){
this._removeArrayElement(this._arrayOfTopLevelItems,item);
}
this.onDelete(item);
return true;
},setValue:function(item,_849,_84a){
return this._setValueOrValues(item,_849,_84a,true);
},setValues:function(item,_84b,_84c){
return this._setValueOrValues(item,_84b,_84c,true);
},unsetAttribute:function(item,_84d){
return this._setValueOrValues(item,_84d,[],true);
},_setValueOrValues:function(item,_84e,_84f,_850){
this._assert(!this._saveInProgress);
this._assertIsItem(item);
this._assert(dojo.isString(_84e));
this._assert(typeof _84f!=="undefined");
var _851=this._getIdentifierAttribute();
if(_84e==_851){
throw new Error("ItemFileWriteStore does not have support for changing the value of an item's identifier.");
}
var _852=this._getValueOrValues(item,_84e);
var _853=this.getIdentity(item);
if(!this._pending._modifiedItems[_853]){
var _854={};
for(var key in item){
if((key===this._storeRefPropName)||(key===this._itemNumPropName)||(key===this._rootItemPropName)){
_854[key]=item[key];
}else{
if(key===this._reverseRefMap){
_854[key]=dojo.clone(item[key]);
}else{
_854[key]=item[key].slice(0,item[key].length);
}
}
}
this._pending._modifiedItems[_853]=_854;
}
var _855=false;
if(dojo.isArray(_84f)&&_84f.length===0){
_855=delete item[_84e];
_84f=undefined;
if(this.referenceIntegrity&&_852){
var _856=_852;
if(!dojo.isArray(_856)){
_856=[_856];
}
for(var i=0;i<_856.length;i++){
var _857=_856[i];
if(this.isItem(_857)){
this._removeReferenceFromMap(_857,item,_84e);
}
}
}
}else{
var _858;
if(dojo.isArray(_84f)){
var _859=_84f;
_858=_84f.slice(0,_84f.length);
}else{
_858=[_84f];
}
if(this.referenceIntegrity){
if(_852){
var _856=_852;
if(!dojo.isArray(_856)){
_856=[_856];
}
var map={};
dojo.forEach(_856,function(_85a){
if(this.isItem(_85a)){
var id=this.getIdentity(_85a);
map[id.toString()]=true;
}
},this);
dojo.forEach(_858,function(_85b){
if(this.isItem(_85b)){
var id=this.getIdentity(_85b);
if(map[id.toString()]){
delete map[id.toString()];
}else{
this._addReferenceToMap(_85b,item,_84e);
}
}
},this);
for(var rId in map){
var _85c;
if(this._itemsByIdentity){
_85c=this._itemsByIdentity[rId];
}else{
_85c=this._arrayOfAllItems[rId];
}
this._removeReferenceFromMap(_85c,item,_84e);
}
}else{
for(var i=0;i<_858.length;i++){
var _857=_858[i];
if(this.isItem(_857)){
this._addReferenceToMap(_857,item,_84e);
}
}
}
}
item[_84e]=_858;
_855=true;
}
if(_850){
this.onSet(item,_84e,_852,_84f);
}
return _855;
},_addReferenceToMap:function(_85d,_85e,_85f){
var _860=this.getIdentity(_85e);
var _861=_85d[this._reverseRefMap];
if(!_861){
_861=_85d[this._reverseRefMap]={};
}
var _862=_861[_860];
if(!_862){
_862=_861[_860]={};
}
_862[_85f]=true;
},_removeReferenceFromMap:function(_863,_864,_865){
var _866=this.getIdentity(_864);
var _867=_863[this._reverseRefMap];
var _868;
if(_867){
for(_868 in _867){
if(_868==_866){
delete _867[_868][_865];
if(this._isEmpty(_867[_868])){
delete _867[_868];
}
}
}
if(this._isEmpty(_867)){
delete _863[this._reverseRefMap];
}
}
},_dumpReferenceMap:function(){
var i;
for(i=0;i<this._arrayOfAllItems.length;i++){
var item=this._arrayOfAllItems[i];
if(item&&item[this._reverseRefMap]){
}
}
},_getValueOrValues:function(item,_869){
var _86a=undefined;
if(this.hasAttribute(item,_869)){
var _86b=this.getValues(item,_869);
if(_86b.length==1){
_86a=_86b[0];
}else{
_86a=_86b;
}
}
return _86a;
},_flatten:function(_86c){
if(this.isItem(_86c)){
var item=_86c;
var _86d=this.getIdentity(item);
var _86e={_reference:_86d};
return _86e;
}else{
if(typeof _86c==="object"){
for(var type in this._datatypeMap){
var _86f=this._datatypeMap[type];
if(dojo.isObject(_86f)&&!dojo.isFunction(_86f)){
if(_86c instanceof _86f.type){
if(!_86f.serialize){
throw new Error("ItemFileWriteStore:  No serializer defined for type mapping: ["+type+"]");
}
return {_type:type,_value:_86f.serialize(_86c)};
}
}else{
if(_86c instanceof _86f){
return {_type:type,_value:_86c.toString()};
}
}
}
}
return _86c;
}
},_getNewFileContentString:function(){
var _870={};
var _871=this._getIdentifierAttribute();
if(_871!==Number){
_870.identifier=_871;
}
if(this._labelAttr){
_870.label=this._labelAttr;
}
_870.items=[];
for(var i=0;i<this._arrayOfAllItems.length;++i){
var item=this._arrayOfAllItems[i];
if(item!==null){
var _872={};
for(var key in item){
if(key!==this._storeRefPropName&&key!==this._itemNumPropName&&key!==this._reverseRefMap&&key!==this._rootItemPropName){
var _873=key;
var _874=this.getValues(item,_873);
if(_874.length==1){
_872[_873]=this._flatten(_874[0]);
}else{
var _875=[];
for(var j=0;j<_874.length;++j){
_875.push(this._flatten(_874[j]));
_872[_873]=_875;
}
}
}
}
_870.items.push(_872);
}
}
var _876=true;
return dojo.toJson(_870,_876);
},_isEmpty:function(_877){
var _878=true;
if(dojo.isObject(_877)){
var i;
for(i in _877){
_878=false;
break;
}
}else{
if(dojo.isArray(_877)){
if(_877.length>0){
_878=false;
}
}
}
return _878;
},save:function(_879){
this._assert(!this._saveInProgress);
this._saveInProgress=true;
var self=this;
var _87a=function(){
self._pending={_newItems:{},_modifiedItems:{},_deletedItems:{}};
self._saveInProgress=false;
if(_879&&_879.onComplete){
var _87b=_879.scope||dojo.global;
_879.onComplete.call(_87b);
}
};
var _87c=function(err){
self._saveInProgress=false;
if(_879&&_879.onError){
var _87d=_879.scope||dojo.global;
_879.onError.call(_87d,err);
}
};
if(this._saveEverything){
var _87e=this._getNewFileContentString();
this._saveEverything(_87a,_87c,_87e);
}
if(this._saveCustom){
this._saveCustom(_87a,_87c);
}
if(!this._saveEverything&&!this._saveCustom){
_87a();
}
},revert:function(){
this._assert(!this._saveInProgress);
var _87f;
for(_87f in this._pending._modifiedItems){
var _880=this._pending._modifiedItems[_87f];
var _881=null;
if(this._itemsByIdentity){
_881=this._itemsByIdentity[_87f];
}else{
_881=this._arrayOfAllItems[_87f];
}
_880[this._storeRefPropName]=this;
for(key in _881){
delete _881[key];
}
dojo.mixin(_881,_880);
}
var _882;
for(_87f in this._pending._deletedItems){
_882=this._pending._deletedItems[_87f];
_882[this._storeRefPropName]=this;
var _883=_882[this._itemNumPropName];
if(_882["backup_"+this._reverseRefMap]){
_882[this._reverseRefMap]=_882["backup_"+this._reverseRefMap];
delete _882["backup_"+this._reverseRefMap];
}
this._arrayOfAllItems[_883]=_882;
if(this._itemsByIdentity){
this._itemsByIdentity[_87f]=_882;
}
if(_882[this._rootItemPropName]){
this._arrayOfTopLevelItems.push(_882);
}
}
for(_87f in this._pending._deletedItems){
_882=this._pending._deletedItems[_87f];
if(_882["backupRefs_"+this._reverseRefMap]){
dojo.forEach(_882["backupRefs_"+this._reverseRefMap],function(_884){
var _885;
if(this._itemsByIdentity){
_885=this._itemsByIdentity[_884.id];
}else{
_885=this._arrayOfAllItems[_884.id];
}
this._addReferenceToMap(_885,_882,_884.attr);
},this);
delete _882["backupRefs_"+this._reverseRefMap];
}
}
for(_87f in this._pending._newItems){
var _886=this._pending._newItems[_87f];
_886[this._storeRefPropName]=null;
this._arrayOfAllItems[_886[this._itemNumPropName]]=null;
if(_886[this._rootItemPropName]){
this._removeArrayElement(this._arrayOfTopLevelItems,_886);
}
if(this._itemsByIdentity){
delete this._itemsByIdentity[_87f];
}
}
this._pending={_newItems:{},_modifiedItems:{},_deletedItems:{}};
return true;
},isDirty:function(item){
if(item){
var _887=this.getIdentity(item);
return new Boolean(this._pending._newItems[_887]||this._pending._modifiedItems[_887]||this._pending._deletedItems[_887]).valueOf();
}else{
if(!this._isEmpty(this._pending._newItems)||!this._isEmpty(this._pending._modifiedItems)||!this._isEmpty(this._pending._deletedItems)){
return true;
}
return false;
}
},onSet:function(item,_888,_889,_88a){
},onNew:function(_88b,_88c){
},onDelete:function(_88d){
},close:function(_88e){
if(this.clearOnClose){
if(!this.isDirty()){
this.inherited(arguments);
}else{
throw new Error("dojo.data.ItemFileWriteStore: There are unsaved changes present in the store.  Please save or revert the changes before invoking close.");
}
}
}});
}
if(!dojo._hasResource["dijit.form.TextBox"]){
dojo._hasResource["dijit.form.TextBox"]=true;
dojo.provide("dijit.form.TextBox");
dojo.declare("dijit.form.TextBox",dijit.form._FormValueWidget,{trim:false,uppercase:false,lowercase:false,propercase:false,maxLength:"",selectOnClick:false,placeHolder:"",templateString:dojo.cache("dijit.form","templates/TextBox.html","<div class=\"dijit dijitReset dijitInline dijitLeft\" id=\"widget_${id}\" role=\"presentation\"\r\n\t><div class=\"dijitReset dijitInputField dijitInputContainer\"\r\n\t\t><input class=\"dijitReset dijitInputInner\" dojoAttachPoint='textbox,focusNode' autocomplete=\"off\"\r\n\t\t\t${!nameAttrSetting} type='${type}'\r\n\t/></div\r\n></div>\r\n"),_singleNodeTemplate:"<input class=\"dijit dijitReset dijitLeft dijitInputField\" dojoAttachPoint=\"textbox,focusNode\" autocomplete=\"off\" type=\"${type}\" ${!nameAttrSetting} />",_buttonInputDisabled:dojo.isIE?"disabled":"",baseClass:"dijitTextBox",attributeMap:dojo.delegate(dijit.form._FormValueWidget.prototype.attributeMap,{maxLength:"focusNode"}),postMixInProperties:function(){
var type=this.type.toLowerCase();
if(this.templateString&&this.templateString.toLowerCase()=="input"||((type=="hidden"||type=="file")&&this.templateString==dijit.form.TextBox.prototype.templateString)){
this.templateString=this._singleNodeTemplate;
}
this.inherited(arguments);
},_setPlaceHolderAttr:function(v){
this._set("placeHolder",v);
if(!this._phspan){
this._attachPoints.push("_phspan");
this._phspan=dojo.create("span",{className:"dijitPlaceHolder dijitInputField"},this.textbox,"after");
}
this._phspan.innerHTML="";
this._phspan.appendChild(document.createTextNode(v));
this._updatePlaceHolder();
},_updatePlaceHolder:function(){
if(this._phspan){
this._phspan.style.display=(this.placeHolder&&!this._focused&&!this.textbox.value)?"":"none";
}
},_getValueAttr:function(){
return this.parse(this.get("displayedValue"),this.constraints);
},_setValueAttr:function(_88f,_890,_891){
var _892;
if(_88f!==undefined){
_892=this.filter(_88f);
if(typeof _891!="string"){
if(_892!==null&&((typeof _892!="number")||!isNaN(_892))){
_891=this.filter(this.format(_892,this.constraints));
}else{
_891="";
}
}
}
if(_891!=null&&_891!=undefined&&((typeof _891)!="number"||!isNaN(_891))&&this.textbox.value!=_891){
this.textbox.value=_891;
this._set("displayedValue",this.get("displayedValue"));
}
this._updatePlaceHolder();
this.inherited(arguments,[_892,_890]);
},displayedValue:"",getDisplayedValue:function(){
dojo.deprecated(this.declaredClass+"::getDisplayedValue() is deprecated. Use set('displayedValue') instead.","","2.0");
return this.get("displayedValue");
},_getDisplayedValueAttr:function(){
return this.filter(this.textbox.value);
},setDisplayedValue:function(_893){
dojo.deprecated(this.declaredClass+"::setDisplayedValue() is deprecated. Use set('displayedValue', ...) instead.","","2.0");
this.set("displayedValue",_893);
},_setDisplayedValueAttr:function(_894){
if(_894===null||_894===undefined){
_894="";
}else{
if(typeof _894!="string"){
_894=String(_894);
}
}
this.textbox.value=_894;
this._setValueAttr(this.get("value"),undefined);
this._set("displayedValue",this.get("displayedValue"));
},format:function(_895,_896){
return ((_895==null||_895==undefined)?"":(_895.toString?_895.toString():_895));
},parse:function(_897,_898){
return _897;
},_refreshState:function(){
},_onInput:function(e){
if(e&&e.type&&/key/i.test(e.type)&&e.keyCode){
switch(e.keyCode){
case dojo.keys.SHIFT:
case dojo.keys.ALT:
case dojo.keys.CTRL:
case dojo.keys.TAB:
return;
}
}
if(this.intermediateChanges){
var _899=this;
setTimeout(function(){
_899._handleOnChange(_899.get("value"),false);
},0);
}
this._refreshState();
this._set("displayedValue",this.get("displayedValue"));
},postCreate:function(){
if(dojo.isIE){
setTimeout(dojo.hitch(this,function(){
var s=dojo.getComputedStyle(this.domNode);
if(s){
var ff=s.fontFamily;
if(ff){
var _89a=this.domNode.getElementsByTagName("INPUT");
if(_89a){
for(var i=0;i<_89a.length;i++){
_89a[i].style.fontFamily=ff;
}
}
}
}
}),0);
}
this.textbox.setAttribute("value",this.textbox.value);
this.inherited(arguments);
if(dojo.isMoz||dojo.isOpera){
this.connect(this.textbox,"oninput","_onInput");
}else{
this.connect(this.textbox,"onkeydown","_onInput");
this.connect(this.textbox,"onkeyup","_onInput");
this.connect(this.textbox,"onpaste","_onInput");
this.connect(this.textbox,"oncut","_onInput");
}
},_blankValue:"",filter:function(val){
if(val===null){
return this._blankValue;
}
if(typeof val!="string"){
return val;
}
if(this.trim){
val=dojo.trim(val);
}
if(this.uppercase){
val=val.toUpperCase();
}
if(this.lowercase){
val=val.toLowerCase();
}
if(this.propercase){
val=val.replace(/[^\s]+/g,function(word){
return word.substring(0,1).toUpperCase()+word.substring(1);
});
}
return val;
},_setBlurValue:function(){
this._setValueAttr(this.get("value"),true);
},_onBlur:function(e){
if(this.disabled){
return;
}
this._setBlurValue();
this.inherited(arguments);
if(this._selectOnClickHandle){
this.disconnect(this._selectOnClickHandle);
}
if(this.selectOnClick&&dojo.isMoz){
this.textbox.selectionStart=this.textbox.selectionEnd=undefined;
}
this._updatePlaceHolder();
},_onFocus:function(by){
if(this.disabled||this.readOnly){
return;
}
if(this.selectOnClick&&by=="mouse"){
this._selectOnClickHandle=this.connect(this.domNode,"onmouseup",function(){
this.disconnect(this._selectOnClickHandle);
var _89b;
if(dojo.isIE){
var _89c=dojo.doc.selection.createRange();
var _89d=_89c.parentElement();
_89b=_89d==this.textbox&&_89c.text.length==0;
}else{
_89b=this.textbox.selectionStart==this.textbox.selectionEnd;
}
if(_89b){
dijit.selectInputText(this.textbox);
}
});
}
this._updatePlaceHolder();
this.inherited(arguments);
this._refreshState();
},reset:function(){
this.textbox.value="";
this.inherited(arguments);
}});
dijit.selectInputText=function(_89e,_89f,stop){
var _8a0=dojo.global;
var _8a1=dojo.doc;
_89e=dojo.byId(_89e);
if(isNaN(_89f)){
_89f=0;
}
if(isNaN(stop)){
stop=_89e.value?_89e.value.length:0;
}
dijit.focus(_89e);
if(_8a1["selection"]&&dojo.body()["createTextRange"]){
if(_89e.createTextRange){
var r=_89e.createTextRange();
r.collapse(true);
r.moveStart("character",-99999);
r.moveStart("character",_89f);
r.moveEnd("character",stop-_89f);
r.select();
}
}else{
if(_8a0["getSelection"]){
if(_89e.setSelectionRange){
_89e.setSelectionRange(_89f,stop);
}
}
}
};
}
if(!dojo._hasResource["dijit.form.ValidationTextBox"]){
dojo._hasResource["dijit.form.ValidationTextBox"]=true;
dojo.provide("dijit.form.ValidationTextBox");
dojo.declare("dijit.form.ValidationTextBox",dijit.form.TextBox,{templateString:dojo.cache("dijit.form","templates/ValidationTextBox.html","<div class=\"dijit dijitReset dijitInlineTable dijitLeft\"\r\n\tid=\"widget_${id}\" role=\"presentation\"\r\n\t><div class='dijitReset dijitValidationContainer'\r\n\t\t><input class=\"dijitReset dijitInputField dijitValidationIcon dijitValidationInner\" value=\"&#935; \" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t/></div\r\n\t><div class=\"dijitReset dijitInputField dijitInputContainer\"\r\n\t\t><input class=\"dijitReset dijitInputInner\" dojoAttachPoint='textbox,focusNode' autocomplete=\"off\"\r\n\t\t\t${!nameAttrSetting} type='${type}'\r\n\t/></div\r\n></div>\r\n"),baseClass:"dijitTextBox dijitValidationTextBox",required:false,promptMessage:"",invalidMessage:"$_unset_$",missingMessage:"$_unset_$",message:"",constraints:{},regExp:".*",regExpGen:function(_8a2){
return this.regExp;
},state:"",tooltipPosition:[],_setValueAttr:function(){
this.inherited(arguments);
this.validate(this._focused);
},validator:function(_8a3,_8a4){
return (new RegExp("^(?:"+this.regExpGen(_8a4)+")"+(this.required?"":"?")+"$")).test(_8a3)&&(!this.required||!this._isEmpty(_8a3))&&(this._isEmpty(_8a3)||this.parse(_8a3,_8a4)!==undefined);
},_isValidSubset:function(){
return this.textbox.value.search(this._partialre)==0;
},isValid:function(_8a5){
return this.validator(this.textbox.value,this.constraints);
},_isEmpty:function(_8a6){
return (this.trim?/^\s*$/:/^$/).test(_8a6);
},getErrorMessage:function(_8a7){
return (this.required&&this._isEmpty(this.textbox.value))?this.missingMessage:this.invalidMessage;
},getPromptMessage:function(_8a8){
return this.promptMessage;
},_maskValidSubsetError:true,validate:function(_8a9){
var _8aa="";
var _8ab=this.disabled||this.isValid(_8a9);
if(_8ab){
this._maskValidSubsetError=true;
}
var _8ac=this._isEmpty(this.textbox.value);
var _8ad=!_8ab&&_8a9&&this._isValidSubset();
this._set("state",_8ab?"":(((((!this._hasBeenBlurred||_8a9)&&_8ac)||_8ad)&&this._maskValidSubsetError)?"Incomplete":"Error"));
dijit.setWaiState(this.focusNode,"invalid",_8ab?"false":"true");
if(this.state=="Error"){
this._maskValidSubsetError=_8a9&&_8ad;
_8aa=this.getErrorMessage(_8a9);
}else{
if(this.state=="Incomplete"){
_8aa=this.getPromptMessage(_8a9);
this._maskValidSubsetError=!this._hasBeenBlurred||_8a9;
}else{
if(_8ac){
_8aa=this.getPromptMessage(_8a9);
}
}
}
this.set("message",_8aa);
return _8ab;
},displayMessage:function(_8ae){
dijit.hideTooltip(this.domNode);
if(_8ae&&this._focused){
dijit.showTooltip(_8ae,this.domNode,this.tooltipPosition,!this.isLeftToRight());
}
},_refreshState:function(){
this.validate(this._focused);
this.inherited(arguments);
},constructor:function(){
this.constraints={};
},_setConstraintsAttr:function(_8af){
if(!_8af.locale&&this.lang){
_8af.locale=this.lang;
}
this._set("constraints",_8af);
this._computePartialRE();
},_computePartialRE:function(){
var p=this.regExpGen(this.constraints);
this.regExp=p;
var _8b0="";
if(p!=".*"){
this.regExp.replace(/\\.|\[\]|\[.*?[^\\]{1}\]|\{.*?\}|\(\?[=:!]|./g,function(re){
switch(re.charAt(0)){
case "{":
case "+":
case "?":
case "*":
case "^":
case "$":
case "|":
case "(":
_8b0+=re;
break;
case ")":
_8b0+="|$)";
break;
default:
_8b0+="(?:"+re+"|$)";
break;
}
});
}
try{
"".search(_8b0);
}
catch(e){
_8b0=this.regExp;
console.warn("RegExp error in "+this.declaredClass+": "+this.regExp);
}
this._partialre="^(?:"+_8b0+")$";
},postMixInProperties:function(){
this.inherited(arguments);
this.messages=dojo.i18n.getLocalization("dijit.form","validate",this.lang);
if(this.invalidMessage=="$_unset_$"){
this.invalidMessage=this.messages.invalidMessage;
}
if(!this.invalidMessage){
this.invalidMessage=this.promptMessage;
}
if(this.missingMessage=="$_unset_$"){
this.missingMessage=this.messages.missingMessage;
}
if(!this.missingMessage){
this.missingMessage=this.invalidMessage;
}
this._setConstraintsAttr(this.constraints);
},_setDisabledAttr:function(_8b1){
this.inherited(arguments);
this._refreshState();
},_setRequiredAttr:function(_8b2){
this._set("required",_8b2);
dijit.setWaiState(this.focusNode,"required",_8b2);
this._refreshState();
},_setMessageAttr:function(_8b3){
this._set("message",_8b3);
this.displayMessage(_8b3);
},reset:function(){
this._maskValidSubsetError=true;
this.inherited(arguments);
},_onBlur:function(){
this.displayMessage("");
this.inherited(arguments);
}});
dojo.declare("dijit.form.MappedTextBox",dijit.form.ValidationTextBox,{postMixInProperties:function(){
this.inherited(arguments);
this.nameAttrSetting="";
},serialize:function(val,_8b4){
return val.toString?val.toString():"";
},toString:function(){
var val=this.filter(this.get("value"));
return val!=null?(typeof val=="string"?val:this.serialize(val,this.constraints)):"";
},validate:function(){
this.valueNode.value=this.toString();
return this.inherited(arguments);
},buildRendering:function(){
this.inherited(arguments);
this.valueNode=dojo.place("<input type='hidden'"+(this.name?" name='"+this.name.replace(/'/g,"&quot;")+"'":"")+"/>",this.textbox,"after");
},reset:function(){
this.valueNode.value="";
this.inherited(arguments);
}});
dojo.declare("dijit.form.RangeBoundTextBox",dijit.form.MappedTextBox,{rangeMessage:"",rangeCheck:function(_8b5,_8b6){
return ("min" in _8b6?(this.compare(_8b5,_8b6.min)>=0):true)&&("max" in _8b6?(this.compare(_8b5,_8b6.max)<=0):true);
},isInRange:function(_8b7){
return this.rangeCheck(this.get("value"),this.constraints);
},_isDefinitelyOutOfRange:function(){
var val=this.get("value");
var _8b8=false;
var _8b9=false;
if("min" in this.constraints){
var min=this.constraints.min;
min=this.compare(val,((typeof min=="number")&&min>=0&&val!=0)?0:min);
_8b8=(typeof min=="number")&&min<0;
}
if("max" in this.constraints){
var max=this.constraints.max;
max=this.compare(val,((typeof max!="number")||max>0)?max:0);
_8b9=(typeof max=="number")&&max>0;
}
return _8b8||_8b9;
},_isValidSubset:function(){
return this.inherited(arguments)&&!this._isDefinitelyOutOfRange();
},isValid:function(_8ba){
return this.inherited(arguments)&&((this._isEmpty(this.textbox.value)&&!this.required)||this.isInRange(_8ba));
},getErrorMessage:function(_8bb){
var v=this.get("value");
if(v!==null&&v!==""&&v!==undefined&&(typeof v!="number"||!isNaN(v))&&!this.isInRange(_8bb)){
return this.rangeMessage;
}
return this.inherited(arguments);
},postMixInProperties:function(){
this.inherited(arguments);
if(!this.rangeMessage){
this.messages=dojo.i18n.getLocalization("dijit.form","validate",this.lang);
this.rangeMessage=this.messages.rangeMessage;
}
},_setConstraintsAttr:function(_8bc){
this.inherited(arguments);
if(this.focusNode){
if(this.constraints.min!==undefined){
dijit.setWaiState(this.focusNode,"valuemin",this.constraints.min);
}else{
dijit.removeWaiState(this.focusNode,"valuemin");
}
if(this.constraints.max!==undefined){
dijit.setWaiState(this.focusNode,"valuemax",this.constraints.max);
}else{
dijit.removeWaiState(this.focusNode,"valuemax");
}
}
},_setValueAttr:function(_8bd,_8be){
dijit.setWaiState(this.focusNode,"valuenow",_8bd);
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.form.ComboBox"]){
dojo._hasResource["dijit.form.ComboBox"]=true;
dojo.provide("dijit.form.ComboBox");
dojo.declare("dijit.form.ComboBoxMixin",dijit._HasDropDown,{item:null,pageSize:Infinity,store:null,fetchProperties:{},query:{},autoComplete:true,highlightMatch:"first",searchDelay:100,searchAttr:"name",labelAttr:"",labelType:"text",queryExpr:"${0}*",ignoreCase:true,hasDownArrow:true,templateString:dojo.cache("dijit.form","templates/DropDownBox.html","<div class=\"dijit dijitReset dijitInlineTable dijitLeft\"\r\n\tid=\"widget_${id}\"\r\n\trole=\"combobox\"\r\n\t><div class='dijitReset dijitRight dijitButtonNode dijitArrowButton dijitDownArrowButton dijitArrowButtonContainer'\r\n\t\tdojoAttachPoint=\"_buttonNode, _popupStateNode\" role=\"presentation\"\r\n\t\t><input class=\"dijitReset dijitInputField dijitArrowButtonInner\" value=\"&#9660; \" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t\t\t${_buttonInputDisabled}\r\n\t/></div\r\n\t><div class='dijitReset dijitValidationContainer'\r\n\t\t><input class=\"dijitReset dijitInputField dijitValidationIcon dijitValidationInner\" value=\"&#935; \" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t/></div\r\n\t><div class=\"dijitReset dijitInputField dijitInputContainer\"\r\n\t\t><input class='dijitReset dijitInputInner' ${!nameAttrSetting} type=\"text\" autocomplete=\"off\"\r\n\t\t\tdojoAttachPoint=\"textbox,focusNode\" role=\"textbox\" aria-haspopup=\"true\"\r\n\t/></div\r\n></div>\r\n"),baseClass:"dijitTextBox dijitComboBox",dropDownClass:"dijit.form._ComboBoxMenu",cssStateNodes:{"_buttonNode":"dijitDownArrowButton"},maxHeight:-1,_stopClickEvents:false,_getCaretPos:function(_8bf){
var pos=0;
if(typeof (_8bf.selectionStart)=="number"){
pos=_8bf.selectionStart;
}else{
if(dojo.isIE){
var tr=dojo.doc.selection.createRange().duplicate();
var ntr=_8bf.createTextRange();
tr.move("character",0);
ntr.move("character",0);
try{
ntr.setEndPoint("EndToEnd",tr);
pos=String(ntr.text).replace(/\r/g,"").length;
}
catch(e){
}
}
}
return pos;
},_setCaretPos:function(_8c0,_8c1){
_8c1=parseInt(_8c1);
dijit.selectInputText(_8c0,_8c1,_8c1);
},_setDisabledAttr:function(_8c2){
this.inherited(arguments);
dijit.setWaiState(this.domNode,"disabled",_8c2);
},_abortQuery:function(){
if(this.searchTimer){
clearTimeout(this.searchTimer);
this.searchTimer=null;
}
if(this._fetchHandle){
if(this._fetchHandle.abort){
this._fetchHandle.abort();
}
this._fetchHandle=null;
}
},_onInput:function(evt){
if(!this.searchTimer&&(evt.type=="paste"||evt.type=="input")&&this._lastInput!=this.textbox.value){
this.searchTimer=setTimeout(dojo.hitch(this,function(){
this._onKey({charOrCode:229});
}),100);
}
this.inherited(arguments);
},_onKey:function(evt){
var key=evt.charOrCode;
if(evt.altKey||((evt.ctrlKey||evt.metaKey)&&(key!="x"&&key!="v"))||key==dojo.keys.SHIFT){
return;
}
var _8c3=false;
var pw=this.dropDown;
var dk=dojo.keys;
var _8c4=null;
this._prev_key_backspace=false;
this._abortQuery();
this.inherited(arguments);
if(this._opened){
_8c4=pw.getHighlightedOption();
}
switch(key){
case dk.PAGE_DOWN:
case dk.DOWN_ARROW:
case dk.PAGE_UP:
case dk.UP_ARROW:
if(this._opened){
this._announceOption(_8c4);
}
dojo.stopEvent(evt);
break;
case dk.ENTER:
if(_8c4){
if(_8c4==pw.nextButton){
this._nextSearch(1);
dojo.stopEvent(evt);
break;
}else{
if(_8c4==pw.previousButton){
this._nextSearch(-1);
dojo.stopEvent(evt);
break;
}
}
}else{
this._setBlurValue();
this._setCaretPos(this.focusNode,this.focusNode.value.length);
}
if(this._opened||this._fetchHandle){
dojo.stopEvent(evt);
}
case dk.TAB:
var _8c5=this.get("displayedValue");
if(pw&&(_8c5==pw._messages["previousMessage"]||_8c5==pw._messages["nextMessage"])){
break;
}
if(_8c4){
this._selectOption();
}
if(this._opened){
this._lastQuery=null;
this.closeDropDown();
}
break;
case " ":
if(_8c4){
dojo.stopEvent(evt);
this._selectOption();
this.closeDropDown();
}else{
_8c3=true;
}
break;
case dk.DELETE:
case dk.BACKSPACE:
this._prev_key_backspace=true;
_8c3=true;
break;
default:
_8c3=typeof key=="string"||key==229;
}
if(_8c3){
this.item=undefined;
this.searchTimer=setTimeout(dojo.hitch(this,"_startSearchFromInput"),1);
}
},_autoCompleteText:function(text){
var fn=this.focusNode;
dijit.selectInputText(fn,fn.value.length);
var _8c6=this.ignoreCase?"toLowerCase":"substr";
if(text[_8c6](0).indexOf(this.focusNode.value[_8c6](0))==0){
var cpos=this._getCaretPos(fn);
if((cpos+1)>fn.value.length){
fn.value=text;
dijit.selectInputText(fn,cpos);
}
}else{
fn.value=text;
dijit.selectInputText(fn);
}
},_openResultList:function(_8c7,_8c8){
this._fetchHandle=null;
if(this.disabled||this.readOnly||(_8c8.query[this.searchAttr]!=this._lastQuery)){
return;
}
var _8c9=this.dropDown._highlighted_option&&dojo.hasClass(this.dropDown._highlighted_option,"dijitMenuItemSelected");
this.dropDown.clearResultList();
if(!_8c7.length&&!this._maxOptions){
this.closeDropDown();
return;
}
_8c8._maxOptions=this._maxOptions;
var _8ca=this.dropDown.createOptions(_8c7,_8c8,dojo.hitch(this,"_getMenuLabelFromItem"));
this._showResultList();
if(_8c8.direction){
if(1==_8c8.direction){
this.dropDown.highlightFirstOption();
}else{
if(-1==_8c8.direction){
this.dropDown.highlightLastOption();
}
}
if(_8c9){
this._announceOption(this.dropDown.getHighlightedOption());
}
}else{
if(this.autoComplete&&!this._prev_key_backspace&&!/^[*]+$/.test(_8c8.query[this.searchAttr])){
this._announceOption(_8ca[1]);
}
}
},_showResultList:function(){
this.closeDropDown(true);
this.displayMessage("");
this.openDropDown();
dijit.setWaiState(this.domNode,"expanded","true");
},loadDropDown:function(_8cb){
this._startSearchAll();
},isLoaded:function(){
return false;
},closeDropDown:function(){
this._abortQuery();
if(this._opened){
this.inherited(arguments);
dijit.setWaiState(this.domNode,"expanded","false");
dijit.removeWaiState(this.focusNode,"activedescendant");
}
},_setBlurValue:function(){
var _8cc=this.get("displayedValue");
var pw=this.dropDown;
if(pw&&(_8cc==pw._messages["previousMessage"]||_8cc==pw._messages["nextMessage"])){
this._setValueAttr(this._lastValueReported,true);
}else{
if(typeof this.item=="undefined"){
this.item=null;
this.set("displayedValue",_8cc);
}else{
if(this.value!=this._lastValueReported){
dijit.form._FormValueWidget.prototype._setValueAttr.call(this,this.value,true);
}
this._refreshState();
}
}
},_onBlur:function(){
this.closeDropDown();
this.inherited(arguments);
},_setItemAttr:function(item,_8cd,_8ce){
if(!_8ce){
_8ce=this.store.getValue(item,this.searchAttr);
}
var _8cf=this._getValueField()!=this.searchAttr?this.store.getIdentity(item):_8ce;
this._set("item",item);
dijit.form.ComboBox.superclass._setValueAttr.call(this,_8cf,_8cd,_8ce);
},_announceOption:function(node){
if(!node){
return;
}
var _8d0;
if(node==this.dropDown.nextButton||node==this.dropDown.previousButton){
_8d0=node.innerHTML;
this.item=undefined;
this.value="";
}else{
_8d0=this.store.getValue(node.item,this.searchAttr).toString();
this.set("item",node.item,false,_8d0);
}
this.focusNode.value=this.focusNode.value.substring(0,this._lastInput.length);
dijit.setWaiState(this.focusNode,"activedescendant",dojo.attr(node,"id"));
this._autoCompleteText(_8d0);
},_selectOption:function(evt){
if(evt){
this._announceOption(evt.target);
}
this.closeDropDown();
this._setCaretPos(this.focusNode,this.focusNode.value.length);
dijit.form._FormValueWidget.prototype._setValueAttr.call(this,this.value,true);
},_startSearchAll:function(){
this._startSearch("");
},_startSearchFromInput:function(){
this._startSearch(this.focusNode.value.replace(/([\\\*\?])/g,"\\$1"));
},_getQueryString:function(text){
return dojo.string.substitute(this.queryExpr,[text]);
},_startSearch:function(key){
if(!this.dropDown){
var _8d1=this.id+"_popup",_8d2=dojo.getObject(this.dropDownClass,false);
this.dropDown=new _8d2({onChange:dojo.hitch(this,this._selectOption),id:_8d1,dir:this.dir});
dijit.removeWaiState(this.focusNode,"activedescendant");
dijit.setWaiState(this.textbox,"owns",_8d1);
}
var _8d3=dojo.clone(this.query);
this._lastInput=key;
this._lastQuery=_8d3[this.searchAttr]=this._getQueryString(key);
this.searchTimer=setTimeout(dojo.hitch(this,function(_8d4,_8d5){
this.searchTimer=null;
var _8d6={queryOptions:{ignoreCase:this.ignoreCase,deep:true},query:_8d4,onBegin:dojo.hitch(this,"_setMaxOptions"),onComplete:dojo.hitch(this,"_openResultList"),onError:function(_8d7){
_8d5._fetchHandle=null;
console.error("dijit.form.ComboBox: "+_8d7);
_8d5.closeDropDown();
},start:0,count:this.pageSize};
dojo.mixin(_8d6,_8d5.fetchProperties);
this._fetchHandle=_8d5.store.fetch(_8d6);
var _8d8=function(_8d9,_8da){
_8d9.start+=_8d9.count*_8da;
_8d9.direction=_8da;
this._fetchHandle=this.store.fetch(_8d9);
this.focus();
};
this._nextSearch=this.dropDown.onPage=dojo.hitch(this,_8d8,this._fetchHandle);
},_8d3,this),this.searchDelay);
},_setMaxOptions:function(size,_8db){
this._maxOptions=size;
},_getValueField:function(){
return this.searchAttr;
},constructor:function(){
this.query={};
this.fetchProperties={};
},postMixInProperties:function(){
if(!this.store){
var _8dc=this.srcNodeRef;
this.store=new dijit.form._ComboBoxDataStore(_8dc);
if(!("value" in this.params)){
var item=(this.item=this.store.fetchSelectedItem());
if(item){
var _8dd=this._getValueField();
this.value=this.store.getValue(item,_8dd);
}
}
}
this.inherited(arguments);
},postCreate:function(){
var _8de=dojo.query("label[for=\""+this.id+"\"]");
if(_8de.length){
_8de[0].id=(this.id+"_label");
dijit.setWaiState(this.domNode,"labelledby",_8de[0].id);
}
this.inherited(arguments);
},_setHasDownArrowAttr:function(val){
this.hasDownArrow=val;
this._buttonNode.style.display=val?"":"none";
},_getMenuLabelFromItem:function(item){
var _8df=this.labelFunc(item,this.store),_8e0=this.labelType;
if(this.highlightMatch!="none"&&this.labelType=="text"&&this._lastInput){
_8df=this.doHighlight(_8df,this._escapeHtml(this._lastInput));
_8e0="html";
}
return {html:_8e0=="html",label:_8df};
},doHighlight:function(_8e1,find){
var _8e2=(this.ignoreCase?"i":"")+(this.highlightMatch=="all"?"g":""),i=this.queryExpr.indexOf("${0}");
find=dojo.regexp.escapeString(find);
return this._escapeHtml(_8e1).replace(new RegExp((i==0?"^":"")+"("+find+")"+(i==(this.queryExpr.length-4)?"$":""),_8e2),"<span class=\"dijitComboBoxHighlightMatch\">$1</span>");
},_escapeHtml:function(str){
str=String(str).replace(/&/gm,"&amp;").replace(/</gm,"&lt;").replace(/>/gm,"&gt;").replace(/"/gm,"&quot;");
return str;
},reset:function(){
this.item=null;
this.inherited(arguments);
},labelFunc:function(item,_8e3){
return _8e3.getValue(item,this.labelAttr||this.searchAttr).toString();
}});
dojo.declare("dijit.form._ComboBoxMenu",[dijit._Widget,dijit._Templated,dijit._CssStateMixin],{templateString:"<ul class='dijitReset dijitMenu' dojoAttachEvent='onmousedown:_onMouseDown,onmouseup:_onMouseUp,onmouseover:_onMouseOver,onmouseout:_onMouseOut' style='overflow: \"auto\"; overflow-x: \"hidden\";'>"+"<li class='dijitMenuItem dijitMenuPreviousButton' dojoAttachPoint='previousButton' role='option'></li>"+"<li class='dijitMenuItem dijitMenuNextButton' dojoAttachPoint='nextButton' role='option'></li>"+"</ul>",_messages:null,baseClass:"dijitComboBoxMenu",postMixInProperties:function(){
this.inherited(arguments);
this._messages=dojo.i18n.getLocalization("dijit.form","ComboBox",this.lang);
},buildRendering:function(){
this.inherited(arguments);
this.previousButton.innerHTML=this._messages["previousMessage"];
this.nextButton.innerHTML=this._messages["nextMessage"];
},_setValueAttr:function(_8e4){
this.value=_8e4;
this.onChange(_8e4);
},onChange:function(_8e5){
},onPage:function(_8e6){
},onClose:function(){
this._blurOptionNode();
},_createOption:function(item,_8e7){
var _8e8=dojo.create("li",{"class":"dijitReset dijitMenuItem"+(this.isLeftToRight()?"":" dijitMenuItemRtl"),role:"option"});
var _8e9=_8e7(item);
if(_8e9.html){
_8e8.innerHTML=_8e9.label;
}else{
_8e8.appendChild(dojo.doc.createTextNode(_8e9.label));
}
if(_8e8.innerHTML==""){
_8e8.innerHTML="&nbsp;";
}
_8e8.item=item;
return _8e8;
},createOptions:function(_8ea,_8eb,_8ec){
this.previousButton.style.display=(_8eb.start==0)?"none":"";
dojo.attr(this.previousButton,"id",this.id+"_prev");
dojo.forEach(_8ea,function(item,i){
var _8ed=this._createOption(item,_8ec);
dojo.attr(_8ed,"id",this.id+i);
this.domNode.insertBefore(_8ed,this.nextButton);
},this);
var _8ee=false;
if(_8eb._maxOptions&&_8eb._maxOptions!=-1){
if((_8eb.start+_8eb.count)<_8eb._maxOptions){
_8ee=true;
}else{
if((_8eb.start+_8eb.count)>_8eb._maxOptions&&_8eb.count==_8ea.length){
_8ee=true;
}
}
}else{
if(_8eb.count==_8ea.length){
_8ee=true;
}
}
this.nextButton.style.display=_8ee?"":"none";
dojo.attr(this.nextButton,"id",this.id+"_next");
return this.domNode.childNodes;
},clearResultList:function(){
while(this.domNode.childNodes.length>2){
this.domNode.removeChild(this.domNode.childNodes[this.domNode.childNodes.length-2]);
}
this._blurOptionNode();
},_onMouseDown:function(evt){
dojo.stopEvent(evt);
},_onMouseUp:function(evt){
if(evt.target===this.domNode||!this._highlighted_option){
return;
}else{
if(evt.target==this.previousButton){
this._blurOptionNode();
this.onPage(-1);
}else{
if(evt.target==this.nextButton){
this._blurOptionNode();
this.onPage(1);
}else{
var tgt=evt.target;
while(!tgt.item){
tgt=tgt.parentNode;
}
this._setValueAttr({target:tgt},true);
}
}
}
},_onMouseOver:function(evt){
if(evt.target===this.domNode){
return;
}
var tgt=evt.target;
if(!(tgt==this.previousButton||tgt==this.nextButton)){
while(!tgt.item){
tgt=tgt.parentNode;
}
}
this._focusOptionNode(tgt);
},_onMouseOut:function(evt){
if(evt.target===this.domNode){
return;
}
this._blurOptionNode();
},_focusOptionNode:function(node){
if(this._highlighted_option!=node){
this._blurOptionNode();
this._highlighted_option=node;
dojo.addClass(this._highlighted_option,"dijitMenuItemSelected");
}
},_blurOptionNode:function(){
if(this._highlighted_option){
dojo.removeClass(this._highlighted_option,"dijitMenuItemSelected");
this._highlighted_option=null;
}
},_highlightNextOption:function(){
if(!this.getHighlightedOption()){
var fc=this.domNode.firstChild;
this._focusOptionNode(fc.style.display=="none"?fc.nextSibling:fc);
}else{
var ns=this._highlighted_option.nextSibling;
if(ns&&ns.style.display!="none"){
this._focusOptionNode(ns);
}else{
this.highlightFirstOption();
}
}
dojo.window.scrollIntoView(this._highlighted_option);
},highlightFirstOption:function(){
var _8ef=this.domNode.firstChild;
var _8f0=_8ef.nextSibling;
this._focusOptionNode(_8f0.style.display=="none"?_8ef:_8f0);
dojo.window.scrollIntoView(this._highlighted_option);
},highlightLastOption:function(){
this._focusOptionNode(this.domNode.lastChild.previousSibling);
dojo.window.scrollIntoView(this._highlighted_option);
},_highlightPrevOption:function(){
if(!this.getHighlightedOption()){
var lc=this.domNode.lastChild;
this._focusOptionNode(lc.style.display=="none"?lc.previousSibling:lc);
}else{
var ps=this._highlighted_option.previousSibling;
if(ps&&ps.style.display!="none"){
this._focusOptionNode(ps);
}else{
this.highlightLastOption();
}
}
dojo.window.scrollIntoView(this._highlighted_option);
},_page:function(up){
var _8f1=0;
var _8f2=this.domNode.scrollTop;
var _8f3=dojo.style(this.domNode,"height");
if(!this.getHighlightedOption()){
this._highlightNextOption();
}
while(_8f1<_8f3){
if(up){
if(!this.getHighlightedOption().previousSibling||this._highlighted_option.previousSibling.style.display=="none"){
break;
}
this._highlightPrevOption();
}else{
if(!this.getHighlightedOption().nextSibling||this._highlighted_option.nextSibling.style.display=="none"){
break;
}
this._highlightNextOption();
}
var _8f4=this.domNode.scrollTop;
_8f1+=(_8f4-_8f2)*(up?-1:1);
_8f2=_8f4;
}
},pageUp:function(){
this._page(true);
},pageDown:function(){
this._page(false);
},getHighlightedOption:function(){
var ho=this._highlighted_option;
return (ho&&ho.parentNode)?ho:null;
},handleKey:function(evt){
switch(evt.charOrCode){
case dojo.keys.DOWN_ARROW:
this._highlightNextOption();
return false;
case dojo.keys.PAGE_DOWN:
this.pageDown();
return false;
case dojo.keys.UP_ARROW:
this._highlightPrevOption();
return false;
case dojo.keys.PAGE_UP:
this.pageUp();
return false;
default:
return true;
}
}});
dojo.declare("dijit.form.ComboBox",[dijit.form.ValidationTextBox,dijit.form.ComboBoxMixin],{_setValueAttr:function(_8f5,_8f6,_8f7){
this._set("item",null);
if(!_8f5){
_8f5="";
}
dijit.form.ValidationTextBox.prototype._setValueAttr.call(this,_8f5,_8f6,_8f7);
}});
dojo.declare("dijit.form._ComboBoxDataStore",null,{constructor:function(root){
this.root=root;
if(root.tagName!="SELECT"&&root.firstChild){
root=dojo.query("select",root);
if(root.length>0){
root=root[0];
}else{
this.root.innerHTML="<SELECT>"+this.root.innerHTML+"</SELECT>";
root=this.root.firstChild;
}
this.root=root;
}
dojo.query("> option",root).forEach(function(node){
node.innerHTML=dojo.trim(node.innerHTML);
});
},getValue:function(item,_8f8,_8f9){
return (_8f8=="value")?item.value:(item.innerText||item.textContent||"");
},isItemLoaded:function(_8fa){
return true;
},getFeatures:function(){
return {"dojo.data.api.Read":true,"dojo.data.api.Identity":true};
},_fetchItems:function(args,_8fb,_8fc){
if(!args.query){
args.query={};
}
if(!args.query.name){
args.query.name="";
}
if(!args.queryOptions){
args.queryOptions={};
}
var _8fd=dojo.data.util.filter.patternToRegExp(args.query.name,args.queryOptions.ignoreCase),_8fe=dojo.query("> option",this.root).filter(function(_8ff){
return (_8ff.innerText||_8ff.textContent||"").match(_8fd);
});
if(args.sort){
_8fe.sort(dojo.data.util.sorter.createSortFunction(args.sort,this));
}
_8fb(_8fe,args);
},close:function(_900){
return;
},getLabel:function(item){
return item.innerHTML;
},getIdentity:function(item){
return dojo.attr(item,"value");
},fetchItemByIdentity:function(args){
var item=dojo.query("> option[value='"+args.identity+"']",this.root)[0];
args.onItem(item);
},fetchSelectedItem:function(){
var root=this.root,si=root.selectedIndex;
return typeof si=="number"?dojo.query("> option:nth-child("+(si!=-1?si+1:1)+")",root)[0]:null;
}});
dojo.extend(dijit.form._ComboBoxDataStore,dojo.data.util.simpleFetch);
}
if(!dojo._hasResource["dijit.form._FormSelectWidget"]){
dojo._hasResource["dijit.form._FormSelectWidget"]=true;
dojo.provide("dijit.form._FormSelectWidget");
dojo.declare("dijit.form._FormSelectWidget",dijit.form._FormValueWidget,{multiple:false,options:null,store:null,query:null,queryOptions:null,onFetch:null,sortByLabel:true,loadChildrenOnOpen:false,getOptions:function(_901){
var _902=_901,opts=this.options||[],l=opts.length;
if(_902===undefined){
return opts;
}
if(dojo.isArray(_902)){
return dojo.map(_902,"return this.getOptions(item);",this);
}
if(dojo.isObject(_901)){
if(!dojo.some(this.options,function(o,idx){
if(o===_902||(o.value&&o.value===_902.value)){
_902=idx;
return true;
}
return false;
})){
_902=-1;
}
}
if(typeof _902=="string"){
for(var i=0;i<l;i++){
if(opts[i].value===_902){
_902=i;
break;
}
}
}
if(typeof _902=="number"&&_902>=0&&_902<l){
return this.options[_902];
}
return null;
},addOption:function(_903){
if(!dojo.isArray(_903)){
_903=[_903];
}
dojo.forEach(_903,function(i){
if(i&&dojo.isObject(i)){
this.options.push(i);
}
},this);
this._loadChildren();
},removeOption:function(_904){
if(!dojo.isArray(_904)){
_904=[_904];
}
var _905=this.getOptions(_904);
dojo.forEach(_905,function(i){
if(i){
this.options=dojo.filter(this.options,function(node,idx){
return (node.value!==i.value||node.label!==i.label);
});
this._removeOptionItem(i);
}
},this);
this._loadChildren();
},updateOption:function(_906){
if(!dojo.isArray(_906)){
_906=[_906];
}
dojo.forEach(_906,function(i){
var _907=this.getOptions(i),k;
if(_907){
for(k in i){
_907[k]=i[k];
}
}
},this);
this._loadChildren();
},setStore:function(_908,_909,_90a){
var _90b=this.store;
_90a=_90a||{};
if(_90b!==_908){
dojo.forEach(this._notifyConnections||[],dojo.disconnect);
delete this._notifyConnections;
if(_908&&_908.getFeatures()["dojo.data.api.Notification"]){
this._notifyConnections=[dojo.connect(_908,"onNew",this,"_onNewItem"),dojo.connect(_908,"onDelete",this,"_onDeleteItem"),dojo.connect(_908,"onSet",this,"_onSetItem")];
}
this._set("store",_908);
}
this._onChangeActive=false;
if(this.options&&this.options.length){
this.removeOption(this.options);
}
if(_908){
this._loadingStore=true;
_908.fetch(dojo.delegate(_90a,{onComplete:function(_90c,opts){
if(this.sortByLabel&&!_90a.sort&&_90c.length){
_90c.sort(dojo.data.util.sorter.createSortFunction([{attribute:_908.getLabelAttributes(_90c[0])[0]}],_908));
}
if(_90a.onFetch){
_90c=_90a.onFetch.call(this,_90c,opts);
}
dojo.forEach(_90c,function(i){
this._addOptionForItem(i);
},this);
this._loadingStore=false;
this.set("value","_pendingValue" in this?this._pendingValue:_909);
delete this._pendingValue;
if(!this.loadChildrenOnOpen){
this._loadChildren();
}else{
this._pseudoLoadChildren(_90c);
}
this._fetchedWith=opts;
this._lastValueReported=this.multiple?[]:null;
this._onChangeActive=true;
this.onSetStore();
this._handleOnChange(this.value);
},scope:this}));
}else{
delete this._fetchedWith;
}
return _90b;
},_setValueAttr:function(_90d,_90e){
if(this._loadingStore){
this._pendingValue=_90d;
return;
}
var opts=this.getOptions()||[];
if(!dojo.isArray(_90d)){
_90d=[_90d];
}
dojo.forEach(_90d,function(i,idx){
if(!dojo.isObject(i)){
i=i+"";
}
if(typeof i==="string"){
_90d[idx]=dojo.filter(opts,function(node){
return node.value===i;
})[0]||{value:"",label:""};
}
},this);
_90d=dojo.filter(_90d,function(i){
return i&&i.value;
});
if(!this.multiple&&(!_90d[0]||!_90d[0].value)&&opts.length){
_90d[0]=opts[0];
}
dojo.forEach(opts,function(i){
i.selected=dojo.some(_90d,function(v){
return v.value===i.value;
});
});
var val=dojo.map(_90d,function(i){
return i.value;
}),disp=dojo.map(_90d,function(i){
return i.label;
});
this._set("value",this.multiple?val:val[0]);
this._setDisplay(this.multiple?disp:disp[0]);
this._updateSelection();
this._handleOnChange(this.value,_90e);
},_getDisplayedValueAttr:function(){
var val=this.get("value");
if(!dojo.isArray(val)){
val=[val];
}
var ret=dojo.map(this.getOptions(val),function(v){
if(v&&"label" in v){
return v.label;
}else{
if(v){
return v.value;
}
}
return null;
},this);
return this.multiple?ret:ret[0];
},_loadChildren:function(){
if(this._loadingStore){
return;
}
dojo.forEach(this._getChildren(),function(_90f){
_90f.destroyRecursive();
});
dojo.forEach(this.options,this._addOptionItem,this);
this._updateSelection();
},_updateSelection:function(){
this._set("value",this._getValueFromOpts());
var val=this.value;
if(!dojo.isArray(val)){
val=[val];
}
if(val&&val[0]){
dojo.forEach(this._getChildren(),function(_910){
var _911=dojo.some(val,function(v){
return _910.option&&(v===_910.option.value);
});
dojo.toggleClass(_910.domNode,this.baseClass+"SelectedOption",_911);
dijit.setWaiState(_910.domNode,"selected",_911);
},this);
}
},_getValueFromOpts:function(){
var opts=this.getOptions()||[];
if(!this.multiple&&opts.length){
var opt=dojo.filter(opts,function(i){
return i.selected;
})[0];
if(opt&&opt.value){
return opt.value;
}else{
opts[0].selected=true;
return opts[0].value;
}
}else{
if(this.multiple){
return dojo.map(dojo.filter(opts,function(i){
return i.selected;
}),function(i){
return i.value;
})||[];
}
}
return "";
},_onNewItem:function(item,_912){
if(!_912||!_912.parent){
this._addOptionForItem(item);
}
},_onDeleteItem:function(item){
var _913=this.store;
this.removeOption(_913.getIdentity(item));
},_onSetItem:function(item){
this.updateOption(this._getOptionObjForItem(item));
},_getOptionObjForItem:function(item){
var _914=this.store,_915=_914.getLabel(item),_916=(_915?_914.getIdentity(item):null);
return {value:_916,label:_915,item:item};
},_addOptionForItem:function(item){
var _917=this.store;
if(!_917.isItemLoaded(item)){
_917.loadItem({item:item,onComplete:function(i){
this._addOptionForItem(item);
},scope:this});
return;
}
var _918=this._getOptionObjForItem(item);
this.addOption(_918);
},constructor:function(_919){
this._oValue=(_919||{}).value||null;
},buildRendering:function(){
this.inherited(arguments);
dojo.setSelectable(this.focusNode,false);
},_fillContent:function(){
var opts=this.options;
if(!opts){
opts=this.options=this.srcNodeRef?dojo.query(">",this.srcNodeRef).map(function(node){
if(node.getAttribute("type")==="separator"){
return {value:"",label:"",selected:false,disabled:false};
}
return {value:(node.getAttribute("data-"+dojo._scopeName+"-value")||node.getAttribute("value")),label:String(node.innerHTML),selected:node.getAttribute("selected")||false,disabled:node.getAttribute("disabled")||false};
},this):[];
}
if(!this.value){
this._set("value",this._getValueFromOpts());
}else{
if(this.multiple&&typeof this.value=="string"){
this._set("value",this.value.split(","));
}
}
},postCreate:function(){
this.inherited(arguments);
this.connect(this,"onChange","_updateSelection");
this.connect(this,"startup","_loadChildren");
this._setValueAttr(this.value,null);
},startup:function(){
this.inherited(arguments);
var _91a=this.store,_91b={};
dojo.forEach(["query","queryOptions","onFetch"],function(i){
if(this[i]){
_91b[i]=this[i];
}
delete this[i];
},this);
if(_91a&&_91a.getFeatures()["dojo.data.api.Identity"]){
this.store=null;
this.setStore(_91a,this._oValue,_91b);
}
},destroy:function(){
dojo.forEach(this._notifyConnections||[],dojo.disconnect);
this.inherited(arguments);
},_addOptionItem:function(_91c){
},_removeOptionItem:function(_91d){
},_setDisplay:function(_91e){
},_getChildren:function(){
return [];
},_getSelectedOptionsAttr:function(){
return this.getOptions(this.get("value"));
},_pseudoLoadChildren:function(_91f){
},onSetStore:function(){
}});
}
if(!dojo._hasResource["dijit.form.Select"]){
dojo._hasResource["dijit.form.Select"]=true;
dojo.provide("dijit.form.Select");
dojo.declare("dijit.form._SelectMenu",dijit.Menu,{buildRendering:function(){
this.inherited(arguments);
var o=(this.menuTableNode=this.domNode);
var n=(this.domNode=dojo.create("div",{style:{overflowX:"hidden",overflowY:"scroll"}}));
if(o.parentNode){
o.parentNode.replaceChild(n,o);
}
dojo.removeClass(o,"dijitMenuTable");
n.className=o.className+" dijitSelectMenu";
o.className="dijitReset dijitMenuTable";
dijit.setWaiRole(o,"listbox");
dijit.setWaiRole(n,"presentation");
n.appendChild(o);
},postCreate:function(){
this.inherited(arguments);
this.connect(this.domNode,"onmousemove",dojo.stopEvent);
},resize:function(mb){
if(mb){
dojo.marginBox(this.domNode,mb);
if("w" in mb){
this.menuTableNode.style.width="100%";
}
}
}});
dojo.declare("dijit.form.Select",[dijit.form._FormSelectWidget,dijit._HasDropDown],{baseClass:"dijitSelect",templateString:dojo.cache("dijit.form","templates/Select.html","<table class=\"dijit dijitReset dijitInline dijitLeft\"\r\n\tdojoAttachPoint=\"_buttonNode,tableNode,focusNode\" cellspacing='0' cellpadding='0'\r\n\trole=\"combobox\" aria-haspopup=\"true\"\r\n\t><tbody role=\"presentation\"><tr role=\"presentation\"\r\n\t\t><td class=\"dijitReset dijitStretch dijitButtonContents dijitButtonNode\" role=\"presentation\"\r\n\t\t\t><span class=\"dijitReset dijitInline dijitButtonText\"  dojoAttachPoint=\"containerNode,_popupStateNode\"></span\r\n\t\t\t><input type=\"hidden\" ${!nameAttrSetting} dojoAttachPoint=\"valueNode\" value=\"${value}\" aria-hidden=\"true\"\r\n\t\t/></td><td class=\"dijitReset dijitRight dijitButtonNode dijitArrowButton dijitDownArrowButton\"\r\n\t\t\t\tdojoAttachPoint=\"titleNode\" role=\"presentation\"\r\n\t\t\t><div class=\"dijitReset dijitArrowButtonInner\" role=\"presentation\"></div\r\n\t\t\t><div class=\"dijitReset dijitArrowButtonChar\" role=\"presentation\">&#9660;</div\r\n\t\t></td\r\n\t></tr></tbody\r\n></table>\r\n"),attributeMap:dojo.mixin(dojo.clone(dijit.form._FormSelectWidget.prototype.attributeMap),{style:"tableNode"}),required:false,state:"",message:"",tooltipPosition:[],emptyLabel:"&nbsp;",_isLoaded:false,_childrenLoaded:false,_fillContent:function(){
this.inherited(arguments);
if(this.options.length&&!this.value&&this.srcNodeRef){
var si=this.srcNodeRef.selectedIndex||0;
this.value=this.options[si>=0?si:0].value;
}
this.dropDown=new dijit.form._SelectMenu({id:this.id+"_menu"});
dojo.addClass(this.dropDown.domNode,this.baseClass+"Menu");
},_getMenuItemForOption:function(_920){
if(!_920.value&&!_920.label){
return new dijit.MenuSeparator();
}else{
var _921=dojo.hitch(this,"_setValueAttr",_920);
var item=new dijit.MenuItem({option:_920,label:_920.label||this.emptyLabel,onClick:_921,disabled:_920.disabled||false});
dijit.setWaiRole(item.focusNode,"listitem");
return item;
}
},_addOptionItem:function(_922){
if(this.dropDown){
this.dropDown.addChild(this._getMenuItemForOption(_922));
}
},_getChildren:function(){
if(!this.dropDown){
return [];
}
return this.dropDown.getChildren();
},_loadChildren:function(_923){
if(_923===true){
if(this.dropDown){
delete this.dropDown.focusedChild;
}
if(this.options.length){
this.inherited(arguments);
}else{
dojo.forEach(this._getChildren(),function(_924){
_924.destroyRecursive();
});
var item=new dijit.MenuItem({label:"&nbsp;"});
this.dropDown.addChild(item);
}
}else{
this._updateSelection();
}
this._isLoaded=false;
this._childrenLoaded=true;
if(!this._loadingStore){
this._setValueAttr(this.value);
}
},_setValueAttr:function(_925){
this.inherited(arguments);
dojo.attr(this.valueNode,"value",this.get("value"));
},_setDisplay:function(_926){
var lbl=_926||this.emptyLabel;
this.containerNode.innerHTML="<span class=\"dijitReset dijitInline "+this.baseClass+"Label\">"+lbl+"</span>";
dijit.setWaiState(this.focusNode,"valuetext",lbl);
},validate:function(_927){
var _928=this.isValid(_927);
this._set("state",_928?"":"Error");
dijit.setWaiState(this.focusNode,"invalid",_928?"false":"true");
var _929=_928?"":this._missingMsg;
if(this.message!==_929){
this._set("message",_929);
dijit.hideTooltip(this.domNode);
if(_929){
dijit.showTooltip(_929,this.domNode,this.tooltipPosition,!this.isLeftToRight());
}
}
return _928;
},isValid:function(_92a){
return (!this.required||this.value===0||!(/^\s*$/.test(this.value||"")));
},reset:function(){
this.inherited(arguments);
dijit.hideTooltip(this.domNode);
this._set("state","");
this._set("message","");
},postMixInProperties:function(){
this.inherited(arguments);
this._missingMsg=dojo.i18n.getLocalization("dijit.form","validate",this.lang).missingMessage;
},postCreate:function(){
this.inherited(arguments);
this.connect(this.domNode,"onmousemove",dojo.stopEvent);
},_setStyleAttr:function(_92b){
this.inherited(arguments);
dojo.toggleClass(this.domNode,this.baseClass+"FixedWidth",!!this.tableNode.style.width);
},isLoaded:function(){
return this._isLoaded;
},loadDropDown:function(_92c){
this._loadChildren(true);
this._isLoaded=true;
_92c();
},closeDropDown:function(){
this.inherited(arguments);
if(this.dropDown&&this.dropDown.menuTableNode){
this.dropDown.menuTableNode.style.width="";
}
},uninitialize:function(_92d){
if(this.dropDown&&!this.dropDown._destroyed){
this.dropDown.destroyRecursive(_92d);
delete this.dropDown;
}
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.form.ToggleButton"]){
dojo._hasResource["dijit.form.ToggleButton"]=true;
dojo.provide("dijit.form.ToggleButton");
}
if(!dojo._hasResource["dijit.form.CheckBox"]){
dojo._hasResource["dijit.form.CheckBox"]=true;
dojo.provide("dijit.form.CheckBox");
dojo.declare("dijit.form.CheckBox",dijit.form.ToggleButton,{templateString:dojo.cache("dijit.form","templates/CheckBox.html","<div class=\"dijit dijitReset dijitInline\" role=\"presentation\"\r\n\t><input\r\n\t \t${!nameAttrSetting} type=\"${type}\" ${checkedAttrSetting}\r\n\t\tclass=\"dijitReset dijitCheckBoxInput\"\r\n\t\tdojoAttachPoint=\"focusNode\"\r\n\t \tdojoAttachEvent=\"onclick:_onClick\"\r\n/></div>\r\n"),baseClass:"dijitCheckBox",type:"checkbox",value:"on",readOnly:false,attributeMap:dojo.delegate(dijit.form._FormWidget.prototype.attributeMap,{readOnly:"focusNode"}),_setReadOnlyAttr:function(_92e){
this._set("readOnly",_92e);
dojo.attr(this.focusNode,"readOnly",_92e);
dijit.setWaiState(this.focusNode,"readonly",_92e);
},_setValueAttr:function(_92f,_930){
if(typeof _92f=="string"){
this._set("value",_92f);
dojo.attr(this.focusNode,"value",_92f);
_92f=true;
}
if(this._created){
this.set("checked",_92f,_930);
}
},_getValueAttr:function(){
return (this.checked?this.value:false);
},_setLabelAttr:undefined,postMixInProperties:function(){
if(this.value==""){
this.value="on";
}
this.checkedAttrSetting=this.checked?"checked":"";
this.inherited(arguments);
},_fillContent:function(_931){
},reset:function(){
this._hasBeenBlurred=false;
this.set("checked",this.params.checked||false);
this._set("value",this.params.value||"on");
dojo.attr(this.focusNode,"value",this.value);
},_onFocus:function(){
if(this.id){
dojo.query("label[for='"+this.id+"']").addClass("dijitFocusedLabel");
}
this.inherited(arguments);
},_onBlur:function(){
if(this.id){
dojo.query("label[for='"+this.id+"']").removeClass("dijitFocusedLabel");
}
this.inherited(arguments);
},_onClick:function(e){
if(this.readOnly){
dojo.stopEvent(e);
return false;
}
return this.inherited(arguments);
}});
dojo.declare("dijit.form.RadioButton",dijit.form.CheckBox,{type:"radio",baseClass:"dijitRadio",_setCheckedAttr:function(_932){
this.inherited(arguments);
if(!this._created){
return;
}
if(_932){
var _933=this;
dojo.query("INPUT[type=radio]",this.focusNode.form||dojo.doc).forEach(function(_934){
if(_934.name==_933.name&&_934!=_933.focusNode&&_934.form==_933.focusNode.form){
var _935=dijit.getEnclosingWidget(_934);
if(_935&&_935.checked){
_935.set("checked",false);
}
}
});
}
},_clicked:function(e){
if(!this.checked){
this.set("checked",true);
}
}});
}
if(!dojo._hasResource["dijit.form.RadioButton"]){
dojo._hasResource["dijit.form.RadioButton"]=true;
dojo.provide("dijit.form.RadioButton");
}
if(!dojo._hasResource["dojo.number"]){
dojo._hasResource["dojo.number"]=true;
dojo.provide("dojo.number");
dojo.getObject("number",true,dojo);
dojo.number.format=function(_936,_937){
_937=dojo.mixin({},_937||{});
var _938=dojo.i18n.normalizeLocale(_937.locale),_939=dojo.i18n.getLocalization("dojo.cldr","number",_938);
_937.customs=_939;
var _93a=_937.pattern||_939[(_937.type||"decimal")+"Format"];
if(isNaN(_936)||Math.abs(_936)==Infinity){
return null;
}
return dojo.number._applyPattern(_936,_93a,_937);
};
dojo.number._numberPatternRE=/[#0,]*[#0](?:\.0*#*)?/;
dojo.number._applyPattern=function(_93b,_93c,_93d){
_93d=_93d||{};
var _93e=_93d.customs.group,_93f=_93d.customs.decimal,_940=_93c.split(";"),_941=_940[0];
_93c=_940[(_93b<0)?1:0]||("-"+_941);
if(_93c.indexOf("%")!=-1){
_93b*=100;
}else{
if(_93c.indexOf("‰")!=-1){
_93b*=1000;
}else{
if(_93c.indexOf("¤")!=-1){
_93e=_93d.customs.currencyGroup||_93e;
_93f=_93d.customs.currencyDecimal||_93f;
_93c=_93c.replace(/\u00a4{1,3}/,function(_942){
var prop=["symbol","currency","displayName"][_942.length-1];
return _93d[prop]||_93d.currency||"";
});
}else{
if(_93c.indexOf("E")!=-1){
throw new Error("exponential notation not supported");
}
}
}
}
var _943=dojo.number._numberPatternRE;
var _944=_941.match(_943);
if(!_944){
throw new Error("unable to find a number expression in pattern: "+_93c);
}
if(_93d.fractional===false){
_93d.places=0;
}
return _93c.replace(_943,dojo.number._formatAbsolute(_93b,_944[0],{decimal:_93f,group:_93e,places:_93d.places,round:_93d.round}));
};
dojo.number.round=function(_945,_946,_947){
var _948=10/(_947||10);
return (_948*+_945).toFixed(_946)/_948;
};
if((0.9).toFixed()==0){
(function(){
var _949=dojo.number.round;
dojo.number.round=function(v,p,m){
var d=Math.pow(10,-p||0),a=Math.abs(v);
if(!v||a>=d||a*Math.pow(10,p+1)<5){
d=0;
}
return _949(v,p,m)+(v>0?d:-d);
};
})();
}
dojo.number._formatAbsolute=function(_94a,_94b,_94c){
_94c=_94c||{};
if(_94c.places===true){
_94c.places=0;
}
if(_94c.places===Infinity){
_94c.places=6;
}
var _94d=_94b.split("."),_94e=typeof _94c.places=="string"&&_94c.places.indexOf(","),_94f=_94c.places;
if(_94e){
_94f=_94c.places.substring(_94e+1);
}else{
if(!(_94f>=0)){
_94f=(_94d[1]||[]).length;
}
}
if(!(_94c.round<0)){
_94a=dojo.number.round(_94a,_94f,_94c.round);
}
var _950=String(Math.abs(_94a)).split("."),_951=_950[1]||"";
if(_94d[1]||_94c.places){
if(_94e){
_94c.places=_94c.places.substring(0,_94e);
}
var pad=_94c.places!==undefined?_94c.places:(_94d[1]&&_94d[1].lastIndexOf("0")+1);
if(pad>_951.length){
_950[1]=dojo.string.pad(_951,pad,"0",true);
}
if(_94f<_951.length){
_950[1]=_951.substr(0,_94f);
}
}else{
if(_950[1]){
_950.pop();
}
}
var _952=_94d[0].replace(",","");
pad=_952.indexOf("0");
if(pad!=-1){
pad=_952.length-pad;
if(pad>_950[0].length){
_950[0]=dojo.string.pad(_950[0],pad);
}
if(_952.indexOf("#")==-1){
_950[0]=_950[0].substr(_950[0].length-pad);
}
}
var _953=_94d[0].lastIndexOf(","),_954,_955;
if(_953!=-1){
_954=_94d[0].length-_953-1;
var _956=_94d[0].substr(0,_953);
_953=_956.lastIndexOf(",");
if(_953!=-1){
_955=_956.length-_953-1;
}
}
var _957=[];
for(var _958=_950[0];_958;){
var off=_958.length-_954;
_957.push((off>0)?_958.substr(off):_958);
_958=(off>0)?_958.slice(0,off):"";
if(_955){
_954=_955;
delete _955;
}
}
_950[0]=_957.reverse().join(_94c.group||",");
return _950.join(_94c.decimal||".");
};
dojo.number.regexp=function(_959){
return dojo.number._parseInfo(_959).regexp;
};
dojo.number._parseInfo=function(_95a){
_95a=_95a||{};
var _95b=dojo.i18n.normalizeLocale(_95a.locale),_95c=dojo.i18n.getLocalization("dojo.cldr","number",_95b),_95d=_95a.pattern||_95c[(_95a.type||"decimal")+"Format"],_95e=_95c.group,_95f=_95c.decimal,_960=1;
if(_95d.indexOf("%")!=-1){
_960/=100;
}else{
if(_95d.indexOf("‰")!=-1){
_960/=1000;
}else{
var _961=_95d.indexOf("¤")!=-1;
if(_961){
_95e=_95c.currencyGroup||_95e;
_95f=_95c.currencyDecimal||_95f;
}
}
}
var _962=_95d.split(";");
if(_962.length==1){
_962.push("-"+_962[0]);
}
var re=dojo.regexp.buildGroupRE(_962,function(_963){
_963="(?:"+dojo.regexp.escapeString(_963,".")+")";
return _963.replace(dojo.number._numberPatternRE,function(_964){
var _965={signed:false,separator:_95a.strict?_95e:[_95e,""],fractional:_95a.fractional,decimal:_95f,exponent:false},_966=_964.split("."),_967=_95a.places;
if(_966.length==1&&_960!=1){
_966[1]="###";
}
if(_966.length==1||_967===0){
_965.fractional=false;
}else{
if(_967===undefined){
_967=_95a.pattern?_966[1].lastIndexOf("0")+1:Infinity;
}
if(_967&&_95a.fractional==undefined){
_965.fractional=true;
}
if(!_95a.places&&(_967<_966[1].length)){
_967+=","+_966[1].length;
}
_965.places=_967;
}
var _968=_966[0].split(",");
if(_968.length>1){
_965.groupSize=_968.pop().length;
if(_968.length>1){
_965.groupSize2=_968.pop().length;
}
}
return "("+dojo.number._realNumberRegexp(_965)+")";
});
},true);
if(_961){
re=re.replace(/([\s\xa0]*)(\u00a4{1,3})([\s\xa0]*)/g,function(_969,_96a,_96b,_96c){
var prop=["symbol","currency","displayName"][_96b.length-1],_96d=dojo.regexp.escapeString(_95a[prop]||_95a.currency||"");
_96a=_96a?"[\\s\\xa0]":"";
_96c=_96c?"[\\s\\xa0]":"";
if(!_95a.strict){
if(_96a){
_96a+="*";
}
if(_96c){
_96c+="*";
}
return "(?:"+_96a+_96d+_96c+")?";
}
return _96a+_96d+_96c;
});
}
return {regexp:re.replace(/[\xa0 ]/g,"[\\s\\xa0]"),group:_95e,decimal:_95f,factor:_960};
};
dojo.number.parse=function(_96e,_96f){
var info=dojo.number._parseInfo(_96f),_970=(new RegExp("^"+info.regexp+"$")).exec(_96e);
if(!_970){
return NaN;
}
var _971=_970[1];
if(!_970[1]){
if(!_970[2]){
return NaN;
}
_971=_970[2];
info.factor*=-1;
}
_971=_971.replace(new RegExp("["+info.group+"\\s\\xa0"+"]","g"),"").replace(info.decimal,".");
return _971*info.factor;
};
dojo.number._realNumberRegexp=function(_972){
_972=_972||{};
if(!("places" in _972)){
_972.places=Infinity;
}
if(typeof _972.decimal!="string"){
_972.decimal=".";
}
if(!("fractional" in _972)||/^0/.test(_972.places)){
_972.fractional=[true,false];
}
if(!("exponent" in _972)){
_972.exponent=[true,false];
}
if(!("eSigned" in _972)){
_972.eSigned=[true,false];
}
var _973=dojo.number._integerRegexp(_972),_974=dojo.regexp.buildGroupRE(_972.fractional,function(q){
var re="";
if(q&&(_972.places!==0)){
re="\\"+_972.decimal;
if(_972.places==Infinity){
re="(?:"+re+"\\d+)?";
}else{
re+="\\d{"+_972.places+"}";
}
}
return re;
},true);
var _975=dojo.regexp.buildGroupRE(_972.exponent,function(q){
if(q){
return "([eE]"+dojo.number._integerRegexp({signed:_972.eSigned})+")";
}
return "";
});
var _976=_973+_974;
if(_974){
_976="(?:(?:"+_976+")|(?:"+_974+"))";
}
return _976+_975;
};
dojo.number._integerRegexp=function(_977){
_977=_977||{};
if(!("signed" in _977)){
_977.signed=[true,false];
}
if(!("separator" in _977)){
_977.separator="";
}else{
if(!("groupSize" in _977)){
_977.groupSize=3;
}
}
var _978=dojo.regexp.buildGroupRE(_977.signed,function(q){
return q?"[-+]":"";
},true);
var _979=dojo.regexp.buildGroupRE(_977.separator,function(sep){
if(!sep){
return "(?:\\d+)";
}
sep=dojo.regexp.escapeString(sep);
if(sep==" "){
sep="\\s";
}else{
if(sep==" "){
sep="\\s\\xa0";
}
}
var grp=_977.groupSize,grp2=_977.groupSize2;
if(grp2){
var _97a="(?:0|[1-9]\\d{0,"+(grp2-1)+"}(?:["+sep+"]\\d{"+grp2+"})*["+sep+"]\\d{"+grp+"})";
return ((grp-grp2)>0)?"(?:"+_97a+"|(?:0|[1-9]\\d{0,"+(grp-1)+"}))":_97a;
}
return "(?:0|[1-9]\\d{0,"+(grp-1)+"}(?:["+sep+"]\\d{"+grp+"})*)";
},true);
return _978+_979;
};
}
if(!dojo._hasResource["dijit.form.NumberTextBox"]){
dojo._hasResource["dijit.form.NumberTextBox"]=true;
dojo.provide("dijit.form.NumberTextBox");
dojo.declare("dijit.form.NumberTextBoxMixin",null,{regExpGen:dojo.number.regexp,value:NaN,editOptions:{pattern:"#.######"},_formatter:dojo.number.format,_setConstraintsAttr:function(_97b){
var _97c=typeof _97b.places=="number"?_97b.places:0;
if(_97c){
_97c++;
}
if(typeof _97b.max!="number"){
_97b.max=9*Math.pow(10,15-_97c);
}
if(typeof _97b.min!="number"){
_97b.min=-9*Math.pow(10,15-_97c);
}
this.inherited(arguments,[_97b]);
if(this.focusNode&&this.focusNode.value&&!isNaN(this.value)){
this.set("value",this.value);
}
},_onFocus:function(){
if(this.disabled){
return;
}
var val=this.get("value");
if(typeof val=="number"&&!isNaN(val)){
var _97d=this.format(val,this.constraints);
if(_97d!==undefined){
this.textbox.value=_97d;
}
}
this.inherited(arguments);
},format:function(_97e,_97f){
var _980=String(_97e);
if(typeof _97e!="number"){
return _980;
}
if(isNaN(_97e)){
return "";
}
if(!("rangeCheck" in this&&this.rangeCheck(_97e,_97f))&&_97f.exponent!==false&&/\de[-+]?\d/i.test(_980)){
return _980;
}
if(this.editOptions&&this._focused){
_97f=dojo.mixin({},_97f,this.editOptions);
}
return this._formatter(_97e,_97f);
},_parser:dojo.number.parse,parse:function(_981,_982){
var v=this._parser(_981,dojo.mixin({},_982,(this.editOptions&&this._focused)?this.editOptions:{}));
if(this.editOptions&&this._focused&&isNaN(v)){
v=this._parser(_981,_982);
}
return v;
},_getDisplayedValueAttr:function(){
var v=this.inherited(arguments);
return isNaN(v)?this.textbox.value:v;
},filter:function(_983){
return (_983===null||_983===""||_983===undefined)?NaN:this.inherited(arguments);
},serialize:function(_984,_985){
return (typeof _984!="number"||isNaN(_984))?"":this.inherited(arguments);
},_setBlurValue:function(){
var val=dojo.hitch(dojo.mixin({},this,{_focused:true}),"get")("value");
this._setValueAttr(val,true);
},_setValueAttr:function(_986,_987,_988){
if(_986!==undefined&&_988===undefined){
_988=String(_986);
if(typeof _986=="number"){
if(isNaN(_986)){
_988="";
}else{
if(("rangeCheck" in this&&this.rangeCheck(_986,this.constraints))||this.constraints.exponent===false||!/\de[-+]?\d/i.test(_988)){
_988=undefined;
}
}
}else{
if(!_986){
_988="";
_986=NaN;
}else{
_986=undefined;
}
}
}
this.inherited(arguments,[_986,_987,_988]);
},_getValueAttr:function(){
var v=this.inherited(arguments);
if(isNaN(v)&&this.textbox.value!==""){
if(this.constraints.exponent!==false&&/\de[-+]?\d/i.test(this.textbox.value)&&(new RegExp("^"+dojo.number._realNumberRegexp(dojo.mixin({},this.constraints))+"$").test(this.textbox.value))){
var n=Number(this.textbox.value);
return isNaN(n)?undefined:n;
}else{
return undefined;
}
}else{
return v;
}
},isValid:function(_989){
if(!this._focused||this._isEmpty(this.textbox.value)){
return this.inherited(arguments);
}else{
var v=this.get("value");
if(!isNaN(v)&&this.rangeCheck(v,this.constraints)){
if(this.constraints.exponent!==false&&/\de[-+]?\d/i.test(this.textbox.value)){
return true;
}else{
return this.inherited(arguments);
}
}else{
return false;
}
}
}});
dojo.declare("dijit.form.NumberTextBox",[dijit.form.RangeBoundTextBox,dijit.form.NumberTextBoxMixin],{baseClass:"dijitTextBox dijitNumberTextBox"});
}
if(!dojo._hasResource["dijit.form.DropDownButton"]){
dojo._hasResource["dijit.form.DropDownButton"]=true;
dojo.provide("dijit.form.DropDownButton");
}
if(!dojo._hasResource["dijit.Calendar"]){
dojo._hasResource["dijit.Calendar"]=true;
dojo.provide("dijit.Calendar");
dojo.declare("dijit.Calendar",[dijit._Widget,dijit._Templated,dijit._CssStateMixin],{templateString:dojo.cache("dijit","templates/Calendar.html","<table cellspacing=\"0\" cellpadding=\"0\" class=\"dijitCalendarContainer\" role=\"grid\" dojoAttachEvent=\"onkeypress: _onKeyPress\" aria-labelledby=\"${id}_year\">\r\n\t<thead>\r\n\t\t<tr class=\"dijitReset dijitCalendarMonthContainer\" valign=\"top\">\r\n\t\t\t<th class='dijitReset dijitCalendarArrow' dojoAttachPoint=\"decrementMonth\">\r\n\t\t\t\t<img src=\"${_blankGif}\" alt=\"\" class=\"dijitCalendarIncrementControl dijitCalendarDecrease\" role=\"presentation\"/>\r\n\t\t\t\t<span dojoAttachPoint=\"decreaseArrowNode\" class=\"dijitA11ySideArrow\">-</span>\r\n\t\t\t</th>\r\n\t\t\t<th class='dijitReset' colspan=\"5\">\r\n\t\t\t\t<div dojoType=\"dijit.form.DropDownButton\" dojoAttachPoint=\"monthDropDownButton\"\r\n\t\t\t\t\tid=\"${id}_mddb\" tabIndex=\"-1\">\r\n\t\t\t\t</div>\r\n\t\t\t</th>\r\n\t\t\t<th class='dijitReset dijitCalendarArrow' dojoAttachPoint=\"incrementMonth\">\r\n\t\t\t\t<img src=\"${_blankGif}\" alt=\"\" class=\"dijitCalendarIncrementControl dijitCalendarIncrease\" role=\"presentation\"/>\r\n\t\t\t\t<span dojoAttachPoint=\"increaseArrowNode\" class=\"dijitA11ySideArrow\">+</span>\r\n\t\t\t</th>\r\n\t\t</tr>\r\n\t\t<tr>\r\n\t\t\t<th class=\"dijitReset dijitCalendarDayLabelTemplate\" role=\"columnheader\"><span class=\"dijitCalendarDayLabel\"></span></th>\r\n\t\t</tr>\r\n\t</thead>\r\n\t<tbody dojoAttachEvent=\"onclick: _onDayClick, onmouseover: _onDayMouseOver, onmouseout: _onDayMouseOut, onmousedown: _onDayMouseDown, onmouseup: _onDayMouseUp\" class=\"dijitReset dijitCalendarBodyContainer\">\r\n\t\t<tr class=\"dijitReset dijitCalendarWeekTemplate\" role=\"row\">\r\n\t\t\t<td class=\"dijitReset dijitCalendarDateTemplate\" role=\"gridcell\"><span class=\"dijitCalendarDateLabel\"></span></td>\r\n\t\t</tr>\r\n\t</tbody>\r\n\t<tfoot class=\"dijitReset dijitCalendarYearContainer\">\r\n\t\t<tr>\r\n\t\t\t<td class='dijitReset' valign=\"top\" colspan=\"7\">\r\n\t\t\t\t<h3 class=\"dijitCalendarYearLabel\">\r\n\t\t\t\t\t<span dojoAttachPoint=\"previousYearLabelNode\" class=\"dijitInline dijitCalendarPreviousYear\"></span>\r\n\t\t\t\t\t<span dojoAttachPoint=\"currentYearLabelNode\" class=\"dijitInline dijitCalendarSelectedYear\" id=\"${id}_year\"></span>\r\n\t\t\t\t\t<span dojoAttachPoint=\"nextYearLabelNode\" class=\"dijitInline dijitCalendarNextYear\"></span>\r\n\t\t\t\t</h3>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t</tfoot>\r\n</table>\r\n"),widgetsInTemplate:true,value:new Date(""),datePackage:"dojo.date",dayWidth:"narrow",tabIndex:"0",currentFocus:new Date(),baseClass:"dijitCalendar",cssStateNodes:{"decrementMonth":"dijitCalendarArrow","incrementMonth":"dijitCalendarArrow","previousYearLabelNode":"dijitCalendarPreviousYear","nextYearLabelNode":"dijitCalendarNextYear"},_isValidDate:function(_98a){
return _98a&&!isNaN(_98a)&&typeof _98a=="object"&&_98a.toString()!=this.constructor.prototype.value.toString();
},setValue:function(_98b){
dojo.deprecated("dijit.Calendar:setValue() is deprecated.  Use set('value', ...) instead.","","2.0");
this.set("value",_98b);
},_getValueAttr:function(){
var _98c=new this.dateClassObj(this.value);
_98c.setHours(0,0,0,0);
if(_98c.getDate()<this.value.getDate()){
_98c=this.dateFuncObj.add(_98c,"hour",1);
}
return _98c;
},_setValueAttr:function(_98d,_98e){
if(_98d){
_98d=new this.dateClassObj(_98d);
}
if(this._isValidDate(_98d)){
if(!this._isValidDate(this.value)||this.dateFuncObj.compare(_98d,this.value)){
_98d.setHours(1,0,0,0);
if(!this.isDisabledDate(_98d,this.lang)){
this._set("value",_98d);
this.set("currentFocus",_98d);
if(_98e||typeof _98e=="undefined"){
this.onChange(this.get("value"));
this.onValueSelected(this.get("value"));
}
}
}
}else{
this._set("value",null);
this.set("currentFocus",this.currentFocus);
}
},_setText:function(node,text){
while(node.firstChild){
node.removeChild(node.firstChild);
}
node.appendChild(dojo.doc.createTextNode(text));
},_populateGrid:function(){
var _98f=new this.dateClassObj(this.currentFocus);
_98f.setDate(1);
var _990=_98f.getDay(),_991=this.dateFuncObj.getDaysInMonth(_98f),_992=this.dateFuncObj.getDaysInMonth(this.dateFuncObj.add(_98f,"month",-1)),_993=new this.dateClassObj(),_994=dojo.cldr.supplemental.getFirstDayOfWeek(this.lang);
if(_994>_990){
_994-=7;
}
dojo.query(".dijitCalendarDateTemplate",this.domNode).forEach(function(_995,i){
i+=_994;
var date=new this.dateClassObj(_98f),_996,_997="dijitCalendar",adj=0;
if(i<_990){
_996=_992-_990+i+1;
adj=-1;
_997+="Previous";
}else{
if(i>=(_990+_991)){
_996=i-_990-_991+1;
adj=1;
_997+="Next";
}else{
_996=i-_990+1;
_997+="Current";
}
}
if(adj){
date=this.dateFuncObj.add(date,"month",adj);
}
date.setDate(_996);
if(!this.dateFuncObj.compare(date,_993,"date")){
_997="dijitCalendarCurrentDate "+_997;
}
if(this._isSelectedDate(date,this.lang)){
_997="dijitCalendarSelectedDate "+_997;
}
if(this.isDisabledDate(date,this.lang)){
_997="dijitCalendarDisabledDate "+_997;
}
var _998=this.getClassForDate(date,this.lang);
if(_998){
_997=_998+" "+_997;
}
_995.className=_997+"Month dijitCalendarDateTemplate";
_995.dijitDateValue=date.valueOf();
dojo.attr(_995,"dijitDateValue",date.valueOf());
var _999=dojo.query(".dijitCalendarDateLabel",_995)[0],text=date.getDateLocalized?date.getDateLocalized(this.lang):date.getDate();
this._setText(_999,text);
},this);
var _99a=this.dateLocaleModule.getNames("months","wide","standAlone",this.lang,_98f);
this.monthDropDownButton.dropDown.set("months",_99a);
this.monthDropDownButton.containerNode.innerHTML=(dojo.isIE==6?"":"<div class='dijitSpacer'>"+this.monthDropDownButton.dropDown.domNode.innerHTML+"</div>")+"<div class='dijitCalendarMonthLabel dijitCalendarCurrentMonthLabel'>"+_99a[_98f.getMonth()]+"</div>";
var y=_98f.getFullYear()-1;
var d=new this.dateClassObj();
dojo.forEach(["previous","current","next"],function(name){
d.setFullYear(y++);
this._setText(this[name+"YearLabelNode"],this.dateLocaleModule.format(d,{selector:"year",locale:this.lang}));
},this);
},goToToday:function(){
this.set("value",new this.dateClassObj());
},constructor:function(args){
var _99b=(args.datePackage&&(args.datePackage!="dojo.date"))?args.datePackage+".Date":"Date";
this.dateClassObj=dojo.getObject(_99b,false);
this.datePackage=args.datePackage||this.datePackage;
this.dateFuncObj=dojo.getObject(this.datePackage,false);
this.dateLocaleModule=dojo.getObject(this.datePackage+".locale",false);
},postMixInProperties:function(){
if(isNaN(this.value)){
delete this.value;
}
this.inherited(arguments);
},buildRendering:function(){
this.inherited(arguments);
dojo.setSelectable(this.domNode,false);
var _99c=dojo.hitch(this,function(_99d,n){
var _99e=dojo.query(_99d,this.domNode)[0];
for(var i=0;i<n;i++){
_99e.parentNode.appendChild(_99e.cloneNode(true));
}
});
_99c(".dijitCalendarDayLabelTemplate",6);
_99c(".dijitCalendarDateTemplate",6);
_99c(".dijitCalendarWeekTemplate",5);
var _99f=this.dateLocaleModule.getNames("days",this.dayWidth,"standAlone",this.lang);
var _9a0=dojo.cldr.supplemental.getFirstDayOfWeek(this.lang);
dojo.query(".dijitCalendarDayLabel",this.domNode).forEach(function(_9a1,i){
this._setText(_9a1,_99f[(i+_9a0)%7]);
},this);
var _9a2=new this.dateClassObj(this.currentFocus);
this.monthDropDownButton.dropDown=new dijit.Calendar._MonthDropDown({id:this.id+"_mdd",onChange:dojo.hitch(this,"_onMonthSelect")});
this.set("currentFocus",_9a2,false);
var _9a3=this;
var _9a4=function(_9a5,_9a6,adj){
_9a3._connects.push(dijit.typematic.addMouseListener(_9a3[_9a5],_9a3,function(_9a7){
if(_9a7>=0){
_9a3._adjustDisplay(_9a6,adj);
}
},0.8,500));
};
_9a4("incrementMonth","month",1);
_9a4("decrementMonth","month",-1);
_9a4("nextYearLabelNode","year",1);
_9a4("previousYearLabelNode","year",-1);
},_adjustDisplay:function(part,_9a8){
this._setCurrentFocusAttr(this.dateFuncObj.add(this.currentFocus,part,_9a8));
},_setCurrentFocusAttr:function(date,_9a9){
var _9aa=this.currentFocus,_9ab=_9aa?dojo.query("[dijitDateValue="+_9aa.valueOf()+"]",this.domNode)[0]:null;
date=new this.dateClassObj(date);
date.setHours(1,0,0,0);
this._set("currentFocus",date);
this._populateGrid();
var _9ac=dojo.query("[dijitDateValue="+date.valueOf()+"]",this.domNode)[0];
_9ac.setAttribute("tabIndex",this.tabIndex);
if(this._focused||_9a9){
_9ac.focus();
}
if(_9ab&&_9ab!=_9ac){
if(dojo.isWebKit){
_9ab.setAttribute("tabIndex","-1");
}else{
_9ab.removeAttribute("tabIndex");
}
}
},focus:function(){
this._setCurrentFocusAttr(this.currentFocus,true);
},_onMonthSelect:function(_9ad){
this.currentFocus=this.dateFuncObj.add(this.currentFocus,"month",_9ad-this.currentFocus.getMonth());
this._populateGrid();
},_onDayClick:function(evt){
dojo.stopEvent(evt);
for(var node=evt.target;node&&!node.dijitDateValue;node=node.parentNode){
}
if(node&&!dojo.hasClass(node,"dijitCalendarDisabledDate")){
this.set("value",node.dijitDateValue);
}
},_onDayMouseOver:function(evt){
var node=dojo.hasClass(evt.target,"dijitCalendarDateLabel")?evt.target.parentNode:evt.target;
if(node&&(node.dijitDateValue||node==this.previousYearLabelNode||node==this.nextYearLabelNode)){
dojo.addClass(node,"dijitCalendarHoveredDate");
this._currentNode=node;
}
},_onDayMouseOut:function(evt){
if(!this._currentNode){
return;
}
if(evt.relatedTarget&&evt.relatedTarget.parentNode==this._currentNode){
return;
}
var cls="dijitCalendarHoveredDate";
if(dojo.hasClass(this._currentNode,"dijitCalendarActiveDate")){
cls+=" dijitCalendarActiveDate";
}
dojo.removeClass(this._currentNode,cls);
this._currentNode=null;
},_onDayMouseDown:function(evt){
var node=evt.target.parentNode;
if(node&&node.dijitDateValue){
dojo.addClass(node,"dijitCalendarActiveDate");
this._currentNode=node;
}
},_onDayMouseUp:function(evt){
var node=evt.target.parentNode;
if(node&&node.dijitDateValue){
dojo.removeClass(node,"dijitCalendarActiveDate");
}
},handleKey:function(evt){
var dk=dojo.keys,_9ae=-1,_9af,_9b0=this.currentFocus;
switch(evt.keyCode){
case dk.RIGHT_ARROW:
_9ae=1;
case dk.LEFT_ARROW:
_9af="day";
if(!this.isLeftToRight()){
_9ae*=-1;
}
break;
case dk.DOWN_ARROW:
_9ae=1;
case dk.UP_ARROW:
_9af="week";
break;
case dk.PAGE_DOWN:
_9ae=1;
case dk.PAGE_UP:
_9af=evt.ctrlKey||evt.altKey?"year":"month";
break;
case dk.END:
_9b0=this.dateFuncObj.add(_9b0,"month",1);
_9af="day";
case dk.HOME:
_9b0=new this.dateClassObj(_9b0);
_9b0.setDate(1);
break;
case dk.ENTER:
case dk.SPACE:
this.set("value",this.currentFocus);
break;
default:
return true;
}
if(_9af){
_9b0=this.dateFuncObj.add(_9b0,_9af,_9ae);
}
this._setCurrentFocusAttr(_9b0);
return false;
},_onKeyPress:function(evt){
if(!this.handleKey(evt)){
dojo.stopEvent(evt);
}
},onValueSelected:function(date){
},onChange:function(date){
},_isSelectedDate:function(_9b1,_9b2){
return this._isValidDate(this.value)&&!this.dateFuncObj.compare(_9b1,this.value,"date");
},isDisabledDate:function(_9b3,_9b4){
},getClassForDate:function(_9b5,_9b6){
}});
dojo.declare("dijit.Calendar._MonthDropDown",[dijit._Widget,dijit._Templated],{months:[],templateString:"<div class='dijitCalendarMonthMenu dijitMenu' "+"dojoAttachEvent='onclick:_onClick,onmouseover:_onMenuHover,onmouseout:_onMenuHover'></div>",_setMonthsAttr:function(_9b7){
this.domNode.innerHTML=dojo.map(_9b7,function(_9b8,idx){
return _9b8?"<div class='dijitCalendarMonthLabel' month='"+idx+"'>"+_9b8+"</div>":"";
}).join("");
},_onClick:function(evt){
this.onChange(dojo.attr(evt.target,"month"));
},onChange:function(_9b9){
},_onMenuHover:function(evt){
dojo.toggleClass(evt.target,"dijitCalendarMonthLabelHover",evt.type=="mouseover");
}});
}
if(!dojo._hasResource["dijit.form._DateTimeTextBox"]){
dojo._hasResource["dijit.form._DateTimeTextBox"]=true;
dojo.provide("dijit.form._DateTimeTextBox");
new Date("X");
dojo.declare("dijit.form._DateTimeTextBox",[dijit.form.RangeBoundTextBox,dijit._HasDropDown],{templateString:dojo.cache("dijit.form","templates/DropDownBox.html","<div class=\"dijit dijitReset dijitInlineTable dijitLeft\"\r\n\tid=\"widget_${id}\"\r\n\trole=\"combobox\"\r\n\t><div class='dijitReset dijitRight dijitButtonNode dijitArrowButton dijitDownArrowButton dijitArrowButtonContainer'\r\n\t\tdojoAttachPoint=\"_buttonNode, _popupStateNode\" role=\"presentation\"\r\n\t\t><input class=\"dijitReset dijitInputField dijitArrowButtonInner\" value=\"&#9660; \" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t\t\t${_buttonInputDisabled}\r\n\t/></div\r\n\t><div class='dijitReset dijitValidationContainer'\r\n\t\t><input class=\"dijitReset dijitInputField dijitValidationIcon dijitValidationInner\" value=\"&#935; \" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t/></div\r\n\t><div class=\"dijitReset dijitInputField dijitInputContainer\"\r\n\t\t><input class='dijitReset dijitInputInner' ${!nameAttrSetting} type=\"text\" autocomplete=\"off\"\r\n\t\t\tdojoAttachPoint=\"textbox,focusNode\" role=\"textbox\" aria-haspopup=\"true\"\r\n\t/></div\r\n></div>\r\n"),hasDownArrow:true,openOnClick:true,regExpGen:dojo.date.locale.regexp,datePackage:"dojo.date",compare:function(val1,val2){
var _9ba=this._isInvalidDate(val1);
var _9bb=this._isInvalidDate(val2);
return _9ba?(_9bb?0:-1):(_9bb?1:dojo.date.compare(val1,val2,this._selector));
},forceWidth:true,format:function(_9bc,_9bd){
if(!_9bc){
return "";
}
return this.dateLocaleModule.format(_9bc,_9bd);
},"parse":function(_9be,_9bf){
return this.dateLocaleModule.parse(_9be,_9bf)||(this._isEmpty(_9be)?null:undefined);
},serialize:function(val,_9c0){
if(val.toGregorian){
val=val.toGregorian();
}
return dojo.date.stamp.toISOString(val,_9c0);
},dropDownDefaultValue:new Date(),value:new Date(""),_blankValue:null,popupClass:"",_selector:"",constructor:function(args){
var _9c1=args.datePackage?args.datePackage+".Date":"Date";
this.dateClassObj=dojo.getObject(_9c1,false);
this.value=new this.dateClassObj("");
this.datePackage=args.datePackage||this.datePackage;
this.dateLocaleModule=dojo.getObject(this.datePackage+".locale",false);
this.regExpGen=this.dateLocaleModule.regexp;
this._invalidDate=dijit.form._DateTimeTextBox.prototype.value.toString();
},buildRendering:function(){
this.inherited(arguments);
if(!this.hasDownArrow){
this._buttonNode.style.display="none";
}
if(this.openOnClick||!this.hasDownArrow){
this._buttonNode=this.domNode;
this.baseClass+=" dijitComboBoxOpenOnClick";
}
},_setConstraintsAttr:function(_9c2){
_9c2.selector=this._selector;
_9c2.fullYear=true;
var _9c3=dojo.date.stamp.fromISOString;
if(typeof _9c2.min=="string"){
_9c2.min=_9c3(_9c2.min);
}
if(typeof _9c2.max=="string"){
_9c2.max=_9c3(_9c2.max);
}
this.inherited(arguments);
},_isInvalidDate:function(_9c4){
return !_9c4||isNaN(_9c4)||typeof _9c4!="object"||_9c4.toString()==this._invalidDate;
},_setValueAttr:function(_9c5,_9c6,_9c7){
if(_9c5!==undefined){
if(typeof _9c5=="string"){
_9c5=dojo.date.stamp.fromISOString(_9c5);
}
if(this._isInvalidDate(_9c5)){
_9c5=null;
}
if(_9c5 instanceof Date&&!(this.dateClassObj instanceof Date)){
_9c5=new this.dateClassObj(_9c5);
}
}
this.inherited(arguments);
if(this.dropDown){
this.dropDown.set("value",_9c5,false);
}
},_set:function(attr,_9c8){
if(attr=="value"&&this.value instanceof Date&&this.compare(_9c8,this.value)==0){
return;
}
this.inherited(arguments);
},_setDropDownDefaultValueAttr:function(val){
if(this._isInvalidDate(val)){
val=new this.dateClassObj();
}
this.dropDownDefaultValue=val;
},openDropDown:function(_9c9){
if(this.dropDown){
this.dropDown.destroy();
}
var _9ca=dojo.getObject(this.popupClass,false),_9cb=this,_9cc=this.get("value");
this.dropDown=new _9ca({onChange:function(_9cd){
dijit.form._DateTimeTextBox.superclass._setValueAttr.call(_9cb,_9cd,true);
},id:this.id+"_popup",dir:_9cb.dir,lang:_9cb.lang,value:_9cc,currentFocus:!this._isInvalidDate(_9cc)?_9cc:this.dropDownDefaultValue,constraints:_9cb.constraints,filterString:_9cb.filterString,datePackage:_9cb.datePackage,isDisabledDate:function(date){
return !_9cb.rangeCheck(date,_9cb.constraints);
}});
this.inherited(arguments);
},_getDisplayedValueAttr:function(){
return this.textbox.value;
},_setDisplayedValueAttr:function(_9ce,_9cf){
this._setValueAttr(this.parse(_9ce,this.constraints),_9cf,_9ce);
}});
}
if(!dojo._hasResource["dijit.form.DateTextBox"]){
dojo._hasResource["dijit.form.DateTextBox"]=true;
dojo.provide("dijit.form.DateTextBox");
dojo.declare("dijit.form.DateTextBox",dijit.form._DateTimeTextBox,{baseClass:"dijitTextBox dijitComboBox dijitDateTextBox",popupClass:"dijit.Calendar",_selector:"date",value:new Date("")});
}
if(!dojo._hasResource["dijit._TimePicker"]){
dojo._hasResource["dijit._TimePicker"]=true;
dojo.provide("dijit._TimePicker");
dojo.declare("dijit._TimePicker",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dijit","templates/TimePicker.html","<div id=\"widget_${id}\" class=\"dijitMenu\"\r\n    ><div dojoAttachPoint=\"upArrow\" class=\"dijitButtonNode dijitUpArrowButton\" dojoAttachEvent=\"onmouseenter:_buttonMouse,onmouseleave:_buttonMouse\"\r\n\t\t><div class=\"dijitReset dijitInline dijitArrowButtonInner\" role=\"presentation\">&nbsp;</div\r\n\t\t><div class=\"dijitArrowButtonChar\">&#9650;</div></div\r\n    ><div dojoAttachPoint=\"timeMenu,focusNode\" dojoAttachEvent=\"onclick:_onOptionSelected,onmouseover,onmouseout\"></div\r\n    ><div dojoAttachPoint=\"downArrow\" class=\"dijitButtonNode dijitDownArrowButton\" dojoAttachEvent=\"onmouseenter:_buttonMouse,onmouseleave:_buttonMouse\"\r\n\t\t><div class=\"dijitReset dijitInline dijitArrowButtonInner\" role=\"presentation\">&nbsp;</div\r\n\t\t><div class=\"dijitArrowButtonChar\">&#9660;</div></div\r\n></div>\r\n"),baseClass:"dijitTimePicker",clickableIncrement:"T00:15:00",visibleIncrement:"T01:00:00",visibleRange:"T05:00:00",value:new Date(),_visibleIncrement:2,_clickableIncrement:1,_totalIncrements:10,constraints:{},serialize:dojo.date.stamp.toISOString,setValue:function(_9d0){
dojo.deprecated("dijit._TimePicker:setValue() is deprecated.  Use set('value', ...) instead.","","2.0");
this.set("value",_9d0);
},_setValueAttr:function(date){
this._set("value",date);
this._showText();
},_setFilterStringAttr:function(val){
this._set("filterString",val);
this._showText();
},isDisabledDate:function(_9d1,_9d2){
return false;
},_getFilteredNodes:function(_9d3,_9d4,_9d5,_9d6){
var _9d7=[],_9d8=_9d6?_9d6.date:this._refDate,n,i=_9d3,max=this._maxIncrement+Math.abs(i),chk=_9d5?-1:1,dec=_9d5?1:0,inc=1-dec;
do{
i=i-dec;
n=this._createOption(i);
if(n){
if((_9d5&&n.date>_9d8)||(!_9d5&&n.date<_9d8)){
break;
}
_9d7[_9d5?"unshift":"push"](n);
_9d8=n.date;
}
i=i+inc;
}while(_9d7.length<_9d4&&(i*chk)<max);
return _9d7;
},_showText:function(){
var _9d9=dojo.date.stamp.fromISOString;
this.timeMenu.innerHTML="";
this._clickableIncrementDate=_9d9(this.clickableIncrement);
this._visibleIncrementDate=_9d9(this.visibleIncrement);
this._visibleRangeDate=_9d9(this.visibleRange);
var _9da=function(date){
return date.getHours()*60*60+date.getMinutes()*60+date.getSeconds();
},_9db=_9da(this._clickableIncrementDate),_9dc=_9da(this._visibleIncrementDate),_9dd=_9da(this._visibleRangeDate),time=(this.value||this.currentFocus).getTime();
this._refDate=new Date(time-time%(_9dc*1000));
this._refDate.setFullYear(1970,0,1);
this._clickableIncrement=1;
this._totalIncrements=_9dd/_9db;
this._visibleIncrement=_9dc/_9db;
this._maxIncrement=(60*60*24)/_9db;
var _9de=this._getFilteredNodes(0,Math.min(this._totalIncrements>>1,10)-1),_9df=this._getFilteredNodes(0,Math.min(this._totalIncrements,10)-_9de.length,true,_9de[0]);
dojo.forEach(_9df.concat(_9de),function(n){
this.timeMenu.appendChild(n);
},this);
},constructor:function(){
this.constraints={};
},postMixInProperties:function(){
this.inherited(arguments);
this._setConstraintsAttr(this.constraints);
},_setConstraintsAttr:function(_9e0){
dojo.mixin(this,_9e0);
if(!_9e0.locale){
_9e0.locale=this.lang;
}
},postCreate:function(){
this.connect(this.timeMenu,dojo.isIE?"onmousewheel":"DOMMouseScroll","_mouseWheeled");
this._connects.push(dijit.typematic.addMouseListener(this.upArrow,this,"_onArrowUp",33,250));
this._connects.push(dijit.typematic.addMouseListener(this.downArrow,this,"_onArrowDown",33,250));
this.inherited(arguments);
},_buttonMouse:function(e){
dojo.toggleClass(e.currentTarget,e.currentTarget==this.upArrow?"dijitUpArrowHover":"dijitDownArrowHover",e.type=="mouseenter"||e.type=="mouseover");
},_createOption:function(_9e1){
var date=new Date(this._refDate);
var _9e2=this._clickableIncrementDate;
date.setHours(date.getHours()+_9e2.getHours()*_9e1,date.getMinutes()+_9e2.getMinutes()*_9e1,date.getSeconds()+_9e2.getSeconds()*_9e1);
if(this.constraints.selector=="time"){
date.setFullYear(1970,0,1);
}
var _9e3=dojo.date.locale.format(date,this.constraints);
if(this.filterString&&_9e3.toLowerCase().indexOf(this.filterString)!==0){
return null;
}
var div=dojo.create("div",{"class":this.baseClass+"Item"});
div.date=date;
div.index=_9e1;
dojo.create("div",{"class":this.baseClass+"ItemInner",innerHTML:_9e3},div);
if(_9e1%this._visibleIncrement<1&&_9e1%this._visibleIncrement>-1){
dojo.addClass(div,this.baseClass+"Marker");
}else{
if(!(_9e1%this._clickableIncrement)){
dojo.addClass(div,this.baseClass+"Tick");
}
}
if(this.isDisabledDate(date)){
dojo.addClass(div,this.baseClass+"ItemDisabled");
}
if(this.value&&!dojo.date.compare(this.value,date,this.constraints.selector)){
div.selected=true;
dojo.addClass(div,this.baseClass+"ItemSelected");
if(dojo.hasClass(div,this.baseClass+"Marker")){
dojo.addClass(div,this.baseClass+"MarkerSelected");
}else{
dojo.addClass(div,this.baseClass+"TickSelected");
}
this._highlightOption(div,true);
}
return div;
},_onOptionSelected:function(tgt){
var _9e4=tgt.target.date||tgt.target.parentNode.date;
if(!_9e4||this.isDisabledDate(_9e4)){
return;
}
this._highlighted_option=null;
this.set("value",_9e4);
this.onChange(_9e4);
},onChange:function(time){
},_highlightOption:function(node,_9e5){
if(!node){
return;
}
if(_9e5){
if(this._highlighted_option){
this._highlightOption(this._highlighted_option,false);
}
this._highlighted_option=node;
}else{
if(this._highlighted_option!==node){
return;
}else{
this._highlighted_option=null;
}
}
dojo.toggleClass(node,this.baseClass+"ItemHover",_9e5);
if(dojo.hasClass(node,this.baseClass+"Marker")){
dojo.toggleClass(node,this.baseClass+"MarkerHover",_9e5);
}else{
dojo.toggleClass(node,this.baseClass+"TickHover",_9e5);
}
},onmouseover:function(e){
this._keyboardSelected=null;
var tgr=(e.target.parentNode===this.timeMenu)?e.target:e.target.parentNode;
if(!dojo.hasClass(tgr,this.baseClass+"Item")){
return;
}
this._highlightOption(tgr,true);
},onmouseout:function(e){
this._keyboardSelected=null;
var tgr=(e.target.parentNode===this.timeMenu)?e.target:e.target.parentNode;
this._highlightOption(tgr,false);
},_mouseWheeled:function(e){
this._keyboardSelected=null;
dojo.stopEvent(e);
var _9e6=(dojo.isIE?e.wheelDelta:-e.detail);
this[(_9e6>0?"_onArrowUp":"_onArrowDown")]();
},_onArrowUp:function(_9e7){
if(typeof _9e7=="number"&&_9e7==-1){
return;
}
if(!this.timeMenu.childNodes.length){
return;
}
var _9e8=this.timeMenu.childNodes[0].index;
var divs=this._getFilteredNodes(_9e8,1,true,this.timeMenu.childNodes[0]);
if(divs.length){
this.timeMenu.removeChild(this.timeMenu.childNodes[this.timeMenu.childNodes.length-1]);
this.timeMenu.insertBefore(divs[0],this.timeMenu.childNodes[0]);
}
},_onArrowDown:function(_9e9){
if(typeof _9e9=="number"&&_9e9==-1){
return;
}
if(!this.timeMenu.childNodes.length){
return;
}
var _9ea=this.timeMenu.childNodes[this.timeMenu.childNodes.length-1].index+1;
var divs=this._getFilteredNodes(_9ea,1,false,this.timeMenu.childNodes[this.timeMenu.childNodes.length-1]);
if(divs.length){
this.timeMenu.removeChild(this.timeMenu.childNodes[0]);
this.timeMenu.appendChild(divs[0]);
}
},handleKey:function(e){
var dk=dojo.keys;
if(e.charOrCode==dk.DOWN_ARROW||e.charOrCode==dk.UP_ARROW){
dojo.stopEvent(e);
if(this._highlighted_option&&!this._highlighted_option.parentNode){
this._highlighted_option=null;
}
var _9eb=this.timeMenu,tgt=this._highlighted_option||dojo.query("."+this.baseClass+"ItemSelected",_9eb)[0];
if(!tgt){
tgt=_9eb.childNodes[0];
}else{
if(_9eb.childNodes.length){
if(e.charOrCode==dk.DOWN_ARROW&&!tgt.nextSibling){
this._onArrowDown();
}else{
if(e.charOrCode==dk.UP_ARROW&&!tgt.previousSibling){
this._onArrowUp();
}
}
if(e.charOrCode==dk.DOWN_ARROW){
tgt=tgt.nextSibling;
}else{
tgt=tgt.previousSibling;
}
}
}
this._highlightOption(tgt,true);
this._keyboardSelected=tgt;
return false;
}else{
if(e.charOrCode==dk.ENTER||e.charOrCode===dk.TAB){
if(!this._keyboardSelected&&e.charOrCode===dk.TAB){
return true;
}
if(this._highlighted_option){
this._onOptionSelected({target:this._highlighted_option});
}
return e.charOrCode===dk.TAB;
}
}
}});
}
if(!dojo._hasResource["dijit.form.TimeTextBox"]){
dojo._hasResource["dijit.form.TimeTextBox"]=true;
dojo.provide("dijit.form.TimeTextBox");
dojo.declare("dijit.form.TimeTextBox",dijit.form._DateTimeTextBox,{baseClass:"dijitTextBox dijitComboBox dijitTimeTextBox",popupClass:"dijit._TimePicker",_selector:"time",value:new Date(""),_onKey:function(evt){
if(this.disabled||this.readOnly){
return;
}
this.inherited(arguments);
switch(evt.keyCode){
case dojo.keys.ENTER:
case dojo.keys.TAB:
case dojo.keys.ESCAPE:
case dojo.keys.DOWN_ARROW:
case dojo.keys.UP_ARROW:
break;
default:
setTimeout(dojo.hitch(this,function(){
var val=this.get("displayedValue");
this.filterString=(val&&!this.parse(val,this.constraints))?val.toLowerCase():"";
if(this._opened){
this.closeDropDown();
}
this.openDropDown();
}),0);
}
}});
}
if(!dojo._hasResource["dojo.cookie"]){
dojo._hasResource["dojo.cookie"]=true;
dojo.provide("dojo.cookie");
dojo.cookie=function(name,_9ec,_9ed){
var c=document.cookie;
if(arguments.length==1){
var _9ee=c.match(new RegExp("(?:^|; )"+dojo.regexp.escapeString(name)+"=([^;]*)"));
return _9ee?decodeURIComponent(_9ee[1]):undefined;
}else{
_9ed=_9ed||{};
var exp=_9ed.expires;
if(typeof exp=="number"){
var d=new Date();
d.setTime(d.getTime()+exp*24*60*60*1000);
exp=_9ed.expires=d;
}
if(exp&&exp.toUTCString){
_9ed.expires=exp.toUTCString();
}
_9ec=encodeURIComponent(_9ec);
var _9ef=name+"="+_9ec,_9f0;
for(_9f0 in _9ed){
_9ef+="; "+_9f0;
var _9f1=_9ed[_9f0];
if(_9f1!==true){
_9ef+="="+_9f1;
}
}
document.cookie=_9ef;
}
};
dojo.cookie.isSupported=function(){
if(!("cookieEnabled" in navigator)){
this("__djCookieTest__","CookiesAllowed");
navigator.cookieEnabled=this("__djCookieTest__")=="CookiesAllowed";
if(navigator.cookieEnabled){
this("__djCookieTest__","",{expires:-1});
}
}
return navigator.cookieEnabled;
};
}
if(!dojo._hasResource["dijit.layout.StackController"]){
dojo._hasResource["dijit.layout.StackController"]=true;
dojo.provide("dijit.layout.StackController");
dojo.declare("dijit.layout.StackController",[dijit._Widget,dijit._Templated,dijit._Container],{templateString:"<span role='tablist' dojoAttachEvent='onkeypress' class='dijitStackController'></span>",containerId:"",buttonWidget:"dijit.layout._StackButton",constructor:function(){
this.pane2button={};
this.pane2connects={};
this.pane2watches={};
},buildRendering:function(){
this.inherited(arguments);
dijit.setWaiRole(this.domNode,"tablist");
},postCreate:function(){
this.inherited(arguments);
this.subscribe(this.containerId+"-startup","onStartup");
this.subscribe(this.containerId+"-addChild","onAddChild");
this.subscribe(this.containerId+"-removeChild","onRemoveChild");
this.subscribe(this.containerId+"-selectChild","onSelectChild");
this.subscribe(this.containerId+"-containerKeyPress","onContainerKeyPress");
},onStartup:function(info){
dojo.forEach(info.children,this.onAddChild,this);
if(info.selected){
this.onSelectChild(info.selected);
}
},destroy:function(){
for(var pane in this.pane2button){
this.onRemoveChild(dijit.byId(pane));
}
this.inherited(arguments);
},onAddChild:function(page,_9f2){
var cls=dojo.getObject(this.buttonWidget);
var _9f3=new cls({id:this.id+"_"+page.id,label:page.title,dir:page.dir,lang:page.lang,showLabel:page.showTitle,iconClass:page.iconClass,closeButton:page.closable,title:page.tooltip});
dijit.setWaiState(_9f3.focusNode,"selected","false");
var _9f4=["title","showTitle","iconClass","closable","tooltip"],_9f5=["label","showLabel","iconClass","closeButton","title"];
this.pane2watches[page.id]=dojo.map(_9f4,function(_9f6,idx){
return page.watch(_9f6,function(name,_9f7,_9f8){
_9f3.set(_9f5[idx],_9f8);
});
});
this.pane2connects[page.id]=[this.connect(_9f3,"onClick",dojo.hitch(this,"onButtonClick",page)),this.connect(_9f3,"onClickCloseButton",dojo.hitch(this,"onCloseButtonClick",page))];
this.addChild(_9f3,_9f2);
this.pane2button[page.id]=_9f3;
page.controlButton=_9f3;
if(!this._currentChild){
_9f3.focusNode.setAttribute("tabIndex","0");
dijit.setWaiState(_9f3.focusNode,"selected","true");
this._currentChild=page;
}
if(!this.isLeftToRight()&&dojo.isIE&&this._rectifyRtlTabList){
this._rectifyRtlTabList();
}
},onRemoveChild:function(page){
if(this._currentChild===page){
this._currentChild=null;
}
dojo.forEach(this.pane2connects[page.id],dojo.hitch(this,"disconnect"));
delete this.pane2connects[page.id];
dojo.forEach(this.pane2watches[page.id],function(w){
w.unwatch();
});
delete this.pane2watches[page.id];
var _9f9=this.pane2button[page.id];
if(_9f9){
this.removeChild(_9f9);
delete this.pane2button[page.id];
_9f9.destroy();
}
delete page.controlButton;
},onSelectChild:function(page){
if(!page){
return;
}
if(this._currentChild){
var _9fa=this.pane2button[this._currentChild.id];
_9fa.set("checked",false);
dijit.setWaiState(_9fa.focusNode,"selected","false");
_9fa.focusNode.setAttribute("tabIndex","-1");
}
var _9fb=this.pane2button[page.id];
_9fb.set("checked",true);
dijit.setWaiState(_9fb.focusNode,"selected","true");
this._currentChild=page;
_9fb.focusNode.setAttribute("tabIndex","0");
var _9fc=dijit.byId(this.containerId);
dijit.setWaiState(_9fc.containerNode,"labelledby",_9fb.id);
},onButtonClick:function(page){
var _9fd=dijit.byId(this.containerId);
_9fd.selectChild(page);
},onCloseButtonClick:function(page){
var _9fe=dijit.byId(this.containerId);
_9fe.closeChild(page);
if(this._currentChild){
var b=this.pane2button[this._currentChild.id];
if(b){
dijit.focus(b.focusNode||b.domNode);
}
}
},adjacent:function(_9ff){
if(!this.isLeftToRight()&&(!this.tabPosition||/top|bottom/.test(this.tabPosition))){
_9ff=!_9ff;
}
var _a00=this.getChildren();
var _a01=dojo.indexOf(_a00,this.pane2button[this._currentChild.id]);
var _a02=_9ff?1:_a00.length-1;
return _a00[(_a01+_a02)%_a00.length];
},onkeypress:function(e){
if(this.disabled||e.altKey){
return;
}
var _a03=null;
if(e.ctrlKey||!e._djpage){
var k=dojo.keys;
switch(e.charOrCode){
case k.LEFT_ARROW:
case k.UP_ARROW:
if(!e._djpage){
_a03=false;
}
break;
case k.PAGE_UP:
if(e.ctrlKey){
_a03=false;
}
break;
case k.RIGHT_ARROW:
case k.DOWN_ARROW:
if(!e._djpage){
_a03=true;
}
break;
case k.PAGE_DOWN:
if(e.ctrlKey){
_a03=true;
}
break;
case k.HOME:
case k.END:
var _a04=this.getChildren();
if(_a04&&_a04.length){
_a04[e.charOrCode==k.HOME?0:_a04.length-1].onClick();
}
dojo.stopEvent(e);
break;
case k.DELETE:
if(this._currentChild.closable){
this.onCloseButtonClick(this._currentChild);
}
dojo.stopEvent(e);
break;
default:
if(e.ctrlKey){
if(e.charOrCode===k.TAB){
this.adjacent(!e.shiftKey).onClick();
dojo.stopEvent(e);
}else{
if(e.charOrCode=="w"){
if(this._currentChild.closable){
this.onCloseButtonClick(this._currentChild);
}
dojo.stopEvent(e);
}
}
}
}
if(_a03!==null){
this.adjacent(_a03).onClick();
dojo.stopEvent(e);
}
}
},onContainerKeyPress:function(info){
info.e._djpage=info.page;
this.onkeypress(info.e);
}});
dojo.declare("dijit.layout._StackButton",dijit.form.ToggleButton,{tabIndex:"-1",buildRendering:function(evt){
this.inherited(arguments);
dijit.setWaiRole((this.focusNode||this.domNode),"tab");
},onClick:function(evt){
dijit.focus(this.focusNode);
},onClickCloseButton:function(evt){
evt.stopPropagation();
}});
}
if(!dojo._hasResource["dijit.layout.StackContainer"]){
dojo._hasResource["dijit.layout.StackContainer"]=true;
dojo.provide("dijit.layout.StackContainer");
dojo.declare("dijit.layout.StackContainer",dijit.layout._LayoutWidget,{doLayout:true,persist:false,baseClass:"dijitStackContainer",buildRendering:function(){
this.inherited(arguments);
dojo.addClass(this.domNode,"dijitLayoutContainer");
dijit.setWaiRole(this.containerNode,"tabpanel");
},postCreate:function(){
this.inherited(arguments);
this.connect(this.domNode,"onkeypress",this._onKeyPress);
},startup:function(){
if(this._started){
return;
}
var _a05=this.getChildren();
dojo.forEach(_a05,this._setupChild,this);
if(this.persist){
this.selectedChildWidget=dijit.byId(dojo.cookie(this.id+"_selectedChild"));
}else{
dojo.some(_a05,function(_a06){
if(_a06.selected){
this.selectedChildWidget=_a06;
}
return _a06.selected;
},this);
}
var _a07=this.selectedChildWidget;
if(!_a07&&_a05[0]){
_a07=this.selectedChildWidget=_a05[0];
_a07.selected=true;
}
dojo.publish(this.id+"-startup",[{children:_a05,selected:_a07}]);
this.inherited(arguments);
},resize:function(){
if(!this._hasBeenShown){
this._hasBeenShown=true;
var _a08=this.selectedChildWidget;
if(_a08){
this._showChild(_a08);
}
}
this.inherited(arguments);
},_setupChild:function(_a09){
this.inherited(arguments);
dojo.replaceClass(_a09.domNode,"dijitHidden","dijitVisible");
_a09.domNode.title="";
},addChild:function(_a0a,_a0b){
this.inherited(arguments);
if(this._started){
dojo.publish(this.id+"-addChild",[_a0a,_a0b]);
this.layout();
if(!this.selectedChildWidget){
this.selectChild(_a0a);
}
}
},removeChild:function(page){
this.inherited(arguments);
if(this._started){
dojo.publish(this.id+"-removeChild",[page]);
}
if(this._beingDestroyed){
return;
}
if(this.selectedChildWidget===page){
this.selectedChildWidget=undefined;
if(this._started){
var _a0c=this.getChildren();
if(_a0c.length){
this.selectChild(_a0c[0]);
}
}
}
if(this._started){
this.layout();
}
},selectChild:function(page,_a0d){
page=dijit.byId(page);
if(this.selectedChildWidget!=page){
var d=this._transition(page,this.selectedChildWidget,_a0d);
this._set("selectedChildWidget",page);
dojo.publish(this.id+"-selectChild",[page]);
if(this.persist){
dojo.cookie(this.id+"_selectedChild",this.selectedChildWidget.id);
}
}
return d;
},_transition:function(_a0e,_a0f,_a10){
if(_a0f){
this._hideChild(_a0f);
}
var d=this._showChild(_a0e);
if(_a0e.resize){
if(this.doLayout){
_a0e.resize(this._containerContentBox||this._contentBox);
}else{
_a0e.resize();
}
}
return d;
},_adjacent:function(_a11){
var _a12=this.getChildren();
var _a13=dojo.indexOf(_a12,this.selectedChildWidget);
_a13+=_a11?1:_a12.length-1;
return _a12[_a13%_a12.length];
},forward:function(){
return this.selectChild(this._adjacent(true),true);
},back:function(){
return this.selectChild(this._adjacent(false),true);
},_onKeyPress:function(e){
dojo.publish(this.id+"-containerKeyPress",[{e:e,page:this}]);
},layout:function(){
if(this.doLayout&&this.selectedChildWidget&&this.selectedChildWidget.resize){
this.selectedChildWidget.resize(this._containerContentBox||this._contentBox);
}
},_showChild:function(page){
var _a14=this.getChildren();
page.isFirstChild=(page==_a14[0]);
page.isLastChild=(page==_a14[_a14.length-1]);
page._set("selected",true);
dojo.replaceClass(page.domNode,"dijitVisible","dijitHidden");
return page._onShow()||true;
},_hideChild:function(page){
page._set("selected",false);
dojo.replaceClass(page.domNode,"dijitHidden","dijitVisible");
page.onHide();
},closeChild:function(page){
var _a15=page.onClose(this,page);
if(_a15){
this.removeChild(page);
page.destroyRecursive();
}
},destroyDescendants:function(_a16){
dojo.forEach(this.getChildren(),function(_a17){
this.removeChild(_a17);
_a17.destroyRecursive(_a16);
},this);
}});
dojo.extend(dijit._Widget,{selected:false,closable:false,iconClass:"",showTitle:true});
}
if(!dojo._hasResource["dijit.layout.AccordionPane"]){
dojo._hasResource["dijit.layout.AccordionPane"]=true;
dojo.provide("dijit.layout.AccordionPane");
dojo.declare("dijit.layout.AccordionPane",dijit.layout.ContentPane,{constructor:function(){
dojo.deprecated("dijit.layout.AccordionPane deprecated, use ContentPane instead","","2.0");
},onSelected:function(){
}});
}
if(!dojo._hasResource["dijit.layout.AccordionContainer"]){
dojo._hasResource["dijit.layout.AccordionContainer"]=true;
dojo.provide("dijit.layout.AccordionContainer");
dojo.declare("dijit.layout.AccordionContainer",dijit.layout.StackContainer,{duration:dijit.defaultDuration,buttonWidget:"dijit.layout._AccordionButton",baseClass:"dijitAccordionContainer",buildRendering:function(){
this.inherited(arguments);
this.domNode.style.overflow="hidden";
dijit.setWaiRole(this.domNode,"tablist");
},startup:function(){
if(this._started){
return;
}
this.inherited(arguments);
if(this.selectedChildWidget){
var _a18=this.selectedChildWidget.containerNode.style;
_a18.display="";
_a18.overflow="auto";
this.selectedChildWidget._wrapperWidget.set("selected",true);
}
},layout:function(){
var _a19=this.selectedChildWidget;
if(!_a19){
return;
}
var _a1a=_a19._wrapperWidget.domNode,_a1b=dojo._getMarginExtents(_a1a),_a1c=dojo._getPadBorderExtents(_a1a),_a1d=_a19._wrapperWidget.containerNode,_a1e=dojo._getMarginExtents(_a1d),_a1f=dojo._getPadBorderExtents(_a1d),_a20=this._contentBox;
var _a21=0;
dojo.forEach(this.getChildren(),function(_a22){
if(_a22!=_a19){
_a21+=dojo._getMarginSize(_a22._wrapperWidget.domNode).h;
}
});
this._verticalSpace=_a20.h-_a21-_a1b.h-_a1c.h-_a1e.h-_a1f.h-_a19._buttonWidget.getTitleHeight();
this._containerContentBox={h:this._verticalSpace,w:this._contentBox.w-_a1b.w-_a1c.w-_a1e.w-_a1f.w};
if(_a19){
_a19.resize(this._containerContentBox);
}
},_setupChild:function(_a23){
_a23._wrapperWidget=new dijit.layout._AccordionInnerContainer({contentWidget:_a23,buttonWidget:this.buttonWidget,id:_a23.id+"_wrapper",dir:_a23.dir,lang:_a23.lang,parent:this});
this.inherited(arguments);
},addChild:function(_a24,_a25){
if(this._started){
dojo.place(_a24.domNode,this.containerNode,_a25);
if(!_a24._started){
_a24.startup();
}
this._setupChild(_a24);
dojo.publish(this.id+"-addChild",[_a24,_a25]);
this.layout();
if(!this.selectedChildWidget){
this.selectChild(_a24);
}
}else{
this.inherited(arguments);
}
},removeChild:function(_a26){
if(_a26._wrapperWidget){
dojo.place(_a26.domNode,_a26._wrapperWidget.domNode,"after");
_a26._wrapperWidget.destroy();
delete _a26._wrapperWidget;
}
dojo.removeClass(_a26.domNode,"dijitHidden");
this.inherited(arguments);
},getChildren:function(){
return dojo.map(this.inherited(arguments),function(_a27){
return _a27.declaredClass=="dijit.layout._AccordionInnerContainer"?_a27.contentWidget:_a27;
},this);
},destroy:function(){
if(this._animation){
this._animation.stop();
}
dojo.forEach(this.getChildren(),function(_a28){
if(_a28._wrapperWidget){
_a28._wrapperWidget.destroy();
}else{
_a28.destroyRecursive();
}
});
this.inherited(arguments);
},_showChild:function(_a29){
_a29._wrapperWidget.containerNode.style.display="block";
return this.inherited(arguments);
},_hideChild:function(_a2a){
_a2a._wrapperWidget.containerNode.style.display="none";
this.inherited(arguments);
},_transition:function(_a2b,_a2c,_a2d){
if(dojo.isIE<8){
_a2d=false;
}
if(this._animation){
this._animation.stop(true);
delete this._animation;
}
var self=this;
if(_a2b){
_a2b._wrapperWidget.set("selected",true);
var d=this._showChild(_a2b);
if(this.doLayout&&_a2b.resize){
_a2b.resize(this._containerContentBox);
}
}
if(_a2c){
_a2c._wrapperWidget.set("selected",false);
if(!_a2d){
this._hideChild(_a2c);
}
}
if(_a2d){
var _a2e=_a2b._wrapperWidget.containerNode,_a2f=_a2c._wrapperWidget.containerNode;
var _a30=_a2b._wrapperWidget.containerNode,_a31=dojo._getMarginExtents(_a30),_a32=dojo._getPadBorderExtents(_a30),_a33=_a31.h+_a32.h;
_a2f.style.height=(self._verticalSpace-_a33)+"px";
this._animation=new dojo.Animation({node:_a2e,duration:this.duration,curve:[1,this._verticalSpace-_a33-1],onAnimate:function(_a34){
_a34=Math.floor(_a34);
_a2e.style.height=_a34+"px";
_a2f.style.height=(self._verticalSpace-_a33-_a34)+"px";
},onEnd:function(){
delete self._animation;
_a2e.style.height="auto";
_a2c._wrapperWidget.containerNode.style.display="none";
_a2f.style.height="auto";
self._hideChild(_a2c);
}});
this._animation.onStop=this._animation.onEnd;
this._animation.play();
}
return d;
},_onKeyPress:function(e,_a35){
if(this.disabled||e.altKey||!(_a35||e.ctrlKey)){
return;
}
var k=dojo.keys,c=e.charOrCode;
if((_a35&&(c==k.LEFT_ARROW||c==k.UP_ARROW))||(e.ctrlKey&&c==k.PAGE_UP)){
this._adjacent(false)._buttonWidget._onTitleClick();
dojo.stopEvent(e);
}else{
if((_a35&&(c==k.RIGHT_ARROW||c==k.DOWN_ARROW))||(e.ctrlKey&&(c==k.PAGE_DOWN||c==k.TAB))){
this._adjacent(true)._buttonWidget._onTitleClick();
dojo.stopEvent(e);
}
}
}});
dojo.declare("dijit.layout._AccordionInnerContainer",[dijit._Widget,dijit._CssStateMixin],{baseClass:"dijitAccordionInnerContainer",isContainer:true,isLayoutContainer:true,buildRendering:function(){
this.domNode=dojo.place("<div class='"+this.baseClass+"'>",this.contentWidget.domNode,"after");
var _a36=this.contentWidget,cls=dojo.getObject(this.buttonWidget);
this.button=_a36._buttonWidget=(new cls({contentWidget:_a36,label:_a36.title,title:_a36.tooltip,dir:_a36.dir,lang:_a36.lang,iconClass:_a36.iconClass,id:_a36.id+"_button",parent:this.parent})).placeAt(this.domNode);
this.containerNode=dojo.place("<div class='dijitAccordionChildWrapper' style='display:none'>",this.domNode);
dojo.place(this.contentWidget.domNode,this.containerNode);
},postCreate:function(){
this.inherited(arguments);
var _a37=this.button;
this._contentWidgetWatches=[this.contentWidget.watch("title",dojo.hitch(this,function(name,_a38,_a39){
_a37.set("label",_a39);
})),this.contentWidget.watch("tooltip",dojo.hitch(this,function(name,_a3a,_a3b){
_a37.set("title",_a3b);
})),this.contentWidget.watch("iconClass",dojo.hitch(this,function(name,_a3c,_a3d){
_a37.set("iconClass",_a3d);
}))];
},_setSelectedAttr:function(_a3e){
this._set("selected",_a3e);
this.button.set("selected",_a3e);
if(_a3e){
var cw=this.contentWidget;
if(cw.onSelected){
cw.onSelected();
}
}
},startup:function(){
this.contentWidget.startup();
},destroy:function(){
this.button.destroyRecursive();
dojo.forEach(this._contentWidgetWatches||[],function(w){
w.unwatch();
});
delete this.contentWidget._buttonWidget;
delete this.contentWidget._wrapperWidget;
this.inherited(arguments);
},destroyDescendants:function(){
this.contentWidget.destroyRecursive();
}});
dojo.declare("dijit.layout._AccordionButton",[dijit._Widget,dijit._Templated,dijit._CssStateMixin],{templateString:dojo.cache("dijit.layout","templates/AccordionButton.html","<div dojoAttachEvent='onclick:_onTitleClick' class='dijitAccordionTitle'>\r\n\t<div dojoAttachPoint='titleNode,focusNode' dojoAttachEvent='onkeypress:_onTitleKeyPress'\r\n\t\t\tclass='dijitAccordionTitleFocus' role=\"tab\" aria-expanded=\"false\"\r\n\t\t><span class='dijitInline dijitAccordionArrow' role=\"presentation\"></span\r\n\t\t><span class='arrowTextUp' role=\"presentation\">+</span\r\n\t\t><span class='arrowTextDown' role=\"presentation\">-</span\r\n\t\t><img src=\"${_blankGif}\" alt=\"\" class=\"dijitIcon\" dojoAttachPoint='iconNode' style=\"vertical-align: middle\" role=\"presentation\"/>\r\n\t\t<span role=\"presentation\" dojoAttachPoint='titleTextNode' class='dijitAccordionText'></span>\r\n\t</div>\r\n</div>\r\n"),attributeMap:dojo.mixin(dojo.clone(dijit.layout.ContentPane.prototype.attributeMap),{label:{node:"titleTextNode",type:"innerHTML"},title:{node:"titleTextNode",type:"attribute",attribute:"title"},iconClass:{node:"iconNode",type:"class"}}),baseClass:"dijitAccordionTitle",getParent:function(){
return this.parent;
},buildRendering:function(){
this.inherited(arguments);
var _a3f=this.id.replace(" ","_");
dojo.attr(this.titleTextNode,"id",_a3f+"_title");
dijit.setWaiState(this.focusNode,"labelledby",dojo.attr(this.titleTextNode,"id"));
dojo.setSelectable(this.domNode,false);
},getTitleHeight:function(){
return dojo._getMarginSize(this.domNode).h;
},_onTitleClick:function(){
var _a40=this.getParent();
_a40.selectChild(this.contentWidget,true);
dijit.focus(this.focusNode);
},_onTitleKeyPress:function(evt){
return this.getParent()._onKeyPress(evt,this.contentWidget);
},_setSelectedAttr:function(_a41){
this._set("selected",_a41);
dijit.setWaiState(this.focusNode,"expanded",_a41);
dijit.setWaiState(this.focusNode,"selected",_a41);
this.focusNode.setAttribute("tabIndex",_a41?"0":"-1");
}});
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.filter.FilterBuilder"]){
dojo._hasResource["dojox.grid.enhanced.plugins.filter.FilterBuilder"]=true;
dojo.provide("dojox.grid.enhanced.plugins.filter.FilterBuilder");
(function(){
var fns=dojox.grid.enhanced.plugins.filter,bdr=function(_a42){
return dojo.partial(function(cls,_a43){
return new fns[cls](_a43);
},_a42);
},_a44=function(_a45){
return dojo.partial(function(cls,_a46){
return new fns.LogicNOT(new fns[cls](_a46));
},_a45);
};
dojo.declare("dojox.grid.enhanced.plugins.filter.FilterBuilder",null,{buildExpression:function(def){
if("op" in def){
return this.supportedOps[def.op.toLowerCase()](dojo.map(def.data,this.buildExpression,this));
}else{
var args=dojo.mixin(this.defaultArgs[def.datatype],def.args||{});
return new this.supportedTypes[def.datatype](def.data,def.isColumn,args);
}
},supportedOps:{"equalto":bdr("EqualTo"),"lessthan":bdr("LessThan"),"lessthanorequalto":bdr("LessThanOrEqualTo"),"largerthan":bdr("LargerThan"),"largerthanorequalto":bdr("LargerThanOrEqualTo"),"contains":bdr("Contains"),"startswith":bdr("StartsWith"),"endswith":bdr("EndsWith"),"notequalto":_a44("EqualTo"),"notcontains":_a44("Contains"),"notstartswith":_a44("StartsWith"),"notendswith":_a44("EndsWith"),"isempty":bdr("IsEmpty"),"range":function(_a47){
return new fns.LogicALL(new fns.LargerThanOrEqualTo(_a47.slice(0,2)),new fns.LessThanOrEqualTo(_a47[0],_a47[2]));
},"logicany":bdr("LogicANY"),"logicall":bdr("LogicALL")},supportedTypes:{"number":fns.NumberExpr,"string":fns.StringExpr,"boolean":fns.BooleanExpr,"date":fns.DateExpr,"time":fns.TimeExpr},defaultArgs:{"boolean":{"falseValue":"false","convert":function(_a48,args){
var _a49=args.falseValue;
var _a4a=args.trueValue;
if(dojo.isString(_a48)){
if(_a4a&&_a48.toLowerCase()==_a4a){
return true;
}
if(_a49&&_a48.toLowerCase()==_a49){
return false;
}
}
return !!_a48;
}}}});
})();
}
if(!dojo._hasResource["dijit.form._Spinner"]){
dojo._hasResource["dijit.form._Spinner"]=true;
dojo.provide("dijit.form._Spinner");
dojo.declare("dijit.form._Spinner",dijit.form.RangeBoundTextBox,{defaultTimeout:500,minimumTimeout:10,timeoutChangeRate:0.9,smallDelta:1,largeDelta:10,templateString:dojo.cache("dijit.form","templates/Spinner.html","<div class=\"dijit dijitReset dijitInlineTable dijitLeft\"\r\n\tid=\"widget_${id}\" role=\"presentation\"\r\n\t><div class=\"dijitReset dijitButtonNode dijitSpinnerButtonContainer\"\r\n\t\t><input class=\"dijitReset dijitInputField dijitSpinnerButtonInner\" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t\t/><div class=\"dijitReset dijitLeft dijitButtonNode dijitArrowButton dijitUpArrowButton\"\r\n\t\t\tdojoAttachPoint=\"upArrowNode\"\r\n\t\t\t><div class=\"dijitArrowButtonInner\"\r\n\t\t\t\t><input class=\"dijitReset dijitInputField\" value=\"&#9650;\" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t\t\t\t\t${_buttonInputDisabled}\r\n\t\t\t/></div\r\n\t\t></div\r\n\t\t><div class=\"dijitReset dijitLeft dijitButtonNode dijitArrowButton dijitDownArrowButton\"\r\n\t\t\tdojoAttachPoint=\"downArrowNode\"\r\n\t\t\t><div class=\"dijitArrowButtonInner\"\r\n\t\t\t\t><input class=\"dijitReset dijitInputField\" value=\"&#9660;\" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t\t\t\t\t${_buttonInputDisabled}\r\n\t\t\t/></div\r\n\t\t></div\r\n\t></div\r\n\t><div class='dijitReset dijitValidationContainer'\r\n\t\t><input class=\"dijitReset dijitInputField dijitValidationIcon dijitValidationInner\" value=\"&#935;\" type=\"text\" tabIndex=\"-1\" readonly=\"readonly\" role=\"presentation\"\r\n\t/></div\r\n\t><div class=\"dijitReset dijitInputField dijitInputContainer\"\r\n\t\t><input class='dijitReset dijitInputInner' dojoAttachPoint=\"textbox,focusNode\" type=\"${type}\" dojoAttachEvent=\"onkeypress:_onKeyPress\"\r\n\t\t\trole=\"spinbutton\" autocomplete=\"off\" ${!nameAttrSetting}\r\n\t/></div\r\n></div>\r\n"),baseClass:"dijitTextBox dijitSpinner",cssStateNodes:{"upArrowNode":"dijitUpArrowButton","downArrowNode":"dijitDownArrowButton"},adjust:function(val,_a4b){
return val;
},_arrowPressed:function(_a4c,_a4d,_a4e){
if(this.disabled||this.readOnly){
return;
}
this._setValueAttr(this.adjust(this.get("value"),_a4d*_a4e),false);
dijit.selectInputText(this.textbox,this.textbox.value.length);
},_arrowReleased:function(node){
this._wheelTimer=null;
if(this.disabled||this.readOnly){
return;
}
},_typematicCallback:function(_a4f,node,evt){
var inc=this.smallDelta;
if(node==this.textbox){
var k=dojo.keys;
var key=evt.charOrCode;
inc=(key==k.PAGE_UP||key==k.PAGE_DOWN)?this.largeDelta:this.smallDelta;
node=(key==k.UP_ARROW||key==k.PAGE_UP)?this.upArrowNode:this.downArrowNode;
}
if(_a4f==-1){
this._arrowReleased(node);
}else{
this._arrowPressed(node,(node==this.upArrowNode)?1:-1,inc);
}
},_wheelTimer:null,_mouseWheeled:function(evt){
dojo.stopEvent(evt);
var _a50=evt.detail?(evt.detail*-1):(evt.wheelDelta/120);
if(_a50!==0){
var node=this[(_a50>0?"upArrowNode":"downArrowNode")];
this._arrowPressed(node,_a50,this.smallDelta);
if(!this._wheelTimer){
clearTimeout(this._wheelTimer);
}
this._wheelTimer=setTimeout(dojo.hitch(this,"_arrowReleased",node),50);
}
},postCreate:function(){
this.inherited(arguments);
this.connect(this.domNode,!dojo.isMozilla?"onmousewheel":"DOMMouseScroll","_mouseWheeled");
this._connects.push(dijit.typematic.addListener(this.upArrowNode,this.textbox,{charOrCode:dojo.keys.UP_ARROW,ctrlKey:false,altKey:false,shiftKey:false,metaKey:false},this,"_typematicCallback",this.timeoutChangeRate,this.defaultTimeout,this.minimumTimeout));
this._connects.push(dijit.typematic.addListener(this.downArrowNode,this.textbox,{charOrCode:dojo.keys.DOWN_ARROW,ctrlKey:false,altKey:false,shiftKey:false,metaKey:false},this,"_typematicCallback",this.timeoutChangeRate,this.defaultTimeout,this.minimumTimeout));
this._connects.push(dijit.typematic.addListener(this.upArrowNode,this.textbox,{charOrCode:dojo.keys.PAGE_UP,ctrlKey:false,altKey:false,shiftKey:false,metaKey:false},this,"_typematicCallback",this.timeoutChangeRate,this.defaultTimeout,this.minimumTimeout));
this._connects.push(dijit.typematic.addListener(this.downArrowNode,this.textbox,{charOrCode:dojo.keys.PAGE_DOWN,ctrlKey:false,altKey:false,shiftKey:false,metaKey:false},this,"_typematicCallback",this.timeoutChangeRate,this.defaultTimeout,this.minimumTimeout));
}});
}
if(!dojo._hasResource["dijit.form.NumberSpinner"]){
dojo._hasResource["dijit.form.NumberSpinner"]=true;
dojo.provide("dijit.form.NumberSpinner");
dojo.declare("dijit.form.NumberSpinner",[dijit.form._Spinner,dijit.form.NumberTextBoxMixin],{adjust:function(val,_a51){
var tc=this.constraints,v=isNaN(val),_a52=!isNaN(tc.max),_a53=!isNaN(tc.min);
if(v&&_a51!=0){
val=(_a51>0)?_a53?tc.min:_a52?tc.max:0:_a52?this.constraints.max:_a53?tc.min:0;
}
var _a54=val+_a51;
if(v||isNaN(_a54)){
return val;
}
if(_a52&&(_a54>tc.max)){
_a54=tc.max;
}
if(_a53&&(_a54<tc.min)){
_a54=tc.min;
}
return _a54;
},_onKeyPress:function(e){
if((e.charOrCode==dojo.keys.HOME||e.charOrCode==dojo.keys.END)&&!(e.ctrlKey||e.altKey||e.metaKey)&&typeof this.get("value")!="undefined"){
var _a55=this.constraints[(e.charOrCode==dojo.keys.HOME?"min":"max")];
if(typeof _a55=="number"){
this._setValueAttr(_a55,false);
}
dojo.stopEvent(e);
}
}});
}
if(!dojo._hasResource["dojo.cldr.monetary"]){
dojo._hasResource["dojo.cldr.monetary"]=true;
dojo.provide("dojo.cldr.monetary");
dojo.getObject("cldr.monetary",true,dojo);
dojo.cldr.monetary.getData=function(code){
var _a56={ADP:0,AFN:0,ALL:0,AMD:0,BHD:3,BIF:0,BYR:0,CLF:0,CLP:0,COP:0,CRC:0,DJF:0,ESP:0,GNF:0,GYD:0,HUF:0,IDR:0,IQD:0,IRR:3,ISK:0,ITL:0,JOD:3,JPY:0,KMF:0,KPW:0,KRW:0,KWD:3,LAK:0,LBP:0,LUF:0,LYD:3,MGA:0,MGF:0,MMK:0,MNT:0,MRO:0,MUR:0,OMR:3,PKR:0,PYG:0,RSD:0,RWF:0,SLL:0,SOS:0,STD:0,SYP:0,TMM:0,TND:3,TRL:0,TZS:0,UGX:0,UZS:0,VND:0,VUV:0,XAF:0,XOF:0,XPF:0,YER:0,ZMK:0,ZWD:0};
var _a57={CHF:5};
var _a58=_a56[code],_a59=_a57[code];
if(typeof _a58=="undefined"){
_a58=2;
}
if(typeof _a59=="undefined"){
_a59=0;
}
return {places:_a58,round:_a59};
};
}
if(!dojo._hasResource["dojo.currency"]){
dojo._hasResource["dojo.currency"]=true;
dojo.provide("dojo.currency");
dojo.getObject("currency",true,dojo);
dojo.currency._mixInDefaults=function(_a5a){
_a5a=_a5a||{};
_a5a.type="currency";
var _a5b=dojo.i18n.getLocalization("dojo.cldr","currency",_a5a.locale)||{};
var iso=_a5a.currency;
var data=dojo.cldr.monetary.getData(iso);
dojo.forEach(["displayName","symbol","group","decimal"],function(prop){
data[prop]=_a5b[iso+"_"+prop];
});
data.fractional=[true,false];
return dojo.mixin(data,_a5a);
};
dojo.currency.format=function(_a5c,_a5d){
return dojo.number.format(_a5c,dojo.currency._mixInDefaults(_a5d));
};
dojo.currency.regexp=function(_a5e){
return dojo.number.regexp(dojo.currency._mixInDefaults(_a5e));
};
dojo.currency.parse=function(_a5f,_a60){
return dojo.number.parse(_a5f,dojo.currency._mixInDefaults(_a60));
};
}
if(!dojo._hasResource["dijit.form.CurrencyTextBox"]){
dojo._hasResource["dijit.form.CurrencyTextBox"]=true;
dojo.provide("dijit.form.CurrencyTextBox");
dojo.declare("dijit.form.CurrencyTextBox",dijit.form.NumberTextBox,{currency:"",baseClass:"dijitTextBox dijitCurrencyTextBox",regExpGen:function(_a61){
return "("+(this._focused?this.inherited(arguments,[dojo.mixin({},_a61,this.editOptions)])+"|":"")+dojo.currency.regexp(_a61)+")";
},_formatter:dojo.currency.format,_parser:dojo.currency.parse,parse:function(_a62,_a63){
var v=this.inherited(arguments);
if(isNaN(v)&&/\d+/.test(_a62)){
v=dojo.hitch(dojo.mixin({},this,{_parser:dijit.form.NumberTextBox.prototype._parser}),"inherited")(arguments);
}
return v;
},_setConstraintsAttr:function(_a64){
if(!_a64.currency&&this.currency){
_a64.currency=this.currency;
}
this.inherited(arguments,[dojo.currency._mixInDefaults(dojo.mixin(_a64,{exponent:false}))]);
}});
}
if(!dojo._hasResource["dijit.form.HorizontalSlider"]){
dojo._hasResource["dijit.form.HorizontalSlider"]=true;
dojo.provide("dijit.form.HorizontalSlider");
dojo.declare("dijit.form.HorizontalSlider",[dijit.form._FormValueWidget,dijit._Container],{templateString:dojo.cache("dijit.form","templates/HorizontalSlider.html","<table class=\"dijit dijitReset dijitSlider dijitSliderH\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\" rules=\"none\" dojoAttachEvent=\"onkeypress:_onKeyPress,onkeyup:_onKeyUp\"\r\n\t><tr class=\"dijitReset\"\r\n\t\t><td class=\"dijitReset\" colspan=\"2\"></td\r\n\t\t><td dojoAttachPoint=\"topDecoration\" class=\"dijitReset dijitSliderDecoration dijitSliderDecorationT dijitSliderDecorationH\"></td\r\n\t\t><td class=\"dijitReset\" colspan=\"2\"></td\r\n\t></tr\r\n\t><tr class=\"dijitReset\"\r\n\t\t><td class=\"dijitReset dijitSliderButtonContainer dijitSliderButtonContainerH\"\r\n\t\t\t><div class=\"dijitSliderDecrementIconH\" style=\"display:none\" dojoAttachPoint=\"decrementButton\"><span class=\"dijitSliderButtonInner\">-</span></div\r\n\t\t></td\r\n\t\t><td class=\"dijitReset\"\r\n\t\t\t><div class=\"dijitSliderBar dijitSliderBumper dijitSliderBumperH dijitSliderLeftBumper\" dojoAttachEvent=\"onmousedown:_onClkDecBumper\"></div\r\n\t\t></td\r\n\t\t><td class=\"dijitReset\"\r\n\t\t\t><input dojoAttachPoint=\"valueNode\" type=\"hidden\" ${!nameAttrSetting}\r\n\t\t\t/><div class=\"dijitReset dijitSliderBarContainerH\" role=\"presentation\" dojoAttachPoint=\"sliderBarContainer\"\r\n\t\t\t\t><div role=\"presentation\" dojoAttachPoint=\"progressBar\" class=\"dijitSliderBar dijitSliderBarH dijitSliderProgressBar dijitSliderProgressBarH\" dojoAttachEvent=\"onmousedown:_onBarClick\"\r\n\t\t\t\t\t><div class=\"dijitSliderMoveable dijitSliderMoveableH\"\r\n\t\t\t\t\t\t><div dojoAttachPoint=\"sliderHandle,focusNode\" class=\"dijitSliderImageHandle dijitSliderImageHandleH\" dojoAttachEvent=\"onmousedown:_onHandleClick\" role=\"slider\" valuemin=\"${minimum}\" valuemax=\"${maximum}\"></div\r\n\t\t\t\t\t></div\r\n\t\t\t\t></div\r\n\t\t\t\t><div role=\"presentation\" dojoAttachPoint=\"remainingBar\" class=\"dijitSliderBar dijitSliderBarH dijitSliderRemainingBar dijitSliderRemainingBarH\" dojoAttachEvent=\"onmousedown:_onBarClick\"></div\r\n\t\t\t></div\r\n\t\t></td\r\n\t\t><td class=\"dijitReset\"\r\n\t\t\t><div class=\"dijitSliderBar dijitSliderBumper dijitSliderBumperH dijitSliderRightBumper\" dojoAttachEvent=\"onmousedown:_onClkIncBumper\"></div\r\n\t\t></td\r\n\t\t><td class=\"dijitReset dijitSliderButtonContainer dijitSliderButtonContainerH\"\r\n\t\t\t><div class=\"dijitSliderIncrementIconH\" style=\"display:none\" dojoAttachPoint=\"incrementButton\"><span class=\"dijitSliderButtonInner\">+</span></div\r\n\t\t></td\r\n\t></tr\r\n\t><tr class=\"dijitReset\"\r\n\t\t><td class=\"dijitReset\" colspan=\"2\"></td\r\n\t\t><td dojoAttachPoint=\"containerNode,bottomDecoration\" class=\"dijitReset dijitSliderDecoration dijitSliderDecorationB dijitSliderDecorationH\"></td\r\n\t\t><td class=\"dijitReset\" colspan=\"2\"></td\r\n\t></tr\r\n></table>\r\n"),value:0,showButtons:true,minimum:0,maximum:100,discreteValues:Infinity,pageIncrement:2,clickSelect:true,slideDuration:dijit.defaultDuration,widgetsInTemplate:true,attributeMap:dojo.delegate(dijit.form._FormWidget.prototype.attributeMap,{id:""}),baseClass:"dijitSlider",cssStateNodes:{incrementButton:"dijitSliderIncrementButton",decrementButton:"dijitSliderDecrementButton",focusNode:"dijitSliderThumb"},_mousePixelCoord:"pageX",_pixelCount:"w",_startingPixelCoord:"x",_startingPixelCount:"l",_handleOffsetCoord:"left",_progressPixelSize:"width",_onKeyUp:function(e){
if(this.disabled||this.readOnly||e.altKey||e.ctrlKey||e.metaKey){
return;
}
this._setValueAttr(this.value,true);
},_onKeyPress:function(e){
if(this.disabled||this.readOnly||e.altKey||e.ctrlKey||e.metaKey){
return;
}
switch(e.charOrCode){
case dojo.keys.HOME:
this._setValueAttr(this.minimum,false);
break;
case dojo.keys.END:
this._setValueAttr(this.maximum,false);
break;
case ((this._descending||this.isLeftToRight())?dojo.keys.RIGHT_ARROW:dojo.keys.LEFT_ARROW):
case (this._descending===false?dojo.keys.DOWN_ARROW:dojo.keys.UP_ARROW):
case (this._descending===false?dojo.keys.PAGE_DOWN:dojo.keys.PAGE_UP):
this.increment(e);
break;
case ((this._descending||this.isLeftToRight())?dojo.keys.LEFT_ARROW:dojo.keys.RIGHT_ARROW):
case (this._descending===false?dojo.keys.UP_ARROW:dojo.keys.DOWN_ARROW):
case (this._descending===false?dojo.keys.PAGE_UP:dojo.keys.PAGE_DOWN):
this.decrement(e);
break;
default:
return;
}
dojo.stopEvent(e);
},_onHandleClick:function(e){
if(this.disabled||this.readOnly){
return;
}
if(!dojo.isIE){
dijit.focus(this.sliderHandle);
}
dojo.stopEvent(e);
},_isReversed:function(){
return !this.isLeftToRight();
},_onBarClick:function(e){
if(this.disabled||this.readOnly||!this.clickSelect){
return;
}
dijit.focus(this.sliderHandle);
dojo.stopEvent(e);
var _a65=dojo.position(this.sliderBarContainer,true);
var _a66=e[this._mousePixelCoord]-_a65[this._startingPixelCoord];
this._setPixelValue(this._isReversed()?(_a65[this._pixelCount]-_a66):_a66,_a65[this._pixelCount],true);
this._movable.onMouseDown(e);
},_setPixelValue:function(_a67,_a68,_a69){
if(this.disabled||this.readOnly){
return;
}
_a67=_a67<0?0:_a68<_a67?_a68:_a67;
var _a6a=this.discreteValues;
if(_a6a<=1||_a6a==Infinity){
_a6a=_a68;
}
_a6a--;
var _a6b=_a68/_a6a;
var _a6c=Math.round(_a67/_a6b);
this._setValueAttr((this.maximum-this.minimum)*_a6c/_a6a+this.minimum,_a69);
},_setValueAttr:function(_a6d,_a6e){
this._set("value",_a6d);
this.valueNode.value=_a6d;
dijit.setWaiState(this.focusNode,"valuenow",_a6d);
this.inherited(arguments);
var _a6f=(_a6d-this.minimum)/(this.maximum-this.minimum);
var _a70=(this._descending===false)?this.remainingBar:this.progressBar;
var _a71=(this._descending===false)?this.progressBar:this.remainingBar;
if(this._inProgressAnim&&this._inProgressAnim.status!="stopped"){
this._inProgressAnim.stop(true);
}
if(_a6e&&this.slideDuration>0&&_a70.style[this._progressPixelSize]){
var _a72=this;
var _a73={};
var _a74=parseFloat(_a70.style[this._progressPixelSize]);
var _a75=this.slideDuration*(_a6f-_a74/100);
if(_a75==0){
return;
}
if(_a75<0){
_a75=0-_a75;
}
_a73[this._progressPixelSize]={start:_a74,end:_a6f*100,units:"%"};
this._inProgressAnim=dojo.animateProperty({node:_a70,duration:_a75,onAnimate:function(v){
_a71.style[_a72._progressPixelSize]=(100-parseFloat(v[_a72._progressPixelSize]))+"%";
},onEnd:function(){
delete _a72._inProgressAnim;
},properties:_a73});
this._inProgressAnim.play();
}else{
_a70.style[this._progressPixelSize]=(_a6f*100)+"%";
_a71.style[this._progressPixelSize]=((1-_a6f)*100)+"%";
}
},_bumpValue:function(_a76,_a77){
if(this.disabled||this.readOnly){
return;
}
var s=dojo.getComputedStyle(this.sliderBarContainer);
var c=dojo._getContentBox(this.sliderBarContainer,s);
var _a78=this.discreteValues;
if(_a78<=1||_a78==Infinity){
_a78=c[this._pixelCount];
}
_a78--;
var _a79=(this.value-this.minimum)*_a78/(this.maximum-this.minimum)+_a76;
if(_a79<0){
_a79=0;
}
if(_a79>_a78){
_a79=_a78;
}
_a79=_a79*(this.maximum-this.minimum)/_a78+this.minimum;
this._setValueAttr(_a79,_a77);
},_onClkBumper:function(val){
if(this.disabled||this.readOnly||!this.clickSelect){
return;
}
this._setValueAttr(val,true);
},_onClkIncBumper:function(){
this._onClkBumper(this._descending===false?this.minimum:this.maximum);
},_onClkDecBumper:function(){
this._onClkBumper(this._descending===false?this.maximum:this.minimum);
},decrement:function(e){
this._bumpValue(e.charOrCode==dojo.keys.PAGE_DOWN?-this.pageIncrement:-1);
},increment:function(e){
this._bumpValue(e.charOrCode==dojo.keys.PAGE_UP?this.pageIncrement:1);
},_mouseWheeled:function(evt){
dojo.stopEvent(evt);
var _a7a=!dojo.isMozilla;
var _a7b=evt[(_a7a?"wheelDelta":"detail")]*(_a7a?1:-1);
this._bumpValue(_a7b<0?-1:1,true);
},startup:function(){
if(this._started){
return;
}
dojo.forEach(this.getChildren(),function(_a7c){
if(this[_a7c.container]!=this.containerNode){
this[_a7c.container].appendChild(_a7c.domNode);
}
},this);
this.inherited(arguments);
},_typematicCallback:function(_a7d,_a7e,e){
if(_a7d==-1){
this._setValueAttr(this.value,true);
}else{
this[(_a7e==(this._descending?this.incrementButton:this.decrementButton))?"decrement":"increment"](e);
}
},buildRendering:function(){
this.inherited(arguments);
if(this.showButtons){
this.incrementButton.style.display="";
this.decrementButton.style.display="";
}
var _a7f=dojo.query("label[for=\""+this.id+"\"]");
if(_a7f.length){
_a7f[0].id=(this.id+"_label");
dijit.setWaiState(this.focusNode,"labelledby",_a7f[0].id);
}
dijit.setWaiState(this.focusNode,"valuemin",this.minimum);
dijit.setWaiState(this.focusNode,"valuemax",this.maximum);
},postCreate:function(){
this.inherited(arguments);
if(this.showButtons){
this._connects.push(dijit.typematic.addMouseListener(this.decrementButton,this,"_typematicCallback",25,500));
this._connects.push(dijit.typematic.addMouseListener(this.incrementButton,this,"_typematicCallback",25,500));
}
this.connect(this.domNode,!dojo.isMozilla?"onmousewheel":"DOMMouseScroll","_mouseWheeled");
var _a80=dojo.declare(dijit.form._SliderMover,{widget:this});
this._movable=new dojo.dnd.Moveable(this.sliderHandle,{mover:_a80});
this._layoutHackIE7();
},destroy:function(){
this._movable.destroy();
if(this._inProgressAnim&&this._inProgressAnim.status!="stopped"){
this._inProgressAnim.stop(true);
}
this._supportingWidgets=dijit.findWidgets(this.domNode);
this.inherited(arguments);
}});
dojo.declare("dijit.form._SliderMover",dojo.dnd.Mover,{onMouseMove:function(e){
var _a81=this.widget;
var _a82=_a81._abspos;
if(!_a82){
_a82=_a81._abspos=dojo.position(_a81.sliderBarContainer,true);
_a81._setPixelValue_=dojo.hitch(_a81,"_setPixelValue");
_a81._isReversed_=_a81._isReversed();
}
var _a83=e.touches?e.touches[0]:e,_a84=_a83[_a81._mousePixelCoord]-_a82[_a81._startingPixelCoord];
_a81._setPixelValue_(_a81._isReversed_?(_a82[_a81._pixelCount]-_a84):_a84,_a82[_a81._pixelCount],false);
},destroy:function(e){
dojo.dnd.Mover.prototype.destroy.apply(this,arguments);
var _a85=this.widget;
_a85._abspos=null;
_a85._setValueAttr(_a85.value,true);
}});
}
if(!dojo._hasResource["dijit._editor.selection"]){
dojo._hasResource["dijit._editor.selection"]=true;
dojo.provide("dijit._editor.selection");
dojo.getObject("_editor.selection",true,dijit);
dojo.mixin(dijit._editor.selection,{getType:function(){
if(dojo.isIE<9){
return dojo.doc.selection.type.toLowerCase();
}else{
var _a86="text";
var oSel;
try{
oSel=dojo.global.getSelection();
}
catch(e){
}
if(oSel&&oSel.rangeCount==1){
var _a87=oSel.getRangeAt(0);
if((_a87.startContainer==_a87.endContainer)&&((_a87.endOffset-_a87.startOffset)==1)&&(_a87.startContainer.nodeType!=3)){
_a86="control";
}
}
return _a86;
}
},getSelectedText:function(){
if(dojo.isIE<9){
if(dijit._editor.selection.getType()=="control"){
return null;
}
return dojo.doc.selection.createRange().text;
}else{
var _a88=dojo.global.getSelection();
if(_a88){
return _a88.toString();
}
}
return "";
},getSelectedHtml:function(){
if(dojo.isIE<9){
if(dijit._editor.selection.getType()=="control"){
return null;
}
return dojo.doc.selection.createRange().htmlText;
}else{
var _a89=dojo.global.getSelection();
if(_a89&&_a89.rangeCount){
var i;
var html="";
for(i=0;i<_a89.rangeCount;i++){
var frag=_a89.getRangeAt(i).cloneContents();
var div=dojo.doc.createElement("div");
div.appendChild(frag);
html+=div.innerHTML;
}
return html;
}
return null;
}
},getSelectedElement:function(){
if(dijit._editor.selection.getType()=="control"){
if(dojo.isIE<9){
var _a8a=dojo.doc.selection.createRange();
if(_a8a&&_a8a.item){
return dojo.doc.selection.createRange().item(0);
}
}else{
var _a8b=dojo.global.getSelection();
return _a8b.anchorNode.childNodes[_a8b.anchorOffset];
}
}
return null;
},getParentElement:function(){
if(dijit._editor.selection.getType()=="control"){
var p=this.getSelectedElement();
if(p){
return p.parentNode;
}
}else{
if(dojo.isIE<9){
var r=dojo.doc.selection.createRange();
r.collapse(true);
return r.parentElement();
}else{
var _a8c=dojo.global.getSelection();
if(_a8c){
var node=_a8c.anchorNode;
while(node&&(node.nodeType!=1)){
node=node.parentNode;
}
return node;
}
}
}
return null;
},hasAncestorElement:function(_a8d){
return this.getAncestorElement.apply(this,arguments)!=null;
},getAncestorElement:function(_a8e){
var node=this.getSelectedElement()||this.getParentElement();
return this.getParentOfType(node,arguments);
},isTag:function(node,tags){
if(node&&node.tagName){
var _a8f=node.tagName.toLowerCase();
for(var i=0;i<tags.length;i++){
var _a90=String(tags[i]).toLowerCase();
if(_a8f==_a90){
return _a90;
}
}
}
return "";
},getParentOfType:function(node,tags){
while(node){
if(this.isTag(node,tags).length){
return node;
}
node=node.parentNode;
}
return null;
},collapse:function(_a91){
if(window.getSelection){
var _a92=dojo.global.getSelection();
if(_a92.removeAllRanges){
if(_a91){
_a92.collapseToStart();
}else{
_a92.collapseToEnd();
}
}else{
_a92.collapse(_a91);
}
}else{
if(dojo.isIE){
var _a93=dojo.doc.selection.createRange();
_a93.collapse(_a91);
_a93.select();
}
}
},remove:function(){
var sel=dojo.doc.selection;
if(dojo.isIE<9){
if(sel.type.toLowerCase()!="none"){
sel.clear();
}
return sel;
}else{
sel=dojo.global.getSelection();
sel.deleteFromDocument();
return sel;
}
},selectElementChildren:function(_a94,_a95){
var win=dojo.global;
var doc=dojo.doc;
var _a96;
_a94=dojo.byId(_a94);
if(doc.selection&&dojo.isIE<9&&dojo.body().createTextRange){
_a96=_a94.ownerDocument.body.createTextRange();
_a96.moveToElementText(_a94);
if(!_a95){
try{
_a96.select();
}
catch(e){
}
}
}else{
if(win.getSelection){
var _a97=dojo.global.getSelection();
if(dojo.isOpera){
if(_a97.rangeCount){
_a96=_a97.getRangeAt(0);
}else{
_a96=doc.createRange();
}
_a96.setStart(_a94,0);
_a96.setEnd(_a94,(_a94.nodeType==3)?_a94.length:_a94.childNodes.length);
_a97.addRange(_a96);
}else{
_a97.selectAllChildren(_a94);
}
}
}
},selectElement:function(_a98,_a99){
var _a9a;
var doc=dojo.doc;
var win=dojo.global;
_a98=dojo.byId(_a98);
if(dojo.isIE<9&&dojo.body().createTextRange){
try{
var tg=_a98.tagName?_a98.tagName.toLowerCase():"";
if(tg==="img"||tg==="table"){
_a9a=dojo.body().createControlRange();
}else{
_a9a=dojo.body().createRange();
}
_a9a.addElement(_a98);
if(!_a99){
_a9a.select();
}
}
catch(e){
this.selectElementChildren(_a98,_a99);
}
}else{
if(dojo.global.getSelection){
var _a9b=win.getSelection();
_a9a=doc.createRange();
if(_a9b.removeAllRanges){
if(dojo.isOpera){
if(_a9b.getRangeAt(0)){
_a9a=_a9b.getRangeAt(0);
}
}
_a9a.selectNode(_a98);
_a9b.removeAllRanges();
_a9b.addRange(_a9a);
}
}
}
},inSelection:function(node){
if(node){
var _a9c;
var doc=dojo.doc;
var _a9d;
if(dojo.global.getSelection){
var sel=dojo.global.getSelection();
if(sel&&sel.rangeCount>0){
_a9d=sel.getRangeAt(0);
}
if(_a9d&&_a9d.compareBoundaryPoints&&doc.createRange){
try{
_a9c=doc.createRange();
_a9c.setStart(node,0);
if(_a9d.compareBoundaryPoints(_a9d.START_TO_END,_a9c)===1){
return true;
}
}
catch(e){
}
}
}else{
if(doc.selection){
_a9d=doc.selection.createRange();
try{
_a9c=node.ownerDocument.body.createControlRange();
if(_a9c){
_a9c.addElement(node);
}
}
catch(e1){
try{
_a9c=node.ownerDocument.body.createTextRange();
_a9c.moveToElementText(node);
}
catch(e2){
}
}
if(_a9d&&_a9c){
if(_a9d.compareEndPoints("EndToStart",_a9c)===1){
return true;
}
}
}
}
}
return false;
}});
}
if(!dojo._hasResource["dijit._editor.range"]){
dojo._hasResource["dijit._editor.range"]=true;
dojo.provide("dijit._editor.range");
dijit.range={};
dijit.range.getIndex=function(node,_a9e){
var ret=[],retR=[];
var stop=_a9e;
var _a9f=node;
var _aa0,n;
while(node!=stop){
var i=0;
_aa0=node.parentNode;
while((n=_aa0.childNodes[i++])){
if(n===node){
--i;
break;
}
}
ret.unshift(i);
retR.unshift(i-_aa0.childNodes.length);
node=_aa0;
}
if(ret.length>0&&_a9f.nodeType==3){
n=_a9f.previousSibling;
while(n&&n.nodeType==3){
ret[ret.length-1]--;
n=n.previousSibling;
}
n=_a9f.nextSibling;
while(n&&n.nodeType==3){
retR[retR.length-1]++;
n=n.nextSibling;
}
}
return {o:ret,r:retR};
};
dijit.range.getNode=function(_aa1,_aa2){
if(!dojo.isArray(_aa1)||_aa1.length==0){
return _aa2;
}
var node=_aa2;
dojo.every(_aa1,function(i){
if(i>=0&&i<node.childNodes.length){
node=node.childNodes[i];
}else{
node=null;
return false;
}
return true;
});
return node;
};
dijit.range.getCommonAncestor=function(n1,n2,root){
root=root||n1.ownerDocument.body;
var _aa3=function(n){
var as=[];
while(n){
as.unshift(n);
if(n!==root){
n=n.parentNode;
}else{
break;
}
}
return as;
};
var n1as=_aa3(n1);
var n2as=_aa3(n2);
var m=Math.min(n1as.length,n2as.length);
var com=n1as[0];
for(var i=1;i<m;i++){
if(n1as[i]===n2as[i]){
com=n1as[i];
}else{
break;
}
}
return com;
};
dijit.range.getAncestor=function(node,_aa4,root){
root=root||node.ownerDocument.body;
while(node&&node!==root){
var name=node.nodeName.toUpperCase();
if(_aa4.test(name)){
return node;
}
node=node.parentNode;
}
return null;
};
dijit.range.BlockTagNames=/^(?:P|DIV|H1|H2|H3|H4|H5|H6|ADDRESS|PRE|OL|UL|LI|DT|DE)$/;
dijit.range.getBlockAncestor=function(node,_aa5,root){
root=root||node.ownerDocument.body;
_aa5=_aa5||dijit.range.BlockTagNames;
var _aa6=null,_aa7;
while(node&&node!==root){
var name=node.nodeName.toUpperCase();
if(!_aa6&&_aa5.test(name)){
_aa6=node;
}
if(!_aa7&&(/^(?:BODY|TD|TH|CAPTION)$/).test(name)){
_aa7=node;
}
node=node.parentNode;
}
return {blockNode:_aa6,blockContainer:_aa7||node.ownerDocument.body};
};
dijit.range.atBeginningOfContainer=function(_aa8,node,_aa9){
var _aaa=false;
var _aab=(_aa9==0);
if(!_aab&&node.nodeType==3){
if(/^[\s\xA0]+$/.test(node.nodeValue.substr(0,_aa9))){
_aab=true;
}
}
if(_aab){
var _aac=node;
_aaa=true;
while(_aac&&_aac!==_aa8){
if(_aac.previousSibling){
_aaa=false;
break;
}
_aac=_aac.parentNode;
}
}
return _aaa;
};
dijit.range.atEndOfContainer=function(_aad,node,_aae){
var _aaf=false;
var _ab0=(_aae==(node.length||node.childNodes.length));
if(!_ab0&&node.nodeType==3){
if(/^[\s\xA0]+$/.test(node.nodeValue.substr(_aae))){
_ab0=true;
}
}
if(_ab0){
var _ab1=node;
_aaf=true;
while(_ab1&&_ab1!==_aad){
if(_ab1.nextSibling){
_aaf=false;
break;
}
_ab1=_ab1.parentNode;
}
}
return _aaf;
};
dijit.range.adjacentNoneTextNode=function(_ab2,next){
var node=_ab2;
var len=(0-_ab2.length)||0;
var prop=next?"nextSibling":"previousSibling";
while(node){
if(node.nodeType!=3){
break;
}
len+=node.length;
node=node[prop];
}
return [node,len];
};
dijit.range._w3c=Boolean(window["getSelection"]);
dijit.range.create=function(win){
if(dijit.range._w3c){
return (win||dojo.global).document.createRange();
}else{
return new dijit.range.W3CRange;
}
};
dijit.range.getSelection=function(win,_ab3){
if(dijit.range._w3c){
return win.getSelection();
}else{
var s=new dijit.range.ie.selection(win);
if(!_ab3){
s._getCurrentSelection();
}
return s;
}
};
if(!dijit.range._w3c){
dijit.range.ie={cachedSelection:{},selection:function(win){
this._ranges=[];
this.addRange=function(r,_ab4){
this._ranges.push(r);
if(!_ab4){
r._select();
}
this.rangeCount=this._ranges.length;
};
this.removeAllRanges=function(){
this._ranges=[];
this.rangeCount=0;
};
var _ab5=function(){
var r=win.document.selection.createRange();
var type=win.document.selection.type.toUpperCase();
if(type=="CONTROL"){
return new dijit.range.W3CRange(dijit.range.ie.decomposeControlRange(r));
}else{
return new dijit.range.W3CRange(dijit.range.ie.decomposeTextRange(r));
}
};
this.getRangeAt=function(i){
return this._ranges[i];
};
this._getCurrentSelection=function(){
this.removeAllRanges();
var r=_ab5();
if(r){
this.addRange(r,true);
}
};
},decomposeControlRange:function(_ab6){
var _ab7=_ab6.item(0),_ab8=_ab6.item(_ab6.length-1);
var _ab9=_ab7.parentNode,_aba=_ab8.parentNode;
var _abb=dijit.range.getIndex(_ab7,_ab9).o;
var _abc=dijit.range.getIndex(_ab8,_aba).o+1;
return [_ab9,_abb,_aba,_abc];
},getEndPoint:function(_abd,end){
var _abe=_abd.duplicate();
_abe.collapse(!end);
var _abf="EndTo"+(end?"End":"Start");
var _ac0=_abe.parentElement();
var _ac1,_ac2,_ac3;
if(_ac0.childNodes.length>0){
dojo.every(_ac0.childNodes,function(node,i){
var _ac4;
if(node.nodeType!=3){
_abe.moveToElementText(node);
if(_abe.compareEndPoints(_abf,_abd)>0){
if(_ac3&&_ac3.nodeType==3){
_ac1=_ac3;
_ac4=true;
}else{
_ac1=_ac0;
_ac2=i;
return false;
}
}else{
if(i==_ac0.childNodes.length-1){
_ac1=_ac0;
_ac2=_ac0.childNodes.length;
return false;
}
}
}else{
if(i==_ac0.childNodes.length-1){
_ac1=node;
_ac4=true;
}
}
if(_ac4&&_ac1){
var _ac5=dijit.range.adjacentNoneTextNode(_ac1)[0];
if(_ac5){
_ac1=_ac5.nextSibling;
}else{
_ac1=_ac0.firstChild;
}
var _ac6=dijit.range.adjacentNoneTextNode(_ac1);
_ac5=_ac6[0];
var _ac7=_ac6[1];
if(_ac5){
_abe.moveToElementText(_ac5);
_abe.collapse(false);
}else{
_abe.moveToElementText(_ac0);
}
_abe.setEndPoint(_abf,_abd);
_ac2=_abe.text.length-_ac7;
return false;
}
_ac3=node;
return true;
});
}else{
_ac1=_ac0;
_ac2=0;
}
if(!end&&_ac1.nodeType==1&&_ac2==_ac1.childNodes.length){
var _ac8=_ac1.nextSibling;
if(_ac8&&_ac8.nodeType==3){
_ac1=_ac8;
_ac2=0;
}
}
return [_ac1,_ac2];
},setEndPoint:function(_ac9,_aca,_acb){
var _acc=_ac9.duplicate(),node,len;
if(_aca.nodeType!=3){
if(_acb>0){
node=_aca.childNodes[_acb-1];
if(node){
if(node.nodeType==3){
_aca=node;
_acb=node.length;
}else{
if(node.nextSibling&&node.nextSibling.nodeType==3){
_aca=node.nextSibling;
_acb=0;
}else{
_acc.moveToElementText(node.nextSibling?node:_aca);
var _acd=node.parentNode;
var _ace=_acd.insertBefore(node.ownerDocument.createTextNode(" "),node.nextSibling);
_acc.collapse(false);
_acd.removeChild(_ace);
}
}
}
}else{
_acc.moveToElementText(_aca);
_acc.collapse(true);
}
}
if(_aca.nodeType==3){
var _acf=dijit.range.adjacentNoneTextNode(_aca);
var _ad0=_acf[0];
len=_acf[1];
if(_ad0){
_acc.moveToElementText(_ad0);
_acc.collapse(false);
if(_ad0.contentEditable!="inherit"){
len++;
}
}else{
_acc.moveToElementText(_aca.parentNode);
_acc.collapse(true);
}
_acb+=len;
if(_acb>0){
if(_acc.move("character",_acb)!=_acb){
console.error("Error when moving!");
}
}
}
return _acc;
},decomposeTextRange:function(_ad1){
var _ad2=dijit.range.ie.getEndPoint(_ad1);
var _ad3=_ad2[0],_ad4=_ad2[1];
var _ad5=_ad2[0],_ad6=_ad2[1];
if(_ad1.htmlText.length){
if(_ad1.htmlText==_ad1.text){
_ad6=_ad4+_ad1.text.length;
}else{
_ad2=dijit.range.ie.getEndPoint(_ad1,true);
_ad5=_ad2[0],_ad6=_ad2[1];
}
}
return [_ad3,_ad4,_ad5,_ad6];
},setRange:function(_ad7,_ad8,_ad9,_ada,_adb,_adc){
var _add=dijit.range.ie.setEndPoint(_ad7,_ad8,_ad9);
_ad7.setEndPoint("StartToStart",_add);
if(!_adc){
var end=dijit.range.ie.setEndPoint(_ad7,_ada,_adb);
}
_ad7.setEndPoint("EndToEnd",end||_add);
return _ad7;
}};
dojo.declare("dijit.range.W3CRange",null,{constructor:function(){
if(arguments.length>0){
this.setStart(arguments[0][0],arguments[0][1]);
this.setEnd(arguments[0][2],arguments[0][3]);
}else{
this.commonAncestorContainer=null;
this.startContainer=null;
this.startOffset=0;
this.endContainer=null;
this.endOffset=0;
this.collapsed=true;
}
},_updateInternal:function(){
if(this.startContainer!==this.endContainer){
this.commonAncestorContainer=dijit.range.getCommonAncestor(this.startContainer,this.endContainer);
}else{
this.commonAncestorContainer=this.startContainer;
}
this.collapsed=(this.startContainer===this.endContainer)&&(this.startOffset==this.endOffset);
},setStart:function(node,_ade){
_ade=parseInt(_ade);
if(this.startContainer===node&&this.startOffset==_ade){
return;
}
delete this._cachedBookmark;
this.startContainer=node;
this.startOffset=_ade;
if(!this.endContainer){
this.setEnd(node,_ade);
}else{
this._updateInternal();
}
},setEnd:function(node,_adf){
_adf=parseInt(_adf);
if(this.endContainer===node&&this.endOffset==_adf){
return;
}
delete this._cachedBookmark;
this.endContainer=node;
this.endOffset=_adf;
if(!this.startContainer){
this.setStart(node,_adf);
}else{
this._updateInternal();
}
},setStartAfter:function(node,_ae0){
this._setPoint("setStart",node,_ae0,1);
},setStartBefore:function(node,_ae1){
this._setPoint("setStart",node,_ae1,0);
},setEndAfter:function(node,_ae2){
this._setPoint("setEnd",node,_ae2,1);
},setEndBefore:function(node,_ae3){
this._setPoint("setEnd",node,_ae3,0);
},_setPoint:function(what,node,_ae4,ext){
var _ae5=dijit.range.getIndex(node,node.parentNode).o;
this[what](node.parentNode,_ae5.pop()+ext);
},_getIERange:function(){
var r=(this._body||this.endContainer.ownerDocument.body).createTextRange();
dijit.range.ie.setRange(r,this.startContainer,this.startOffset,this.endContainer,this.endOffset,this.collapsed);
return r;
},getBookmark:function(body){
this._getIERange();
return this._cachedBookmark;
},_select:function(){
var r=this._getIERange();
r.select();
},deleteContents:function(){
var r=this._getIERange();
r.pasteHTML("");
this.endContainer=this.startContainer;
this.endOffset=this.startOffset;
this.collapsed=true;
},cloneRange:function(){
var r=new dijit.range.W3CRange([this.startContainer,this.startOffset,this.endContainer,this.endOffset]);
r._body=this._body;
return r;
},detach:function(){
this._body=null;
this.commonAncestorContainer=null;
this.startContainer=null;
this.startOffset=0;
this.endContainer=null;
this.endOffset=0;
this.collapsed=true;
}});
}
}
if(!dojo._hasResource["dijit._editor.html"]){
dojo._hasResource["dijit._editor.html"]=true;
dojo.provide("dijit._editor.html");
var exports=dojo.getObject("_editor",true,dijit);
var escape=exports.escapeXml=function(str,_ae6){
str=str.replace(/&/gm,"&amp;").replace(/</gm,"&lt;").replace(/>/gm,"&gt;").replace(/"/gm,"&quot;");
if(!_ae6){
str=str.replace(/'/gm,"&#39;");
}
return str;
};
exports.getNodeHtml=function(node){
var _ae7=[];
exports.getNodeHtmlHelper(node,_ae7);
return _ae7.join("");
};
exports.getNodeHtmlHelper=function(node,_ae8){
switch(node.nodeType){
case 1:
var _ae9=node.nodeName.toLowerCase();
if(!_ae9||_ae9.charAt(0)=="/"){
return "";
}
_ae8.push("<",_ae9);
var _aea=[];
var attr;
if(dojo.isIE){
var _aeb=/^input$|^img$/i.test(node.nodeName)?node:node.cloneNode(false);
var s=_aeb.outerHTML;
s=s.substr(0,s.indexOf(">")).replace(/(['"])[^"']*\1/g,"");
var reg=/(\b\w+)\s?=/g;
var m,key;
while((m=reg.exec(s))){
key=m[1];
if(key.substr(0,3)!="_dj"){
if(key=="src"||key=="href"){
if(node.getAttribute("_djrealurl")){
_aea.push([key,node.getAttribute("_djrealurl")]);
continue;
}
}
var val,_aec;
switch(key){
case "style":
val=node.style.cssText.toLowerCase();
break;
case "class":
val=node.className;
break;
case "width":
if(_ae9==="img"){
_aec=/width=(\S+)/i.exec(s);
if(_aec){
val=_aec[1];
}
break;
}
case "height":
if(_ae9==="img"){
_aec=/height=(\S+)/i.exec(s);
if(_aec){
val=_aec[1];
}
break;
}
default:
val=node.getAttribute(key);
}
if(val!=null){
_aea.push([key,val.toString()]);
}
}
}
}else{
var i=0;
while((attr=node.attributes[i++])){
var n=attr.name;
if(n.substr(0,3)!="_dj"){
var v=attr.value;
if(n=="src"||n=="href"){
if(node.getAttribute("_djrealurl")){
v=node.getAttribute("_djrealurl");
}
}
_aea.push([n,v]);
}
}
}
_aea.sort(function(a,b){
return a[0]<b[0]?-1:(a[0]==b[0]?0:1);
});
var j=0;
while((attr=_aea[j++])){
_ae8.push(" ",attr[0],"=\"",(dojo.isString(attr[1])?escape(attr[1],true):attr[1]),"\"");
}
switch(_ae9){
case "br":
case "hr":
case "img":
case "input":
case "base":
case "meta":
case "area":
case "basefont":
_ae8.push(" />");
break;
case "script":
_ae8.push(">",node.innerHTML,"</",_ae9,">");
break;
default:
_ae8.push(">");
if(node.hasChildNodes()){
exports.getChildrenHtmlHelper(node,_ae8);
}
_ae8.push("</",_ae9,">");
}
break;
case 4:
case 3:
_ae8.push(escape(node.nodeValue,true));
break;
case 8:
_ae8.push("<!--",escape(node.nodeValue,true),"-->");
break;
default:
_ae8.push("<!-- Element not recognized - Type: ",node.nodeType," Name: ",node.nodeName,"-->");
}
};
exports.getChildrenHtml=function(node){
var _aed=[];
exports.getChildrenHtmlHelper(node,_aed);
return _aed.join("");
};
exports.getChildrenHtmlHelper=function(dom,_aee){
if(!dom){
return;
}
var _aef=dom["childNodes"]||dom;
var _af0=!dojo.isIE||_aef!==dom;
var node,i=0;
while((node=_aef[i++])){
if(!_af0||node.parentNode==dom){
exports.getNodeHtmlHelper(node,_aee);
}
}
};
}
if(!dojo._hasResource["dijit._editor.RichText"]){
dojo._hasResource["dijit._editor.RichText"]=true;
dojo.provide("dijit._editor.RichText");
if(!dojo.config["useXDomain"]||dojo.config["allowXdRichTextSave"]){
if(dojo._postLoad){
(function(){
var _af1=dojo.doc.createElement("textarea");
_af1.id=dijit._scopeName+"._editor.RichText.value";
dojo.style(_af1,{display:"none",position:"absolute",top:"-100px",height:"3px",width:"3px"});
dojo.body().appendChild(_af1);
})();
}else{
try{
dojo.doc.write("<textarea id=\""+dijit._scopeName+"._editor.RichText.value\" "+"style=\"display:none;position:absolute;top:-100px;left:-100px;height:3px;width:3px;overflow:hidden;\"></textarea>");
}
catch(e){
}
}
}
dojo.declare("dijit._editor.RichText",[dijit._Widget,dijit._CssStateMixin],{constructor:function(_af2){
this.contentPreFilters=[];
this.contentPostFilters=[];
this.contentDomPreFilters=[];
this.contentDomPostFilters=[];
this.editingAreaStyleSheets=[];
this.events=[].concat(this.events);
this._keyHandlers={};
if(_af2&&dojo.isString(_af2.value)){
this.value=_af2.value;
}
this.onLoadDeferred=new dojo.Deferred();
},baseClass:"dijitEditor",inheritWidth:false,focusOnLoad:false,name:"",styleSheets:"",height:"300px",minHeight:"1em",isClosed:true,isLoaded:false,_SEPARATOR:"@@**%%__RICHTEXTBOUNDRY__%%**@@",_NAME_CONTENT_SEP:"@@**%%:%%**@@",onLoadDeferred:null,isTabIndent:false,disableSpellCheck:false,postCreate:function(){
if("textarea"==this.domNode.tagName.toLowerCase()){
console.warn("RichText should not be used with the TEXTAREA tag.  See dijit._editor.RichText docs.");
}
this.contentPreFilters=[dojo.hitch(this,"_preFixUrlAttributes")].concat(this.contentPreFilters);
if(dojo.isMoz){
this.contentPreFilters=[this._normalizeFontStyle].concat(this.contentPreFilters);
this.contentPostFilters=[this._removeMozBogus].concat(this.contentPostFilters);
}
if(dojo.isWebKit){
this.contentPreFilters=[this._removeWebkitBogus].concat(this.contentPreFilters);
this.contentPostFilters=[this._removeWebkitBogus].concat(this.contentPostFilters);
}
if(dojo.isIE){
this.contentPostFilters=[this._normalizeFontStyle].concat(this.contentPostFilters);
}
this.inherited(arguments);
dojo.publish(dijit._scopeName+"._editor.RichText::init",[this]);
this.open();
this.setupDefaultShortcuts();
},setupDefaultShortcuts:function(){
var exec=dojo.hitch(this,function(cmd,arg){
return function(){
return !this.execCommand(cmd,arg);
};
});
var _af3={b:exec("bold"),i:exec("italic"),u:exec("underline"),a:exec("selectall"),s:function(){
this.save(true);
},m:function(){
this.isTabIndent=!this.isTabIndent;
},"1":exec("formatblock","h1"),"2":exec("formatblock","h2"),"3":exec("formatblock","h3"),"4":exec("formatblock","h4"),"\\":exec("insertunorderedlist")};
if(!dojo.isIE){
_af3.Z=exec("redo");
}
for(var key in _af3){
this.addKeyHandler(key,true,false,_af3[key]);
}
},events:["onKeyPress","onKeyDown","onKeyUp"],captureEvents:[],_editorCommandsLocalized:false,_localizeEditorCommands:function(){
if(dijit._editor._editorCommandsLocalized){
this._local2NativeFormatNames=dijit._editor._local2NativeFormatNames;
this._native2LocalFormatNames=dijit._editor._native2LocalFormatNames;
return;
}
dijit._editor._editorCommandsLocalized=true;
dijit._editor._local2NativeFormatNames={};
dijit._editor._native2LocalFormatNames={};
this._local2NativeFormatNames=dijit._editor._local2NativeFormatNames;
this._native2LocalFormatNames=dijit._editor._native2LocalFormatNames;
var _af4=["div","p","pre","h1","h2","h3","h4","h5","h6","ol","ul","address"];
var _af5="",_af6,i=0;
while((_af6=_af4[i++])){
if(_af6.charAt(1)!=="l"){
_af5+="<"+_af6+"><span>content</span></"+_af6+"><br/>";
}else{
_af5+="<"+_af6+"><li>content</li></"+_af6+"><br/>";
}
}
var _af7={position:"absolute",top:"0px",zIndex:10,opacity:0.01};
var div=dojo.create("div",{style:_af7,innerHTML:_af5});
dojo.body().appendChild(div);
var _af8=dojo.hitch(this,function(){
var node=div.firstChild;
while(node){
try{
dijit._editor.selection.selectElement(node.firstChild);
var _af9=node.tagName.toLowerCase();
this._local2NativeFormatNames[_af9]=document.queryCommandValue("formatblock");
this._native2LocalFormatNames[this._local2NativeFormatNames[_af9]]=_af9;
node=node.nextSibling.nextSibling;
}
catch(e){
}
}
div.parentNode.removeChild(div);
div.innerHTML="";
});
setTimeout(_af8,0);
},open:function(_afa){
if(!this.onLoadDeferred||this.onLoadDeferred.fired>=0){
this.onLoadDeferred=new dojo.Deferred();
}
if(!this.isClosed){
this.close();
}
dojo.publish(dijit._scopeName+"._editor.RichText::open",[this]);
if(arguments.length==1&&_afa.nodeName){
this.domNode=_afa;
}
var dn=this.domNode;
var html;
if(dojo.isString(this.value)){
html=this.value;
delete this.value;
dn.innerHTML="";
}else{
if(dn.nodeName&&dn.nodeName.toLowerCase()=="textarea"){
var ta=(this.textarea=dn);
this.name=ta.name;
html=ta.value;
dn=this.domNode=dojo.doc.createElement("div");
dn.setAttribute("widgetId",this.id);
ta.removeAttribute("widgetId");
dn.cssText=ta.cssText;
dn.className+=" "+ta.className;
dojo.place(dn,ta,"before");
var _afb=dojo.hitch(this,function(){
dojo.style(ta,{display:"block",position:"absolute",top:"-1000px"});
if(dojo.isIE){
var s=ta.style;
this.__overflow=s.overflow;
s.overflow="hidden";
}
});
if(dojo.isIE){
setTimeout(_afb,10);
}else{
_afb();
}
if(ta.form){
var _afc=ta.value;
this.reset=function(){
var _afd=this.getValue();
if(_afd!=_afc){
this.replaceValue(_afc);
}
};
dojo.connect(ta.form,"onsubmit",this,function(){
dojo.attr(ta,"disabled",this.disabled);
ta.value=this.getValue();
});
}
}else{
html=dijit._editor.getChildrenHtml(dn);
dn.innerHTML="";
}
}
var _afe=dojo.contentBox(dn);
this._oldHeight=_afe.h;
this._oldWidth=_afe.w;
this.value=html;
if(dn.nodeName&&dn.nodeName=="LI"){
dn.innerHTML=" <br>";
}
this.header=dn.ownerDocument.createElement("div");
dn.appendChild(this.header);
this.editingArea=dn.ownerDocument.createElement("div");
dn.appendChild(this.editingArea);
this.footer=dn.ownerDocument.createElement("div");
dn.appendChild(this.footer);
if(!this.name){
this.name=this.id+"_AUTOGEN";
}
if(this.name!==""&&(!dojo.config["useXDomain"]||dojo.config["allowXdRichTextSave"])){
var _aff=dojo.byId(dijit._scopeName+"._editor.RichText.value");
if(_aff&&_aff.value!==""){
var _b00=_aff.value.split(this._SEPARATOR),i=0,dat;
while((dat=_b00[i++])){
var data=dat.split(this._NAME_CONTENT_SEP);
if(data[0]==this.name){
html=data[1];
_b00=_b00.splice(i,1);
_aff.value=_b00.join(this._SEPARATOR);
break;
}
}
}
if(!dijit._editor._globalSaveHandler){
dijit._editor._globalSaveHandler={};
dojo.addOnUnload(function(){
var id;
for(id in dijit._editor._globalSaveHandler){
var f=dijit._editor._globalSaveHandler[id];
if(dojo.isFunction(f)){
f();
}
}
});
}
dijit._editor._globalSaveHandler[this.id]=dojo.hitch(this,"_saveContent");
}
this.isClosed=false;
var ifr=(this.editorObject=this.iframe=dojo.doc.createElement("iframe"));
ifr.id=this.id+"_iframe";
this._iframeSrc=this._getIframeDocTxt();
ifr.style.border="none";
ifr.style.width="100%";
if(this._layoutMode){
ifr.style.height="100%";
}else{
if(dojo.isIE>=7){
if(this.height){
ifr.style.height=this.height;
}
if(this.minHeight){
ifr.style.minHeight=this.minHeight;
}
}else{
ifr.style.height=this.height?this.height:this.minHeight;
}
}
ifr.frameBorder=0;
ifr._loadFunc=dojo.hitch(this,function(win){
this.window=win;
this.document=this.window.document;
if(dojo.isIE){
this._localizeEditorCommands();
}
this.onLoad(html);
});
var s="javascript:parent."+dijit._scopeName+".byId(\""+this.id+"\")._iframeSrc";
ifr.setAttribute("src",s);
this.editingArea.appendChild(ifr);
if(dojo.isSafari<=4){
var src=ifr.getAttribute("src");
if(!src||src.indexOf("javascript")==-1){
setTimeout(function(){
ifr.setAttribute("src",s);
},0);
}
}
if(dn.nodeName=="LI"){
dn.lastChild.style.marginTop="-1.2em";
}
dojo.addClass(this.domNode,this.baseClass);
},_local2NativeFormatNames:{},_native2LocalFormatNames:{},_getIframeDocTxt:function(){
var _b01=dojo.getComputedStyle(this.domNode);
var html="";
var _b02=true;
if(dojo.isIE||dojo.isWebKit||(!this.height&&!dojo.isMoz)){
html="<div id='dijitEditorBody'></div>";
_b02=false;
}else{
if(dojo.isMoz){
this._cursorToStart=true;
html="&nbsp;";
}
}
var font=[_b01.fontWeight,_b01.fontSize,_b01.fontFamily].join(" ");
var _b03=_b01.lineHeight;
if(_b03.indexOf("px")>=0){
_b03=parseFloat(_b03)/parseFloat(_b01.fontSize);
}else{
if(_b03.indexOf("em")>=0){
_b03=parseFloat(_b03);
}else{
_b03="normal";
}
}
var _b04="";
var self=this;
this.style.replace(/(^|;)\s*(line-|font-?)[^;]+/ig,function(_b05){
_b05=_b05.replace(/^;/ig,"")+";";
var s=_b05.split(":")[0];
if(s){
s=dojo.trim(s);
s=s.toLowerCase();
var i;
var sC="";
for(i=0;i<s.length;i++){
var c=s.charAt(i);
switch(c){
case "-":
i++;
c=s.charAt(i).toUpperCase();
default:
sC+=c;
}
}
dojo.style(self.domNode,sC,"");
}
_b04+=_b05+";";
});
var _b06=dojo.query("label[for=\""+this.id+"\"]");
return [this.isLeftToRight()?"<html>\n<head>\n":"<html dir='rtl'>\n<head>\n",(dojo.isMoz&&_b06.length?"<title>"+_b06[0].innerHTML+"</title>\n":""),"<meta http-equiv='Content-Type' content='text/html'>\n","<style>\n","\tbody,html {\n","\t\tbackground:transparent;\n","\t\tpadding: 1px 0 0 0;\n","\t\tmargin: -1px 0 0 0;\n",((dojo.isWebKit)?"\t\twidth: 100%;\n":""),((dojo.isWebKit)?"\t\theight: 100%;\n":""),"\t}\n","\tbody{\n","\t\ttop:0px;\n","\t\tleft:0px;\n","\t\tright:0px;\n","\t\tfont:",font,";\n",((this.height||dojo.isOpera)?"":"\t\tposition: fixed;\n"),"\t\tmin-height:",this.minHeight,";\n","\t\tline-height:",_b03,";\n","\t}\n","\tp{ margin: 1em 0; }\n",(!_b02&&!this.height?"\tbody,html {overflow-y: hidden;}\n":""),"\t#dijitEditorBody{overflow-x: auto; overflow-y:"+(this.height?"auto;":"hidden;")+" outline: 0px;}\n","\tli > ul:-moz-first-node, li > ol:-moz-first-node{ padding-top: 1.2em; }\n",(!dojo.isIE?"\tli{ min-height:1.2em; }\n":""),"</style>\n",this._applyEditingAreaStyleSheets(),"\n","</head>\n<body ",(_b02?"id='dijitEditorBody' ":""),"onload='frameElement._loadFunc(window,document)' style='"+_b04+"'>",html,"</body>\n</html>"].join("");
},_applyEditingAreaStyleSheets:function(){
var _b07=[];
if(this.styleSheets){
_b07=this.styleSheets.split(";");
this.styleSheets="";
}
_b07=_b07.concat(this.editingAreaStyleSheets);
this.editingAreaStyleSheets=[];
var text="",i=0,url;
while((url=_b07[i++])){
var _b08=(new dojo._Url(dojo.global.location,url)).toString();
this.editingAreaStyleSheets.push(_b08);
text+="<link rel=\"stylesheet\" type=\"text/css\" href=\""+_b08+"\"/>";
}
return text;
},addStyleSheet:function(uri){
var url=uri.toString();
if(url.charAt(0)=="."||(url.charAt(0)!="/"&&!uri.host)){
url=(new dojo._Url(dojo.global.location,url)).toString();
}
if(dojo.indexOf(this.editingAreaStyleSheets,url)>-1){
return;
}
this.editingAreaStyleSheets.push(url);
this.onLoadDeferred.addCallback(dojo.hitch(this,function(){
if(this.document.createStyleSheet){
this.document.createStyleSheet(url);
}else{
var head=this.document.getElementsByTagName("head")[0];
var _b09=this.document.createElement("link");
_b09.rel="stylesheet";
_b09.type="text/css";
_b09.href=url;
head.appendChild(_b09);
}
}));
},removeStyleSheet:function(uri){
var url=uri.toString();
if(url.charAt(0)=="."||(url.charAt(0)!="/"&&!uri.host)){
url=(new dojo._Url(dojo.global.location,url)).toString();
}
var _b0a=dojo.indexOf(this.editingAreaStyleSheets,url);
if(_b0a==-1){
return;
}
delete this.editingAreaStyleSheets[_b0a];
dojo.withGlobal(this.window,"query",dojo,["link:[href=\""+url+"\"]"]).orphan();
},disabled:false,_mozSettingProps:{"styleWithCSS":false},_setDisabledAttr:function(_b0b){
_b0b=!!_b0b;
this._set("disabled",_b0b);
if(!this.isLoaded){
return;
}
if(dojo.isIE||dojo.isWebKit||dojo.isOpera){
var _b0c=dojo.isIE&&(this.isLoaded||!this.focusOnLoad);
if(_b0c){
this.editNode.unselectable="on";
}
this.editNode.contentEditable=!_b0b;
if(_b0c){
var _b0d=this;
setTimeout(function(){
_b0d.editNode.unselectable="off";
},0);
}
}else{
try{
this.document.designMode=(_b0b?"off":"on");
}
catch(e){
return;
}
if(!_b0b&&this._mozSettingProps){
var ps=this._mozSettingProps;
for(var n in ps){
if(ps.hasOwnProperty(n)){
try{
this.document.execCommand(n,false,ps[n]);
}
catch(e2){
}
}
}
}
}
this._disabledOK=true;
},onLoad:function(html){
if(!this.window.__registeredWindow){
this.window.__registeredWindow=true;
this._iframeRegHandle=dijit.registerIframe(this.iframe);
}
if(!dojo.isIE&&!dojo.isWebKit&&(this.height||dojo.isMoz)){
this.editNode=this.document.body;
}else{
this.editNode=this.document.body.firstChild;
var _b0e=this;
if(dojo.isIE){
this.tabStop=dojo.create("div",{tabIndex:-1},this.editingArea);
this.iframe.onfocus=function(){
_b0e.editNode.setActive();
};
}
}
this.focusNode=this.editNode;
var _b0f=this.events.concat(this.captureEvents);
var ap=this.iframe?this.document:this.editNode;
dojo.forEach(_b0f,function(item){
this.connect(ap,item.toLowerCase(),item);
},this);
this.connect(ap,"onmouseup","onClick");
if(dojo.isIE){
this.connect(this.document,"onmousedown","_onIEMouseDown");
this.editNode.style.zoom=1;
}else{
this.connect(this.document,"onmousedown",function(){
delete this._cursorToStart;
});
}
if(dojo.isWebKit){
this._webkitListener=this.connect(this.document,"onmouseup","onDisplayChanged");
this.connect(this.document,"onmousedown",function(e){
var t=e.target;
if(t&&(t===this.document.body||t===this.document)){
setTimeout(dojo.hitch(this,"placeCursorAtEnd"),0);
}
});
}
if(dojo.isIE){
try{
this.document.execCommand("RespectVisibilityInDesign",true,null);
}
catch(e){
}
}
this.isLoaded=true;
this.set("disabled",this.disabled);
var _b10=dojo.hitch(this,function(){
this.setValue(html);
if(this.onLoadDeferred){
this.onLoadDeferred.callback(true);
}
this.onDisplayChanged();
if(this.focusOnLoad){
dojo.addOnLoad(dojo.hitch(this,function(){
setTimeout(dojo.hitch(this,"focus"),this.updateInterval);
}));
}
this.value=this.getValue(true);
});
if(this.setValueDeferred){
this.setValueDeferred.addCallback(_b10);
}else{
_b10();
}
},onKeyDown:function(e){
if(e.keyCode===dojo.keys.TAB&&this.isTabIndent){
dojo.stopEvent(e);
if(this.queryCommandEnabled((e.shiftKey?"outdent":"indent"))){
this.execCommand((e.shiftKey?"outdent":"indent"));
}
}
if(dojo.isIE){
if(e.keyCode==dojo.keys.TAB&&!this.isTabIndent){
if(e.shiftKey&&!e.ctrlKey&&!e.altKey){
this.iframe.focus();
}else{
if(!e.shiftKey&&!e.ctrlKey&&!e.altKey){
this.tabStop.focus();
}
}
}else{
if(e.keyCode===dojo.keys.BACKSPACE&&this.document.selection.type==="Control"){
dojo.stopEvent(e);
this.execCommand("delete");
}else{
if((65<=e.keyCode&&e.keyCode<=90)||(e.keyCode>=37&&e.keyCode<=40)){
e.charCode=e.keyCode;
this.onKeyPress(e);
}
}
}
}
return true;
},onKeyUp:function(e){
return;
},setDisabled:function(_b11){
dojo.deprecated("dijit.Editor::setDisabled is deprecated","use dijit.Editor::attr(\"disabled\",boolean) instead",2);
this.set("disabled",_b11);
},_setValueAttr:function(_b12){
this.setValue(_b12);
},_setDisableSpellCheckAttr:function(_b13){
if(this.document){
dojo.attr(this.document.body,"spellcheck",!_b13);
}else{
this.onLoadDeferred.addCallback(dojo.hitch(this,function(){
dojo.attr(this.document.body,"spellcheck",!_b13);
}));
}
this._set("disableSpellCheck",_b13);
},onKeyPress:function(e){
var c=(e.keyChar&&e.keyChar.toLowerCase())||e.keyCode,_b14=this._keyHandlers[c],args=arguments;
if(_b14&&!e.altKey){
dojo.some(_b14,function(h){
if(!(h.shift^e.shiftKey)&&!(h.ctrl^(e.ctrlKey||e.metaKey))){
if(!h.handler.apply(this,args)){
e.preventDefault();
}
return true;
}
},this);
}
if(!this._onKeyHitch){
this._onKeyHitch=dojo.hitch(this,"onKeyPressed");
}
setTimeout(this._onKeyHitch,1);
return true;
},addKeyHandler:function(key,ctrl,_b15,_b16){
if(!dojo.isArray(this._keyHandlers[key])){
this._keyHandlers[key]=[];
}
this._keyHandlers[key].push({shift:_b15||false,ctrl:ctrl||false,handler:_b16});
},onKeyPressed:function(){
this.onDisplayChanged();
},onClick:function(e){
this.onDisplayChanged(e);
},_onIEMouseDown:function(e){
if(!this._focused&&!this.disabled){
this.focus();
}
},_onBlur:function(e){
this.inherited(arguments);
var _b17=this.getValue(true);
if(_b17!=this.value){
this.onChange(_b17);
}
this._set("value",_b17);
},_onFocus:function(e){
if(!this.disabled){
if(!this._disabledOK){
this.set("disabled",false);
}
this.inherited(arguments);
}
},blur:function(){
if(!dojo.isIE&&this.window.document.documentElement&&this.window.document.documentElement.focus){
this.window.document.documentElement.focus();
}else{
if(dojo.doc.body.focus){
dojo.doc.body.focus();
}
}
},focus:function(){
if(!this.isLoaded){
this.focusOnLoad=true;
return;
}
if(this._cursorToStart){
delete this._cursorToStart;
if(this.editNode.childNodes){
this.placeCursorAtStart();
return;
}
}
if(!dojo.isIE){
dijit.focus(this.iframe);
}else{
if(this.editNode&&this.editNode.focus){
this.iframe.fireEvent("onfocus",document.createEventObject());
}
}
},updateInterval:200,_updateTimer:null,onDisplayChanged:function(e){
if(this._updateTimer){
clearTimeout(this._updateTimer);
}
if(!this._updateHandler){
this._updateHandler=dojo.hitch(this,"onNormalizedDisplayChanged");
}
this._updateTimer=setTimeout(this._updateHandler,this.updateInterval);
},onNormalizedDisplayChanged:function(){
delete this._updateTimer;
},onChange:function(_b18){
},_normalizeCommand:function(cmd,_b19){
var _b1a=cmd.toLowerCase();
if(_b1a=="formatblock"){
if(dojo.isSafari&&_b19===undefined){
_b1a="heading";
}
}else{
if(_b1a=="hilitecolor"&&!dojo.isMoz){
_b1a="backcolor";
}
}
return _b1a;
},_qcaCache:{},queryCommandAvailable:function(_b1b){
var ca=this._qcaCache[_b1b];
if(ca!==undefined){
return ca;
}
return (this._qcaCache[_b1b]=this._queryCommandAvailable(_b1b));
},_queryCommandAvailable:function(_b1c){
var ie=1;
var _b1d=1<<1;
var _b1e=1<<2;
var _b1f=1<<3;
function _b20(_b21){
return {ie:Boolean(_b21&ie),mozilla:Boolean(_b21&_b1d),webkit:Boolean(_b21&_b1e),opera:Boolean(_b21&_b1f)};
};
var _b22=null;
switch(_b1c.toLowerCase()){
case "bold":
case "italic":
case "underline":
case "subscript":
case "superscript":
case "fontname":
case "fontsize":
case "forecolor":
case "hilitecolor":
case "justifycenter":
case "justifyfull":
case "justifyleft":
case "justifyright":
case "delete":
case "selectall":
case "toggledir":
_b22=_b20(_b1d|ie|_b1e|_b1f);
break;
case "createlink":
case "unlink":
case "removeformat":
case "inserthorizontalrule":
case "insertimage":
case "insertorderedlist":
case "insertunorderedlist":
case "indent":
case "outdent":
case "formatblock":
case "inserthtml":
case "undo":
case "redo":
case "strikethrough":
case "tabindent":
_b22=_b20(_b1d|ie|_b1f|_b1e);
break;
case "blockdirltr":
case "blockdirrtl":
case "dirltr":
case "dirrtl":
case "inlinedirltr":
case "inlinedirrtl":
_b22=_b20(ie);
break;
case "cut":
case "copy":
case "paste":
_b22=_b20(ie|_b1d|_b1e);
break;
case "inserttable":
_b22=_b20(_b1d|ie);
break;
case "insertcell":
case "insertcol":
case "insertrow":
case "deletecells":
case "deletecols":
case "deleterows":
case "mergecells":
case "splitcell":
_b22=_b20(ie|_b1d);
break;
default:
return false;
}
return (dojo.isIE&&_b22.ie)||(dojo.isMoz&&_b22.mozilla)||(dojo.isWebKit&&_b22.webkit)||(dojo.isOpera&&_b22.opera);
},execCommand:function(_b23,_b24){
var _b25;
this.focus();
_b23=this._normalizeCommand(_b23,_b24);
if(_b24!==undefined){
if(_b23=="heading"){
throw new Error("unimplemented");
}else{
if((_b23=="formatblock")&&dojo.isIE){
_b24="<"+_b24+">";
}
}
}
var _b26="_"+_b23+"Impl";
if(this[_b26]){
_b25=this[_b26](_b24);
}else{
_b24=arguments.length>1?_b24:null;
if(_b24||_b23!="createlink"){
_b25=this.document.execCommand(_b23,false,_b24);
}
}
this.onDisplayChanged();
return _b25;
},queryCommandEnabled:function(_b27){
if(this.disabled||!this._disabledOK){
return false;
}
_b27=this._normalizeCommand(_b27);
if(dojo.isMoz||dojo.isWebKit){
if(_b27=="unlink"){
return this._sCall("hasAncestorElement",["a"]);
}else{
if(_b27=="inserttable"){
return true;
}
}
}
if(dojo.isWebKit){
if(_b27=="cut"||_b27=="copy"){
var sel=this.window.getSelection();
if(sel){
sel=sel.toString();
}
return !!sel;
}else{
if(_b27=="paste"){
return true;
}
}
}
var elem=dojo.isIE?this.document.selection.createRange():this.document;
try{
return elem.queryCommandEnabled(_b27);
}
catch(e){
return false;
}
},queryCommandState:function(_b28){
if(this.disabled||!this._disabledOK){
return false;
}
_b28=this._normalizeCommand(_b28);
try{
return this.document.queryCommandState(_b28);
}
catch(e){
return false;
}
},queryCommandValue:function(_b29){
if(this.disabled||!this._disabledOK){
return false;
}
var r;
_b29=this._normalizeCommand(_b29);
if(dojo.isIE&&_b29=="formatblock"){
r=this._native2LocalFormatNames[this.document.queryCommandValue(_b29)];
}else{
if(dojo.isMoz&&_b29==="hilitecolor"){
var _b2a;
try{
_b2a=this.document.queryCommandValue("styleWithCSS");
}
catch(e){
_b2a=false;
}
this.document.execCommand("styleWithCSS",false,true);
r=this.document.queryCommandValue(_b29);
this.document.execCommand("styleWithCSS",false,_b2a);
}else{
r=this.document.queryCommandValue(_b29);
}
}
return r;
},_sCall:function(name,args){
return dojo.withGlobal(this.window,name,dijit._editor.selection,args);
},placeCursorAtStart:function(){
this.focus();
var _b2b=false;
if(dojo.isMoz){
var _b2c=this.editNode.firstChild;
while(_b2c){
if(_b2c.nodeType==3){
if(_b2c.nodeValue.replace(/^\s+|\s+$/g,"").length>0){
_b2b=true;
this._sCall("selectElement",[_b2c]);
break;
}
}else{
if(_b2c.nodeType==1){
_b2b=true;
var tg=_b2c.tagName?_b2c.tagName.toLowerCase():"";
if(/br|input|img|base|meta|area|basefont|hr|link/.test(tg)){
this._sCall("selectElement",[_b2c]);
}else{
this._sCall("selectElementChildren",[_b2c]);
}
break;
}
}
_b2c=_b2c.nextSibling;
}
}else{
_b2b=true;
this._sCall("selectElementChildren",[this.editNode]);
}
if(_b2b){
this._sCall("collapse",[true]);
}
},placeCursorAtEnd:function(){
this.focus();
var _b2d=false;
if(dojo.isMoz){
var last=this.editNode.lastChild;
while(last){
if(last.nodeType==3){
if(last.nodeValue.replace(/^\s+|\s+$/g,"").length>0){
_b2d=true;
this._sCall("selectElement",[last]);
break;
}
}else{
if(last.nodeType==1){
_b2d=true;
if(last.lastChild){
this._sCall("selectElement",[last.lastChild]);
}else{
this._sCall("selectElement",[last]);
}
break;
}
}
last=last.previousSibling;
}
}else{
_b2d=true;
this._sCall("selectElementChildren",[this.editNode]);
}
if(_b2d){
this._sCall("collapse",[false]);
}
},getValue:function(_b2e){
if(this.textarea){
if(this.isClosed||!this.isLoaded){
return this.textarea.value;
}
}
return this._postFilterContent(null,_b2e);
},_getValueAttr:function(){
return this.getValue(true);
},setValue:function(html){
if(!this.isLoaded){
this.onLoadDeferred.addCallback(dojo.hitch(this,function(){
this.setValue(html);
}));
return;
}
this._cursorToStart=true;
if(this.textarea&&(this.isClosed||!this.isLoaded)){
this.textarea.value=html;
}else{
html=this._preFilterContent(html);
var node=this.isClosed?this.domNode:this.editNode;
if(html&&dojo.isMoz&&html.toLowerCase()=="<p></p>"){
html="<p>&nbsp;</p>";
}
if(!html&&dojo.isWebKit){
html="&nbsp;";
}
node.innerHTML=html;
this._preDomFilterContent(node);
}
this.onDisplayChanged();
this._set("value",this.getValue(true));
},replaceValue:function(html){
if(this.isClosed){
this.setValue(html);
}else{
if(this.window&&this.window.getSelection&&!dojo.isMoz){
this.setValue(html);
}else{
if(this.window&&this.window.getSelection){
html=this._preFilterContent(html);
this.execCommand("selectall");
if(!html){
this._cursorToStart=true;
html="&nbsp;";
}
this.execCommand("inserthtml",html);
this._preDomFilterContent(this.editNode);
}else{
if(this.document&&this.document.selection){
this.setValue(html);
}
}
}
}
this._set("value",this.getValue(true));
},_preFilterContent:function(html){
var ec=html;
dojo.forEach(this.contentPreFilters,function(ef){
if(ef){
ec=ef(ec);
}
});
return ec;
},_preDomFilterContent:function(dom){
dom=dom||this.editNode;
dojo.forEach(this.contentDomPreFilters,function(ef){
if(ef&&dojo.isFunction(ef)){
ef(dom);
}
},this);
},_postFilterContent:function(dom,_b2f){
var ec;
if(!dojo.isString(dom)){
dom=dom||this.editNode;
if(this.contentDomPostFilters.length){
if(_b2f){
dom=dojo.clone(dom);
}
dojo.forEach(this.contentDomPostFilters,function(ef){
dom=ef(dom);
});
}
ec=dijit._editor.getChildrenHtml(dom);
}else{
ec=dom;
}
if(!dojo.trim(ec.replace(/^\xA0\xA0*/,"").replace(/\xA0\xA0*$/,"")).length){
ec="";
}
dojo.forEach(this.contentPostFilters,function(ef){
ec=ef(ec);
});
return ec;
},_saveContent:function(e){
var _b30=dojo.byId(dijit._scopeName+"._editor.RichText.value");
if(_b30.value){
_b30.value+=this._SEPARATOR;
}
_b30.value+=this.name+this._NAME_CONTENT_SEP+this.getValue(true);
},escapeXml:function(str,_b31){
str=str.replace(/&/gm,"&amp;").replace(/</gm,"&lt;").replace(/>/gm,"&gt;").replace(/"/gm,"&quot;");
if(!_b31){
str=str.replace(/'/gm,"&#39;");
}
return str;
},getNodeHtml:function(node){
dojo.deprecated("dijit.Editor::getNodeHtml is deprecated","use dijit._editor.getNodeHtml instead",2);
return dijit._editor.getNodeHtml(node);
},getNodeChildrenHtml:function(dom){
dojo.deprecated("dijit.Editor::getNodeChildrenHtml is deprecated","use dijit._editor.getChildrenHtml instead",2);
return dijit._editor.getChildrenHtml(dom);
},close:function(save){
if(this.isClosed){
return;
}
if(!arguments.length){
save=true;
}
if(save){
this._set("value",this.getValue(true));
}
if(this.interval){
clearInterval(this.interval);
}
if(this._webkitListener){
this.disconnect(this._webkitListener);
delete this._webkitListener;
}
if(dojo.isIE){
this.iframe.onfocus=null;
}
this.iframe._loadFunc=null;
if(this._iframeRegHandle){
dijit.unregisterIframe(this._iframeRegHandle);
delete this._iframeRegHandle;
}
if(this.textarea){
var s=this.textarea.style;
s.position="";
s.left=s.top="";
if(dojo.isIE){
s.overflow=this.__overflow;
this.__overflow=null;
}
this.textarea.value=this.value;
dojo.destroy(this.domNode);
this.domNode=this.textarea;
}else{
this.domNode.innerHTML=this.value;
}
delete this.iframe;
dojo.removeClass(this.domNode,this.baseClass);
this.isClosed=true;
this.isLoaded=false;
delete this.editNode;
delete this.focusNode;
if(this.window&&this.window._frameElement){
this.window._frameElement=null;
}
this.window=null;
this.document=null;
this.editingArea=null;
this.editorObject=null;
},destroy:function(){
if(!this.isClosed){
this.close(false);
}
this.inherited(arguments);
if(dijit._editor._globalSaveHandler){
delete dijit._editor._globalSaveHandler[this.id];
}
},_removeMozBogus:function(html){
return html.replace(/\stype="_moz"/gi,"").replace(/\s_moz_dirty=""/gi,"").replace(/_moz_resizing="(true|false)"/gi,"");
},_removeWebkitBogus:function(html){
html=html.replace(/\sclass="webkit-block-placeholder"/gi,"");
html=html.replace(/\sclass="apple-style-span"/gi,"");
html=html.replace(/<meta charset=\"utf-8\" \/>/gi,"");
return html;
},_normalizeFontStyle:function(html){
return html.replace(/<(\/)?strong([ \>])/gi,"<$1b$2").replace(/<(\/)?em([ \>])/gi,"<$1i$2");
},_preFixUrlAttributes:function(html){
return html.replace(/(?:(<a(?=\s).*?\shref=)("|')(.*?)\2)|(?:(<a\s.*?href=)([^"'][^ >]+))/gi,"$1$4$2$3$5$2 _djrealurl=$2$3$5$2").replace(/(?:(<img(?=\s).*?\ssrc=)("|')(.*?)\2)|(?:(<img\s.*?src=)([^"'][^ >]+))/gi,"$1$4$2$3$5$2 _djrealurl=$2$3$5$2");
},_inserthorizontalruleImpl:function(_b32){
if(dojo.isIE){
return this._inserthtmlImpl("<hr>");
}
return this.document.execCommand("inserthorizontalrule",false,_b32);
},_unlinkImpl:function(_b33){
if((this.queryCommandEnabled("unlink"))&&(dojo.isMoz||dojo.isWebKit)){
var a=this._sCall("getAncestorElement",["a"]);
this._sCall("selectElement",[a]);
return this.document.execCommand("unlink",false,null);
}
return this.document.execCommand("unlink",false,_b33);
},_hilitecolorImpl:function(_b34){
var _b35;
if(dojo.isMoz){
this.document.execCommand("styleWithCSS",false,true);
_b35=this.document.execCommand("hilitecolor",false,_b34);
this.document.execCommand("styleWithCSS",false,false);
}else{
_b35=this.document.execCommand("hilitecolor",false,_b34);
}
return _b35;
},_backcolorImpl:function(_b36){
if(dojo.isIE){
_b36=_b36?_b36:null;
}
return this.document.execCommand("backcolor",false,_b36);
},_forecolorImpl:function(_b37){
if(dojo.isIE){
_b37=_b37?_b37:null;
}
return this.document.execCommand("forecolor",false,_b37);
},_inserthtmlImpl:function(_b38){
_b38=this._preFilterContent(_b38);
var rv=true;
if(dojo.isIE){
var _b39=this.document.selection.createRange();
if(this.document.selection.type.toUpperCase()=="CONTROL"){
var n=_b39.item(0);
while(_b39.length){
_b39.remove(_b39.item(0));
}
n.outerHTML=_b38;
}else{
_b39.pasteHTML(_b38);
}
_b39.select();
}else{
if(dojo.isMoz&&!_b38.length){
this._sCall("remove");
}else{
rv=this.document.execCommand("inserthtml",false,_b38);
}
}
return rv;
},_boldImpl:function(_b3a){
if(dojo.isIE){
this._adaptIESelection();
}
return this.document.execCommand("bold",false,_b3a);
},_italicImpl:function(_b3b){
if(dojo.isIE){
this._adaptIESelection();
}
return this.document.execCommand("italic",false,_b3b);
},_underlineImpl:function(_b3c){
if(dojo.isIE){
this._adaptIESelection();
}
return this.document.execCommand("underline",false,_b3c);
},_strikethroughImpl:function(_b3d){
if(dojo.isIE){
this._adaptIESelection();
}
return this.document.execCommand("strikethrough",false,_b3d);
},getHeaderHeight:function(){
return this._getNodeChildrenHeight(this.header);
},getFooterHeight:function(){
return this._getNodeChildrenHeight(this.footer);
},_getNodeChildrenHeight:function(node){
var h=0;
if(node&&node.childNodes){
var i;
for(i=0;i<node.childNodes.length;i++){
var size=dojo.position(node.childNodes[i]);
h+=size.h;
}
}
return h;
},_isNodeEmpty:function(node,_b3e){
if(node.nodeType==1){
if(node.childNodes.length>0){
return this._isNodeEmpty(node.childNodes[0],_b3e);
}
return true;
}else{
if(node.nodeType==3){
return (node.nodeValue.substring(_b3e)=="");
}
}
return false;
},_removeStartingRangeFromRange:function(node,_b3f){
if(node.nextSibling){
_b3f.setStart(node.nextSibling,0);
}else{
var _b40=node.parentNode;
while(_b40&&_b40.nextSibling==null){
_b40=_b40.parentNode;
}
if(_b40){
_b3f.setStart(_b40.nextSibling,0);
}
}
return _b3f;
},_adaptIESelection:function(){
var _b41=dijit.range.getSelection(this.window);
if(_b41&&_b41.rangeCount&&!_b41.isCollapsed){
var _b42=_b41.getRangeAt(0);
var _b43=_b42.startContainer;
var _b44=_b42.startOffset;
while(_b43.nodeType==3&&_b44>=_b43.length&&_b43.nextSibling){
_b44=_b44-_b43.length;
_b43=_b43.nextSibling;
}
var _b45=null;
while(this._isNodeEmpty(_b43,_b44)&&_b43!=_b45){
_b45=_b43;
_b42=this._removeStartingRangeFromRange(_b43,_b42);
_b43=_b42.startContainer;
_b44=0;
}
_b41.removeAllRanges();
_b41.addRange(_b42);
}
}});
}
if(!dojo._hasResource["dijit.ToolbarSeparator"]){
dojo._hasResource["dijit.ToolbarSeparator"]=true;
dojo.provide("dijit.ToolbarSeparator");
dojo.declare("dijit.ToolbarSeparator",[dijit._Widget,dijit._Templated],{templateString:"<div class=\"dijitToolbarSeparator dijitInline\" role=\"presentation\"></div>",buildRendering:function(){
this.inherited(arguments);
dojo.setSelectable(this.domNode,false);
},isFocusable:function(){
return false;
}});
}
if(!dojo._hasResource["dijit.Toolbar"]){
dojo._hasResource["dijit.Toolbar"]=true;
dojo.provide("dijit.Toolbar");
dojo.declare("dijit.Toolbar",[dijit._Widget,dijit._Templated,dijit._KeyNavContainer],{templateString:"<div class=\"dijit\" role=\"toolbar\" tabIndex=\"${tabIndex}\" dojoAttachPoint=\"containerNode\">"+"</div>",baseClass:"dijitToolbar",postCreate:function(){
this.inherited(arguments);
this.connectKeyNavHandlers(this.isLeftToRight()?[dojo.keys.LEFT_ARROW]:[dojo.keys.RIGHT_ARROW],this.isLeftToRight()?[dojo.keys.RIGHT_ARROW]:[dojo.keys.LEFT_ARROW]);
},startup:function(){
if(this._started){
return;
}
this.startupKeyNavChildren();
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit._editor._Plugin"]){
dojo._hasResource["dijit._editor._Plugin"]=true;
dojo.provide("dijit._editor._Plugin");
dojo.declare("dijit._editor._Plugin",null,{constructor:function(args,node){
this.params=args||{};
dojo.mixin(this,this.params);
this._connects=[];
this._attrPairNames={};
},editor:null,iconClassPrefix:"dijitEditorIcon",button:null,command:"",useDefaultCommand:true,buttonClass:dijit.form.Button,disabled:false,getLabel:function(key){
return this.editor.commands[key];
},_initButton:function(){
if(this.command.length){
var _b46=this.getLabel(this.command),_b47=this.editor,_b48=this.iconClassPrefix+" "+this.iconClassPrefix+this.command.charAt(0).toUpperCase()+this.command.substr(1);
if(!this.button){
var _b49=dojo.mixin({label:_b46,dir:_b47.dir,lang:_b47.lang,showLabel:false,iconClass:_b48,dropDown:this.dropDown,tabIndex:"-1"},this.params||{});
this.button=new this.buttonClass(_b49);
}
}
if(this.get("disabled")&&this.button){
this.button.set("disabled",this.get("disabled"));
}
},destroy:function(){
dojo.forEach(this._connects,dojo.disconnect);
if(this.dropDown){
this.dropDown.destroyRecursive();
}
},connect:function(o,f,tf){
this._connects.push(dojo.connect(o,f,this,tf));
},updateState:function(){
var e=this.editor,c=this.command,_b4a,_b4b;
if(!e||!e.isLoaded||!c.length){
return;
}
var _b4c=this.get("disabled");
if(this.button){
try{
_b4b=!_b4c&&e.queryCommandEnabled(c);
if(this.enabled!==_b4b){
this.enabled=_b4b;
this.button.set("disabled",!_b4b);
}
if(typeof this.button.checked=="boolean"){
_b4a=e.queryCommandState(c);
if(this.checked!==_b4a){
this.checked=_b4a;
this.button.set("checked",e.queryCommandState(c));
}
}
}
catch(e){
}
}
},setEditor:function(_b4d){
this.editor=_b4d;
this._initButton();
if(this.button&&this.useDefaultCommand){
if(this.editor.queryCommandAvailable(this.command)){
this.connect(this.button,"onClick",dojo.hitch(this.editor,"execCommand",this.command,this.commandArg));
}else{
this.button.domNode.style.display="none";
}
}
this.connect(this.editor,"onNormalizedDisplayChanged","updateState");
},setToolbar:function(_b4e){
if(this.button){
_b4e.addChild(this.button);
}
},set:function(name,_b4f){
if(typeof name==="object"){
for(var x in name){
this.set(x,name[x]);
}
return this;
}
var _b50=this._getAttrNames(name);
if(this[_b50.s]){
var _b51=this[_b50.s].apply(this,Array.prototype.slice.call(arguments,1));
}else{
this._set(name,_b4f);
}
return _b51||this;
},get:function(name){
var _b52=this._getAttrNames(name);
return this[_b52.g]?this[_b52.g]():this[name];
},_setDisabledAttr:function(_b53){
this.disabled=_b53;
this.updateState();
},_getAttrNames:function(name){
var apn=this._attrPairNames;
if(apn[name]){
return apn[name];
}
var uc=name.charAt(0).toUpperCase()+name.substr(1);
return (apn[name]={s:"_set"+uc+"Attr",g:"_get"+uc+"Attr"});
},_set:function(name,_b54){
var _b55=this[name];
this[name]=_b54;
}});
}
if(!dojo._hasResource["dijit._editor.plugins.EnterKeyHandling"]){
dojo._hasResource["dijit._editor.plugins.EnterKeyHandling"]=true;
dojo.provide("dijit._editor.plugins.EnterKeyHandling");
dojo.declare("dijit._editor.plugins.EnterKeyHandling",dijit._editor._Plugin,{blockNodeForEnter:"BR",constructor:function(args){
if(args){
if("blockNodeForEnter" in args){
args.blockNodeForEnter=args.blockNodeForEnter.toUpperCase();
}
dojo.mixin(this,args);
}
},setEditor:function(_b56){
if(this.editor===_b56){
return;
}
this.editor=_b56;
if(this.blockNodeForEnter=="BR"){
this.editor.customUndo=true;
_b56.onLoadDeferred.addCallback(dojo.hitch(this,function(d){
this.connect(_b56.document,"onkeypress",function(e){
if(e.charOrCode==dojo.keys.ENTER){
var ne=dojo.mixin({},e);
ne.shiftKey=true;
if(!this.handleEnterKey(ne)){
dojo.stopEvent(e);
}
}
});
return d;
}));
}else{
if(this.blockNodeForEnter){
var h=dojo.hitch(this,this.handleEnterKey);
_b56.addKeyHandler(13,0,0,h);
_b56.addKeyHandler(13,0,1,h);
this.connect(this.editor,"onKeyPressed","onKeyPressed");
}
}
},onKeyPressed:function(e){
if(this._checkListLater){
if(dojo.withGlobal(this.editor.window,"isCollapsed",dijit)){
var _b57=dojo.withGlobal(this.editor.window,"getAncestorElement",dijit._editor.selection,["LI"]);
if(!_b57){
dijit._editor.RichText.prototype.execCommand.call(this.editor,"formatblock",this.blockNodeForEnter);
var _b58=dojo.withGlobal(this.editor.window,"getAncestorElement",dijit._editor.selection,[this.blockNodeForEnter]);
if(_b58){
_b58.innerHTML=this.bogusHtmlContent;
if(dojo.isIE){
var r=this.editor.document.selection.createRange();
r.move("character",-1);
r.select();
}
}else{
console.error("onKeyPressed: Cannot find the new block node");
}
}else{
if(dojo.isMoz){
if(_b57.parentNode.parentNode.nodeName=="LI"){
_b57=_b57.parentNode.parentNode;
}
}
var fc=_b57.firstChild;
if(fc&&fc.nodeType==1&&(fc.nodeName=="UL"||fc.nodeName=="OL")){
_b57.insertBefore(fc.ownerDocument.createTextNode(" "),fc);
var _b59=dijit.range.create(this.editor.window);
_b59.setStart(_b57.firstChild,0);
var _b5a=dijit.range.getSelection(this.editor.window,true);
_b5a.removeAllRanges();
_b5a.addRange(_b59);
}
}
}
this._checkListLater=false;
}
if(this._pressedEnterInBlock){
if(this._pressedEnterInBlock.previousSibling){
this.removeTrailingBr(this._pressedEnterInBlock.previousSibling);
}
delete this._pressedEnterInBlock;
}
},bogusHtmlContent:"&nbsp;",blockNodes:/^(?:P|H1|H2|H3|H4|H5|H6|LI)$/,handleEnterKey:function(e){
var _b5b,_b5c,_b5d,_b5e,_b5f,_b60,doc=this.editor.document,br,rs,txt;
if(e.shiftKey){
var _b61=dojo.withGlobal(this.editor.window,"getParentElement",dijit._editor.selection);
var _b62=dijit.range.getAncestor(_b61,this.blockNodes);
if(_b62){
if(_b62.tagName=="LI"){
return true;
}
_b5b=dijit.range.getSelection(this.editor.window);
_b5c=_b5b.getRangeAt(0);
if(!_b5c.collapsed){
_b5c.deleteContents();
_b5b=dijit.range.getSelection(this.editor.window);
_b5c=_b5b.getRangeAt(0);
}
if(dijit.range.atBeginningOfContainer(_b62,_b5c.startContainer,_b5c.startOffset)){
br=doc.createElement("br");
_b5d=dijit.range.create(this.editor.window);
_b62.insertBefore(br,_b62.firstChild);
_b5d.setStartBefore(br.nextSibling);
_b5b.removeAllRanges();
_b5b.addRange(_b5d);
}else{
if(dijit.range.atEndOfContainer(_b62,_b5c.startContainer,_b5c.startOffset)){
_b5d=dijit.range.create(this.editor.window);
br=doc.createElement("br");
_b62.appendChild(br);
_b62.appendChild(doc.createTextNode(" "));
_b5d.setStart(_b62.lastChild,0);
_b5b.removeAllRanges();
_b5b.addRange(_b5d);
}else{
rs=_b5c.startContainer;
if(rs&&rs.nodeType==3){
txt=rs.nodeValue;
dojo.withGlobal(this.editor.window,function(){
_b5e=doc.createTextNode(txt.substring(0,_b5c.startOffset));
_b5f=doc.createTextNode(txt.substring(_b5c.startOffset));
_b60=doc.createElement("br");
if(_b5f.nodeValue==""&&dojo.isWebKit){
_b5f=doc.createTextNode(" ");
}
dojo.place(_b5e,rs,"after");
dojo.place(_b60,_b5e,"after");
dojo.place(_b5f,_b60,"after");
dojo.destroy(rs);
_b5d=dijit.range.create(dojo.gobal);
_b5d.setStart(_b5f,0);
_b5b.removeAllRanges();
_b5b.addRange(_b5d);
});
return false;
}
return true;
}
}
}else{
_b5b=dijit.range.getSelection(this.editor.window);
if(_b5b.rangeCount){
_b5c=_b5b.getRangeAt(0);
if(_b5c&&_b5c.startContainer){
if(!_b5c.collapsed){
_b5c.deleteContents();
_b5b=dijit.range.getSelection(this.editor.window);
_b5c=_b5b.getRangeAt(0);
}
rs=_b5c.startContainer;
if(rs&&rs.nodeType==3){
dojo.withGlobal(this.editor.window,dojo.hitch(this,function(){
var _b63=false;
var _b64=_b5c.startOffset;
if(rs.length<_b64){
ret=this._adjustNodeAndOffset(rs,_b64);
rs=ret.node;
_b64=ret.offset;
}
txt=rs.nodeValue;
_b5e=doc.createTextNode(txt.substring(0,_b64));
_b5f=doc.createTextNode(txt.substring(_b64));
_b60=doc.createElement("br");
if(!_b5f.length){
_b5f=doc.createTextNode(" ");
_b63=true;
}
if(_b5e.length){
dojo.place(_b5e,rs,"after");
}else{
_b5e=rs;
}
dojo.place(_b60,_b5e,"after");
dojo.place(_b5f,_b60,"after");
dojo.destroy(rs);
_b5d=dijit.range.create(dojo.gobal);
_b5d.setStart(_b5f,0);
_b5d.setEnd(_b5f,_b5f.length);
_b5b.removeAllRanges();
_b5b.addRange(_b5d);
if(_b63&&!dojo.isWebKit){
dijit._editor.selection.remove();
}else{
dijit._editor.selection.collapse(true);
}
}));
}else{
var _b65;
if(_b5c.startOffset>=0){
_b65=rs.childNodes[_b5c.startOffset];
}
dojo.withGlobal(this.editor.window,dojo.hitch(this,function(){
var _b66=doc.createElement("br");
var _b67=doc.createTextNode(" ");
if(!_b65){
rs.appendChild(_b66);
rs.appendChild(_b67);
}else{
dojo.place(_b66,_b65,"before");
dojo.place(_b67,_b66,"after");
}
_b5d=dijit.range.create(dojo.global);
_b5d.setStart(_b67,0);
_b5d.setEnd(_b67,_b67.length);
_b5b.removeAllRanges();
_b5b.addRange(_b5d);
dijit._editor.selection.collapse(true);
}));
}
}
}else{
dijit._editor.RichText.prototype.execCommand.call(this.editor,"inserthtml","<br>");
}
}
return false;
}
var _b68=true;
_b5b=dijit.range.getSelection(this.editor.window);
_b5c=_b5b.getRangeAt(0);
if(!_b5c.collapsed){
_b5c.deleteContents();
_b5b=dijit.range.getSelection(this.editor.window);
_b5c=_b5b.getRangeAt(0);
}
var _b69=dijit.range.getBlockAncestor(_b5c.endContainer,null,this.editor.editNode);
var _b6a=_b69.blockNode;
if((this._checkListLater=(_b6a&&(_b6a.nodeName=="LI"||_b6a.parentNode.nodeName=="LI")))){
if(dojo.isMoz){
this._pressedEnterInBlock=_b6a;
}
if(/^(\s|&nbsp;|\xA0|<span\b[^>]*\bclass=['"]Apple-style-span['"][^>]*>(\s|&nbsp;|\xA0)<\/span>)?(<br>)?$/.test(_b6a.innerHTML)){
_b6a.innerHTML="";
if(dojo.isWebKit){
_b5d=dijit.range.create(this.editor.window);
_b5d.setStart(_b6a,0);
_b5b.removeAllRanges();
_b5b.addRange(_b5d);
}
this._checkListLater=false;
}
return true;
}
if(!_b69.blockNode||_b69.blockNode===this.editor.editNode){
try{
dijit._editor.RichText.prototype.execCommand.call(this.editor,"formatblock",this.blockNodeForEnter);
}
catch(e2){
}
_b69={blockNode:dojo.withGlobal(this.editor.window,"getAncestorElement",dijit._editor.selection,[this.blockNodeForEnter]),blockContainer:this.editor.editNode};
if(_b69.blockNode){
if(_b69.blockNode!=this.editor.editNode&&(!(_b69.blockNode.textContent||_b69.blockNode.innerHTML).replace(/^\s+|\s+$/g,"").length)){
this.removeTrailingBr(_b69.blockNode);
return false;
}
}else{
_b69.blockNode=this.editor.editNode;
}
_b5b=dijit.range.getSelection(this.editor.window);
_b5c=_b5b.getRangeAt(0);
}
var _b6b=doc.createElement(this.blockNodeForEnter);
_b6b.innerHTML=this.bogusHtmlContent;
this.removeTrailingBr(_b69.blockNode);
var _b6c=_b5c.endOffset;
var node=_b5c.endContainer;
if(node.length<_b6c){
var ret=this._adjustNodeAndOffset(node,_b6c);
node=ret.node;
_b6c=ret.offset;
}
if(dijit.range.atEndOfContainer(_b69.blockNode,node,_b6c)){
if(_b69.blockNode===_b69.blockContainer){
_b69.blockNode.appendChild(_b6b);
}else{
dojo.place(_b6b,_b69.blockNode,"after");
}
_b68=false;
_b5d=dijit.range.create(this.editor.window);
_b5d.setStart(_b6b,0);
_b5b.removeAllRanges();
_b5b.addRange(_b5d);
if(this.editor.height){
dojo.window.scrollIntoView(_b6b);
}
}else{
if(dijit.range.atBeginningOfContainer(_b69.blockNode,_b5c.startContainer,_b5c.startOffset)){
dojo.place(_b6b,_b69.blockNode,_b69.blockNode===_b69.blockContainer?"first":"before");
if(_b6b.nextSibling&&this.editor.height){
_b5d=dijit.range.create(this.editor.window);
_b5d.setStart(_b6b.nextSibling,0);
_b5b.removeAllRanges();
_b5b.addRange(_b5d);
dojo.window.scrollIntoView(_b6b.nextSibling);
}
_b68=false;
}else{
if(_b69.blockNode===_b69.blockContainer){
_b69.blockNode.appendChild(_b6b);
}else{
dojo.place(_b6b,_b69.blockNode,"after");
}
_b68=false;
if(_b69.blockNode.style){
if(_b6b.style){
if(_b69.blockNode.style.cssText){
_b6b.style.cssText=_b69.blockNode.style.cssText;
}
}
}
rs=_b5c.startContainer;
var _b6d;
if(rs&&rs.nodeType==3){
var _b6e,_b6f;
_b6c=_b5c.endOffset;
if(rs.length<_b6c){
ret=this._adjustNodeAndOffset(rs,_b6c);
rs=ret.node;
_b6c=ret.offset;
}
txt=rs.nodeValue;
_b5e=doc.createTextNode(txt.substring(0,_b6c));
_b5f=doc.createTextNode(txt.substring(_b6c,txt.length));
dojo.place(_b5e,rs,"before");
dojo.place(_b5f,rs,"after");
dojo.destroy(rs);
var _b70=_b5e.parentNode;
while(_b70!==_b69.blockNode){
var tg=_b70.tagName;
var _b71=doc.createElement(tg);
if(_b70.style){
if(_b71.style){
if(_b70.style.cssText){
_b71.style.cssText=_b70.style.cssText;
}
}
}
if(_b70.tagName==="FONT"){
if(_b70.color){
_b71.color=_b70.color;
}
if(_b70.face){
_b71.face=_b70.face;
}
if(_b70.size){
_b71.size=_b70.size;
}
}
_b6e=_b5f;
while(_b6e){
_b6f=_b6e.nextSibling;
_b71.appendChild(_b6e);
_b6e=_b6f;
}
dojo.place(_b71,_b70,"after");
_b5e=_b70;
_b5f=_b71;
_b70=_b70.parentNode;
}
_b6e=_b5f;
if(_b6e.nodeType==1||(_b6e.nodeType==3&&_b6e.nodeValue)){
_b6b.innerHTML="";
}
_b6d=_b6e;
while(_b6e){
_b6f=_b6e.nextSibling;
_b6b.appendChild(_b6e);
_b6e=_b6f;
}
}
_b5d=dijit.range.create(this.editor.window);
var _b72;
var _b73=_b6d;
if(this.blockNodeForEnter!=="BR"){
while(_b73){
_b72=_b73;
_b6f=_b73.firstChild;
_b73=_b6f;
}
if(_b72&&_b72.parentNode){
_b6b=_b72.parentNode;
_b5d.setStart(_b6b,0);
_b5b.removeAllRanges();
_b5b.addRange(_b5d);
if(this.editor.height){
dijit.scrollIntoView(_b6b);
}
if(dojo.isMoz){
this._pressedEnterInBlock=_b69.blockNode;
}
}else{
_b68=true;
}
}else{
_b5d.setStart(_b6b,0);
_b5b.removeAllRanges();
_b5b.addRange(_b5d);
if(this.editor.height){
dijit.scrollIntoView(_b6b);
}
if(dojo.isMoz){
this._pressedEnterInBlock=_b69.blockNode;
}
}
}
}
return _b68;
},_adjustNodeAndOffset:function(node,_b74){
while(node.length<_b74&&node.nextSibling&&node.nextSibling.nodeType==3){
_b74=_b74-node.length;
node=node.nextSibling;
}
var ret={"node":node,"offset":_b74};
return ret;
},removeTrailingBr:function(_b75){
var para=/P|DIV|LI/i.test(_b75.tagName)?_b75:dijit._editor.selection.getParentOfType(_b75,["P","DIV","LI"]);
if(!para){
return;
}
if(para.lastChild){
if((para.childNodes.length>1&&para.lastChild.nodeType==3&&/^[\s\xAD]*$/.test(para.lastChild.nodeValue))||para.lastChild.tagName=="BR"){
dojo.destroy(para.lastChild);
}
}
if(!para.childNodes.length){
para.innerHTML=this.bogusHtmlContent;
}
}});
}
if(!dojo._hasResource["dijit.Editor"]){
dojo._hasResource["dijit.Editor"]=true;
dojo.provide("dijit.Editor");
dojo.declare("dijit.Editor",dijit._editor.RichText,{plugins:null,extraPlugins:null,constructor:function(){
if(!dojo.isArray(this.plugins)){
this.plugins=["undo","redo","|","cut","copy","paste","|","bold","italic","underline","strikethrough","|","insertOrderedList","insertUnorderedList","indent","outdent","|","justifyLeft","justifyRight","justifyCenter","justifyFull","dijit._editor.plugins.EnterKeyHandling"];
}
this._plugins=[];
this._editInterval=this.editActionInterval*1000;
if(dojo.isIE){
this.events.push("onBeforeDeactivate");
this.events.push("onBeforeActivate");
}
},postMixInProperties:function(){
this.setValueDeferred=new dojo.Deferred();
this.inherited(arguments);
},postCreate:function(){
this._steps=this._steps.slice(0);
this._undoedSteps=this._undoedSteps.slice(0);
if(dojo.isArray(this.extraPlugins)){
this.plugins=this.plugins.concat(this.extraPlugins);
}
this.inherited(arguments);
this.commands=dojo.i18n.getLocalization("dijit._editor","commands",this.lang);
if(!this.toolbar){
this.toolbar=new dijit.Toolbar({dir:this.dir,lang:this.lang});
this.header.appendChild(this.toolbar.domNode);
}
dojo.forEach(this.plugins,this.addPlugin,this);
this.setValueDeferred.callback(true);
dojo.addClass(this.iframe.parentNode,"dijitEditorIFrameContainer");
dojo.addClass(this.iframe,"dijitEditorIFrame");
dojo.attr(this.iframe,"allowTransparency",true);
if(dojo.isWebKit){
dojo.style(this.domNode,"KhtmlUserSelect","none");
}
this.toolbar.startup();
this.onNormalizedDisplayChanged();
},destroy:function(){
dojo.forEach(this._plugins,function(p){
if(p&&p.destroy){
p.destroy();
}
});
this._plugins=[];
this.toolbar.destroyRecursive();
delete this.toolbar;
this.inherited(arguments);
},addPlugin:function(_b76,_b77){
var args=dojo.isString(_b76)?{name:_b76}:_b76;
if(!args.setEditor){
var o={"args":args,"plugin":null,"editor":this};
dojo.publish(dijit._scopeName+".Editor.getPlugin",[o]);
if(!o.plugin){
var pc=dojo.getObject(args.name);
if(pc){
o.plugin=new pc(args);
}
}
if(!o.plugin){
console.warn("Cannot find plugin",_b76);
return;
}
_b76=o.plugin;
}
if(arguments.length>1){
this._plugins[_b77]=_b76;
}else{
this._plugins.push(_b76);
}
_b76.setEditor(this);
if(dojo.isFunction(_b76.setToolbar)){
_b76.setToolbar(this.toolbar);
}
},startup:function(){
},resize:function(size){
if(size){
dijit.layout._LayoutWidget.prototype.resize.apply(this,arguments);
}
},layout:function(){
var _b78=(this._contentBox.h-(this.getHeaderHeight()+this.getFooterHeight()+dojo._getPadBorderExtents(this.iframe.parentNode).h+dojo._getMarginExtents(this.iframe.parentNode).h));
this.editingArea.style.height=_b78+"px";
if(this.iframe){
this.iframe.style.height="100%";
}
this._layoutMode=true;
},_onIEMouseDown:function(e){
var _b79;
var b=this.document.body;
var _b7a=b.clientWidth;
var _b7b=b.clientHeight;
var _b7c=b.clientLeft;
var _b7d=b.offsetWidth;
var _b7e=b.offsetHeight;
var _b7f=b.offsetLeft;
bodyDir=b.dir?b.dir.toLowerCase():"";
if(bodyDir!="rtl"){
if(_b7a<_b7d&&e.x>_b7a&&e.x<_b7d){
_b79=true;
}
}else{
if(e.x<_b7c&&e.x>_b7f){
_b79=true;
}
}
if(!_b79){
if(_b7b<_b7e&&e.y>_b7b&&e.y<_b7e){
_b79=true;
}
}
if(!_b79){
delete this._cursorToStart;
delete this._savedSelection;
if(e.target.tagName=="BODY"){
setTimeout(dojo.hitch(this,"placeCursorAtEnd"),0);
}
this.inherited(arguments);
}
},onBeforeActivate:function(e){
this._restoreSelection();
},onBeforeDeactivate:function(e){
if(this.customUndo){
this.endEditing(true);
}
if(e.target.tagName!="BODY"){
this._saveSelection();
}
},customUndo:true,editActionInterval:3,beginEditing:function(cmd){
if(!this._inEditing){
this._inEditing=true;
this._beginEditing(cmd);
}
if(this.editActionInterval>0){
if(this._editTimer){
clearTimeout(this._editTimer);
}
this._editTimer=setTimeout(dojo.hitch(this,this.endEditing),this._editInterval);
}
},_steps:[],_undoedSteps:[],execCommand:function(cmd){
if(this.customUndo&&(cmd=="undo"||cmd=="redo")){
return this[cmd]();
}else{
if(this.customUndo){
this.endEditing();
this._beginEditing();
}
var r;
var _b80=/copy|cut|paste/.test(cmd);
try{
r=this.inherited(arguments);
if(dojo.isWebKit&&_b80&&!r){
throw {code:1011};
}
}
catch(e){
if(e.code==1011&&_b80){
var sub=dojo.string.substitute,_b81={cut:"X",copy:"C",paste:"V"};
alert(sub(this.commands.systemShortcut,[this.commands[cmd],sub(this.commands[dojo.isMac?"appleKey":"ctrlKey"],[_b81[cmd]])]));
}
r=false;
}
if(this.customUndo){
this._endEditing();
}
return r;
}
},queryCommandEnabled:function(cmd){
if(this.customUndo&&(cmd=="undo"||cmd=="redo")){
return cmd=="undo"?(this._steps.length>1):(this._undoedSteps.length>0);
}else{
return this.inherited(arguments);
}
},_moveToBookmark:function(b){
var _b82=b.mark;
var mark=b.mark;
var col=b.isCollapsed;
var r,_b83,_b84,sel;
if(mark){
if(dojo.isIE<9){
if(dojo.isArray(mark)){
_b82=[];
dojo.forEach(mark,function(n){
_b82.push(dijit.range.getNode(n,this.editNode));
},this);
dojo.withGlobal(this.window,"moveToBookmark",dijit,[{mark:_b82,isCollapsed:col}]);
}else{
if(mark.startContainer&&mark.endContainer){
sel=dijit.range.getSelection(this.window);
if(sel&&sel.removeAllRanges){
sel.removeAllRanges();
r=dijit.range.create(this.window);
_b83=dijit.range.getNode(mark.startContainer,this.editNode);
_b84=dijit.range.getNode(mark.endContainer,this.editNode);
if(_b83&&_b84){
r.setStart(_b83,mark.startOffset);
r.setEnd(_b84,mark.endOffset);
sel.addRange(r);
}
}
}
}
}else{
sel=dijit.range.getSelection(this.window);
if(sel&&sel.removeAllRanges){
sel.removeAllRanges();
r=dijit.range.create(this.window);
_b83=dijit.range.getNode(mark.startContainer,this.editNode);
_b84=dijit.range.getNode(mark.endContainer,this.editNode);
if(_b83&&_b84){
r.setStart(_b83,mark.startOffset);
r.setEnd(_b84,mark.endOffset);
sel.addRange(r);
}
}
}
}
},_changeToStep:function(from,to){
this.setValue(to.text);
var b=to.bookmark;
if(!b){
return;
}
this._moveToBookmark(b);
},undo:function(){
var ret=false;
if(!this._undoRedoActive){
this._undoRedoActive=true;
this.endEditing(true);
var s=this._steps.pop();
if(s&&this._steps.length>0){
this.focus();
this._changeToStep(s,this._steps[this._steps.length-1]);
this._undoedSteps.push(s);
this.onDisplayChanged();
delete this._undoRedoActive;
ret=true;
}
delete this._undoRedoActive;
}
return ret;
},redo:function(){
var ret=false;
if(!this._undoRedoActive){
this._undoRedoActive=true;
this.endEditing(true);
var s=this._undoedSteps.pop();
if(s&&this._steps.length>0){
this.focus();
this._changeToStep(this._steps[this._steps.length-1],s);
this._steps.push(s);
this.onDisplayChanged();
ret=true;
}
delete this._undoRedoActive;
}
return ret;
},endEditing:function(_b85){
if(this._editTimer){
clearTimeout(this._editTimer);
}
if(this._inEditing){
this._endEditing(_b85);
this._inEditing=false;
}
},_getBookmark:function(){
var b=dojo.withGlobal(this.window,dijit.getBookmark);
var tmp=[];
if(b&&b.mark){
var mark=b.mark;
if(dojo.isIE<9){
var sel=dijit.range.getSelection(this.window);
if(!dojo.isArray(mark)){
if(sel){
var _b86;
if(sel.rangeCount){
_b86=sel.getRangeAt(0);
}
if(_b86){
b.mark=_b86.cloneRange();
}else{
b.mark=dojo.withGlobal(this.window,dijit.getBookmark);
}
}
}else{
dojo.forEach(b.mark,function(n){
tmp.push(dijit.range.getIndex(n,this.editNode).o);
},this);
b.mark=tmp;
}
}
try{
if(b.mark&&b.mark.startContainer){
tmp=dijit.range.getIndex(b.mark.startContainer,this.editNode).o;
b.mark={startContainer:tmp,startOffset:b.mark.startOffset,endContainer:b.mark.endContainer===b.mark.startContainer?tmp:dijit.range.getIndex(b.mark.endContainer,this.editNode).o,endOffset:b.mark.endOffset};
}
}
catch(e){
b.mark=null;
}
}
return b;
},_beginEditing:function(cmd){
if(this._steps.length===0){
this._steps.push({"text":dijit._editor.getChildrenHtml(this.editNode),"bookmark":this._getBookmark()});
}
},_endEditing:function(_b87){
var v=dijit._editor.getChildrenHtml(this.editNode);
this._undoedSteps=[];
this._steps.push({text:v,bookmark:this._getBookmark()});
},onKeyDown:function(e){
if(!dojo.isIE&&!this.iframe&&e.keyCode==dojo.keys.TAB&&!this.tabIndent){
this._saveSelection();
}
if(!this.customUndo){
this.inherited(arguments);
return;
}
var k=e.keyCode,ks=dojo.keys;
if(e.ctrlKey&&!e.altKey){
if(k==90||k==122){
dojo.stopEvent(e);
this.undo();
return;
}else{
if(k==89||k==121){
dojo.stopEvent(e);
this.redo();
return;
}
}
}
this.inherited(arguments);
switch(k){
case ks.ENTER:
case ks.BACKSPACE:
case ks.DELETE:
this.beginEditing();
break;
case 88:
case 86:
if(e.ctrlKey&&!e.altKey&&!e.metaKey){
this.endEditing();
if(e.keyCode==88){
this.beginEditing("cut");
setTimeout(dojo.hitch(this,this.endEditing),1);
}else{
this.beginEditing("paste");
setTimeout(dojo.hitch(this,this.endEditing),1);
}
break;
}
default:
if(!e.ctrlKey&&!e.altKey&&!e.metaKey&&(e.keyCode<dojo.keys.F1||e.keyCode>dojo.keys.F15)){
this.beginEditing();
break;
}
case ks.ALT:
this.endEditing();
break;
case ks.UP_ARROW:
case ks.DOWN_ARROW:
case ks.LEFT_ARROW:
case ks.RIGHT_ARROW:
case ks.HOME:
case ks.END:
case ks.PAGE_UP:
case ks.PAGE_DOWN:
this.endEditing(true);
break;
case ks.CTRL:
case ks.SHIFT:
case ks.TAB:
break;
}
},_onBlur:function(){
this.inherited(arguments);
this.endEditing(true);
},_saveSelection:function(){
try{
this._savedSelection=this._getBookmark();
}
catch(e){
}
},_restoreSelection:function(){
if(this._savedSelection){
delete this._cursorToStart;
if(dojo.withGlobal(this.window,"isCollapsed",dijit)){
this._moveToBookmark(this._savedSelection);
}
delete this._savedSelection;
}
},onClick:function(){
this.endEditing(true);
this.inherited(arguments);
},replaceValue:function(html){
if(!this.customUndo){
this.inherited(arguments);
}else{
if(this.isClosed){
this.setValue(html);
}else{
this.beginEditing();
if(!html){
html="&nbsp;";
}
this.setValue(html);
this.endEditing();
}
}
},_setDisabledAttr:function(_b88){
var _b89=dojo.hitch(this,function(){
if((!this.disabled&&_b88)||(!this._buttonEnabledPlugins&&_b88)){
dojo.forEach(this._plugins,function(p){
p.set("disabled",true);
});
}else{
if(this.disabled&&!_b88){
dojo.forEach(this._plugins,function(p){
p.set("disabled",false);
});
}
}
});
this.setValueDeferred.addCallback(_b89);
this.inherited(arguments);
},_setStateClass:function(){
try{
this.inherited(arguments);
if(this.document&&this.document.body){
dojo.style(this.document.body,"color",dojo.style(this.iframe,"color"));
}
}
catch(e){
}
}});
dojo.subscribe(dijit._scopeName+".Editor.getPlugin",null,function(o){
if(o.plugin){
return;
}
var args=o.args,p;
var _b8a=dijit._editor._Plugin;
var name=args.name;
switch(name){
case "undo":
case "redo":
case "cut":
case "copy":
case "paste":
case "insertOrderedList":
case "insertUnorderedList":
case "indent":
case "outdent":
case "justifyCenter":
case "justifyFull":
case "justifyLeft":
case "justifyRight":
case "delete":
case "selectAll":
case "removeFormat":
case "unlink":
case "insertHorizontalRule":
p=new _b8a({command:name});
break;
case "bold":
case "italic":
case "underline":
case "strikethrough":
case "subscript":
case "superscript":
p=new _b8a({buttonClass:dijit.form.ToggleButton,command:name});
break;
case "|":
p=new _b8a({button:new dijit.ToolbarSeparator(),setEditor:function(_b8b){
this.editor=_b8b;
}});
}
o.plugin=p;
});
}
if(!dojo._hasResource["dojox.grid.cells.dijit"]){
dojo._hasResource["dojox.grid.cells.dijit"]=true;
dojo.provide("dojox.grid.cells.dijit");
(function(){
var dgc=dojox.grid.cells;
dojo.declare("dojox.grid.cells._Widget",dgc._Base,{widgetClass:dijit.form.TextBox,constructor:function(_b8c){
this.widget=null;
if(typeof this.widgetClass=="string"){
dojo.deprecated("Passing a string to widgetClass is deprecated","pass the widget class object instead","2.0");
this.widgetClass=dojo.getObject(this.widgetClass);
}
},formatEditing:function(_b8d,_b8e){
this.needFormatNode(_b8d,_b8e);
return "<div></div>";
},getValue:function(_b8f){
return this.widget.get("value");
},_unescapeHTML:function(_b90){
return (_b90&&_b90.replace&&this.grid.escapeHTMLInData)?_b90.replace(/&lt;/g,"<").replace(/&amp;/g,"&"):_b90;
},setValue:function(_b91,_b92){
if(this.widget&&this.widget.set){
_b92=this._unescapeHTML(_b92);
if(this.widget.onLoadDeferred){
var self=this;
this.widget.onLoadDeferred.addCallback(function(){
self.widget.set("value",_b92===null?"":_b92);
});
}else{
this.widget.set("value",_b92);
}
}else{
this.inherited(arguments);
}
},getWidgetProps:function(_b93){
return dojo.mixin({dir:this.dir,lang:this.lang},this.widgetProps||{},{constraints:dojo.mixin({},this.constraint)||{},value:this._unescapeHTML(_b93)});
},createWidget:function(_b94,_b95,_b96){
return new this.widgetClass(this.getWidgetProps(_b95),_b94);
},attachWidget:function(_b97,_b98,_b99){
_b97.appendChild(this.widget.domNode);
this.setValue(_b99,_b98);
},formatNode:function(_b9a,_b9b,_b9c){
if(!this.widgetClass){
return _b9b;
}
if(!this.widget){
this.widget=this.createWidget.apply(this,arguments);
}else{
this.attachWidget.apply(this,arguments);
}
this.sizeWidget.apply(this,arguments);
this.grid.views.renormalizeRow(_b9c);
this.grid.scroller.rowHeightChanged(_b9c,true);
this.focus();
return undefined;
},sizeWidget:function(_b9d,_b9e,_b9f){
var c=this.widget.declaredClass;
if(c!="dijit.form.CheckBox"&&c!="dijit.form.RadioButton"){
dojo.marginBox(this.widget.domNode,{w:dojo.contentBox(this.getNode(_b9f)).w});
}
},focus:function(_ba0,_ba1){
if(this.widget){
setTimeout(dojo.hitch(this.widget,function(){
dojox.grid.util.fire(this,"focus");
}),0);
}
},_finish:function(_ba2){
this.inherited(arguments);
dojox.grid.util.removeNode(this.widget.domNode);
if(dojo.isIE){
dojo.setSelectable(this.widget.domNode,true);
}
}});
dgc._Widget.markupFactory=function(node,cell){
dgc._Base.markupFactory(node,cell);
var d=dojo;
var _ba3=d.trim(d.attr(node,"widgetProps")||"");
var _ba4=d.trim(d.attr(node,"constraint")||"");
var _ba5=d.trim(d.attr(node,"widgetClass")||"");
if(_ba3){
cell.widgetProps=d.fromJson(_ba3);
}
if(_ba4){
cell.constraint=d.fromJson(_ba4);
}
if(_ba5){
cell.widgetClass=d.getObject(_ba5);
}
};
dojo.declare("dojox.grid.cells.ComboBox",dgc._Widget,{widgetClass:dijit.form.ComboBox,getWidgetProps:function(_ba6){
var _ba7=[];
dojo.forEach(this.options,function(o){
_ba7.push({name:o,value:o});
});
var _ba8=new dojo.data.ItemFileReadStore({data:{identifier:"name",items:_ba7}});
return dojo.mixin({},this.widgetProps||{},{value:_ba6,store:_ba8});
},getValue:function(){
var e=this.widget;
e.set("displayedValue",e.get("displayedValue"));
return e.get("value");
}});
dgc.ComboBox.markupFactory=function(node,cell){
dgc._Widget.markupFactory(node,cell);
var d=dojo;
var _ba9=d.trim(d.attr(node,"options")||"");
if(_ba9){
var o=_ba9.split(",");
if(o[0]!=_ba9){
cell.options=o;
}
}
};
dojo.declare("dojox.grid.cells.DateTextBox",dgc._Widget,{widgetClass:dijit.form.DateTextBox,setValue:function(_baa,_bab){
if(this.widget){
this.widget.set("value",new Date(_bab));
}else{
this.inherited(arguments);
}
},getWidgetProps:function(_bac){
return dojo.mixin(this.inherited(arguments),{value:new Date(_bac)});
}});
dgc.DateTextBox.markupFactory=function(node,cell){
dgc._Widget.markupFactory(node,cell);
};
dojo.declare("dojox.grid.cells.CheckBox",dgc._Widget,{widgetClass:dijit.form.CheckBox,getValue:function(){
return this.widget.checked;
},setValue:function(_bad,_bae){
if(this.widget&&this.widget.attributeMap.checked){
this.widget.set("checked",_bae);
}else{
this.inherited(arguments);
}
},sizeWidget:function(_baf,_bb0,_bb1){
return;
}});
dgc.CheckBox.markupFactory=function(node,cell){
dgc._Widget.markupFactory(node,cell);
};
dojo.declare("dojox.grid.cells.Editor",dgc._Widget,{widgetClass:dijit.Editor,getWidgetProps:function(_bb2){
return dojo.mixin({},this.widgetProps||{},{height:this.widgetHeight||"100px"});
},createWidget:function(_bb3,_bb4,_bb5){
var _bb6=new this.widgetClass(this.getWidgetProps(_bb4),_bb3);
dojo.connect(_bb6,"onLoad",dojo.hitch(this,"populateEditor"));
return _bb6;
},formatNode:function(_bb7,_bb8,_bb9){
this.content=_bb8;
this.inherited(arguments);
if(dojo.isMoz){
var e=this.widget;
e.open();
if(this.widgetToolbar){
dojo.place(e.toolbar.domNode,e.editingArea,"before");
}
}
},populateEditor:function(){
this.widget.set("value",this.content);
this.widget.placeCursorAtEnd();
}});
dgc.Editor.markupFactory=function(node,cell){
dgc._Widget.markupFactory(node,cell);
var d=dojo;
var h=dojo.trim(dojo.attr(node,"widgetHeight")||"");
if(h){
if((h!="auto")&&(h.substr(-2)!="em")){
h=parseInt(h,10)+"px";
}
cell.widgetHeight=h;
}
};
})();
}
if(!dojo._hasResource["dojox.html.ellipsis"]){
dojo._hasResource["dojox.html.ellipsis"]=true;
dojo.provide("dojox.html.ellipsis");
(function(d){
if(d.isMoz){
var _bba=1;
if("dojoxFFEllipsisDelay" in d.config){
_bba=Number(d.config.dojoxFFEllipsisDelay);
if(isNaN(_bba)){
_bba=1;
}
}
try{
var _bbb=(function(){
var sNS="http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul";
var xml=document.createElementNS(sNS,"window");
var _bbc=document.createElementNS(sNS,"description");
_bbc.setAttribute("crop","end");
xml.appendChild(_bbc);
return function(n){
var x=xml.cloneNode(true);
x.firstChild.setAttribute("value",n.textContent);
n.innerHTML="";
n.appendChild(x);
};
})();
}
catch(e){
}
var _bbd=d.create;
var dd=d.doc;
var dp=d.place;
var _bbe=_bbd("iframe",{className:"dojoxEllipsisIFrame",src:"javascript:'<html><head><script>if(\"loadFirebugConsole\" in window){window.loadFirebugConsole();}</script></head><body></body></html>'"});
var _bbf=function(r,cnt){
if(r.collapsed){
return;
}
if(cnt>0){
do{
_bbf(r);
cnt--;
}while(cnt);
return;
}
if(r.endContainer.nodeType==3&&r.endOffset>0){
r.setEnd(r.endContainer,r.endOffset-1);
}else{
if(r.endContainer.nodeType==3){
r.setEndBefore(r.endContainer);
_bbf(r);
return;
}else{
if(r.endOffset&&r.endContainer.childNodes.length>=r.endOffset){
var _bc0=r.endContainer.childNodes[r.endOffset-1];
if(_bc0.nodeType==3){
r.setEnd(_bc0,_bc0.length-1);
}else{
if(_bc0.childNodes.length){
r.setEnd(_bc0,_bc0.childNodes.length);
_bbf(r);
return;
}else{
r.setEndBefore(_bc0);
_bbf(r);
return;
}
}
}else{
r.setEndBefore(r.endContainer);
_bbf(r);
return;
}
}
}
};
var _bc1=function(n){
var c=_bbd("div",{className:"dojoxEllipsisContainer"});
var e=_bbd("div",{className:"dojoxEllipsisShown",style:{display:"none"}});
n.parentNode.replaceChild(c,n);
c.appendChild(n);
c.appendChild(e);
var i=_bbe.cloneNode(true);
var ns=n.style;
var es=e.style;
var _bc2;
var _bc3=function(){
ns.display="";
es.display="none";
if(n.scrollWidth<=n.offsetWidth){
return;
}
var r=dd.createRange();
r.selectNodeContents(n);
ns.display="none";
es.display="";
var done=false;
do{
var _bc4=1;
dp(r.cloneContents(),e,"only");
var sw=e.scrollWidth,ow=e.offsetWidth;
done=(sw<=ow);
var pct=(1-((ow*1)/sw));
if(pct>0){
_bc4=Math.max(Math.round(e.textContent.length*pct)-1,1);
}
_bbf(r,_bc4);
}while(!r.collapsed&&!done);
};
i.onload=function(){
i.contentWindow.onresize=_bc3;
_bc3();
};
c.appendChild(i);
};
var hc=d.hasClass;
var doc=d.doc;
var s,fn,opt;
if(doc.querySelectorAll){
s=doc;
fn="querySelectorAll";
opt=".dojoxEllipsis";
}else{
if(doc.getElementsByClassName){
s=doc;
fn="getElementsByClassName";
opt="dojoxEllipsis";
}else{
s=d;
fn="query";
opt=".dojoxEllipsis";
}
}
fx=function(){
d.forEach(s[fn].apply(s,[opt]),function(n){
if(!n||n._djx_ellipsis_done){
return;
}
n._djx_ellipsis_done=true;
if(_bbb&&n.textContent==n.innerHTML&&!hc(n,"dojoxEllipsisSelectable")){
_bbb(n);
}else{
_bc1(n);
}
});
};
d.addOnLoad(function(){
var t=null;
var c=null;
var _bc5=function(){
if(c){
d.disconnect(c);
c=null;
}
if(t){
clearTimeout(t);
}
t=setTimeout(function(){
t=null;
fx();
c=d.connect(d.body(),"DOMSubtreeModified",_bc5);
},_bba);
};
_bc5();
});
}
})(dojo);
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.filter.FilterDefDialog"]){
dojo._hasResource["dojox.grid.enhanced.plugins.filter.FilterDefDialog"]=true;
dojo.provide("dojox.grid.enhanced.plugins.filter.FilterDefDialog");
(function(){
var fns=dojox.grid.enhanced.plugins.filter,_bc6={relSelect:60,accordionTitle:70,removeCBoxBtn:-1,colSelect:90,condSelect:95,valueBox:10,addCBoxBtn:20,filterBtn:30,clearBtn:40,cancelBtn:50};
dojo.declare("dojox.grid.enhanced.plugins.filter.FilterDefDialog",null,{curColIdx:-1,_relOpCls:"logicall",_savedCriterias:null,plugin:null,constructor:function(args){
var _bc7=this.plugin=args.plugin;
this.builder=new fns.FilterBuilder();
this._setupData();
this._cboxes=[];
this.defaultType=_bc7.args.defaultType||"string";
(this.filterDefPane=new fns.FilterDefPane({"dlg":this})).startup();
(this._defPane=new dojox.grid.enhanced.plugins.Dialog({"refNode":this.plugin.grid.domNode,"title":_bc7.nls.filterDefDialogTitle,"class":"dojoxGridFDTitlePane","iconClass":"dojoxGridFDPaneIcon","content":this.filterDefPane})).startup();
this._defPane.connect(_bc7.grid.layer("filter"),"filterDef",dojo.hitch(this,"_onSetFilter"));
_bc7.grid.setFilter=dojo.hitch(this,"setFilter");
_bc7.grid.getFilter=dojo.hitch(this,"getFilter");
_bc7.grid.getFilterRelation=dojo.hitch(this,function(){
return this._relOpCls;
});
_bc7.connect(_bc7.grid.layout,"moveColumn",dojo.hitch(this,"onMoveColumn"));
},onMoveColumn:function(_bc8,_bc9,_bca,_bcb,_bcc){
if(this._savedCriterias&&_bca!=_bcb){
if(_bca<_bcb){
--_bcb;
}
if(!_bcc){
++_bcb;
}
var min=_bca<_bcb?_bca:_bcb;
var max=_bca<_bcb?_bcb:_bca;
var dir=_bcb>min?1:-1;
dojo.forEach(this._savedCriterias,function(sc){
var idx=parseInt(sc.column,10);
if(!isNaN(idx)&&idx>=min&&idx<=max){
sc.column=String(idx==_bca?idx+(max-min)*dir:idx-dir);
}
});
}
},destroy:function(){
this._defPane.destroyRecursive();
this._defPane=null;
this.filterDefPane=null;
this.builder=null;
this._dataTypeMap=null;
this._cboxes=null;
var g=this.plugin.grid;
g.setFilter=null;
g.getFilter=null;
g.getFilterRelation=null;
this.plugin=null;
},_setupData:function(){
var nls=this.plugin.nls;
this._dataTypeMap={"number":{valueBoxCls:{dft:dijit.form.NumberTextBox,ac:fns.UniqueComboBox},conditions:[{label:nls.conditionEqual,value:"equalto",selected:true},{label:nls.conditionNotEqual,value:"notequalto"},{label:nls.conditionLess,value:"lessthan"},{label:nls.conditionLessEqual,value:"lessthanorequalto"},{label:nls.conditionLarger,value:"largerthan"},{label:nls.conditionLargerEqual,value:"largerthanorequalto"},{label:nls.conditionIsEmpty,value:"isempty"}]},"string":{valueBoxCls:{dft:dijit.form.TextBox,ac:fns.UniqueComboBox},conditions:[{label:nls.conditionContains,value:"contains",selected:true},{label:nls.conditionIs,value:"equalto"},{label:nls.conditionStartsWith,value:"startswith"},{label:nls.conditionEndWith,value:"endswith"},{label:nls.conditionNotContain,value:"notcontains"},{label:nls.conditionIsNot,value:"notequalto"},{label:nls.conditionNotStartWith,value:"notstartswith"},{label:nls.conditionNotEndWith,value:"notendswith"},{label:nls.conditionIsEmpty,value:"isempty"}]},"date":{valueBoxCls:{dft:dijit.form.DateTextBox},conditions:[{label:nls.conditionIs,value:"equalto",selected:true},{label:nls.conditionBefore,value:"lessthan"},{label:nls.conditionAfter,value:"largerthan"},{label:nls.conditionRange,value:"range"},{label:nls.conditionIsEmpty,value:"isempty"}]},"time":{valueBoxCls:{dft:dijit.form.TimeTextBox},conditions:[{label:nls.conditionIs,value:"equalto",selected:true},{label:nls.conditionBefore,value:"lessthan"},{label:nls.conditionAfter,value:"largerthan"},{label:nls.conditionRange,value:"range"},{label:nls.conditionIsEmpty,value:"isempty"}]},"boolean":{valueBoxCls:{dft:fns.BooleanValueBox},conditions:[{label:nls.conditionIs,value:"equalto",selected:true},{label:nls.conditionIsEmpty,value:"isempty"}]}};
},setFilter:function(_bcd,_bce){
_bcd=_bcd||[];
if(!dojo.isArray(_bcd)){
_bcd=[_bcd];
}
var func=function(){
if(_bcd.length){
this._savedCriterias=dojo.map(_bcd,function(rule){
var type=rule.type||this.defaultType;
return {"type":type,"column":String(rule.column),"condition":rule.condition,"value":rule.value,"colTxt":this.getColumnLabelByValue(String(rule.column)),"condTxt":this.getConditionLabelByValue(type,rule.condition),"formattedVal":rule.formattedVal||rule.value};
},this);
this._criteriasChanged=true;
if(_bce==="logicall"||_bce==="logicany"){
this._relOpCls=_bce;
}
var _bcf=dojo.map(_bcd,this.getExprForCriteria,this);
_bcf=this.builder.buildExpression(_bcf.length==1?_bcf[0]:{"op":this._relOpCls,"data":_bcf});
this.plugin.grid.layer("filter").filterDef(_bcf);
this.plugin.filterBar.toggleClearFilterBtn(false);
}
this._closeDlgAndUpdateGrid();
};
if(this._savedCriterias){
this._clearWithoutRefresh=true;
var _bd0=dojo.connect(this,"clearFilter",this,function(){
dojo.disconnect(_bd0);
this._clearWithoutRefresh=false;
func.apply(this);
});
this.onClearFilter();
}else{
func.apply(this);
}
},getFilter:function(){
return dojo.clone(this._savedCriterias)||[];
},getColumnLabelByValue:function(v){
var nls=this.plugin.nls;
if(v.toLowerCase()=="anycolumn"){
return nls["anyColumnOption"];
}else{
var cell=this.plugin.grid.layout.cells[parseInt(v,10)];
return cell?(cell.name||cell.field):"";
}
},getConditionLabelByValue:function(type,c){
var _bd1=this._dataTypeMap[type].conditions;
for(var i=_bd1.length-1;i>=0;--i){
var cond=_bd1[i];
if(cond.value==c.toLowerCase()){
return cond.label;
}
}
return "";
},addCriteriaBoxes:function(cnt){
if(typeof cnt!="number"||cnt<=0){
return;
}
var cbs=this._cboxes,cc=this.filterDefPane.cboxContainer,_bd2=this.plugin.args.ruleCount,len=cbs.length,cbox;
if(_bd2>0&&len+cnt>_bd2){
cnt=_bd2-len;
}
for(;cnt>0;--cnt){
cbox=new fns.CriteriaBox({dlg:this});
cbs.push(cbox);
cc.addChild(cbox);
}
cc.startup();
this._updatePane();
this._updateCBoxTitles();
cc.selectChild(cbs[cbs.length-1]);
this.filterDefPane.criteriaPane.scrollTop=1000000;
if(cbs.length===4){
if(dojo.isIE<=6&&!this.__alreadyResizedForIE6){
var size=dojo.position(cc.domNode);
size.w-=dojox.html.metrics.getScrollbar().w;
cc.resize(size);
this.__alreadyResizedForIE6=true;
}else{
cc.resize();
}
}
},removeCriteriaBoxes:function(cnt,_bd3){
var cbs=this._cboxes,cc=this.filterDefPane.cboxContainer,len=cbs.length,_bd4=len-cnt,end=len-1,cbox,_bd5=dojo.indexOf(cbs,cc.selectedChildWidget.content);
if(dojo.isArray(cnt)){
var i,_bd6=cnt;
_bd6.sort();
cnt=_bd6.length;
for(i=len-1;i>=0&&dojo.indexOf(_bd6,i)>=0;--i){
}
if(i>=0){
if(i!=_bd5){
cc.selectChild(cbs[i]);
}
for(i=cnt-1;i>=0;--i){
if(_bd6[i]>=0&&_bd6[i]<len){
cc.removeChild(cbs[_bd6[i]]);
cbs.splice(_bd6[i],1);
}
}
}
_bd4=cbs.length;
}else{
if(_bd3===true){
if(cnt>=0&&cnt<len){
_bd4=end=cnt;
cnt=1;
}else{
return;
}
}else{
if(cnt instanceof fns.CriteriaBox){
cbox=cnt;
cnt=1;
_bd4=end=dojo.indexOf(cbs,cbox);
}else{
if(typeof cnt!="number"||cnt<=0){
return;
}else{
if(cnt>=len){
cnt=end;
_bd4=1;
}
}
}
}
if(end<_bd4){
return;
}
if(_bd5>=_bd4&&_bd5<=end){
cc.selectChild(cbs[_bd4?_bd4-1:end+1]);
}
for(;end>=_bd4;--end){
cc.removeChild(cbs[end]);
}
cbs.splice(_bd4,cnt);
}
this._updatePane();
this._updateCBoxTitles();
if(cbs.length===3){
cc.resize();
}
},getCriteria:function(idx){
if(typeof idx!="number"){
return this._savedCriterias?this._savedCriterias.length:0;
}
if(this._savedCriterias&&this._savedCriterias[idx]){
return dojo.mixin({relation:this._relOpCls=="logicall"?this.plugin.nls.and:this.plugin.nls.or},this._savedCriterias[idx]);
}
return null;
},getExprForCriteria:function(rule){
if(rule.column=="anycolumn"){
var _bd7=dojo.filter(this.plugin.grid.layout.cells,function(cell){
return !(cell.filterable===false||cell.hidden);
});
return {"op":"logicany","data":dojo.map(_bd7,function(cell){
return this.getExprForColumn(rule.value,cell.index,rule.type,rule.condition);
},this)};
}else{
return this.getExprForColumn(rule.value,rule.column,rule.type,rule.condition);
}
},getExprForColumn:function(_bd8,_bd9,type,_bda){
_bd9=parseInt(_bd9,10);
var cell=this.plugin.grid.layout.cells[_bd9],_bdb=cell.field||cell.name,obj={"datatype":type||this.getColumnType(_bd9),"args":cell.dataTypeArgs,"isColumn":true},_bdc=[dojo.mixin({"data":this.plugin.args.isServerSide?_bdb:cell},obj)];
obj.isColumn=false;
if(_bda=="range"){
_bdc.push(dojo.mixin({"data":_bd8.start},obj),dojo.mixin({"data":_bd8.end},obj));
}else{
if(_bda!="isempty"){
_bdc.push(dojo.mixin({"data":_bd8},obj));
}
}
return {"op":_bda,"data":_bdc};
},getColumnType:function(_bdd){
var cell=this.plugin.grid.layout.cells[parseInt(_bdd,10)];
if(!cell||!cell.datatype){
return this.defaultType;
}
var type=String(cell.datatype).toLowerCase();
return this._dataTypeMap[type]?type:this.defaultType;
},clearFilter:function(_bde){
if(!this._savedCriterias){
return;
}
this._savedCriterias=null;
this.plugin.grid.layer("filter").filterDef(null);
try{
this.plugin.filterBar.toggleClearFilterBtn(true);
this.filterDefPane._clearFilterBtn.set("disabled",true);
this.removeCriteriaBoxes(this._cboxes.length-1);
this._cboxes[0].load({});
}
catch(e){
}
if(_bde){
this.closeDialog();
}else{
this._closeDlgAndUpdateGrid();
}
},showDialog:function(_bdf){
this._defPane.show();
this.plugin.filterStatusTip.closeDialog();
this._prepareDialog(_bdf);
},closeDialog:function(){
this._defPane.hide();
},onFilter:function(e){
if(this.canFilter()){
this._defineFilter();
this._closeDlgAndUpdateGrid();
this.plugin.filterBar.toggleClearFilterBtn(false);
}
},onClearFilter:function(e){
if(this._savedCriterias){
if(this._savedCriterias.length>=this.plugin.ruleCountToConfirmClearFilter){
this.plugin.clearFilterDialog.show();
}else{
this.clearFilter(this._clearWithoutRefresh);
}
}
},onCancel:function(e){
var sc=this._savedCriterias;
var cbs=this._cboxes;
if(sc){
this.addCriteriaBoxes(sc.length-cbs.length);
this.removeCriteriaBoxes(cbs.length-sc.length);
dojo.forEach(sc,function(c,i){
cbs[i].load(c);
});
}else{
this.removeCriteriaBoxes(cbs.length-1);
cbs[0].load({});
}
this.closeDialog();
},onRendered:function(cbox){
if(!dojo.isFF){
var _be0=dijit._getTabNavigable(dojo.byId(cbox.domNode));
dijit.focus(_be0.lowest||_be0.first);
}else{
var dp=this._defPane;
dp._getFocusItems(dp.domNode);
dijit.focus(dp._firstFocusItem);
}
},_onSetFilter:function(_be1){
if(_be1===null&&this._savedCriterias){
this.clearFilter();
}
},_prepareDialog:function(_be2){
var sc=this._savedCriterias,cbs=this._cboxes,i,cbox;
this.curColIdx=_be2;
if(!sc){
if(cbs.length===0){
this.addCriteriaBoxes(1);
}else{
for(i=0;(cbox=cbs[i]);++i){
cbox.changeCurrentColumn();
}
}
}else{
if(this._criteriasChanged){
this.filterDefPane._relSelect.set("value",this._relOpCls==="logicall"?"0":"1");
this._criteriasChanged=false;
var _be3=sc.length>cbs.length?sc.length-cbs.length:0;
this.addCriteriaBoxes(_be3);
this.removeCriteriaBoxes(cbs.length-sc.length);
this.filterDefPane._clearFilterBtn.set("disabled",false);
for(i=0;i<cbs.length-_be3;++i){
cbs[i].load(sc[i]);
}
if(_be3>0){
var _be4=[],_be5=dojo.connect(this,"onRendered",function(cbox){
var i=dojo.indexOf(cbs,cbox);
if(!_be4[i]){
_be4[i]=true;
if(--_be3===0){
dojo.disconnect(_be5);
}
cbox.load(sc[i]);
}
});
}
}
}
this.filterDefPane.cboxContainer.resize();
},_defineFilter:function(){
var cbs=this._cboxes,_be6=function(_be7){
return dojo.filter(dojo.map(cbs,function(cbox){
return cbox[_be7]();
}),function(_be8){
return !!_be8;
});
},_be9=_be6("getExpr");
this._savedCriterias=_be6("save");
_be9=_be9.length==1?_be9[0]:{"op":this._relOpCls,"data":_be9};
_be9=this.builder.buildExpression(_be9);
this.plugin.grid.layer("filter").filterDef(_be9);
this.filterDefPane._clearFilterBtn.set("disabled",false);
},_updateCBoxTitles:function(){
for(var cbs=this._cboxes,i=cbs.length;i>0;--i){
cbs[i-1].updateRuleIndex(i);
cbs[i-1].setAriaInfo(i);
}
},_updatePane:function(){
var cbs=this._cboxes,_bea=this.filterDefPane;
_bea._addCBoxBtn.set("disabled",cbs.length==this.plugin.args.ruleCount);
_bea._filterBtn.set("disabled",!this.canFilter());
},canFilter:function(){
return dojo.filter(this._cboxes,function(cbox){
return !cbox.isEmpty();
}).length>0;
},_closeDlgAndUpdateGrid:function(){
this.closeDialog();
var g=this.plugin.grid;
g.showMessage(g.loadingMessage);
setTimeout(dojo.hitch(g,g._refresh),this._defPane.duration+10);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.FilterDefPane",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dojox.grid","enhanced/templates/FilterDefPane.html","<div class=\"dojoxGridFDPane\">\r\n\t<div class=\"dojoxGridFDPaneRelation\">${_relMsgFront}\r\n\t<span class=\"dojoxGridFDPaneModes\" dojoAttachPoint=\"criteriaModeNode\">\r\n\t\t<select dojoAttachPoint=\"_relSelect\" dojoType=\"dijit.form.Select\" dojoAttachEvent=\"onChange: _onRelSelectChange\">\r\n\t\t\t<option value=\"0\">${_relAll}</option>\r\n\t\t\t<option value=\"1\">${_relAny}</option>\r\n\t\t</select>\r\n\t</span>\r\n\t${_relMsgTail}\r\n\t</div>\r\n\t<div dojoAttachPoint=\"criteriaPane\" class=\"dojoxGridFDPaneRulePane\"></div>\r\n\t<div dojoAttachPoint=\"_addCBoxBtn\" dojoType=\"dijit.form.Button\" \r\n\t\tclass=\"dojoxGridFDPaneAddCBoxBtn\" iconClass=\"dojoxGridFDPaneAddCBoxBtnIcon\"\r\n\t\tdojoAttachEvent=\"onClick:_onAddCBox\" label=\"${_addRuleBtnLabel}\" showLabel=\"false\">\r\n\t</div>\r\n\t<div class=\"dojoxGridFDPaneBtns\" dojoAttachPoint=\"buttonsPane\">\r\n\t\t<span dojoAttachPoint=\"_cancelBtn\" dojoType=\"dijit.form.Button\" \r\n\t\t\tdojoAttachEvent=\"onClick:_onCancel\" label=\"${_cancelBtnLabel}\">\r\n\t\t</span>\r\n\t\t<span dojoAttachPoint=\"_clearFilterBtn\" dojoType=\"dijit.form.Button\" \r\n\t\t\tdojoAttachEvent=\"onClick:_onClearFilter\" label=\"${_clearBtnLabel}\" disabled=\"true\">\r\n\t\t</span>\r\n\t\t<span dojoAttachPoint=\"_filterBtn\" dojoType=\"dijit.form.Button\" \r\n\t\t\tdojoAttachEvent=\"onClick:_onFilter\" label=\"${_filterBtnLabel}\" disabled=\"true\">\r\n\t\t</span>\r\n\t</div>\r\n</div>\r\n"),widgetsInTemplate:true,dlg:null,postMixInProperties:function(){
this.plugin=this.dlg.plugin;
var nls=this.plugin.nls;
this._addRuleBtnLabel=nls.addRuleButton;
this._cancelBtnLabel=nls.cancelButton;
this._clearBtnLabel=nls.clearButton;
this._filterBtnLabel=nls.filterButton;
this._relAll=nls.relationAll;
this._relAny=nls.relationAny;
this._relMsgFront=nls.relationMsgFront;
this._relMsgTail=nls.relationMsgTail;
},postCreate:function(){
this.inherited(arguments);
this.connect(this.domNode,"onkeypress","_onKey");
(this.cboxContainer=new fns.AccordionContainer({nls:this.plugin.nls})).placeAt(this.criteriaPane);
this._relSelect.set("tabIndex",_bc6.relSelect);
this._addCBoxBtn.set("tabIndex",_bc6.addCBoxBtn);
this._cancelBtn.set("tabIndex",_bc6.cancelBtn);
this._clearFilterBtn.set("tabIndex",_bc6.clearBtn);
this._filterBtn.set("tabIndex",_bc6.filterBtn);
var nls=this.plugin.nls;
this._relSelect.domNode.setAttribute("aria-label",nls.waiRelAll);
this._addCBoxBtn.domNode.setAttribute("aria-label",nls.waiAddRuleButton);
this._cancelBtn.domNode.setAttribute("aria-label",nls.waiCancelButton);
this._clearFilterBtn.domNode.setAttribute("aria-label",nls.waiClearButton);
this._filterBtn.domNode.setAttribute("aria-label",nls.waiFilterButton);
this._relSelect.set("value",this.dlg._relOpCls==="logicall"?"0":"1");
},uninitialize:function(){
this.cboxContainer.destroyRecursive();
this.plugin=null;
this.dlg=null;
},_onRelSelectChange:function(val){
this.dlg._relOpCls=val=="0"?"logicall":"logicany";
this._relSelect.domNode.setAttribute("aria-label",this.plugin.nls[val=="0"?"waiRelAll":"waiRelAny"]);
},_onAddCBox:function(){
this.dlg.addCriteriaBoxes(1);
},_onCancel:function(){
this.dlg.onCancel();
},_onClearFilter:function(){
this.dlg.onClearFilter();
},_onFilter:function(){
this.dlg.onFilter();
},_onKey:function(e){
if(e.keyCode==dojo.keys.ENTER){
this.dlg.onFilter();
}
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.CriteriaBox",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dojox.grid","enhanced/templates/CriteriaBox.html","<div class=\"dojoxGridFCBox\">\r\n\t<div class=\"dojoxGridFCBoxSelCol\" dojoAttachPoint=\"selColNode\">\r\n\t\t<span class=\"dojoxGridFCBoxField\">${_colSelectLabel}</span>\r\n\t\t<select dojoAttachPoint=\"_colSelect\" dojoType=\"dijit.form.Select\" \r\n\t\t\tclass=\"dojoxGridFCBoxColSelect\"\r\n\t\t\tdojoAttachEvent=\"onChange:_onChangeColumn\">\r\n\t\t</select>\r\n\t</div>\r\n\t<div class=\"dojoxGridFCBoxCondition\" dojoAttachPoint=\"condNode\">\r\n\t\t<span class=\"dojoxGridFCBoxField\">${_condSelectLabel}</span>\r\n\t\t<select dojoAttachPoint=\"_condSelect\" dojoType=\"dijit.form.Select\" \r\n\t\t\tclass=\"dojoxGridFCBoxCondSelect\"\r\n\t\t\tdojoAttachEvent=\"onChange:_onChangeCondition\">\r\n\t\t</select>\r\n\t\t<div class=\"dojoxGridFCBoxCondSelectAlt\" dojoAttachPoint=\"_condSelectAlt\" style=\"display:none;\"></div>\r\n\t</div>\r\n\t<div class=\"dojoxGridFCBoxValue\" dojoAttachPoint=\"valueNode\">\r\n\t\t<span class=\"dojoxGridFCBoxField\">${_valueBoxLabel}</span>\r\n\t</div>\r\n</div>\r\n"),widgetsInTemplate:true,dlg:null,postMixInProperties:function(){
this.plugin=this.dlg.plugin;
this._curValueBox=null;
var nls=this.plugin.nls;
this._colSelectLabel=nls.columnSelectLabel;
this._condSelectLabel=nls.conditionSelectLabel;
this._valueBoxLabel=nls.valueBoxLabel;
this._anyColumnOption=nls.anyColumnOption;
},postCreate:function(){
var dlg=this.dlg,g=this.plugin.grid;
this._colSelect.set("tabIndex",_bc6.colSelect);
this._colOptions=this._getColumnOptions();
this._colSelect.addOption([{label:this.plugin.nls.anyColumnOption,value:"anycolumn",selected:dlg.curColIdx<0},{value:""}].concat(this._colOptions));
this._condSelect.set("tabIndex",_bc6.condSelect);
this._condSelect.addOption(this._getUsableConditions(dlg.getColumnType(dlg.curColIdx)));
this._showSelectOrLabel(this._condSelect,this._condSelectAlt);
this.connect(g.layout,"moveColumn","onMoveColumn");
},_getColumnOptions:function(){
var _beb=this.dlg.curColIdx>=0?String(this.dlg.curColIdx):"anycolumn";
return dojo.map(dojo.filter(this.plugin.grid.layout.cells,function(cell){
return !(cell.filterable===false||cell.hidden);
}),function(cell){
return {label:cell.name||cell.field,value:String(cell.index),selected:_beb==String(cell.index)};
});
},onMoveColumn:function(){
var tmp=this._onChangeColumn;
this._onChangeColumn=function(){
};
var _bec=this._colSelect.get("selectedOptions");
this._colSelect.removeOption(this._colOptions);
this._colOptions=this._getColumnOptions();
this._colSelect.addOption(this._colOptions);
var i=0;
for(;i<this._colOptions.length;++i){
if(this._colOptions[i].label==_bec.label){
break;
}
}
if(i<this._colOptions.length){
this._colSelect.set("value",this._colOptions[i].value);
}
var _bed=this;
setTimeout(function(){
_bed._onChangeColumn=tmp;
},0);
},onRemove:function(){
this.dlg.removeCriteriaBoxes(this);
},uninitialize:function(){
if(this._curValueBox){
this._curValueBox.destroyRecursive();
this._curValueBox=null;
}
this.plugin=null;
this.dlg=null;
},_showSelectOrLabel:function(sel,alt){
var _bee=sel.getOptions();
if(_bee.length==1){
alt.innerHTML=_bee[0].label;
dojo.style(sel.domNode,"display","none");
dojo.style(alt,"display","");
}else{
dojo.style(sel.domNode,"display","");
dojo.style(alt,"display","none");
}
},_onChangeColumn:function(val){
this._checkValidCriteria();
var type=this.dlg.getColumnType(val);
this._setConditionsByType(type);
this._setValueBoxByType(type);
this._updateValueBox();
},_onChangeCondition:function(val){
this._checkValidCriteria();
var f=(val=="range");
if(f^this._isRange){
this._isRange=f;
this._setValueBoxByType(this.dlg.getColumnType(this._colSelect.get("value")));
}
this._updateValueBox();
},_updateValueBox:function(cond){
this._curValueBox.set("disabled",this._condSelect.get("value")=="isempty");
},_checkValidCriteria:function(){
if(this._checkValidHandler){
clearTimeout(this._checkValidHandler);
}
this._checkValidHandler=setTimeout(dojo.hitch(this,function(){
this._checkValidHandler=null;
this.updateRuleTitle();
this.dlg._updatePane();
}),10);
},_createValueBox:function(cls,arg){
var func=dojo.hitch(arg.cbox,"_checkValidCriteria");
return new cls(dojo.mixin(arg,{tabIndex:_bc6.valueBox,onKeyPress:func,onChange:func,"class":"dojoxGridFCBoxValueBox"}));
},_createRangeBox:function(cls,arg){
var func=dojo.hitch(arg.cbox,"_checkValidCriteria");
dojo.mixin(arg,{tabIndex:_bc6.valueBox,onKeyPress:func,onChange:func});
var div=dojo.create("div",{"class":"dojoxGridFCBoxValueBox"}),_bef=new cls(arg),txt=dojo.create("span",{"class":"dojoxGridFCBoxRangeValueTxt","innerHTML":this.plugin.nls.rangeTo}),end=new cls(arg);
dojo.addClass(_bef.domNode,"dojoxGridFCBoxStartValue");
dojo.addClass(end.domNode,"dojoxGridFCBoxEndValue");
div.appendChild(_bef.domNode);
div.appendChild(txt);
div.appendChild(end.domNode);
div.domNode=div;
div.set=function(_bf0,args){
if(dojo.isObject(args)){
_bef.set("value",args.start);
end.set("value",args.end);
}
};
div.get=function(){
var s=_bef.get("value"),e=end.get("value");
return s&&e?{start:s,end:e}:"";
};
return div;
},changeCurrentColumn:function(_bf1){
var _bf2=this.dlg.curColIdx;
this._colSelect.removeOption(this._colOptions);
this._colOptions=this._getColumnOptions();
this._colSelect.addOption(this._colOptions);
this._colSelect.set("value",_bf2>=0?String(_bf2):"anycolumn");
this.updateRuleTitle(true);
},curColumn:function(){
return this._colSelect.getOptions(this._colSelect.get("value")).label;
},curCondition:function(){
return this._condSelect.getOptions(this._condSelect.get("value")).label;
},curValue:function(){
var cond=this._condSelect.get("value");
var _bf3=this._colSelect.get("value");
var _bf4=this._curValueBox?this._curValueBox.get("value"):"";
if(_bf3){
var cell=this.plugin.grid.layout.cells[_bf3];
}
if(cell&&cell.dataTypeArgs&&cell.dataTypeArgs.enumConst){
var _bf5=cell.dataTypeArgs.enumConst;
for(var i=0;i<_bf5.length;i++){
if(_bf5[i].label[0]===_bf4){
_bf4=_bf5[i].value;
}
}
}
if(cond=="isempty"){
return "";
}
return _bf4;
},save:function(){
if(this.isEmpty()){
return null;
}
var _bf6=this._colSelect.get("value"),type=this.dlg.getColumnType(_bf6),_bf7=this.curValue(),cond=this._condSelect.get("value");
return {"column":_bf6,"condition":cond,"value":_bf7,"formattedVal":this.formatValue(type,cond,_bf7),"type":type,"colTxt":this.curColumn(),"condTxt":this.curCondition()};
},load:function(obj){
var tmp=[this._onChangeColumn,this._onChangeCondition];
this._onChangeColumn=this._onChangeCondition=function(){
};
if(obj.column){
this._colSelect.set("value",obj.column);
}
if(obj.type){
this._setConditionsByType(obj.type);
this._setValueBoxByType(obj.type);
}else{
obj.type=this.dlg.getColumnType(this._colSelect.get("value"));
}
if(obj.condition){
this._condSelect.set("value",obj.condition);
}
var _bf8=obj.value||"";
if(_bf8||(obj.type!="date"&&obj.type!="time")){
this._curValueBox.set("value",_bf8);
}
this._updateValueBox();
setTimeout(dojo.hitch(this,function(){
this._onChangeColumn=tmp[0];
this._onChangeCondition=tmp[1];
}),0);
},getExpr:function(){
if(this.isEmpty()){
return null;
}
var _bf9=this._colSelect.get("value");
return this.dlg.getExprForCriteria({"type":this.dlg.getColumnType(_bf9),"column":_bf9,"condition":this._condSelect.get("value"),"value":this.curValue()});
},isEmpty:function(){
var cond=this._condSelect.get("value");
if(cond=="isempty"){
return false;
}
var v=this.curValue();
return v===""||v===null||typeof v=="undefined"||(typeof v=="number"&&isNaN(v));
},updateRuleTitle:function(_bfa){
var node=this._pane._buttonWidget.titleTextNode;
var _bfb=["<div class='dojoxEllipsis'>"];
if(_bfa||this.isEmpty()){
node.title=dojo.string.substitute(this.plugin.nls.ruleTitleTemplate,[this._ruleIndex||1]);
_bfb.push(node.title);
}else{
var type=this.dlg.getColumnType(this._colSelect.get("value"));
var _bfc=this.curColumn();
var _bfd=this.curCondition();
var _bfe=this.formatValue(type,this._condSelect.get("value"),this.curValue());
_bfb.push(_bfc,"&nbsp;<span class='dojoxGridRuleTitleCondition'>",_bfd,"</span>&nbsp;",_bfe);
node.title=[_bfc," ",_bfd," ",_bfe].join("");
}
node.innerHTML=_bfb.join("");
if(dojo.isMoz){
var tt=dojo.create("div",{"style":"width: 100%; height: 100%; position: absolute; top: 0; left: 0; z-index: 9999;"},node);
tt.title=node.title;
}
},updateRuleIndex:function(_bff){
if(this._ruleIndex!=_bff){
this._ruleIndex=_bff;
if(this.isEmpty()){
this.updateRuleTitle();
}
}
},setAriaInfo:function(idx){
var dss=dojo.string.substitute,nls=this.plugin.nls;
this._colSelect.domNode.setAttribute("aria-label",dss(nls.waiColumnSelectTemplate,[idx]));
this._condSelect.domNode.setAttribute("aria-label",dss(nls.waiConditionSelectTemplate,[idx]));
this._pane._removeCBoxBtn.domNode.setAttribute("aria-label",dss(nls.waiRemoveRuleButtonTemplate,[idx]));
this._index=idx;
},_getUsableConditions:function(type){
var _c00=dojo.clone(this.dlg._dataTypeMap[type].conditions);
var _c01=(this.plugin.args.disabledConditions||{})[type];
var _c02=parseInt(this._colSelect.get("value"),10);
var _c03=isNaN(_c02)?(this.plugin.args.disabledConditions||{})["anycolumn"]:this.plugin.grid.layout.cells[_c02].disabledConditions;
if(!dojo.isArray(_c01)){
_c01=[];
}
if(!dojo.isArray(_c03)){
_c03=[];
}
var arr=_c01.concat(_c03);
if(arr.length){
var _c04={};
dojo.forEach(arr,function(c){
if(dojo.isString(c)){
_c04[c.toLowerCase()]=true;
}
});
return dojo.filter(_c00,function(_c05){
return !(_c05.value in _c04);
});
}
return _c00;
},_setConditionsByType:function(type){
var _c06=this._condSelect;
_c06.removeOption(_c06.options);
_c06.addOption(this._getUsableConditions(type));
this._showSelectOrLabel(this._condSelect,this._condSelectAlt);
},_setValueBoxByType:function(type){
if(this._curValueBox){
this.valueNode.removeChild(this._curValueBox.domNode);
try{
this._curValueBox.destroyRecursive();
}
catch(e){
}
delete this._curValueBox;
}
var _c07=this.dlg._dataTypeMap[type].valueBoxCls[this._getValueBoxClsInfo(this._colSelect.get("value"),type)],_c08=this._getValueBoxArgByType(type);
this._curValueBox=this[this._isRange?"_createRangeBox":"_createValueBox"](_c07,_c08);
this.valueNode.appendChild(this._curValueBox.domNode);
this._curValueBox.domNode.setAttribute("aria-label",dojo.string.substitute(this.plugin.nls.waiValueBoxTemplate,[this._index]));
this.dlg.onRendered(this);
},_getValueBoxArgByType:function(type){
var g=this.plugin.grid,cell=g.layout.cells[parseInt(this._colSelect.get("value"),10)],res={cbox:this};
if(type=="string"){
if(cell&&(cell.suggestion||cell.autoComplete)){
dojo.mixin(res,{store:g.store,searchAttr:cell.field||cell.name,query:g.query||{},fetchProperties:{sort:[{"attribute":cell.field||cell.name}],queryOptions:dojo.mixin({ignoreCase:true,deep:true},g.queryOptions||{})}});
}
}else{
if(type=="boolean"){
dojo.mixin(res,this.dlg.builder.defaultArgs["boolean"]);
}
}
if(cell&&cell.dataTypeArgs){
if(cell.dataTypeArgs&&cell.dataTypeArgs.enumConst){
var _c09=cell.dataTypeArgs.enumConst;
var data={identifier:"label",label:"label",items:_c09};
var _c0a=new dojo.data.ItemFileReadStore({data:data});
dojo.mixin(res,{store:_c0a,autoComplete:true,searchAttr:"label"});
}else{
dojo.mixin(res,cell.dataTypeArgs);
}
}
return res;
},formatValue:function(type,cond,v){
if(cond=="isempty"){
return "";
}
var cell=null;
var _c0b=this._colSelect.get("value");
if(_c0b){
cell=this.plugin.grid.layout.cells[parseInt(_c0b,10)];
}
if(type=="date"||type=="time"){
var opt={selector:type},fmt=dojo.date.locale.format;
if(cond=="range"){
return dojo.string.substitute(this.plugin.nls.rangeTemplate,[fmt(v.start,opt),fmt(v.end,opt)]);
}
return fmt(v,opt);
}else{
if(type=="boolean"){
return v?this._curValueBox._lblTrue:this._curValueBox._lblFalse;
}
}
if(cell&&cell.dataTypeArgs&&cell.dataTypeArgs.enumConst){
var _c0c=cell.dataTypeArgs.enumConst;
for(var j=0;j<_c0c.length;j++){
if(_c0c[j].value===v){
return _c0c[j].label;
}
}
}
return v;
},_getValueBoxClsInfo:function(_c0d,type){
var cell=this.plugin.grid.layout.cells[parseInt(_c0d,10)];
if(type=="string"){
return (cell&&(cell.suggestion||cell.autoComplete||(cell.dataTypeArgs&&cell.dataTypeArgs.enumConst)))?"ac":"dft";
}else{
if(type=="number"){
return (cell&&(cell.suggestion||cell.autoComplete||(cell.dataTypeArgs&&cell.dataTypeArgs.enumConst)))?"ac":"dft";
}
}
return "dft";
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.AccordionContainer",dijit.layout.AccordionContainer,{nls:null,addChild:function(_c0e,_c0f){
var pane=arguments[0]=_c0e._pane=new dijit.layout.ContentPane({content:_c0e});
this.inherited(arguments);
this._modifyChild(pane);
},removeChild:function(_c10){
var pane=_c10,_c11=false;
if(_c10._pane){
_c11=true;
pane=arguments[0]=_c10._pane;
}
this.inherited(arguments);
if(_c11){
this._hackHeight(false,this._titleHeight);
var _c12=this.getChildren();
if(_c12.length===1){
dojo.style(_c12[0]._removeCBoxBtn.domNode,"display","none");
}
}
pane.destroyRecursive();
},selectChild:function(_c13){
if(_c13._pane){
arguments[0]=_c13._pane;
}
this.inherited(arguments);
},resize:function(){
this.inherited(arguments);
dojo.forEach(this.getChildren(),this._setupTitleDom);
},startup:function(){
if(this._started){
return;
}
this.inherited(arguments);
if(parseInt(dojo.isIE,10)==7){
dojo.some(this._connects,function(cnnt){
if(cnnt[0][1]=="onresize"){
this.disconnect(cnnt);
return true;
}
},this);
}
dojo.forEach(this.getChildren(),function(_c14){
this._modifyChild(_c14,true);
},this);
},_onKeyPress:function(e,_c15){
if(this.disabled||e.altKey||!(_c15||e.ctrlKey)){
return;
}
var k=dojo.keys,c=e.charOrCode,ltr=dojo._isBodyLtr(),_c16=null;
if((_c15&&c==k.UP_ARROW)||(e.ctrlKey&&c==k.PAGE_UP)){
_c16=false;
}else{
if((_c15&&c==k.DOWN_ARROW)||(e.ctrlKey&&(c==k.PAGE_DOWN||c==k.TAB))){
_c16=true;
}else{
if(c==(ltr?k.LEFT_ARROW:k.RIGHT_ARROW)){
_c16=this._focusOnRemoveBtn?null:false;
this._focusOnRemoveBtn=!this._focusOnRemoveBtn;
}else{
if(c==(ltr?k.RIGHT_ARROW:k.LEFT_ARROW)){
_c16=this._focusOnRemoveBtn?true:null;
this._focusOnRemoveBtn=!this._focusOnRemoveBtn;
}else{
return;
}
}
}
}
if(_c16!==null){
this._adjacent(_c16)._buttonWidget._onTitleClick();
}
dojo.stopEvent(e);
dojo.window.scrollIntoView(this.selectedChildWidget._buttonWidget.domNode.parentNode);
if(dojo.isIE){
this.selectedChildWidget._removeCBoxBtn.focusNode.setAttribute("tabIndex",this._focusOnRemoveBtn?_bc6.accordionTitle:-1);
}
dijit.focus(this.selectedChildWidget[this._focusOnRemoveBtn?"_removeCBoxBtn":"_buttonWidget"].focusNode);
},_modifyChild:function(_c17,_c18){
if(!_c17||!this._started){
return;
}
dojo.style(_c17.domNode,"overflow","hidden");
_c17._buttonWidget.connect(_c17._buttonWidget,"_setSelectedAttr",function(){
this.focusNode.setAttribute("tabIndex",this.selected?_bc6.accordionTitle:"-1");
});
var _c19=this;
_c17._buttonWidget.connect(_c17._buttonWidget.domNode,"onclick",function(){
_c19._focusOnRemoveBtn=false;
});
(_c17._removeCBoxBtn=new dijit.form.Button({label:this.nls.removeRuleButton,showLabel:false,iconClass:"dojoxGridFCBoxRemoveCBoxBtnIcon",tabIndex:_bc6.removeCBoxBtn,onClick:dojo.hitch(_c17.content,"onRemove"),onKeyPress:function(e){
_c19._onKeyPress(e,_c17._buttonWidget.contentWidget);
}})).placeAt(_c17._buttonWidget.domNode);
var i,_c1a=this.getChildren();
if(_c1a.length===1){
_c17._buttonWidget.set("selected",true);
dojo.style(_c17._removeCBoxBtn.domNode,"display","none");
}else{
for(i=0;i<_c1a.length;++i){
if(_c1a[i]._removeCBoxBtn){
dojo.style(_c1a[i]._removeCBoxBtn.domNode,"display","");
}
}
}
this._setupTitleDom(_c17);
if(!this._titleHeight){
for(i=0;i<_c1a.length;++i){
if(_c1a[i]!=this.selectedChildWidget){
this._titleHeight=dojo.marginBox(_c1a[i]._buttonWidget.domNode.parentNode).h;
break;
}
}
}
if(!_c18){
this._hackHeight(true,this._titleHeight);
}
},_hackHeight:function(_c1b,_c1c){
var _c1d=this.getChildren(),dn=this.domNode,h=dojo.style(dn,"height");
if(!_c1b){
dn.style.height=(h-_c1c)+"px";
}else{
if(_c1d.length>1){
dn.style.height=(h+_c1c)+"px";
}else{
return;
}
}
this.resize();
},_setupTitleDom:function(_c1e){
var w=dojo.contentBox(_c1e._buttonWidget.titleNode).w;
if(dojo.isIE<8){
w-=8;
}
dojo.style(_c1e._buttonWidget.titleTextNode,"width",w+"px");
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.UniqueComboBox",dijit.form.ComboBox,{_openResultList:function(_c1f){
var _c20={},s=this.store,_c21=this.searchAttr;
arguments[0]=dojo.filter(_c1f,function(item){
var key=s.getValue(item,_c21),_c22=_c20[key];
_c20[key]=true;
return !_c22;
});
this.inherited(arguments);
},_onKey:function(evt){
if(evt.charOrCode===dojo.keys.ENTER&&this._opened){
dojo.stopEvent(evt);
}
this.inherited(arguments);
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.BooleanValueBox",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dojox.grid","enhanced/templates/FilterBoolValueBox.html","<div class=\"dojoxGridBoolValueBox\">\r\n\t<div class=\"dojoxGridTrueBox\">\r\n\t\t<input dojoType=\"dijit.form.RadioButton\" type='radio' name='a1' id='${_baseId}_rbTrue' checked=\"true\" \r\n\t\t\tdojoAttachPoint=\"rbTrue\" dojoAttachEvent=\"onChange: onChange\"/>\r\n\t\t<div class=\"dojoxGridTrueLabel\" for='${_baseId}_rbTrue'>${_lblTrue}</div>\r\n\t</div>\r\n\t<div class=\"dojoxGridFalseBox\">\r\n\t\t<input dojoType=\"dijit.form.RadioButton\" dojoAttachPoint=\"rbFalse\" type='radio' name='a1' id='${_baseId}_rbFalse'/>\r\n\t\t<div class=\"dojoxGridTrueLabel\" for='${_baseId}_rbFalse'>${_lblFalse}</div>\r\n\t</div>\r\n</div>\r\n"),widgetsInTemplate:true,constructor:function(args){
var nls=args.cbox.plugin.nls;
this._baseId=args.cbox.id;
this._lblTrue=args.trueLabel||nls.trueLabel||"true";
this._lblFalse=args.falseLabel||nls.falseLabel||"false";
this.args=args;
},postCreate:function(){
this.onChange();
},onChange:function(){
},get:function(prop){
return this.rbTrue.get("checked");
},set:function(prop,v){
this.inherited(arguments);
if(prop=="value"){
this.rbTrue.set("checked",!!v);
this.rbFalse.set("checked",!v);
}
}});
})();
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.filter.FilterStatusTip"]){
dojo._hasResource["dojox.grid.enhanced.plugins.filter.FilterStatusTip"]=true;
dojo.provide("dojox.grid.enhanced.plugins.filter.FilterStatusTip");
(function(){
var _c23="",_c24="",_c25="",_c26="",_c27="dojoxGridFStatusTipOddRow",_c28="dojoxGridFStatusTipHandle",_c29="dojoxGridFStatusTipCondition",_c2a="dojoxGridFStatusTipDelRuleBtnIcon",_c2b="</tbody></table>";
dojo.declare("dojox.grid.enhanced.plugins.filter.FilterStatusTip",null,{constructor:function(args){
var _c2c=this.plugin=args.plugin;
this._statusHeader=["<table border='0' cellspacing='0' class='",_c23,"'><thead><tr class='",_c24,"'><th class='",_c25,"'><div>",_c2c.nls["statusTipHeaderColumn"],"</div></th><th class='",_c25," lastColumn'><div>",_c2c.nls["statusTipHeaderCondition"],"</div></th></tr></thead><tbody>"].join("");
this._removedCriterias=[];
this._rules=[];
this.statusPane=new dojox.grid.enhanced.plugins.filter.FilterStatusPane();
this._dlg=new dijit.TooltipDialog({"class":"dojoxGridFStatusTipDialog",content:this.statusPane,autofocus:false,onMouseLeave:dojo.hitch(this,function(){
this.closeDialog();
})});
this._dlg.connect(this._dlg.domNode,"click",dojo.hitch(this,this._modifyFilter));
},destroy:function(){
this._dlg.destroyRecursive();
},showDialog:function(_c2d,_c2e,_c2f){
this._pos={x:_c2d,y:_c2e};
dijit.popup.close(this._dlg);
this._removedCriterias=[];
this._rules=[];
this._updateStatus(_c2f);
dijit.popup.open({popup:this._dlg,parent:this.plugin.filterBar,x:_c2d-12,y:_c2e-3});
},closeDialog:function(){
dijit.popup.close(this._dlg);
if(this._removedCriterias.length){
this.plugin.filterDefDialog.removeCriteriaBoxes(this._removedCriterias);
this._removedCriterias=[];
this.plugin.filterDefDialog.onFilter();
}
},_updateStatus:function(_c30){
var res,p=this.plugin,nls=p.nls,sp=this.statusPane,fdg=p.filterDefDialog;
if(fdg.getCriteria()===0){
sp.statusTitle.innerHTML=nls["statusTipTitleNoFilter"];
sp.statusRel.innerHTML="";
var cell=p.grid.layout.cells[_c30];
var _c31=cell?"'"+(cell.name||cell.field)+"'":nls["anycolumn"];
res=dojo.string.substitute(nls["statusTipMsg"],[_c31]);
}else{
sp.statusTitle.innerHTML=nls["statusTipTitleHasFilter"];
sp.statusRel.innerHTML=fdg._relOpCls=="logicall"?nls["statusTipRelAll"]:nls["statusTipRelAny"];
this._rules=[];
var i=0,c=fdg.getCriteria(i++);
while(c){
c.index=i-1;
this._rules.push(c);
c=fdg.getCriteria(i++);
}
res=this._createStatusDetail();
}
sp.statusDetailNode.innerHTML=res;
this._addButtonForRules();
},_createStatusDetail:function(){
return this._statusHeader+dojo.map(this._rules,function(rule,i){
return this._getCriteriaStr(rule,i);
},this).join("")+_c2b;
},_addButtonForRules:function(){
if(this._rules.length>1){
dojo.query("."+_c28,this.statusPane.statusDetailNode).forEach(dojo.hitch(this,function(nd,idx){
(new dijit.form.Button({label:this.plugin.nls["removeRuleButton"],showLabel:false,iconClass:_c2a,onClick:dojo.hitch(this,function(e){
e.stopPropagation();
this._removedCriterias.push(this._rules[idx].index);
this._rules.splice(idx,1);
this.statusPane.statusDetailNode.innerHTML=this._createStatusDetail();
this._addButtonForRules();
})})).placeAt(nd,"last");
}));
}
},_getCriteriaStr:function(c,_c32){
var res=["<tr class='",_c26," ",(_c32%2?_c27:""),"'><td class='",_c25,"'>",c.colTxt,"</td><td class='",_c25,"'><div class='",_c28,"'><span class='",_c29,"'>",c.condTxt,"&nbsp;</span>",c.formattedVal,"</div></td></tr>"];
return res.join("");
},_modifyFilter:function(){
this.closeDialog();
var p=this.plugin;
p.filterDefDialog.showDialog(p.filterBar.getColumnIdx(this._pos.x));
}});
dojo.declare("dojox.grid.enhanced.plugins.filter.FilterStatusPane",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dojox.grid","enhanced/templates/FilterStatusPane.html","<div class=\"dojoxGridFStatusTip\"\r\n\t><div class=\"dojoxGridFStatusTipHead\"\r\n\t\t><span class=\"dojoxGridFStatusTipTitle\" dojoAttachPoint=\"statusTitle\"></span\r\n\t\t><span class=\"dojoxGridFStatusTipRel\" dojoAttachPoint=\"statusRel\"></span\r\n\t></div\r\n\t><div class=\"dojoxGridFStatusTipDetail\" dojoAttachPoint=\"statusDetailNode\"\r\n\t></div\r\n></div>\r\n")});
})();
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.filter.ClearFilterConfirm"]){
dojo._hasResource["dojox.grid.enhanced.plugins.filter.ClearFilterConfirm"]=true;
dojo.provide("dojox.grid.enhanced.plugins.filter.ClearFilterConfirm");
dojo.declare("dojox.grid.enhanced.plugins.filter.ClearFilterConfirm",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dojox.grid","enhanced/templates/ClearFilterConfirmPane.html","<div class=\"dojoxGridClearFilterConfirm\">\r\n\t<div class=\"dojoxGridClearFilterMsg\">\r\n\t\t${_clearFilterMsg}\r\n\t</div>\r\n\t<div class=\"dojoxGridClearFilterBtns\" dojoAttachPoint=\"btnsNode\">\r\n\t\t<span dojoType=\"dijit.form.Button\" label=\"${_cancelBtnLabel}\" dojoAttachPoint=\"cancelBtn\" dojoAttachEvent=\"onClick:_onCancel\"></span>\r\n\t\t<span dojoType=\"dijit.form.Button\" label=\"${_clearBtnLabel}\" dojoAttachPoint=\"clearBtn\" dojoAttachEvent=\"onClick:_onClear\"></span>\r\n\t</div>\r\n</div>\r\n"),widgetsInTemplate:true,plugin:null,postMixInProperties:function(){
var nls=this.plugin.nls;
this._clearBtnLabel=nls["clearButton"];
this._cancelBtnLabel=nls["cancelButton"];
this._clearFilterMsg=nls["clearFilterMsg"];
},postCreate:function(){
this.inherited(arguments);
this.cancelBtn.domNode.setAttribute("aria-label",this.plugin.nls["waiCancelButton"]);
this.clearBtn.domNode.setAttribute("aria-label",this.plugin.nls["waiClearButton"]);
},uninitialize:function(){
this.plugin=null;
},_onCancel:function(){
this.plugin.clearFilterDialog.hide();
},_onClear:function(){
this.plugin.clearFilterDialog.hide();
this.plugin.filterDefDialog.clearFilter(this.plugin.filterDefDialog._clearWithoutRefresh);
}});
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.Filter"]){
dojo._hasResource["dojox.grid.enhanced.plugins.Filter"]=true;
dojo.provide("dojox.grid.enhanced.plugins.Filter");
(function(){
var ns=dojox.grid.enhanced.plugins,fns=ns.filter;
dojo.declare("dojox.grid.enhanced.plugins.Filter",dojox.grid.enhanced._Plugin,{name:"filter",constructor:function(grid,args){
this.grid=grid;
this.nls=dojo.i18n.getLocalization("dojox.grid.enhanced","Filter");
args=this.args=dojo.isObject(args)?args:{};
if(typeof args.ruleCount!="number"||args.ruleCount<0){
args.ruleCount=3;
}
var rc=this.ruleCountToConfirmClearFilter=args.ruleCountToConfirmClearFilter;
if(rc===undefined){
this.ruleCountToConfirmClearFilter=2;
}
this._wrapStore();
var obj={"plugin":this};
this.clearFilterDialog=new dojox.grid.enhanced.plugins.Dialog({refNode:this.grid.domNode,title:this.nls["clearFilterDialogTitle"],content:new fns.ClearFilterConfirm(obj)});
this.filterDefDialog=new fns.FilterDefDialog(obj);
this.filterBar=new fns.FilterBar(obj);
this.filterStatusTip=new fns.FilterStatusTip(obj);
grid.onFilterDefined=function(){
};
this.connect(grid.layer("filter"),"onFilterDefined",function(_c33){
grid.onFilterDefined(grid.getFilter(),grid.getFilterRelation());
});
},destroy:function(){
this.inherited(arguments);
try{
this.grid.unwrap("filter");
this.filterBar.destroyRecursive();
this.filterBar=null;
this.clearFilterDialog.destroyRecursive();
this.clearFilterDialog=null;
this.filterStatusTip.destroy();
this.filterStatusTip=null;
this.filterDefDialog.destroy();
this.filterDefDialog=null;
this.grid=null;
this.nls=null;
this.args=null;
}
catch(e){
console.warn("Filter.destroy() error:",e);
}
},_wrapStore:function(){
var g=this.grid;
var args=this.args;
var _c34=args.isServerSide?new fns.ServerSideFilterLayer(args):new fns.ClientSideFilterLayer({cacheSize:args.filterCacheSize,fetchAll:args.fetchAllOnFirstFilter,getter:this._clientFilterGetter});
ns.wrap(g,"_storeLayerFetch",_c34);
this.connect(g,"_onDelete",dojo.hitch(_c34,"invalidate"));
},onSetStore:function(_c35){
this.filterDefDialog.clearFilter(true);
},_clientFilterGetter:function(_c36,cell,_c37){
return cell.get(_c37,_c36);
}});
})();
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.Filter);
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.IndirectSelection"]){
dojo._hasResource["dojox.grid.enhanced.plugins.IndirectSelection"]=true;
dojo.provide("dojox.grid.enhanced.plugins.IndirectSelection");
dojo.declare("dojox.grid.enhanced.plugins.IndirectSelection",dojox.grid.enhanced._Plugin,{name:"indirectSelection",constructor:function(){
var _c38=this.grid.layout;
this.connect(_c38,"setStructure",dojo.hitch(_c38,this.addRowSelectCell,this.option));
},addRowSelectCell:function(_c39){
if(!this.grid.indirectSelection||this.grid.selectionMode=="none"){
return;
}
var _c3a=false,_c3b=["get","formatter","field","fields"],_c3c={type:dojox.grid.cells.MultipleRowSelector,name:"",width:"30px",styles:"text-align: center;"};
if(_c39.headerSelector){
_c39.name="";
}
if(this.grid.rowSelectCell){
this.grid.rowSelectCell.destroy();
}
dojo.forEach(this.structure,function(view){
var _c3d=view.cells;
if(_c3d&&_c3d.length>0&&!_c3a){
var _c3e=_c3d[0];
if(_c3e[0]&&_c3e[0].isRowSelector){
_c3a=true;
return;
}
var _c3f,_c40=this.grid.selectionMode=="single"?dojox.grid.cells.SingleRowSelector:dojox.grid.cells.MultipleRowSelector;
_c3f=dojo.mixin(_c3c,_c39,{type:_c40,editable:false,notselectable:true,filterable:false,navigatable:true,nosort:true});
dojo.forEach(_c3b,function(_c41){
if(_c41 in _c3f){
delete _c3f[_c41];
}
});
if(_c3d.length>1){
_c3f.rowSpan=_c3d.length;
}
dojo.forEach(this.cells,function(cell,i){
if(cell.index>=0){
cell.index+=1;
}else{
console.warn("Error:IndirectSelection.addRowSelectCell()-  cell "+i+" has no index!");
}
});
var _c42=this.addCellDef(0,0,_c3f);
_c42.index=0;
_c3e.unshift(_c42);
this.cells.unshift(_c42);
this.grid.rowSelectCell=_c42;
_c3a=true;
}
},this);
this.cellCount=this.cells.length;
},destroy:function(){
this.grid.rowSelectCell.destroy();
delete this.grid.rowSelectCell;
this.inherited(arguments);
}});
dojo.declare("dojox.grid.cells.RowSelector",dojox.grid.cells._Widget,{inputType:"",map:null,disabledMap:null,isRowSelector:true,_connects:null,_subscribes:null,checkedText:"&#10003;",unCheckedText:"O",constructor:function(){
this.map={};
this.disabledMap={},this.disabledCount=0;
this._connects=[];
this._subscribes=[];
this.inA11YMode=dojo.hasClass(dojo.body(),"dijit_a11y");
this.baseClass="dojoxGridRowSelector dijitReset dijitInline dijit"+this.inputType;
this.checkedClass=" dijit"+this.inputType+"Checked";
this.disabledClass=" dijit"+this.inputType+"Disabled";
this.checkedDisabledClass=" dijit"+this.inputType+"CheckedDisabled";
this.statusTextClass=" dojoxGridRowSelectorStatusText";
this._connects.push(dojo.connect(this.grid,"dokeyup",this,"_dokeyup"));
this._connects.push(dojo.connect(this.grid.selection,"onSelected",this,"_onSelected"));
this._connects.push(dojo.connect(this.grid.selection,"onDeselected",this,"_onDeselected"));
this._connects.push(dojo.connect(this.grid.scroller,"invalidatePageNode",this,"_pageDestroyed"));
this._connects.push(dojo.connect(this.grid,"onCellClick",this,"_onClick"));
this._connects.push(dojo.connect(this.grid,"updateRow",this,"_onUpdateRow"));
},formatter:function(data,_c43,_c44){
var _c45=_c44;
var _c46=_c45.baseClass;
var _c47=_c45.getValue(_c43);
var _c48=!!_c45.disabledMap[_c43];
if(_c47){
_c46+=_c45.checkedClass;
if(_c48){
_c46+=_c45.checkedDisabledClass;
}
}else{
if(_c48){
_c46+=_c45.disabledClass;
}
}
return ["<div tabindex = -1 ","id = '"+_c45.grid.id+"_rowSelector_"+_c43+"' ","name = '"+_c45.grid.id+"_rowSelector' class = '"+_c46+"' ","role = 'presentation' aria-pressed = '"+_c47+"' aria-disabled = '"+_c48+"' aria-label = '"+dojo.string.substitute(_c45.grid._nls["indirectSelection"+_c45.inputType],[_c43+1])+"'>","<span class = '"+_c45.statusTextClass+"'>"+(_c47?_c45.checkedText:_c45.unCheckedText)+"</span>","</div>"].join("");
},setValue:function(_c49,_c4a){
},getValue:function(_c4b){
return this.grid.selection.isSelected(_c4b);
},toggleRow:function(_c4c,_c4d){
this._nativeSelect(_c4c,_c4d);
},setDisabled:function(_c4e,_c4f){
if(_c4e<0){
return;
}
this._toggleDisabledStyle(_c4e,_c4f);
},disabled:function(_c50){
return !!this.disabledMap[_c50];
},_onClick:function(e){
if(e.cell===this){
this._selectRow(e);
}
},_dokeyup:function(e){
if(e.cellIndex==this.index&&e.rowIndex>=0&&e.keyCode==dojo.keys.SPACE){
this._selectRow(e);
}
},focus:function(_c51){
var _c52=this.map[_c51];
if(_c52){
_c52.focus();
}
},_focusEndingCell:function(_c53,_c54){
var cell=this.grid.getCell(_c54);
this.grid.focus.setFocusCell(cell,_c53);
},_nativeSelect:function(_c55,_c56){
this.grid.selection[_c56?"select":"deselect"](_c55);
},_onSelected:function(_c57){
this._toggleCheckedStyle(_c57,true);
},_onDeselected:function(_c58){
this._toggleCheckedStyle(_c58,false);
},_onUpdateRow:function(_c59){
delete this.map[_c59];
},_toggleCheckedStyle:function(_c5a,_c5b){
var _c5c=this._getSelector(_c5a);
if(_c5c){
dojo.toggleClass(_c5c,this.checkedClass,_c5b);
if(this.disabledMap[_c5a]){
dojo.toggleClass(_c5c,this.checkedDisabledClass,_c5b);
}
_c5c.setAttribute("aria-pressed",_c5b);
if(this.inA11YMode){
dojo.attr(_c5c.firstChild,"innerHTML",_c5b?this.checkedText:this.unCheckedText);
}
}
},_toggleDisabledStyle:function(_c5d,_c5e){
var _c5f=this._getSelector(_c5d);
if(_c5f){
dojo.toggleClass(_c5f,this.disabledClass,_c5e);
if(this.getValue(_c5d)){
dojo.toggleClass(_c5f,this.checkedDisabledClass,_c5e);
}
_c5f.setAttribute("aria-disabled",_c5e);
}
this.disabledMap[_c5d]=_c5e;
if(_c5d>=0){
this.disabledCount+=_c5e?1:-1;
}
},_getSelector:function(_c60){
var _c61=this.map[_c60];
if(!_c61){
var _c62=this.view.rowNodes[_c60];
if(_c62){
_c61=dojo.query(".dojoxGridRowSelector",_c62)[0];
if(_c61){
this.map[_c60]=_c61;
}
}
}
return _c61;
},_pageDestroyed:function(_c63){
var _c64=this.grid.scroller.rowsPerPage;
var _c65=_c63*_c64,end=_c65+_c64-1;
for(var i=_c65;i<=end;i++){
if(!this.map[i]){
continue;
}
dojo.destroy(this.map[i]);
delete this.map[i];
}
},destroy:function(){
for(var i in this.map){
dojo.destroy(this.map[i]);
delete this.map[i];
}
for(i in this.disabledMap){
delete this.disabledMap[i];
}
dojo.forEach(this._connects,dojo.disconnect);
dojo.forEach(this._subscribes,dojo.unsubscribe);
delete this._connects;
delete this._subscribes;
}});
dojo.declare("dojox.grid.cells.SingleRowSelector",dojox.grid.cells.RowSelector,{inputType:"Radio",_selectRow:function(e){
var _c66=e.rowIndex;
if(this.disabledMap[_c66]){
return;
}
this._focusEndingCell(_c66,0);
this._nativeSelect(_c66,!this.grid.selection.selected[_c66]);
}});
dojo.declare("dojox.grid.cells.MultipleRowSelector",dojox.grid.cells.RowSelector,{inputType:"CheckBox",swipeStartRowIndex:-1,swipeMinRowIndex:-1,swipeMaxRowIndex:-1,toSelect:false,lastClickRowIdx:-1,toggleAllTrigerred:false,unCheckedText:"&#9633;",constructor:function(){
this._connects.push(dojo.connect(dojo.doc,"onmouseup",this,"_domouseup"));
this._connects.push(dojo.connect(this.grid,"onRowMouseOver",this,"_onRowMouseOver"));
this._connects.push(dojo.connect(this.grid.focus,"move",this,"_swipeByKey"));
this._connects.push(dojo.connect(this.grid,"onCellMouseDown",this,"_onMouseDown"));
if(this.headerSelector){
this._connects.push(dojo.connect(this.grid.views,"render",this,"_addHeaderSelector"));
this._connects.push(dojo.connect(this.grid,"_onFetchComplete",this,"_addHeaderSelector"));
this._connects.push(dojo.connect(this.grid,"onSelectionChanged",this,"_onSelectionChanged"));
this._connects.push(dojo.connect(this.grid,"onKeyDown",this,function(e){
if(e.rowIndex==-1&&e.cellIndex==this.index&&e.keyCode==dojo.keys.SPACE){
this._toggletHeader();
}
}));
}
},toggleAllSelection:function(_c67){
var grid=this.grid,_c68=grid.selection;
if(_c67){
_c68.selectRange(0,grid.rowCount-1);
}else{
_c68.deselectAll();
}
this.toggleAllTrigerred=true;
},_onMouseDown:function(e){
if(e.cell==this){
this._startSelection(e.rowIndex);
dojo.stopEvent(e);
}
},_onRowMouseOver:function(e){
this._updateSelection(e,0);
},_domouseup:function(e){
if(dojo.isIE){
this.view.content.decorateEvent(e);
}
var _c69=e.cellIndex>=0&&this.inSwipeSelection()&&!this.grid.edit.isEditRow(e.rowIndex);
if(_c69){
this._focusEndingCell(e.rowIndex,e.cellIndex);
}
this._finishSelect();
},_dokeyup:function(e){
this.inherited(arguments);
if(!e.shiftKey){
this._finishSelect();
}
},_startSelection:function(_c6a){
this.swipeStartRowIndex=this.swipeMinRowIndex=this.swipeMaxRowIndex=_c6a;
this.toSelect=!this.getValue(_c6a);
},_updateSelection:function(e,_c6b){
if(!this.inSwipeSelection()){
return;
}
var _c6c=_c6b!==0;
var _c6d=e.rowIndex,_c6e=_c6d-this.swipeStartRowIndex+_c6b;
if(_c6e>0&&this.swipeMaxRowIndex<_c6d+_c6b){
this.swipeMaxRowIndex=_c6d+_c6b;
}
if(_c6e<0&&this.swipeMinRowIndex>_c6d+_c6b){
this.swipeMinRowIndex=_c6d+_c6b;
}
var min=_c6e>0?this.swipeStartRowIndex:_c6d+_c6b;
var max=_c6e>0?_c6d+_c6b:this.swipeStartRowIndex;
for(var i=this.swipeMinRowIndex;i<=this.swipeMaxRowIndex;i++){
if(this.disabledMap[i]||i<0){
continue;
}
if(i>=min&&i<=max){
this._nativeSelect(i,this.toSelect);
}else{
if(!_c6c){
this._nativeSelect(i,!this.toSelect);
}
}
}
},_swipeByKey:function(_c6f,_c70,e){
if(!e||_c6f===0||!e.shiftKey||e.cellIndex!=this.index||this.grid.focus.rowIndex<0){
return;
}
var _c71=e.rowIndex;
if(this.swipeStartRowIndex<0){
this.swipeStartRowIndex=_c71;
if(_c6f>0){
this.swipeMaxRowIndex=_c71+_c6f;
this.swipeMinRowIndex=_c71;
}else{
this.swipeMinRowIndex=_c71+_c6f;
this.swipeMaxRowIndex=_c71;
}
this.toSelect=this.getValue(_c71);
}
this._updateSelection(e,_c6f);
},_finishSelect:function(){
this.swipeStartRowIndex=-1;
this.swipeMinRowIndex=-1;
this.swipeMaxRowIndex=-1;
this.toSelect=false;
},inSwipeSelection:function(){
return this.swipeStartRowIndex>=0;
},_nativeSelect:function(_c72,_c73){
this.grid.selection[_c73?"addToSelection":"deselect"](_c72);
},_selectRow:function(e){
var _c74=e.rowIndex;
if(this.disabledMap[_c74]){
return;
}
dojo.stopEvent(e);
this._focusEndingCell(_c74,0);
var _c75=_c74-this.lastClickRowIdx;
var _c76=!this.grid.selection.selected[_c74];
if(this.lastClickRowIdx>=0&&!e.ctrlKey&&!e.altKey&&e.shiftKey){
var min=_c75>0?this.lastClickRowIdx:_c74;
var max=_c75>0?_c74:this.lastClickRowIdx;
for(var i=min;i>=0&&i<=max;i++){
this._nativeSelect(i,_c76);
}
}else{
this._nativeSelect(_c74,_c76);
}
this.lastClickRowIdx=_c74;
},getValue:function(_c77){
if(_c77==-1){
var g=this.grid;
return g.rowCount>0&&g.rowCount<=g.selection.getSelectedCount();
}
return this.inherited(arguments);
},_addHeaderSelector:function(){
var _c78=this.view.getHeaderCellNode(this.index);
if(!_c78){
return;
}
dojo.empty(_c78);
var g=this.grid;
var _c79=_c78.appendChild(dojo.create("div",{"aria-label":g._nls["selectAll"],"tabindex":-1,"id":g.id+"_rowSelector_-1","class":this.baseClass,"role":"presentation","innerHTML":"<span class = '"+this.statusTextClass+"'></span><span style='height: 0; width: 0; overflow: hidden; display: block;'>"+g._nls["selectAll"]+"</span>"}));
this.map[-1]=_c79;
var idx=this._headerSelectorConnectIdx;
if(idx!==undefined){
dojo.disconnect(this._connects[idx]);
this._connects.splice(idx,1);
}
this._headerSelectorConnectIdx=this._connects.length;
this._connects.push(dojo.connect(_c79,"onclick",this,"_toggletHeader"));
this._onSelectionChanged();
},_toggletHeader:function(){
if(!!this.disabledMap[-1]){
return;
}
this.grid._selectingRange=true;
this.toggleAllSelection(!this.getValue(-1));
this._onSelectionChanged();
this.grid._selectingRange=false;
},_onSelectionChanged:function(){
var g=this.grid;
if(!this.map[-1]||g._selectingRange){
return;
}
g.allItemsSelected=this.getValue(-1);
this._toggleCheckedStyle(-1,g.allItemsSelected);
},_toggleDisabledStyle:function(_c7a,_c7b){
this.inherited(arguments);
if(this.headerSelector){
var _c7c=(this.grid.rowCount==this.disabledCount);
if(_c7c!=!!this.disabledMap[-1]){
arguments[0]=-1;
arguments[1]=_c7c;
this.inherited(arguments);
}
}
}});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.IndirectSelection,{"preInit":true});
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.NestedSorting"]){
dojo._hasResource["dojox.grid.enhanced.plugins.NestedSorting"]=true;
dojo.provide("dojox.grid.enhanced.plugins.NestedSorting");
dojo.declare("dojox.grid.enhanced.plugins.NestedSorting",dojox.grid.enhanced._Plugin,{name:"nestedSorting",_currMainSort:"none",_currRegionIdx:-1,_a11yText:{"dojoxGridDescending":"&#9662;","dojoxGridAscending":"&#9652;","dojoxGridAscendingTip":"&#1784;","dojoxGridDescendingTip":"&#1783;","dojoxGridUnsortedTip":"x"},constructor:function(){
this._sortDef=[];
this._sortData={};
this._headerNodes={};
this._excludedColIdx=[];
this.nls=this.grid._nls;
this.grid.setSortInfo=function(){
};
this.grid.setSortIndex=dojo.hitch(this,"_setGridSortIndex");
this.grid.getSortIndex=function(){
};
this.grid.getSortProps=dojo.hitch(this,"getSortProps");
if(this.grid.sortFields){
this._setGridSortIndex(this.grid.sortFields,null,true);
}
this.connect(this.grid.views,"render","_initSort");
this.initCookieHandler();
dojo.subscribe("dojox/grid/rearrange/move/"+this.grid.id,dojo.hitch(this,"_onColumnDnD"));
},onStartUp:function(){
this.inherited(arguments);
this.connect(this.grid,"onHeaderCellClick","_onHeaderCellClick");
this.connect(this.grid,"onHeaderCellMouseOver","_onHeaderCellMouseOver");
this.connect(this.grid,"onHeaderCellMouseOut","_onHeaderCellMouseOut");
},_onColumnDnD:function(type,_c7d){
if(type!=="col"){
return;
}
var m=_c7d,obj={},d=this._sortData,p;
var cr=this._getCurrentRegion();
this._blurRegion(cr);
var idx=dojo.attr(this._getRegionHeader(cr),"idx");
for(p in m){
if(d[p]){
obj[m[p]]=d[p];
delete d[p];
}
if(p===idx){
idx=m[p];
}
}
for(p in obj){
d[p]=obj[p];
}
var c=this._headerNodes[idx];
this._currRegionIdx=dojo.indexOf(this._getRegions(),c.firstChild);
this._initSort(false);
},_setGridSortIndex:function(_c7e,_c7f,_c80){
if(dojo.isArray(_c7e)){
var i,d,cell;
for(i=0;i<_c7e.length;i++){
d=_c7e[i];
cell=this.grid.getCellByField(d.attribute);
if(!cell){
console.warn("Invalid sorting option, column ",d.attribute," not found.");
return;
}
if(cell["nosort"]||!this.grid.canSort(cell.index,cell.field)){
console.warn("Invalid sorting option, column ",d.attribute," is unsortable.");
return;
}
}
this.clearSort();
dojo.forEach(_c7e,function(d,i){
cell=this.grid.getCellByField(d.attribute);
this.setSortData(cell.index,"index",i);
this.setSortData(cell.index,"order",d.descending?"desc":"asc");
},this);
}else{
if(!isNaN(_c7e)){
if(_c7f===undefined){
return;
}
this.setSortData(_c7e,"order",_c7f?"asc":"desc");
}else{
return;
}
}
this._updateSortDef();
if(!_c80){
this.grid.sort();
}
},getSortProps:function(){
return this._sortDef.length?this._sortDef:null;
},_initSort:function(_c81){
var g=this.grid,n=g.domNode,len=this._sortDef.length;
dojo.toggleClass(n,"dojoxGridSorted",!!len);
dojo.toggleClass(n,"dojoxGridSingleSorted",len===1);
dojo.toggleClass(n,"dojoxGridNestSorted",len>1);
if(len>0){
this._currMainSort=this._sortDef[0].descending?"desc":"asc";
}
var idx,_c82=this._excludedCoIdx=[];
this._headerNodes=dojo.query("th",g.viewsHeaderNode).forEach(function(n){
idx=parseInt(dojo.attr(n,"idx"),10);
if(dojo.style(n,"display")==="none"||g.layout.cells[idx]["nosort"]||(g.canSort&&!g.canSort(idx,g.layout.cells[idx]["field"]))){
_c82.push(idx);
}
});
this._headerNodes.forEach(this._initHeaderNode,this);
this._initFocus();
if(_c81){
this._focusHeader();
}
},_initHeaderNode:function(node){
dojo.toggleClass(node,"dojoxGridSortNoWrap",true);
var _c83=dojo.query(".dojoxGridSortNode",node)[0];
if(_c83){
dojo.toggleClass(_c83,"dojoxGridSortNoWrap",true);
}
if(dojo.indexOf(this._excludedCoIdx,dojo.attr(node,"idx"))>=0){
dojo.addClass(node,"dojoxGridNoSort");
return;
}
if(!dojo.query(".dojoxGridSortBtn",node).length){
this._connects=dojo.filter(this._connects,function(conn){
if(conn._sort){
dojo.disconnect(conn);
return false;
}
return true;
});
var n=dojo.create("a",{className:"dojoxGridSortBtn dojoxGridSortBtnNested",title:dojo.string.substitute(this.nls.sortingState,[this.nls.nestedSort,this.nls.ascending]),innerHTML:"1"},node.firstChild,"last");
n.onmousedown=dojo.stopEvent;
n=dojo.create("a",{className:"dojoxGridSortBtn dojoxGridSortBtnSingle",title:dojo.string.substitute(this.nls.sortingState,[this.nls.singleSort,this.nls.ascending])},node.firstChild,"last");
n.onmousedown=dojo.stopEvent;
}else{
var a1=dojo.query(".dojoxGridSortBtnSingle",node)[0];
var a2=dojo.query(".dojoxGridSortBtnNested",node)[0];
a1.className="dojoxGridSortBtn dojoxGridSortBtnSingle";
a2.className="dojoxGridSortBtn dojoxGridSortBtnNested";
a2.innerHTML="1";
dojo.removeClass(node,"dojoxGridCellShowIndex");
dojo.removeClass(node.firstChild,"dojoxGridSortNodeSorted");
dojo.removeClass(node.firstChild,"dojoxGridSortNodeAsc");
dojo.removeClass(node.firstChild,"dojoxGridSortNodeDesc");
dojo.removeClass(node.firstChild,"dojoxGridSortNodeMain");
dojo.removeClass(node.firstChild,"dojoxGridSortNodeSub");
}
this._updateHeaderNodeUI(node);
},_onHeaderCellClick:function(e){
this._focusRegion(e.target);
if(dojo.hasClass(e.target,"dojoxGridSortBtn")){
this._onSortBtnClick(e);
dojo.stopEvent(e);
this._focusRegion(this._getCurrentRegion());
}
},_onHeaderCellMouseOver:function(e){
if(!e.cell){
return;
}
if(this._sortDef.length>1){
return;
}
if(this._sortData[e.cellIndex]&&this._sortData[e.cellIndex].index===0){
return;
}
var p;
for(p in this._sortData){
if(this._sortData[p]&&this._sortData[p].index===0){
dojo.addClass(this._headerNodes[p],"dojoxGridCellShowIndex");
break;
}
}
if(!dojo.hasClass(dojo.body(),"dijit_a11y")){
return;
}
var i=e.cell.index,node=e.cellNode;
var _c84=dojo.query(".dojoxGridSortBtnSingle",node)[0];
var _c85=dojo.query(".dojoxGridSortBtnNested",node)[0];
var _c86="none";
if(dojo.hasClass(this.grid.domNode,"dojoxGridSingleSorted")){
_c86="single";
}else{
if(dojo.hasClass(this.grid.domNode,"dojoxGridNestSorted")){
_c86="nested";
}
}
var _c87=dojo.attr(_c85,"orderIndex");
if(_c87===null||_c87===undefined){
dojo.attr(_c85,"orderIndex",_c85.innerHTML);
_c87=_c85.innerHTML;
}
if(this.isAsc(i)){
_c85.innerHTML=_c87+this._a11yText.dojoxGridDescending;
}else{
if(this.isDesc(i)){
_c85.innerHTML=_c87+this._a11yText.dojoxGridUnsortedTip;
}else{
_c85.innerHTML=_c87+this._a11yText.dojoxGridAscending;
}
}
if(this._currMainSort==="none"){
_c84.innerHTML=this._a11yText.dojoxGridAscending;
}else{
if(this._currMainSort==="asc"){
_c84.innerHTML=this._a11yText.dojoxGridDescending;
}else{
if(this._currMainSort==="desc"){
_c84.innerHTML=this._a11yText.dojoxGridUnsortedTip;
}
}
}
this._updateA11y(node);
},_onHeaderCellMouseOut:function(e){
var p;
for(p in this._sortData){
if(this._sortData[p]&&this._sortData[p].index===0){
dojo.removeClass(this._headerNodes[p],"dojoxGridCellShowIndex");
break;
}
}
if(e.cellNode){
this._updateA11y(e.cellNode);
}
},_onSortBtnClick:function(e){
var _c88=e.cell.index;
if(dojo.hasClass(e.target,"dojoxGridSortBtnSingle")){
this._prepareSingleSort(_c88);
}else{
if(dojo.hasClass(e.target,"dojoxGridSortBtnNested")){
this._prepareNestedSort(_c88);
}else{
return;
}
}
dojo.stopEvent(e);
this._doSort(_c88);
},_doSort:function(_c89){
if(!this._sortData[_c89]||!this._sortData[_c89].order){
this.setSortData(_c89,"order","asc");
}else{
if(this.isAsc(_c89)){
this.setSortData(_c89,"order","desc");
}else{
if(this.isDesc(_c89)){
this.removeSortData(_c89);
}
}
}
this._updateSortDef();
this.grid.sort();
this._initSort(true);
},setSortData:function(_c8a,attr,_c8b){
var sd=this._sortData[_c8a];
if(!sd){
sd=this._sortData[_c8a]={};
}
sd[attr]=_c8b;
},removeSortData:function(_c8c){
var d=this._sortData,i=d[_c8c].index,p;
delete d[_c8c];
for(p in d){
if(d[p].index>i){
d[p].index--;
}
}
},_prepareSingleSort:function(_c8d){
var d=this._sortData,p;
for(p in d){
delete d[p];
}
this.setSortData(_c8d,"index",0);
this.setSortData(_c8d,"order",this._currMainSort==="none"?null:this._currMainSort);
if(!this._sortData[_c8d]||!this._sortData[_c8d].order){
this._currMainSort="asc";
}else{
if(this.isAsc(_c8d)){
this._currMainSort="desc";
}else{
if(this.isDesc(_c8d)){
this._currMainSort="none";
}
}
}
},_prepareNestedSort:function(_c8e){
var i=this._sortData[_c8e]?this._sortData[_c8e].index:null;
if(i===0||!!i){
return;
}
this.setSortData(_c8e,"index",this._sortDef.length);
},_updateSortDef:function(){
this._sortDef.length=0;
var d=this._sortData,p;
for(p in d){
this._sortDef[d[p].index]={attribute:this.grid.layout.cells[p].field,descending:d[p].order==="desc"};
}
},_updateHeaderNodeUI:function(node){
var cell=this._getCellByNode(node);
var _c8f=cell.index;
var data=this._sortData[_c8f];
var _c90=dojo.query(".dojoxGridSortNode",node)[0];
var _c91=dojo.query(".dojoxGridSortBtnSingle",node)[0];
var _c92=dojo.query(".dojoxGridSortBtnNested",node)[0];
dojo.toggleClass(_c91,"dojoxGridSortBtnAsc",this._currMainSort==="asc");
dojo.toggleClass(_c91,"dojoxGridSortBtnDesc",this._currMainSort==="desc");
if(this._currMainSort==="asc"){
_c91.title=dojo.string.substitute(this.nls.sortingState,[this.nls.singleSort,this.nls.descending]);
}else{
if(this._currMainSort==="desc"){
_c91.title=dojo.string.substitute(this.nls.sortingState,[this.nls.singleSort,this.nls.unsorted]);
}else{
_c91.title=dojo.string.substitute(this.nls.sortingState,[this.nls.singleSort,this.nls.ascending]);
}
}
var _c93=this;
function _c94(){
var _c95="Column "+(cell.index+1)+" "+cell.field;
var _c96="none";
var _c97="ascending";
if(data){
_c96=data.order==="asc"?"ascending":"descending";
_c97=data.order==="asc"?"descending":"none";
}
var _c98=_c95+" - is sorted by "+_c96;
var _c99=_c95+" - is nested sorted by "+_c96;
var _c9a=_c95+" - choose to sort by "+_c97;
var _c9b=_c95+" - choose to nested sort by "+_c97;
_c91.setAttribute("aria-label",_c98);
_c92.setAttribute("aria-label",_c99);
var _c9c=[_c93.connect(_c91,"onmouseover",function(){
_c91.setAttribute("aria-label",_c9a);
}),_c93.connect(_c91,"onmouseout",function(){
_c91.setAttribute("aria-label",_c98);
}),_c93.connect(_c92,"onmouseover",function(){
_c92.setAttribute("aria-label",_c9b);
}),_c93.connect(_c92,"onmouseout",function(){
_c92.setAttribute("aria-label",_c99);
})];
dojo.forEach(_c9c,function(_c9d){
_c9d._sort=true;
});
};
_c94();
var a11y=dojo.hasClass(dojo.body(),"dijit_a11y");
if(!data){
_c92.innerHTML=this._sortDef.length+1;
_c92.title=dojo.string.substitute(this.nls.sortingState,[this.nls.nestedSort,this.nls.ascending]);
}else{
if(data.index||(data.index===0&&this._sortDef.length>1)){
_c92.innerHTML=data.index+1;
}
dojo.addClass(_c90,"dojoxGridSortNodeSorted");
if(this.isAsc(_c8f)){
dojo.addClass(_c90,"dojoxGridSortNodeAsc");
_c92.title=dojo.string.substitute(this.nls.sortingState,[this.nls.nestedSort,this.nls.descending]);
}else{
if(this.isDesc(_c8f)){
dojo.addClass(_c90,"dojoxGridSortNodeDesc");
_c92.title=dojo.string.substitute(this.nls.sortingState,[this.nls.nestedSort,this.nls.unsorted]);
}
}
dojo.addClass(_c90,(data.index===0?"dojoxGridSortNodeMain":"dojoxGridSortNodeSub"));
}
this._updateA11y(node);
},isAsc:function(_c9e){
return this._sortData[_c9e]&&this._sortData[_c9e].order==="asc";
},isDesc:function(_c9f){
return this._sortData[_c9f]&&this._sortData[_c9f].order==="desc";
},_updateA11y:function(node){
if(!dojo.hasClass(dojo.body(),"dijit_a11y")){
return;
}
var cell=this._getCellByNode(node),_ca0=cell.index,data=this._sortData[_ca0];
var nls=this.nls,txt=this._a11yText;
var _ca1=dojo.query(".dojoxGridSortNode",node)[0];
var _ca2=dojo.query(".dojoxGridSortBtnSingle",node)[0];
var _ca3=dojo.query(".dojoxGridSortBtnNested",node)[0];
var _ca4=dojo.hasClass(node,"dojoxGridCellOver")||dojo.hasClass(node,"dojoxGridCellSortFocus");
var idx=(data?data.index:this._sortDef.length)+1;
var s1,s2;
if(this.isAsc(_ca0)){
s2=idx+"&nbsp;"+(_ca4?txt.dojoxGridDescendingTip:txt.dojoxGridAscending);
}else{
if(this.isDesc(_ca0)){
s2=idx+"&nbsp;"+(_ca4?txt.dojoxGridUnsortedTip:txt.dojoxGridDescending);
}else{
s2=idx+"&nbsp;"+(_ca4?txt.dojoxGridAscendingTip:"");
}
}
if(this._currMainSort==="asc"){
s1=_ca4?txt.dojoxGridDescendingTip:txt.dojoxGridAscending;
}else{
if(this._currMainSort==="desc"){
s1=_ca4?txt.dojoxGridUnsortedTip:txt.dojoxGridDescending;
}else{
s1=_ca4?txt.dojoxGridAscendingTip:"";
}
}
_ca2.innerHTML=s1;
_ca3.innerHTML=s2;
},_getCellByNode:function(node){
var i;
for(i=0;i<this._headerNodes.length;i++){
if(this._headerNodes[i]===node){
return this.grid.layout.cells[i];
}
}
return null;
},clearSort:function(){
this._sortData={};
this._sortDef.length=0;
},initCookieHandler:function(){
if(this.grid.addCookieHandler){
this.grid.addCookieHandler({name:"sortOrder",onLoad:dojo.hitch(this,"_loadNestedSortingProps"),onSave:dojo.hitch(this,"_saveNestedSortingProps")});
}
},_loadNestedSortingProps:function(_ca5,grid){
this._setGridSortIndex(_ca5);
},_saveNestedSortingProps:function(grid){
return this.getSortProps();
},_initFocus:function(){
var f=this.focus=this.grid.focus;
this._focusRegions=this._getRegions();
if(!this._headerArea){
var area=this._headerArea=f.getArea("header");
area.onFocus=f.focusHeader=dojo.hitch(this,"_focusHeader");
area.onBlur=f.blurHeader=f._blurHeader=dojo.hitch(this,"_blurHeader");
area.onMove=dojo.hitch(this,"_onMove");
area.onKeyDown=dojo.hitch(this,"_onKeyDown");
area._regions=[];
area.getRegions=null;
this.connect(this.grid,"onBlur","_blurHeader");
}
},_focusHeader:function(evt){
if(this._currRegionIdx===-1){
this._onMove(0,1,null);
}else{
this._focusRegion(this._getCurrentRegion());
}
try{
dojo.stopEvent(evt);
}
catch(e){
}
return true;
},_blurHeader:function(evt){
this._blurRegion(this._getCurrentRegion());
return true;
},_onMove:function(_ca6,_ca7,evt){
var curr=this._currRegionIdx||0,_ca8=this._focusRegions;
var _ca9=_ca8[curr+_ca7];
if(!_ca9){
return;
}else{
if(dojo.style(_ca9,"display")==="none"||dojo.style(_ca9,"visibility")==="hidden"){
this._onMove(_ca6,_ca7+(_ca7>0?1:-1),evt);
return;
}
}
this._focusRegion(_ca9);
var view=this._getRegionView(_ca9);
view.scrollboxNode.scrollLeft=view.headerNode.scrollLeft;
},_onKeyDown:function(e,_caa){
if(_caa){
switch(e.keyCode){
case dojo.keys.ENTER:
case dojo.keys.SPACE:
if(dojo.hasClass(e.target,"dojoxGridSortBtnSingle")||dojo.hasClass(e.target,"dojoxGridSortBtnNested")){
this._onSortBtnClick(e);
}
}
}
},_getRegionView:function(_cab){
var _cac=_cab;
while(_cac&&!dojo.hasClass(_cac,"dojoxGridHeader")){
_cac=_cac.parentNode;
}
if(_cac){
return dojo.filter(this.grid.views.views,function(view){
return view.headerNode===_cac;
})[0]||null;
}
return null;
},_getRegions:function(){
var _cad=[],_cae=this.grid.layout.cells;
this._headerNodes.forEach(function(n,i){
if(dojo.style(n,"display")==="none"){
return;
}
if(_cae[i]["isRowSelector"]){
_cad.push(n);
return;
}
dojo.query(".dojoxGridSortNode,.dojoxGridSortBtnNested,.dojoxGridSortBtnSingle",n).forEach(function(node){
dojo.attr(node,"tabindex",0);
_cad.push(node);
});
},this);
return _cad;
},_focusRegion:function(_caf){
if(!_caf){
return;
}
var _cb0=this._getCurrentRegion();
if(_cb0&&_caf!==_cb0){
this._blurRegion(_cb0);
}
var _cb1=this._getRegionHeader(_caf);
dojo.addClass(_cb1,"dojoxGridCellSortFocus");
if(dojo.hasClass(_caf,"dojoxGridSortNode")){
dojo.addClass(_caf,"dojoxGridSortNodeFocus");
}else{
if(dojo.hasClass(_caf,"dojoxGridSortBtn")){
dojo.addClass(_caf,"dojoxGridSortBtnFocus");
}
}
_caf.focus();
this.focus.currentArea("header");
this._currRegionIdx=dojo.indexOf(this._focusRegions,_caf);
},_blurRegion:function(_cb2){
if(!_cb2){
return;
}
var _cb3=this._getRegionHeader(_cb2);
dojo.removeClass(_cb3,"dojoxGridCellSortFocus");
if(dojo.hasClass(_cb2,"dojoxGridSortNode")){
dojo.removeClass(_cb2,"dojoxGridSortNodeFocus");
}else{
if(dojo.hasClass(_cb2,"dojoxGridSortBtn")){
dojo.removeClass(_cb2,"dojoxGridSortBtnFocus");
}
}
_cb2.blur();
this._updateA11y(_cb3);
},_getCurrentRegion:function(){
return this._focusRegions?this._focusRegions[this._currRegionIdx]:null;
},_getRegionHeader:function(_cb4){
while(_cb4&&!dojo.hasClass(_cb4,"dojoxGridCell")){
_cb4=_cb4.parentNode;
}
return _cb4;
},destroy:function(){
this._sortDef=this._sortData=null;
this._headerNodes=this._focusRegions=null;
this.inherited(arguments);
}});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.NestedSorting);
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.Menu"]){
dojo._hasResource["dojox.grid.enhanced.plugins.Menu"]=true;
dojo.provide("dojox.grid.enhanced.plugins.Menu");
dojo.declare("dojox.grid.enhanced.plugins.Menu",dojox.grid.enhanced._Plugin,{name:"menus",types:["headerMenu","rowMenu","cellMenu","selectedRegionMenu"],constructor:function(){
var g=this.grid;
g.showMenu=dojo.hitch(g,this.showMenu);
g._setRowMenuAttr=dojo.hitch(this,"_setRowMenuAttr");
g._setCellMenuAttr=dojo.hitch(this,"_setCellMenuAttr");
g._setSelectedRegionMenuAttr=dojo.hitch(this,"_setSelectedRegionMenuAttr");
},onStartUp:function(){
var type,_cb5=this.option;
for(type in _cb5){
if(dojo.indexOf(this.types,type)>=0&&_cb5[type]){
this._initMenu(type,_cb5[type]);
}
}
},_initMenu:function(_cb6,menu){
var g=this.grid;
if(!g[_cb6]){
var m=this._getMenuWidget(menu);
if(!m){
return;
}
g.set(_cb6,m);
if(_cb6!="headerMenu"){
m._scheduleOpen=function(){
return;
};
}
}
},_getMenuWidget:function(menu){
return (menu instanceof dijit.Menu)?menu:dijit.byId(menu);
},_setRowMenuAttr:function(menu){
this._setMenuAttr(menu,"rowMenu");
},_setCellMenuAttr:function(menu){
this._setMenuAttr(menu,"cellMenu");
},_setSelectedRegionMenuAttr:function(menu){
this._setMenuAttr(menu,"selectedRegionMenu");
},_setMenuAttr:function(menu,_cb7){
var g=this.grid,n=g.domNode;
if(!menu||!(menu instanceof dijit.Menu)){
console.warn(_cb7," of Grid ",g.id," is not existed!");
return;
}
if(g[_cb7]){
g[_cb7].unBindDomNode(n);
}
g[_cb7]=menu;
g[_cb7].bindDomNode(n);
},showMenu:function(e){
var _cb8=(e.cellNode&&dojo.hasClass(e.cellNode,"dojoxGridRowSelected")||e.rowNode&&(dojo.hasClass(e.rowNode,"dojoxGridRowSelected")||dojo.hasClass(e.rowNode,"dojoxGridRowbarSelected")));
if(_cb8&&this.selectedRegionMenu){
this.onSelectedRegionContextMenu(e);
return;
}
var info={target:e.target,coords:e.keyCode!==dojo.keys.F10&&"pageX" in e?{x:e.pageX,y:e.pageY}:null};
if(this.rowMenu&&(!this.cellMenu||this.selection.isSelected(e.rowIndex)||e.rowNode&&dojo.hasClass(e.rowNode,"dojoxGridRowbar"))){
this.rowMenu._openMyself(info);
dojo.stopEvent(e);
return;
}
if(this.cellMenu){
this.cellMenu._openMyself(info);
}
dojo.stopEvent(e);
},destroy:function(){
var g=this.grid;
if(g.headerMenu){
g.headerMenu.unBindDomNode(g.viewsHeaderNode);
}
if(g.rowMenu){
g.rowMenu.unBindDomNode(g.domNode);
}
if(g.cellMenu){
g.cellMenu.unBindDomNode(g.domNode);
}
if(g.selectedRegionMenu){
g.selectedRegionMenu.destroy();
}
this.inherited(arguments);
}});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.Menu);
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.AutoScroll"]){
dojo._hasResource["dojox.grid.enhanced.plugins.AutoScroll"]=true;
dojo.provide("dojox.grid.enhanced.plugins.AutoScroll");
dojo.declare("dojox.grid.enhanced.plugins.AutoScroll",dojox.grid.enhanced._Plugin,{name:"autoScroll",autoScrollInterval:1000,autoScrollMargin:30,constructor:function(grid,args){
this.grid=grid;
this.readyForAutoScroll=false;
this._scrolling=false;
args=dojo.isObject(args)?args:{};
if("interval" in args){
this.autoScrollInterval=args.interval;
}
if("margin" in args){
this.autoScrollMargin=args.margin;
}
this._initEvents();
this._mixinGrid();
},_initEvents:function(){
var g=this.grid;
this.connect(g,"onCellMouseDown",function(){
this.readyForAutoScroll=true;
});
this.connect(g,"onHeaderCellMouseDown",function(){
this.readyForAutoScroll=true;
});
this.connect(g,"onRowSelectorMouseDown",function(){
this.readyForAutoScroll=true;
});
this.connect(dojo.doc,"onmouseup",function(evt){
this._manageAutoScroll(true);
this.readyForAutoScroll=false;
});
this.connect(dojo.doc,"onmousemove",function(evt){
if(this.readyForAutoScroll){
this._event=evt;
var _cb9=dojo.position(g.domNode),hh=g._getHeaderHeight(),_cba=this.autoScrollMargin,ey=evt.clientY,ex=evt.clientX,gy=_cb9.y,gx=_cb9.x,gh=_cb9.h,gw=_cb9.w;
if(ex>=gx&&ex<=gx+gw){
if(ey>=gy+hh&&ey<gy+hh+_cba){
this._manageAutoScroll(false,true,false);
return;
}else{
if(ey>gy+gh-_cba&&ey<=gy+gh){
this._manageAutoScroll(false,true,true);
return;
}else{
if(ey>=gy&&ey<=gy+gh){
var _cbb=dojo.some(g.views.views,function(view,i){
if(view instanceof dojox.grid._RowSelector){
return false;
}
var _cbc=dojo.position(view.domNode);
if(ex<_cbc.x+_cba&&ex>=_cbc.x){
this._manageAutoScroll(false,false,false,view);
return true;
}else{
if(ex>_cbc.x+_cbc.w-_cba&&ex<_cbc.x+_cbc.w){
this._manageAutoScroll(false,false,true,view);
return true;
}
}
return false;
},this);
if(_cbb){
return;
}
}
}
}
}
this._manageAutoScroll(true);
}
});
},_mixinGrid:function(){
var g=this.grid;
g.onStartAutoScroll=function(){
};
g.onEndAutoScroll=function(){
};
},_fireEvent:function(_cbd,args){
var g=this.grid;
switch(_cbd){
case "start":
g.onStartAutoScroll.apply(g,args);
break;
case "end":
g.onEndAutoScroll.apply(g,args);
break;
}
},_manageAutoScroll:function(_cbe,_cbf,_cc0,view){
if(_cbe){
this._scrolling=false;
clearInterval(this._handler);
}else{
if(!this._scrolling){
this._scrolling=true;
this._fireEvent("start",[_cbf,_cc0,view]);
this._autoScroll(_cbf,_cc0,view);
this._handler=setInterval(dojo.hitch(this,"_autoScroll",_cbf,_cc0,view),this.autoScrollInterval);
}
}
},_autoScroll:function(_cc1,_cc2,view){
var g=this.grid,_cc3=null;
if(_cc1){
var _cc4=g.scroller.firstVisibleRow+(_cc2?1:-1);
if(_cc4>=0&&_cc4<g.rowCount){
g.scrollToRow(_cc4);
_cc3=_cc4;
}
}else{
_cc3=this._scrollColumn(_cc2,view);
}
if(_cc3!==null){
this._fireEvent("end",[_cc1,_cc2,view,_cc3,this._event]);
}
},_scrollColumn:function(_cc5,view){
var node=view.scrollboxNode,_cc6=null;
if(node.clientWidth<node.scrollWidth){
var _cc7=dojo.filter(this.grid.layout.cells,function(cell){
return !cell.hidden;
});
var _cc8=dojo.position(view.domNode);
var _cc9,edge,_cca,i;
if(_cc5){
_cc9=node.clientWidth;
for(i=0;i<_cc7.length;++i){
_cca=dojo.position(_cc7[i].getHeaderNode());
edge=_cca.x-_cc8.x+_cca.w;
if(edge>_cc9){
_cc6=_cc7[i].index;
node.scrollLeft+=edge-_cc9+10;
break;
}
}
}else{
_cc9=0;
for(i=_cc7.length-1;i>=0;--i){
_cca=dojo.position(_cc7[i].getHeaderNode());
edge=_cca.x-_cc8.x;
if(edge<_cc9){
_cc6=_cc7[i].index;
node.scrollLeft+=edge-_cc9-10;
break;
}
}
}
}
return _cc6;
}});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.AutoScroll);
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.Selector"]){
dojo._hasResource["dojox.grid.enhanced.plugins.Selector"]=true;
dojo.provide("dojox.grid.enhanced.plugins.Selector");
(function(){
var _ccb=0,_ccc=1,_ccd=2,_cce={col:"row",row:"col"},_ccf=function(type,_cd0,_cd1,end,_cd2){
if(type!=="cell"){
_cd0=_cd0[type];
_cd1=_cd1[type];
end=end[type];
if(typeof _cd0!=="number"||typeof _cd1!=="number"||typeof end!=="number"){
return false;
}
return _cd2?((_cd0>=_cd1&&_cd0<end)||(_cd0>end&&_cd0<=_cd1)):((_cd0>=_cd1&&_cd0<=end)||(_cd0>=end&&_cd0<=_cd1));
}else{
return _ccf("col",_cd0,_cd1,end,_cd2)&&_ccf("row",_cd0,_cd1,end,_cd2);
}
},_cd3=function(type,v1,v2){
try{
if(v1&&v2){
switch(type){
case "col":
case "row":
return v1[type]==v2[type]&&typeof v1[type]=="number"&&!(_cce[type] in v1)&&!(_cce[type] in v2);
case "cell":
return v1.col==v2.col&&v1.row==v2.row&&typeof v1.col=="number"&&typeof v1.row=="number";
}
}
}
catch(e){
}
return false;
},_cd4=function(evt){
try{
if(evt&&evt.preventDefault){
dojo.stopEvent(evt);
}
}
catch(e){
}
},_cd5=function(type,_cd6,_cd7){
switch(type){
case "col":
return {"col":typeof _cd7=="undefined"?_cd6:_cd7,"except":[]};
case "row":
return {"row":_cd6,"except":[]};
case "cell":
return {"row":_cd6,"col":_cd7};
}
return null;
};
dojo.declare("dojox.grid.enhanced.plugins.Selector",dojox.grid.enhanced._Plugin,{name:"selector",constructor:function(grid,args){
this.grid=grid;
this._config={row:_ccd,col:_ccd,cell:_ccd};
this.noClear=args&&args.noClear;
this.setupConfig(args);
if(grid.selectionMode==="single"){
this._config.row=_ccc;
}
this._enabled=true;
this._selecting={};
this._selected={"col":[],"row":[],"cell":[]};
this._startPoint={};
this._currentPoint={};
this._lastAnchorPoint={};
this._lastEndPoint={};
this._lastSelectedAnchorPoint={};
this._lastSelectedEndPoint={};
this._keyboardSelect={};
this._lastType=null;
this._selectedRowModified={};
this._hacks();
this._initEvents();
this._initAreas();
this._mixinGrid();
},destroy:function(){
this.inherited(arguments);
},setupConfig:function(_cd8){
if(!_cd8||!dojo.isObject(_cd8)){
return;
}
var _cd9=["row","col","cell"];
for(var type in _cd8){
if(dojo.indexOf(_cd9,type)>=0){
if(!_cd8[type]||_cd8[type]=="disabled"){
this._config[type]=_ccb;
}else{
if(_cd8[type]=="single"){
this._config[type]=_ccc;
}else{
this._config[type]=_ccd;
}
}
}
}
var mode=["none","single","extended"][this._config.row];
this.grid.selection.setMode(mode);
},isSelected:function(type,_cda,_cdb){
return this._isSelected(type,_cd5(type,_cda,_cdb));
},toggleSelect:function(type,_cdc,_cdd){
this._startSelect(type,_cd5(type,_cdc,_cdd),this._config[type]===_ccd,false,false,!this.isSelected(type,_cdc,_cdd));
this._endSelect(type);
},select:function(type,_cde,_cdf){
if(!this.isSelected(type,_cde,_cdf)){
this.toggleSelect(type,_cde,_cdf);
}
},deselect:function(type,_ce0,_ce1){
if(this.isSelected(type,_ce0,_ce1)){
this.toggleSelect(type,_ce0,_ce1);
}
},selectRange:function(type,_ce2,end,_ce3){
this.grid._selectingRange=true;
var _ce4=type=="cell"?_cd5(type,_ce2.row,_ce2.col):_cd5(type,_ce2),_ce5=type=="cell"?_cd5(type,end.row,end.col):_cd5(type,end);
this._startSelect(type,_ce4,false,false,false,_ce3);
this._highlight(type,_ce5,_ce3===undefined?true:_ce3);
this._endSelect(type);
this.grid._selectingRange=false;
},clear:function(type){
this._clearSelection(type||"all");
},isSelecting:function(type){
if(typeof type=="undefined"){
return this._selecting.col||this._selecting.row||this._selecting.cell;
}
return this._selecting[type];
},selectEnabled:function(_ce6){
if(typeof _ce6!="undefined"&&!this.isSelecting()){
this._enabled=!!_ce6;
}
return this._enabled;
},getSelected:function(type,_ce7){
switch(type){
case "cell":
return dojo.map(this._selected[type],function(item){
return item;
});
case "col":
case "row":
return dojo.map(_ce7?this._selected[type]:dojo.filter(this._selected[type],function(item){
return item.except.length===0;
}),function(item){
return _ce7?item:item[type];
});
}
return [];
},getSelectedCount:function(type,_ce8){
switch(type){
case "cell":
return this._selected[type].length;
case "col":
case "row":
return (_ce8?this._selected[type]:dojo.filter(this._selected[type],function(item){
return item.except.length===0;
})).length;
}
return 0;
},getSelectedType:function(){
var s=this._selected;
return ["","cell","row","row|cell","col","col|cell","col|row","col|row|cell"][(!!s.cell.length)|(!!s.row.length<<1)|(!!s.col.length<<2)];
},getLastSelectedRange:function(type){
return this._lastAnchorPoint[type]?{"start":this._lastAnchorPoint[type],"end":this._lastEndPoint[type]}:null;
},_hacks:function(){
var g=this.grid;
var _ce9=function(e){
if(e.cellNode){
g.onMouseUp(e);
}
g.onMouseUpRow(e);
};
var _cea=dojo.hitch(g,"onMouseUp");
var _ceb=dojo.hitch(g,"onMouseDown");
var _cec=function(e){
e.cellNode.style.border="solid 1px";
};
dojo.forEach(g.views.views,function(view){
view.content.domouseup=_ce9;
view.header.domouseup=_cea;
if(view.declaredClass=="dojox.grid._RowSelector"){
view.domousedown=_ceb;
view.domouseup=_cea;
view.dofocus=_cec;
}
});
g.selection.clickSelect=function(){
};
this._oldDeselectAll=g.selection.deselectAll;
var _ced=this;
g.selection.selectRange=function(from,to){
_ced.selectRange("row",from,to,true);
if(g.selection.preserver){
g.selection.preserver._updateMapping(true,true,false,from,to);
}
g.selection.onChanged();
};
g.selection.deselectRange=function(from,to){
_ced.selectRange("row",from,to,false);
if(g.selection.preserver){
g.selection.preserver._updateMapping(true,false,false,from,to);
}
g.selection.onChanged();
};
g.selection.deselectAll=function(){
g._selectingRange=true;
_ced._oldDeselectAll.apply(g.selection,arguments);
_ced._clearSelection("all");
g._selectingRange=false;
if(g.selection.preserver){
g.selection.preserver._updateMapping(true,false,true);
}
g.selection.onChanged();
};
var _cee=g.views.views[0];
if(_cee instanceof dojox.grid._RowSelector){
_cee.doStyleRowNode=function(_cef,_cf0){
dojo.removeClass(_cf0,"dojoxGridRow");
dojo.addClass(_cf0,"dojoxGridRowbar");
dojo.addClass(_cf0,"dojoxGridNonNormalizedCell");
dojo.toggleClass(_cf0,"dojoxGridRowbarOver",g.rows.isOver(_cef));
dojo.toggleClass(_cf0,"dojoxGridRowbarSelected",!!g.selection.isSelected(_cef));
};
}
this.connect(g,"updateRow",function(_cf1){
dojo.forEach(g.layout.cells,function(cell){
if(this.isSelected("cell",_cf1,cell.index)){
this._highlightNode(cell.getNode(_cf1),true);
}
},this);
});
},_mixinGrid:function(){
var g=this.grid;
g.setupSelectorConfig=dojo.hitch(this,this.setupConfig);
g.onStartSelect=function(){
};
g.onEndSelect=function(){
};
g.onStartDeselect=function(){
};
g.onEndDeselect=function(){
};
g.onSelectCleared=function(){
};
},_initEvents:function(){
var g=this.grid,_cf2=this,dp=dojo.partial,_cf3=function(type,e){
if(type==="row"){
_cf2._isUsingRowSelector=true;
}
if(_cf2.selectEnabled()&&_cf2._config[type]&&e.button!=2){
if(_cf2._keyboardSelect.col||_cf2._keyboardSelect.row||_cf2._keyboardSelect.cell){
_cf2._endSelect("all");
_cf2._keyboardSelect.col=_cf2._keyboardSelect.row=_cf2._keyboardSelect.cell=0;
}
if(_cf2._usingKeyboard){
_cf2._usingKeyboard=false;
}
var _cf4=_cd5(type,e.rowIndex,e.cell&&e.cell.index);
_cf2._startSelect(type,_cf4,e.ctrlKey,e.shiftKey);
}
},_cf5=dojo.hitch(this,"_endSelect");
this.connect(g,"onHeaderCellMouseDown",dp(_cf3,"col"));
this.connect(g,"onHeaderCellMouseUp",dp(_cf5,"col"));
this.connect(g,"onRowSelectorMouseDown",dp(_cf3,"row"));
this.connect(g,"onRowSelectorMouseUp",dp(_cf5,"row"));
this.connect(g,"onCellMouseDown",function(e){
if(e.cell&&e.cell.isRowSelector){
return;
}
if(g.singleClickEdit){
_cf2._singleClickEdit=true;
g.singleClickEdit=false;
}
_cf3(_cf2._config["cell"]==_ccb?"row":"cell",e);
});
this.connect(g,"onCellMouseUp",function(e){
if(_cf2._singleClickEdit){
delete _cf2._singleClickEdit;
g.singleClickEdit=true;
}
_cf5("all",e);
});
this.connect(g,"onCellMouseOver",function(e){
if(_cf2._curType!="row"&&_cf2._selecting[_cf2._curType]&&_cf2._config[_cf2._curType]==_ccd){
_cf2._highlight("col",_cd5("col",e.cell.index),_cf2._toSelect);
if(!_cf2._keyboardSelect.cell){
_cf2._highlight("cell",_cd5("cell",e.rowIndex,e.cell.index),_cf2._toSelect);
}
}
});
this.connect(g,"onHeaderCellMouseOver",function(e){
if(_cf2._selecting.col&&_cf2._config.col==_ccd){
_cf2._highlight("col",_cd5("col",e.cell.index),_cf2._toSelect);
}
});
this.connect(g,"onRowMouseOver",function(e){
if(_cf2._selecting.row&&_cf2._config.row==_ccd){
_cf2._highlight("row",_cd5("row",e.rowIndex),_cf2._toSelect);
}
});
this.connect(g,"onSelectedById","_onSelectedById");
this.connect(g,"_onFetchComplete",function(){
if(!g._notRefreshSelection){
this._refreshSelected(true);
}
});
this.connect(g.scroller,"buildPage",function(){
if(!g._notRefreshSelection){
this._refreshSelected(true);
}
});
this.connect(dojo.doc,"onmouseup",dp(_cf5,"all"));
this.connect(g,"onEndAutoScroll",function(_cf6,_cf7,view,_cf8){
var _cf9=_cf2._selecting.cell,type,_cfa,dir=_cf7?1:-1;
if(_cf6&&(_cf9||_cf2._selecting.row)){
type=_cf9?"cell":"row";
_cfa=_cf2._currentPoint[type];
_cf2._highlight(type,_cd5(type,_cfa.row+dir,_cfa.col),_cf2._toSelect);
}else{
if(!_cf6&&(_cf9||_cf2._selecting.col)){
type=_cf9?"cell":"col";
_cfa=_cf2._currentPoint[type];
_cf2._highlight(type,_cd5(type,_cfa.row,_cf8),_cf2._toSelect);
}
}
});
this.subscribe("dojox/grid/rearrange/move/"+g.id,"_onInternalRearrange");
this.subscribe("dojox/grid/rearrange/copy/"+g.id,"_onInternalRearrange");
this.subscribe("dojox/grid/rearrange/change/"+g.id,"_onExternalChange");
this.subscribe("dojox/grid/rearrange/insert/"+g.id,"_onExternalChange");
this.subscribe("dojox/grid/rearrange/remove/"+g.id,"clear");
this.connect(g,"onSelected",function(_cfb){
if(this._selectedRowModified&&this._isUsingRowSelector){
delete this._selectedRowModified;
}else{
if(!this.grid._selectingRange){
this.select("row",_cfb);
}
}
});
this.connect(g,"onDeselected",function(_cfc){
if(this._selectedRowModified&&this._isUsingRowSelector){
delete this._selectedRowModified;
}else{
if(!this.grid._selectingRange){
this.deselect("row",_cfc);
}
}
});
},_onSelectedById:function(id,_cfd,_cfe){
if(this.grid._noInternalMapping){
return;
}
var _cff=[this._lastAnchorPoint.row,this._lastEndPoint.row,this._lastSelectedAnchorPoint.row,this._lastSelectedEndPoint.row];
_cff=_cff.concat(this._selected.row);
var _d00=false;
dojo.forEach(_cff,function(item){
if(item){
if(item.id===id){
_d00=true;
item.row=_cfd;
}else{
if(item.row===_cfd&&item.id){
item.row=-1;
}
}
}
});
if(!_d00&&_cfe){
dojo.some(this._selected.row,function(item){
if(item&&!item.id&&!item.except.length){
item.id=id;
item.row=_cfd;
return true;
}
return false;
});
}
_d00=false;
_cff=[this._lastAnchorPoint.cell,this._lastEndPoint.cell,this._lastSelectedAnchorPoint.cell,this._lastSelectedEndPoint.cell];
_cff=_cff.concat(this._selected.cell);
dojo.forEach(_cff,function(item){
if(item){
if(item.id===id){
_d00=true;
item.row=_cfd;
}else{
if(item.row===_cfd&&item.id){
item.row=-1;
}
}
}
});
},onSetStore:function(){
this._clearSelection("all");
},_onInternalRearrange:function(type,_d01){
try{
this._refresh("col",false);
dojo.forEach(this._selected.row,function(item){
dojo.forEach(this.grid.layout.cells,function(cell){
this._highlightNode(cell.getNode(item.row),false);
},this);
},this);
dojo.query(".dojoxGridRowSelectorSelected").forEach(function(node){
dojo.removeClass(node,"dojoxGridRowSelectorSelected");
dojo.removeClass(node,"dojoxGridRowSelectorSelectedUp");
dojo.removeClass(node,"dojoxGridRowSelectorSelectedDown");
});
var _d02=function(item){
if(item){
delete item.converted;
}
},_d03=[this._lastAnchorPoint[type],this._lastEndPoint[type],this._lastSelectedAnchorPoint[type],this._lastSelectedEndPoint[type]];
if(type==="cell"){
this.selectRange("cell",_d01.to.min,_d01.to.max);
var _d04=this.grid.layout.cells;
dojo.forEach(_d03,function(item){
if(item.converted){
return;
}
for(var r=_d01.from.min.row,tr=_d01.to.min.row;r<=_d01.from.max.row;++r,++tr){
for(var c=_d01.from.min.col,tc=_d01.to.min.col;c<=_d01.from.max.col;++c,++tc){
while(_d04[c].hidden){
++c;
}
while(_d04[tc].hidden){
++tc;
}
if(item.row==r&&item.col==c){
item.row=tr;
item.col=tc;
item.converted=true;
return;
}
}
}
});
}else{
_d03=this._selected.cell.concat(this._selected[type]).concat(_d03).concat([this._lastAnchorPoint.cell,this._lastEndPoint.cell,this._lastSelectedAnchorPoint.cell,this._lastSelectedEndPoint.cell]);
dojo.forEach(_d03,function(item){
if(item&&!item.converted){
var from=item[type];
if(from in _d01){
item[type]=_d01[from];
}
item.converted=true;
}
});
dojo.forEach(this._selected[_cce[type]],function(item){
for(var i=0,len=item.except.length;i<len;++i){
var from=item.except[i];
if(from in _d01){
item.except[i]=_d01[from];
}
}
});
}
dojo.forEach(_d03,_d02);
this._refreshSelected(true);
this._focusPoint(type,this._lastEndPoint);
}
catch(e){
console.warn("Selector._onInternalRearrange() error",e);
}
},_onExternalChange:function(type,_d05){
var _d06=type=="cell"?_d05.min:_d05[0],end=type=="cell"?_d05.max:_d05[_d05.length-1];
this.selectRange(type,_d06,end);
},_refresh:function(type,_d07){
if(!this._keyboardSelect[type]){
dojo.forEach(this._selected[type],function(item){
this._highlightSingle(type,_d07,item,undefined,true);
},this);
}
},_refreshSelected:function(){
this._refresh("col",true);
this._refresh("row",true);
this._refresh("cell",true);
},_initAreas:function(){
var g=this.grid,f=g.focus,_d08=this,dk=dojo.keys,_d09=1,_d0a=2,_d0b=function(type,_d0c,_d0d,_d0e,evt){
var ks=_d08._keyboardSelect;
if(evt.shiftKey&&ks[type]){
if(ks[type]===_d09){
if(type==="cell"){
var item=_d08._lastEndPoint[type];
if(f.cell!=g.layout.cells[item.col+_d0e]||f.rowIndex!=item.row+_d0d){
ks[type]=0;
return;
}
}
_d08._startSelect(type,_d08._lastAnchorPoint[type],true,false,true);
_d08._highlight(type,_d08._lastEndPoint[type],_d08._toSelect);
ks[type]=_d0a;
}
var _d0f=_d0c(type,_d0d,_d0e,evt);
if(_d08._isValid(type,_d0f,g)){
_d08._highlight(type,_d0f,_d08._toSelect);
}
_cd4(evt);
}
},_d10=function(type,_d11,evt,_d12){
if(_d12&&_d08.selectEnabled()&&_d08._config[type]!=_ccb){
switch(evt.keyCode){
case dk.SPACE:
_d08._startSelect(type,_d11(),evt.ctrlKey,evt.shiftKey);
_d08._endSelect(type);
break;
case dk.SHIFT:
if(_d08._config[type]==_ccd&&_d08._isValid(type,_d08._lastAnchorPoint[type],g)){
_d08._endSelect(type);
_d08._keyboardSelect[type]=_d09;
_d08._usingKeyboard=true;
}
}
}
},_d13=function(type,evt,_d14){
if(_d14&&evt.keyCode==dojo.keys.SHIFT&&_d08._keyboardSelect[type]){
_d08._endSelect(type);
_d08._keyboardSelect[type]=0;
}
};
if(g.views.views[0] instanceof dojox.grid._RowSelector){
this._lastFocusedRowBarIdx=0;
f.addArea({name:"rowHeader",onFocus:function(evt,step){
var view=g.views.views[0];
if(view instanceof dojox.grid._RowSelector){
var _d15=view.getCellNode(_d08._lastFocusedRowBarIdx,0);
if(_d15){
dojo.toggleClass(_d15,f.focusClass,false);
}
if(evt&&"rowIndex" in evt){
if(evt.rowIndex>=0){
_d08._lastFocusedRowBarIdx=evt.rowIndex;
}else{
if(!_d08._lastFocusedRowBarIdx){
_d08._lastFocusedRowBarIdx=0;
}
}
}
_d15=view.getCellNode(_d08._lastFocusedRowBarIdx,0);
if(_d15){
dijit.focus(_d15);
dojo.toggleClass(_d15,f.focusClass,true);
}
f.rowIndex=_d08._lastFocusedRowBarIdx;
_cd4(evt);
return true;
}
return false;
},onBlur:function(evt,step){
var view=g.views.views[0];
if(view instanceof dojox.grid._RowSelector){
var _d16=view.getCellNode(_d08._lastFocusedRowBarIdx,0);
if(_d16){
dojo.toggleClass(_d16,f.focusClass,false);
}
_cd4(evt);
}
return true;
},onMove:function(_d17,_d18,evt){
var view=g.views.views[0];
if(_d17&&view instanceof dojox.grid._RowSelector){
var next=_d08._lastFocusedRowBarIdx+_d17;
if(next>=0&&next<g.rowCount){
_cd4(evt);
var _d19=view.getCellNode(_d08._lastFocusedRowBarIdx,0);
dojo.toggleClass(_d19,f.focusClass,false);
var sc=g.scroller;
var _d1a=sc.getLastPageRow(sc.page);
var rc=g.rowCount-1,row=Math.min(rc,next);
if(next>_d1a){
g.setScrollTop(g.scrollTop+sc.findScrollTop(row)-sc.findScrollTop(_d08._lastFocusedRowBarIdx));
}
_d19=view.getCellNode(next,0);
dijit.focus(_d19);
dojo.toggleClass(_d19,f.focusClass,true);
_d08._lastFocusedRowBarIdx=next;
f.cell=_d19;
f.cell.view=view;
f.cell.getNode=function(_d1b){
return f.cell;
};
f.rowIndex=_d08._lastFocusedRowBarIdx;
f.scrollIntoView();
f.cell=null;
}
}
}});
f.placeArea("rowHeader","before","content");
}
f.addArea({name:"cellselect",onMove:dojo.partial(_d0b,"cell",function(type,_d1c,_d1d,evt){
var _d1e=_d08._currentPoint[type];
return _cd5("cell",_d1e.row+_d1c,_d1e.col+_d1d);
}),onKeyDown:dojo.partial(_d10,"cell",function(){
return _cd5("cell",f.rowIndex,f.cell.index);
}),onKeyUp:dojo.partial(_d13,"cell")});
f.placeArea("cellselect","below","content");
f.addArea({name:"colselect",onMove:dojo.partial(_d0b,"col",function(type,_d1f,_d20,evt){
var _d21=_d08._currentPoint[type];
return _cd5("col",_d21.col+_d20);
}),onKeyDown:dojo.partial(_d10,"col",function(){
return _cd5("col",f.getHeaderIndex());
}),onKeyUp:dojo.partial(_d13,"col")});
f.placeArea("colselect","below","header");
f.addArea({name:"rowselect",onMove:dojo.partial(_d0b,"row",function(type,_d22,_d23,evt){
return _cd5("row",f.rowIndex);
}),onKeyDown:dojo.partial(_d10,"row",function(){
return _cd5("row",f.rowIndex);
}),onKeyUp:dojo.partial(_d13,"row")});
f.placeArea("rowselect","below","rowHeader");
},_clearSelection:function(type,_d24){
if(type=="all"){
this._clearSelection("cell",_d24);
this._clearSelection("col",_d24);
this._clearSelection("row",_d24);
return;
}
this._isUsingRowSelector=true;
dojo.forEach(this._selected[type],function(item){
if(!_cd3(type,_d24,item)){
this._highlightSingle(type,false,item);
}
},this);
this._blurPoint(type,this._currentPoint);
this._selecting[type]=false;
this._startPoint[type]=this._currentPoint[type]=null;
this._selected[type]=[];
if(type=="row"&&!this.grid._selectingRange){
this._oldDeselectAll.call(this.grid.selection);
this.grid.selection._selectedById={};
}
this.grid.onEndDeselect(type,null,null,this._selected);
this.grid.onSelectCleared(type);
},_startSelect:function(type,_d25,_d26,_d27,_d28,_d29){
if(!this._isValid(type,_d25)){
return;
}
var _d2a=this._isSelected(type,this._lastEndPoint[type]),_d2b=this._isSelected(type,_d25);
if(this.noClear&&!_d26){
this._toSelect=_d29===undefined?true:_d29;
}else{
this._toSelect=_d28?_d2b:!_d2b;
}
if(!_d26||(!_d2b&&this._config[type]==_ccc)){
this._clearSelection("col",_d25);
this._clearSelection("cell",_d25);
if(!this.noClear||type==="row"){
this._clearSelection("row",_d25);
}
this._toSelect=_d29===undefined?true:_d29;
}
this._selecting[type]=true;
this._currentPoint[type]=null;
if(_d27&&this._lastType==type&&_d2a==this._toSelect&&this._config[type]==_ccd){
if(type==="row"){
this._isUsingRowSelector=true;
}
this._startPoint[type]=this._lastEndPoint[type];
this._highlight(type,this._startPoint[type]);
this._isUsingRowSelector=false;
}else{
this._startPoint[type]=_d25;
}
this._curType=type;
this._fireEvent("start",type);
this._isStartFocus=true;
this._isUsingRowSelector=true;
this._highlight(type,_d25,this._toSelect);
this._isStartFocus=false;
},_endSelect:function(type){
if(type==="row"){
delete this._isUsingRowSelector;
}
if(type=="all"){
this._endSelect("col");
this._endSelect("row");
this._endSelect("cell");
}else{
if(this._selecting[type]){
this._addToSelected(type);
this._lastAnchorPoint[type]=this._startPoint[type];
this._lastEndPoint[type]=this._currentPoint[type];
if(this._toSelect){
this._lastSelectedAnchorPoint[type]=this._lastAnchorPoint[type];
this._lastSelectedEndPoint[type]=this._lastEndPoint[type];
}
this._startPoint[type]=this._currentPoint[type]=null;
this._selecting[type]=false;
this._lastType=type;
this._fireEvent("end",type);
}
}
},_fireEvent:function(_d2c,type){
switch(_d2c){
case "start":
this.grid[this._toSelect?"onStartSelect":"onStartDeselect"](type,this._startPoint[type],this._selected);
break;
case "end":
this.grid[this._toSelect?"onEndSelect":"onEndDeselect"](type,this._lastAnchorPoint[type],this._lastEndPoint[type],this._selected);
break;
}
},_calcToHighlight:function(type,_d2d,_d2e,_d2f){
if(_d2f!==undefined){
var sltd;
if(this._usingKeyboard&&!_d2e){
var last=this._isInLastRange(this._lastType,_d2d);
if(last){
sltd=this._isSelected(type,_d2d);
if(_d2f&&sltd){
return false;
}
if(!_d2f&&!sltd&&this._isInLastRange(this._lastType,_d2d,true)){
return true;
}
}
}
return _d2e?_d2f:(sltd||this._isSelected(type,_d2d));
}
return _d2e;
},_highlightNode:function(node,_d30){
if(node){
var _d31="dojoxGridRowSelected";
var _d32="dojoxGridCellSelected";
dojo.toggleClass(node,_d31,_d30);
dojo.toggleClass(node,_d32,_d30);
}
},_highlightHeader:function(_d33,_d34){
var _d35=this.grid.layout.cells;
var node=_d35[_d33].getHeaderNode();
var _d36="dojoxGridHeaderSelected";
dojo.toggleClass(node,_d36,_d34);
},_highlightRowSelector:function(_d37,_d38){
var _d39=this.grid.views.views[0];
if(_d39 instanceof dojox.grid._RowSelector){
var node=_d39.getRowNode(_d37);
if(node){
var _d3a="dojoxGridRowSelectorSelected";
dojo.toggleClass(node,_d3a,_d38);
}
}
},_highlightSingle:function(type,_d3b,_d3c,_d3d,_d3e){
var _d3f=this,toHL,g=_d3f.grid,_d40=g.layout.cells;
switch(type){
case "cell":
toHL=this._calcToHighlight(type,_d3c,_d3b,_d3d);
var c=_d40[_d3c.col];
if(!c.hidden&&!c.notselectable){
this._highlightNode(_d3c.node||c.getNode(_d3c.row),toHL);
}
break;
case "col":
toHL=this._calcToHighlight(type,_d3c,_d3b,_d3d);
this._highlightHeader(_d3c.col,toHL);
dojo.query("td[idx='"+_d3c.col+"']",g.domNode).forEach(function(_d41){
var _d42=_d40[_d3c.col].view.content.findRowTarget(_d41);
if(_d42){
var _d43=_d42[dojox.grid.util.rowIndexTag];
_d3f._highlightSingle("cell",toHL,{"row":_d43,"col":_d3c.col,"node":_d41});
}
});
break;
case "row":
toHL=this._calcToHighlight(type,_d3c,_d3b,_d3d);
this._highlightRowSelector(_d3c.row,toHL);
if(this._config.cell){
dojo.forEach(_d40,function(cell){
_d3f._highlightSingle("cell",toHL,{"row":_d3c.row,"col":cell.index,"node":cell.getNode(_d3c.row)});
});
}
this._selectedRowModified=true;
if(!_d3e){
g.selection.setSelected(_d3c.row,toHL);
}
}
},_highlight:function(type,_d44,_d45){
if(this._selecting[type]&&_d44!==null){
var _d46=this._startPoint[type],_d47=this._currentPoint[type],_d48=this,_d49=function(from,to,toHL){
_d48._forEach(type,from,to,function(item){
_d48._highlightSingle(type,toHL,item,_d45);
},true);
};
switch(type){
case "col":
case "row":
if(_d47!==null){
if(_ccf(type,_d44,_d46,_d47,true)){
_d49(_d47,_d44,false);
}else{
if(_ccf(type,_d46,_d44,_d47,true)){
_d49(_d47,_d46,false);
_d47=_d46;
}
_d49(_d44,_d47,true);
}
}else{
this._highlightSingle(type,true,_d44,_d45);
}
break;
case "cell":
if(_d47!==null){
if(_ccf("row",_d44,_d46,_d47,true)||_ccf("col",_d44,_d46,_d47,true)||_ccf("row",_d46,_d44,_d47,true)||_ccf("col",_d46,_d44,_d47,true)){
_d49(_d46,_d47,false);
}
}
_d49(_d46,_d44,true);
}
this._currentPoint[type]=_d44;
this._focusPoint(type,this._currentPoint);
}
},_focusPoint:function(type,_d4a){
if(!this._isStartFocus){
var _d4b=_d4a[type],f=this.grid.focus;
if(type=="col"){
f._colHeadFocusIdx=_d4b.col;
f.focusArea("header");
}else{
if(type=="row"){
f.focusArea("rowHeader",{"rowIndex":_d4b.row});
}else{
if(type=="cell"){
f.setFocusIndex(_d4b.row,_d4b.col);
}
}
}
}
},_blurPoint:function(type,_d4c){
var f=this.grid.focus;
if(type=="col"){
f._blurHeader();
}else{
if(type=="cell"){
f._blurContent();
}
}
},_addToSelected:function(type){
var _d4d=this._toSelect,_d4e=this,_d4f=[],_d50=[],_d51=this._startPoint[type],end=this._currentPoint[type];
if(this._usingKeyboard){
this._forEach(type,this._lastAnchorPoint[type],this._lastEndPoint[type],function(item){
if(!_ccf(type,item,_d51,end)){
(_d4d?_d50:_d4f).push(item);
}
});
}
this._forEach(type,_d51,end,function(item){
var _d52=_d4e._isSelected(type,item);
if(_d4d&&!_d52){
_d4f.push(item);
}else{
if(!_d4d){
_d50.push(item);
}
}
});
this._add(type,_d4f);
this._remove(type,_d50);
dojo.forEach(this._selected.row,function(item){
if(item.except.length>0){
this._selectedRowModified=true;
this.grid.selection.setSelected(item.row,false);
}
},this);
},_forEach:function(type,_d53,end,func,_d54){
if(!this._isValid(type,_d53,true)||!this._isValid(type,end,true)){
return;
}
switch(type){
case "col":
case "row":
_d53=_d53[type];
end=end[type];
var dir=end>_d53?1:-1;
if(!_d54){
end+=dir;
}
for(;_d53!=end;_d53+=dir){
func(_cd5(type,_d53));
}
break;
case "cell":
var _d55=end.col>_d53.col?1:-1,_d56=end.row>_d53.row?1:-1;
for(var i=_d53.row,p=end.row+_d56;i!=p;i+=_d56){
for(var j=_d53.col,q=end.col+_d55;j!=q;j+=_d55){
func(_cd5(type,i,j));
}
}
}
},_makeupForExceptions:function(type,_d57){
var _d58=[];
dojo.forEach(this._selected[type],function(v1){
dojo.forEach(_d57,function(v2){
if(v1[type]==v2[type]){
var pos=dojo.indexOf(v1.except,v2[_cce[type]]);
if(pos>=0){
v1.except.splice(pos,1);
}
_d58.push(v2);
}
});
});
return _d58;
},_makeupForCells:function(type,_d59){
var _d5a=[];
dojo.forEach(this._selected.cell,function(v1){
dojo.some(_d59,function(v2){
if(v1[type]==v2[type]){
_d5a.push(v1);
return true;
}
return false;
});
});
this._remove("cell",_d5a);
dojo.forEach(this._selected[_cce[type]],function(v1){
dojo.forEach(_d59,function(v2){
var pos=dojo.indexOf(v1.except,v2[type]);
if(pos>=0){
v1.except.splice(pos,1);
}
});
});
},_addException:function(type,_d5b){
dojo.forEach(this._selected[type],function(v1){
dojo.forEach(_d5b,function(v2){
v1.except.push(v2[_cce[type]]);
});
});
},_addCellException:function(type,_d5c){
dojo.forEach(this._selected[type],function(v1){
dojo.forEach(_d5c,function(v2){
if(v1[type]==v2[type]){
v1.except.push(v2[_cce[type]]);
}
});
});
},_add:function(type,_d5d){
var _d5e=this.grid.layout.cells;
if(type=="cell"){
var _d5f=this._makeupForExceptions("col",_d5d);
var _d60=this._makeupForExceptions("row",_d5d);
_d5d=dojo.filter(_d5d,function(item){
return dojo.indexOf(_d5f,item)<0&&dojo.indexOf(_d60,item)<0&&!_d5e[item.col].hidden&&!_d5e[item.col].notselectable;
});
}else{
if(type=="col"){
_d5d=dojo.filter(_d5d,function(item){
return !_d5e[item.col].hidden&&!_d5e[item.col].notselectable;
});
}
this._makeupForCells(type,_d5d);
this._selected[type]=dojo.filter(this._selected[type],function(v){
return dojo.every(_d5d,function(item){
return v[type]!==item[type];
});
});
}
if(type!="col"&&this.grid._hasIdentity){
dojo.forEach(_d5d,function(item){
var _d61=this.grid._by_idx[item.row];
if(_d61){
item.id=_d61.idty;
}
},this);
}
this._selected[type]=this._selected[type].concat(_d5d);
},_remove:function(type,_d62){
var comp=dojo.partial(_cd3,type);
this._selected[type]=dojo.filter(this._selected[type],function(v1){
return !dojo.some(_d62,function(v2){
return comp(v1,v2);
});
});
if(type=="cell"){
this._addCellException("col",_d62);
this._addCellException("row",_d62);
}else{
if(this._config.cell){
this._addException(_cce[type],_d62);
}
}
},_isCellNotInExcept:function(type,item){
var attr=item[type],_d63=item[_cce[type]];
return dojo.some(this._selected[type],function(v){
return v[type]==attr&&dojo.indexOf(v.except,_d63)<0;
});
},_isSelected:function(type,item){
if(!item){
return false;
}
var res=dojo.some(this._selected[type],function(v){
var ret=_cd3(type,item,v);
if(ret&&type!=="cell"){
return v.except.length===0;
}
return ret;
});
if(!res&&type==="cell"){
res=(this._isCellNotInExcept("col",item)||this._isCellNotInExcept("row",item));
if(type==="cell"){
res=res&&!this.grid.layout.cells[item.col].notselectable;
}
}
return res;
},_isInLastRange:function(type,item,_d64){
var _d65=this[_d64?"_lastSelectedAnchorPoint":"_lastAnchorPoint"][type],end=this[_d64?"_lastSelectedEndPoint":"_lastEndPoint"][type];
if(!item||!_d65||!end){
return false;
}
return _ccf(type,item,_d65,end);
},_isValid:function(type,item,_d66){
if(!item){
return false;
}
try{
var g=this.grid,_d67=item[type];
switch(type){
case "col":
return _d67>=0&&_d67<g.layout.cells.length&&dojo.isArray(item.except)&&(_d66||!g.layout.cells[_d67].notselectable);
case "row":
return _d67>=0&&_d67<g.rowCount&&dojo.isArray(item.except);
case "cell":
return item.col>=0&&item.col<g.layout.cells.length&&item.row>=0&&item.row<g.rowCount&&(_d66||!g.layout.cells[item.col].notselectable);
}
}
catch(e){
}
return false;
}});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.Selector,{"dependency":["autoScroll"]});
})();
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins._RowMapLayer"]){
dojo._hasResource["dojox.grid.enhanced.plugins._RowMapLayer"]=true;
dojo.provide("dojox.grid.enhanced.plugins._RowMapLayer");
(function(){
var _d68=function(a){
a.sort(function(v1,v2){
return v1-v2;
});
var arr=[[a[0]]];
for(var i=1,j=0;i<a.length;++i){
if(a[i]==a[i-1]+1){
arr[j].push(a[i]);
}else{
arr[++j]=[a[i]];
}
}
return arr;
},_d69=function(_d6a,func){
return func?dojo.hitch(_d6a||dojo.global,func):function(){
};
};
dojo.declare("dojox.grid.enhanced.plugins._RowMapLayer",dojox.grid.enhanced.plugins._StoreLayer,{tags:["reorder"],constructor:function(grid){
this._map={};
this._revMap={};
this.grid=grid;
this._oldOnDelete=grid._onDelete;
var _d6b=this;
grid._onDelete=function(item){
_d6b._onDelete(item);
_d6b._oldOnDelete.call(grid,item);
};
this._oldSort=grid.sort;
grid.sort=function(){
_d6b.clearMapping();
_d6b._oldSort.apply(grid,arguments);
};
},uninitialize:function(){
this.grid._onDelete=this._oldOnDelete;
this.grid.sort=this._oldSort;
},setMapping:function(_d6c){
this._store.forEachLayer(function(_d6d){
if(_d6d.name()==="rowmap"){
return false;
}else{
if(_d6d.onRowMappingChange){
_d6d.onRowMappingChange(_d6c);
}
}
return true;
},false);
var from,to,_d6e,_d6f={};
for(from in _d6c){
from=parseInt(from,10);
to=_d6c[from];
if(typeof to=="number"){
if(from in this._revMap){
_d6e=this._revMap[from];
delete this._revMap[from];
}else{
_d6e=from;
}
if(_d6e==to){
delete this._map[_d6e];
_d6f[to]="eq";
}else{
this._map[_d6e]=to;
_d6f[to]=_d6e;
}
}
}
for(to in _d6f){
if(_d6f[to]==="eq"){
delete this._revMap[parseInt(to,10)];
}else{
this._revMap[parseInt(to,10)]=_d6f[to];
}
}
},clearMapping:function(){
this._map={};
this._revMap={};
},_onDelete:function(item){
var idx=this.grid._getItemIndex(item,true);
if(idx in this._revMap){
var _d70=[],r,i,_d71=this._revMap[idx];
delete this._map[_d71];
delete this._revMap[idx];
for(r in this._revMap){
r=parseInt(r,10);
if(this._revMap[r]>_d71){
--this._revMap[r];
}
}
for(r in this._revMap){
r=parseInt(r,10);
if(r>idx){
_d70.push(r);
}
}
_d70.sort(function(a,b){
return b-a;
});
for(i=_d70.length-1;i>=0;--i){
r=_d70[i];
this._revMap[r-1]=this._revMap[r];
delete this._revMap[r];
}
this._map={};
for(r in this._revMap){
this._map[this._revMap[r]]=r;
}
}
},_fetch:function(_d72){
var _d73=0,r;
var _d74=_d72.start||0;
for(r in this._revMap){
r=parseInt(r,10);
if(r>=_d74){
++_d73;
}
}
if(_d73>0){
var rows=[],i,map={},_d75=_d72.count>0?_d72.count:-1;
if(_d75>0){
for(i=0;i<_d75;++i){
r=_d74+i;
r=r in this._revMap?this._revMap[r]:r;
map[r]=i;
rows.push(r);
}
}else{
for(i=0;;++i){
r=_d74+i;
if(r in this._revMap){
--_d73;
r=this._revMap[r];
}
map[r]=i;
rows.push(r);
if(_d73<=0){
break;
}
}
}
this._subFetch(_d72,this._getRowArrays(rows),0,[],map,_d72.onComplete,_d74,_d75);
return _d72;
}else{
return dojo.hitch(this._store,this._originFetch)(_d72);
}
},_getRowArrays:function(rows){
return _d68(rows);
},_subFetch:function(_d76,_d77,_d78,_d79,map,_d7a,_d7b,_d7c){
var arr=_d77[_d78],_d7d=this;
var _d7e=_d76.start=arr[0];
_d76.count=arr[arr.length-1]-arr[0]+1;
_d76.onComplete=function(_d7f){
dojo.forEach(_d7f,function(item,i){
var r=_d7e+i;
if(r in map){
_d79[map[r]]=item;
}
});
if(++_d78==_d77.length){
if(_d7c>0){
_d76.start=_d7b;
_d76.count=_d7c;
_d76.onComplete=_d7a;
_d69(_d76.scope,_d7a)(_d79,_d76);
}else{
_d76.start=_d76.start+_d7f.length;
delete _d76.count;
_d76.onComplete=function(_d80){
_d79=_d79.concat(_d80);
_d76.start=_d7b;
_d76.onComplete=_d7a;
_d69(_d76.scope,_d7a)(_d79,_d76);
};
_d7d.originFetch(_d76);
}
}else{
_d7d._subFetch(_d76,_d77,_d78,_d79,map,_d7a,_d7b,_d7c);
}
};
_d7d.originFetch(_d76);
}});
})();
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.Rearrange"]){
dojo._hasResource["dojox.grid.enhanced.plugins.Rearrange"]=true;
dojo.provide("dojox.grid.enhanced.plugins.Rearrange");
dojo.declare("dojox.grid.enhanced.plugins.Rearrange",dojox.grid.enhanced._Plugin,{name:"rearrange",constructor:function(grid,args){
this.grid=grid;
this.setArgs(args);
var _d81=new dojox.grid.enhanced.plugins._RowMapLayer(grid);
dojox.grid.enhanced.plugins.wrap(grid,"_storeLayerFetch",_d81);
},setArgs:function(args){
this.args=dojo.mixin(this.args||{},args||{});
this.args.setIdentifierForNewItem=this.args.setIdentifierForNewItem||function(v){
return v;
};
},destroy:function(){
this.inherited(arguments);
this.grid.unwrap("rowmap");
},onSetStore:function(_d82){
this.grid.layer("rowmap").clearMapping();
},_hasIdentity:function(_d83){
var g=this.grid,s=g.store,_d84=g.layout.cells;
if(s.getFeatures()["dojo.data.api.Identity"]){
if(dojo.some(_d83,function(_d85){
return s.getIdentityAttributes(g._by_idx[_d85.r].item)==_d84[_d85.c].field;
})){
return true;
}
}
return false;
},moveColumns:function(_d86,_d87){
var g=this.grid,_d88=g.layout,_d89=_d88.cells,_d8a,i,_d8b=0,_d8c=true,tmp={},_d8d={};
_d86.sort(function(a,b){
return a-b;
});
for(i=0;i<_d86.length;++i){
tmp[_d86[i]]=i;
if(_d86[i]<_d87){
++_d8b;
}
}
var _d8e=0,_d8f=0;
var _d90=Math.max(_d86[_d86.length-1],_d87);
if(_d90==_d89.length){
--_d90;
}
var _d91=Math.min(_d86[0],_d87);
for(i=_d91;i<=_d90;++i){
var j=tmp[i];
if(j>=0){
_d8d[i]=_d87-_d8b+j;
}else{
if(i<_d87){
_d8d[i]=_d91+_d8e;
++_d8e;
}else{
if(i>=_d87){
_d8d[i]=_d87+_d86.length-_d8b+_d8f;
++_d8f;
}
}
}
}
_d8b=0;
if(_d87==_d89.length){
--_d87;
_d8c=false;
}
g._notRefreshSelection=true;
for(i=0;i<_d86.length;++i){
_d8a=_d86[i];
if(_d8a<_d87){
_d8a-=_d8b;
}
++_d8b;
if(_d8a!=_d87){
_d88.moveColumn(_d89[_d8a].view.idx,_d89[_d87].view.idx,_d8a,_d87,_d8c&&_d8a>_d87);
_d89=_d88.cells;
}
if(_d87<=_d8a){
++_d87;
}
}
delete g._notRefreshSelection;
dojo.publish("dojox/grid/rearrange/move/"+g.id,["col",_d8d,_d86]);
},moveRows:function(_d92,_d93){
var g=this.grid,_d94={},_d95=[],_d96=[],len=_d92.length,i,r,k,arr,_d97,_d98;
for(i=0;i<len;++i){
r=_d92[i];
if(r>=_d93){
break;
}
_d95.push(r);
}
_d96=_d92.slice(i);
arr=_d95;
len=arr.length;
if(len){
_d97={};
dojo.forEach(arr,function(r){
_d97[r]=true;
});
_d94[arr[0]]=_d93-len;
for(k=0,i=arr[k]+1,_d98=i-1;i<_d93;++i){
if(!_d97[i]){
_d94[i]=_d98;
++_d98;
}else{
++k;
_d94[i]=_d93-len+k;
}
}
}
arr=_d96;
len=arr.length;
if(len){
_d97={};
dojo.forEach(arr,function(r){
_d97[r]=true;
});
_d94[arr[len-1]]=_d93+len-1;
for(k=len-1,i=arr[k]-1,_d98=i+1;i>=_d93;--i){
if(!_d97[i]){
_d94[i]=_d98;
--_d98;
}else{
--k;
_d94[i]=_d93+k;
}
}
}
var _d99=dojo.clone(_d94);
g.layer("rowmap").setMapping(_d94);
g.forEachLayer(function(_d9a){
if(_d9a.name()!="rowmap"){
_d9a.invalidate();
return true;
}else{
return false;
}
},false);
g.selection.selected=[];
g._noInternalMapping=true;
g._refresh();
setTimeout(function(){
dojo.publish("dojox/grid/rearrange/move/"+g.id,["row",_d99,_d92]);
g._noInternalMapping=false;
},0);
},moveCells:function(_d9b,_d9c){
var g=this.grid,s=g.store;
if(s.getFeatures()["dojo.data.api.Write"]){
if(_d9b.min.row==_d9c.min.row&&_d9b.min.col==_d9c.min.col){
return;
}
var _d9d=g.layout.cells,cnt=_d9b.max.row-_d9b.min.row+1,r,c,tr,tc,_d9e=[],_d9f=[];
for(r=_d9b.min.row,tr=_d9c.min.row;r<=_d9b.max.row;++r,++tr){
for(c=_d9b.min.col,tc=_d9c.min.col;c<=_d9b.max.col;++c,++tc){
while(_d9d[c]&&_d9d[c].hidden){
++c;
}
while(_d9d[tc]&&_d9d[tc].hidden){
++tc;
}
_d9e.push({"r":r,"c":c});
_d9f.push({"r":tr,"c":tc,"v":_d9d[c].get(r,g._by_idx[r].item)});
}
}
if(this._hasIdentity(_d9e.concat(_d9f))){
console.warn("Can not write to identity!");
return;
}
dojo.forEach(_d9e,function(_da0){
s.setValue(g._by_idx[_da0.r].item,_d9d[_da0.c].field,"");
});
dojo.forEach(_d9f,function(_da1){
s.setValue(g._by_idx[_da1.r].item,_d9d[_da1.c].field,_da1.v);
});
s.save({onComplete:function(){
dojo.publish("dojox/grid/rearrange/move/"+g.id,["cell",{"from":_d9b,"to":_d9c}]);
}});
}
},copyCells:function(_da2,_da3){
var g=this.grid,s=g.store;
if(s.getFeatures()["dojo.data.api.Write"]){
if(_da2.min.row==_da3.min.row&&_da2.min.col==_da3.min.col){
return;
}
var _da4=g.layout.cells,cnt=_da2.max.row-_da2.min.row+1,r,c,tr,tc,_da5=[];
for(r=_da2.min.row,tr=_da3.min.row;r<=_da2.max.row;++r,++tr){
for(c=_da2.min.col,tc=_da3.min.col;c<=_da2.max.col;++c,++tc){
while(_da4[c]&&_da4[c].hidden){
++c;
}
while(_da4[tc]&&_da4[tc].hidden){
++tc;
}
_da5.push({"r":tr,"c":tc,"v":_da4[c].get(r,g._by_idx[r].item)});
}
}
if(this._hasIdentity(_da5)){
console.warn("Can not write to identity!");
return;
}
dojo.forEach(_da5,function(_da6){
s.setValue(g._by_idx[_da6.r].item,_da4[_da6.c].field,_da6.v);
});
s.save({onComplete:function(){
setTimeout(function(){
dojo.publish("dojox/grid/rearrange/copy/"+g.id,["cell",{"from":_da2,"to":_da3}]);
},0);
}});
}
},changeCells:function(_da7,_da8,_da9){
var g=this.grid,s=g.store;
if(s.getFeatures()["dojo.data.api.Write"]){
var srcg=_da7,_daa=g.layout.cells,_dab=srcg.layout.cells,cnt=_da8.max.row-_da8.min.row+1,r,c,tr,tc,_dac=[];
for(r=_da8.min.row,tr=_da9.min.row;r<=_da8.max.row;++r,++tr){
for(c=_da8.min.col,tc=_da9.min.col;c<=_da8.max.col;++c,++tc){
while(_dab[c]&&_dab[c].hidden){
++c;
}
while(_daa[tc]&&_daa[tc].hidden){
++tc;
}
_dac.push({"r":tr,"c":tc,"v":_dab[c].get(r,srcg._by_idx[r].item)});
}
}
if(this._hasIdentity(_dac)){
console.warn("Can not write to identity!");
return;
}
dojo.forEach(_dac,function(_dad){
s.setValue(g._by_idx[_dad.r].item,_daa[_dad.c].field,_dad.v);
});
s.save({onComplete:function(){
dojo.publish("dojox/grid/rearrange/change/"+g.id,["cell",_da9]);
}});
}
},clearCells:function(_dae){
var g=this.grid,s=g.store;
if(s.getFeatures()["dojo.data.api.Write"]){
var _daf=g.layout.cells,cnt=_dae.max.row-_dae.min.row+1,r,c,_db0=[];
for(r=_dae.min.row;r<=_dae.max.row;++r){
for(c=_dae.min.col;c<=_dae.max.col;++c){
while(_daf[c]&&_daf[c].hidden){
++c;
}
_db0.push({"r":r,"c":c});
}
}
if(this._hasIdentity(_db0)){
console.warn("Can not write to identity!");
return;
}
dojo.forEach(_db0,function(_db1){
s.setValue(g._by_idx[_db1.r].item,_daf[_db1.c].field,"");
});
s.save({onComplete:function(){
dojo.publish("dojox/grid/rearrange/change/"+g.id,["cell",_dae]);
}});
}
},insertRows:function(_db2,_db3,_db4){
try{
var g=this.grid,s=g.store,_db5=g.rowCount,_db6={},obj={idx:0},_db7=[],i,_db8=_db4<0;
_this=this;
var len=_db3.length;
if(_db8){
_db4=0;
}else{
for(i=_db4;i<g.rowCount;++i){
_db6[i]=i+len;
}
}
if(s.getFeatures()["dojo.data.api.Write"]){
if(_db2){
var srcg=_db2,srcs=srcg.store,_db9,_dba;
if(!_db8){
for(i=0;!_db9;++i){
_db9=g._by_idx[i];
}
_dba=s.getAttributes(_db9.item);
}else{
_dba=dojo.map(g.layout.cells,function(cell){
return cell.field;
});
}
var _dbb=[];
dojo.forEach(_db3,function(_dbc,i){
var item={};
var _dbd=srcg._by_idx[_dbc];
if(_dbd){
dojo.forEach(_dba,function(attr){
item[attr]=srcs.getValue(_dbd.item,attr);
});
item=_this.args.setIdentifierForNewItem(item,s,_db5+obj.idx)||item;
try{
s.newItem(item);
_db7.push(_db4+i);
_db6[_db5+obj.idx]=_db4+i;
++obj.idx;
}
catch(e){
}
}else{
_dbb.push(_dbc);
}
});
}else{
if(_db3.length&&dojo.isObject(_db3[0])){
dojo.forEach(_db3,function(_dbe,i){
var item=_this.args.setIdentifierForNewItem(_dbe,s,_db5+obj.idx)||_dbe;
try{
s.newItem(item);
_db7.push(_db4+i);
_db6[_db5+obj.idx]=_db4+i;
++obj.idx;
}
catch(e){
}
});
}else{
return;
}
}
g.layer("rowmap").setMapping(_db6);
s.save({onComplete:function(){
g._refresh();
setTimeout(function(){
dojo.publish("dojox/grid/rearrange/insert/"+g.id,["row",_db7]);
},0);
}});
}
}
catch(e){
}
},removeRows:function(_dbf){
var g=this.grid;
var s=g.store;
try{
dojo.forEach(dojo.map(_dbf,function(_dc0){
return g._by_idx[_dc0];
}),function(row){
if(row){
s.deleteItem(row.item);
}
});
s.save({onComplete:function(){
dojo.publish("dojox/grid/rearrange/remove/"+g.id,["row",_dbf]);
}});
}
catch(e){
}
},_getPageInfo:function(){
var _dc1=this.grid.scroller,_dc2=_dc1.page,_dc3=_dc1.page,_dc4=_dc1.firstVisibleRow,_dc5=_dc1.lastVisibleRow,_dc6=_dc1.rowsPerPage,_dc7=_dc1.pageNodes[0],_dc8,_dc9,_dca,_dcb=[];
dojo.forEach(_dc7,function(page,_dcc){
if(!page){
return;
}
_dca=false;
_dc8=_dcc*_dc6;
_dc9=(_dcc+1)*_dc6-1;
if(_dc4>=_dc8&&_dc4<=_dc9){
_dc2=_dcc;
_dca=true;
}
if(_dc5>=_dc8&&_dc5<=_dc9){
_dc3=_dcc;
_dca=true;
}
if(!_dca&&(_dc8>_dc5||_dc9<_dc4)){
_dcb.push(_dcc);
}
});
return {topPage:_dc2,bottomPage:_dc3,invalidPages:_dcb};
}});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.Rearrange);
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.DnD"]){
dojo._hasResource["dojox.grid.enhanced.plugins.DnD"]=true;
dojo.provide("dojox.grid.enhanced.plugins.DnD");
(function(){
var _dcd=function(a){
a.sort(function(v1,v2){
return v1-v2;
});
var arr=[[a[0]]];
for(var i=1,j=0;i<a.length;++i){
if(a[i]==a[i-1]+1){
arr[j].push(a[i]);
}else{
arr[++j]=[a[i]];
}
}
return arr;
},_dce=function(_dcf){
var a=_dcf[0];
for(var i=1;i<_dcf.length;++i){
a=a.concat(_dcf[i]);
}
return a;
};
dojo.declare("dojox.grid.enhanced.plugins.DnD",dojox.grid.enhanced._Plugin,{name:"dnd",_targetAnchorBorderWidth:2,_copyOnly:false,_config:{"row":{"within":true,"in":true,"out":true},"col":{"within":true,"in":true,"out":true},"cell":{"within":true,"in":true,"out":true}},constructor:function(grid,args){
this.grid=grid;
this._config=dojo.clone(this._config);
args=dojo.isObject(args)?args:{};
this.setupConfig(args.dndConfig);
this._copyOnly=!!args.copyOnly;
this._mixinGrid();
this.selector=grid.pluginMgr.getPlugin("selector");
this.rearranger=grid.pluginMgr.getPlugin("rearrange");
this.rearranger.setArgs(args);
this._clear();
this._elem=new dojox.grid.enhanced.plugins.GridDnDElement(this);
this._source=new dojox.grid.enhanced.plugins.GridDnDSource(this._elem.node,{"grid":grid,"dndElem":this._elem,"dnd":this});
this._container=dojo.query(".dojoxGridMasterView",this.grid.domNode)[0];
this._initEvents();
},destroy:function(){
this.inherited(arguments);
this._clear();
this._source.destroy();
this._elem.destroy();
this._container=null;
this.grid=null;
this.selector=null;
this.rearranger=null;
this._config=null;
},_mixinGrid:function(){
this.grid.setupDnDConfig=dojo.hitch(this,"setupConfig");
this.grid.dndCopyOnly=dojo.hitch(this,"copyOnly");
},setupConfig:function(_dd0){
if(_dd0&&dojo.isObject(_dd0)){
var _dd1=["row","col","cell"],_dd2=["within","in","out"],cfg=this._config;
dojo.forEach(_dd1,function(type){
if(type in _dd0){
var t=_dd0[type];
if(t&&dojo.isObject(t)){
dojo.forEach(_dd2,function(mode){
if(mode in t){
cfg[type][mode]=!!t[mode];
}
});
}else{
dojo.forEach(_dd2,function(mode){
cfg[type][mode]=!!t;
});
}
}
});
dojo.forEach(_dd2,function(mode){
if(mode in _dd0){
var m=_dd0[mode];
if(m&&dojo.isObject(m)){
dojo.forEach(_dd1,function(type){
if(type in m){
cfg[type][mode]=!!m[type];
}
});
}else{
dojo.forEach(_dd1,function(type){
cfg[type][mode]=!!m;
});
}
}
});
}
},copyOnly:function(_dd3){
if(typeof _dd3!="undefined"){
this._copyOnly=!!_dd3;
}
return this._copyOnly;
},_isOutOfGrid:function(evt){
var _dd4=dojo.position(this.grid.domNode),x=evt.clientX,y=evt.clientY;
return y<_dd4.y||y>_dd4.y+_dd4.h||x<_dd4.x||x>_dd4.x+_dd4.w;
},_onMouseMove:function(evt){
if(this._dndRegion&&!this._dnding&&!this._externalDnd){
this._dnding=true;
this._startDnd(evt);
}else{
if(this._isMouseDown&&!this._dndRegion){
delete this._isMouseDown;
this._oldCursor=dojo.style(dojo.body(),"cursor");
dojo.style(dojo.body(),"cursor","not-allowed");
}
var _dd5=this._isOutOfGrid(evt);
if(!this._alreadyOut&&_dd5){
this._alreadyOut=true;
if(this._dnding){
this._destroyDnDUI(true,false);
}
this._moveEvent=evt;
this._source.onOutEvent();
}else{
if(this._alreadyOut&&!_dd5){
this._alreadyOut=false;
if(this._dnding){
this._createDnDUI(evt,true);
}
this._moveEvent=evt;
this._source.onOverEvent();
}
}
}
},_onMouseUp:function(){
if(!this._extDnding&&!this._isSource){
var _dd6=this._dnding&&!this._alreadyOut;
if(_dd6&&this._config[this._dndRegion.type]["within"]){
this._rearrange();
}
this._endDnd(_dd6);
}
dojo.style(dojo.body(),"cursor",this._oldCursor||"");
delete this._isMouseDown;
},_initEvents:function(){
var g=this.grid,s=this.selector;
this.connect(dojo.doc,"onmousemove","_onMouseMove");
this.connect(dojo.doc,"onmouseup","_onMouseUp");
this.connect(g,"onCellMouseOver",function(evt){
if(!this._dnding&&!s.isSelecting()&&!evt.ctrlKey){
this._dndReady=s.isSelected("cell",evt.rowIndex,evt.cell.index);
s.selectEnabled(!this._dndReady);
}
});
this.connect(g,"onHeaderCellMouseOver",function(evt){
if(this._dndReady){
s.selectEnabled(true);
}
});
this.connect(g,"onRowMouseOver",function(evt){
if(this._dndReady&&!evt.cell){
s.selectEnabled(true);
}
});
this.connect(g,"onCellMouseDown",function(evt){
if(!evt.ctrlKey&&this._dndReady){
this._dndRegion=this._getDnDRegion(evt.rowIndex,evt.cell.index);
this._isMouseDown=true;
}
});
this.connect(g,"onCellMouseUp",function(evt){
if(!this._dndReady&&!s.isSelecting()&&evt.cell){
this._dndReady=s.isSelected("cell",evt.rowIndex,evt.cell.index);
s.selectEnabled(!this._dndReady);
}
});
this.connect(g,"onCellClick",function(evt){
if(this._dndReady&&!evt.ctrlKey&&!evt.shiftKey){
s.select("cell",evt.rowIndex,evt.cell.index);
}
});
this.connect(g,"onEndAutoScroll",function(_dd7,_dd8,view,_dd9,evt){
if(this._dnding){
this._markTargetAnchor(evt);
}
});
this.connect(dojo.doc,"onkeydown",function(evt){
if(evt.keyCode==dojo.keys.ESCAPE){
this._endDnd(false);
}else{
if(evt.keyCode==dojo.keys.CTRL){
s.selectEnabled(true);
this._isCopy=true;
}
}
});
this.connect(dojo.doc,"onkeyup",function(evt){
if(evt.keyCode==dojo.keys.CTRL){
s.selectEnabled(!this._dndReady);
this._isCopy=false;
}
});
},_clear:function(){
this._dndRegion=null;
this._target=null;
this._moveEvent=null;
this._targetAnchor={};
this._dnding=false;
this._externalDnd=false;
this._isSource=false;
this._alreadyOut=false;
this._extDnding=false;
},_getDnDRegion:function(_dda,_ddb){
var s=this.selector,_ddc=s._selected,flag=(!!_ddc.cell.length)|(!!_ddc.row.length<<1)|(!!_ddc.col.length<<2),type;
switch(flag){
case 1:
type="cell";
if(!this._config[type]["within"]&&!this._config[type]["out"]){
return null;
}
var _ddd=this.grid.layout.cells,_dde=function(_ddf){
var _de0=0;
for(var i=_ddf.min.col;i<=_ddf.max.col;++i){
if(_ddd[i].hidden){
++_de0;
}
}
return (_ddf.max.row-_ddf.min.row+1)*(_ddf.max.col-_ddf.min.col+1-_de0);
},_de1=function(item,_de2){
return item.row>=_de2.min.row&&item.row<=_de2.max.row&&item.col>=_de2.min.col&&item.col<=_de2.max.col;
},_de3={max:{row:-1,col:-1},min:{row:Infinity,col:Infinity}};
dojo.forEach(_ddc[type],function(item){
if(item.row<_de3.min.row){
_de3.min.row=item.row;
}
if(item.row>_de3.max.row){
_de3.max.row=item.row;
}
if(item.col<_de3.min.col){
_de3.min.col=item.col;
}
if(item.col>_de3.max.col){
_de3.max.col=item.col;
}
});
if(dojo.some(_ddc[type],function(item){
return item.row==_dda&&item.col==_ddb;
})){
if(_dde(_de3)==_ddc[type].length&&dojo.every(_ddc[type],function(item){
return _de1(item,_de3);
})){
return {"type":type,"selected":[_de3],"handle":{"row":_dda,"col":_ddb}};
}
}
return null;
case 2:
case 4:
type=flag==2?"row":"col";
if(!this._config[type]["within"]&&!this._config[type]["out"]){
return null;
}
var res=s.getSelected(type);
if(res.length){
return {"type":type,"selected":_dcd(res),"handle":flag==2?_dda:_ddb};
}
return null;
}
return null;
},_startDnd:function(evt){
this._createDnDUI(evt);
},_endDnd:function(_de4){
this._destroyDnDUI(false,_de4);
this._clear();
},_createDnDUI:function(evt,_de5){
var _de6=dojo.position(this.grid.views.views[0].domNode);
dojo.style(this._container,"height",_de6.h+"px");
try{
if(!_de5){
this._createSource(evt);
}
this._createMoveable(evt);
this._oldCursor=dojo.style(dojo.body(),"cursor");
dojo.style(dojo.body(),"cursor","default");
}
catch(e){
console.warn("DnD._createDnDUI() error:",e);
}
},_destroyDnDUI:function(_de7,_de8){
try{
if(_de8){
this._destroySource();
}
this._unmarkTargetAnchor();
if(!_de7){
this._destroyMoveable();
}
dojo.style(dojo.body(),"cursor",this._oldCursor);
}
catch(e){
console.warn("DnD._destroyDnDUI() error:",this.grid.id,e);
}
},_createSource:function(evt){
this._elem.createDnDNodes(this._dndRegion);
var m=dojo.dnd.manager();
var _de9=m.makeAvatar;
m._dndPlugin=this;
m.makeAvatar=function(){
var _dea=new dojox.grid.enhanced.plugins.GridDnDAvatar(m);
delete m._dndPlugin;
return _dea;
};
m.startDrag(this._source,this._elem.getDnDNodes(),evt.ctrlKey);
m.makeAvatar=_de9;
m.onMouseMove(evt);
},_destroySource:function(){
dojo.publish("/dnd/cancel");
},_createMoveable:function(evt){
if(!this._markTagetAnchorHandler){
this._markTagetAnchorHandler=this.connect(dojo.doc,"onmousemove","_markTargetAnchor");
}
},_destroyMoveable:function(){
this.disconnect(this._markTagetAnchorHandler);
delete this._markTagetAnchorHandler;
},_calcColTargetAnchorPos:function(evt,_deb){
var i,_dec,left,_ded,ex=evt.clientX,_dee=this.grid.layout.cells,ltr=dojo._isBodyLtr(),_def=this._getVisibleHeaders();
for(i=0;i<_def.length;++i){
_dec=dojo.position(_def[i].node);
if(ltr?((i===0||ex>=_dec.x)&&ex<_dec.x+_dec.w):((i===0||ex<_dec.x+_dec.w)&&ex>=_dec.x)){
left=_dec.x+(ltr?0:_dec.w);
break;
}else{
if(ltr?(i===_def.length-1&&ex>=_dec.x+_dec.w):(i===_def.length-1&&ex<_dec.x)){
++i;
left=_dec.x+(ltr?_dec.w:0);
break;
}
}
}
if(i<_def.length){
_ded=_def[i].cell.index;
if(this.selector.isSelected("col",_ded)&&this.selector.isSelected("col",_ded-1)){
var _df0=this._dndRegion.selected;
for(i=0;i<_df0.length;++i){
if(dojo.indexOf(_df0[i],_ded)>=0){
_ded=_df0[i][0];
_dec=dojo.position(_dee[_ded].getHeaderNode());
left=_dec.x+(ltr?0:_dec.w);
break;
}
}
}
}else{
_ded=_dee.length;
}
this._target=_ded;
return left-_deb.x;
},_calcRowTargetAnchorPos:function(evt,_df1){
var g=this.grid,top,i=0,_df2=g.layout.cells;
while(_df2[i].hidden){
++i;
}
var cell=g.layout.cells[i],_df3=g.scroller.firstVisibleRow,_df4=cell.getNode(_df3);
if(!_df4){
this._target=-1;
return 0;
}
var _df5=dojo.position(_df4);
while(_df5.y+_df5.h<evt.clientY){
if(++_df3>=g.rowCount){
break;
}
_df5=dojo.position(cell.getNode(_df3));
}
if(_df3<g.rowCount){
if(this.selector.isSelected("row",_df3)&&this.selector.isSelected("row",_df3-1)){
var _df6=this._dndRegion.selected;
for(i=0;i<_df6.length;++i){
if(dojo.indexOf(_df6[i],_df3)>=0){
_df3=_df6[i][0];
_df5=dojo.position(cell.getNode(_df3));
break;
}
}
}
top=_df5.y;
}else{
top=_df5.y+_df5.h;
}
this._target=_df3;
return top-_df1.y;
},_calcCellTargetAnchorPos:function(evt,_df7,_df8){
var s=this._dndRegion.selected[0],_df9=this._dndRegion.handle,g=this.grid,ltr=dojo._isBodyLtr(),_dfa=g.layout.cells,_dfb,_dfc,_dfd,_dfe,_dff,_e00,left,top,_e01,_e02,i,_e03=_df9.col-s.min.col,_e04=s.max.col-_df9.col,_e05,_e06;
if(!_df8.childNodes.length){
_e05=dojo.create("div",{"class":"dojoxGridCellBorderLeftTopDIV"},_df8);
_e06=dojo.create("div",{"class":"dojoxGridCellBorderRightBottomDIV"},_df8);
}else{
_e05=dojo.query(".dojoxGridCellBorderLeftTopDIV",_df8)[0];
_e06=dojo.query(".dojoxGridCellBorderRightBottomDIV",_df8)[0];
}
for(i=s.min.col+1;i<_df9.col;++i){
if(_dfa[i].hidden){
--_e03;
}
}
for(i=_df9.col+1;i<s.max.col;++i){
if(_dfa[i].hidden){
--_e04;
}
}
_dfe=this._getVisibleHeaders();
for(i=_e03;i<_dfe.length-_e04;++i){
_dfb=dojo.position(_dfe[i].node);
if((evt.clientX>=_dfb.x&&evt.clientX<_dfb.x+_dfb.w)||(i==_e03&&(ltr?evt.clientX<_dfb.x:evt.clientX>=_dfb.x+_dfb.w))||(i==_dfe.length-_e04-1&&(ltr?evt.clientX>=_dfb.x+_dfb.w:evt<_dfb.x))){
_e01=_dfe[i-_e03];
_e02=_dfe[i+_e04];
_dfc=dojo.position(_e01.node);
_dfd=dojo.position(_e02.node);
_e01=_e01.cell.index;
_e02=_e02.cell.index;
left=ltr?_dfc.x:_dfd.x;
_e00=ltr?(_dfd.x+_dfd.w-_dfc.x):(_dfc.x+_dfc.w-_dfd.x);
break;
}
}
i=0;
while(_dfa[i].hidden){
++i;
}
var cell=_dfa[i],_e07=g.scroller.firstVisibleRow,_e08=dojo.position(cell.getNode(_e07));
while(_e08.y+_e08.h<evt.clientY){
if(++_e07<g.rowCount){
_e08=dojo.position(cell.getNode(_e07));
}else{
break;
}
}
var _e09=_e07>=_df9.row-s.min.row?_e07-_df9.row+s.min.row:0;
var _e0a=_e09+s.max.row-s.min.row;
if(_e0a>=g.rowCount){
_e0a=g.rowCount-1;
_e09=_e0a-s.max.row+s.min.row;
}
_dfc=dojo.position(cell.getNode(_e09));
_dfd=dojo.position(cell.getNode(_e0a));
top=_dfc.y;
_dff=_dfd.y+_dfd.h-_dfc.y;
this._target={"min":{"row":_e09,"col":_e01},"max":{"row":_e0a,"col":_e02}};
var _e0b=(dojo.marginBox(_e05).w-dojo.contentBox(_e05).w)/2;
var _e0c=dojo.position(_dfa[_e01].getNode(_e09));
dojo.style(_e05,{"width":(_e0c.w-_e0b)+"px","height":(_e0c.h-_e0b)+"px"});
var _e0d=dojo.position(_dfa[_e02].getNode(_e0a));
dojo.style(_e06,{"width":(_e0d.w-_e0b)+"px","height":(_e0d.h-_e0b)+"px"});
return {h:_dff,w:_e00,l:left-_df7.x,t:top-_df7.y};
},_markTargetAnchor:function(evt){
try{
var t=this._dndRegion.type;
if(this._alreadyOut||(this._dnding&&!this._config[t]["within"])||(this._extDnding&&!this._config[t]["in"])){
return;
}
var _e0e,_e0f,left,top,_e10=this._targetAnchor[t],pos=dojo.position(this._container);
if(!_e10){
_e10=this._targetAnchor[t]=dojo.create("div",{"class":(t=="cell")?"dojoxGridCellBorderDIV":"dojoxGridBorderDIV"});
dojo.style(_e10,"display","none");
this._container.appendChild(_e10);
}
switch(t){
case "col":
_e0e=pos.h;
_e0f=this._targetAnchorBorderWidth;
left=this._calcColTargetAnchorPos(evt,pos);
top=0;
break;
case "row":
_e0e=this._targetAnchorBorderWidth;
_e0f=pos.w;
left=0;
top=this._calcRowTargetAnchorPos(evt,pos);
break;
case "cell":
var _e11=this._calcCellTargetAnchorPos(evt,pos,_e10);
_e0e=_e11.h;
_e0f=_e11.w;
left=_e11.l;
top=_e11.t;
}
if(typeof _e0e=="number"&&typeof _e0f=="number"&&typeof left=="number"&&typeof top=="number"){
dojo.style(_e10,{"height":_e0e+"px","width":_e0f+"px","left":left+"px","top":top+"px"});
dojo.style(_e10,"display","");
}else{
this._target=null;
}
}
catch(e){
console.warn("DnD._markTargetAnchor() error:",e);
}
},_unmarkTargetAnchor:function(){
if(this._dndRegion){
var _e12=this._targetAnchor[this._dndRegion.type];
if(_e12){
dojo.style(this._targetAnchor[this._dndRegion.type],"display","none");
}
}
},_getVisibleHeaders:function(){
return dojo.map(dojo.filter(this.grid.layout.cells,function(cell){
return !cell.hidden;
}),function(cell){
return {"node":cell.getHeaderNode(),"cell":cell};
});
},_rearrange:function(){
if(this._target===null){
return;
}
var t=this._dndRegion.type;
var _e13=this._dndRegion.selected;
if(t==="cell"){
this.rearranger[(this._isCopy||this._copyOnly)?"copyCells":"moveCells"](_e13[0],this._target===-1?null:this._target);
}else{
this.rearranger[t=="col"?"moveColumns":"moveRows"](_dce(_e13),this._target===-1?null:this._target);
}
this._target=null;
},onDraggingOver:function(_e14){
if(!this._dnding&&_e14){
_e14._isSource=true;
this._extDnding=true;
if(!this._externalDnd){
this._externalDnd=true;
this._dndRegion=this._mapRegion(_e14.grid,_e14._dndRegion);
}
this._createDnDUI(this._moveEvent,true);
this.grid.pluginMgr.getPlugin("autoScroll").readyForAutoScroll=true;
}
},_mapRegion:function(_e15,_e16){
if(_e16.type==="cell"){
var _e17=_e16.selected[0];
var _e18=this.grid.layout.cells;
var _e19=_e15.layout.cells;
var c,cnt=0;
for(c=_e17.min.col;c<=_e17.max.col;++c){
if(!_e19[c].hidden){
++cnt;
}
}
for(c=0;cnt>0;++c){
if(!_e18[c].hidden){
--cnt;
}
}
var _e1a=dojo.clone(_e16);
_e1a.selected[0].min.col=0;
_e1a.selected[0].max.col=c-1;
for(c=_e17.min.col;c<=_e16.handle.col;++c){
if(!_e19[c].hidden){
++cnt;
}
}
for(c=0;cnt>0;++c){
if(!_e18[c].hidden){
--cnt;
}
}
_e1a.handle.col=c;
}
return _e16;
},onDraggingOut:function(_e1b){
if(this._externalDnd){
this._extDnding=false;
this._destroyDnDUI(true,false);
if(_e1b){
_e1b._isSource=false;
}
}
},onDragIn:function(_e1c,_e1d){
var _e1e=false;
if(this._target!==null){
var type=_e1c._dndRegion.type;
var _e1f=_e1c._dndRegion.selected;
switch(type){
case "cell":
this.rearranger.changeCells(_e1c.grid,_e1f[0],this._target);
break;
case "row":
var _e20=_dce(_e1f);
this.rearranger.insertRows(_e1c.grid,_e20,this._target);
break;
}
_e1e=true;
}
this._endDnd(true);
if(_e1c.onDragOut){
_e1c.onDragOut(_e1e&&!_e1d);
}
},onDragOut:function(_e21){
if(_e21&&!this._copyOnly){
var type=this._dndRegion.type;
var _e22=this._dndRegion.selected;
switch(type){
case "cell":
this.rearranger.clearCells(_e22[0]);
break;
case "row":
this.rearranger.removeRows(_dce(_e22));
break;
}
}
this._endDnd(true);
},_canAccept:function(_e23){
if(!_e23){
return false;
}
var _e24=_e23._dndRegion;
var type=_e24.type;
if(!this._config[type]["in"]||!_e23._config[type]["out"]){
return false;
}
var g=this.grid;
var _e25=_e24.selected;
var _e26=dojo.filter(g.layout.cells,function(cell){
return !cell.hidden;
}).length;
var _e27=g.rowCount;
var res=true;
switch(type){
case "cell":
_e25=_e25[0];
res=g.store.getFeatures()["dojo.data.api.Write"]&&(_e25.max.row-_e25.min.row)<=_e27&&dojo.filter(_e23.grid.layout.cells,function(cell){
return cell.index>=_e25.min.col&&cell.index<=_e25.max.col&&!cell.hidden;
}).length<=_e26;
case "row":
if(_e23._allDnDItemsLoaded()){
return res;
}
}
return false;
},_allDnDItemsLoaded:function(){
if(this._dndRegion){
var type=this._dndRegion.type,_e28=this._dndRegion.selected,rows=[];
switch(type){
case "cell":
for(var i=_e28[0].min.row,max=_e28[0].max.row;i<=max;++i){
rows.push(i);
}
break;
case "row":
rows=_dce(_e28);
break;
default:
return false;
}
var _e29=this.grid._by_idx;
return dojo.every(rows,function(_e2a){
return !!_e29[_e2a];
});
}
return false;
}});
dojo.declare("dojox.grid.enhanced.plugins.GridDnDElement",null,{constructor:function(_e2b){
this.plugin=_e2b;
this.node=dojo.create("div");
this._items={};
},destroy:function(){
this.plugin=null;
dojo.destroy(this.node);
this.node=null;
this._items=null;
},createDnDNodes:function(_e2c){
this.destroyDnDNodes();
var _e2d=["grid/"+_e2c.type+"s"];
var _e2e=this.plugin.grid.id+"_dndItem";
dojo.forEach(_e2c.selected,function(_e2f,i){
var id=_e2e+i;
this._items[id]={"type":_e2d,"data":_e2f,"dndPlugin":this.plugin};
this.node.appendChild(dojo.create("div",{"id":id}));
},this);
},getDnDNodes:function(){
return dojo.map(this.node.childNodes,function(node){
return node;
});
},destroyDnDNodes:function(){
dojo.empty(this.node);
this._items={};
},getItem:function(_e30){
return this._items[_e30];
}});
dojo.declare("dojox.grid.enhanced.plugins.GridDnDSource",dojo.dnd.Source,{accept:["grid/cells","grid/rows","grid/cols"],constructor:function(node,_e31){
this.grid=_e31.grid;
this.dndElem=_e31.dndElem;
this.dndPlugin=_e31.dnd;
this.sourcePlugin=null;
},destroy:function(){
this.inherited(arguments);
this.grid=null;
this.dndElem=null;
this.dndPlugin=null;
this.sourcePlugin=null;
},getItem:function(_e32){
return this.dndElem.getItem(_e32);
},checkAcceptance:function(_e33,_e34){
if(this!=_e33&&_e34[0]){
var item=_e33.getItem(_e34[0].id);
if(item.dndPlugin){
var type=item.type;
for(var j=0;j<type.length;++j){
if(type[j] in this.accept){
if(this.dndPlugin._canAccept(item.dndPlugin)){
this.sourcePlugin=item.dndPlugin;
}else{
return false;
}
break;
}
}
}else{
if("grid/rows" in this.accept){
var rows=[];
dojo.forEach(_e34,function(node){
var item=_e33.getItem(node.id);
if(item.data&&dojo.indexOf(item.type,"grid/rows")>=0){
var _e35=item.data;
if(typeof item.data=="string"){
_e35=dojo.fromJson(item.data);
}
if(_e35){
rows.push(_e35);
}
}
});
if(rows.length){
this.sourcePlugin={_dndRegion:{type:"row",selected:[rows]}};
}else{
return false;
}
}
}
}
return this.inherited(arguments);
},onDraggingOver:function(){
this.dndPlugin.onDraggingOver(this.sourcePlugin);
},onDraggingOut:function(){
this.dndPlugin.onDraggingOut(this.sourcePlugin);
},onDndDrop:function(_e36,_e37,copy,_e38){
this.onDndCancel();
if(this!=_e36&&this==_e38){
this.dndPlugin.onDragIn(this.sourcePlugin,copy);
}
}});
dojo.declare("dojox.grid.enhanced.plugins.GridDnDAvatar",dojo.dnd.Avatar,{construct:function(){
this._itemType=this.manager._dndPlugin._dndRegion.type;
this._itemCount=this._getItemCount();
this.isA11y=dojo.hasClass(dojo.body(),"dijit_a11y");
var a=dojo.create("table",{"border":"0","cellspacing":"0","class":"dojoxGridDndAvatar","style":{position:"absolute",zIndex:"1999",margin:"0px"}}),_e39=this.manager.source,b=dojo.create("tbody",null,a),tr=dojo.create("tr",null,b),td=dojo.create("td",{"class":"dojoxGridDnDIcon"},tr);
if(this.isA11y){
dojo.create("span",{"id":"a11yIcon","innerHTML":this.manager.copy?"+":"<"},td);
}
td=dojo.create("td",{"class":"dojoxGridDnDItemIcon "+this._getGridDnDIconClass()},tr);
td=dojo.create("td",null,tr);
dojo.create("span",{"class":"dojoxGridDnDItemCount","innerHTML":_e39.generateText?this._generateText():""},td);
dojo.style(tr,{"opacity":0.9});
this.node=a;
},_getItemCount:function(){
var _e3a=this.manager._dndPlugin._dndRegion.selected,_e3b=0;
switch(this._itemType){
case "cell":
_e3a=_e3a[0];
var _e3c=this.manager._dndPlugin.grid.layout.cells,_e3d=_e3a.max.col-_e3a.min.col+1,_e3e=_e3a.max.row-_e3a.min.row+1;
if(_e3d>1){
for(var i=_e3a.min.col;i<=_e3a.max.col;++i){
if(_e3c[i].hidden){
--_e3d;
}
}
}
_e3b=_e3d*_e3e;
break;
case "row":
case "col":
_e3b=_dce(_e3a).length;
}
return _e3b;
},_getGridDnDIconClass:function(){
return {"row":["dojoxGridDnDIconRowSingle","dojoxGridDnDIconRowMulti"],"col":["dojoxGridDnDIconColSingle","dojoxGridDnDIconColMulti"],"cell":["dojoxGridDnDIconCellSingle","dojoxGridDnDIconCellMulti"]}[this._itemType][this._itemCount==1?0:1];
},_generateText:function(){
return "("+this._itemCount+")";
}});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.DnD,{"dependency":["selector","rearrange"]});
})();
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.Cookie"]){
dojo._hasResource["dojox.grid.enhanced.plugins.Cookie"]=true;
dojo.provide("dojox.grid.enhanced.plugins.Cookie");
(function(){
var _e3f=function(grid){
return window.location+"/"+grid.id;
};
var _e40=function(_e41){
var _e42=[];
if(!dojo.isArray(_e41)){
_e41=[_e41];
}
dojo.forEach(_e41,function(_e43){
if(dojo.isArray(_e43)){
_e43={"cells":_e43};
}
var rows=_e43.rows||_e43.cells;
if(dojo.isArray(rows)){
if(!dojo.isArray(rows[0])){
rows=[rows];
}
dojo.forEach(rows,function(row){
if(dojo.isArray(row)){
dojo.forEach(row,function(cell){
_e42.push(cell);
});
}
});
}
});
return _e42;
};
var _e44=function(_e45,grid){
if(dojo.isArray(_e45)){
var _e46=grid._setStructureAttr;
grid._setStructureAttr=function(_e47){
if(!grid._colWidthLoaded){
grid._colWidthLoaded=true;
var _e48=_e40(_e47);
for(var i=_e48.length-1;i>=0;--i){
if(typeof _e45[i]=="number"){
_e48[i].width=_e45[i]+"px";
}
}
}
_e46.call(grid,_e47);
grid._setStructureAttr=_e46;
};
}
};
var _e49=function(grid){
return dojo.map(dojo.filter(grid.layout.cells,function(cell){
return !(cell.isRowSelector||cell instanceof dojox.grid.cells.RowIndex);
}),function(cell){
return dojo[dojo.isWebKit?"marginBox":"contentBox"](cell.getHeaderNode()).w;
});
};
var _e4a=function(_e4b,grid){
if(_e4b&&dojo.every(_e4b,function(_e4c){
return dojo.isArray(_e4c)&&dojo.every(_e4c,function(_e4d){
return dojo.isArray(_e4d)&&_e4d.length>0;
});
})){
var _e4e=grid._setStructureAttr;
var _e4f=function(def){
return ("name" in def||"field" in def||"get" in def);
};
var _e50=function(def){
return (def!==null&&dojo.isObject(def)&&("cells" in def||"rows" in def||("type" in def&&!_e4f(def))));
};
grid._setStructureAttr=function(_e51){
if(!grid._colOrderLoaded){
grid._colOrderLoaded=true;
grid._setStructureAttr=_e4e;
_e51=dojo.clone(_e51);
if(dojo.isArray(_e51)&&!dojo.some(_e51,_e50)){
_e51=[{cells:_e51}];
}else{
if(_e50(_e51)){
_e51=[_e51];
}
}
var _e52=_e40(_e51);
dojo.forEach(dojo.isArray(_e51)?_e51:[_e51],function(_e53,_e54){
var _e55=_e53;
if(dojo.isArray(_e53)){
_e53.splice(0,_e53.length);
}else{
delete _e53.rows;
_e55=_e53.cells=[];
}
dojo.forEach(_e4b[_e54],function(_e56){
dojo.forEach(_e56,function(_e57){
var i,cell;
for(i=0;i<_e52.length;++i){
cell=_e52[i];
if(dojo.toJson({"name":cell.name,"field":cell.field})==dojo.toJson(_e57)){
break;
}
}
if(i<_e52.length){
_e55.push(cell);
}
});
});
});
}
_e4e.call(grid,_e51);
};
}
};
var _e58=function(grid){
var _e59=dojo.map(dojo.filter(grid.views.views,function(view){
return !(view instanceof dojox.grid._RowSelector);
}),function(view){
return dojo.map(view.structure.cells,function(_e5a){
return dojo.map(dojo.filter(_e5a,function(cell){
return !(cell.isRowSelector||cell instanceof dojox.grid.cells.RowIndex);
}),function(cell){
return {"name":cell.name,"field":cell.field};
});
});
});
return _e59;
};
var _e5b=function(_e5c,grid){
try{
if(dojo.isObject(_e5c)){
grid.setSortIndex(_e5c.idx,_e5c.asc);
}
}
catch(e){
}
};
var _e5d=function(grid){
return {idx:grid.getSortIndex(),asc:grid.getSortAsc()};
};
if(!dojo.isIE){
dojo.addOnWindowUnload(function(){
dojo.forEach(dijit.findWidgets(dojo.body()),function(_e5e){
if(_e5e instanceof dojox.grid.EnhancedGrid&&!_e5e._destroyed){
_e5e.destroyRecursive();
}
});
});
}
dojo.declare("dojox.grid.enhanced.plugins.Cookie",dojox.grid.enhanced._Plugin,{name:"cookie",_cookieEnabled:true,constructor:function(grid,args){
this.grid=grid;
args=(args&&dojo.isObject(args))?args:{};
this.cookieProps=args.cookieProps;
this._cookieHandlers=[];
this._mixinGrid();
this.addCookieHandler({name:"columnWidth",onLoad:_e44,onSave:_e49});
this.addCookieHandler({name:"columnOrder",onLoad:_e4a,onSave:_e58});
this.addCookieHandler({name:"sortOrder",onLoad:_e5b,onSave:_e5d});
dojo.forEach(this._cookieHandlers,function(_e5f){
if(args[_e5f.name]===false){
_e5f.enable=false;
}
},this);
},destroy:function(){
this._saveCookie();
this._cookieHandlers=null;
this.inherited(arguments);
},_mixinGrid:function(){
var g=this.grid;
g.addCookieHandler=dojo.hitch(this,"addCookieHandler");
g.removeCookie=dojo.hitch(this,"removeCookie");
g.setCookieEnabled=dojo.hitch(this,"setCookieEnabled");
g.getCookieEnabled=dojo.hitch(this,"getCookieEnabled");
},_saveCookie:function(){
if(this.getCookieEnabled()){
var _e60={},chs=this._cookieHandlers,_e61=this.cookieProps,_e62=_e3f(this.grid);
for(var i=chs.length-1;i>=0;--i){
if(chs[i].enabled){
_e60[chs[i].name]=chs[i].onSave(this.grid);
}
}
_e61=dojo.isObject(this.cookieProps)?this.cookieProps:{};
dojo.cookie(_e62,dojo.toJson(_e60),_e61);
}else{
this.removeCookie();
}
},onPreInit:function(){
var grid=this.grid,chs=this._cookieHandlers,_e63=_e3f(grid),_e64=dojo.cookie(_e63);
if(_e64){
_e64=dojo.fromJson(_e64);
for(var i=0;i<chs.length;++i){
if(chs[i].name in _e64&&chs[i].enabled){
chs[i].onLoad(_e64[chs[i].name],grid);
}
}
}
this._cookie=_e64||{};
this._cookieStartedup=true;
},addCookieHandler:function(args){
if(args.name){
var _e65=function(){
};
args.onLoad=args.onLoad||_e65;
args.onSave=args.onSave||_e65;
if(!("enabled" in args)){
args.enabled=true;
}
for(var i=this._cookieHandlers.length-1;i>=0;--i){
if(this._cookieHandlers[i].name==args.name){
this._cookieHandlers.splice(i,1);
}
}
this._cookieHandlers.push(args);
if(this._cookieStartedup&&args.name in this._cookie){
args.onLoad(this._cookie[args.name],this.grid);
}
}
},removeCookie:function(){
var key=_e3f(this.grid);
dojo.cookie(key,null,{expires:-1});
},setCookieEnabled:function(_e66,_e67){
if(arguments.length==2){
var chs=this._cookieHandlers;
for(var i=chs.length-1;i>=0;--i){
if(chs[i].name===_e66){
chs[i].enabled=!!_e67;
}
}
}else{
this._cookieEnabled=!!_e66;
if(!this._cookieEnabled){
this.removeCookie();
}
}
},getCookieEnabled:function(_e68){
if(dojo.isString(_e68)){
var chs=this._cookieHandlers;
for(var i=chs.length-1;i>=0;--i){
if(chs[i].name==_e68){
return chs[i].enabled;
}
}
return false;
}
return this._cookieEnabled;
}});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.Cookie,{"preInit":true});
})();
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.GridSource"]){
dojo._hasResource["dojox.grid.enhanced.plugins.GridSource"]=true;
dojo.provide("dojox.grid.enhanced.plugins.GridSource");
(function(){
var _e69=function(_e6a){
var a=_e6a[0];
for(var i=1;i<_e6a.length;++i){
a=a.concat(_e6a[i]);
}
return a;
};
dojo.declare("dojox.grid.enhanced.plugins.GridSource",dojo.dnd.Source,{accept:["grid/cells","grid/rows","grid/cols","text"],insertNodesForGrid:false,markupFactory:function(_e6b,node){
return new dojox.grid.enhanced.plugins.GridSource(node,_e6b);
},checkAcceptance:function(_e6c,_e6d){
if(_e6c instanceof dojox.grid.enhanced.plugins.GridDnDSource){
if(_e6d[0]){
var item=_e6c.getItem(_e6d[0].id);
if(item&&(dojo.indexOf(item.type,"grid/rows")>=0||dojo.indexOf(item.type,"grid/cells")>=0)&&!_e6c.dndPlugin._allDnDItemsLoaded()){
return false;
}
}
this.sourcePlugin=_e6c.dndPlugin;
}
return this.inherited(arguments);
},onDraggingOver:function(){
if(this.sourcePlugin){
this.sourcePlugin._isSource=true;
}
},onDraggingOut:function(){
if(this.sourcePlugin){
this.sourcePlugin._isSource=false;
}
},onDropExternal:function(_e6e,_e6f,copy){
if(_e6e instanceof dojox.grid.enhanced.plugins.GridDnDSource){
var _e70=dojo.map(_e6f,function(node){
return _e6e.getItem(node.id).data;
});
var item=_e6e.getItem(_e6f[0].id);
var grid=item.dndPlugin.grid;
var type=item.type[0];
var _e71;
try{
switch(type){
case "grid/cells":
_e6f[0].innerHTML=this.getCellContent(grid,_e70[0].min,_e70[0].max)||"";
this.onDropGridCells(grid,_e70[0].min,_e70[0].max);
break;
case "grid/rows":
_e71=_e69(_e70);
_e6f[0].innerHTML=this.getRowContent(grid,_e71)||"";
this.onDropGridRows(grid,_e71);
break;
case "grid/cols":
_e71=_e69(_e70);
_e6f[0].innerHTML=this.getColumnContent(grid,_e71)||"";
this.onDropGridColumns(grid,_e71);
break;
}
if(this.insertNodesForGrid){
this.selectNone();
this.insertNodes(true,[_e6f[0]],this.before,this.current);
}
item.dndPlugin.onDragOut(!copy);
}
catch(e){
console.warn("GridSource.onDropExternal() error:",e);
}
}else{
this.inherited(arguments);
}
},getCellContent:function(grid,_e72,_e73){
},getRowContent:function(grid,_e74){
},getColumnContent:function(grid,_e75){
},onDropGridCells:function(grid,_e76,_e77){
},onDropGridRows:function(grid,_e78){
},onDropGridColumns:function(grid,_e79){
}});
})();
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.Search"]){
dojo._hasResource["dojox.grid.enhanced.plugins.Search"]=true;
dojo.provide("dojox.grid.enhanced.plugins.Search");
dojo.declare("dojox.grid.enhanced.plugins.Search",dojox.grid.enhanced._Plugin,{name:"search",constructor:function(grid,args){
this.grid=grid;
args=(args&&dojo.isObject(args))?args:{};
this._cacheSize=args.cacheSize||-1;
grid.searchRow=dojo.hitch(this,"searchRow");
},searchRow:function(_e7a,_e7b){
if(!dojo.isFunction(_e7b)){
return;
}
if(dojo.isString(_e7a)){
_e7a=dojo.data.util.filter.patternToRegExp(_e7a);
}
var _e7c=false;
if(_e7a instanceof RegExp){
_e7c=true;
}else{
if(dojo.isObject(_e7a)){
var _e7d=true;
for(var _e7e in _e7a){
if(dojo.isString(_e7a[_e7e])){
_e7a[_e7e]=dojo.data.util.filter.patternToRegExp(_e7a[_e7e]);
}
_e7d=false;
}
if(_e7d){
return;
}
}else{
return;
}
}
this._search(_e7a,0,_e7b,_e7c);
},_search:function(_e7f,_e80,_e81,_e82){
var _e83=this,cnt=this._cacheSize,args={"start":_e80,"onBegin":function(size){
_e83._storeSize=size;
},"onComplete":function(_e84){
if(!dojo.some(_e84,function(item,i){
if(_e83._checkRow(item,_e7f,_e82)){
_e81(_e80+i,item);
return true;
}
return false;
})){
if(cnt>0&&_e80+cnt<_e83._storeSize){
_e83._search(_e7f,_e80+cnt,_e81,_e82);
}else{
_e81(-1,null);
}
}
}};
if(cnt>0){
args.count=cnt;
}
this.grid._storeLayerFetch(args);
},_checkRow:function(item,_e85,_e86){
var g=this.grid,s=g.store,i,_e87,_e88=dojo.filter(g.layout.cells,function(cell){
return !cell.hidden;
});
if(_e86){
return dojo.some(_e88,function(cell){
try{
if(cell.field){
return String(s.getValue(item,cell.field)).search(_e85)>=0;
}
}
catch(e){
}
return false;
});
}else{
for(_e87 in _e85){
if(_e85[_e87] instanceof RegExp){
for(i=_e88.length-1;i>=0;--i){
if(_e88[i].field==_e87){
try{
if(String(s.getValue(item,_e87)).search(_e85[_e87])<0){
return false;
}
break;
}
catch(e){
return false;
}
}
}
if(i<0){
return false;
}
}
}
return true;
}
}});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.Search);
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.Exporter"]){
dojo._hasResource["dojox.grid.enhanced.plugins.Exporter"]=true;
dojo.provide("dojox.grid.enhanced.plugins.Exporter");
dojo.declare("dojox.grid.enhanced.plugins.Exporter",dojox.grid.enhanced._Plugin,{name:"exporter",constructor:function(grid,args){
this.grid=grid;
this.formatter=(args&&dojo.isObject(args))&&args.exportFormatter;
this._mixinGrid();
},_mixinGrid:function(){
var g=this.grid;
g.exportTo=dojo.hitch(this,this.exportTo);
g.exportGrid=dojo.hitch(this,this.exportGrid);
g.exportSelected=dojo.hitch(this,this.exportSelected);
g.setExportFormatter=dojo.hitch(this,this.setExportFormatter);
},setExportFormatter:function(_e89){
this.formatter=_e89;
},exportGrid:function(type,args,_e8a){
if(dojo.isFunction(args)){
_e8a=args;
args={};
}
if(!dojo.isString(type)||!dojo.isFunction(_e8a)){
return;
}
args=args||{};
var g=this.grid,_e8b=this,_e8c=this._getExportWriter(type,args.writerArgs),_e8d=(args.fetchArgs&&dojo.isObject(args.fetchArgs))?args.fetchArgs:{},_e8e=_e8d.onComplete;
if(g.store){
_e8d.onComplete=function(_e8f,_e90){
if(_e8e){
_e8e(_e8f,_e90);
}
_e8a(_e8b._goThroughGridData(_e8f,_e8c));
};
_e8d.sort=_e8d.sort||g.getSortProps();
g._storeLayerFetch(_e8d);
}else{
var _e91=_e8d.start||0,_e92=_e8d.count||-1,_e93=[];
for(var i=_e91;i!=_e91+_e92&&i<g.rowCount;++i){
_e93.push(g.getItem(i));
}
_e8a(this._goThroughGridData(_e93,_e8c));
}
},exportSelected:function(type,_e94,_e95){
var _e96=this,_e97=this._getExportWriter(type,_e94);
this.grid.selection.getSelectedItems().then(function(_e98){
_e95(_e96._goThroughGridData(_e98,_e97));
});
},_buildRow:function(_e99,_e9a){
var _e9b=this;
dojo.forEach(_e99._views,function(view,vIdx){
_e99.view=view;
_e99.viewIdx=vIdx;
if(_e9a.beforeView(_e99)){
dojo.forEach(view.structure.cells,function(_e9c,_e9d){
_e99.subrow=_e9c;
_e99.subrowIdx=_e9d;
if(_e9a.beforeSubrow(_e99)){
dojo.forEach(_e9c,function(cell,cIdx){
if(_e99.isHeader&&_e9b._isSpecialCol(cell)){
_e99.spCols.push(cell.index);
}
_e99.cell=cell;
_e99.cellIdx=cIdx;
_e9a.handleCell(_e99);
});
_e9a.afterSubrow(_e99);
}
});
_e9a.afterView(_e99);
}
});
},_goThroughGridData:function(_e9e,_e9f){
var grid=this.grid,_ea0=dojo.filter(grid.views.views,function(view){
return !(view instanceof dojox.grid._RowSelector);
}),_ea1={"grid":grid,"isHeader":true,"spCols":[],"_views":_ea0,"colOffset":(_ea0.length<grid.views.views.length?-1:0)};
if(_e9f.beforeHeader(grid)){
this._buildRow(_ea1,_e9f);
_e9f.afterHeader();
}
_ea1.isHeader=false;
if(_e9f.beforeContent(_e9e)){
dojo.forEach(_e9e,function(item,rIdx){
_ea1.row=item;
_ea1.rowIdx=rIdx;
if(_e9f.beforeContentRow(_ea1)){
this._buildRow(_ea1,_e9f);
_e9f.afterContentRow(_ea1);
}
},this);
_e9f.afterContent();
}
return _e9f.toString();
},_isSpecialCol:function(_ea2){
return _ea2.isRowSelector||_ea2 instanceof dojox.grid.cells.RowIndex;
},_getExportWriter:function(_ea3,_ea4){
var _ea5,cls,_ea6=dojox.grid.enhanced.plugins.Exporter;
if(_ea6.writerNames){
_ea5=_ea6.writerNames[_ea3.toLowerCase()];
cls=dojo.getObject(_ea5);
if(cls){
var _ea7=new cls(_ea4);
_ea7.formatter=this.formatter;
return _ea7;
}else{
throw new Error("Please make sure class \""+_ea5+"\" is required.");
}
}
throw new Error("The writer for \""+_ea3+"\" has not been registered.");
}});
dojox.grid.enhanced.plugins.Exporter.registerWriter=function(_ea8,_ea9){
var _eaa=dojox.grid.enhanced.plugins.Exporter;
_eaa.writerNames=_eaa.writerNames||{};
_eaa.writerNames[_ea8]=_ea9;
};
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.Exporter);
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.exporter._ExportWriter"]){
dojo._hasResource["dojox.grid.enhanced.plugins.exporter._ExportWriter"]=true;
dojo.provide("dojox.grid.enhanced.plugins.exporter._ExportWriter");
dojo.declare("dojox.grid.enhanced.plugins.exporter._ExportWriter",null,{constructor:function(_eab){
},_getExportDataForCell:function(_eac,_ead,cell,grid){
var data=(cell.get||grid.get).call(cell,_eac,_ead);
if(this.formatter){
return this.formatter(data,cell,_eac,_ead);
}else{
return data;
}
},beforeHeader:function(grid){
return true;
},afterHeader:function(){
},beforeContent:function(_eae){
return true;
},afterContent:function(){
},beforeContentRow:function(_eaf){
return true;
},afterContentRow:function(_eb0){
},beforeView:function(_eb1){
return true;
},afterView:function(_eb2){
},beforeSubrow:function(_eb3){
return true;
},afterSubrow:function(_eb4){
},handleCell:function(_eb5){
},toString:function(){
return "";
}});
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.exporter.CSVWriter"]){
dojo._hasResource["dojox.grid.enhanced.plugins.exporter.CSVWriter"]=true;
dojo.provide("dojox.grid.enhanced.plugins.exporter.CSVWriter");
dojox.grid.enhanced.plugins.Exporter.registerWriter("csv","dojox.grid.enhanced.plugins.exporter.CSVWriter");
dojo.declare("dojox.grid.enhanced.plugins.exporter.CSVWriter",dojox.grid.enhanced.plugins.exporter._ExportWriter,{_separator:",",_newline:"\r\n",constructor:function(_eb6){
if(_eb6){
this._separator=_eb6.separator?_eb6.separator:this._separator;
this._newline=_eb6.newline?_eb6.newline:this._newline;
}
this._headers=[];
this._dataRows=[];
},_formatCSVCell:function(_eb7){
if(_eb7===null||_eb7===undefined){
return "";
}
var _eb8=String(_eb7).replace(/"/g,"\"\"");
if(_eb8.indexOf(this._separator)>=0||_eb8.search(/[" \t\r\n]/)>=0){
_eb8="\""+_eb8+"\"";
}
return _eb8;
},beforeContentRow:function(_eb9){
var row=[],func=this._formatCSVCell;
dojo.forEach(_eb9.grid.layout.cells,function(cell){
if(!cell.hidden&&dojo.indexOf(_eb9.spCols,cell.index)<0){
row.push(func(this._getExportDataForCell(_eb9.rowIndex,_eb9.row,cell,_eb9.grid)));
}
},this);
this._dataRows.push(row);
return false;
},handleCell:function(_eba){
var cell=_eba.cell;
if(_eba.isHeader&&!cell.hidden&&dojo.indexOf(_eba.spCols,cell.index)<0){
this._headers.push(cell.name||cell.field);
}
},toString:function(){
var _ebb=this._headers.join(this._separator);
for(var i=this._dataRows.length-1;i>=0;--i){
this._dataRows[i]=this._dataRows[i].join(this._separator);
}
return _ebb+this._newline+this._dataRows.join(this._newline);
}});
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.exporter.TableWriter"]){
dojo._hasResource["dojox.grid.enhanced.plugins.exporter.TableWriter"]=true;
dojo.provide("dojox.grid.enhanced.plugins.exporter.TableWriter");
dojox.grid.enhanced.plugins.Exporter.registerWriter("table","dojox.grid.enhanced.plugins.exporter.TableWriter");
dojo.declare("dojox.grid.enhanced.plugins.exporter.TableWriter",dojox.grid.enhanced.plugins.exporter._ExportWriter,{constructor:function(_ebc){
this._viewTables=[];
this._tableAttrs=_ebc||{};
},_getTableAttrs:function(_ebd){
var _ebe=this._tableAttrs[_ebd]||"";
if(_ebe&&_ebe[0]!=" "){
_ebe=" "+_ebe;
}
return _ebe;
},_getRowClass:function(_ebf){
return _ebf.isHeader?" grid_header":[" grid_row grid_row_",_ebf.rowIdx+1,_ebf.rowIdx%2?" grid_even_row":" grid_odd_row"].join("");
},_getColumnClass:function(_ec0){
var _ec1=_ec0.cell.index+_ec0.colOffset+1;
return [" grid_column grid_column_",_ec1,_ec1%2?" grid_odd_column":" grid_even_column"].join("");
},beforeView:function(_ec2){
var _ec3=_ec2.viewIdx,_ec4=this._viewTables[_ec3],_ec5,_ec6=dojo.marginBox(_ec2.view.contentNode).w;
if(!_ec4){
var left=0;
for(var i=0;i<_ec3;++i){
left+=this._viewTables[i]._width;
}
_ec4=this._viewTables[_ec3]=["<div class=\"grid_view\" style=\"position: absolute; top: 0; ",dojo._isBodyLtr()?"left":"right",":",left,"px;\">"];
}
_ec4._width=_ec6;
if(_ec2.isHeader){
_ec5=dojo.contentBox(_ec2.view.headerContentNode).h;
}else{
var _ec7=_ec2.grid.getRowNode(_ec2.rowIdx);
if(_ec7){
_ec5=dojo.contentBox(_ec7).h;
}else{
_ec5=_ec2.grid.scroller.averageRowHeight;
}
}
_ec4.push("<table class=\"",this._getRowClass(_ec2),"\" style=\"table-layout:fixed; height:",_ec5,"px; width:",_ec6,"px;\" ","border=\"0\" cellspacing=\"0\" cellpadding=\"0\" ",this._getTableAttrs("table"),"><tbody ",this._getTableAttrs("tbody"),">");
return true;
},afterView:function(_ec8){
this._viewTables[_ec8.viewIdx].push("</tbody></table>");
},beforeSubrow:function(_ec9){
this._viewTables[_ec9.viewIdx].push("<tr",this._getTableAttrs("tr"),">");
return true;
},afterSubrow:function(_eca){
this._viewTables[_eca.viewIdx].push("</tr>");
},handleCell:function(_ecb){
var cell=_ecb.cell;
if(cell.hidden||dojo.indexOf(_ecb.spCols,cell.index)>=0){
return;
}
var _ecc=_ecb.isHeader?"th":"td",_ecd=[cell.colSpan?" colspan=\""+cell.colSpan+"\"":"",cell.rowSpan?" rowspan=\""+cell.rowSpan+"\"":""," style=\"width: ",dojo.contentBox(cell.getHeaderNode()).w,"px;\"",this._getTableAttrs(_ecc)," class=\"",this._getColumnClass(_ecb),"\""].join(""),_ece=this._viewTables[_ecb.viewIdx];
_ece.push("<",_ecc,_ecd,">");
if(_ecb.isHeader){
_ece.push(cell.name||cell.field);
}else{
_ece.push(this._getExportDataForCell(_ecb.rowIdx,_ecb.row,cell,_ecb.grid));
}
_ece.push("</",_ecc,">");
},afterContent:function(){
dojo.forEach(this._viewTables,function(_ecf){
_ecf.push("</div>");
});
},toString:function(){
var _ed0=dojo.map(this._viewTables,function(_ed1){
return _ed1.join("");
}).join("");
return ["<div style=\"position: relative;\">",_ed0,"</div>"].join("");
}});
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.Printer"]){
dojo._hasResource["dojox.grid.enhanced.plugins.Printer"]=true;
dojo.provide("dojox.grid.enhanced.plugins.Printer");
dojo.declare("dojox.grid.enhanced.plugins.Printer",dojox.grid.enhanced._Plugin,{name:"printer",constructor:function(grid){
this.grid=grid;
this._mixinGrid(grid);
grid.setExportFormatter(function(data,cell,_ed2,_ed3){
return cell.format(_ed2,_ed3);
});
},_mixinGrid:function(){
var g=this.grid;
g.printGrid=dojo.hitch(this,this.printGrid);
g.printSelected=dojo.hitch(this,this.printSelected);
g.exportToHTML=dojo.hitch(this,this.exportToHTML);
g.exportSelectedToHTML=dojo.hitch(this,this.exportSelectedToHTML);
g.normalizePrintedGrid=dojo.hitch(this,this.normalizeRowHeight);
},printGrid:function(args){
this.exportToHTML(args,dojo.hitch(this,this._print));
},printSelected:function(args){
this.exportSelectedToHTML(args,dojo.hitch(this,this._print));
},exportToHTML:function(args,_ed4){
args=this._formalizeArgs(args);
var _ed5=this;
this.grid.exportGrid("table",args,function(str){
_ed5._wrapHTML(args.title,args.cssFiles,args.titleInBody+str).then(_ed4);
});
},exportSelectedToHTML:function(args,_ed6){
args=this._formalizeArgs(args);
var _ed7=this;
this.grid.exportSelected("table",args.writerArgs,function(str){
_ed7._wrapHTML(args.title,args.cssFiles,args.titleInBody+str).then(_ed6);
});
},_loadCSSFiles:function(_ed8){
var dl=dojo.map(_ed8,function(_ed9){
_ed9=dojo.trim(_ed9);
if(_ed9.substring(_ed9.length-4).toLowerCase()===".css"){
return dojo.xhrGet({url:_ed9});
}else{
var d=new dojo.Deferred();
d.callback(_ed9);
return d;
}
});
return dojo.DeferredList.prototype.gatherResults(dl);
},_print:function(_eda){
var win,_edb=this,_edc=function(w){
var doc=w.document;
doc.open();
doc.write(_eda);
doc.close();
_edb.normalizeRowHeight(doc);
};
if(!window.print){
return;
}else{
if(dojo.isChrome||dojo.isOpera){
win=window.open("javascript: ''","","status=0,menubar=0,location=0,toolbar=0,width=1,height=1,resizable=0,scrollbars=0");
_edc(win);
win.print();
win.close();
}else{
var fn=this._printFrame,dn=this.grid.domNode;
if(!fn){
var _edd=dn.id+"_print_frame";
if(!(fn=dojo.byId(_edd))){
fn=dojo.create("iframe");
fn.id=_edd;
fn.frameBorder=0;
dojo.style(fn,{width:"1px",height:"1px",position:"absolute",right:0,bottom:0,border:"none",overflow:"hidden"});
if(!dojo.isIE){
dojo.style(fn,"visibility","hidden");
}
dn.appendChild(fn);
}
this._printFrame=fn;
}
win=fn.contentWindow;
_edc(win);
win.focus();
win.print();
}
}
},_wrapHTML:function(_ede,_edf,_ee0){
return this._loadCSSFiles(_edf).then(function(_ee1){
var i,html=["<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">","<html ",dojo._isBodyLtr()?"":"dir=\"rtl\"","><head><title>",_ede,"</title><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"></meta>"];
for(i=0;i<_ee1.length;++i){
html.push("<style type=\"text/css\">",_ee1[i],"</style>");
}
html.push("</head>");
if(_ee0.search(/^\s*<body/i)<0){
_ee0="<body>"+_ee0+"</body>";
}
html.push(_ee0,"</html>");
return html.join("");
});
},normalizeRowHeight:function(doc){
var _ee2=dojo.query(".grid_view",doc.body);
var _ee3=dojo.map(_ee2,function(view){
return dojo.query(".grid_header",view)[0];
});
var _ee4=dojo.map(_ee2,function(view){
return dojo.query(".grid_row",view);
});
var _ee5=_ee4[0].length;
var i,v,h,_ee6=0;
for(v=_ee2.length-1;v>=0;--v){
h=dojo.contentBox(_ee3[v]).h;
if(h>_ee6){
_ee6=h;
}
}
for(v=_ee2.length-1;v>=0;--v){
dojo.style(_ee3[v],"height",_ee6+"px");
}
for(i=0;i<_ee5;++i){
_ee6=0;
for(v=_ee2.length-1;v>=0;--v){
h=dojo.contentBox(_ee4[v][i]).h;
if(h>_ee6){
_ee6=h;
}
}
for(v=_ee2.length-1;v>=0;--v){
dojo.style(_ee4[v][i],"height",_ee6+"px");
}
}
var left=0,ltr=dojo._isBodyLtr();
for(v=0;v<_ee2.length;++v){
dojo.style(_ee2[v],ltr?"left":"right",left+"px");
left+=dojo.marginBox(_ee2[v]).w;
}
},_formalizeArgs:function(args){
args=(args&&dojo.isObject(args))?args:{};
args.title=String(args.title)||"";
if(!dojo.isArray(args.cssFiles)){
args.cssFiles=[args.cssFiles];
}
args.titleInBody=args.title?["<h1>",args.title,"</h1>"].join(""):"";
return args;
}});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.Printer,{"dependency":["exporter"]});
}
if(!dojo._hasResource["dojox.grid.enhanced.plugins.Pagination"]){
dojo._hasResource["dojox.grid.enhanced.plugins.Pagination"]=true;
dojo.provide("dojox.grid.enhanced.plugins.Pagination");
dojo.declare("dojox.grid.enhanced.plugins.Pagination",dojox.grid.enhanced._Plugin,{name:"pagination",_pageSize:25,_defaultRowsPerPage:25,_currentPage:0,_maxSize:0,init:function(){
this.gh=null;
this._defaultRowsPerPage=this.grid.rowsPerPage;
var size=this.option.defaultPageSize>0?this.option.defaultPageSize:(this.grid.rowsPerPage?this.grid.rowsPerPage:this._pageSize);
this.grid.rowsPerPage=this._pageSize=size;
this._currentPage=this.option.defaultPage>0?this.option.defaultPage-1:0;
this.grid.usingPagination=true;
this.nls=dojo.i18n.getLocalization("dojox.grid.enhanced","Pagination");
this._wrapStoreLayer();
this._createPaginators(this.option);
this._regApis();
},_createPaginators:function(_ee7){
_ee7.pageSizes=dojo.isArray(_ee7.pageSizes)?_ee7.pageSizes:["10","25","50","100","All"];
var ps=[];
dojo.forEach(_ee7.pageSizes,function(size){
size=parseInt(size,10);
size=isNaN(size)||size<=0?this.nls.all:String(size);
if(dojo.indexOf(ps,size)<0){
ps.push(size);
}
},this);
_ee7.pageSizes=ps;
this.paginators=[];
if(_ee7.position==="both"){
this.paginators=[new dojox.grid.enhanced.plugins._Paginator(dojo.mixin(_ee7,{position:"bottom",plugin:this})),new dojox.grid.enhanced.plugins._Paginator(dojo.mixin(_ee7,{position:"top",plugin:this}))];
}else{
this.paginators=[new dojox.grid.enhanced.plugins._Paginator(dojo.mixin(_ee7,{plugin:this}))];
}
},_wrapStoreLayer:function(){
var g=this.grid,ns=dojox.grid.enhanced.plugins;
this._store=g.store;
this.forcePageStoreLayer=new ns._ForcedPageStoreLayer(this);
ns.wrap(g,"_storeLayerFetch",this.forcePageStoreLayer);
},_stopEvent:function(_ee8){
try{
dojo.stopEvent(_ee8);
}
catch(e){
}
},_onNew:function(item,_ee9){
var _eea=Math.ceil(this._maxSize/this._pageSize);
if(((this._currentPage+1===_eea||_eea===0)&&this.grid.rowCount<this._pageSize)||this.showAll){
dojo.hitch(this.grid,this._originalOnNew)(item,_ee9);
this.forcePageStoreLayer.endIdx++;
}
this._maxSize++;
if(this.showAll){
this._pageSize++;
}
if(this.showAll&&this.grid.autoHeight){
this.grid._refresh();
}else{
dojo.forEach(this.paginators,function(p){
p.update();
});
}
},_removeSelectedRows:function(){
this._multiRemoving=true;
this._originalRemove();
this._multiRemoving=false;
this.grid.resize();
this.grid._refresh();
},_onDelete:function(){
if(!this._multiRemoving){
this.grid.resize();
if(this.showAll){
this.grid._refresh();
}
}
if(this.grid.get("rowCount")===0){
this.prevPage();
}
},_regApis:function(){
var g=this.grid;
g.gotoPage=dojo.hitch(this,this.gotoPage);
g.nextPage=dojo.hitch(this,this.nextPage);
g.prevPage=dojo.hitch(this,this.prevPage);
g.gotoFirstPage=dojo.hitch(this,this.gotoFirstPage);
g.gotoLastPage=dojo.hitch(this,this.gotoLastPage);
g.changePageSize=dojo.hitch(this,this.changePageSize);
g.showGotoPageButton=dojo.hitch(this,this.showGotoPageButton);
g.getTotalRowCount=dojo.hitch(this,this.getTotalRowCount);
this.originalScrollToRow=dojo.hitch(g,g.scrollToRow);
g.scrollToRow=dojo.hitch(this,this.scrollToRow);
this._originalOnNew=dojo.hitch(g,g._onNew);
this._originalRemove=dojo.hitch(g,g.removeSelectedRows);
g.removeSelectedRows=dojo.hitch(this,this._removeSelectedRows);
g._onNew=dojo.hitch(this,this._onNew);
this.connect(g,"_onDelete",dojo.hitch(this,this._onDelete));
},destroy:function(){
this.inherited(arguments);
var g=this.grid;
try{
dojo.forEach(this.paginators,function(p){
p.destroy();
});
g.unwrap(this.forcePageStoreLayer.name());
g._onNew=this._originalOnNew;
g.removeSelectedRows=this._originalRemove;
g.scrollToRow=this.originalScrollToRow;
this.paginators=null;
this.nls=null;
}
catch(e){
console.warn("Pagination.destroy() error: ",e);
}
},nextPage:function(){
if(this._maxSize>((this._currentPage+1)*this._pageSize)){
this.gotoPage(this._currentPage+2);
}
},prevPage:function(){
if(this._currentPage>0){
this.gotoPage(this._currentPage);
}
},gotoPage:function(page){
var _eeb=Math.ceil(this._maxSize/this._pageSize);
page--;
if(page<_eeb&&page>=0&&this._currentPage!==page){
this._currentPage=page;
this.grid._refresh(true);
this.grid.resize();
}
},gotoFirstPage:function(){
this.gotoPage(1);
},gotoLastPage:function(){
var _eec=Math.ceil(this._maxSize/this._pageSize);
this.gotoPage(_eec);
},changePageSize:function(size){
if(typeof size==="string"){
size=parseInt(size,10);
}
var _eed=this._pageSize*this._currentPage;
dojo.forEach(this.paginators,function(f){
if(size==-1){
f.currentPageSize=this._pageSize=this._maxSize;
this.grid.rowsPerPage=this._defaultRowsPerPage;
this.showAll=true;
}else{
f.currentPageSize=this.grid.rowsPerPage=this._pageSize=size;
this.showAll=false;
}
this.grid.usingPagination=!this.showAll;
},this);
var _eee=_eed+Math.min(this._pageSize,this._maxSize);
if(_eee>this._maxSize){
this.gotoLastPage();
}else{
var cp=Math.ceil(_eed/this._pageSize);
if(cp!==this._currentPage){
this.gotoPage(cp+1);
}else{
this.grid._refresh(true);
}
}
this.grid.resize();
},showGotoPageButton:function(flag){
dojo.forEach(this.paginators,function(p){
p._showGotoButton(flag);
});
},scrollToRow:function(_eef){
var page=parseInt(_eef/this._pageSize,10),_ef0=Math.ceil(this._maxSize/this._pageSize);
if(page>_ef0){
return;
}
this.gotoPage(page+1);
var _ef1=_eef%this._pageSize;
return this.originalScrollToRow(_ef1);
},getTotalRowCount:function(){
return this._maxSize;
}});
dojo.declare("dojox.grid.enhanced.plugins._ForcedPageStoreLayer",dojox.grid.enhanced.plugins._StoreLayer,{tags:["presentation"],constructor:function(_ef2){
this._plugin=_ef2;
},_fetch:function(_ef3){
var self=this,_ef4=self._plugin,grid=_ef4.grid,_ef5=_ef3.scope||dojo.global,_ef6=_ef3.onBegin;
_ef3.start=_ef4._currentPage*_ef4._pageSize+_ef3.start;
self.startIdx=_ef3.start;
self.endIdx=_ef3.start+_ef4._pageSize-1;
if(_ef6&&(_ef4.showAll||dojo.every(_ef4.paginators,function(p){
_ef4.showAll=!p.sizeSwitch&&!p.pageStepper&&!p.gotoButton;
return _ef4.showAll;
}))){
_ef3.onBegin=function(size,req){
_ef4._maxSize=_ef4._pageSize=size;
self.startIdx=0;
self.endIdx=size-1;
dojo.forEach(_ef4.paginators,function(f){
f.update();
});
req.onBegin=_ef6;
req.onBegin.call(_ef5,size,req);
};
}else{
if(_ef6){
_ef3.onBegin=function(size,req){
req.start=0;
req.count=_ef4._pageSize;
_ef4._maxSize=size;
self.endIdx=self.endIdx>=size?(size-1):self.endIdx;
if(self.startIdx>size&&size!==0){
grid._pending_requests[req.start]=false;
_ef4.gotoFirstPage();
}
dojo.forEach(_ef4.paginators,function(f){
f.update();
});
req.onBegin=_ef6;
req.onBegin.call(_ef5,Math.min(_ef4._pageSize,(size-self.startIdx)),req);
};
}
}
return dojo.hitch(this._store,this._originFetch)(_ef3);
}});
dojo.declare("dojox.grid.enhanced.plugins._Paginator",[dijit._Widget,dijit._Templated],{templateString:"<div dojoAttachPoint=\"paginatorBar\"\r\n\t><table cellpadding=\"0\" cellspacing=\"0\"  class=\"dojoxGridPaginator\"\r\n\t\t><tr\r\n\t\t\t><td dojoAttachPoint=\"descriptionTd\" class=\"dojoxGridDescriptionTd\"\r\n\t\t\t\t><div dojoAttachPoint=\"descriptionDiv\" class=\"dojoxGridDescription\"></div\r\n\t\t\t></div></td\r\n\t\t\t><td dojoAttachPoint=\"sizeSwitchTd\"></td\r\n\t\t\t><td dojoAttachPoint=\"pageStepperTd\" class=\"dojoxGridPaginatorFastStep\"\r\n\t\t\t\t><div dojoAttachPoint=\"pageStepperDiv\" class=\"dojoxGridPaginatorStep\"></div\r\n\t\t\t></td\r\n\t\t></tr\r\n\t></table\r\n></div>\r\n",position:"bottom",_maxItemSize:0,description:true,pageStepper:true,maxPageStep:7,sizeSwitch:true,gotoButton:false,constructor:function(_ef7){
dojo.mixin(this,_ef7);
this.grid=this.plugin.grid;
},postCreate:function(){
this.inherited(arguments);
this._setWidthValue();
var self=this;
var g=this.grid;
this.plugin.connect(g,"_resize",dojo.hitch(this,"_resetGridHeight"));
this._originalResize=dojo.hitch(g,"resize");
g.resize=function(_ef8,_ef9){
self._changeSize=g._pendingChangeSize=_ef8;
self._resultSize=g._pendingResultSize=_ef9;
g.sizeChange();
};
this._placeSelf();
},destroy:function(){
this.inherited(arguments);
this.grid.focus.removeArea("pagination"+this.position.toLowerCase());
if(this._gotoPageDialog){
this._gotoPageDialog.destroy();
dojo.destroy(this.gotoPageTd);
delete this.gotoPageTd;
delete this._gotoPageDialog;
}
this.grid.resize=this._originalResize;
this.pageSizes=null;
},update:function(){
this.currentPageSize=this.plugin._pageSize;
this._maxItemSize=this.plugin._maxSize;
this._updateDescription();
this._updatePageStepper();
this._updateSizeSwitch();
this._updateGotoButton();
},_setWidthValue:function(){
var type=["description","sizeSwitch","pageStepper"];
var _efa=function(str1,str2){
var reg=new RegExp(str2+"$");
return reg.test(str1);
};
dojo.forEach(type,function(t){
var _efb,flag=this[t];
if(flag===undefined||typeof flag==="boolean"){
return;
}
if(dojo.isString(flag)){
_efb=_efa(flag,"px")||_efa(flag,"%")||_efa(flag,"em")?flag:parseInt(flag,10)>0?parseInt(flag,10)+"px":null;
}else{
if(typeof flag==="number"&&flag>0){
_efb=flag+"px";
}
}
this[t]=_efb?true:false;
this[t+"Width"]=_efb;
},this);
},_regFocusMgr:function(_efc){
this.grid.focus.addArea({name:"pagination"+_efc,onFocus:dojo.hitch(this,this._onFocusPaginator),onBlur:dojo.hitch(this,this._onBlurPaginator),onMove:dojo.hitch(this,this._moveFocus),onKeyDown:dojo.hitch(this,this._onKeyDown)});
switch(_efc){
case "top":
this.grid.focus.placeArea("pagination"+_efc,"before","header");
break;
case "bottom":
default:
this.grid.focus.placeArea("pagination"+_efc,"after","content");
break;
}
},_placeSelf:function(){
var g=this.grid;
var _efd=dojo.trim(this.position.toLowerCase());
switch(_efd){
case "top":
this.placeAt(g.viewsHeaderNode,"before");
this._regFocusMgr("top");
break;
case "bottom":
default:
this.placeAt(g.viewsNode,"after");
this._regFocusMgr("bottom");
break;
}
},_resetGridHeight:function(_efe,_eff){
var g=this.grid;
_efe=_efe||this._changeSize;
_eff=_eff||this._resultSize;
delete this._changeSize;
delete this._resultSize;
if(g._autoHeight){
return;
}
var _f00=g._getPadBorder().h;
if(!this.plugin.gh){
this.plugin.gh=dojo.contentBox(g.domNode).h+2*_f00;
}
if(_eff){
_efe=_eff;
}
if(_efe){
this.plugin.gh=dojo.contentBox(g.domNode).h+2*_f00;
}
var gh=this.plugin.gh,hh=g._getHeaderHeight(),ph=dojo.marginBox(this.domNode).h;
ph=this.plugin.paginators[1]?ph*2:ph;
if(typeof g.autoHeight==="number"){
var cgh=gh+ph-_f00;
dojo.style(g.domNode,"height",cgh+"px");
dojo.style(g.viewsNode,"height",(cgh-ph-hh)+"px");
this._styleMsgNode(hh,dojo.marginBox(g.viewsNode).w,cgh-ph-hh);
}else{
var h=gh-ph-hh-_f00;
dojo.style(g.viewsNode,"height",h+"px");
var _f01=dojo.some(g.views.views,function(v){
return v.hasHScrollbar();
});
dojo.forEach(g.viewsNode.childNodes,function(c){
dojo.style(c,"height",h+"px");
});
dojo.forEach(g.views.views,function(v){
if(v.scrollboxNode){
if(!v.hasHScrollbar()&&_f01){
dojo.style(v.scrollboxNode,"height",(h-dojox.html.metrics.getScrollbar().h)+"px");
}else{
dojo.style(v.scrollboxNode,"height",h+"px");
}
}
});
this._styleMsgNode(hh,dojo.marginBox(g.viewsNode).w,h);
}
},_styleMsgNode:function(top,_f02){
var _f03=this.grid.messagesNode;
dojo.style(_f03,{position:"absolute",top:top+"px",zIndex:"100"});
dojo.marginBox(_f03,{w:_f02});
},_updateDescription:function(){
if(this.description&&this.descriptionDiv){
var p=this.plugin,nls=p.nls,s=p.forcePageStoreLayer,_f04=this.descEmptyTemplate||nls.descEmptyTemplate;
if(this._maxItemSize>0){
var all=p.showAll?"All":"",_f05=this._maxItemSize==1?"Single":"",attr=["desc",_f05,all,"Template"].join("");
_f04=this[attr]||nls[attr];
}
this.descriptionDiv.innerHTML=dojo.string.substitute(_f04,[this._maxItemSize,s.startIdx+1,s.endIdx+1]);
}
if(this.descriptionWidth){
dojo.style(this.descriptionTd,"width",this.descriptionWidth);
}
},_updateSizeSwitch:function(){
if(!this.sizeSwitchTd){
return;
}
if(!this.sizeSwitch||this._maxItemSize<=0){
dojo.style(this.sizeSwitchTd,"display","none");
return;
}else{
dojo.style(this.sizeSwitchTd,"display","");
}
if(this.sizeSwitchTd.childNodes.length<1){
this._createSizeSwitchNodes();
}
this._updateSwitchNodeClass();
this._moveToNextActivableNode(this._getAllPageSizeNodes(),this.pageSizeValue);
this.pageSizeValue=null;
},_createSizeSwitchNodes:function(){
var node=null;
if(!this.pageSizes||this.pageSizes.length<1){
return;
}
dojo.forEach(this.pageSizes,function(size){
var _f06=size==this.plugin.nls.all?this.plugin.nls.allItemsLabelTemplate:dojo.string.substitute(this.plugin.nls.pageSizeLabelTemplate,[size]);
node=dojo.create("span",{innerHTML:size,title:_f06,value:size,tabindex:-1,role:"button"},this.sizeSwitchTd,"last");
node.setAttribute("aria-label",_f06);
this.plugin.connect(node,"onclick",dojo.hitch(this,"_onSwitchPageSize"));
this.plugin.connect(node,"onmouseover",function(e){
dojo.addClass(e.target,"dojoxGridPageTextHover");
});
this.plugin.connect(node,"onmouseout",function(e){
dojo.removeClass(e.target,"dojoxGridPageTextHover");
});
node=dojo.create("span",{innerHTML:"|"},this.sizeSwitchTd,"last");
dojo.addClass(node,"dojoxGridSeparator");
},this);
dojo.destroy(node);
if(this.sizeSwitchWidth){
dojo.style(this.sizeSwitchTd,"width",this.sizeSwitchWidth);
}
},_updateSwitchNodeClass:function(){
var size=null;
var _f07=false;
var _f08=function(node,_f09){
if(_f09){
dojo.addClass(node,"dojoxGridActivedSwitch");
dojo.removeAttr(node,"tabindex");
_f07=true;
}else{
dojo.addClass(node,"dojoxGridInactiveSwitch");
dojo.attr(node,"tabindex","-1");
}
};
dojo.forEach(this.sizeSwitchTd.childNodes,function(node){
if(node.value){
size=node.value;
dojo.removeClass(node);
if(this.plugin._pageSizeValue){
_f08(node,size===this.plugin._pageSizeValue&&!_f07);
}else{
if(size==this.plugin.nls.all){
size=this._maxItemSize;
}
_f08(node,this.currentPageSize===parseInt(size,10)&&!_f07);
}
}
},this);
},_updatePageStepper:function(){
if(!this.pageStepperTd){
return;
}
if(!this.pageStepper||this._maxItemSize<=0){
dojo.style(this.pageStepperTd,"display","none");
return;
}else{
dojo.style(this.pageStepperTd,"display","");
}
if(this.pageStepperDiv.childNodes.length<1){
this._createPageStepNodes();
this._createWardBtns();
}else{
this._resetPageStepNodes();
}
this._updatePageStepNodeClass();
this._moveToNextActivableNode(this._getAllPageStepNodes(),this.pageStepValue);
this.pageStepValue=null;
},_createPageStepNodes:function(){
var _f0a=this._getStartPage(),_f0b=this._getStepPageSize(),_f0c="",node=null,i=_f0a;
for(;i<_f0a+this.maxPageStep+1;i++){
_f0c=dojo.string.substitute(this.plugin.nls.pageStepLabelTemplate,[i]);
node=dojo.create("div",{innerHTML:i,value:i,title:_f0c,role:"button"},this.pageStepperDiv,"last");
if(i<_f0a+_f0b){
dojo.attr(node,"tabindex","-1");
}
node.setAttribute("aria-label",_f0c);
this.plugin.connect(node,"onclick",dojo.hitch(this,"_onPageStep"));
this.plugin.connect(node,"onmouseover",function(e){
dojo.addClass(e.target,"dojoxGridPageTextHover");
});
this.plugin.connect(node,"onmouseout",function(e){
dojo.removeClass(e.target,"dojoxGridPageTextHover");
});
dojo.style(node,"display",i<_f0a+_f0b?"block":"none");
}
if(this.pageStepperWidth){
dojo.style(this.pageStepperTd,"width",this.pageStepperWidth);
}
},_createWardBtns:function(){
var self=this;
var _f0d={prevPage:"&#60;",firstPage:"&#171;",nextPage:"&#62;",lastPage:"&#187;"};
var _f0e=function(_f0f,_f10,_f11){
var node=dojo.create("div",{value:_f0f,title:_f10,tabindex:-1,role:"button"},self.pageStepperDiv,_f11);
self.plugin.connect(node,"onclick",dojo.hitch(self,"_onPageStep"));
node.setAttribute("aria-label",_f10);
var _f12=dojo.create("span",{value:_f0f,title:_f10,innerHTML:_f0d[_f0f]},node,_f11);
dojo.addClass(_f12,"dojoxGridWardButtonInner");
};
_f0e("prevPage",this.plugin.nls.prevTip,"first");
_f0e("firstPage",this.plugin.nls.firstTip,"first");
_f0e("nextPage",this.plugin.nls.nextTip,"last");
_f0e("lastPage",this.plugin.nls.lastTip,"last");
},_resetPageStepNodes:function(){
var _f13=this._getStartPage(),_f14=this._getStepPageSize(),_f15=this.pageStepperDiv.childNodes,node=null,i=_f13,j=2,tip;
for(;j<_f15.length-2;j++,i++){
node=_f15[j];
if(i<_f13+_f14){
tip=dojo.string.substitute(this.plugin.nls.pageStepLabelTemplate,[i]);
dojo.attr(node,{"innerHTML":i,"title":tip,"value":i});
dojo.style(node,"display","block");
node.setAttribute("aria-label",tip);
}else{
dojo.style(node,"display","none");
}
}
},_updatePageStepNodeClass:function(){
var _f16=null,_f17=this._getCurrentPageNo(),_f18=this._getPageCount();
var _f19=function(node,_f1a,_f1b){
var _f1c=node.value,_f1d=_f1a?"dojoxGrid"+_f1c+"Btn":"dojoxGridInactived",_f1e=_f1a?"dojoxGrid"+_f1c+"BtnDisable":"dojoxGridActived";
if(_f1b){
dojo.addClass(node,_f1e);
dojo.removeAttr(node,"tabindex");
}else{
dojo.addClass(node,_f1d);
dojo.attr(node,"tabindex","-1");
}
};
dojo.forEach(this.pageStepperDiv.childNodes,function(node){
dojo.removeClass(node);
if(isNaN(parseInt(node.value,10))){
dojo.addClass(node,"dojoxGridWardButton");
var _f1f=node.value=="prevPage"||node.value=="firstPage"?1:_f18;
_f19(node,true,(_f17===_f1f));
}else{
_f16=parseInt(node.value,10);
_f19(node,false,(_f16===_f17||dojo.style(node,"display")==="none"));
}
},this);
},_showGotoButton:function(flag){
this.gotoButton=flag;
this._updateGotoButton();
},_updateGotoButton:function(){
if(!this.gotoButton){
if(this.gotoPageTd){
if(this._gotoPageDialog){
this._gotoPageDialog.destroy();
}
dojo.destroy(this.gotoPageDiv);
dojo.destroy(this.gotoPageTd);
delete this.gotoPageDiv;
delete this.gotoPageTd;
}
return;
}
if(!this.gotoPageTd){
this._createGotoNode();
}
dojo.toggleClass(this.gotoPageDiv,"dojoxGridPaginatorGotoDivDisabled",this.plugin._pageSize>=this.plugin._maxSize);
if(this.plugin._pageSize>=this.plugin._maxSize){
dojo.removeAttr(this.gotoPageDiv,"tabindex");
}else{
dojo.attr(this.gotoPageDiv,"tabindex","-1");
}
},_createGotoNode:function(){
this.gotoPageTd=dojo.create("td",{},dojo.query("tr",this.domNode)[0],"last");
dojo.addClass(this.gotoPageTd,"dojoxGridPaginatorGotoTd");
this.gotoPageDiv=dojo.create("div",{tabindex:"-1",title:this.plugin.nls.gotoButtonTitle},this.gotoPageTd,"first");
dojo.addClass(this.gotoPageDiv,"dojoxGridPaginatorGotoDiv");
this.plugin.connect(this.gotoPageDiv,"onclick",dojo.hitch(this,"_openGotopageDialog"));
var _f20=dojo.create("span",{title:this.plugin.nls.gotoButtonTitle,innerHTML:"&#8869;"},this.gotoPageDiv,"last");
dojo.addClass(_f20,"dojoxGridWardButtonInner");
},_openGotopageDialog:function(_f21){
if(this._getPageCount()<=1){
return;
}
if(!this._gotoPageDialog){
this._gotoPageDialog=new dojox.grid.enhanced.plugins.pagination._GotoPageDialog(this.plugin);
}
if(!this._currentFocusNode){
this.grid.focus.focusArea("pagination"+this.position,_f21);
}else{
this._currentFocusNode=this.gotoPageDiv;
}
if(this.focusArea!="pageStep"){
this.focusArea="pageStep";
}
this._gotoPageDialog.updatePageCount();
this._gotoPageDialog.showDialog();
},_onFocusPaginator:function(_f22,step){
if(step==0&&this._currentFocusNode){
this._currentFocusNode.focus();
this.plugin._stopEvent(_f22);
return true;
}else{
if(!this._currentFocusNode){
if(step>0){
return this._onFocusPageSizeNode(_f22)?true:this._onFocusPageStepNode(_f22);
}else{
if(step<0){
return this._onFocusPageStepNode(_f22)?true:this._onFocusPageSizeNode(_f22);
}else{
return false;
}
}
}else{
if(step>0){
return this.focusArea==="pageSize"?this._onFocusPageStepNode(_f22):false;
}else{
if(step<0){
return this.focusArea==="pageStep"?this._onFocusPageSizeNode(_f22):false;
}else{
return false;
}
}
}
}
},_onFocusPageSizeNode:function(_f23){
var _f24=this._getPageSizeActivableNodes();
if(_f23&&_f23.type!=="click"){
if(_f24[0]){
_f24[0].focus();
this._currentFocusNode=_f24[0];
this.focusArea="pageSize";
this.plugin._stopEvent(_f23);
return true;
}else{
return false;
}
}
if(_f23&&_f23.type=="click"){
if(dojo.indexOf(this._getPageSizeActivableNodes(),_f23.target)>-1){
this.focusArea="pageSize";
this.plugin._stopEvent(_f23);
return true;
}
}
return false;
},_onFocusPageStepNode:function(_f25){
var _f26=this._getPageStepActivableNodes();
if(_f25&&_f25.type!=="click"){
if(_f26[0]){
_f26[0].focus();
this._currentFocusNode=_f26[0];
this.focusArea="pageStep";
this.plugin._stopEvent(_f25);
return true;
}else{
if(this.gotoPageDiv){
this.gotoPageDiv.focus();
this._currentFocusNode=this.gotoPageDiv;
this.focusArea="pageStep";
this.plugin._stopEvent(_f25);
return true;
}else{
return false;
}
}
}
if(_f25&&_f25.type=="click"){
if(dojo.indexOf(this._getPageStepActivableNodes(),_f25.target)>-1){
this.focusArea="pageStep";
this.plugin._stopEvent(_f25);
return true;
}else{
if(_f25.target===this.gotoPageDiv){
this.gotoPageDiv.focus();
this._currentFocusNode=this.gotoPageDiv;
this.focusArea="pageStep";
this.plugin._stopEvent(_f25);
return true;
}
}
}
return false;
},_onFocusGotoPageNode:function(_f27){
if(!this.gotoButton||!this.gotoPageTd){
return false;
}
if(_f27&&_f27.type!=="click"||(_f27.type=="click"&&_f27.target==this.gotoPageDiv)){
this.gotoPageDiv.focus();
this._currentFocusNode=this.gotoPageDiv;
this.focusArea="gotoButton";
this.plugin._stopEvent(_f27);
return true;
}
return true;
},_onBlurPaginator:function(_f28,step){
var _f29=this._getPageSizeActivableNodes(),_f2a=this._getPageStepActivableNodes();
if(step>0&&this.focusArea==="pageSize"&&(_f2a.length>1||this.gotoButton)){
return false;
}else{
if(step<0&&this.focusArea==="pageStep"&&_f29.length>1){
return false;
}
}
this._currentFocusNode=null;
this.focusArea=null;
return true;
},_onKeyDown:function(_f2b,_f2c){
if(_f2c){
return;
}
if(_f2b.altKey||_f2b.metaKey){
return;
}
var dk=dojo.keys;
if(_f2b.keyCode===dk.ENTER||_f2b.keyCode===dk.SPACE){
if(dojo.indexOf(this._getPageStepActivableNodes(),this._currentFocusNode)>-1){
this._onPageStep(_f2b);
}else{
if(dojo.indexOf(this._getPageSizeActivableNodes(),this._currentFocusNode)>-1){
this._onSwitchPageSize(_f2b);
}else{
if(this._currentFocusNode===this.gotoPageDiv){
this._openGotopageDialog(_f2b);
}
}
}
}
this.plugin._stopEvent(_f2b);
},_moveFocus:function(_f2d,_f2e,evt){
var _f2f;
if(this.focusArea=="pageSize"){
_f2f=this._getPageSizeActivableNodes();
}else{
if(this.focusArea=="pageStep"){
_f2f=this._getPageStepActivableNodes();
if(this.gotoPageDiv){
_f2f.push(this.gotoPageDiv);
}
}
}
if(_f2f.length<1){
return;
}
var _f30=dojo.indexOf(_f2f,this._currentFocusNode);
var _f31=_f30+_f2e;
if(_f31>=0&&_f31<_f2f.length){
_f2f[_f31].focus();
this._currentFocusNode=_f2f[_f31];
}
this.plugin._stopEvent(evt);
},_getPageSizeActivableNodes:function(){
return dojo.query("span[tabindex='-1']",this.sizeSwitchTd);
},_getPageStepActivableNodes:function(){
return (dojo.query("div[tabindex='-1']",this.pageStepperDiv));
},_getAllPageSizeNodes:function(){
var _f32=[];
dojo.forEach(this.sizeSwitchTd.childNodes,function(node){
if(node.value){
_f32.push(node);
}
});
return _f32;
},_getAllPageStepNodes:function(){
var _f33=[],i=0,len=this.pageStepperDiv.childNodes.length;
for(;i<len;i++){
_f33.push(this.pageStepperDiv.childNodes[i]);
}
return _f33;
},_moveToNextActivableNode:function(_f34,_f35){
if(!_f35){
return;
}
if(_f34.length<2){
this.grid.focus.tab(1);
return;
}
var nl=[],node=null,_f36=0;
dojo.forEach(_f34,function(n){
if(n.value===_f35){
nl.push(n);
node=n;
}else{
if(dojo.attr(n,"tabindex")=="-1"){
nl.push(n);
}
}
});
if(nl.length<2){
this.grid.focus.tab(1);
return;
}
_f36=dojo.indexOf(nl,node);
if(dojo.attr(node,"tabindex")!="-1"){
node=nl[_f36+1]?nl[_f36+1]:nl[_f36-1];
}
node.focus();
this._currentFocusNode=node;
},_onSwitchPageSize:function(e){
var size=this.plugin._pageSizeValue=this.pageSizeValue=e.target.value;
if(!size){
return;
}
if(size==this.plugin.nls.all){
size=-1;
}else{
size=parseInt(size,10);
if(isNaN(size)||size<=0){
return;
}
}
if(!this._currentFocusNode){
this.grid.focus.currentArea("pagination"+this.position);
}
if(this.focusArea!="pageSize"){
this.focusArea="pageSize";
}
this.plugin.changePageSize(size);
},_onPageStep:function(e){
var p=this.plugin,_f37=this.pageStepValue=e.target.value;
if(!this._currentFocusNode){
this.grid.focus.currentArea("pagination"+this.position);
}
if(this.focusArea!="pageStep"){
this.focusArea="pageStep";
}
if(!isNaN(parseInt(_f37,10))){
p.gotoPage(_f37);
}else{
switch(e.target.value){
case "prevPage":
p.prevPage();
break;
case "nextPage":
p.nextPage();
break;
case "firstPage":
p.gotoFirstPage();
break;
case "lastPage":
p.gotoLastPage();
}
}
},_getCurrentPageNo:function(){
return this.plugin._currentPage+1;
},_getPageCount:function(){
if(!this._maxItemSize||!this.currentPageSize){
return 0;
}
return Math.ceil(this._maxItemSize/this.currentPageSize);
},_getStartPage:function(){
var cp=this._getCurrentPageNo();
var ms=parseInt(this.maxPageStep/2,10);
var pc=this._getPageCount();
if(cp<ms||(cp-ms)<1){
return 1;
}else{
if(pc<=this.maxPageStep){
return 1;
}else{
if(pc-cp<ms&&cp-this.maxPageStep>=0){
return pc-this.maxPageStep+1;
}else{
return (cp-ms);
}
}
}
},_getStepPageSize:function(){
var sp=this._getStartPage();
var _f38=this._getPageCount();
if((sp+this.maxPageStep)>_f38){
return _f38-sp+1;
}else{
return this.maxPageStep;
}
}});
dojo.declare("dojox.grid.enhanced.plugins.pagination._GotoPageDialog",null,{pageCount:0,constructor:function(_f39){
this.plugin=_f39;
this.pageCount=this.plugin.paginators[0]._getPageCount();
this._dialogNode=dojo.create("div",{},dojo.body(),"last");
this._gotoPageDialog=new dojox.grid.enhanced.plugins.Dialog({"refNode":_f39.grid.domNode,"title":this.plugin.nls.dialogTitle},this._dialogNode);
this._createDialogContent();
this._gotoPageDialog.startup();
},_createDialogContent:function(){
this._specifyNode=dojo.create("div",{innerHTML:this.plugin.nls.dialogIndication},this._gotoPageDialog.containerNode,"last");
this._pageInputDiv=dojo.create("div",{},this._gotoPageDialog.containerNode,"last");
this._pageTextBox=new dijit.form.NumberTextBox();
this._pageTextBox.constraints={fractional:false,min:1,max:this.pageCount};
this.plugin.connect(this._pageTextBox.textbox,"onkeyup",dojo.hitch(this,"_setConfirmBtnState"));
this._pageInputDiv.appendChild(this._pageTextBox.domNode);
this._pageLabel=dojo.create("label",{innerHTML:dojo.string.substitute(this.plugin.nls.pageCountIndication,[this.pageCount])},this._pageInputDiv,"last");
this._buttonDiv=dojo.create("div",{},this._gotoPageDialog.containerNode,"last");
this._confirmBtn=new dijit.form.Button({label:this.plugin.nls.dialogConfirm,onClick:dojo.hitch(this,this._onConfirm)});
this._confirmBtn.set("disabled",true);
this._cancelBtn=new dijit.form.Button({label:this.plugin.nls.dialogCancel,onClick:dojo.hitch(this,this._onCancel)});
this._buttonDiv.appendChild(this._confirmBtn.domNode);
this._buttonDiv.appendChild(this._cancelBtn.domNode);
this._styleContent();
this._gotoPageDialog.onCancel=dojo.hitch(this,this._onCancel);
this.plugin.connect(this._gotoPageDialog,"_onKey",dojo.hitch(this,"_onKeyDown"));
},_styleContent:function(){
dojo.addClass(this._specifyNode,"dojoxGridDialogMargin");
dojo.addClass(this._pageInputDiv,"dojoxGridDialogMargin");
dojo.addClass(this._buttonDiv,"dojoxGridDialogButton");
dojo.style(this._pageTextBox.domNode,"width","50px");
},updatePageCount:function(){
this.pageCount=this.plugin.paginators[0]._getPageCount();
this._pageTextBox.constraints={fractional:false,min:1,max:this.pageCount};
dojo.attr(this._pageLabel,"innerHTML",dojo.string.substitute(this.plugin.nls.pageCountIndication,[this.pageCount]));
},showDialog:function(){
this._gotoPageDialog.show();
},_onConfirm:function(_f3a){
if(this._pageTextBox.isValid()&&this._pageTextBox.getDisplayedValue()!==""){
this.plugin.gotoPage(this._pageTextBox.parse(this._pageTextBox.getDisplayedValue()));
this._gotoPageDialog.hide();
this._pageTextBox.reset();
}
this.plugin._stopEvent(_f3a);
},_onCancel:function(_f3b){
this._pageTextBox.reset();
this._gotoPageDialog.hide();
this.plugin._stopEvent(_f3b);
},_onKeyDown:function(_f3c){
if(_f3c.altKey||_f3c.metaKey){
return;
}
var dk=dojo.keys;
if(_f3c.keyCode===dk.ENTER){
this._onConfirm(_f3c);
}
},_setConfirmBtnState:function(){
if(this._pageTextBox.isValid()&&this._pageTextBox.getDisplayedValue()!==""){
this._confirmBtn.set("disabled",false);
}else{
this._confirmBtn.set("disabled",true);
}
},destroy:function(){
this._pageTextBox.destroy();
this._confirmBtn.destroy();
this._cancelBtn.destroy();
this._gotoPageDialog.destroy();
dojo.destroy(this._specifyNode);
dojo.destroy(this._pageInputDiv);
dojo.destroy(this._pageLabel);
dojo.destroy(this._buttonDiv);
dojo.destroy(this._dialogNode);
}});
dojox.grid.EnhancedGrid.registerPlugin(dojox.grid.enhanced.plugins.Pagination);
}
if(!dojo._hasResource["dojoe.mapping"]){
dojo._hasResource["dojoe.mapping"]=true;
dojo.provide("dojoe.mapping");
dojo.provide("dojoe.table.plugins.GridFilter");
dojo.provide("dojoe.table.plugins.IndirectSelection");
dojo.provide("dojoe.table.plugins.NestedSorting");
dojo.provide("dojoe.table.plugins.Menu");
dojo.provide("dojoe.table.plugins.DnD");
dojo.provide("dojoe.table.plugins.AutoScroll");
dojo.provide("dojoe.table.plugins.Selector");
dojo.provide("dojoe.table.plugins.Cookie");
dojo.provide("dojoe.table.plugins.GridSource");
dojo.provide("dojoe.table.plugins.Search");
dojo.provide("dojoe.table.plugins.exporter.CSVWriter");
dojo.provide("dojoe.table.plugins.Printer");
dojo.provide("dojoe.table.plugins.Pagination");
(function(){
dojo.setObject("dojoe.table.plugins.GridFilter",dojox.grid.enhanced.plugins.Filter);
dojo.setObject("dojoe.table.plugins.IndirectSelection",dojox.grid.enhanced.plugins.IndirectSelection);
dojo.setObject("dojoe.table.plugins.NestedSorting",dojox.grid.enhanced.plugins.NestedSorting);
dojo.setObject("dojoe.table.plugins.Menu",dojox.grid.enhanced.plugins.Menu);
dojo.setObject("dojoe.table.plugins.DnD",dojox.grid.enhanced.plugins.DnD);
dojo.setObject("dojoe.table.plugins.AutoScroll",dojox.grid.enhanced.plugins.AutoScroll);
dojo.setObject("dojoe.table.plugins.Selector",dojox.grid.enhanced.plugins.Selector);
dojo.setObject("dojoe.table.plugins.Cookie",dojox.grid.enhanced.plugins.Cookie);
dojo.setObject("dojoe.table.plugins.GridSource",dojox.grid.enhanced.plugins.GridSource);
dojo.setObject("dojoe.table.plugins.CellFormatter",dojox.grid.enhanced.plugins.CellFormatter);
dojo.setObject("dojoe.table.plugins.Search",dojox.grid.enhanced.plugins.Search);
dojo.setObject("dojoe.table.plugins.exporter.CSVWriter",dojox.grid.enhanced.plugins.exporter.CSVWriter);
dojo.setObject("dojoe.table.plugins.Printer",dojox.grid.enhanced.plugins.Printer);
dojo.setObject("dojoe.table.plugins.Pagination",dojox.grid.enhanced.plugins.Pagination);
})();
}
if(!dojo._hasResource["dijit.form.SimpleTextarea"]){
dojo._hasResource["dijit.form.SimpleTextarea"]=true;
dojo.provide("dijit.form.SimpleTextarea");
dojo.declare("dijit.form.SimpleTextarea",dijit.form.TextBox,{baseClass:"dijitTextBox dijitTextArea",attributeMap:dojo.delegate(dijit.form._FormValueWidget.prototype.attributeMap,{rows:"textbox",cols:"textbox"}),rows:"3",cols:"20",templateString:"<textarea ${!nameAttrSetting} dojoAttachPoint='focusNode,containerNode,textbox' autocomplete='off'></textarea>",postMixInProperties:function(){
if(!this.value&&this.srcNodeRef){
this.value=this.srcNodeRef.value;
}
this.inherited(arguments);
},buildRendering:function(){
this.inherited(arguments);
if(dojo.isIE&&this.cols){
dojo.addClass(this.textbox,"dijitTextAreaCols");
}
},filter:function(_f3d){
if(_f3d){
_f3d=_f3d.replace(/\r/g,"");
}
return this.inherited(arguments);
},_previousValue:"",_onInput:function(e){
if(this.maxLength){
var _f3e=parseInt(this.maxLength);
var _f3f=this.textbox.value.replace(/\r/g,"");
var _f40=_f3f.length-_f3e;
if(_f40>0){
if(e){
dojo.stopEvent(e);
}
var _f41=this.textbox;
if(_f41.selectionStart){
var pos=_f41.selectionStart;
var cr=0;
if(dojo.isOpera){
cr=(this.textbox.value.substring(0,pos).match(/\r/g)||[]).length;
}
this.textbox.value=_f3f.substring(0,pos-_f40-cr)+_f3f.substring(pos-cr);
_f41.setSelectionRange(pos-_f40,pos-_f40);
}else{
if(dojo.doc.selection){
_f41.focus();
var _f42=dojo.doc.selection.createRange();
_f42.moveStart("character",-_f40);
_f42.text="";
_f42.select();
}
}
}
this._previousValue=this.textbox.value;
}
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.form.Form"]){
dojo._hasResource["dijit.form.Form"]=true;
dojo.provide("dijit.form.Form");
dojo.declare("dijit.form.Form",[dijit._Widget,dijit._Templated,dijit.form._FormMixin,dijit.layout._ContentPaneResizeMixin],{name:"",action:"",method:"",encType:"","accept-charset":"",accept:"",target:"",templateString:"<form dojoAttachPoint='containerNode' dojoAttachEvent='onreset:_onReset,onsubmit:_onSubmit' ${!nameAttrSetting}></form>",attributeMap:dojo.delegate(dijit._Widget.prototype.attributeMap,{action:"",method:"",encType:"","accept-charset":"",accept:"",target:""}),postMixInProperties:function(){
this.nameAttrSetting=this.name?("name='"+this.name+"'"):"";
this.inherited(arguments);
},execute:function(_f43){
},onExecute:function(){
},_setEncTypeAttr:function(_f44){
this.encType=_f44;
dojo.attr(this.domNode,"encType",_f44);
if(dojo.isIE){
this.domNode.encoding=_f44;
}
},postCreate:function(){
if(dojo.isIE&&this.srcNodeRef&&this.srcNodeRef.attributes){
var item=this.srcNodeRef.attributes.getNamedItem("encType");
if(item&&!item.specified&&(typeof item.value=="string")){
this.set("encType",item.value);
}
}
this.inherited(arguments);
},reset:function(e){
var faux={returnValue:true,preventDefault:function(){
this.returnValue=false;
},stopPropagation:function(){
},currentTarget:e?e.target:this.domNode,target:e?e.target:this.domNode};
if(!(this.onReset(faux)===false)&&faux.returnValue){
this.inherited(arguments,[]);
}
},onReset:function(e){
return true;
},_onReset:function(e){
this.reset(e);
dojo.stopEvent(e);
return false;
},_onSubmit:function(e){
var fp=dijit.form.Form.prototype;
if(this.execute!=fp.execute||this.onExecute!=fp.onExecute){
dojo.deprecated("dijit.form.Form:execute()/onExecute() are deprecated. Use onSubmit() instead.","","2.0");
this.onExecute();
this.execute(this.getValues());
}
if(this.onSubmit(e)===false){
dojo.stopEvent(e);
}
},onSubmit:function(e){
return this.isValid();
},submit:function(){
if(!(this.onSubmit()===false)){
this.containerNode.submit();
}
}});
}
if(!dojo._hasResource["dijit.layout._TabContainerBase"]){
dojo._hasResource["dijit.layout._TabContainerBase"]=true;
dojo.provide("dijit.layout._TabContainerBase");
dojo.declare("dijit.layout._TabContainerBase",[dijit.layout.StackContainer,dijit._Templated],{tabPosition:"top",baseClass:"dijitTabContainer",tabStrip:false,nested:false,templateString:dojo.cache("dijit.layout","templates/TabContainer.html","<div class=\"dijitTabContainer\">\r\n\t<div class=\"dijitTabListWrapper\" dojoAttachPoint=\"tablistNode\"></div>\r\n\t<div dojoAttachPoint=\"tablistSpacer\" class=\"dijitTabSpacer ${baseClass}-spacer\"></div>\r\n\t<div class=\"dijitTabPaneWrapper ${baseClass}-container\" dojoAttachPoint=\"containerNode\"></div>\r\n</div>\r\n"),postMixInProperties:function(){
this.baseClass+=this.tabPosition.charAt(0).toUpperCase()+this.tabPosition.substr(1).replace(/-.*/,"");
this.srcNodeRef&&dojo.style(this.srcNodeRef,"visibility","hidden");
this.inherited(arguments);
},buildRendering:function(){
this.inherited(arguments);
this.tablist=this._makeController(this.tablistNode);
if(!this.doLayout){
dojo.addClass(this.domNode,"dijitTabContainerNoLayout");
}
if(this.nested){
dojo.addClass(this.domNode,"dijitTabContainerNested");
dojo.addClass(this.tablist.containerNode,"dijitTabContainerTabListNested");
dojo.addClass(this.tablistSpacer,"dijitTabContainerSpacerNested");
dojo.addClass(this.containerNode,"dijitTabPaneWrapperNested");
}else{
dojo.addClass(this.domNode,"tabStrip-"+(this.tabStrip?"enabled":"disabled"));
}
},_setupChild:function(tab){
dojo.addClass(tab.domNode,"dijitTabPane");
this.inherited(arguments);
},startup:function(){
if(this._started){
return;
}
this.tablist.startup();
this.inherited(arguments);
},layout:function(){
if(!this._contentBox||typeof (this._contentBox.l)=="undefined"){
return;
}
var sc=this.selectedChildWidget;
if(this.doLayout){
var _f45=this.tabPosition.replace(/-h/,"");
this.tablist.layoutAlign=_f45;
var _f46=[this.tablist,{domNode:this.tablistSpacer,layoutAlign:_f45},{domNode:this.containerNode,layoutAlign:"client"}];
dijit.layout.layoutChildren(this.domNode,this._contentBox,_f46);
this._containerContentBox=dijit.layout.marginBox2contentBox(this.containerNode,_f46[2]);
if(sc&&sc.resize){
sc.resize(this._containerContentBox);
}
}else{
if(this.tablist.resize){
var s=this.tablist.domNode.style;
s.width="0";
var _f47=dojo.contentBox(this.domNode).w;
s.width="";
this.tablist.resize({w:_f47});
}
if(sc&&sc.resize){
sc.resize();
}
}
},destroy:function(){
if(this.tablist){
this.tablist.destroy();
}
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.layout.TabController"]){
dojo._hasResource["dijit.layout.TabController"]=true;
dojo.provide("dijit.layout.TabController");
dojo.declare("dijit.layout.TabController",dijit.layout.StackController,{templateString:"<div role='tablist' dojoAttachEvent='onkeypress:onkeypress'></div>",tabPosition:"top",buttonWidget:"dijit.layout._TabButton",_rectifyRtlTabList:function(){
if(0>=this.tabPosition.indexOf("-h")){
return;
}
if(!this.pane2button){
return;
}
var _f48=0;
for(var pane in this.pane2button){
var ow=this.pane2button[pane].innerDiv.scrollWidth;
_f48=Math.max(_f48,ow);
}
for(pane in this.pane2button){
this.pane2button[pane].innerDiv.style.width=_f48+"px";
}
}});
dojo.declare("dijit.layout._TabButton",dijit.layout._StackButton,{baseClass:"dijitTab",cssStateNodes:{closeNode:"dijitTabCloseButton"},templateString:dojo.cache("dijit.layout","templates/_TabButton.html","<div role=\"presentation\" dojoAttachPoint=\"titleNode\" dojoAttachEvent='onclick:onClick'>\r\n    <div role=\"presentation\" class='dijitTabInnerDiv' dojoAttachPoint='innerDiv'>\r\n        <div role=\"presentation\" class='dijitTabContent' dojoAttachPoint='tabContent'>\r\n        \t<div role=\"presentation\" dojoAttachPoint='focusNode'>\r\n\t\t        <img src=\"${_blankGif}\" alt=\"\" class=\"dijitIcon dijitTabButtonIcon\" dojoAttachPoint='iconNode' />\r\n\t\t        <span dojoAttachPoint='containerNode' class='tabLabel'></span>\r\n\t\t        <span class=\"dijitInline dijitTabCloseButton dijitTabCloseIcon\" dojoAttachPoint='closeNode'\r\n\t\t        \t\tdojoAttachEvent='onclick: onClickCloseButton' role=\"presentation\">\r\n\t\t            <span dojoAttachPoint='closeText' class='dijitTabCloseText'>[x]</span\r\n\t\t        ></span>\r\n\t\t\t</div>\r\n        </div>\r\n    </div>\r\n</div>\r\n"),scrollOnFocus:false,buildRendering:function(){
this.inherited(arguments);
dojo.setSelectable(this.containerNode,false);
},startup:function(){
this.inherited(arguments);
var n=this.domNode;
setTimeout(function(){
n.className=n.className;
},1);
},_setCloseButtonAttr:function(disp){
this._set("closeButton",disp);
dojo.toggleClass(this.innerDiv,"dijitClosable",disp);
this.closeNode.style.display=disp?"":"none";
if(disp){
var _f49=dojo.i18n.getLocalization("dijit","common");
if(this.closeNode){
dojo.attr(this.closeNode,"title",_f49.itemClose);
}
var _f49=dojo.i18n.getLocalization("dijit","common");
this._closeMenu=new dijit.Menu({id:this.id+"_Menu",dir:this.dir,lang:this.lang,targetNodeIds:[this.domNode]});
this._closeMenu.addChild(new dijit.MenuItem({label:_f49.itemClose,dir:this.dir,lang:this.lang,onClick:dojo.hitch(this,"onClickCloseButton")}));
}else{
if(this._closeMenu){
this._closeMenu.destroyRecursive();
delete this._closeMenu;
}
}
},_setLabelAttr:function(_f4a){
this.inherited(arguments);
if(this.showLabel==false&&!this.params.title){
this.iconNode.alt=dojo.trim(this.containerNode.innerText||this.containerNode.textContent||"");
}
},destroy:function(){
if(this._closeMenu){
this._closeMenu.destroyRecursive();
delete this._closeMenu;
}
this.inherited(arguments);
}});
}
if(!dojo._hasResource["dijit.layout.ScrollingTabController"]){
dojo._hasResource["dijit.layout.ScrollingTabController"]=true;
dojo.provide("dijit.layout.ScrollingTabController");
dojo.declare("dijit.layout.ScrollingTabController",dijit.layout.TabController,{templateString:dojo.cache("dijit.layout","templates/ScrollingTabController.html","<div class=\"dijitTabListContainer-${tabPosition}\" style=\"visibility:hidden\">\r\n\t<div dojoType=\"dijit.layout._ScrollingTabControllerMenuButton\"\r\n\t\t\tclass=\"tabStripButton-${tabPosition}\"\r\n\t\t\tid=\"${id}_menuBtn\" containerId=\"${containerId}\" iconClass=\"dijitTabStripMenuIcon\"\r\n\t\t\tdropDownPosition=\"below-alt, above-alt\"\r\n\t\t\tdojoAttachPoint=\"_menuBtn\" showLabel=\"false\">&#9660;</div>\r\n\t<div dojoType=\"dijit.layout._ScrollingTabControllerButton\"\r\n\t\t\tclass=\"tabStripButton-${tabPosition}\"\r\n\t\t\tid=\"${id}_leftBtn\" iconClass=\"dijitTabStripSlideLeftIcon\"\r\n\t\t\tdojoAttachPoint=\"_leftBtn\" dojoAttachEvent=\"onClick: doSlideLeft\" showLabel=\"false\">&#9664;</div>\r\n\t<div dojoType=\"dijit.layout._ScrollingTabControllerButton\"\r\n\t\t\tclass=\"tabStripButton-${tabPosition}\"\r\n\t\t\tid=\"${id}_rightBtn\" iconClass=\"dijitTabStripSlideRightIcon\"\r\n\t\t\tdojoAttachPoint=\"_rightBtn\" dojoAttachEvent=\"onClick: doSlideRight\" showLabel=\"false\">&#9654;</div>\r\n\t<div class='dijitTabListWrapper' dojoAttachPoint='tablistWrapper'>\r\n\t\t<div role='tablist' dojoAttachEvent='onkeypress:onkeypress'\r\n\t\t\t\tdojoAttachPoint='containerNode' class='nowrapTabStrip'></div>\r\n\t</div>\r\n</div>\r\n"),useMenu:true,useSlider:true,tabStripClass:"",widgetsInTemplate:true,_minScroll:5,attributeMap:dojo.delegate(dijit._Widget.prototype.attributeMap,{"class":"containerNode"}),buildRendering:function(){
this.inherited(arguments);
var n=this.domNode;
this.scrollNode=this.tablistWrapper;
this._initButtons();
if(!this.tabStripClass){
this.tabStripClass="dijitTabContainer"+this.tabPosition.charAt(0).toUpperCase()+this.tabPosition.substr(1).replace(/-.*/,"")+"None";
dojo.addClass(n,"tabStrip-disabled");
}
dojo.addClass(this.tablistWrapper,this.tabStripClass);
},onStartup:function(){
this.inherited(arguments);
dojo.style(this.domNode,"visibility","visible");
this._postStartup=true;
},onAddChild:function(page,_f4b){
this.inherited(arguments);
dojo.forEach(["label","iconClass"],function(attr){
this.pane2watches[page.id].push(this.pane2button[page.id].watch(attr,dojo.hitch(this,function(name,_f4c,_f4d){
if(this._postStartup&&this._dim){
this.resize(this._dim);
}
})));
},this);
dojo.style(this.containerNode,"width",(dojo.style(this.containerNode,"width")+200)+"px");
},onRemoveChild:function(page,_f4e){
var _f4f=this.pane2button[page.id];
if(this._selectedTab===_f4f.domNode){
this._selectedTab=null;
}
this.inherited(arguments);
},_initButtons:function(){
this._btnWidth=0;
this._buttons=dojo.query("> .tabStripButton",this.domNode).filter(function(btn){
if((this.useMenu&&btn==this._menuBtn.domNode)||(this.useSlider&&(btn==this._rightBtn.domNode||btn==this._leftBtn.domNode))){
this._btnWidth+=dojo._getMarginSize(btn).w;
return true;
}else{
dojo.style(btn,"display","none");
return false;
}
},this);
},_getTabsWidth:function(){
var _f50=this.getChildren();
if(_f50.length){
var _f51=_f50[this.isLeftToRight()?0:_f50.length-1].domNode,_f52=_f50[this.isLeftToRight()?_f50.length-1:0].domNode;
return _f52.offsetLeft+dojo.style(_f52,"width")-_f51.offsetLeft;
}else{
return 0;
}
},_enableBtn:function(_f53){
var _f54=this._getTabsWidth();
_f53=_f53||dojo.style(this.scrollNode,"width");
return _f54>0&&_f53<_f54;
},resize:function(dim){
if(this.domNode.offsetWidth==0){
return;
}
this._dim=dim;
this.scrollNode.style.height="auto";
this._contentBox=dijit.layout.marginBox2contentBox(this.domNode,{h:0,w:dim.w});
this._contentBox.h=this.scrollNode.offsetHeight;
dojo.contentBox(this.domNode,this._contentBox);
var _f55=this._enableBtn(this._contentBox.w);
this._buttons.style("display",_f55?"":"none");
this._leftBtn.layoutAlign="left";
this._rightBtn.layoutAlign="right";
this._menuBtn.layoutAlign=this.isLeftToRight()?"right":"left";
dijit.layout.layoutChildren(this.domNode,this._contentBox,[this._menuBtn,this._leftBtn,this._rightBtn,{domNode:this.scrollNode,layoutAlign:"client"}]);
if(this._selectedTab){
if(this._anim&&this._anim.status()=="playing"){
this._anim.stop();
}
var w=this.scrollNode,sl=this._convertToScrollLeft(this._getScrollForSelectedTab());
w.scrollLeft=sl;
}
this._setButtonClass(this._getScroll());
this._postResize=true;
return {h:this._contentBox.h,w:dim.w};
},_getScroll:function(){
var sl=(this.isLeftToRight()||dojo.isIE<8||(dojo.isIE&&dojo.isQuirks)||dojo.isWebKit)?this.scrollNode.scrollLeft:dojo.style(this.containerNode,"width")-dojo.style(this.scrollNode,"width")+(dojo.isIE==8?-1:1)*this.scrollNode.scrollLeft;
return sl;
},_convertToScrollLeft:function(val){
if(this.isLeftToRight()||dojo.isIE<8||(dojo.isIE&&dojo.isQuirks)||dojo.isWebKit){
return val;
}else{
var _f56=dojo.style(this.containerNode,"width")-dojo.style(this.scrollNode,"width");
return (dojo.isIE==8?-1:1)*(val-_f56);
}
},onSelectChild:function(page){
var tab=this.pane2button[page.id];
if(!tab||!page){
return;
}
var node=tab.domNode;
if(this._postResize&&node!=this._selectedTab){
this._selectedTab=node;
var sl=this._getScroll();
if(sl>node.offsetLeft||sl+dojo.style(this.scrollNode,"width")<node.offsetLeft+dojo.style(node,"width")){
this.createSmoothScroll().play();
}
}
this.inherited(arguments);
},_getScrollBounds:function(){
var _f57=this.getChildren(),_f58=dojo.style(this.scrollNode,"width"),_f59=dojo.style(this.containerNode,"width"),_f5a=_f59-_f58,_f5b=this._getTabsWidth();
if(_f57.length&&_f5b>_f58){
return {min:this.isLeftToRight()?0:_f57[_f57.length-1].domNode.offsetLeft,max:this.isLeftToRight()?(_f57[_f57.length-1].domNode.offsetLeft+dojo.style(_f57[_f57.length-1].domNode,"width"))-_f58:_f5a};
}else{
var _f5c=this.isLeftToRight()?0:_f5a;
return {min:_f5c,max:_f5c};
}
},_getScrollForSelectedTab:function(){
var w=this.scrollNode,n=this._selectedTab,_f5d=dojo.style(this.scrollNode,"width"),_f5e=this._getScrollBounds();
var pos=(n.offsetLeft+dojo.style(n,"width")/2)-_f5d/2;
pos=Math.min(Math.max(pos,_f5e.min),_f5e.max);
return pos;
},createSmoothScroll:function(x){
if(arguments.length>0){
var _f5f=this._getScrollBounds();
x=Math.min(Math.max(x,_f5f.min),_f5f.max);
}else{
x=this._getScrollForSelectedTab();
}
if(this._anim&&this._anim.status()=="playing"){
this._anim.stop();
}
var self=this,w=this.scrollNode,anim=new dojo._Animation({beforeBegin:function(){
if(this.curve){
delete this.curve;
}
var oldS=w.scrollLeft,newS=self._convertToScrollLeft(x);
anim.curve=new dojo._Line(oldS,newS);
},onAnimate:function(val){
w.scrollLeft=val;
}});
this._anim=anim;
this._setButtonClass(x);
return anim;
},_getBtnNode:function(e){
var n=e.target;
while(n&&!dojo.hasClass(n,"tabStripButton")){
n=n.parentNode;
}
return n;
},doSlideRight:function(e){
this.doSlide(1,this._getBtnNode(e));
},doSlideLeft:function(e){
this.doSlide(-1,this._getBtnNode(e));
},doSlide:function(_f60,node){
if(node&&dojo.hasClass(node,"dijitTabDisabled")){
return;
}
var _f61=dojo.style(this.scrollNode,"width");
var d=(_f61*0.75)*_f60;
var to=this._getScroll()+d;
this._setButtonClass(to);
this.createSmoothScroll(to).play();
},_setButtonClass:function(_f62){
var _f63=this._getScrollBounds();
this._leftBtn.set("disabled",_f62<=_f63.min);
this._rightBtn.set("disabled",_f62>=_f63.max);
}});
dojo.declare("dijit.layout._ScrollingTabControllerButtonMixin",null,{baseClass:"dijitTab tabStripButton",templateString:dojo.cache("dijit.layout","templates/_ScrollingTabControllerButton.html","<div dojoAttachEvent=\"onclick:_onButtonClick\">\r\n\t<div role=\"presentation\" class=\"dijitTabInnerDiv\" dojoattachpoint=\"innerDiv,focusNode\">\r\n\t\t<div role=\"presentation\" class=\"dijitTabContent dijitButtonContents\" dojoattachpoint=\"tabContent\">\r\n\t\t\t<img role=\"presentation\" alt=\"\" src=\"${_blankGif}\" class=\"dijitTabStripIcon\" dojoAttachPoint=\"iconNode\"/>\r\n\t\t\t<span dojoAttachPoint=\"containerNode,titleNode\" class=\"dijitButtonText\"></span>\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n"),tabIndex:"",isFocusable:function(){
return false;
}});
dojo.declare("dijit.layout._ScrollingTabControllerButton",[dijit.form.Button,dijit.layout._ScrollingTabControllerButtonMixin]);
dojo.declare("dijit.layout._ScrollingTabControllerMenuButton",[dijit.form.Button,dijit._HasDropDown,dijit.layout._ScrollingTabControllerButtonMixin],{containerId:"",tabIndex:"-1",isLoaded:function(){
return false;
},loadDropDown:function(_f64){
this.dropDown=new dijit.Menu({id:this.containerId+"_menu",dir:this.dir,lang:this.lang});
var _f65=dijit.byId(this.containerId);
dojo.forEach(_f65.getChildren(),function(page){
var _f66=new dijit.MenuItem({id:page.id+"_stcMi",label:page.title,iconClass:page.iconClass,dir:page.dir,lang:page.lang,onClick:function(){
_f65.selectChild(page);
}});
this.dropDown.addChild(_f66);
},this);
_f64();
},closeDropDown:function(_f67){
this.inherited(arguments);
if(this.dropDown){
this.dropDown.destroyRecursive();
delete this.dropDown;
}
}});
}
if(!dojo._hasResource["dijit.layout.TabContainer"]){
dojo._hasResource["dijit.layout.TabContainer"]=true;
dojo.provide("dijit.layout.TabContainer");
dojo.declare("dijit.layout.TabContainer",dijit.layout._TabContainerBase,{useMenu:true,useSlider:true,controllerWidget:"",_makeController:function(_f68){
var cls=this.baseClass+"-tabs"+(this.doLayout?"":" dijitTabNoLayout"),_f69=dojo.getObject(this.controllerWidget);
return new _f69({id:this.id+"_tablist",dir:this.dir,lang:this.lang,tabPosition:this.tabPosition,doLayout:this.doLayout,containerId:this.id,"class":cls,nested:this.nested,useMenu:this.useMenu,useSlider:this.useSlider,tabStripClass:this.tabStrip?this.baseClass+(this.tabStrip?"":"No")+"Strip":null},_f68);
},postMixInProperties:function(){
this.inherited(arguments);
if(!this.controllerWidget){
this.controllerWidget=(this.tabPosition=="top"||this.tabPosition=="bottom")&&!this.nested?"dijit.layout.ScrollingTabController":"dijit.layout.TabController";
}
}});
}
if(!dojo._hasResource["dijit.layout.LayoutContainer"]){
dojo._hasResource["dijit.layout.LayoutContainer"]=true;
dojo.provide("dijit.layout.LayoutContainer");
dojo.declare("dijit.layout.LayoutContainer",dijit.layout._LayoutWidget,{baseClass:"dijitLayoutContainer",constructor:function(){
dojo.deprecated("dijit.layout.LayoutContainer is deprecated","use BorderContainer instead",2);
},layout:function(){
dijit.layout.layoutChildren(this.domNode,this._contentBox,this.getChildren());
},addChild:function(_f6a,_f6b){
this.inherited(arguments);
if(this._started){
dijit.layout.layoutChildren(this.domNode,this._contentBox,this.getChildren());
}
},removeChild:function(_f6c){
this.inherited(arguments);
if(this._started){
dijit.layout.layoutChildren(this.domNode,this._contentBox,this.getChildren());
}
}});
dojo.extend(dijit._Widget,{layoutAlign:"none"});
}
if(!dojo._hasResource["dojoe.table._TableOptions"]){
dojo._hasResource["dojoe.table._TableOptions"]=true;
dojo.provide("dojoe.table._TableOptions");
dojo.declare("dojoe.table._TableOptions",[dijit._Widget,dijit._Container],{grid:null,constructor:function(){
this.resources_=dojo.i18n.getLocalization("dojoe.table","Table",this.lang);
},postCreate:function(){
this.inherited("postCreate",arguments);
this.addColumnsVisible(this.grid.layout.cells);
},addColumnsVisible:function(_f6d){
var _f6e=null;
var _f6f=null;
for(var i in _f6d){
if(i){
_f6f=_f6d[i];
if(_f6f.field){
_f6e=new dojoe.table.ColumnVisible({id:this.id+"column_"+_f6f.field,columnid:this.id+"column_"+_f6f.field,checked:_f6f.visible===undefined?!_f6f.hidden:_f6f.visible,label:_f6f.name});
this.addChild(_f6e);
}else{
}
}
}
},onSelectAll:function(){
for(var k=0;k<this.grid.layout.cells.length;k++){
var _f70=this.grid.layout.cells[k];
if(_f70&&_f70.field){
var _f71=dijit.byId(this.id+"column_"+_f70.field);
_f71.setVisible(true);
}
}
},onDeselectAll:function(){
for(var k=0;k<this.grid.layout.cells.length;k++){
var _f72=this.grid.layout.cells[k];
if(_f72&&_f72.field){
var _f73=dijit.byId(this.id+"column_"+_f72.field);
_f73.setVisible(false);
}
}
},onSave:function(){
for(var k=0;k<this.grid.layout.cells.length;k++){
var _f74=this.grid.layout.cells[k];
if(_f74&&_f74.field){
var _f75=_f74;
_f75.width=_f75.unitWidth;
_f74.width=_f75.unitWidth;
var _f76=dijit.byId(this.id+"column_"+_f74.field);
_f74.hidden=!(_f76.isVisible());
this.grid.layout.cells[k].hidden=_f74.hidden;
}
}
this.grid.views.forEach(function(v,i){
var w=v.width;
if(w&&w!="auto"){
v._togglingColumn=dojo.marginBox(v.structure.cells[0].getHeaderNode()).w||0;
}
v.update();
});
},isColumnVisible:function(_f77){
var _f78=dijit.byId(this.id+"column_"+_f77);
return (_f78.isVisible());
}});
dojo.declare("dojoe.table.ColumnVisible",[dijit._Widget,dijit._Templated],{columnid:null,label:null,checked:false,widgetsInTemplate:true,templateString:dojo.cache("dojoe.table","templates/ColumnVisible.html","<div>\r\n\t<input dojoType=\"dijit.form.CheckBox\" dojoAttachPoint=\"checkbox\" name=\"${columnid}CB\" id=\"${columnid}CB\" value=\"\" role=\"checkbox\" />\r\n\t\t&#160;\r\n\t<label for=\"${columnid}CB\">${label}</label>\r\n</div>\r\n"),constructor:function(){
},postCreate:function(){
if(this.checked){
this.checkbox.setChecked(this.checked);
dijit.byId(this.checkbox.id.toString()).set("disabled",true);
dijit.byId(this.checkbox.id.toString()).set("disabled",false);
}
},setVisible:function(_f79){
this.checkbox.setChecked(_f79);
dijit.byId(this.checkbox.id.toString()).set("disabled",true);
dijit.byId(this.checkbox.id.toString()).set("disabled",false);
},isVisible:function(){
return this.checkbox.checked;
},destroy:function(){
try{
delete this.resources_;
var _f7a=dijit.findWidgets(this.domNode);
dojo.forEach(_f7a,function(w){
if(w){
if(w.destroyRecursive){
w.destroyRecursive();
}else{
if(w.destroy){
w.destroy();
}
}
}
});
var _f7b=this.getChildren();
dojo.forEach(_f7b,function(_f7c){
if(_f7c){
if(_f7c.destroyRecursive){
_f7c.destroyRecursive();
}else{
if(_f7c.destroy){
_f7c.destroy();
}
}
}
});
this.inherited(arguments);
}
catch(ex){
console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
}
}});
}
if(!dojo._hasResource["dojoe.table._ConfigureColumnsDialog"]){
dojo._hasResource["dojoe.table._ConfigureColumnsDialog"]=true;
dojo.provide("dojoe.table._ConfigureColumnsDialog");
dojo.declare("dojoe.table._ConfigureColumnsDialog",[dijit._Widget,dijit._Templated],{widgetsInTemplate:true,templateString:dojo.cache("dojoe.table","templates/ConfigureColumnsDialog.html","\r\n<div>\r\n  <div dojoType=\"dijit.Dialog\" dojoAttachPoint=\"dialog\"\ttitle=\"${resources_.CONFIGURE_SETTINGS}\" tabindex=0 role=\"dialog\" style=\"width:350px;height:260px;overflow:auto;\" >\r\n\t\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" role=\"presentation\" style=\"width:100%height:100%\">\r\n\t\t\t<tr height=\"20%\" style=\"vertical-align:top;\"><td>\r\n\t\t\t\t<div  style=\"width:100%;height:100%;overflow:auto;\" class=\"tivTable\">\r\n\t\t\t\t\t<label>${resources_.COLUMNS_VISIBLE}</label>\t\t\r\n\t\t\t\t\t \t\r\n\t                  <table border=\"0\" cellspacing=\"7\" cellpadding=\"0\" role=\"presentation\">\r\n\t\t\t\t\t\t<tbody>\r\n\t\t\t\t\t\t\t<tr>\t\t\t\t\t\t\r\n\t\t\t\t\t\t\t\t<td>\r\n\t\t\t\t\t\t\t\t\t<span dojoAttachPoint=\"selectAllButton\" role=\"button\">\r\n\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t\t<td>\r\n\t\t\t\t\t\t\t\t\t<span dojoAttachPoint=\"deselectAllButton\" role=\"button\">\r\n\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t\t</tbody>\r\n\t\t\t\t\t</table>\r\n\t\t\t\t</div>\r\n\t\t\t</td></tr>\r\n\t\t\t<tr height=\"50%\"><td>\t\t\r\n\t\t\t\t<div tabStrip=\"false\" id=\"${id}tabs\" dojoType=\"dijit.layout.LayoutContainer\"  class=\"dialog\" style=\"vertical-align:top;width:315px;height:110px;overflow-x:hidden;overflow-y:auto;padding:2px 0px 0px 10px;\">\r\n\t\t\t\t \t<div dojoType=\"dijit.layout.ContentPane\" style=\"width:100%;\">\r\n\t\t\t\t\t\t<div id=\"${id}columnsVisibleDivContainer\" >\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t \t</div>\r\n\t\t\t\t</div>\r\n\t\t\t</td></tr>\r\n\t\t\t<tr><td><br/></td></tr>\t\r\n\t\t\t<tr height=\"30%\" style=\"vertical-align:top;\"><td >\t\r\n\t\t\t\t<button value=\"${resources_.OK}\" dojoType=\"dijit.form.Button\" role=\"button\"\r\n\t\t\t\t\tdojoAttachEvent=\"onClick:onOK,onKeypress:onOK\">${resources_.OK}</button>&nbsp;\r\n\t\t\t\t<button value=\"${resources_.CANCEL}\" dojoType=\"dijit.form.Button\" role=\"button\"\r\n\t\t\t\tdojoAttachPoint=\"cancelButton\" dojoAttachEvent=\"onClick:onCancel,onKeypress:onCancel\">${resources_.CANCEL}</button>\t\r\n\t\t\t</td></tr>\r\n\t\t</table>\r\n  </div>\r\n</div>\r\n"),optionsWidget_:null,constructor:function(){
this.resources_=dojo.i18n.getLocalization("dojoe.table","Table",this.lang);
},postCreate:function(){
this.inherited("postCreate",arguments);
this.optionsWidget_=new dojoe.table._TableOptions({grid:this.grid},dojo.byId(this.id+"columnsVisibleDivContainer"));
this.optionsWidget_.startup();
var _f7d=new dijit.form.Button({id:this.id+"selectAllIcon",showLabel:false,iconClass:"selectAllIcon",label:this.resources_.SELECT_ALL},this.selectAllButton);
_f7d.onClick=dojo.hitch(this,"onSelectAll");
_f7d.onKeypress=dojo.hitch(this,"onSelectAll");
var _f7e=new dijit.form.Button({id:this.id+"deselectAllIcon",showLabel:false,iconClass:"deselectAllIcon",label:this.resources_.DESELECT_ALL},this.deselectAllButton);
_f7e.onClick=dojo.hitch(this,"onDeselectAll");
_f7e.onKeypress=dojo.hitch(this,"onDeselectAll");
},onSelectAll:function(){
this.optionsWidget_.onSelectAll();
},onDeselectAll:function(){
this.optionsWidget_.onDeselectAll();
},onOK:function(){
window.document.body.style.cursor="wait";
this.optionsWidget_.onSave();
this.hide();
window.document.body.style.cursor="default";
},onCancel:function(){
this.hide();
},show:function(){
this.dialog.show();
dijit.byId(this.id+"tabs").resize();
},hide:function(){
this.dialog.hide();
setTimeout(dojo.hitch(this,this.kill),100);
},kill:function(){
var id=this.id;
this.destroyRecursive();
dijit.registry.remove(id);
},getTableOptions:function(){
return this.optionsWidget_;
},destroy:function(){
try{
delete this.resources_;
var _f7f=dijit.findWidgets(this.domNode);
dojo.forEach(_f7f,function(w){
if(w){
if(w.destroyRecursive){
w.destroyRecursive();
}else{
if(w.destroy){
w.destroy();
}
}
}
});
var _f80=this.getChildren();
dojo.forEach(_f80,function(_f81){
if(_f81){
if(_f81.destroyRecursive){
_f81.destroyRecursive();
}else{
if(_f81.destroy){
_f81.destroy();
}
}
}
});
this.inherited(arguments);
}
catch(ex){
console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
}
}});
}
if(!dojo._hasResource["dojoe.table._QuickFilter"]){
dojo._hasResource["dojoe.table._QuickFilter"]=true;
dojo.provide("dojoe.table._QuickFilter");
dojo.declare("dojoe.table._QuickFilter",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dojoe.table","templates/QuickFilter.html","<div class=\"dijitReset  dijitTextBox quickFilter\" dojoAttachEvent='onmouseover:_onHover,mouseleave:_onUnHover,onblur:_onBlur,onclick: _onClick'>\r\n\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" role=\"presentation\">\r\n\t\t<tbody>\r\n\t\t\t<tr valign=\"center\">\r\n\t\t\t\t<td width=\"98%\" height=\"100%\">\r\n\t\t\t\t  <div>\t\t    \r\n\t\t\t\t\t\t<input dojoAttachPoint=\"searchField\" title=\"${resources_.QUICK_FILTER}\" class=\"dijitInputInner qf-textfield\" type=\"text\" \r\n\t\t\t\t\t\t\tvalue=\"${resources_.QF_DEFAULT_TEXT}\" valign=\"middle\" tabindex=\"0\" role=\"textbox\" \r\n\t\t\t\t\t\t\tdojoAttachEvent='onfocus:_onFocus,onkeyup:_onKeyUp,onpaste:_onKeyUp,oncut:_onKeyUp'/>\t\r\n\t\t\t\t  </div>\r\n\t\t\t\t</td>\t\r\n\t\t\t\t<td width=\"2%\" height=\"100%\">\r\n\t\t\t\t  <div class=\"dijitReset  dijitArrowButtonContainer \">\r\n\t\t\t\t\t\t<button title=\"${resources_.CLEAR_FILTER}\" class=\"dijitReset dijitInline dijitIcon quickFilterClearInner\" type=\"button\" tabindex=\"0\" \r\n\t\t\t\t\t\t\tvalign=\"middle\" dojoAttachPoint='clearFilterNode' dojoAttachEvent='onclick:_onCancel,onkeypress:_onCancel' role=\"button\"></button>\t\t\r\n\t\t\t\t  </div>\r\n\t\t\t\t</td>\r\n\t\t\t</tr>\r\n\t\t</tbody>\t\t\r\n\t</table>\r\n</div>\r\n"),widgetsInTemplate:false,grid:null,timer:null,filterOptions:null,_quickFilterDelay:700,_quickFilterButton:false,_savedCriteria:null,_ruleCntClearFilter:null,_retainSelection:false,constructor:function(){
this.resources_=dojo.i18n.getLocalization("dojoe.table","Table",this.lang);
},postCreate:function(){
if(this.filterOptions){
if(this.filterOptions.showQuickFilterButton!==undefined){
this._quickFilterButton=this.filterOptions.showQuickFilterButton;
}
if(this.filterOptions.quickFilterDelay){
this._quickFilterDelay=this.filterOptions.quickFilterDelay;
}
if(this.filterOptions.retainSelection){
this._retainSelection=this.filterOptions.retainSelection;
}
}
var _f82=this.searchField.value;
if(this.filterText!==null&&this.filterText!==""&&_f82!==this.resources_.QF_DEFAULT_TEXT){
dojo.style(this.clearFilterNode,"display","block");
}else{
dojo.style(this.clearFilterNode,"display","none");
}
},postMixInProperties:function(){
this.connect(this.grid,"onFilterDefined","_onFilterDefined");
if(this.grid.pluginMgr.getPlugin("Filter")){
this.connect(this.grid.pluginMgr.getPlugin("Filter").filterDefDialog,"showDialog","_onShowDialog");
}
},_onFocus:function(){
dojo.addClass(this.domNode,"dijitTextBoxFocused");
if(this.searchField.value==this.resources_.QF_DEFAULT_TEXT){
this.searchField.style.color="#000000";
this.searchField.value="";
}
},_onClick:function(){
dojo.addClass(this.domNode,"dijitTextBoxFocused");
this.searchField.focus();
this.searchField.style.color="#000000";
},_onBlur:function(){
dojo.removeClass(this.domNode,"dijitTextBoxFocused");
dojo.removeClass(this.domNode,"dijitTextBoxHover");
if(this.searchField.value===""){
this.searchField.style.color="#999999";
this.searchField.value=this.resources_.QF_DEFAULT_TEXT;
}
},_onHover:function(){
dojo.addClass(this.domNode,"dijitTextBoxHover");
},_onUnHover:function(){
dojo.removeClass(this.domNode,"dijitTextBoxHover");
},_onKeyUp:function(_f83){
if(_f83.keyCode==13){
dojo.stopEvent(_f83);
this._setFilter();
return;
}else{
if(_f83.keyCode==9||_f83.keyCode==16){
return;
}else{
if(this._quickFilterButton){
return;
}else{
if(this.timer){
clearTimeout(this.timer);
this.timer=null;
}
}
}
}
this.timer=setTimeout(dojo.hitch(this,"_setFilter"),this._quickFilterDelay);
},_onShowDialog:function(){
this._clearText();
},_setFilter:function(){
var _f84=this.searchField.value;
if(_f84==this.resources_.QF_DEFAULT_TEXT||_f84==""){
_f84="";
this._clearQuickFilter();
return;
}
var rule={"type":"string","column":"anycolumn","condition":"contains","value":_f84,"colTxt":"Any Column","condTxt":"contains","formattedVal":_f84};
if(this._savedCriteria){
var _f85=this._savedCriteria;
}
this._savedCriteria=rule;
if(this.grid.getFilter().length>0){
var _f86=false;
var _f87=this.grid.getFilter();
if(_f85){
for(var i=0;i<_f87.length;i++){
if(_f87[i].column==="anycolumn"&&(_f85.value===_f87[i].value)){
_f87[i].value=rule.value;
_f86=true;
break;
}
}
}
if(!_f86){
_f87.push(rule);
}
rule=_f87;
}
this._ruleCntClearFilter=this.grid.pluginMgr.getPlugin("Filter").ruleCountToConfirmClearFilter;
this.grid.pluginMgr.getPlugin("Filter").ruleCountToConfirmClearFilter="Infinity";
this.grid.setFilter(rule);
dojo.style(this.clearFilterNode,"display","block");
},_onFilterDefined:function(_f88){
if(this._retainSelection==false){
this.grid.selection.clear();
}
if(this._ruleCntClearFilter){
this.grid.pluginMgr.getPlugin("Filter").ruleCountToConfirmClearFilter=this._ruleCntClearFilter;
}
},_setFocus:function(){
this.searchField.focus();
},_onCancel:function(_f89){
if(_f89.keyCode==9||_f89.keyCode==16){
return;
}else{
this._clearQuickFilter();
}
},_clearQuickFilter:function(){
if(this.grid.getFilter().length>0&&this._savedCriteria){
var _f8a=this.grid.getFilter();
for(var i=0;i<_f8a.length;i++){
if(_f8a[i].column==="anycolumn"&&(this._savedCriteria.value===_f8a[i].value)){
_f8a.splice(i,1);
break;
}
}
this.grid.setFilter(_f8a);
}
this.searchField.style.color="#999999";
this.searchField.value=this.resources_.QF_DEFAULT_TEXT;
dojo.style(this.clearFilterNode,"display","none");
},_clearText:function(){
this.searchField.style.color="#999999";
this.searchField.value=this.resources_.QF_DEFAULT_TEXT;
this._savedCriteria=null;
dojo.style(this.clearFilterNode,"display","none");
},destroy:function(){
try{
delete this.resources_;
var _f8b=dijit.findWidgets(this.domNode);
dojo.forEach(_f8b,function(w){
if(w){
if(w.destroyRecursive){
w.destroyRecursive();
}else{
if(w.destroy){
w.destroy();
}
}
}
});
var _f8c=this.getChildren();
dojo.forEach(_f8c,function(_f8d){
if(_f8d){
if(_f8d.destroyRecursive){
_f8d.destroyRecursive();
}else{
if(_f8d.destroy){
_f8d.destroy();
}
}
}
});
this.inherited(arguments);
}
catch(ex){
console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
}
}});
}
if(!dojo._hasResource["dojoe.table._Toolbar"]){
dojo._hasResource["dojoe.table._Toolbar"]=true;
dojo.provide("dojoe.table._Toolbar");
dojo.declare("dojoe.table._Toolbar",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dojoe.table","templates/Toolbar.html","<div  dojoAttachEvent='oncontextmenu:_stopEvent' class=\"tivTable dijitToolbar\" width=\"100%\">\r\n<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" role=\"presentation\">\r\n\t<tbody>\r\n\t\t<tr valign=\"center\">\r\n\t\t\t<td width=\"80%\" height=\"100%\">\r\n\t\t\t\t<span dojoAttachPoint=\"toolbarFirstRow\"><span dojoAttachPoint=\"refreshNode\" role=\"button\"></span><span dojoAttachPoint=\"refSeperator\" role=\"separator\"></span><span dojoAttachPoint=\"toolbarFirstRow_userItems\"></span><span dojoAttachPoint=\"exportDataNode\" role=\"button\"></span><span dojoAttachPoint=\"printNode\" role=\"button\"></span><span dojoAttachPoint=\"configureColNode\" role=\"button\"></span><span dojoAttachPoint=\"actionListNode\" role=\"button\"></span></span>\r\n\t\t\t</td>\r\n\t\t\t<td width=\"20%\" height=\"100%\" align=\"right\"><div dojoAttachPoint=\"quickFilterNode\" role=\"search\"></div></td>\r\n\t\t\t<td><div dojoAttachPoint=\"filterNode\" role=\"button\"></div></td>\t\t\t\r\n\t\t</tr>\r\n\t\t<tr valign=\"center\">\r\n\t\t\t<td width=\"100%\">\r\n\t\t\t\t<span dojoAttachPoint=\"toolbarSecondRow\">\r\n\t\t\t\t</span>\t\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t</tbody>\t\t\r\n</table>\r\n</div>\r\n"),widgetsInTemplate:true,plugins:null,inGrid:null,actionListWidget:null,resources_:null,toolbarOptions:null,filterOptions:null,refreshIcon:true,refreshMenu:true,actionMenu:true,configTableIcon:true,configTableMenu:true,tivTable:null,configureTableDialog:null,_quickFilter:null,constructor:function(){
this.resources_=dojo.i18n.getLocalization("dojoe.table","Table",this.lang);
},postCreate:function(){
this.inGrid=this.tivTable.grid;
this.plugins=this.tivTable.gridParams.plugins;
this.toolbarOptions=this.tivTable.toolbarOptions;
this.filterOptions=this.tivTable.filterOptions;
this._mapToolbarOptions();
this._addRefreshIcon();
this._addExporterIcon();
this._addPrintIcon();
this._addConfigTableIcon();
this._addActionMenu();
this._addFilters();
},_stopEvent:function(e){
dojo.stopEvent(e);
},_addRefreshIcon:function(){
if(this.refreshIcon){
var _f8e=new dijit.form.Button({showLabel:false,id:"refreshIcon"+this.id,iconClass:"refreshIcon",label:this.resources_.REFRESH,title:this.resources_.REFRESH},this.refreshNode);
_f8e.onClick=dojo.hitch(this,"_refreshTable");
_f8e.onKeypress=dojo.hitch(this,"_refreshTable");
var _f8f=new dijit.ToolbarSeparator({id:"refSeperator"+this.id},this.refSeperator);
}else{
dojo.style(this.refreshNode.parentNode,"width","0px");
dojo.style(this.refSeperator.parentNode,"width","0px");
}
},_addExporterIcon:function(){
if(this.plugins.exporter&&this.toolbarOptions.exporterIcon){
var _f90=new dijit.Menu({style:"display: none;"});
var _f91=new dijit.MenuItem({title:this.resources_.EXPORT_HTML,label:this.resources_.EXPORT_HTML});
_f91.onClick=dojo.hitch(this,"_exportHTML");
_f91.onKeypress=dojo.hitch(this,"_exportHTML");
_f90.addChild(_f91);
var _f92=new dijit.MenuItem({title:this.resources_.EXPORT_ALL_CSV,label:this.resources_.EXPORT_ALL_CSV});
_f92.onClick=dojo.hitch(this,"_exportCSV");
_f92.onKeypress=dojo.hitch(this,"_exportCSV");
_f90.addChild(_f92);
var _f93=new dijit.form.DropDownButton({showLabel:false,iconClass:"exportDataIcon",id:"exportDataIcon"+this.id,label:this.resources_.EXPORT,title:this.resources_.EXPORT,dropDown:_f90},this.exportDataNode);
}else{
dojo.style(this.exportDataNode.parentNode,"width","0px");
}
},_addPrintIcon:function(){
if(this.plugins.printer&&this.toolbarOptions.printerIcon){
var _f94=new dijit.Menu({style:"display: none;"});
var _f95=new dijit.MenuItem({title:this.resources_.PRINT_ALL,label:this.resources_.PRINT_ALL});
_f95.onClick=dojo.hitch(this,"_printAll");
_f95.onKeypress=dojo.hitch(this,"_printAll");
_f94.addChild(_f95);
var _f96=new dijit.MenuItem({title:this.resources_.PRINT_SELECTED,label:this.resources_.PRINT_SELECTED});
_f96.onClick=dojo.hitch(this,"_printSelected");
_f96.onKeypress=dojo.hitch(this,"_printSelected");
_f94.addChild(_f96);
var _f97=new dijit.MenuItem({title:this.resources_.PRINT_PREVIEW,label:this.resources_.PRINT_PREVIEW});
_f97.onClick=dojo.hitch(this,"_printPreview");
_f97.onKeypress=dojo.hitch(this,"_printPreview");
_f94.addChild(_f97);
var _f98=new dijit.form.DropDownButton({showLabel:false,iconClass:"printIcon",id:"printIcon"+this.id,label:this.resources_.PRINT,title:this.resources_.PRINT,dropDown:_f94},this.printNode);
}else{
dojo.style(this.printNode.parentNode,"width","0px");
}
},_addConfigTableIcon:function(){
if(this.configTableIcon){
var _f99=new dijit.form.Button({showLabel:false,iconClass:"configureColIcon",id:"configureColIcon"+this.id,label:this.resources_.CONFIGURE_SETTINGS,title:this.resources_.CONFIGURE_SETTINGS},this.configureColNode);
_f99.onClick=dojo.hitch(this,"_configureTable");
_f99.onKeypress=dojo.hitch(this,"_configureTable");
}else{
dojo.style(this.configureColNode.parentNode,"width","0px");
}
},_addActionMenu:function(){
if(this.actionMenu){
var menu=new dijit.Menu({style:"display: none;"});
if(this.refreshMenu){
var _f9a=new dijit.MenuItem({title:this.resources_.REFRESH,label:this.resources_.REFRESH,iconClass:"refreshIcon"});
_f9a.onClick=dojo.hitch(this,"_refreshTable");
_f9a.onKeypress=dojo.hitch(this,"_refreshTable");
menu.addChild(_f9a);
}
if(this.filterOptions.showAdvancedFilter){
var _f9b=new dijit.MenuItem({title:this.resources_.ADVANCED_FILTER,label:this.resources_.ADVANCED_FILTER,iconClass:"filterIcon"});
_f9b.onClick=dojo.hitch(this,"_advancedFilter");
_f9b.onKeypress=dojo.hitch(this,"_advancedFilter");
menu.addChild(_f9b);
}
if(this.plugins.exporter&&this.toolbarOptions.exporterMenu){
var _f9c=new dijit.Menu();
_f9c.addChild(new dijit.MenuItem({title:this.resources_.EXPORT_HTML,label:this.resources_.EXPORT_HTML,onClick:dojo.hitch(this,this._exportHTML),onKeypress:dojo.hitch(this,this._exportHTML)}));
_f9c.addChild(new dijit.MenuItem({title:this.resources_.EXPORT_ALL_CSV,label:this.resources_.EXPORT_ALL_CSV,onClick:dojo.hitch(this,this._exportCSV),onKeypress:dojo.hitch(this,this._exportCSV)}));
var _f9d=new dijit.PopupMenuItem({title:this.resources_.EXPORT,label:this.resources_.EXPORT,iconClass:"exportDataIcon",popup:_f9c});
menu.addChild(_f9d);
}
if(this.plugins.printer&&this.toolbarOptions.printerMenu){
var _f9e=new dijit.Menu();
_f9e.addChild(new dijit.MenuItem({title:this.resources_.PRINT_ALL,label:this.resources_.PRINT_ALL,onClick:dojo.hitch(this,this._printAll),onKeypress:dojo.hitch(this,this._printAll)}));
_f9e.addChild(new dijit.MenuItem({title:this.resources_.PRINT_SELECTED,label:this.resources_.PRINT_SELECTED,onClick:dojo.hitch(this,this._printSelected),onKeypress:dojo.hitch(this,this._printSelected)}));
_f9e.addChild(new dijit.MenuItem({title:this.resources_.PRINT_PREVIEW,label:this.resources_.PRINT_PREVIEW,onClick:dojo.hitch(this,this._printPreview),onKeypress:dojo.hitch(this,this._printPreview)}));
var _f9f=new dijit.PopupMenuItem({title:this.resources_.PRINT,label:this.resources_.PRINT,iconClass:"printIcon",popup:_f9e});
menu.addChild(_f9f);
}
if(this.configTableMenu){
var _fa0=new dijit.MenuItem({title:this.resources_.CONFIGURE_SETTINGS,label:this.resources_.CONFIGURE_SETTINGS,iconClass:"configureColIcon"});
_fa0.onClick=dojo.hitch(this,"_configureTable");
_fa0.onKeypress=dojo.hitch(this,"_configureTable");
menu.addChild(_fa0);
}
menu.startup();
var _fa1=new dijit.form.DropDownButton({optionsTitle:this.resources_.ACTIONS,label:this.resources_.ACTIONS,title:this.resources_.ACTIONS,id:"actionListMenu"+this.id,dropDown:menu},this.actionListNode);
this.actionListWidget=_fa1;
}else{
dojo.style(this.actionListNode.parentNode,"width","0px");
}
},_addFilters:function(){
if(this.filterOptions.hideFilterBar==true&&this.inGrid.showFilterBar!==undefined){
this.inGrid.showFilterBar(false);
}else{
if(this.filterOptions.hideFilterBar==false){
this.inGrid.showFilterBar(true);
}
}
if(this.filterOptions.showQuickFilter&&this.filterOptions.showQuickFilterButton&&!this.filterOptions.showAdvancedFilter){
this._quickFilter=new dojoe.table._QuickFilter({grid:this.inGrid,id:"quickFilter"+this.id,filterOptions:this.filterOptions,placeHolder:this.resources_.QF_DEFAULT_TEXT,clearIconText:this.resources_.CLEAR_FILTER},this.quickFilterNode);
var _fa2=new dijit.form.Button({showLabel:false,iconClass:"filterIcon",id:"filterIcon"+this.id,title:this.resources_.QUICK_FILTER},this.filterNode);
_fa2.onClick=dojo.hitch(this,"_setQuickFilter");
_fa2.onKeypress=dojo.hitch(this,"_setQuickFilter");
_fa2.domNode.title=this.resources_.QUICK_FILTER;
}else{
if(this.filterOptions.showQuickFilter&&this.filterOptions.showQuickFilterButton&&this.filterOptions.showAdvancedFilter){
this._quickFilter=new dojoe.table._QuickFilter({grid:this.inGrid,id:"quickFilter"+this.id,filterOptions:this.filterOptions,clearIconText:this.resources_.CLEAR_FILTER,placeHolder:this.resources_.QF_DEFAULT_TEXT},this.quickFilterNode);
var menu=new dijit.Menu({});
menu.domNode.style.display="none";
var _fa3=new dijit.MenuItem({label:this.resources_.QF_DEFAULT_TEXT,onClick:dojo.hitch(this,"_setQuickFilter"),onKeypress:dojo.hitch(this,"_setQuickFilter")});
var _fa4=new dijit.MenuItem({label:this.resources_.ADVANCED_FILTER,onClick:dojo.hitch(this,"_advancedFilter"),onKeypress:dojo.hitch(this,"_advancedFilter")});
menu.addChild(_fa3);
menu.addChild(_fa4);
var _fa5=new dijit.form.ComboButton({showLabel:false,iconClass:"filterIcon",id:"comboFilterIcon"+this.id,label:this.resources_.QUICK_FILTER,title:this.resources_.QUICK_FILTER,dropDown:menu,onClick:dojo.hitch(this,"_setQuickFilter"),onKeypress:dojo.hitch(this,"_setQuickFilter")},this.filterNode);
}else{
if(this.filterOptions.showQuickFilter&&!this.filterOptions.showQuickFilterButton&&!this.filterOptions.showAdvancedFilter){
this._quickFilter=new dojoe.table._QuickFilter({grid:this.inGrid,id:"quickFilter"+this.id,filterOptions:this.filterOptions,clearIconText:this.resources_.CLEAR_FILTER,placeHolder:this.resources_.QF_DEFAULT_TEXT},this.quickFilterNode);
}else{
if(this.filterOptions.showAdvancedFilter&&!this.filterOptions.showQuickFilterButton&&this.filterOptions.showAdvancedFilter){
this._quickFilter=new dojoe.table._QuickFilter({grid:this.inGrid,id:"quickFilter"+this.id,filterOptions:this.filterOptions,clearIconText:this.resources_.CLEAR_FILTER,placeHolder:this.resources_.QF_DEFAULT_TEXT},this.quickFilterNode);
var _fa6=new dijit.form.Button({showLabel:false,iconClass:"filterIcon",id:"advancedFilterIcon"+this.id,title:this.resources_.ADVANCED_FILTER},this.filterNode);
_fa6.onClick=dojo.hitch(this,"_advancedFilter");
_fa6.onKeypress=dojo.hitch(this,"_advancedFilter");
}else{
if(!this.filterOptions.showAdvancedFilter&&this.filterOptions.showAdvancedFilter){
var _fa6=new dijit.form.Button({showLabel:false,iconClass:"filterIcon",id:"advancedFilterIcon"+this.id,title:this.resources_.ADVANCED_FILTER},this.filterNode);
_fa6.onClick=dojo.hitch(this,"_advancedFilter");
_fa6.onKeypress=dojo.hitch(this,"_advancedFilter");
}
}
}
}
}
},_refreshTable:function(){
this.tivTable.refresh();
},_customizeData:function(){
if(this.tivTable.defaultExportFormatter){
this.inGrid.setExportFormatter(function(data,cell,_fa7,_fa8){
return data;
});
}
},_exportHTML:function(){
this._customizeData();
var grid=this.inGrid;
var url=dojo.moduleUrl("dojoe","table/themes/print_style.css");
var _fa9=url.toString();
var _faa={title:this.resources_.EXPORT_HTML,cssFiles:[_fa9]};
if(this.inGrid.selection.getSelectedCount()>0){
this.inGrid.exportSelectedToHTML(_faa,function(_fab){
var win=window.open();
win.document.open();
win.document.write(_fab);
grid.normalizePrintedGrid(win.document);
win.document.close();
});
}else{
this.inGrid.exportToHTML(_faa,function(str){
var win=window.open();
win.document.open();
win.document.write(str);
grid.normalizePrintedGrid(win.document);
win.document.close();
});
}
},_exportCSV:function(){
this._customizeData();
this.inGrid.exportGrid("csv",function(str){
resources_=dojo.i18n.getLocalization("dojoe.table","Table",this.lang);
var _fac=new dijit.form.SimpleTextarea({value:str,rows:20,cols:100,selectOnClick:true});
_fac.selected=true;
var _fad=new dijit.Dialog({title:resources_.EXPORT_ALL_CSV+" - "+resources_.EXPORT_ALL_CSV_SAVE});
_fad.attr("content",_fac);
_fad.show();
});
},_printAll:function(){
this._customizeData();
var url=dojo.moduleUrl("dojoe","table/themes/print_style.css");
var _fae=url.toString();
var _faf={title:this.resources_.PRINT_ALL,cssFiles:[_fae]};
this.inGrid.printGrid(_faf);
},_printSelected:function(){
this._customizeData();
var url=dojo.moduleUrl("dojoe","table/themes/print_style.css");
var _fb0=url.toString();
var _fb1={title:this.resources_.PRINT_SELECTED,cssFiles:[_fb0]};
this.inGrid.printSelected(_fb1);
},_printPreview:function(){
this._customizeData();
var grid=this.inGrid;
var url=dojo.moduleUrl("dojoe","table/themes/print_style.css");
var _fb2=url.toString();
var _fb3={title:this.resources_.PRINT_PREVIEW,cssFiles:[_fb2]};
if(this.inGrid.selection.getSelectedCount()>0){
this.inGrid.exportSelectedToHTML(_fb3,function(_fb4){
var win=window.open();
win.document.open();
win.document.write(_fb4);
grid.normalizePrintedGrid(win.document);
win.document.close();
});
}else{
this.inGrid.exportToHTML(_fb3,function(str){
var win=window.open();
win.document.open();
win.document.write(str);
grid.normalizePrintedGrid(win.document);
win.document.close();
});
}
},_setQuickFilter:function(){
this._quickFilter._setFilter();
},_advancedFilter:function(){
this.inGrid.pluginMgr.getPlugin("Filter").filterDefDialog.showDialog();
this.inGrid.showFilterBar(true,true,{duration:200});
},_configureTable:function(){
this.configureTableDialog=new dojoe.table._ConfigureColumnsDialog({grid:this.inGrid});
this.configureTableDialog.show();
},_addToToolbarFirstRow:function(item,_fb5){
var _fb6=dojo.doc.createElement("span");
dojo.style(_fb6,"width","1px");
if(_fb5!==undefined){
dojo.place(_fb6,this.toolbarFirstRow_userItems,parseInt(_fb5));
}else{
dojo.place(_fb6,this.toolbarFirstRow_userItems,"last");
}
_fb6.appendChild(item.domNode);
},_addToToolbarSecondRow:function(item,_fb7){
var _fb8=dojo.doc.createElement("span");
dojo.style(_fb8,"width","1px");
if(_fb7!==undefined){
dojo.place(_fb8,this.toolbarSecondRow,parseInt(_fb7));
}else{
dojo.place(_fb8,this.toolbarSecondRow,"last");
}
_fb8.appendChild(item.domNode);
},_removeItem:function(_fb9){
var _fba=dijit.byId(_fb9);
if(_fba!==null&&_fba!==undefined){
if(_fba.domNode.parentNode){
buttonParent=_fba.domNode.parentNode;
buttonParent.parentNode.removeChild(buttonParent);
}
_fba.destroyRecursive();
}
},_mapToolbarOptions:function(){
if(this.toolbarOptions){
if(this.toolbarOptions.refreshIcon==false){
this.refreshIcon=this.toolbarOptions.refreshIcon;
}
if(this.toolbarOptions.refreshMenu==false){
this.refreshMenu=this.toolbarOptions.refreshMenu;
}
if(this.toolbarOptions.configTableIcon==false){
this.configTableIcon=this.toolbarOptions.configTableIcon;
}
if(this.toolbarOptions.configTableMenu==false){
this.configTableMenu=this.toolbarOptions.configTableMenu;
}
if(this.toolbarOptions.actionMenu==false){
this.actionMenu=this.toolbarOptions.actionMenu;
}
}
},_addToActionList:function(item){
if(this.actionMenu){
this.actionListWidget.dropDown.addChild(item,0);
}
},_removeFromActionList:function(_fbb){
var _fbc=dijit.byId(_fbb);
if(_fbc!==null&&_fbc!==undefined){
_fbc.destroyRecursive();
}
},_enableMenuItem:function(_fbd){
var _fbe=dijit.byId(_fbd);
if(_fbe!==null&&_fbe!==undefined){
_fbe.set("disabled",false);
}
},_disableMenuItem:function(_fbf){
var _fc0=dijit.byId(_fbf);
if(_fc0!==null&&_fc0!==undefined){
_fc0.set("disabled",true);
}
},destroy:function(){
try{
delete this.resources_;
var _fc1=dijit.findWidgets(this.domNode);
dojo.forEach(_fc1,function(w){
if(w){
if(w.destroyRecursive){
w.destroyRecursive();
}else{
if(w.destroy){
w.destroy();
}
}
}
});
var _fc2=this.getChildren();
dojo.forEach(_fc2,function(_fc3){
if(_fc3){
if(_fc3.destroyRecursive){
_fc3.destroyRecursive();
}else{
if(_fc3.destroy){
_fc3.destroy();
}
}
}
});
this.inherited(arguments);
}
catch(ex){
console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
}
}});
}
if(!dojo._hasResource["dojox.collections._base"]){
dojo._hasResource["dojox.collections._base"]=true;
dojo.provide("dojox.collections._base");
dojox.collections.DictionaryEntry=function(k,v){
this.key=k;
this.value=v;
this.valueOf=function(){
return this.value;
};
this.toString=function(){
return String(this.value);
};
};
dojox.collections.Iterator=function(arr){
var a=arr;
var _fc4=0;
this.element=a[_fc4]||null;
this.atEnd=function(){
return (_fc4>=a.length);
};
this.get=function(){
if(this.atEnd()){
return null;
}
this.element=a[_fc4++];
return this.element;
};
this.map=function(fn,_fc5){
return dojo.map(a,fn,_fc5);
};
this.reset=function(){
_fc4=0;
this.element=a[_fc4];
};
};
dojox.collections.DictionaryIterator=function(obj){
var a=[];
var _fc6={};
for(var p in obj){
if(!_fc6[p]){
a.push(obj[p]);
}
}
var _fc7=0;
this.element=a[_fc7]||null;
this.atEnd=function(){
return (_fc7>=a.length);
};
this.get=function(){
if(this.atEnd()){
return null;
}
this.element=a[_fc7++];
return this.element;
};
this.map=function(fn,_fc8){
return dojo.map(a,fn,_fc8);
};
this.reset=function(){
_fc7=0;
this.element=a[_fc7];
};
};
}
if(!dojo._hasResource["dojox.collections.ArrayList"]){
dojo._hasResource["dojox.collections.ArrayList"]=true;
dojo.provide("dojox.collections.ArrayList");
dojox.collections.ArrayList=function(arr){
var _fc9=[];
if(arr){
_fc9=_fc9.concat(arr);
}
this.count=_fc9.length;
this.add=function(obj){
_fc9.push(obj);
this.count=_fc9.length;
};
this.addRange=function(a){
if(a.getIterator){
var e=a.getIterator();
while(!e.atEnd()){
this.add(e.get());
}
this.count=_fc9.length;
}else{
for(var i=0;i<a.length;i++){
_fc9.push(a[i]);
}
this.count=_fc9.length;
}
};
this.clear=function(){
_fc9.splice(0,_fc9.length);
this.count=0;
};
this.clone=function(){
return new dojox.collections.ArrayList(_fc9);
};
this.contains=function(obj){
for(var i=0;i<_fc9.length;i++){
if(_fc9[i]==obj){
return true;
}
}
return false;
};
this.forEach=function(fn,_fca){
dojo.forEach(_fc9,fn,_fca);
};
this.getIterator=function(){
return new dojox.collections.Iterator(_fc9);
};
this.indexOf=function(obj){
for(var i=0;i<_fc9.length;i++){
if(_fc9[i]==obj){
return i;
}
}
return -1;
};
this.insert=function(i,obj){
_fc9.splice(i,0,obj);
this.count=_fc9.length;
};
this.item=function(i){
return _fc9[i];
};
this.remove=function(obj){
var i=this.indexOf(obj);
if(i>=0){
_fc9.splice(i,1);
}
this.count=_fc9.length;
};
this.removeAt=function(i){
_fc9.splice(i,1);
this.count=_fc9.length;
};
this.reverse=function(){
_fc9.reverse();
};
this.sort=function(fn){
if(fn){
_fc9.sort(fn);
}else{
_fc9.sort();
}
};
this.setByIndex=function(i,obj){
_fc9[i]=obj;
this.count=_fc9.length;
};
this.toArray=function(){
return [].concat(_fc9);
};
this.toString=function(_fcb){
return _fc9.join((_fcb||","));
};
};
}
if(!dojo._hasResource["dojoe.slidingpane.SlidingPane"]){
dojo._hasResource["dojoe.slidingpane.SlidingPane"]=true;
dojo.provide("dojoe.slidingpane.SlidingPane");
dojo.require("dojo.fx");
dojo.require("dijit._Templated");
dojo.require("dijit.layout.ContentPane");
dojo.declare("dojoe.slidingpane.SlidingPane",[dijit._Widget,dijit._Templated],{widgetsInTemplate:true,templateString:dojo.cache("dojoe.slidingpane","templates/SlidingPane.html","<div class='slidingPane open' tabIndex=0 aria-label=\"slidingpane\" >\r\n\t<div dojoAttachPoint='innerDIV' aria-label=\"content inside slidingpane\">\r\n\t\t<div dojoAttachPoint='hideNode'>\r\n\t\t\t<div class='dijitReset' dojoAttachPoint='wipeNode'>\r\n\t\t\t\t<div dojoAttachPoint='containerNode'></div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n\t<div class='slidingPaneClose' dojoAttachPoint='closeNode' dojoAttachEvent=\"onclick:_toggle, onkeypress:_keyEvent\" tabIndex=0>\r\n\t</div>\r\n</div>\r\n\t\r\n"),backgroundClass:null,closeNodeClass:null,open:true,duration:500,constructor:function(){
this._resources=dojo.i18n.getLocalization("dojoe.slidingpane","SlidingPane",this.lang);
},postCreate:function(){
if(!this.open){
this.hideNode.style.display=this.wipeNode.style.display="none";
}
this._updateClass();
this.inherited("postCreate",arguments);
this.wipeNode.containerNode=this.containerNode;
if(this.backgroundClass!==null){
this.innerDIV.className=this.backgroundClass;
}
if(this.closeNodeClass!==null){
this.closeNode.className=this.closeNodeClass;
}
var _fcc=this.hideNode,_fcd=this.wipeNode;
this._wipeIn=dojo.fx.wipeIn({node:this.wipeNode,duration:this.duration,beforeBegin:function(){
_fcc.style.display="";
}});
this._wipeOut=dojo.fx.wipeOut({node:this.wipeNode,duration:this.duration,onEnd:function(){
_fcc.style.display="none";
}});
},_keyEvent:function(evt){
if(evt!=null){
var _fce=evt.keyCode;
if(_fce==13){
this._toggle();
}
}
},_toggle:function(){
dojo.forEach([this._wipeIn,this._wipeOut],function(_fcf){
if(_fcf.status()=="playing"){
_fcf.stop();
}
});
this[this.open?"_wipeOut":"_wipeIn"].play();
this.open=!this.open;
this._updateClass();
this.onClick();
},_updateClass:function(){
if(this.open){
dojo.removeClass(this.domNode,"close");
dojo.addClass(this.domNode,"open");
this.closeNode.setAttribute("title",this._resources.CLOSE);
}else{
dojo.removeClass(this.domNode,"open");
dojo.addClass(this.domNode,"close");
this.closeNode.setAttribute("title",this._resources.EXPAND);
}
},onClick:function(){
},destroy:function(){
try{
delete this._resources;
var _fd0=this.getChildren();
dojo.forEach(_fd0,function(_fd1){
if(_fd1){
if(_fd1.destroyRecursive){
_fd1.destroyRecursive();
}else{
if(_fd1.destroy){
_fd1.destroy();
}
}
}
});
this.inherited(arguments);
}
catch(ex){
console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
}
}});
}
if(!dojo._hasResource["dojoe.table.Table"]){
dojo._hasResource["dojoe.table.Table"]=true;
dojo.provide("dojoe.table.Table");
dojo.declare("dojoe.table.Table",[dijit._Widget,dijit._Templated],{templateString:dojo.cache("dojoe.table","templates/Table.html","\r\n<div class=\"tivTable\" tabIndex=0 aria-label=\"table\" role=\"application\">\r\n\t<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" height=\"100%\" \r\n\t\tstyle=\"width:100%;height:100%;\" role=\"presentation\">\t\t\r\n\t\t<tr valign=\"center\">\r\n\t\t\t<td width=\"100%\" role=\"toolbar\">\r\n\t\t\t\t<div dojoAttachPoint=\"wipeNode\">\r\n\t\t\t\t<div dojoAttachPoint=\"toolbarNode\"></div>\r\n\t\t\t\t</div>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t<tr valign=\"center\"><td width=\"100%\" role=\"grid\">\r\n\t\t\t<div  dojoAttachPoint=\"enhancedGridNode\"></div></td></tr>\t\t\r\n\t</table>\r\n</div>\t\r\n"),widgetsInTemplate:true,toolbarVisible:true,toolbarOptions:null,filterOptions:null,enableResize:false,gridParams:null,grid:null,defaultExportFormatter:true,pageSizeArr:null,width:"",height:"",_toolbar:null,_defaultHeight:"70%",_defaultWidth:"80%",footerDescription:true,footerVisible:true,resources_:null,_previousSize:null,_resizing:false,enableCollapsibleToolbar:false,toolbarExpand:true,constructor:function(){
this.filterOptions={};
this.resources_=dojo.i18n.getLocalization("dojoe.table","Table",this.lang);
this.pageSizeArr=["5","10","25","50","100","All"];
},postCreate:function(){
if(this.width===""&&!this.gridParams.autoWidth){
this.width=this._defaultWidth;
}
if(this.height===""){
this.height=this._defaultHeight;
}
var size=dijit.getViewport();
var _fd2=this.height;
var _fd3=this.height.substring(this.height.length-1,this.height.length);
if(_fd3=="%"){
_fd2=size.h*((parseInt(this.height.slice(0,-1)))/100);
_fd2=_fd2+"px";
}
if(!this.gridParams.autoWidth){
dojo.style(this.domNode,"width",this.width);
}
dojo.style(this.domNode,"height",_fd2);
this._makeGrid();
if(this.toolbarVisible){
this._toolbar=new dojoe.table._Toolbar({tivTable:this},this.toolbarNode);
if(this.enableCollapsibleToolbar){
this.slidingPane=new dojoe.slidingpane.SlidingPane({closeNodeClass:"slidingPaneClose",open:this.toolbarExpand},this.wipeNode);
dojo.connect(this.slidingPane,"onClick",dojo.hitch(this,"slidingPaneClicked"));
}
}
this.resize();
if(this.enableResize===true){
this.connect(window,"onresize","resize");
}
if(this._toolbar&&this._toolbar.actionListWidget){
this.connect(this._toolbar.actionListWidget,"openDropDown",dojo.hitch(this,"onActionListOpen"));
this.connect(this._toolbar.actionListWidget,"closeDropDown",dojo.hitch(this,"onActionListClose"));
}
setTimeout(dojo.hitch(this,"onTableLoad",this),1000);
},onTableLoad:function(_fd4){
},onActionListOpen:function(){
},onActionListClose:function(){
},_makeGrid:function(){
this._mapGridParams();
if(this.gridParams.plugins.exporter===true&&!this.gridParams.plugins.printer){
var _fd5=this.gridParams;
_fd5.plugins.printer=true;
this.grid=new dojox.grid.EnhancedGrid(_fd5,this.enhancedGridNode);
delete _fd5.plugins.printer;
}else{
this.grid=new dojox.grid.EnhancedGrid(this.gridParams,this.enhancedGridNode);
}
if(this.gridParams.preFilter){
this.setFilter(this.gridParams.preFilter,this.gridParams.preFilter.hideFilterBar);
}
if(!this.gridParams.noDataMessage){
this.grid.noDataMessage=this.resources_.NO_DATA;
}else{
this.grid.noDataMessage=this.gridParams.noDataMessage;
}
if(this.gridParams.selectable==undefined&&this.gridParams.plugins.selector&&this.gridParams.plugins.selector.cell!=="disabled"){
this.grid.selectable=true;
}else{
this.grid.selectable=this.gridParams.selectable;
}
this.grid.startup();
this.grid.plugins&&dojo.mixin(this.grid,this.grid.plugins);
if(this.grid.plugin("dnd")){
this.grid.plugin("dnd").copyOnly(true);
this.grid.plugin("dnd").setupConfig({"within":true,"in":true,"out":true});
}
},resize:function(_fd6){
var _fd7=false;
if(_fd6&&_fd6.currentTarget){
_fd7=true;
}
var size=dijit.getViewport();
if(this._previousSize&&this._previousSize.h==size.h&&this._previousSize.w==size.w&&_fd7==true){
return;
}else{
this._previousSize=size;
}
if(!this.grid||!this.domNode||!this.domNode.parentNode||this.domNode.parentNode.nodeType!=1){
return;
}
if(!this.grid.autoWidth){
dojo.style(this.domNode,"width",this.width);
}else{
dojo.style(this.domNode,"width",dojo.marginBox(this.grid.domNode).w+"px");
}
var _fd8=this.height;
if(!(this.domNode.parentNode.style&&this.domNode.parentNode.style.height)){
var _fd9=this.height.substring(this.height.length-1,this.height.length);
if(_fd9=="%"){
_fd8=size.h*((parseInt(this.height.slice(0,-1)))/100);
_fd8=_fd8+"px";
}
}
dojo.style(this.domNode,"height",_fd8);
setTimeout(dojo.hitch(this,function(){
this._delayResize(_fd7);
}),100);
},_delayResize:function(_fda){
var _fdb=dojo.marginBox(this.domNode);
var _fdc=this.grid._getPadBorder().h;
if(this._toolbar){
var _fdd=dojo.marginBox(this._toolbar.domNode);
_fdb.h=_fdb.h-_fdd.h-(2*_fdc);
}
if((_fdb.h<=0||_fdb.w<=0)){
return;
}
if(_fda){
this.grid.resize({h:_fdb.h,w:_fdb.w});
}else{
if(dojo.isIE==7){
this.grid.resize({h:_fdb.h,w:_fdb.w});
}else{
this.grid.resize({h:_fdb.h});
}
}
var _fde=this.height;
if(this.enableCollapsibleToolbar){
if(this.slidingPane!=null&&!this.slidingPane.open){
_fdb.h=parseInt(_fde)-8;
this.grid.resize({h:_fdb.h});
}
}
this._resizing=false;
},_mapGridParams:function(){
this.gridParams.keepSelection=true;
if(this.gridParams.plugins.pagination){
this.gridParams.plugins.pagination={pageSizes:this.pageSizeArr,description:this.footerDescription,sizeSwitch:true,pageStepper:true,gotoButton:true,maxPageStep:10,position:"bottom"};
}else{
if(this.footerVisible){
this.gridParams.plugins.pagination={description:this.footerDescription,sizeSwitch:false,pageStepper:false,gotoButton:false,position:"bottom",descTemplate:"${1} ${0}"};
}
}
if(this.gridParams.plugins.indirectSelection&&this.gridParams.plugins.indirectSelection.headerSelector==undefined){
if(this.gridParams.plugins.indirectSelection instanceof Object){
dojo.mixin(this.gridParams.plugins.indirectSelection,{"headerSelector":true});
}else{
this.gridParams.plugins.indirectSelection={"headerSelector":true};
}
}
if(this.gridParams.plugins.filter!==undefined){
this.gridParams.plugins.filter.closeFilterbarButton=true;
if(this.gridParams.preFilter){
this.filterOptions.hideFilterBar=false;
}else{
this.filterOptions.hideFilterBar=true;
}
if(this.gridParams.plugins.filter.advancedFilter!==undefined){
this.filterOptions.showAdvancedFilter=this.gridParams.plugins.filter.advancedFilter;
delete this.gridParams.plugins.filter.advancedFilter;
}
if(this.gridParams.plugins.filter.quickFilter!==undefined){
this.filterOptions.showQuickFilter=this.gridParams.plugins.filter.quickFilter;
delete this.gridParams.plugins.filter.quickFilter;
}
if(this.gridParams.plugins.filter.showQuickFilterButton!==undefined){
this.filterOptions.showQuickFilterButton=this.gridParams.plugins.filter.showQuickFilterButton;
delete this.gridParams.plugins.filter.showQuickFilterButton;
}
if(this.gridParams.plugins.filter.searchDelay!==undefined){
this.filterOptions.searchDelay=this.gridParams.plugins.filter.searchDelay;
}
if(this.gridParams.plugins.filter.retainSelection!==undefined){
this.filterOptions.retainSelection=this.gridParams.plugins.filter.retainSelection;
}
this.gridParams.plugins.filter=this.gridParams.plugins.filter;
}
if(this.gridParams.plugins.printer){
this.gridParams.plugins.printer=this.gridParams.plugins.printer;
}else{
delete this.gridParams.plugins.printer;
}
if(this.gridParams.plugins.exporter!==undefined){
this.gridParams.plugins.exporter=this.gridParams.plugins.exporter;
}
},getRowCount:function(){
return this.grid.rowCount;
},getSelectedRowCount:function(){
return this.grid.selection.getSelectedCount();
},getSelectedRows:function(){
return this.grid.selection.getSelected();
},getFilter:function(_fdf){
var _fe0=this.grid.getFilter();
if(_fdf){
for(var i=0;i<_fe0.length;i++){
if(this._isInt(_fe0[i].column)){
_fe0[i].column=this._getColumnField(_fe0[i].column);
}
}
}
var _fe1=this.getFilterRelation();
_fe0.ruleRelation=_fe1;
return _fe0;
},getFilterRelation:function(){
if(this.grid){
return this.grid.getFilterRelation();
}
},_getColumnName:function(_fe2){
return this.grid.layout.cells[_fe2].name;
},_getColumnField:function(_fe3){
return this.grid.layout.cells[_fe3].field;
},_isInt:function(_fe4){
if((parseFloat(_fe4)==parseInt(_fe4))&&!isNaN(_fe4)){
return true;
}else{
return false;
}
},_getColumnIndex:function(_fe5){
var _fe6=this.grid.layout.cells;
for(var i=_fe6.length-1;i>=0;--i){
var cell=_fe6[i];
if(cell.field==_fe5){
return i;
}
}
return null;
},setFilter:function(_fe7,_fe8){
if(this.grid.setFilter){
var _fe9=new dojox.collections.ArrayList();
if(_fe7){
for(var i=0;i<_fe7.length;i++){
var _fea=_fe7[i];
if(_fea.value){
if((_fea.column)&&(this._isInt(_fea.column)==false)){
_fea.column=this._getColumnIndex(_fea.column);
}
var _feb={"type":_fea.type?_fea.type:"string","column":_fea.column?_fea.column:"anycolumn","value":_fea.value,"condition":_fea.condition?_fea.condition:"contains"};
_fe9.add(_feb);
}
}
var _fec=_fe9.toArray();
var _fed=_fe7.ruleRelation;
if(_fed){
this.grid.setFilter(_fec,_fed);
}else{
this.grid.setFilter(_fec);
}
}else{
this.clearFilter();
}
if(_fe8==true){
this.grid.showFilterBar(false);
}else{
this.grid.showFilterBar(true);
}
}
},clearFilter:function(_fee){
if(this._toolbar&&this._toolbar._quickFilter){
this._toolbar._quickFilter._clearQuickFilter();
}
if(this.grid.getFilter().length>0){
this.grid.setFilter(null);
}
if(_fee==true){
this.grid.showFilterBar(false);
}
},removeSelectedRows:function(){
this.grid.removeSelectedRows();
},deleteAllRows:function(){
var _fef=this.grid.rowCount;
for(var i=0;i<_fef;i++){
this.deleteRow(i);
}
},deleteRow:function(_ff0){
var _ff1=this.grid.store;
var _ff2=this.grid;
_ff1.fetch({query:{},onComplete:function(_ff3,_ff4){
for(i=0;i<_ff3.length;i++){
var item=_ff3[i];
if(item){
_ff1.deleteItem(item);
}
}
_ff2._refresh(0,true);
}});
},addToActionList:function(item){
if(this._toolbar){
this._toolbar._addToActionList(item);
}
},addToToolbar:function(item,_ff5,row,_ff6){
if(this._toolbar){
if(row&&row==2){
this._toolbar._addToToolbarSecondRow(item,_ff5);
}else{
this._toolbar._addToToolbarFirstRow(item,_ff5);
}
if(_ff6==false){
}else{
this.resize();
}
}
},addItemsToToolbar:function(_ff7,_ff8,row,_ff9){
if(this._toolbar){
for(var i=0;i<_ff7.length;i++){
if(row&&row==2){
this._toolbar._addToToolbarSecondRow(_ff7[i],_ff8+i);
}else{
this._toolbar._addToToolbarFirstRow(_ff7[i],_ff8+i);
}
}
if(_ff9==false){
}else{
this.resize();
}
}
},addCustomMenuToTable:function(_ffa,_ffb){
if(_ffa=="headerMenu"){
var _ffc=this.grid.headerMenu;
if(_ffc){
_ffc.destroyRecursive();
}
this.grid.plugins.menus.headerMenu=_ffb.id;
this.grid.headerMenu=_ffb;
}else{
if(_ffa=="rowMenu"){
var _ffc=this.grid.rowMenu;
if(_ffc){
_ffc.destroyRecursive();
}
this.grid.plugins.menus.rowMenu=_ffb.id;
this.grid.rowMenu=_ffb;
}else{
if(_ffa=="cellMenu"){
var _ffc=this.grid.cellMenu;
if(_ffc){
_ffc.destroyRecursive();
}
this.grid.plugins.menus.cellMenu=_ffb.id;
this.grid.cellMenu=_ffb;
}else{
if(_ffa=="selectedRegionMenu"){
var _ffc=this.grid.selectedRegionMenu;
if(_ffc){
_ffc.destroyRecursive();
}
this.grid.plugins.menus.selectedRegionMenu=_ffb.id;
this.grid.selectedRegionMenu=_ffb;
}
}
}
}
},removeFromActionList:function(_ffd){
if(this._toolbar){
this._toolbar._removeFromActionList(_ffd);
}
},enableMenuItem:function(_ffe){
if(this._toolbar){
this._toolbar._enableMenuItem(_ffe);
}
},disableMenuItem:function(_fff){
if(this._toolbar){
this._toolbar._disableMenuItem(_fff);
}
},removeItemFromToolbar:function(_1000){
if(this._toolbar){
this._toolbar._removeItem(_1000);
}
},refresh:function(){
if(this.grid){
if(this.grid.store.CURIRefresh){
this.grid.store.CURIRefresh();
}
var _1001=this.grid.scrollTop;
if(this.grid.getFilter){
var _1002=this.grid.pluginMgr.getPlugin("filter").ruleCountToConfirmClearFilter;
this.grid.pluginMgr.getPlugin("filter").ruleCountToConfirmClearFilter=Infinity;
var _1003=this.getFilter();
var _1004=this.getFilterRelation();
this.grid.setFilter(_1003,_1004);
this.grid.pluginMgr.getPlugin("filter").ruleCountToConfirmClearFilter=_1002;
}else{
this.grid._refresh(true);
}
this.grid.setScrollTop(_1001);
}
},addRow:function(item){
if(this.grid){
this.clearSort();
this.clearFilter();
var g=this.grid;
setTimeout(function(){
var _1005=g.store.newItem(item);
var _1006=g.getTotalRowCount?g.getTotalRowCount()-1:g.getItemIndex(_1005);
g.scrollToRow(_1006);
},10);
}
},clearSort:function(){
this.grid.setSortIndex([]);
},slidingPaneClicked:function(){
this.resize();
},destroy:function(){
try{
delete this.resources_;
var _1007=dijit.findWidgets(this.domNode);
dojo.forEach(_1007,function(w){
if(w){
if(w.destroyRecursive){
w.destroyRecursive();
}else{
if(w.destroy){
w.destroy();
}
}
}
});
var _1008=this.getChildren();
dojo.forEach(_1008,function(child){
if(child){
if(child.destroyRecursive){
child.destroyRecursive();
}else{
if(child.destroy){
child.destroy();
}
}
}
});
this.inherited(arguments);
}
catch(ex){
console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
}
}});
}
if(!dojo._hasResource["dojoe.table.TableAll"]){
dojo._hasResource["dojoe.table.TableAll"]=true;
dojo.provide("dojoe.table.TableAll");
dojo.require("dojoe.mapping");
dojo.require("dojoe.table.Table");
dojo.require("dojoe.table._TableOptions");
dojo.require("dojoe.table._Toolbar");
dojo.require("dojoe.table._ConfigureColumnsDialog");
dojo.require("dojoe.table._QuickFilter");
}
dojo.i18n._preloadLocalizations("dojoe.table.nls.TableAll",["ROOT","ar","cs","da","de","es","fi","fr","he","hr","hu","it","ja","ko","nb","nl","pl","pt","pt-br","ru","sl","sv","tr","xx","zh","zh-tw"]);
