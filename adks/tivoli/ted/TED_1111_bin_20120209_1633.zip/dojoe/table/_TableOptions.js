/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.table._TableOptions"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.table._TableOptions"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.table._TableOptions");

dojo.require("dijit._Widget");
dojo.require("dijit._Templated");
dojo.require("dijit._Container");
dojo.require("dijit.form.CheckBox");

// NLS
dojo.requireLocalization("dojoe.table", "Table", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");
// define the widget class
dojo.declare (
	"dojoe.table._TableOptions",[ dijit._Widget, dijit._Container ],{
    grid: null,
	constructor: function() {
		// summary: A reusable widget for displaying a dynamic set of parameters to be 
		//  filled in at runtime.
	    this.resources_ = dojo.i18n.getLocalization("dojoe.table", "Table", this.lang);
	},
	postCreate: function() { 
		this.inherited ("postCreate", arguments);	
		/*LS - 13/01/2012 - 30956 - Unresponsive script msg when using configure options */	
		//removing the indirect way of fetching columns through grid structure and getting it through layout.cells directly
		// this is improve performance of this feature reducing no of iterations...
		this.addColumnsVisible(this.grid.layout.cells);
	},
	addColumnsVisible: function (columns) {		
		var widget = null;
		var column = null;
		for (var i in columns) {
			if (i) {
				column = columns[i];
				if (column.field) {
					widget = new dojoe.table.ColumnVisible ({
						id: this.id + "column_" + column.field,
						columnid: this.id + "column_" + column.field,
						checked: column.visible===undefined?!column.hidden:column.visible,  
						label: column.name
					});
					this.addChild(widget);
					//console.log ("added column widget");
				} else {
					//console.log ("this column was created internally by data store.  do not show it.");
				}
			}
		}
	},	
	onSelectAll: function(){		
		//for(var j=0; j<this.grid.structure.length; j++) {
			//var columns = this.grid.structure[j].rows;	
			//Anupama :24May11, replacing for..in construct with regular for loop since for..in construct interfering with changes in Array prototype in IE7.
			//26600: select all,de-select all feature in Table configure options dialog not working on IE7 browser.
			//for (var i in columns) {
			/*LS - 13/01/2012 - 30956 - Unresponsive script msg when using configure options */	
			//removing the indirect way of fetching columns through grid structure and getting it through layout.cells directly
			// this is improve performance of this feature reducing no of iterations...
			for(var k=0; k<this.grid.layout.cells.length; k++) {
				var column = this.grid.layout.cells[k];
				if (column && column.field) {
					var columnWidget = dijit.byId (this.id + "column_" +column.field);
					columnWidget.setVisible(true);	 
				}
			}		
		//}
	},
	onDeselectAll: function(){
		//for(var j=0; j<this.grid.structure.length; j++) {
			//var columns = this.grid.structure[j].rows;
			//Anupama :24May11, replacing for..in construct with regular for loop since for..in construct interfering with changes in Array prototype in IE7.
			//26600: select all,de-select all feature in Table configure options dialog not working on IE7 browser.
			//for (var i in columns) {
			/*LS - 13/01/2012 - 30956 - Unresponsive script msg when using configure options */	
			//removing the indirect way of fetching columns through grid structure and getting it through layout.cells directly
			// this is improve performance of this feature reducing no of iterations...
			for(var k=0; k<this.grid.layout.cells.length; k++) {
				var column = this.grid.layout.cells[k];
				if (column && column.field) {
					var columnWidget = dijit.byId (this.id + "column_" + column.field);
					columnWidget.setVisible(false);	 
				}
			}
		//}
	},
	onSave: function(){
	/*LS - 13/01/2012 - 30956 - Unresponsive script msg when using configure options */	
		//removing the indirect way of fetching columns through grid structure and getting it through layout.cells directly
		// this is improve performance of this feature reducing no of iterations...	
	
		for(var k=0; k<this.grid.layout.cells.length; k++) {
			var column = this.grid.layout.cells[k];
			if(column && column.field) {
				var tblColumn = column;
				tblColumn.width = tblColumn.unitWidth;
				column.width = tblColumn.unitWidth;
				var columnWidget = dijit.byId (this.id + "column_" + column.field);
				column.hidden = !(columnWidget.isVisible());
				//do not use setColumnVisibility, as each call for each cell makes a view update which is a overkill...
				//this.grid.layout.setColumnVisibility(k, columnWidget.isVisible());
				this.grid.layout.cells[k].hidden = column.hidden;	
				
			}
		}	
	/*Ls - 17/01/2012 - 30956 - further reducing the time taken to hide/show columns*/
		this.grid.views.forEach(function(v,i){
			var w = v.width;
			if(w && w != "auto"){
				v._togglingColumn = dojo.marginBox(v.structure.cells[0].getHeaderNode()).w || 0;
			}
			v.update();
		});			
	},
	
	isColumnVisible: function (columnID) {
		var columnWidget = dijit.byId (this.id + "column_" + columnID);
		return (columnWidget.isVisible());
	}	
});

// define the widget class
dojo.declare (
	"dojoe.table.ColumnVisible", [ dijit._Widget, dijit._Templated ],{
	columnid: null,
	label: null,
	checked: false,
	widgetsInTemplate: true,
	// Path to the template
	templateString : dojo.cache("dojoe.table", "templates/ColumnVisible.html", "<div>\r\n\t<input dojoType=\"dijit.form.CheckBox\" dojoAttachPoint=\"checkbox\" name=\"${columnid}CB\" id=\"${columnid}CB\" value=\"\" role=\"checkbox\" />\r\n\t\t&#160;\r\n\t<label for=\"${columnid}CB\">${label}</label>\r\n</div>\r\n"),		
	constructor: function () {		
	},
	postCreate: function () {		
		if (this.checked) {
			this.checkbox.setChecked (this.checked);
		    //Defect 27350: Safari:In Table, Select All/ Deselect All for config columns popup does not work as expected for safari browser.
		    //Anupama -  workaround, adding a fake event
		    dijit.byId(this.checkbox.id.toString()).set("disabled", true);
		    dijit.byId(this.checkbox.id.toString()).set("disabled", false);
		}		
	},
	setVisible: function (checked) {
		this.checkbox.setChecked (checked);
		//Defect 27350: Safari:In Table, Select All/ Deselect All for config columns popup does not work as expected for safari browser.
		//Anupama -  workaround, adding a fake event
		dijit.byId(this.checkbox.id.toString()).set("disabled", true);
		dijit.byId(this.checkbox.id.toString()).set("disabled", false);
	},
	isVisible: function () {
		return this.checkbox.checked;
		
	},
	destroy: function () {		
		//memory leak issue: custom destroy method to take care of removing all widgets					
		try{
			delete this.resources_;
			//this is for destroying child templated widgets 
			//this should happen by itself but need to figure out why dijit._Templated is not taking care of it...
			var widgets = dijit.findWidgets(this.domNode);
			dojo.forEach(widgets, function(w) {
				if(w){
					if(w.destroyRecursive){
						w.destroyRecursive();
					} else if(w.destroy){
						w.destroy();
					}
				}
			});
			// this is for widgets added as child to this widget and their children..
			//not present in template
			var widgetArr = this.getChildren();
			dojo.forEach(widgetArr, function (child) {
				if(child){
					if(child.destroyRecursive){
						child.destroyRecursive();
					} else if(child.destroy){
						child.destroy();
					}
				}
			});
			this.inherited(arguments);
		}catch(ex){
			console.warn("Widget destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
		}
	}	
});



}
