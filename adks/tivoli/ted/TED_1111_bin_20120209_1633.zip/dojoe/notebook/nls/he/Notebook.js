/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"לא","CANCEL":"ביטול","CLOSE":"סגירה","CLOSE_CONFIRM":"האם ברצונכם לסגור?","APPLY":"החלה","OK_CONFIRM":"האם ברצונכם להחיל את השינויים ולסגור?","CANCEL_CONFIRM":"האם ברצונכם לבטל את השינויים ולסגור?","OK":"אישור","CONFIRM_YES":"כן"})