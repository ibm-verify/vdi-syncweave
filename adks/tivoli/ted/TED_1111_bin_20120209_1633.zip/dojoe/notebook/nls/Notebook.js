/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"No","CANCEL":"Cancel","CLOSE":"Close","CLOSE_CONFIRM":"Do you want to close?","APPLY":"Apply","OK_CONFIRM":"Do you want to apply the changes and close?","CANCEL_CONFIRM":"Do you want to cancel the changes and close?","OK":"OK","CONFIRM_YES":"Yes"})