/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Ne","CANCEL":"Opoziv","CLOSE":"Zatvori","CLOSE_CONFIRM":"Želite li zatvoriti?","APPLY":"Primijeni","OK_CONFIRM":"Želite li primijeniti promjene i zatvoriti?","CANCEL_CONFIRM":"Želite li opozvati promjene i zatvoriti?","OK":"OK","CONFIRM_YES":"Da"})