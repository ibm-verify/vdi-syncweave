/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nei","CANCEL":"Avbryt","CLOSE":"Lukk","CLOSE_CONFIRM":"Vil du lukke?","APPLY":"Bruk","OK_CONFIRM":"Vil du ta i bruk endringene og lukke?","CANCEL_CONFIRM":"Vil du lukke uten å ta i bruk endringene?","OK":"OK","CONFIRM_YES":"Ja"})