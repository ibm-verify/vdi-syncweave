/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Non","CANCEL":"Annuler","CLOSE":"Fermer","CLOSE_CONFIRM":"Voulez-vous fermer ?","APPLY":"Appliquer","OK_CONFIRM":"Voulez-vous appliquer les modifications et fermer ?","CANCEL_CONFIRM":"Voulez-vous annuler les modifications et fermer ?","OK":"OK","CONFIRM_YES":"Oui"})