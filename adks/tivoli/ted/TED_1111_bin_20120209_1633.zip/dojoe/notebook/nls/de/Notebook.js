/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nein","CANCEL":"Abbrechen","CLOSE":"Schließen","CLOSE_CONFIRM":"Schließen?","APPLY":"Anwenden","OK_CONFIRM":"Änderungen anwenden und Fenster schließen?","CANCEL_CONFIRM":"Änderungen abbrechen und Fenster schließen?","OK":"OK","CONFIRM_YES":"Ja"})