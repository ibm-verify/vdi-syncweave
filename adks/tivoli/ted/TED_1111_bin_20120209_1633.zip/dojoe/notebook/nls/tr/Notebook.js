/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Hayır","CANCEL":"İptal","CLOSE":"Kapat","CLOSE_CONFIRM":"Kapatmak istiyor musunuz?","APPLY":"Uygula","OK_CONFIRM":"Değişiklikleri uygulayıp kapatmak istiyor musunuz?","CANCEL_CONFIRM":"Değişiklikleri iptal edip kapatmak istiyor musunuz?","OK":"Tamam","CONFIRM_YES":"Evet"})