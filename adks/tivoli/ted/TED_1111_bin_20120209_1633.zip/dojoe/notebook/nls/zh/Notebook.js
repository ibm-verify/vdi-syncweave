/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"否","CANCEL":"取消","CLOSE":"关闭","CLOSE_CONFIRM":"是否要关闭？","APPLY":"应用","OK_CONFIRM":"是否要应用更改并关闭？","CANCEL_CONFIRM":"是否要取消更改并关闭？","OK":"确定","CONFIRM_YES":"是"})