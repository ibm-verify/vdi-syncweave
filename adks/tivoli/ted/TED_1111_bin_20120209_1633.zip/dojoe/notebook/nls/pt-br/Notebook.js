/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Não","CANCEL":"Cancelar","CLOSE":"Fechar","CLOSE_CONFIRM":"Você deseja fechar?","APPLY":"Aplicar","OK_CONFIRM":"Você deseja aplicar as alterações e fechar?","CANCEL_CONFIRM":"Você deseja cancelar as alterações e fechar?","OK":"OK","CONFIRM_YES":"Sim"})