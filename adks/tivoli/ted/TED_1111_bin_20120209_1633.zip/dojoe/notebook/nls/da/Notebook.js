/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nej","CANCEL":"Annullér","CLOSE":"Luk","CLOSE_CONFIRM":"Vil du lukke?","APPLY":"Anvend","OK_CONFIRM":"Vil du anvende ændringerne og lukke?","CANCEL_CONFIRM":"Vil du annullere ændringerne og lukke?","OK":"OK","CONFIRM_YES":"Ja"})