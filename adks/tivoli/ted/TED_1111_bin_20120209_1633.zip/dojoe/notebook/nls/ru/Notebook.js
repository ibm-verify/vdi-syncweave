/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Нет","CANCEL":"Отмена","CLOSE":"Закрыть","CLOSE_CONFIRM":"Закрыть?","APPLY":"Применить","OK_CONFIRM":"Применить изменения и закрыть?","CANCEL_CONFIRM":"Отменить изменения и закрыть?","OK":"ОК","CONFIRM_YES":"Да"})