/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nem","CANCEL":"Mégse","CLOSE":"Bezárás","CLOSE_CONFIRM":"Bezárja az ablakot?","APPLY":"Alkalmaz","OK_CONFIRM":"Alkalmazza a módosításokat, és bezárja az ablakot?","CANCEL_CONFIRM":"Visszavonja a módosításokat, és bezárja az ablakot?","OK":"OK","CONFIRM_YES":"Igen"})