/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Ne","CANCEL":"Prekliči","CLOSE":"Zapri","CLOSE_CONFIRM":"Ali želite zapreti?","APPLY":"Uveljavi","OK_CONFIRM":"Ali želite uveljaviti spremembe in zapreti?","CANCEL_CONFIRM":"Ali želite preklicati spremembe in zapreti?","OK":"V redu","CONFIRM_YES":"Da"})