/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"아니오","CANCEL":"취소","CLOSE":"닫기","CLOSE_CONFIRM":"닫으시겠습니까?","APPLY":"적용","OK_CONFIRM":"이 변경을 적용하고 닫으시겠습니까?","CANCEL_CONFIRM":"이 변경을 취소하고 닫으시겠습니까?","OK":"확인","CONFIRM_YES":"예"})