/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"No","CANCEL":"Annulla","CLOSE":"Chiudi","CLOSE_CONFIRM":"Chiudere?","APPLY":"Applica","OK_CONFIRM":"Applicare le modifiche e chiudere?","CANCEL_CONFIRM":"Annullare le modifiche e chiudere?","OK":"OK","CONFIRM_YES":"Sì"})