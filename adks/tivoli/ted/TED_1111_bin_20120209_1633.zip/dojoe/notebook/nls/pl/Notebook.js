/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nie","CANCEL":"Anuluj","CLOSE":"Zamknij","CLOSE_CONFIRM":"Czy chcesz zamknąć?","APPLY":"Zastosuj","OK_CONFIRM":"Czy chcesz zastosować zmiany i zamknąć?","CANCEL_CONFIRM":"Czy chcesz anulować zmiany i zamknąć?","OK":"OK","CONFIRM_YES":"Tak"})