/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Ei","CANCEL":"Peruuta","CLOSE":"Sulje","CLOSE_CONFIRM":"Haluatko sulkea?","APPLY":"Käytä","OK_CONFIRM":"Haluatko ottaa muutokset käyttöön ja sulkea ikkunan?","CANCEL_CONFIRM":"Haluatko peruuttaa muutokset ja sulkea ikkunan?","OK":"OK","CONFIRM_YES":"Kyllä"})