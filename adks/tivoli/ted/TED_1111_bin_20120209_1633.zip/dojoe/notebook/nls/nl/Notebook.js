/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nee","CANCEL":"Annuleren","CLOSE":"Sluiten","CLOSE_CONFIRM":"Wilt u afsluiten?","APPLY":"Toepassen","OK_CONFIRM":"Wilt u de wijzigingen toepassen en afsluiten?","CANCEL_CONFIRM":"Wilt u de wijzigingen annuleren en afsluiten?","OK":"OK","CONFIRM_YES":"Ja"})