/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Nej","CANCEL":"Avbryt","CLOSE":"Stäng","CLOSE_CONFIRM":"Vill du stänga? ","APPLY":"Tillämpa","OK_CONFIRM":"Vill du tillämpa ändringarna och stänga? ","CANCEL_CONFIRM":"Vill du avbryta ändringarna och stänga? ","OK":"OK","CONFIRM_YES":"Ja"})