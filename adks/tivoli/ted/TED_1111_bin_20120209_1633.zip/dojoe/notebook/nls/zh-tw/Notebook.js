/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"否","CANCEL":"取消","CLOSE":"關閉","CLOSE_CONFIRM":"您要關閉嗎？","APPLY":"套用","OK_CONFIRM":"您要套用變更並關閉嗎？","CANCEL_CONFIRM":"您要取消變更並關閉嗎？","OK":"確定","CONFIRM_YES":"是"})