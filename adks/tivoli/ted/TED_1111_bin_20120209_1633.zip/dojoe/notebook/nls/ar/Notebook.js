/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"لا","CANCEL":"الغاء","CLOSE":"اغلاق","CLOSE_CONFIRM":"هل تريد الاغلاق؟","APPLY":"تطبيق","OK_CONFIRM":"هل تريد تطبيق التغييرات والاغلاق؟","CANCEL_CONFIRM":"هل تريد الغاء التغييرات والاغلاق؟","OK":"حسنا","CONFIRM_YES":"نعم"})