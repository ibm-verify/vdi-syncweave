/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"Ne","CANCEL":"Storno","CLOSE":"Zavřít","CLOSE_CONFIRM":"Chcete provést zavření?","APPLY":"Použít","OK_CONFIRM":"Chcete použít změny a provést zavření?","CANCEL_CONFIRM":"Chcete zrušit změny a provést zavření?","OK":"OK","CONFIRM_YES":"Ano"})