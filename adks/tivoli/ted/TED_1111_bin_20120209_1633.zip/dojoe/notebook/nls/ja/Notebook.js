/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
({"CONFIRM_NO":"いいえ","CANCEL":"キャンセル","CLOSE":"クローズ","CLOSE_CONFIRM":"閉じますか?","APPLY":"適用","OK_CONFIRM":"変更を適用してから閉じますか?","CANCEL_CONFIRM":"変更を取り消してから閉じますか?","OK":"OK","CONFIRM_YES":"はい"})