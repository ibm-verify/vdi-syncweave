/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/

if(!dojo._hasResource["dojoe.notebook.Notebook"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojoe.notebook.Notebook"] = true;
/*********************************************************** {COPYRIGHT-TOP} ***
* Licensed Materials - Property of IBM
* Tivoli Extensions for Dojo
*
* (C) Copyright IBM Corp. 2011.  All Rights Reserved.
*
* US Government Users Restricted Rights - Use, duplication, or
* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
************************************************************ {COPYRIGHT-END} **/
dojo.provide("dojoe.notebook.Notebook");

dojo.require("dijit._Widget");
dojo.require("dijit._Templated");
dojo.require("dijit.layout.TabContainer");
dojo.require("dijit.layout.BorderContainer");
dojo.require("dijit.layout.ContentPane");
dojo.require("dojo.i18n");
dojo.requireLocalization("dojoe.notebook", "Notebook", null, "ROOT,ar,cs,da,de,es,fi,fr,he,hr,hu,it,ja,ko,nb,nl,pl,pt-br,ru,sl,sv,tr,zh,zh-tw");
dojo.require("dojoe.wizard.Page");
dojo.require("dojoe.messagedialog.MessageDialog");

/**
 * Inherit from TivPageContainer which contains the common functions of both
 * the notebook and wizard.
 */
dojo.require("dojoe.wizard.PageContainer");

/*
 * Creating a TivNotebook in markup
 * <div id="note" dojoType="dojoe.notebook.Notebook">
 *    <div dojoType="support.notebook.nbpages.Welcome"></div>
 *    <div dojoType="support.notebook.nbpages.BaseWidget"></div>
 *    <div dojoType="support.notebook.nbpages.General"></div>
 *    <div dojoType="support.notebook.nbpages.Security"></div>
 *    <div dojoType="support.notebook.nbpages.Summary" ></div>
 *  </div> 
 * 
 * Events:
 *  OnPageSelected: when a page is made active
 *  AfterPageSelected: after a page has been made active
 *  OnOK: when the OK button is clicked
 *  OnApply: when the Apply button is clicked
 *  OnCancel: when the Cancel button is clicked
 */
dojo.declare("dojoe.notebook.Notebook", 
            [dijit._Widget, dijit._Templated, dojoe.wizard.PageContainer],
	{

		// summary:  Notebook is a widget   used to show information about an object in a tabbed form.
		// description: Notebook widget uses the dojoe.wizard.PageContainer for its implementation.
		//		Pages can be created by extending dojoe.wizard.Page.
		

		// widgetsInTemplate: [public]Boolean
		//		Set this to true if the widget contains other widgets
		widgetsInTemplate: true,
	  
		// templatePath:  [private]String
		//		Path to the template
		templatePath: "",
		
		// mode:  [private]String
		//		creation mode default is n for notebook
		mode: "n",           

		// applyLabel: [public]String
		//		label of apply button.
		applyLabel: "",
		
		// okLabel: [public]String
		//		label of ok button.
		okLabel: "",  
		
		// cancelLabel: [public]String
		//		label of cancel button.
		cancelLabel: "",  
		
		// _origApply: [private]Object
		//		object for onApply event.
		_origApply: null,
  
		constructor: function () {
			this._origApply = this.OnApply;
			this._resources = dojo.i18n.getLocalization("dojoe.notebook", "Notebook", this.lang);
		},

		postMixInProperties: function () {
			// summary:  Creates and initialises the Notebook.
			// tags: private
				
			if (this.nested) {
				this.templateString="<div class=\"tiv-notebook\" role=\"application\">\r\n  <div dojoType=\"dijit.layout.BorderContainer\" design=\"headline\" gutters=\"false\" class=\"tiv-notebook-outer\" dojoAttachPoint=\"_outerContainer\">\r\n    <div dojoType=\"dijit.layout.BorderContainer\" gutters=\"false\" liveSplitters=\"false\" design=\"sidebar\" region=\"center\" style=\"width:100%;height:100%;\" dojoAttachPoint=\"_borderArea\">\r\n      <div dojoType=\"dijit.layout.ContentPane\" region=\"leading\" splitter=\"false\" class=\"tiv-notebook-toc\" dojoAttachPoint=\"_tocArea\">\r\n        <ol dojoAttachPoint=\"_toc\"></ol>\r\n      </div>\r\n      <div dojoType=\"dijit.layout.TabContainer\" region=\"center\" splitter=\"false\" dojoAttachPoint=\"_pageContainer\" nested=\"true\" class=\"tiv-notebook-work-area\">\r\n        <div dojoAttachPoint=\"containerNode\"></div>              \r\n      </div>\r\n    </div>\r\n    <div dojoType=\"dijit.layout.ContentPane\" region=\"bottom\" splitter=\"false\" class=\"tiv-notebook-footer\" dojoAttachPoint=\"_buttonArea\">\r\n      <div class=\"tiv-notebook-buttons\" dojoAttachPoint=\"_buttons\"> \r\n        <button role=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickFinish\" dojoAttachPoint=\"_finishButton\">${okLabel}</button>\r\n        <button role=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickApply\" dojoAttachPoint=\"_applyButton\">${applyLabel}</button>\r\n        <button role=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickCancel\" dojoAttachPoint=\"_cancelButton\">${cancelLabel}</button>\r\n      </div>        \r\n    </div>\r\n  </div>\r\n</div>\r\n";
			} else {
				this.templateString="<div class=\"tiv-notebook\" role=\"application\">\r\n  <div dojoType=\"dijit.layout.BorderContainer\" design=\"headline\" gutters=\"false\" class=\"tiv-notebook-outer\" dojoAttachPoint=\"_outerContainer\" label=\"Notebook\">\r\n    <div dojoType=\"dijit.layout.BorderContainer\" gutters=\"false\" liveSplitters=\"false\" design=\"sidebar\" region=\"center\" style=\"width:100%;height:100%;\" dojoAttachPoint=\"_borderArea\">\r\n      <div dojoType=\"dijit.layout.ContentPane\" region=\"leading\" splitter=\"false\" class=\"tiv-notebook-toc\" dojoAttachPoint=\"_tocArea\">\r\n        <ol dojoAttachPoint=\"_toc\"></ol>\r\n      </div>\r\n      <div dojoType=\"dijit.layout.TabContainer\" region=\"center\" splitter=\"false\" dojoAttachPoint=\"_pageContainer\" class=\"tiv-notebook-work-area\">\r\n        <form id=\"${id}_form\" dojoAttachPoint=\"containerNode\" action=\"${action}\" method=\"${method}\"></form>              \r\n      </div>\r\n    </div>\r\n    <div dojoType=\"dijit.layout.ContentPane\" region=\"bottom\" splitter=\"false\" class=\"tiv-notebook-footer\" dojoAttachPoint=\"_buttonArea\">\r\n      <div class=\"tiv-notebook-buttons\" dojoAttachPoint=\"_buttons\"> \r\n        <button role=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickFinish\" dojoAttachPoint=\"_finishButton\">${okLabel}</button>\r\n        <button role=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickApply\" dojoAttachPoint=\"_applyButton\">${applyLabel}</button>\r\n        <button role=\"button\" dojoType=\"dijit.form.Button\" dojoAttachEvent=\"onClick:_onClickCancel\" dojoAttachPoint=\"_cancelButton\">${cancelLabel}</button>\r\n      </div>        \r\n    </div>\r\n  </div>\r\n</div>\r\n";
			}
			this.applyLabel = this._resources.APPLY;
			this.okLabel = this._resources.OK;
			this.cancelLabel = this._resources.CANCEL;
			this.inherited(arguments);
		},
  
		buildRendering: function () {
			// summary:  Builds and renders the container whenever changes occur.
			// tags: private
			
			this.inherited(arguments);
			// if horizontal layout...
			if ('h' === this.layout) {
				// remove toc area and use tab container's tab strip
				this._borderArea.removeChild(this._tocArea);
				this._toc = null;
			} else {
				// hide tab container's tab strip and use toc area
				this._pageContainer._setClassAttr("tiv-notebook-tabstrip-hidden");
			}
		},
  
		_setContainerType: function (page) {
			// summary:  Sets the container type for Notebook
			// tags: private
			
			page.attr("notebook", this);
		},
  
		_addToCItemConnections: function (toc_item) {
			// summary:  connects the onmouseover,onmouseout,onclick events of  ToC item/tab  to respective handlers
			// tags: private
			
			// only called for vertical layout
			this.connect(toc_item, "onclick", this._onToCClick);
			this.connect(toc_item, "onmouseover", dojo.hitch(this, this._onToCOver));
			this.connect(toc_item, "onmouseout", dojo.hitch(this, this._onToCOut));
			this.connect(toc_item, "onkeypress", dojo.hitch(this, this._onToCFocus));
		},
  
		updateUI: function () {
			// summary:  updates UI whenever changes occurs.
			// tags: public
			
			// disable the Apply button if the selected page does not validate
			var curr_page = this._pageContainer.selectedChildWidget;
			var isCurrentPageValid = curr_page && curr_page.isValid(); 
			if (!isCurrentPageValid) {
				this._applyButton.attr("disabled", true);
			}
			// disable the OK button until all pages are valid
			var allValid = dojo.every(this._pages, function (p) {
				var v = p.isValid();
				return v;
			}, this);
			this._finishButton.attr("disabled", !allValid);
			this._applyButton.attr("disabled", !allValid);
			// if horizontal layout update invalid icon on tabs
			if ('h' === this.layout) {
				dojo.query(".tabLabel", this._pageContainer.tablist.domNode).forEach(function (n, i) {
					var p = this._pages[i];
					dojo[(p && (!p.visited || p.validated)) ? "removeClass" : "addClass"](n, "tiv-page-invalid");
				}, this);     
			}
			this.inherited(arguments);
		},
  
		updateToCItemIcon: function (page, valid) {
			// summary:  If valid removes invalid icon on ToC item/tab.  If invalid adds invalid icon.  Provided as a utility function when nesting this widget.
			// tags: public
			
			var toc_items;
			if ('h' === this.layout) {
				toc_items = dojo.query(".tabLabel", this._pageContainer.tablist.domNode);
			} else {
				toc_items = dojo.query("li", this._toc);
			}
			dojo.every(toc_items, function (n, i) {
				var p = this._pages[i];
				if (page == p) {
					dojo[(valid) ? "removeClass" : "addClass"](n, "tiv-page-invalid");
					return false;
				} else {
					return true;
				}
			}, this);      
		},
  
		_onToCOver: function (evt) {
			// summary:  Calls when mouseover on  ToC item/tab.
			// tags: callback
			
			var li = evt.target;
			while (null != li && li.tagName.toLowerCase() != "li") {
				li = li.parentNode;
			}
			if (null == li) { 
				return;
			}
			dojo.addClass(li, "over");
		},
		
		_onToCFocus: function (evt) {
			// summary:  Calls when keypressed on  ToC item/tab.
			// tags: callback
			var li = evt.target;
			while (null != li && li.tagName.toLowerCase() != "li") {
				li = li.parentNode;
			}
			if (null == li) { 
				return;
			}
			if (evt.keyCode == 13) {
				var pid = dojo.attr(li, "pageID");
				if (null != pid) {
					this.selectPage(pid);
				}
			}
			
		},
  
		_onToCOut: function (evt) {
			// summary:  Calls when mouseout on  ToC item/tab.
			// tags: callback
			
			var li = evt.target;
			while (null != li && li.tagName.toLowerCase() != "li") {
				li = li.parentNode;
			}
			if (null == li) { 
				return;
			}
			dojo.removeClass(li, "over");    
		},
  
		_onToCClick: function (evt) {
			// summary:  Calls when click on  ToC item/tab.
			// tags: callback
		
			var li = evt.target;
			while (null != li && li.tagName.toLowerCase() != "li") {
				li = li.parentNode;
			}
			if (null == li) { 
				return;	
			}
			var pid = dojo.attr(li, "pageID");
			if (null != pid) {
				this.selectPage(pid);
			}
		},
  
		_onPageSelected: function (page) {
			// summary:  Calls when a page has been selected from Notebook.
			// tags: private extension
			
			page.visited = true;
			this.inherited(arguments);    
		},
  
		_onClickApply: function (evt) {
			// summary:  Calls by clicking Apply button.
			// tags: callback
			
			this.OnApply(this);
		},
  
		OnApply: function (wiz) {
		// summary:  Calls by clicking Apply button.
		// tags: public
		
		// override or connect to me
		// if this is still the same function as it was originally,
		// then nobody has connected to the event. do the default
		if(this._origApply === this.OnApply) {
		  // nothing connected, do the default
		  this.submit(this);
		}
	},
  
	
		enableOKButton: function (shouldEnable) {
			// summary:  Enables or disables the OK button. 
			// shouldEnable: boolean	if it is true enables the Ok button otherwise disables. default is false.
			// tags: public
			
			this._finishButton.attr("disabled", !shouldEnable);
		},
 
		enableApplyButton: function (shouldEnable) {
			// summary:  Enables or disables the Apply button. 
			// shouldEnable: boolean	if it is true enables the Apply button otherwise disables. default is false.
			// tags: public
			
			this._applyButton.attr("disabled", !shouldEnable);
		},

		hideOKButton: function (shouldHide) {
			// summary:  Hides or Shows the OK button. 
			// shouldHide: boolean	if it is true hides the OK button otherwise shows. default is false.
			// tags: public
			
			this.hideFinishButton(shouldHide);
		},
  
		hideApplyButton: function (shouldHide) {
			// summary:  Hides or Shows the Apply button. 
			// shouldHide: boolean	if it is true hides the Apply button otherwise shows. default is false.
			// tags: public
			
			if (shouldHide) {
				dojo.style(this._applyButton.domNode, "display", "none");
			} else {
				dojo.style(this._applyButton.domNode, "display", "inline-block");
			}
		},
  
		//methods added by TED team.
  
		OnCancel: function (note) {
			this.note = note;
			var dialog = new dojoe.messagedialog.MessageDialog({ message: this._resources.CANCEL_CONFIRM,
																 messageId: "",
																 type: "Confirm",
																 callback:  dojo.hitch(this, this.onCancelClick),
																 buttons: [this._resources.CONFIRM_YES, this._resources.CONFIRM_NO],
																 showCheckbox: false                                         
																});
			dialog.show();
		},
	
		onCancelClick : function (buttonPressedId, messageId, checked) {
			if (buttonPressedId == 0) {
				var pages = this.note.getChildren(); 
				dojo.forEach(pages, function (p, i) {
					this.note.removePage(p);
				//p.destroy();
				}, this);
				this.hideAllButtons();
				this._outerContainer.destroy();
				//dijit.byId(note).destroy();
			}
		},
  
		addPage: function (p) {			//p is widget
			// summary:  Adds a page to the Notebook
			// p: widget	A newly created page by extending dojoe.wizard.Page
			// tags: public
			
			this.inherited(arguments);
		},
   
		removePage: function (p) {		//p is widget
			// summary:  Removes a page to the Notebook
			// p: widget		
			// tags: public
			
			this.inherited(arguments);
		},
  
		selectPage: function (p) {		//p is widget
			// summary:  Selects a page from the Notebook
			// p: widget		
			// tags: public
			
			this.inherited(arguments);
		},
	
		OnOK: function (note) {
			// summary:  Event called on clicking the OK button
			// tags: callback extension
			
		//Latha 5July 2011 : Basing on the requirement from TIP team , removing the display of Confirmation messages after click on OK button	
		/*	this.note = note;
			var dialog = new dojoe.messagedialog.MessageDialog({ message: this._resources.OK_CONFIRM,
															 messageId: "NotebookOkMsg",
															 type: "Confirm",
															 callback:  dojo.hitch(this, this.onOkClick),
															 buttons: [this._resources.CONFIRM_YES, this._resources.CONFIRM_NO],
															 showCheckbox: false                                         
															});
			dialog.show(); */
		},
		/*onOkClick : function (buttonPressedId, messageId, checked) {
		
			if (buttonPressedId == 0) {
				var pages = this.note.getChildren(); 
				dojo.forEach(pages, function (p, i) {
					this.note.removePage(p);
					//p.destroy();
				}, this);
				this.hideAllButtons();
				this._outerContainer.destroy();
			}
		}, */
 
		enableCancelButton: function (shouldEnable) {
			// summary:  Enables or disables the Cancel button. 
			// shouldEnable: boolean	if it is true enables the Cancel button otherwise disables. default is false.
			// tags: public
			
			this.inherited(arguments);
		},
   
		hideCancelButton: function (shouldHide) {
			// summary:  Hides or Shows the Cancel button. 
			// shouldHide: boolean	if it is true hides the Cancel button otherwise shows. default is false.
			// tags: public
			
			this.inherited(arguments);
		},
  
		getSelectedPage: function () {
			// summary:  Returns currently selected page
			// tags: public
			
			var page = this.inherited(arguments);
			return page;
		},
  
		resize: function (newSize) {	
			// summary:  Resizes the Notebook according to the new dimensions.
			//newSize: array	newSize  is the new dimensions with properties w for width and h for height
			// tags: public
		
			this.inherited(arguments);
		},
  
		hideAllButtons: function () {
			// summary:   Hides all the buttons 
			// tags: public
			
			dojo.addClass(this._buttonArea.domNode, "tiv-notebook-footer-hidden");
		},
  
		showAllButtons: function () {
			// summary:   Shows all the buttons 
			// tags: public
			
			dojo.removeClass(this._buttonArea.domNode, "tiv-notebook-footer-hidden");
		},
  
		getChildren : function () {
			// summary:   Returns the pages attached to the Notebook
			// tags: public
			
			var page = [];
			page = this.inherited(arguments);
			return page;
		},
  
		restartNotebook : function () {
			// summary:   Restarts the Notebook
			// tags: public
			
			this.showAllButtons();	// the bottom button area might have been hidden
			this.enableOKButton(false);	// or maybe disabled
			this.enableApplyButton(false);
			this.enableCancelButton(true);
			var theKids = this._pageContainer.getChildren();	// get all of the children
			var i;
			for (i = 0; i < theKids.length; i++) {	// do for all children
				if ("function" == typeof theKids[i].reset) {	// if the child supports the "reset" method
					theKids[i].reset();		// give the kid a chance to reset
				}
			}
			this.selectPage(theKids[0]);	// and then select the first page
		},
		//Latha:04May2011: updating destroy for complete cleanup
		destroy : function() {
				// summary:  Destroys the note book.
				// tags: public
				
			try{
				delete this._resources;
				if (this._origApply) {
					delete this._origApply;
				}
				delete this.applyLabel;
				delete this.okLabel;
				delete this.cancelLabel;
				delete this.layout;
				
				dijit.registry.remove (this.id);
				this.inherited("destroy", arguments);
			}catch(ex){
						console.warn("Notebook destroy failed: "+this.id+", ex="+ex.name+":"+ex.message);
			}
		}	

});


}
