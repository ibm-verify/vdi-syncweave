/**
 * ModifyProvisionedParametersResponseType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package api._1._0.provisioning.ws.names.ibm;

public class ModifyProvisionedParametersResponseType  extends core._1._0.provisioning.ws.names.ibm.ExtensibleType  implements java.io.Serializable {
    private core._1._0.provisioning.ws.names.ibm.ProvisioningRequestStatusType requestStatus;
    private core._1._0.provisioning.ws.names.ibm.ProvisionedItemType provisionedItem;
    private core._1._0.provisioning.ws.names.ibm.ProvisioningObjectStatusType[] modificationStatus;

    public ModifyProvisionedParametersResponseType() {
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningRequestStatusType getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(core._1._0.provisioning.ws.names.ibm.ProvisioningRequestStatusType requestStatus) {
        this.requestStatus = requestStatus;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisionedItemType getProvisionedItem() {
        return provisionedItem;
    }

    public void setProvisionedItem(core._1._0.provisioning.ws.names.ibm.ProvisionedItemType provisionedItem) {
        this.provisionedItem = provisionedItem;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningObjectStatusType[] getModificationStatus() {
        return modificationStatus;
    }

    public void setModificationStatus(core._1._0.provisioning.ws.names.ibm.ProvisioningObjectStatusType[] modificationStatus) {
        this.modificationStatus = modificationStatus;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningObjectStatusType getModificationStatus(int i) {
        return modificationStatus[i];
    }

    public void setModificationStatus(int i, core._1._0.provisioning.ws.names.ibm.ProvisioningObjectStatusType value) {
        this.modificationStatus[i] = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ModifyProvisionedParametersResponseType)) return false;
        ModifyProvisionedParametersResponseType other = (ModifyProvisionedParametersResponseType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.requestStatus==null && other.getRequestStatus()==null) || 
             (this.requestStatus!=null &&
              this.requestStatus.equals(other.getRequestStatus()))) &&
            ((this.provisionedItem==null && other.getProvisionedItem()==null) || 
             (this.provisionedItem!=null &&
              this.provisionedItem.equals(other.getProvisionedItem()))) &&
            ((this.modificationStatus==null && other.getModificationStatus()==null) || 
             (this.modificationStatus!=null &&
              java.util.Arrays.equals(this.modificationStatus, other.getModificationStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getRequestStatus() != null) {
            _hashCode += getRequestStatus().hashCode();
        }
        if (getProvisionedItem() != null) {
            _hashCode += getProvisionedItem().hashCode();
        }
        if (getModificationStatus() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getModificationStatus());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getModificationStatus(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ModifyProvisionedParametersResponseType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "ModifyProvisionedParametersResponseType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requestStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "requestStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningRequestStatusType"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("provisionedItem");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "provisionedItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisionedItemType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modificationStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "modificationStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningObjectStatusType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
