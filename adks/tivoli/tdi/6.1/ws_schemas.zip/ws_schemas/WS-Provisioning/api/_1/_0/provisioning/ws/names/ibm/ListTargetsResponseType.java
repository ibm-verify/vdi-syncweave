/**
 * ListTargetsResponseType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package api._1._0.provisioning.ws.names.ibm;

public class ListTargetsResponseType  extends core._1._0.provisioning.ws.names.ibm.ExtensibleType  implements java.io.Serializable {
    private core._1._0.provisioning.ws.names.ibm.ProvisioningTargetSetType targets;
    private core._1._0.provisioning.ws.names.ibm.ProvisioningIteratedResultType result;
	// --- Manually edited --------------------------------------------------------
    //private java.lang.Object remaining;  // attribute
	private java.lang.String remaining;  // attribute
	// --- Manually edited --------------------------------------------------------

    public ListTargetsResponseType() {
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningTargetSetType getTargets() {
        return targets;
    }

    public void setTargets(core._1._0.provisioning.ws.names.ibm.ProvisioningTargetSetType targets) {
        this.targets = targets;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningIteratedResultType getResult() {
        return result;
    }

    public void setResult(core._1._0.provisioning.ws.names.ibm.ProvisioningIteratedResultType result) {
        this.result = result;
    }

	// --- Manually edited --------------------------------------------------------
    //public java.lang.Object getRemaining() {
	public java.lang.String getRemaining() {
	// --- Manually edited --------------------------------------------------------
        return remaining;
    }

	// --- Manually edited --------------------------------------------------------
    //public void setRemaining(java.lang.Object remaining) {
	public void setRemaining(java.lang.String remaining) {
	// --- Manually edited --------------------------------------------------------
        this.remaining = remaining;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ListTargetsResponseType)) return false;
        ListTargetsResponseType other = (ListTargetsResponseType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.targets==null && other.getTargets()==null) || 
             (this.targets!=null &&
              this.targets.equals(other.getTargets()))) &&
            ((this.result==null && other.getResult()==null) || 
             (this.result!=null &&
              this.result.equals(other.getResult()))) &&
            ((this.remaining==null && other.getRemaining()==null) || 
             (this.remaining!=null &&
              this.remaining.equals(other.getRemaining())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getTargets() != null) {
            _hashCode += getTargets().hashCode();
        }
        if (getResult() != null) {
            _hashCode += getResult().hashCode();
        }
        if (getRemaining() != null) {
            _hashCode += getRemaining().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ListTargetsResponseType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "ListTargetsResponseType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("remaining");
        attrField.setXmlName(new javax.xml.namespace.QName("", "remaining"));
		// --- Manually edited --------------------------------------------------------
        //attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyType"));
		attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		// --- Manually edited --------------------------------------------------------
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("targets");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "targets"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningTargetSetType"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("result");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "result"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningIteratedResultType"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
