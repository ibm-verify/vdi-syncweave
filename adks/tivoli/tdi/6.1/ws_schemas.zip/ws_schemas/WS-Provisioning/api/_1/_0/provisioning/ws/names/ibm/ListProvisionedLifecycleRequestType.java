/**
 * ListProvisionedLifecycleRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package api._1._0.provisioning.ws.names.ibm;

public class ListProvisionedLifecycleRequestType  extends core._1._0.provisioning.ws.names.ibm.ExtensibleType  implements java.io.Serializable {
    private core._1._0.provisioning.ws.names.ibm.ProvisioningIntervalType lifecycleInterval;
    private core._1._0.provisioning.ws.names.ibm.ProvisionedItemType provisionedItem;
    private core._1._0.provisioning.ws.names.ibm.ProvisioningIterator iterator;

    public ListProvisionedLifecycleRequestType() {
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningIntervalType getLifecycleInterval() {
        return lifecycleInterval;
    }

    public void setLifecycleInterval(core._1._0.provisioning.ws.names.ibm.ProvisioningIntervalType lifecycleInterval) {
        this.lifecycleInterval = lifecycleInterval;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisionedItemType getProvisionedItem() {
        return provisionedItem;
    }

    public void setProvisionedItem(core._1._0.provisioning.ws.names.ibm.ProvisionedItemType provisionedItem) {
        this.provisionedItem = provisionedItem;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningIterator getIterator() {
        return iterator;
    }

    public void setIterator(core._1._0.provisioning.ws.names.ibm.ProvisioningIterator iterator) {
        this.iterator = iterator;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ListProvisionedLifecycleRequestType)) return false;
        ListProvisionedLifecycleRequestType other = (ListProvisionedLifecycleRequestType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.lifecycleInterval==null && other.getLifecycleInterval()==null) || 
             (this.lifecycleInterval!=null &&
              this.lifecycleInterval.equals(other.getLifecycleInterval()))) &&
            ((this.provisionedItem==null && other.getProvisionedItem()==null) || 
             (this.provisionedItem!=null &&
              this.provisionedItem.equals(other.getProvisionedItem()))) &&
            ((this.iterator==null && other.getIterator()==null) || 
             (this.iterator!=null &&
              this.iterator.equals(other.getIterator())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getLifecycleInterval() != null) {
            _hashCode += getLifecycleInterval().hashCode();
        }
        if (getProvisionedItem() != null) {
            _hashCode += getProvisionedItem().hashCode();
        }
        if (getIterator() != null) {
            _hashCode += getIterator().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ListProvisionedLifecycleRequestType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "ListProvisionedLifecycleRequestType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lifecycleInterval");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "lifecycleInterval"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningIntervalType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("provisionedItem");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "provisionedItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisionedItemType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("iterator");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "iterator"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningIterator"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
