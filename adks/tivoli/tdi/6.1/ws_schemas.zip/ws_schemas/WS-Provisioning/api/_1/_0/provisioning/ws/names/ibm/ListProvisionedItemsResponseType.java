/**
 * ListProvisionedItemsResponseType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package api._1._0.provisioning.ws.names.ibm;

public class ListProvisionedItemsResponseType  extends core._1._0.provisioning.ws.names.ibm.ExtensibleType  implements java.io.Serializable {
    private core._1._0.provisioning.ws.names.ibm.ProvisionedItemSetType items;
    private core._1._0.provisioning.ws.names.ibm.ProvisioningIteratedResultType result;

    public ListProvisionedItemsResponseType() {
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisionedItemSetType getItems() {
        return items;
    }

    public void setItems(core._1._0.provisioning.ws.names.ibm.ProvisionedItemSetType items) {
        this.items = items;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningIteratedResultType getResult() {
        return result;
    }

    public void setResult(core._1._0.provisioning.ws.names.ibm.ProvisioningIteratedResultType result) {
        this.result = result;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ListProvisionedItemsResponseType)) return false;
        ListProvisionedItemsResponseType other = (ListProvisionedItemsResponseType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.items==null && other.getItems()==null) || 
             (this.items!=null &&
              this.items.equals(other.getItems()))) &&
            ((this.result==null && other.getResult()==null) || 
             (this.result!=null &&
              this.result.equals(other.getResult())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getItems() != null) {
            _hashCode += getItems().hashCode();
        }
        if (getResult() != null) {
            _hashCode += getResult().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ListProvisionedItemsResponseType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "ListProvisionedItemsResponseType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("items");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "items"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisionedItemSetType"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("result");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "result"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningIteratedResultType"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
