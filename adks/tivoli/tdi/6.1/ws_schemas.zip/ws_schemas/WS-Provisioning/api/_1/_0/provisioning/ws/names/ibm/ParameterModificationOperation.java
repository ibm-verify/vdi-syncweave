/**
 * ParameterModificationOperation.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package api._1._0.provisioning.ws.names.ibm;

public class ParameterModificationOperation implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected ParameterModificationOperation(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _add = "add";
    public static final java.lang.String _delete = "delete";
    public static final java.lang.String _replace = "replace";
    public static final ParameterModificationOperation add = new ParameterModificationOperation(_add);
    public static final ParameterModificationOperation delete = new ParameterModificationOperation(_delete);
    public static final ParameterModificationOperation replace = new ParameterModificationOperation(_replace);
    public java.lang.String getValue() { return _value_;}
    public static ParameterModificationOperation fromValue(java.lang.String value)
          throws java.lang.IllegalStateException {
        ParameterModificationOperation enum = (ParameterModificationOperation)
            _table_.get(value);
        if (enum==null) throw new java.lang.IllegalStateException();
        return enum;
    }
    public static ParameterModificationOperation fromString(java.lang.String value)
          throws java.lang.IllegalStateException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}

	// --- Manually added --------------------------------------------------------------------------------------------------
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ParameterModificationOperation.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:api", "ParameterModificationOperation"));
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
	// ---------------------------------------------------------------------------------------------------------------------
}
