/**
 * ProvisioningStatusCode.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package core._1._0.provisioning.ws.names.ibm;

public class ProvisioningStatusCode implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected ProvisioningStatusCode(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _success = "success";
    public static final java.lang.String _inProcess = "inProcess";
    public static final java.lang.String _pending = "pending";
    public static final java.lang.String _badRequest = "badRequest";
    public static final java.lang.String _badState = "badState";
    public static final java.lang.String _busy = "busy";
    public static final java.lang.String _expired = "expired";
    public static final java.lang.String _timeout = "timeout";
    public static final java.lang.String _unavailable = "unavailable";
    public static final java.lang.String _invalidExpression = "invalidExpression";
    public static final java.lang.String _serverError = "serverError";
    public static final java.lang.String _unsupportedOperation = "unsupportedOperation";
    public static final java.lang.String _notAuthorized = "notAuthorized";
    public static final java.lang.String _schemaViolation = "schemaViolation";
    public static final java.lang.String _unsupportedSchema = "unsupportedSchema";
    public static final java.lang.String _unrecognizedIdentifier = "unrecognizedIdentifier";
    public static final java.lang.String _objectUnavailable = "objectUnavailable";
    public static final java.lang.String _targetUnavailable = "targetUnavailable";
    public static final java.lang.String _targetReportedError = "targetReportedError";
    public static final java.lang.String _incompleteModification = "incompleteModification";
    public static final ProvisioningStatusCode success = new ProvisioningStatusCode(_success);
    public static final ProvisioningStatusCode inProcess = new ProvisioningStatusCode(_inProcess);
    public static final ProvisioningStatusCode pending = new ProvisioningStatusCode(_pending);
    public static final ProvisioningStatusCode badRequest = new ProvisioningStatusCode(_badRequest);
    public static final ProvisioningStatusCode badState = new ProvisioningStatusCode(_badState);
    public static final ProvisioningStatusCode busy = new ProvisioningStatusCode(_busy);
    public static final ProvisioningStatusCode expired = new ProvisioningStatusCode(_expired);
    public static final ProvisioningStatusCode timeout = new ProvisioningStatusCode(_timeout);
    public static final ProvisioningStatusCode unavailable = new ProvisioningStatusCode(_unavailable);
    public static final ProvisioningStatusCode invalidExpression = new ProvisioningStatusCode(_invalidExpression);
    public static final ProvisioningStatusCode serverError = new ProvisioningStatusCode(_serverError);
    public static final ProvisioningStatusCode unsupportedOperation = new ProvisioningStatusCode(_unsupportedOperation);
    public static final ProvisioningStatusCode notAuthorized = new ProvisioningStatusCode(_notAuthorized);
    public static final ProvisioningStatusCode schemaViolation = new ProvisioningStatusCode(_schemaViolation);
    public static final ProvisioningStatusCode unsupportedSchema = new ProvisioningStatusCode(_unsupportedSchema);
    public static final ProvisioningStatusCode unrecognizedIdentifier = new ProvisioningStatusCode(_unrecognizedIdentifier);
    public static final ProvisioningStatusCode objectUnavailable = new ProvisioningStatusCode(_objectUnavailable);
    public static final ProvisioningStatusCode targetUnavailable = new ProvisioningStatusCode(_targetUnavailable);
    public static final ProvisioningStatusCode targetReportedError = new ProvisioningStatusCode(_targetReportedError);
    public static final ProvisioningStatusCode incompleteModification = new ProvisioningStatusCode(_incompleteModification);
    public java.lang.String getValue() { return _value_;}
    public static ProvisioningStatusCode fromValue(java.lang.String value)
          throws java.lang.IllegalStateException {
        ProvisioningStatusCode enum = (ProvisioningStatusCode)
            _table_.get(value);
        if (enum==null) throw new java.lang.IllegalStateException();
        return enum;
    }
    public static ProvisioningStatusCode fromString(java.lang.String value)
          throws java.lang.IllegalStateException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}

	// --- Manually added --------------------------------------------------------------------------------------------------
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProvisioningStatusCode.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningStatusCode"));
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
	// ---------------------------------------------------------------------------------------------------------------------
}
