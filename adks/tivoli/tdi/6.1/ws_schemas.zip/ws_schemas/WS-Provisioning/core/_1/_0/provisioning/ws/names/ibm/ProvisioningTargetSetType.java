/**
 * ProvisioningTargetSetType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package core._1._0.provisioning.ws.names.ibm;

public class ProvisioningTargetSetType  implements java.io.Serializable {
    private core._1._0.provisioning.ws.names.ibm.ProvisioningTargetType[] provisioningTarget;

    public ProvisioningTargetSetType() {
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningTargetType[] getProvisioningTarget() {
        return provisioningTarget;
    }

    public void setProvisioningTarget(core._1._0.provisioning.ws.names.ibm.ProvisioningTargetType[] provisioningTarget) {
        this.provisioningTarget = provisioningTarget;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningTargetType getProvisioningTarget(int i) {
        return provisioningTarget[i];
    }

    public void setProvisioningTarget(int i, core._1._0.provisioning.ws.names.ibm.ProvisioningTargetType value) {
        this.provisioningTarget[i] = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProvisioningTargetSetType)) return false;
        ProvisioningTargetSetType other = (ProvisioningTargetSetType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.provisioningTarget==null && other.getProvisioningTarget()==null) || 
             (this.provisioningTarget!=null &&
              java.util.Arrays.equals(this.provisioningTarget, other.getProvisioningTarget())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProvisioningTarget() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getProvisioningTarget());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getProvisioningTarget(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProvisioningTargetSetType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningTargetSetType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("provisioningTarget");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningTarget"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningTargetType"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
