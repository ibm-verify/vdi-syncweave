/**
 * ProvisionedItemFilterType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package core._1._0.provisioning.ws.names.ibm;

public class ProvisionedItemFilterType  implements java.io.Serializable {
    private core._1._0.provisioning.ws.names.ibm.ProvisioningIdentifierType target;
    private core._1._0.provisioning.ws.names.ibm.ProvisioningIdentifierType owner;
    private core._1._0.provisioning.ws.names.ibm.ProvisioningStateSetType states;
    private core._1._0.provisioning.ws.names.ibm.ProvisioningSelectorType selector;

    public ProvisionedItemFilterType() {
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningIdentifierType getTarget() {
        return target;
    }

    public void setTarget(core._1._0.provisioning.ws.names.ibm.ProvisioningIdentifierType target) {
        this.target = target;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningIdentifierType getOwner() {
        return owner;
    }

    public void setOwner(core._1._0.provisioning.ws.names.ibm.ProvisioningIdentifierType owner) {
        this.owner = owner;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningStateSetType getStates() {
        return states;
    }

    public void setStates(core._1._0.provisioning.ws.names.ibm.ProvisioningStateSetType states) {
        this.states = states;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningSelectorType getSelector() {
        return selector;
    }

    public void setSelector(core._1._0.provisioning.ws.names.ibm.ProvisioningSelectorType selector) {
        this.selector = selector;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProvisionedItemFilterType)) return false;
        ProvisionedItemFilterType other = (ProvisionedItemFilterType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.target==null && other.getTarget()==null) || 
             (this.target!=null &&
              this.target.equals(other.getTarget()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.states==null && other.getStates()==null) || 
             (this.states!=null &&
              this.states.equals(other.getStates()))) &&
            ((this.selector==null && other.getSelector()==null) || 
             (this.selector!=null &&
              this.selector.equals(other.getSelector())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTarget() != null) {
            _hashCode += getTarget().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getStates() != null) {
            _hashCode += getStates().hashCode();
        }
        if (getSelector() != null) {
            _hashCode += getSelector().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProvisionedItemFilterType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisionedItemFilterType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("target");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "target"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningIdentifierType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningIdentifierType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("states");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "states"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningStateSetType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("selector");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "selector"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningSelectorType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
