/**
 * ProvisioningIntervalSetType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package core._1._0.provisioning.ws.names.ibm;

public class ProvisioningIntervalSetType  implements java.io.Serializable {
    private core._1._0.provisioning.ws.names.ibm.ProvisioningIntervalType[] provisioningInterval;

    public ProvisioningIntervalSetType() {
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningIntervalType[] getProvisioningInterval() {
        return provisioningInterval;
    }

    public void setProvisioningInterval(core._1._0.provisioning.ws.names.ibm.ProvisioningIntervalType[] provisioningInterval) {
        this.provisioningInterval = provisioningInterval;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningIntervalType getProvisioningInterval(int i) {
        return provisioningInterval[i];
    }

    public void setProvisioningInterval(int i, core._1._0.provisioning.ws.names.ibm.ProvisioningIntervalType value) {
        this.provisioningInterval[i] = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProvisioningIntervalSetType)) return false;
        ProvisioningIntervalSetType other = (ProvisioningIntervalSetType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.provisioningInterval==null && other.getProvisioningInterval()==null) || 
             (this.provisioningInterval!=null &&
              java.util.Arrays.equals(this.provisioningInterval, other.getProvisioningInterval())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProvisioningInterval() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getProvisioningInterval());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getProvisioningInterval(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProvisioningIntervalSetType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningIntervalSetType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("provisioningInterval");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningInterval"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningIntervalType"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
