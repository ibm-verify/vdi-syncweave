/**
 * ProvisioningTargetType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package core._1._0.provisioning.ws.names.ibm;

public class ProvisioningTargetType  extends core._1._0.provisioning.ws.names.ibm.ExtensibleType  implements java.io.Serializable {
    private core._1._0.provisioning.ws.names.ibm.ProvisioningIdentifierType identifier;
    private core._1._0.provisioning.ws.names.ibm.ProvisioningTextType[] description;
    private core._1._0.provisioning.ws.names.ibm.ProvisioningTargetSchema[] schema;

    public ProvisioningTargetType() {
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningIdentifierType getIdentifier() {
        return identifier;
    }

    public void setIdentifier(core._1._0.provisioning.ws.names.ibm.ProvisioningIdentifierType identifier) {
        this.identifier = identifier;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningTextType[] getDescription() {
        return description;
    }

    public void setDescription(core._1._0.provisioning.ws.names.ibm.ProvisioningTextType[] description) {
        this.description = description;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningTextType getDescription(int i) {
        return description[i];
    }

    public void setDescription(int i, core._1._0.provisioning.ws.names.ibm.ProvisioningTextType value) {
        this.description[i] = value;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningTargetSchema[] getSchema() {
        return schema;
    }

    public void setSchema(core._1._0.provisioning.ws.names.ibm.ProvisioningTargetSchema[] schema) {
        this.schema = schema;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningTargetSchema getSchema(int i) {
        return schema[i];
    }

    public void setSchema(int i, core._1._0.provisioning.ws.names.ibm.ProvisioningTargetSchema value) {
        this.schema[i] = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProvisioningTargetType)) return false;
        ProvisioningTargetType other = (ProvisioningTargetType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.identifier==null && other.getIdentifier()==null) || 
             (this.identifier!=null &&
              this.identifier.equals(other.getIdentifier()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              java.util.Arrays.equals(this.description, other.getDescription()))) &&
            ((this.schema==null && other.getSchema()==null) || 
             (this.schema!=null &&
              java.util.Arrays.equals(this.schema, other.getSchema())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getIdentifier() != null) {
            _hashCode += getIdentifier().hashCode();
        }
        if (getDescription() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDescription());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDescription(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSchema() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSchema());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSchema(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProvisioningTargetType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningTargetType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("identifier");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "identifier"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningIdentifierType"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningTextType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("schema");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "schema"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningTargetSchema"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
