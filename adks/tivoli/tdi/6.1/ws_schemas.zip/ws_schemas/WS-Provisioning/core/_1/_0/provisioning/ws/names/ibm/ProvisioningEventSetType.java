/**
 * ProvisioningEventSetType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package core._1._0.provisioning.ws.names.ibm;

public class ProvisioningEventSetType  implements java.io.Serializable {
    private core._1._0.provisioning.ws.names.ibm.ProvisioningIdentifierType provisionedItem;
    private core._1._0.provisioning.ws.names.ibm.ProvisioningIntervalType interval;
    private core._1._0.provisioning.ws.names.ibm.ProvisioningEventType[] event;

    public ProvisioningEventSetType() {
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningIdentifierType getProvisionedItem() {
        return provisionedItem;
    }

    public void setProvisionedItem(core._1._0.provisioning.ws.names.ibm.ProvisioningIdentifierType provisionedItem) {
        this.provisionedItem = provisionedItem;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningIntervalType getInterval() {
        return interval;
    }

    public void setInterval(core._1._0.provisioning.ws.names.ibm.ProvisioningIntervalType interval) {
        this.interval = interval;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningEventType[] getEvent() {
        return event;
    }

    public void setEvent(core._1._0.provisioning.ws.names.ibm.ProvisioningEventType[] event) {
        this.event = event;
    }

    public core._1._0.provisioning.ws.names.ibm.ProvisioningEventType getEvent(int i) {
        return event[i];
    }

    public void setEvent(int i, core._1._0.provisioning.ws.names.ibm.ProvisioningEventType value) {
        this.event[i] = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProvisioningEventSetType)) return false;
        ProvisioningEventSetType other = (ProvisioningEventSetType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.provisionedItem==null && other.getProvisionedItem()==null) || 
             (this.provisionedItem!=null &&
              this.provisionedItem.equals(other.getProvisionedItem()))) &&
            ((this.interval==null && other.getInterval()==null) || 
             (this.interval!=null &&
              this.interval.equals(other.getInterval()))) &&
            ((this.event==null && other.getEvent()==null) || 
             (this.event!=null &&
              java.util.Arrays.equals(this.event, other.getEvent())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProvisionedItem() != null) {
            _hashCode += getProvisionedItem().hashCode();
        }
        if (getInterval() != null) {
            _hashCode += getInterval().hashCode();
        }
        if (getEvent() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEvent());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEvent(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProvisioningEventSetType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningEventSetType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("provisionedItem");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "provisionedItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningIdentifierType"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("interval");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "interval"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningIntervalType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("event");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "event"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningEventType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
