/**
 * ProvisioningSelectorType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package core._1._0.provisioning.ws.names.ibm;

public class ProvisioningSelectorType  implements java.io.Serializable {
    private java.lang.String select;
    private core._1._0.provisioning.ws.names.ibm.NamespaceSpecifierType[] namespace;

    public ProvisioningSelectorType() {
    }

    public java.lang.String getSelect() {
        return select;
    }

    public void setSelect(java.lang.String select) {
        this.select = select;
    }

    public core._1._0.provisioning.ws.names.ibm.NamespaceSpecifierType[] getNamespace() {
        return namespace;
    }

    public void setNamespace(core._1._0.provisioning.ws.names.ibm.NamespaceSpecifierType[] namespace) {
        this.namespace = namespace;
    }

    public core._1._0.provisioning.ws.names.ibm.NamespaceSpecifierType getNamespace(int i) {
        return namespace[i];
    }

    public void setNamespace(int i, core._1._0.provisioning.ws.names.ibm.NamespaceSpecifierType value) {
        this.namespace[i] = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProvisioningSelectorType)) return false;
        ProvisioningSelectorType other = (ProvisioningSelectorType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.select==null && other.getSelect()==null) || 
             (this.select!=null &&
              this.select.equals(other.getSelect()))) &&
            ((this.namespace==null && other.getNamespace()==null) || 
             (this.namespace!=null &&
              java.util.Arrays.equals(this.namespace, other.getNamespace())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSelect() != null) {
            _hashCode += getSelect().hashCode();
        }
        if (getNamespace() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getNamespace());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getNamespace(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProvisioningSelectorType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningSelectorType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("select");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "select"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("namespace");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "namespace"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "NamespaceSpecifierType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
