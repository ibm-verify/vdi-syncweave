/**
 * ProvisioningStateType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package core._1._0.provisioning.ws.names.ibm;

public class ProvisioningStateType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected ProvisioningStateType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _created = "created";
    public static final java.lang.String _active = "active";
    public static final java.lang.String _suspended = "suspended";
    public static final java.lang.String _locked = "locked";
    public static final java.lang.String _terminated = "terminated";
    public static final ProvisioningStateType created = new ProvisioningStateType(_created);
    public static final ProvisioningStateType active = new ProvisioningStateType(_active);
    public static final ProvisioningStateType suspended = new ProvisioningStateType(_suspended);
    public static final ProvisioningStateType locked = new ProvisioningStateType(_locked);
    public static final ProvisioningStateType terminated = new ProvisioningStateType(_terminated);
    public java.lang.String getValue() { return _value_;}
    public static ProvisioningStateType fromValue(java.lang.String value)
          throws java.lang.IllegalStateException {
        ProvisioningStateType enum = (ProvisioningStateType)
            _table_.get(value);
        if (enum==null) throw new java.lang.IllegalStateException();
        return enum;
    }
    public static ProvisioningStateType fromString(java.lang.String value)
          throws java.lang.IllegalStateException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}

	// --- Manually added --------------------------------------------------------------------------------------------------
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProvisioningStateType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:ibm:names:ws:provisioning:0.1:core", "ProvisioningStateType"));
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
	// ---------------------------------------------------------------------------------------------------------------------
}
