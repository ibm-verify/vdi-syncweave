/**
 * SignaturePropertiesType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package org.w3.www._2000._09.xmldsig;

public class SignaturePropertiesType  implements java.io.Serializable {
    private org.w3.www._2000._09.xmldsig.SignaturePropertyType[] signaturePropertiesType;
    private org.apache.axis.types.Id id;  // attribute

    public SignaturePropertiesType() {
    }

    public org.w3.www._2000._09.xmldsig.SignaturePropertyType[] getSignaturePropertiesType() {
        return signaturePropertiesType;
    }

    public void setSignaturePropertiesType(org.w3.www._2000._09.xmldsig.SignaturePropertyType[] signaturePropertiesType) {
        this.signaturePropertiesType = signaturePropertiesType;
    }

    public org.w3.www._2000._09.xmldsig.SignaturePropertyType getSignaturePropertiesType(int i) {
        return signaturePropertiesType[i];
    }

    public void setSignaturePropertiesType(int i, org.w3.www._2000._09.xmldsig.SignaturePropertyType value) {
        this.signaturePropertiesType[i] = value;
    }

    public org.apache.axis.types.Id getId() {
        return id;
    }

    public void setId(org.apache.axis.types.Id id) {
        this.id = id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SignaturePropertiesType)) return false;
        SignaturePropertiesType other = (SignaturePropertiesType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.signaturePropertiesType==null && other.getSignaturePropertiesType()==null) || 
             (this.signaturePropertiesType!=null &&
              java.util.Arrays.equals(this.signaturePropertiesType, other.getSignaturePropertiesType()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSignaturePropertiesType() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSignaturePropertiesType());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSignaturePropertiesType(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SignaturePropertiesType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "SignaturePropertiesType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("id");
        attrField.setXmlName(new javax.xml.namespace.QName("", "Id"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "ID"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signaturePropertiesType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "SignaturePropertiesType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "SignaturePropertyType"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
