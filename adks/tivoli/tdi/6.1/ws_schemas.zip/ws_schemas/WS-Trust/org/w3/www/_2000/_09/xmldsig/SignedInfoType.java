/**
 * SignedInfoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jun 14, 2005 (09:15:57 EDT) WSDL2Java emitter.
 */

package org.w3.www._2000._09.xmldsig;

public class SignedInfoType  implements java.io.Serializable {
    private org.w3.www._2000._09.xmldsig.CanonicalizationMethodType canonicalizationMethod;
    private org.w3.www._2000._09.xmldsig.SignatureMethodType signatureMethod;
    private org.w3.www._2000._09.xmldsig.ReferenceType[] _null;
    private org.apache.axis.types.Id id;  // attribute

    public SignedInfoType() {
    }

    public SignedInfoType(
           org.w3.www._2000._09.xmldsig.CanonicalizationMethodType canonicalizationMethod,
           org.w3.www._2000._09.xmldsig.SignatureMethodType signatureMethod,
           org.w3.www._2000._09.xmldsig.ReferenceType[] _null,
           org.apache.axis.types.Id id) {
           this.canonicalizationMethod = canonicalizationMethod;
           this.signatureMethod = signatureMethod;
           this._null = _null;
           this.id = id;
    }


    /**
     * Gets the canonicalizationMethod value for this SignedInfoType.
     * 
     * @return canonicalizationMethod
     */
    public org.w3.www._2000._09.xmldsig.CanonicalizationMethodType getCanonicalizationMethod() {
        return canonicalizationMethod;
    }


    /**
     * Sets the canonicalizationMethod value for this SignedInfoType.
     * 
     * @param canonicalizationMethod
     */
    public void setCanonicalizationMethod(org.w3.www._2000._09.xmldsig.CanonicalizationMethodType canonicalizationMethod) {
        this.canonicalizationMethod = canonicalizationMethod;
    }


    /**
     * Gets the signatureMethod value for this SignedInfoType.
     * 
     * @return signatureMethod
     */
    public org.w3.www._2000._09.xmldsig.SignatureMethodType getSignatureMethod() {
        return signatureMethod;
    }


    /**
     * Sets the signatureMethod value for this SignedInfoType.
     * 
     * @param signatureMethod
     */
    public void setSignatureMethod(org.w3.www._2000._09.xmldsig.SignatureMethodType signatureMethod) {
        this.signatureMethod = signatureMethod;
    }


    /**
     * Gets the _null value for this SignedInfoType.
     * 
     * @return _null
     */
    public org.w3.www._2000._09.xmldsig.ReferenceType[] get_null() {
        return _null;
    }


    /**
     * Sets the _null value for this SignedInfoType.
     * 
     * @param _null
     */
    public void set_null(org.w3.www._2000._09.xmldsig.ReferenceType[] _null) {
        this._null = _null;
    }

    public org.w3.www._2000._09.xmldsig.ReferenceType get_null(int i) {
        return this._null[i];
    }

    public void set_null(int i, org.w3.www._2000._09.xmldsig.ReferenceType _value) {
        this._null[i] = _value;
    }


    /**
     * Gets the id value for this SignedInfoType.
     * 
     * @return id
     */
    public org.apache.axis.types.Id getId() {
        return id;
    }


    /**
     * Sets the id value for this SignedInfoType.
     * 
     * @param id
     */
    public void setId(org.apache.axis.types.Id id) {
        this.id = id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SignedInfoType)) return false;
        SignedInfoType other = (SignedInfoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.canonicalizationMethod==null && other.getCanonicalizationMethod()==null) || 
             (this.canonicalizationMethod!=null &&
              this.canonicalizationMethod.equals(other.getCanonicalizationMethod()))) &&
            ((this.signatureMethod==null && other.getSignatureMethod()==null) || 
             (this.signatureMethod!=null &&
              this.signatureMethod.equals(other.getSignatureMethod()))) &&
            ((this._null==null && other.get_null()==null) || 
             (this._null!=null &&
              java.util.Arrays.equals(this._null, other.get_null()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCanonicalizationMethod() != null) {
            _hashCode += getCanonicalizationMethod().hashCode();
        }
        if (getSignatureMethod() != null) {
            _hashCode += getSignatureMethod().hashCode();
        }
        if (get_null() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(get_null());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(get_null(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SignedInfoType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "SignedInfoType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("id");
        attrField.setXmlName(new javax.xml.namespace.QName("", "Id"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "ID"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("canonicalizationMethod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "CanonicalizationMethod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "CanonicalizationMethod"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signatureMethod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "SignatureMethod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "SignatureMethod"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_null");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "null"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "ReferenceType"));
        elemField.setMaxOccurs(-1);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
