/**
 * EndpointReferenceType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jun 14, 2005 (09:15:57 EDT) WSDL2Java emitter.
 */

package org.xmlsoap.schemas.ws._2004._08.addressing;

public class EndpointReferenceType  implements java.io.Serializable {
    private org.xmlsoap.schemas.ws._2004._08.addressing.AttributedURI address;
    private org.xmlsoap.schemas.ws._2004._08.addressing.ReferencePropertiesType referenceProperties;
    private org.xmlsoap.schemas.ws._2004._08.addressing.ReferenceParametersType referenceParameters;
    private org.xmlsoap.schemas.ws._2004._08.addressing.AttributedQName portType;
    private org.xmlsoap.schemas.ws._2004._08.addressing.ServiceNameType serviceName;
    private org.apache.axis.message.MessageElement [] _any;

    public EndpointReferenceType() {
    }

    public EndpointReferenceType(
           org.xmlsoap.schemas.ws._2004._08.addressing.AttributedURI address,
           org.xmlsoap.schemas.ws._2004._08.addressing.ReferencePropertiesType referenceProperties,
           org.xmlsoap.schemas.ws._2004._08.addressing.ReferenceParametersType referenceParameters,
           org.xmlsoap.schemas.ws._2004._08.addressing.AttributedQName portType,
           org.xmlsoap.schemas.ws._2004._08.addressing.ServiceNameType serviceName,
           org.apache.axis.message.MessageElement [] _any) {
           this.address = address;
           this.referenceProperties = referenceProperties;
           this.referenceParameters = referenceParameters;
           this.portType = portType;
           this.serviceName = serviceName;
           this._any = _any;
    }


    /**
     * Gets the address value for this EndpointReferenceType.
     * 
     * @return address
     */
    public org.xmlsoap.schemas.ws._2004._08.addressing.AttributedURI getAddress() {
        return address;
    }


    /**
     * Sets the address value for this EndpointReferenceType.
     * 
     * @param address
     */
    public void setAddress(org.xmlsoap.schemas.ws._2004._08.addressing.AttributedURI address) {
        this.address = address;
    }


    /**
     * Gets the referenceProperties value for this EndpointReferenceType.
     * 
     * @return referenceProperties
     */
    public org.xmlsoap.schemas.ws._2004._08.addressing.ReferencePropertiesType getReferenceProperties() {
        return referenceProperties;
    }


    /**
     * Sets the referenceProperties value for this EndpointReferenceType.
     * 
     * @param referenceProperties
     */
    public void setReferenceProperties(org.xmlsoap.schemas.ws._2004._08.addressing.ReferencePropertiesType referenceProperties) {
        this.referenceProperties = referenceProperties;
    }


    /**
     * Gets the referenceParameters value for this EndpointReferenceType.
     * 
     * @return referenceParameters
     */
    public org.xmlsoap.schemas.ws._2004._08.addressing.ReferenceParametersType getReferenceParameters() {
        return referenceParameters;
    }


    /**
     * Sets the referenceParameters value for this EndpointReferenceType.
     * 
     * @param referenceParameters
     */
    public void setReferenceParameters(org.xmlsoap.schemas.ws._2004._08.addressing.ReferenceParametersType referenceParameters) {
        this.referenceParameters = referenceParameters;
    }


    /**
     * Gets the portType value for this EndpointReferenceType.
     * 
     * @return portType
     */
    public org.xmlsoap.schemas.ws._2004._08.addressing.AttributedQName getPortType() {
        return portType;
    }


    /**
     * Sets the portType value for this EndpointReferenceType.
     * 
     * @param portType
     */
    public void setPortType(org.xmlsoap.schemas.ws._2004._08.addressing.AttributedQName portType) {
        this.portType = portType;
    }


    /**
     * Gets the serviceName value for this EndpointReferenceType.
     * 
     * @return serviceName
     */
    public org.xmlsoap.schemas.ws._2004._08.addressing.ServiceNameType getServiceName() {
        return serviceName;
    }


    /**
     * Sets the serviceName value for this EndpointReferenceType.
     * 
     * @param serviceName
     */
    public void setServiceName(org.xmlsoap.schemas.ws._2004._08.addressing.ServiceNameType serviceName) {
        this.serviceName = serviceName;
    }


    /**
     * Gets the _any value for this EndpointReferenceType.
     * 
     * @return _any
     */
    public org.apache.axis.message.MessageElement [] get_any() {
        return _any;
    }


    /**
     * Sets the _any value for this EndpointReferenceType.
     * 
     * @param _any
     */
    public void set_any(org.apache.axis.message.MessageElement [] _any) {
        this._any = _any;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EndpointReferenceType)) return false;
        EndpointReferenceType other = (EndpointReferenceType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.address==null && other.getAddress()==null) || 
             (this.address!=null &&
              this.address.equals(other.getAddress()))) &&
            ((this.referenceProperties==null && other.getReferenceProperties()==null) || 
             (this.referenceProperties!=null &&
              this.referenceProperties.equals(other.getReferenceProperties()))) &&
            ((this.referenceParameters==null && other.getReferenceParameters()==null) || 
             (this.referenceParameters!=null &&
              this.referenceParameters.equals(other.getReferenceParameters()))) &&
            ((this.portType==null && other.getPortType()==null) || 
             (this.portType!=null &&
              this.portType.equals(other.getPortType()))) &&
            ((this.serviceName==null && other.getServiceName()==null) || 
             (this.serviceName!=null &&
              this.serviceName.equals(other.getServiceName()))) &&
            ((this._any==null && other.get_any()==null) || 
             (this._any!=null &&
              java.util.Arrays.equals(this._any, other.get_any())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAddress() != null) {
            _hashCode += getAddress().hashCode();
        }
        if (getReferenceProperties() != null) {
            _hashCode += getReferenceProperties().hashCode();
        }
        if (getReferenceParameters() != null) {
            _hashCode += getReferenceParameters().hashCode();
        }
        if (getPortType() != null) {
            _hashCode += getPortType().hashCode();
        }
        if (getServiceName() != null) {
            _hashCode += getServiceName().hashCode();
        }
        if (get_any() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(get_any());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(get_any(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EndpointReferenceType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/ws/2004/08/addressing", "EndpointReferenceType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("address");
        elemField.setXmlName(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/ws/2004/08/addressing", "Address"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/ws/2004/08/addressing", "AttributedURI"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("referenceProperties");
        elemField.setXmlName(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/ws/2004/08/addressing", "ReferenceProperties"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/ws/2004/08/addressing", "ReferencePropertiesType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("referenceParameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/ws/2004/08/addressing", "ReferenceParameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/ws/2004/08/addressing", "ReferenceParametersType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("portType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/ws/2004/08/addressing", "PortType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/ws/2004/08/addressing", "AttributedQName"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/ws/2004/08/addressing", "ServiceName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/ws/2004/08/addressing", "ServiceNameType"));
        elemField.setMinOccurs(0);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
