/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * (C) Copyright IBM Corp. 2009, 2019 All Rights Reserved
 *
 * The source code for this program is not published or other-
 * wise divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */
package com.ibm.net.ssh;

import java.util.logging.Logger;

/**
 * This class loads user defined properties for the SSH client
 * from the Java System properties.  See ssh.properties for details
 * on the format.
 * 
 * @author Eric W. Brown
 */
public final class Configuration {
   /** Copyright statement. */
   private static final String COPYRIGHT = Copyright.HEADER + "2009, 2019" + Copyright.FOOTER;

   /** Debugging variables. */
   private static Logger logger = Logger.getLogger("com.ibm.net.ssh");

   /** Default port. */
   private static final int DEFAULT_PORT = 22;

   /** Default timeout. */
   private static final int DEFAULT_TIMEOUT = 15000;

   /** Default key exchange algorithms. */
   private static final String[] DEFAULT_KEX_ALGORITHMS = {KeyExchange.DH_GROUP_EXCHANGE_SHA256, KeyExchange.DH_GROUP_EXCHANGE_SHA1,
                                                           KeyExchange.DH_GROUP14_SHA1, KeyExchange.DH_GROUP1_SHA1,
                                                           KeyExchange.DH_GROUP14_SHA256, KeyExchange.DH_GROUP16_SHA512,
                                                           KeyExchange.DH_GROUP18_SHA512, KeyExchange.ECDH_SHA2_NISTP256,
                                                           KeyExchange.ECDH_SHA2_NISTP384, KeyExchange.ECDH_SHA2_NISTP521};

   /** Default server host key algorithms.*/
   private static final String[] DEFAULT_SERVER_HOST_KEY_ALGORITHMS = {SSHConstants.RSA_KEY_FORMAT, SSHConstants.DSS_KEY_FORMAT,
                                                                       SSHConstants.RSA_SHA2_256_ALGORITHM, SSHConstants.RSA_SHA2_512_ALGORITHM,
                                                                       SSHConstants.ECDSA_SHA2_NISTP_256,
                                                                       SSHConstants.ECDSA_SHA2_NISTP_384,
                                                                       SSHConstants.ECDSA_SHA2_NISTP_521};

   /** Default encryption algorithms. */
   private static final String[] DEFAULT_ENCRYPTION_ALGORITHMS = {"aes128-ctr", "aes128-cbc", "3des-ctr", "3des-cbc", "arcfour",
                                                                  "blowfish-ctr", "blowfish-cbc", "aes192-ctr", "aes256-ctr"};

   /** Default MAC algorithms. */
   private static final String[] DEFAULT_MAC_ALGORITHMS = {"hmac-md5", "hmac-sha1", "hmac-sha2-256", "hmac-sha2-512", "hmac-md5-96", "hmac-sha1-96"};

   /** Default compression algorithms. */
   private static final String[] DEFAULT_COMPRESSION_ALGORITHMS = {KeyExchange.NO_COMPRESSION};

   /** Default public key directory used for OpenSSH SSH Servers. */
   private static final String DEFAULT_OPENSSH_PUBLIC_KEY_DIRECTORY = ".ssh";

   /** Default public key file used for OpenSSH SSH Servers. */
   private static final String DEFAULT_OPENSSH_PUBLIC_KEY_FILE = "authorized_keys";

   /** Default public key directory used for Attachmate Reflection for IT SSH Servers. */
   private static final String DEFAULT_REFLECTION_PUBLIC_KEY_DIRECTORY = ".ssh2";

   /** Default public key file used for Attachmate Reflection for IT SSH Servers. */
   private static final String DEFAULT_REFLECTION_PUBLIC_KEY_FILE = "authorization";

   /** Default public key directory used for Tectia SSH Servers. */
   private static final String DEFAULT_TECTIA_PUBLIC_KEY_DIRECTORY = ".ssh2";

   /** Default public key file used for Tectia SSH Servers. */
   private static final String DEFAULT_TECTIA_PUBLIC_KEY_FILE = "authorization";

   /** Default private key file format. */
   private static final String DEFAULT_PRIVATE_KEY_FILE_FORMAT = "openssh";

   /** Allowed private key file formats. */
   private static final String[] ALLOWED_PRIVATE_KEY_FILE_FORMATS = {"openssh", "tectia"};

   /** Default private key file encryption algorithm. */
   private static final String DEFAULT_PRIVATE_KEY_FILE_ALGORITHM = "aes";

   /** Allowed private key file encryption algorithms. */
   private static final String[] ALLOWED_PRIVATE_KEY_FILE_ALGORITHMS = {"aes", "3des"};

   /** User defined port. */
   private static Integer port;

   /** User defined timeout. */
   private static Integer timeout;

   /** User defined key exchange algorithms. */
   private static String[] kexAlgorithms;

   /** User defined server host key algorithms. */
   private static String[] serverHostKeyAlgorithms;

   /** User defined encryption algorithms. */
   private static String[] encryptionAlgorithms;

   /** User defined MAC algorithms. */
   private static String[] macAlgorithms;

   /** User defined compression algorithms. */
   private static String[] compressionAlgorithms;

   /** Public key directory used for OpenSSH SSH Servers. */
   private static String opensshPublicKeyDirectory;

   /** Public key file used for OpenSSH SSH Servers. */
   private static String opensshPublicKeyFile;

   /** Public key directory used for Attachmate Reflection for IT SSH Servers. */
   private static String reflectionPublicKeyDirectory;

   /** Public key file used for Attachmate Reflection for IT SSH Servers. */
   private static String reflectionPublicKeyFile;

   /** Public key directory used for Tectia SSH Servers. */
   private static String tectiaPublicKeyDirectory;

   /** Public key file used for Tectia SSH Servers. */
   private static String tectiaPublicKeyFile;

   /** Private key file format. */
   private static String privateKeyFileFormat;

   /** Private key file encryption algorithm. */
   private static String privateKeyFileAlgorithm;

   /**
    * Get the user defined port from the system properties.
    * 
    * @return  port number
    */
   static int getPort() {
      if (port == null) {
         int result = DEFAULT_PORT;
         String value = System.getProperty("com.ibm.net.ssh.port");

         if (value != null) {
            try {
               result = Integer.parseInt(value);
               if ((result < 0) || (result > 65535)) {
                  result = DEFAULT_PORT;
               }
            } catch (NumberFormatException exception) {
               logger.fine(exception.toString());
            }
         }

         port = new Integer(result);
      }

      return port.intValue();
   }

   /**
    * Get the user defined timeout from the system properties.
    * 
    * @return  timeout value in milliseconds
    */
   static int getTimeout() {
      if (timeout == null) {
         int result = DEFAULT_TIMEOUT;
         String value = System.getProperty("com.ibm.net.ssh.timeout");

         if (value != null) {
            try {
               result = Integer.parseInt(value);
               // A valid timeout range is between 0 and 10 minutes
               if ((result < 0) || (result > 600000)) {
                  result = DEFAULT_TIMEOUT;
               }
            } catch (NumberFormatException exception) {
               logger.fine(exception.toString());
            }
         }

         timeout = new Integer(result);
      }

      return timeout.intValue();
   }

   /**
    * Get the user defined key exchange algorithms from the system properties.
    * 
    * @return  array of algorithm strings
    */
   static String[] getKexAlgorithms() {
      if (kexAlgorithms == null) {
         String[] result = DEFAULT_KEX_ALGORITHMS;
         String value = System.getProperty("com.ibm.net.ssh.kexAlgorithms");

         if (value != null) {
            result = SSHNameList.stringToNameList(value);
            if (result.length == 0) {
               result = DEFAULT_KEX_ALGORITHMS;
            }
         }

         kexAlgorithms = result;
      }

      return kexAlgorithms;
   }

   /**
    * Get the user defined server host key algorithms from the system properties.
    * 
    * @return  array of algorithm strings
    */
   static String[] getServerHostKeyAlgorithms() {
      if (serverHostKeyAlgorithms == null) {
         String[] result = DEFAULT_SERVER_HOST_KEY_ALGORITHMS;
         String value = System.getProperty("com.ibm.net.ssh.serverHostKeyAlgorithms");

         if (value != null) {
            result = SSHNameList.stringToNameList(value);
            if (result.length == 0) {
               result = DEFAULT_SERVER_HOST_KEY_ALGORITHMS;
            }
         }

         serverHostKeyAlgorithms = result;
      }

      return serverHostKeyAlgorithms;
   }

   /**
    * Get the user defined encryption algorithms from the system properties.
    * 
    * @return  array of algorithm strings
    */
   static String[] getEncryptionAlgorithms() {
      if (encryptionAlgorithms == null) {
         String[] result = DEFAULT_ENCRYPTION_ALGORITHMS;
         String value = System.getProperty("com.ibm.net.ssh.encryptionAlgorithms");

         if (value != null) {
            result = SSHNameList.stringToNameList(value);
            if (result.length == 0) {
               result = DEFAULT_ENCRYPTION_ALGORITHMS;
            }
         }

         encryptionAlgorithms = result;
      }

      return encryptionAlgorithms;
   }

   /**
    * Get the user defined MAC algorithms from the system properties.
    * 
    * @return  array of algorithm strings
    */
   static String[] getMacAlgorithms() {
      if (macAlgorithms == null) {
         String[] result = DEFAULT_MAC_ALGORITHMS;
         String value = System.getProperty("com.ibm.net.ssh.macAlgorithms");

         if (value != null) {
            result = SSHNameList.stringToNameList(value);
            if (result.length == 0) {
               result = DEFAULT_MAC_ALGORITHMS;
            }
         }

         macAlgorithms = result;
      }

      return macAlgorithms;
   }

   /**
    * Get the user defined compression algorithms from the system properties.
    * 
    * @return  array of algorithm strings
    */
   static String[] getCompressionAlgorithms() {
      if (compressionAlgorithms == null) {
         String[] result = DEFAULT_COMPRESSION_ALGORITHMS;
         String value = System.getProperty("com.ibm.net.ssh.compressionAlgorithms");

         if (value != null) {
            result = SSHNameList.stringToNameList(value);
            if (result.length == 0) {
               result = DEFAULT_COMPRESSION_ALGORITHMS;
            }
         }

         compressionAlgorithms = result;
      }

      return compressionAlgorithms;
   }

   /**
    * Get public key directory used for OpenSSH SSH Servers.
    * 
    * @return  OpenSSH public key directory
    */
   static String getOpensshPublicKeyDirectory() {
      if (opensshPublicKeyDirectory == null) {
         String result = DEFAULT_OPENSSH_PUBLIC_KEY_DIRECTORY;
         String value = System.getProperty("com.ibm.net.ssh.opensshPublicKeyDirectory");

         if (value != null) {
            result = value;
         }

         opensshPublicKeyDirectory = result;
      }

      return opensshPublicKeyDirectory;
   }

   /**
    * Get public key file used for OpenSSH SSH Servers.
    * 
    * @return  OpenSSH public key file
    */
   static String getOpensshPublicKeyFile() {
      if (opensshPublicKeyFile == null) {
         String result = DEFAULT_OPENSSH_PUBLIC_KEY_FILE;
         String value = System.getProperty("com.ibm.net.ssh.opensshPublicKeyFile");

         if (value != null) {
            result = value;
         }

         opensshPublicKeyFile = result;
      }

      return opensshPublicKeyFile;
   }

   /**
    * Get public key directory used for Attachmate Reflection for IT SSH Servers.
    * 
    * @return  reflection public key directory
    */
   static String getReflectionPublicKeyDirectory() {
      if (reflectionPublicKeyDirectory == null) {
         String result = DEFAULT_REFLECTION_PUBLIC_KEY_DIRECTORY;
         String value = System.getProperty("com.ibm.net.ssh.reflectionPublicKeyDirectory");

         if (value != null) {
            result = value;
         }

         reflectionPublicKeyDirectory = result;
      }

      return reflectionPublicKeyDirectory;
   }

   /**
    * Get public key file used for Attachmate Reflection for IT SSH Servers.
    * 
    * @return  reflection public key file
    */
   static String getReflectionPublicKeyFile() {
      if (reflectionPublicKeyFile == null) {
         String result = DEFAULT_REFLECTION_PUBLIC_KEY_FILE;
         String value = System.getProperty("com.ibm.net.ssh.reflectionPublicKeyFile");

         if (value != null) {
            result = value;
         }

         reflectionPublicKeyFile = result;
      }

      return reflectionPublicKeyFile;
   }

   /**
    * Get public key directory used for Tectia SSH Servers.
    * 
    * @return  tectia public key directory
    */
   static String getTectiaPublicKeyDirectory() {
      if (tectiaPublicKeyDirectory == null) {
         String result = DEFAULT_TECTIA_PUBLIC_KEY_DIRECTORY;
         String value = System.getProperty("com.ibm.net.ssh.tectiaPublicKeyDirectory");

         if (value != null) {
            result = value;
         }

         tectiaPublicKeyDirectory = result;
      }

      return tectiaPublicKeyDirectory;
   }

   /**
    * Get public key file used for Tectia SSH Servers.
    * 
    * @return  tectia public key file
    */
   static String getTectiaPublicKeyFile() {
      if (tectiaPublicKeyFile == null) {
         String result = DEFAULT_TECTIA_PUBLIC_KEY_FILE;
         String value = System.getProperty("com.ibm.net.ssh.tectiaPublicKeyFile");

         if (value != null) {
            result = value;
         }

         tectiaPublicKeyFile = result;
      }

      return tectiaPublicKeyFile;
   }

   /**
    * Get private key file format.
    * 
    * @return  private key file format string
    */
   static String getPrivateKeyFileFormat() {
      if (privateKeyFileFormat == null) {
         String result = DEFAULT_PRIVATE_KEY_FILE_FORMAT;
         String value = System.getProperty("com.ibm.net.ssh.privateKeyFileFormat");

         if (value != null) {
            for (int i = 0; i < ALLOWED_PRIVATE_KEY_FILE_FORMATS.length; i++) {
               if (value.equals(ALLOWED_PRIVATE_KEY_FILE_FORMATS[i])) {
                  result = value;
                  break;
               }
            }
         }

         privateKeyFileFormat = result;
      }

      return privateKeyFileFormat;
   }

   /**
    * Get private key file encryption algorithm.
    * 
    * @return  private key file encryption algorithm
    */
   static String getPrivateKeyFileAlgorithm() {
      if (privateKeyFileAlgorithm == null) {
         String result = DEFAULT_PRIVATE_KEY_FILE_ALGORITHM;
         String value = System.getProperty("com.ibm.net.ssh.privateKeyFileAlgorithm");

         if (value != null) {
            for (int i = 0; i < ALLOWED_PRIVATE_KEY_FILE_ALGORITHMS.length; i++) {
               if (value.equals(ALLOWED_PRIVATE_KEY_FILE_ALGORITHMS[i])) {
                  result = value;
                  break;
               }
            }
         }

         privateKeyFileAlgorithm = result;
      }

      return privateKeyFileAlgorithm;
   }
}
