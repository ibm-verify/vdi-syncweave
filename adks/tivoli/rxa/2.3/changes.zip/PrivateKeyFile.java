/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * (C) Copyright IBM Corp. 2005, 2019 All Rights Reserved
 *
 * The source code for this program is not published or other-
 * wise divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */
package com.ibm.net.ssh;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.IOException;

import java.math.BigInteger;

import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;

import java.security.spec.DSAPrivateKeySpec;
import java.security.spec.DSAPublicKeySpec;
import java.security.spec.RSAPrivateCrtKeySpec;
import java.security.spec.RSAPublicKeySpec;

import javax.crypto.spec.IvParameterSpec;

import com.ibm.net.ssh.OpensshPrivateKeyReader.KeyType;

/**
 * This class loads and stores private keys to
 * files.  It can currently handle files in OpenSSH
 * format.
 *
 * @author Eric W. Brown
 */
public final class PrivateKeyFile {
   /** Copyright statement. */
   private static final String COPYRIGHT = Copyright.HEADER + "2005, 2019" + Copyright.FOOTER;

   /** RSA key factory type. */
   private static final String RSA_KEY_FACTORY = "RSA";

   /** DSA key factory type. */
   private static final String DSA_KEY_FACTORY = "DSA";

   /** Public and private key pair. */
   private KeyPair keyPair;

   /** Initialization vector. */
   private IvParameterSpec ivParameterSpec;

   /** Encryption algorithm. */
   private String algorithm;

   /**
    * Initialize a private key file using the given key pair.
    *
    * @param keyPair public and private key
    */
   public PrivateKeyFile(final KeyPair keyPair) {
      if (keyPair != null) {
         this.keyPair = keyPair;
      } else {
         throw new NullPointerException();
      }
   }

   /**
    * Initialize a private key file with the specified file
    * name and pass phrase.  Pass a null passPhrase for
    * unencrypted private key files.
    *
    * @param filename     file name to load
    * @param passPhrase   pass phrase for encryption
    *
    * @exception IOException  if any problem occurs parsing the file
    */
   public PrivateKeyFile(final String filename, final char[] passPhrase) throws IOException {
      // Load from given filename using pass phrase
      load(filename, passPhrase);
   }

   /**
    * Get the public and private key pair.
    *
    * @return   key pair containing public and private key
    */
   public KeyPair getKeyPair() {
      return keyPair;
   }

   /**
    * Load a private key from the specified file name using the
    * given pass phrase.  If pass phrase is null, it will assume
    * the data is unencrypted.
    *
    * @param filename   private key file name
    * @param passPhrase pass phrase
    *
    * @exception IOException  if any problem occurs parsing the file
    */
   public void load(final String filename, final char[] passPhrase) throws IOException {
      BufferedReader bufferedReader = null;

      try {
         FileInputStream fileInputStream = new FileInputStream(filename);
         bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));

         // Read begin marker
         String beginMarker = bufferedReader.readLine();
         if (beginMarker == null) {
            throw new IOException("Private key file is empty.");
         }

         KeyType keyType = null;
         switch (beginMarker) {
         case OpensshPrivateKeyReader.RSA_PRIVATE_BEGIN_MARKER: keyType = KeyType.RSA; break;
         case OpensshPrivateKeyReader.DSA_PRIVATE_BEGIN_MARKER: keyType = KeyType.DSA; break;
         case OpensshPrivateKeyReader.EC_PRIVATE_BEGIN_MARKER:  keyType = KeyType.EC;  break;
         }
         
         if (keyType != null) {
            // OpenSSH key format
            OpensshPrivateKeyReader opensshReader = new OpensshPrivateKeyReader(bufferedReader, passPhrase, keyType);
            keyPair = opensshReader.getKeyPair();
            ivParameterSpec = opensshReader.getIvParameterSpec();
            algorithm = opensshReader.getAlgorithm();
         } else if (beginMarker.equals(TectiaPrivateKeyReader.ENCRYPTED_PRIVATE_BEGIN_MARKER)) {
            // Tectia key format
            TectiaPrivateKeyReader tectiaReader = new TectiaPrivateKeyReader(bufferedReader, passPhrase);
            keyPair = tectiaReader.getKeyPair();
         } else {
            throw new IOException("Unsupported private key format.");
         }
      } finally {
         if (bufferedReader != null) {
            bufferedReader.close();
         }
      }
   }

   /**
    * This method will read private key data and return
    * a public and private key pair.  This is turn can
    * be used for public key authentication.  The format
    * of private key files is usually different on every
    * implementation. That's why this method does not accept
    * file names.
    *
    * @param publicKeyBlob    public key data blob
    * @param privateKeyBlob   private key data blob
    *
    * @return public/private key pair
    */
   static KeyPair load(final String publicKeyBlob, final String privateKeyBlob) throws IOException {
      KeyPair keyPair = null;

      try {
         Base64Decoder base64Decoder = new Base64Decoder();
         byte[] publicBlob = base64Decoder.decodeBuffer(publicKeyBlob);
         byte[] privateBlob = base64Decoder.decodeBuffer(privateKeyBlob);

         ByteArrayInputStream publicInputStream = new ByteArrayInputStream(publicBlob);
         ByteArrayInputStream privateInputStream = new ByteArrayInputStream(privateBlob);
         String pubAlgorithm = SSHString.readString(publicInputStream);

         if (pubAlgorithm.equals(SSHConstants.RSA_KEY_FORMAT)) {
            KeyFactory keyFactory = KeyFactory.getInstance(RSA_KEY_FACTORY);

            BigInteger publicExponent = SSHMpint.readBigInteger(publicInputStream);
            BigInteger modulus = SSHMpint.readBigInteger(publicInputStream);

            RSAPublicKeySpec rsaPublicKeySpec = new RSAPublicKeySpec(modulus, publicExponent);
            PublicKey rsaPublicKey = keyFactory.generatePublic(rsaPublicKeySpec);

            BigInteger privateExponent = SSHMpint.readBigInteger(privateInputStream);
            BigInteger primeP = SSHMpint.readBigInteger(privateInputStream);
            BigInteger primeQ = SSHMpint.readBigInteger(privateInputStream);
            BigInteger crtCoefficient = SSHMpint.readBigInteger(privateInputStream);

            BigInteger primeExponentP = privateExponent.mod(primeP.subtract(BigInteger.ONE));
            BigInteger primeExponentQ = privateExponent.mod(primeQ.subtract(BigInteger.ONE));

            RSAPrivateCrtKeySpec rsaPrivateKeySpec = new RSAPrivateCrtKeySpec(modulus, publicExponent, privateExponent,
                                                                              primeP, primeQ, primeExponentP,
                                                                              primeExponentQ, crtCoefficient);
            PrivateKey rsaPrivateKey = keyFactory.generatePrivate(rsaPrivateKeySpec);

            keyPair = new KeyPair(rsaPublicKey, rsaPrivateKey);

         } else if (pubAlgorithm.equals(SSHConstants.DSS_KEY_FORMAT)) {
            KeyFactory keyFactory = KeyFactory.getInstance(DSA_KEY_FACTORY);

            BigInteger p = SSHMpint.readBigInteger(publicInputStream);
            BigInteger q = SSHMpint.readBigInteger(publicInputStream);
            BigInteger g = SSHMpint.readBigInteger(publicInputStream);
            BigInteger y = SSHMpint.readBigInteger(publicInputStream);

            DSAPublicKeySpec dsaPublicKeySpec = new DSAPublicKeySpec(y, p, q, g);
            PublicKey dsaPublicKey = keyFactory.generatePublic(dsaPublicKeySpec);

            BigInteger x = SSHMpint.readBigInteger(privateInputStream);

            DSAPrivateKeySpec dsaPrivateKeySpec = new DSAPrivateKeySpec(x, p, q, g);
            PrivateKey dsaPrivateKey = keyFactory.generatePrivate(dsaPrivateKeySpec);

            keyPair = new KeyPair(dsaPublicKey, dsaPrivateKey);
         }
      } catch (GeneralSecurityException exception) {
         throw new IOException("Unable to load key: " + exception.toString());
      }

      return keyPair;
   }

   /**
    * Write the private key to the specified file in OpenSSH
    * private key format.  This format is similar to PEM certificate
    * format.  It is DER and base 64 encoded.  If a passPhrase is
    * specified, then the contents are encrypted.
    *
    * @param filename     output private key file name
    * @param passPhrase   pass phrase for encryption
    *
    * @return   true if the store was successful, false otherwise
    */
   public boolean store(final String filename, final char[] passPhrase) {
      if (algorithm != null) {
         return store(filename, passPhrase, algorithm);
      }

      return store(filename, passPhrase, Configuration.getPrivateKeyFileAlgorithm());
   }

   /**
    * Write the private key to the specified file in OpenSSH
    * private key format.  This format is similar to PEM certificate
    * format.  It is DER and base 64 encoded.  If a passPhrase is
    * specified, then the contents are encrypted.
    *
    * @param filename     output private key file name
    * @param passPhrase   pass phrase for encryption
    * @param cipherAlg   name of encryption algorithm (valid choices are:
    *                   "3DES", "AES", or null if no pass phrase)
    *
    * @return   true if the store was successful, false otherwise
    */
   public boolean store(final String filename, final char[] passPhrase, final String cipherAlg) {
      if (Configuration.getPrivateKeyFileFormat().equals("openssh")) {
         OpensshPrivateKeyWriter opensshWriter = new OpensshPrivateKeyWriter();
         try {
            return opensshWriter.store(keyPair, ivParameterSpec, filename, passPhrase, cipherAlg);
         } catch (IOException exception) {
         }
      }
      // TODO: handle other formats (tectia, putty, etc)

      return false;
   }
}
