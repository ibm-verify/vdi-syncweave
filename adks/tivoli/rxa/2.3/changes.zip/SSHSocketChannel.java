/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * (C) Copyright IBM Corp. 2005, 2019 All Rights Reserved
 *
 * The source code for this program is not published or other-
 * wise divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */
package com.ibm.net.ssh;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import java.net.ConnectException;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketOption;

import java.nio.ByteBuffer;
import java.nio.BufferUnderflowException;
import java.nio.channels.SocketChannel;
import java.nio.channels.AlreadyConnectedException;
import java.nio.channels.ConnectionPendingException;
import java.nio.channels.NoConnectionPendingException;
import java.nio.channels.NotYetConnectedException;
import java.nio.channels.UnresolvedAddressException;
import java.nio.channels.UnsupportedAddressTypeException;
import java.nio.channels.spi.SelectorProvider;

import java.util.Random;
import java.util.Set;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import java.util.logging.Logger;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.ShortBufferException;

/**
 * This class is responsible for all of the SSH
 * communication transport.
 *
 * @author Eric W. Brown
 */
public final class SSHSocketChannel extends SocketChannel {
   /** Copyright statement */
   private static final String COPYRIGHT = Copyright.HEADER + "2005, 2019" + Copyright.FOOTER;

   /** Packet constants */
   private static final int SIZEOF_SEQUENCE_NUMBER = 4;
   private static final int SIZEOF_PACKET_LENGTH = 4;
   private static final int SIZEOF_PADDING_LENGTH = 1;

   private static final int MIN_PACKET_LENGTH = 16;
   private static final int MAX_PACKET_LENGTH = 35000;
   private static final int MIN_PADDING_LENGTH = 4;
   private static final int MAX_PADDING_LENGTH = 255;
   private static final int MIN_PADDING_MULTIPLE = 8;
   private static final int MAX_PAYLOAD_LENGTH = 32768;

   /** Socket Type of Service (TOS) values */
   private static final int IPTOS_THROUGHPUT = 0x08;
   private static final int IPTOS_LOWDELAY   = 0x10;

   /** Maximum version string length */
   private static final int MAX_VERSION_LENGTH = 255;

   /** Debugging object */
   private static Logger logger = Logger.getLogger("com.ibm.net.ssh");

   /** Socket channel */
   private SocketChannel socketChannel;

   /** Packet sequence numbers.  Wraps to 0 every 2^32 packets */
   private long readSequenceNumber = -1;
   private long writeSequenceNumber = -1;

   /** Encrypt and decrypt ciphers */
   private Cipher encryptCipher;
   private Cipher decryptCipher;

   /** Send and receive message authenication codes */
   private Mac sendMAC;
   private Mac recvMAC;
   private int sendDigestLength;
   private int recvDigestLength;

   /** Send and receive compression */
   private Deflater sendCompression;
   private Inflater recvCompression;

   /** These are the send and receive MAC byte arrays */
   private ByteArrayOutputStream sendMacByteArray = new ByteArrayOutputStream();

   /** This is our random number generator */
   private static Random random = new Random();

   /** This is our write packet to output stream mutex */
   private Object writeMutex = new Object();

   /** Temporary byte buffer for decompressed payload */
   //private byte[] tempPayload = new byte[MAX_PAYLOAD_LENGTH];

   static final long SEQUENCE_NUMBER_LIMIT = 4294967296L;

   /**
    * Constructor
    */
   SSHSocketChannel(SocketChannel socketChannel) {
      super(SelectorProvider.provider());
      this.socketChannel = socketChannel;

      Socket socket = socketChannel.socket();

      try {
         /* Disable Nagle algorithm */
         socket.setTcpNoDelay(true);

         /* Optimize connection */
         socket.setTrafficClass(IPTOS_THROUGHPUT | IPTOS_LOWDELAY);
      } catch (SocketException exception) {
         logger.fine("SocketException in constructor: " + exception.toString());
      }
   }

   /**
    * Sets the encrypt/decrypt ciphers and turns on encryption.
    *
    * @param encryptCipher  encryption cipher
    * @param decryptCipher  decryption cipher
    */
   void setCiphers(Cipher encryptCipher, Cipher decryptCipher) {
      this.encryptCipher = encryptCipher;
      this.decryptCipher = decryptCipher;
   }

   /**
    * Sets the message authentication codes.
    *
    * @param sendMAC            send MAC
    * @param sendDigestLength   digest length for the send MAC
    * @param recvMAC            receive MAC
    * @param recvDigestLength   digest length for the receive MAC
    */
   void setMACs(Mac sendMAC, int sendDigestLength, Mac recvMAC, int recvDigestLength) {
      this.sendMAC = sendMAC;
      this.sendDigestLength = sendDigestLength;
      this.recvMAC = recvMAC;
      this.recvDigestLength = recvDigestLength;
   }

   /**
    * Sets the compression.
    *
    * @param sendCompression   send compression
    * @param recvCompression   receive compression
    */
   void setCompression(Deflater sendCompression, Inflater recvCompression) {
      this.sendCompression = sendCompression;
      this.recvCompression = recvCompression;
   }

   /**
    * Returns the current read sequence number.
    *
    * @return   read sequence number
    */
   long getReadSequenceNum() {
      return readSequenceNumber;
   }

   /**
    * Opens an SSH socket channel.
    *
    */
   public static SocketChannel open() throws IOException
   {
      SocketChannel socketChannel = SocketChannel.open();
      return new SSHSocketChannel(socketChannel);
   }

   /**
    * @see SocketChannel#connect
    */
   public boolean connect(SocketAddress remote) throws IOException
   {
      return socketChannel.connect(remote);
   }

   /**
    * Connect this SSH socket channel to the specified
    * address and port.  This method blocks until the
    * a connection is made or the time out expires.
    *
    * @param remote    remote address and port
    * @param timeout   time out
    *
    * @return   always true
    *
    * @throws IOException if there was a problem connecting
    * @throws SocketTimeoutException if timeout expires
    */
   public boolean connect(SocketAddress remote, int timeout) throws IOException
   {
      boolean isConnected = false;

      /* Turn off blocking on reads that way we can time out */
      socketChannel.configureBlocking(false);

      long startTime = System.currentTimeMillis();
      try {
         isConnected = socketChannel.connect(remote);
      } catch (AlreadyConnectedException exception) {
         throw new IOException(exception.toString());
      } catch (ConnectionPendingException exception) {
         throw new IOException(exception.toString());
      } catch (UnresolvedAddressException exception) {
         throw new IOException(exception.toString());
      } catch (UnsupportedAddressTypeException exception) {
         throw new IOException(exception.toString());
      }

      while (isConnected == false) {
         try {
            isConnected = socketChannel.finishConnect();
         } catch (NoConnectionPendingException exception) {
            throw new IOException(exception.toString());
         } catch (NullPointerException exception) {
            /* This is done because i5/OS seems to have JRE bugs with channels */
            throw new IOException(exception.toString());
         }

         if (isConnected == true) {
            break;
         } else {
            /* Not yet connected, wait a while */
            try {
               Thread.sleep(100);
            } catch (InterruptedException exception) {
               Thread.currentThread().interrupt();
               throw new ConnectException("Connection was interrupted");
            }
         }
         if ((timeout > 0) && ((System.currentTimeMillis() - startTime) >= timeout)) {
            socketChannel.close();
            /* Timeout expired */
            throw new ConnectException("Connection timed out");
         }
      }

      try {
         /* Turn blocking back on */
         socketChannel.configureBlocking(true);
      } catch (IOException exception) {
      }

      return isConnected;
   }

   /**
    * @see SocketChannel#finishConnect
    */
   public boolean finishConnect() throws IOException
   {
      return socketChannel.finishConnect();
   }

   /**
    * @see SocketChannel#isConnected
    */
   public boolean isConnected() {
      return socketChannel.isConnected();
   }

   /**
    * @see SocketChannel#isConnectionPending
    */
   public boolean isConnectionPending() {
      return socketChannel.isConnectionPending();
   }

   /**
    * @see SocketChannel#socket
    */
   public Socket socket() {
      return socketChannel.socket();
   }

   /**
    * @see SocketChannel#read
    */
   public long read(ByteBuffer[] dsts, int offset, int length) throws IOException
   {
      long bytesRead = 0;

      for (int i = offset; i < length; i++) {
         bytesRead += read(dsts[i]);
      }

      return bytesRead;
   }

   /**
    * Read one packet according to the binary packet protocol.
    *
    * @param dst   packet to read
    *
    * @return  number of bytes read
    *
    * @exception IOException
    */
   public int read(ByteBuffer dst) throws IOException
   {
      /* uint32    packet_length                                     */
      /* byte      padding_length                                    */
      /* byte[n1]  payload; n1 = packet_length - padding_length - 1  */
      /* byte[n2]  random padding; n2 = padding_length               */
      /* byte[m]   MAC (Message Authentication Code); m = mac_length */

      /* Update read sequence number */
      ++readSequenceNumber;
      if (readSequenceNumber == SEQUENCE_NUMBER_LIMIT) {
         readSequenceNumber = 0;
      }

      /* Write the read sequence number */
      dst.limit(SIZEOF_SEQUENCE_NUMBER);
      dst.position(0);
      SSHUint32.writeUnsignedInt(dst, readSequenceNumber);

      /* Determine first block size */
      int firstBlockSize;
      if (decryptCipher != null) {
         /* The amount to read first is largest of 8 or block size */
         firstBlockSize = Math.max(MIN_PADDING_MULTIPLE, decryptCipher.getBlockSize());
      } else {
         firstBlockSize = MIN_PADDING_MULTIPLE;
      }

      /* Read first block */
      SSHByte.read(socketChannel, dst, SIZEOF_SEQUENCE_NUMBER, firstBlockSize);

      /* If encryption is on, decrypt first block */
      if (decryptCipher != null) {
         try {
            decryptCipher.update(dst.array(), SIZEOF_SEQUENCE_NUMBER, firstBlockSize, dst.array(), SIZEOF_SEQUENCE_NUMBER);
         } catch (ShortBufferException exception) {
            throw new DisconnectException(SSHConstants.SSH_DISCONNECT_PROTOCOL_ERROR, "ShortBufferException on decrypt of first block: " + exception.toString());
         }
      }

      /* Read the packet length */
      dst.position(SIZEOF_SEQUENCE_NUMBER);
      int packetLength = dst.getInt();

      logger.finest("readPacket: firstBlockSize = " + firstBlockSize);
      logger.finest("readPacket: packetLength = " + packetLength);

      /* Read entire packet */
      SSHByte.read(socketChannel, dst, SIZEOF_SEQUENCE_NUMBER + firstBlockSize, packetLength + SIZEOF_PACKET_LENGTH - firstBlockSize);

      /* Each packet has min length of 16 and max of 35000 */
      if (((packetLength + SIZEOF_PACKET_LENGTH) >= MIN_PACKET_LENGTH) && (packetLength <= MAX_PACKET_LENGTH)) {
         if (decryptCipher != null) {
            try {
               decryptCipher.update(dst.array(), SIZEOF_SEQUENCE_NUMBER + firstBlockSize, packetLength + SIZEOF_PACKET_LENGTH - firstBlockSize, dst.array(), SIZEOF_SEQUENCE_NUMBER + firstBlockSize);
            } catch (ShortBufferException exception) {
               throw new DisconnectException(SSHConstants.SSH_DISCONNECT_PROTOCOL_ERROR, "ShortBufferException on decrypt: " + exception.toString());
            }
         }

         /* Read the padding length */
         dst.position(SIZEOF_SEQUENCE_NUMBER + SIZEOF_PACKET_LENGTH);
         int paddingLength = dst.get();

         logger.finest("readPacket: paddingLength = " + paddingLength);

         /* Minimum padding length is 4 and maximum payload length is 32768 */
         if ((paddingLength >= MIN_PADDING_LENGTH) && (paddingLength <= MAX_PADDING_LENGTH) && ((packetLength - paddingLength - SIZEOF_PADDING_LENGTH) <= MAX_PAYLOAD_LENGTH)) {
            /* Skip past payload */
            dst.position(SIZEOF_SEQUENCE_NUMBER + SIZEOF_PACKET_LENGTH + packetLength - paddingLength);

            /* Read the random padding */
            if (dst.remaining() != paddingLength) {
               throw new DisconnectException(SSHConstants.SSH_DISCONNECT_PROTOCOL_ERROR, "Remaining bytes length wrong! " + dst.remaining());
            }
         } else {
            throw new DisconnectException(SSHConstants.SSH_DISCONNECT_PROTOCOL_ERROR, "Padding length or max payload exceeded!");
         }

         /* Read MAC if one */
         if (recvMAC != null) {
            try {
               /* Calculate MAC */
               byte[] macOutput = new byte[recvMAC.getMacLength()];
               recvMAC.update(dst.array(), 0, SIZEOF_SEQUENCE_NUMBER + packetLength + SIZEOF_PACKET_LENGTH);
               recvMAC.doFinal(macOutput, 0);

               /* Read MAC */
               SSHByte.read(socketChannel, dst, SIZEOF_SEQUENCE_NUMBER + packetLength + SIZEOF_PACKET_LENGTH, recvDigestLength);

               /* Compare the mac output with read mac input */
               for (int i = 0; i < recvDigestLength; i++) {
                  if (macOutput[i] != dst.array()[i + SIZEOF_SEQUENCE_NUMBER + packetLength + SIZEOF_PACKET_LENGTH]) {
                     throw new DisconnectException(SSHConstants.SSH_DISCONNECT_MAC_ERROR, "MAC check failed!!, i = " + i);
                  }
               }
            } catch (ShortBufferException exception) {
               throw new DisconnectException(SSHConstants.SSH_DISCONNECT_MAC_ERROR, "ShortBufferException during mac check: " + exception.toString());
            }
         }

         /* If compression is enabled */
         //if (recvCompression != null) {
         //   recvCompression.reset();
         //   recvCompression.setInput(payload, 0, payload.length);
         //   int outputLength = 0;
         //   try {
         //      outputLength = recvCompression.inflate(tempPayload, 0, tempPayload.length);
         //   } catch (DataFormatException exception) {
         //      throw new DisconnectException(SSHConstants.SSH_DISCONNECT_COMPRESSION_ERROR, "DataFormatException during decompress: " + exception.toString());
         //   }
         //   byte[] decompressedPayload = new byte[outputLength];
         //   System.arraycopy(tempPayload, 0, decompressedPayload, 0, outputLength);
         //   return decompressedPayload;
         //}

         /* Set position on payload */
         dst.limit(SIZEOF_SEQUENCE_NUMBER + SIZEOF_PACKET_LENGTH + packetLength - paddingLength);
         dst.position(SIZEOF_SEQUENCE_NUMBER + SIZEOF_PACKET_LENGTH + SIZEOF_PADDING_LENGTH);

         return packetLength - paddingLength;
      } else {
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_PROTOCOL_ERROR, "Invalid packet length! " + packetLength);
      }
   }

   /**
    * @see SocketChannel#write
    */
   public long write(ByteBuffer[] srcs, int offset, int length) throws IOException
   {
      long bytesWritten = 0;

      for (int i = offset; i < length; i++) {
         bytesWritten += write(srcs[i]);
      }

      return bytesWritten;
   }

   /**
    * Write one packet according to the binary packet protocol.
    *
    * @param src   packet to write
    *
    * @return   number of bytes written
    *
    * @exception IOException
    */
   public int write(ByteBuffer src) throws IOException
   {
      try {
         /* uint32    packet_length                                     */
         /* byte      padding_length                                    */
         /* byte[n1]  payload; n1 = packet_length - padding_length - 1  */
         /* byte[n2]  random padding; n2 = padding_length               */
         /* byte[m]   MAC (Message Authentication Code); m = mac_length */

         /* Our packet's destination in a byte array */
         ByteArrayOutputStream packetByteArray = new ByteArrayOutputStream();

         /* If encryption is on */
         int cipherBlockSize;
         if (encryptCipher != null) {
            /* Padding multiple is the max of 8 and cipher blocksize */
            cipherBlockSize = Math.max(MIN_PADDING_MULTIPLE, encryptCipher.getBlockSize());
         } else {
            /* Padding is a multiple of this number, initially 8 */
            cipherBlockSize = MIN_PADDING_MULTIPLE;
         }

         /* If compression is enabled */
         byte[] payload;
         if (sendCompression != null) {
            sendCompression.reset();
            sendCompression.setInput(src.array());
            sendCompression.finish();
            byte[] tmpPayload = new byte[src.array().length + 4];
            int outputLength = sendCompression.deflate(tmpPayload, 0, tmpPayload.length);

            logger.finest("writePacket: uncompressed outputLength = " + src.array().length);
            logger.finest("writePacket: compressed outputLength = " + outputLength);
            logger.finest("writePacket: sendCompression done? = " + sendCompression.finished());

            payload = new byte[outputLength];
            System.arraycopy(tmpPayload, 0, payload, 0, outputLength);
            tmpPayload = null;
         } else {
            payload = src.array();
         }

         /* Calculate the padding length first */
         int totalLength = (SIZEOF_PACKET_LENGTH + SIZEOF_PADDING_LENGTH + payload.length);

         logger.finest("writePacket: cipherBlockSize = " + cipherBlockSize);
         logger.finest("writePacket: totalLength = " + totalLength);

         /* Padding length is between 4 and 255 such that the total */
         /* length is a multiplier of 8 or the cipher block size.   */
         /* Total length = packetLength + paddingLength + payload + padding */
         int paddingLength = (((totalLength / cipherBlockSize) + 1) * cipherBlockSize) - totalLength;
         if (paddingLength < MIN_PADDING_LENGTH) {
            paddingLength = (((totalLength / cipherBlockSize) + 2) * cipherBlockSize) - totalLength;
         }

         logger.finest("writePacket: paddingLength = " + paddingLength);

         /* Write the packet length */
         int packetLength = SIZEOF_PADDING_LENGTH + payload.length + paddingLength;
         SSHUint32.writeInt(packetByteArray, packetLength);

         logger.finest("writePacket: packetLength = " + packetLength);

         /* Write the padding length */
         packetByteArray.write(paddingLength);

         /* Write the payload */
         packetByteArray.write(payload);

         /* Write the random padding */
         byte[] randomPadding = new byte[paddingLength];
         random.nextBytes(randomPadding);
         packetByteArray.write(randomPadding);

         /* Encrypt the data */
         if ((encryptCipher != null) && (sendMAC != null)) {
            byte[] packetBytes = packetByteArray.toByteArray();

            //debugLogger.finest("write packetBytes = " + SSHString.bytesToString(packetBytes));

            synchronized (writeMutex) {
               byte[] encryptedBytes = encryptCipher.update(packetBytes, 0, packetBytes.length);

               //debugLogger.finest("write encryptedBytes = " + SSHString.bytesToString(encryptedBytes));

               /* Update write sequence number */
               ++writeSequenceNumber;
               if (writeSequenceNumber == SEQUENCE_NUMBER_LIMIT) {
                  writeSequenceNumber = 0;
               }

               /* Calculate the mac */
               sendMacByteArray.reset();
               SSHUint32.writeUnsignedInt(sendMacByteArray, writeSequenceNumber);
               sendMacByteArray.write(packetBytes);
               sendMAC.update(sendMacByteArray.toByteArray());
               byte[] macBytes = sendMAC.doFinal();

               /* Put data in one byte array for picky SSH servers */
               byte[] outputBytes = new byte[encryptedBytes.length + sendDigestLength];
               System.arraycopy(encryptedBytes, 0, outputBytes, 0, encryptedBytes.length);
               System.arraycopy(macBytes, 0, outputBytes, encryptedBytes.length, sendDigestLength);

               ByteBuffer byteBuffer = ByteBuffer.wrap(outputBytes, 0, outputBytes.length);
               socketChannel.write(byteBuffer);
            }
         } else {
            synchronized (writeMutex) {
               /* Update write sequence number */
               ++writeSequenceNumber;
               if (writeSequenceNumber == SEQUENCE_NUMBER_LIMIT) {
                  writeSequenceNumber = 0;
               }

               ByteBuffer byteBuffer = ByteBuffer.wrap(packetByteArray.toByteArray());
               socketChannel.write(byteBuffer);
            }
         }

         return payload.length;
      } catch (NotYetConnectedException exception) {
         throw new IOException(exception.toString());
      }
   }

   /**
    * @see AbstractSelectableChannel.implCloseSelectableChannel
    */
   public void implCloseSelectableChannel() {
      //socketChannel.implCloseSelectableChannel();
   }

   /**
    * @see AbstractSelectableChannel.implConfigureBlocking
    */
   public void implConfigureBlocking(boolean block) {
      //socketChannel.implConfigureBlocking(block);
   }

   /**
    * Read a "line" from the SSH server (with CR/LF).
    */
   String readLine(int timeout) {
      ByteBuffer byteBuffer = ByteBuffer.allocate(1);
      StringBuffer stringBuffer = new StringBuffer();
      char singleChar = ' ';

      try {
         int readChars = 0;

         /* Turn off blocking on reads that way we can time out */
         socketChannel.configureBlocking(false);

         long startTime = System.currentTimeMillis();

         while ((singleChar != '\n') && (readChars <= MAX_VERSION_LENGTH)) {
            byteBuffer.position(0);
            byteBuffer.limit(1);
            int bytesRead = socketChannel.read(byteBuffer);
            if (bytesRead > 0) {
               byteBuffer.position(0);
               byte singleByte = byteBuffer.get();
               if (singleByte < 0) {
                  throw new IOException("Non-ASCII byte");
               }
               singleChar = (char) singleByte;

               if (singleChar != '\r') {
                  stringBuffer.append(singleChar);
               }
               ++readChars;
            } else {
               /* Nothing on the stream, wait a while */
               try {
                  Thread.sleep(100);
               } catch (InterruptedException exception) {
                  Thread.currentThread().interrupt();
                  break;
               }
            }
            if ((timeout > 0) && ((System.currentTimeMillis() - startTime) >= timeout)) {
               /* Timeout expired */
               break;
            }
         }
      } catch (BufferUnderflowException exception) {
      } catch (NotYetConnectedException exception) {
      } catch (IOException exception) {
      }

      try {
         /* Turn blocking back on */
         socketChannel.configureBlocking(true);
      } catch (IOException exception) {
      }

      if (stringBuffer.length() > 0) {
         return stringBuffer.substring(0, stringBuffer.length() - 1);
      } else {
         return stringBuffer.toString();
      }
   }

   /**
    * Send a "line" to the SSH server (with CR/LF).
    */
   void sendLine(String line) {
      /* Copy line and control line/line feed into one byte array */
      byte[] b = new byte[line.getBytes().length + 2];
      System.arraycopy(line.getBytes(), 0, b, 0, line.getBytes().length);
      b[b.length - 2] = '\r';
      b[b.length - 1] = '\n';

      ByteBuffer byteBuffer = ByteBuffer.wrap(b, 0, b.length);

      /* Write out line */
      try {
         socketChannel.write(byteBuffer);
      } catch (IOException exception) {
      }
   }

   @Override
   public SocketAddress getLocalAddress() throws IOException {
	   return socketChannel.getLocalAddress();
   }

   @Override
   public <T> T getOption(SocketOption<T> name) throws IOException {
	   return socketChannel.getOption(name);
   }

   @Override
   public Set<SocketOption<?>> supportedOptions() {
	   return socketChannel.supportedOptions();
   }

   @Override
   public SocketChannel bind(SocketAddress local) throws IOException {
	   // TODO Auto-generated method stub
	   socketChannel.bind(local);
	   return this;
   }

   @Override
   public <T> SocketChannel setOption(SocketOption<T> name, T value)
		   throws IOException {
	   socketChannel.setOption(name, value);
	   return this;
   }

   @Override
   public SocketChannel shutdownInput() throws IOException {
	   socketChannel.shutdownInput();
	   return this;
   }

   @Override
   public SocketChannel shutdownOutput() throws IOException {
	   socketChannel.shutdownOutput();
	   return this;
   }

   @Override
   public SocketAddress getRemoteAddress() throws IOException {
	   return socketChannel.getRemoteAddress();
   }

}
