/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * (C) Copyright IBM Corp. 2005, 2019 All Rights Reserved
 *
 * The source code for this program is not published or other-
 * wise divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */
package com.ibm.net.ssh;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import java.net.InetAddress;
import java.net.UnknownHostException;

import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;
import java.security.SignatureException;
import java.security.interfaces.DSAParams;
import java.security.interfaces.DSAPublicKey;
import java.security.interfaces.RSAPublicKey;

/**
 * This class represents a host based authentication
 * method.  Most SSH servers do not support this method.
 * It is viewed as less secure than password or public
 * key method.
 *
 * @author Eric W. Brown
 */
public class AuthHostBased extends AuthMethod {
   /** Copyright statement */
   private static final String COPYRIGHT = Copyright.HEADER + "2005, 2019" + Copyright.FOOTER;

   /** The host based authentication method name */
   private static final String HOST_BASED_METHOD = "hostbased";

   /** Public/private key pair of local client host */
   private KeyPair keyPair;

   /** Local address */
   private InetAddress inetAddress;

   /** User name of local client host */
   private String clientUsername;

   /** Raw DSS constants */
   private static final byte R_SIZE = 0x14;
   private static final byte S_SIZE = 0x14;

   /**
    * Construct a host based authentication method.
    *
    * @param username        user name of remote host
    * @param keyPair         public/private key pair of client host
    */
   public AuthHostBased(String username, KeyPair keyPair) {
      super(username);

      if (keyPair != null) {
         this.keyPair = keyPair;

         try {
            inetAddress = InetAddress.getLocalHost();
         } catch (UnknownHostException exception) {
         }

         clientUsername = System.getProperty("user.name");
         if (clientUsername == null) {
            clientUsername = "";
         }
      } else {
         throw new NullPointerException("keyPair is null");
      }
   }

   /**
    * Construct a host based authentication method.
    * This method takes a public key also as a
    * parameter.  If not null, this public key is
    * copied to the SSH server automatically.
    *
    * @param username        user name of remote host
    * @param keyPair         public/private key pair of client host
    * @param publicKeyFile   public key to copy
    */
   public AuthHostBased(String username, KeyPair keyPair, PublicKeyFile publicKeyFile) {
      super(username, publicKeyFile);

      this.keyPair = keyPair;

      if (keyPair != null) {
         try {
            inetAddress = InetAddress.getLocalHost();
         } catch (UnknownHostException exception) {
         }

         clientUsername = System.getProperty("user.name");
         if (clientUsername == null) {
            clientUsername = "";
         }
      } else {
         throw new NullPointerException("keyPair is null");
      }
   }

   /**
    * Return the authentication method name string.
    *
    * @return  method name string
    */
   public String getMethodName() {
      return HOST_BASED_METHOD;
   }

   /**
    * Return the request packet byte array
    * for this authentication method.
    *
    * @param sessionIdentifier   session identifier byte array
    *
    * @return byte array containing host based auth message
    *
    * @exception IOException
    */
   byte[] getRequestPacket(byte[] sessionIdentifier) throws IOException {
      ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();

      /* byte      SSH_MSG_USERAUTH_REQUEST                                 */
      /* string    user name                                                */
      /* string    service                                                  */
      /* string    "hostbased"                                              */
      /* string    public key algorithm for host key                        */
      /* string    public host key and certificates for client host         */
      /* string    client host name expressed as the FQDN in US-ASCII       */
      /* string    user name on the client host in ISO-10646 UTF-8 encoding */
      /* string    signature                                                */

      /* Write the message type */
      byteOutputStream.write(SSHConstants.SSH_MSG_USERAUTH_REQUEST);

      SSHString.writeString(byteOutputStream, username);
      SSHString.writeString(byteOutputStream, SSHConstants.CONNECTION_SERVICE);
      SSHString.writeString(byteOutputStream, HOST_BASED_METHOD);

      PublicKey publicKey = keyPair.getPublic();
      PrivateKey privateKey = keyPair.getPrivate();

      String algorithm;
      byte[] publicKeyBlob;
      if (publicKey instanceof RSAPublicKey) {
         algorithm = getRSAKeyAlgorithm();
         logger.finer("AuthHostBased: Using RSA algorithm " + algorithm);
         SSHString.writeString(byteOutputStream, algorithm);

         RSAPublicKey rsaPublicKey = (RSAPublicKey)publicKey;
         ByteArrayOutputStream publicKeyBlobStream = new ByteArrayOutputStream();
         SSHString.writeString(publicKeyBlobStream, SSHConstants.RSA_KEY_FORMAT);
         SSHMpint.writeBigInteger(publicKeyBlobStream, rsaPublicKey.getPublicExponent());
         SSHMpint.writeBigInteger(publicKeyBlobStream, rsaPublicKey.getModulus());
         publicKeyBlob = publicKeyBlobStream.toByteArray();

      } else {
         algorithm = SSHConstants.DSS_KEY_FORMAT;
         SSHString.writeString(byteOutputStream, algorithm);

         DSAPublicKey dsaPublicKey = (DSAPublicKey)publicKey;
         DSAParams dsaParams = dsaPublicKey.getParams();
         ByteArrayOutputStream publicKeyBlobStream = new ByteArrayOutputStream();
         SSHString.writeString(publicKeyBlobStream, algorithm);
         SSHMpint.writeBigInteger(publicKeyBlobStream, dsaParams.getP());
         SSHMpint.writeBigInteger(publicKeyBlobStream, dsaParams.getQ());
         SSHMpint.writeBigInteger(publicKeyBlobStream, dsaParams.getG());
         SSHMpint.writeBigInteger(publicKeyBlobStream, dsaPublicKey.getY());
         publicKeyBlob = publicKeyBlobStream.toByteArray();
      }
      SSHString.writeString(byteOutputStream, publicKeyBlob);
      SSHString.writeString(byteOutputStream, inetAddress.getCanonicalHostName());
      SSHString.writeString(byteOutputStream, clientUsername);

      byte[] sigBytes = generateSignature(algorithm, sessionIdentifier, publicKeyBlob, privateKey);
      SSHString.writeString(byteOutputStream, sigBytes);

      return byteOutputStream.toByteArray();
   }

   /**
    * Generate a public key signature for public-key authentication.
    *
    * @param user               username for public key
    * @param algorithm          public key algorithm
    * @param sessionIdentifier  session identifier
    * @param publicKeyBlob      public key blob
    * @param privateKey         private key
    *
    * @return   signature bytes
    *
    * @exception IOException
    */
   private byte[] generateSignature(String algorithm, byte[] sessionIdentifier, byte[] publicKeyBlob, PrivateKey privateKey) throws IOException {
      byte[] resultBytes = null;

      try {
         Signature signature;
         if (algorithm.equals(SSHConstants.RSA_KEY_FORMAT)) {
            signature = Signature.getInstance("SHA1withRSA");
         } else if (algorithm.equals(SSHConstants.RSA_SHA2_256_ALGORITHM)) {
            signature = Signature.getInstance("SHA256withRSA");
         } else if (algorithm.equals(SSHConstants.RSA_SHA2_512_ALGORITHM)) {
            signature = Signature.getInstance("SHA512withRSA");
         } else {
            signature = Signature.getInstance("SHA1withDSA");
         }

         signature.initSign(privateKey, SSHConstants.SECURE_RANDOM);

         ByteArrayOutputStream signatureStream = new ByteArrayOutputStream();
         SSHString.writeString(signatureStream, sessionIdentifier);
         signatureStream.write(SSHConstants.SSH_MSG_USERAUTH_REQUEST);
         SSHString.writeString(signatureStream, username);
         SSHString.writeString(signatureStream, SSHConstants.CONNECTION_SERVICE);
         SSHString.writeString(signatureStream, HOST_BASED_METHOD);
         SSHString.writeString(signatureStream, algorithm);
         SSHString.writeString(signatureStream, publicKeyBlob);
         SSHString.writeString(signatureStream, inetAddress.getCanonicalHostName());
         SSHString.writeString(signatureStream, clientUsername);

         signature.update(signatureStream.toByteArray());
         byte[] sigBytes = signature.sign();

         /* Strip out DER encoding (see KeyExchange) */
         if (algorithm.equals(SSHConstants.DSS_KEY_FORMAT)) {
            byte[] finalSigBytes = new byte[R_SIZE + S_SIZE];
            /* Sometimes there is a leading 0 byte, strip it out */
            if (sigBytes.length > (R_SIZE + S_SIZE + 4 + 2)) {
               int rStart = 4;
               int sStart = 2;
               /* Third byte is the length of R */
               if ((sigBytes[3] == (R_SIZE + 1)) && (sigBytes[rStart] == 0)) {
                  rStart = 5;
               }
               /* This byte is the length of S */
               if ((sigBytes[rStart + R_SIZE + 1] == (R_SIZE + 1)) && (sigBytes[rStart + R_SIZE + sStart] == 0)) {
                  sStart = 3;
               }
               System.arraycopy(sigBytes, rStart, finalSigBytes, 0, R_SIZE);
               System.arraycopy(sigBytes, rStart + R_SIZE + sStart, finalSigBytes, R_SIZE, S_SIZE);
            } else {
               /* Signature is already okay */
               System.arraycopy(sigBytes, 4, finalSigBytes, 0, R_SIZE);
               System.arraycopy(sigBytes, 4 + R_SIZE + 2, finalSigBytes, R_SIZE, S_SIZE);
            }
            sigBytes = finalSigBytes;
         }

         ByteArrayOutputStream resultStream = new ByteArrayOutputStream();
         SSHString.writeString(resultStream, algorithm);
         SSHString.writeString(resultStream, sigBytes);
         resultBytes = resultStream.toByteArray();

      } catch (InvalidKeyException exception) {
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_BY_APPLICATION, "Invalid key for signature: " + exception.toString());
      } catch (SignatureException exception) {
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_BY_APPLICATION, "Signature exception during update or sign: " + exception.toString());
      } catch (NoSuchAlgorithmException exception) {
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_BY_APPLICATION, "No such algorithm for signature: " + exception.toString());
      }

      return resultBytes;
   }
}

