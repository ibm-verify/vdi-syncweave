/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * (C) Copyright IBM Corp. 2007, 2019 All Rights Reserved
 *
 * The source code for this program is not published or other-
 * wise divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */
package com.ibm.net.ssh;

import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;

import java.math.BigInteger;

import java.nio.ByteBuffer;

/**
 * Represents multiple precision integers in two's complement format,
 * stored as a string, 8 bits per byte, MSB first.  Negative numbers
 * have the value 1 as the most significant bit of the first byte of
 * the data partition.  If the most significant bit would be set for
 * a positive number, the number MUST be preceded by a zero byte.
 * Unnecessary leading bytes with the value 0 or 255 MUST NOT be
 * included.  The value zero MUST be stored as a string with zero
 * bytes of data.
 *
 * By convention, a number that is used in modular computations in
 * Z_n SHOULD be represented in the range 0 <= x < n.
 *     Examples:
 *
 *     value (hex)        representation (hex)
 *     -----------        --------------------
 *     0                  00 00 00 00
 *     9a378f9b2e332a7    00 00 00 08 09 a3 78 f9 b2 e3 32 a7
 *     80                 00 00 00 02 00 80
 *     -1234              00 00 00 02 ed cc
 *     -deadbeef          00 00 00 05 ff 21 52 41 11
 *
 * @author Eric W. Brown
 */
public final class SSHMpint {
   /** Copyright statement. */
   private static final String COPYRIGHT = Copyright.HEADER + "2007, 2019" + Copyright.FOOTER;

   /** The maximum reasonable size for a byte array. */
   private static final int MAX_BYTE_LENGTH = 131072;

   /** The number of bytes per bit. */
   private static final int BITS_PER_BYTE = 8;

   /** The value. */
   private BigInteger value;

   /**
    * Constructor.
    *
    * @param  value to initialize with
    */
   public SSHMpint(final BigInteger value) {
      this.value = value;
   }

   /**
    * Constructor.
    *
    * @param  inputStream containing value to initialize with
    *
    * @throws IOException  if problem reading from stream
    */
   public SSHMpint(final InputStream inputStream) throws IOException {
      value = readBigInteger(inputStream);
   }

   /**
    * Constructor.
    *
    * @param  byteBuffer containing value to initialize with
    *
    * @throws IOException  if problem reading from byte buffer
    */
   public SSHMpint(final ByteBuffer byteBuffer) throws IOException {
      value = readBigInteger(byteBuffer);
   }

   /**
    * Read an big integer value from the stream.
    *
    * @param inputStream   stream to read from
    *
    * @return   big integer value
    *
    * @throws IOException  if problem reading from stream
    */
   public static BigInteger readBigInteger(final InputStream inputStream) throws IOException {
      byte[] byteArray = SSHString.readStringAsBytes(inputStream);
      return new BigInteger(byteArray);
   }

   /**
    * Read a positive big integer value from the stream.
    *
    * @param inputStream   stream to read from
    *
    * @return   big integer value
    *
    * @throws IOException  if problem reading from stream
    */
   public static BigInteger readPositiveBigInteger(final InputStream inputStream) throws IOException {
      byte[] byteArray = SSHString.readStringAsBytes(inputStream);
      return new BigInteger(1, byteArray);
   }

   /**
    * Read an big integer value from the stream.  This
    * method differs in that the byte length is encoded
    * as bits, not bytes.
    *
    * @param inputStream   stream to read from
    *
    * @return   big integer value
    *
    * @throws IOException  if problem reading from stream
    */
   public static BigInteger readBigIntegerWithBits(final InputStream inputStream) throws IOException {
      final int bits = SSHUint32.readInt(inputStream);
      // new offset = (offset + align - 1) & ~(align - 1)
      final int byteArrayLength = ((bits + BITS_PER_BYTE - 1) & -BITS_PER_BYTE) / BITS_PER_BYTE;

      if (byteArrayLength >= 0) {
         if (byteArrayLength < MAX_BYTE_LENGTH) {
            final byte[] byteArray = new byte[byteArrayLength];
            SSHByte.read(inputStream, byteArray);

            return new BigInteger(1, byteArray);
         } else {
            throw new IOException("Read byte array length too large = " + byteArrayLength);
         }
      } else {
         throw new IOException("Read negative byte array length = " + byteArrayLength);
      }
   }

   /**
    * Read an big integer value from the byte buffer.
    *
    * @param byteBuffer   byte buffer to read from
    *
    * @return   big integer value
    *
    * @throws IOException  if problem reading from byte buffer
    */
   public static BigInteger readBigInteger(final ByteBuffer byteBuffer) throws IOException {
      byte[] byteArray = SSHString.readStringAsBytes(byteBuffer);
      return new BigInteger(byteArray);
   }

   /**
    * Write a big integer value to the stream.
    *
    * @param outputStream   stream to write value
    *
    * @throws IOException  if problem reading from stream
    */
   public void writeBigInteger(final OutputStream outputStream) throws IOException {
      writeBigInteger(outputStream, value);
   }

   /**
    * Write a big integer value to the stream.
    *
    * @param outputStream   stream to write value
    * @param value          big integer to write
    *
    * @throws IOException  if problem reading from stream
    */
   public static void writeBigInteger(final OutputStream outputStream, final BigInteger value) throws IOException {
      SSHString.writeString(outputStream, value.toByteArray());
   }
}
