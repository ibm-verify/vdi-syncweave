/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * (C) Copyright IBM Corp. 2005, 2019 All Rights Reserved
 *
 * The source code for this program is not published or other-
 * wise divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */
package com.ibm.net.ssh;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import java.nio.ByteBuffer;

import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;
import java.security.SignatureException;
import java.security.interfaces.DSAParams;
import java.security.interfaces.DSAPublicKey;
import java.security.interfaces.ECPublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.ECPoint;

import com.ibm.net.ssh.ECDHKeyExchange.Point;

/**
 * This class represents the public key
 * authentication method.  This is the preferred
 * method of login.  While a public key can be
 * harmless if stolen, the private key is not.  The
 * private key of the key pair must be protected as
 * if it were a password.
 *
 * @author Eric W. Brown
 */
public class AuthPublicKey extends AuthMethod {
   /** Copyright statement */
   private static final String COPYRIGHT = Copyright.HEADER + "2005, 2019" + Copyright.FOOTER;

   /** The public key authentication method name */
   private static final String PUBLIC_KEY_METHOD = "publickey";

   /** The user's public and private key pair */
   private KeyPair keyPair;

   /** Raw DSS constants */
   private static final byte R_SIZE = 0x14;
   private static final byte S_SIZE = 0x14;

   /**
    * Construct a public key based authentication
    * method.
    *
    * @param username  user name string
    * @param keyPair   public/private key pair.
    *
    * @see SSHKeyGenerator
    */
   public AuthPublicKey(String username, KeyPair keyPair) {
      super(username);

      if (keyPair != null) {
         this.keyPair = keyPair;
      } else {
         throw new NullPointerException("keyPair is null");
      }
   }

   /**
    * Construct a public key based authentication
    * method.  This method takes a public key also
    * as a parmameter.  If not null, this public key
    * is copied to the SSH server automatically.
    *
    * @param username        user name string
    * @param keyPair         public/private key pair.
    * @param publicKeyFile   public key to copy
    *
    * @see SSHKeyGenerator
    */
   public AuthPublicKey(String username, KeyPair keyPair, PublicKeyFile publicKeyFile) {
      super(username, publicKeyFile);

      if (keyPair != null) {
         this.keyPair = keyPair;
      } else {
         throw new NullPointerException("keyPair is null");
      }
   }

   /**
    * Return the authentication method name string.
    *
    * @return  method name string
    */
   public String getMethodName() {
      return PUBLIC_KEY_METHOD;
   }

   /**
    * Return the public/private key pair to
    * use in authentication.
    *
    * @return  the key pair object
    */
   public KeyPair getKeyPair() {
      return keyPair;
   }

   /**
    * Return the request packet byte array
    * for this authentication method.
    *
    * @return  byte array containing public key auth message
    */
   byte[] getRequestPacket(byte[] sessionIdentifier) throws IOException {
      ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();

      /* byte      SSH_MSG_USERAUTH_REQUEST  */
      /* string    user name                 */
      /* string    service                   */
      /* string    "publickey"               */
      /* boolean   FALSE                     */
      /* string    public key algorithm name */
      /* string    public key blob           */

      /* Write the message type */
      byteOutputStream.write(SSHConstants.SSH_MSG_USERAUTH_REQUEST);

      SSHString.writeString(byteOutputStream, username);
      SSHString.writeString(byteOutputStream, SSHConstants.CONNECTION_SERVICE);
      SSHString.writeString(byteOutputStream, PUBLIC_KEY_METHOD);
      SSHBoolean.writeBoolean(byteOutputStream, true);

      PublicKey publicKey = keyPair.getPublic();
      PrivateKey privateKey = keyPair.getPrivate();

      String algorithm;
      byte[] publicKeyBlob;
      if (publicKey instanceof RSAPublicKey) {
         algorithm = getRSAKeyAlgorithm();
         logger.finer("AuthPublicKey: Using algorithm " + algorithm);
         SSHString.writeString(byteOutputStream, algorithm);

         RSAPublicKey rsaPublicKey = (RSAPublicKey)publicKey;
         ByteArrayOutputStream publicKeyBlobStream = new ByteArrayOutputStream();
         SSHString.writeString(publicKeyBlobStream, SSHConstants.RSA_KEY_FORMAT);
         SSHMpint.writeBigInteger(publicKeyBlobStream, rsaPublicKey.getPublicExponent());
         SSHMpint.writeBigInteger(publicKeyBlobStream, rsaPublicKey.getModulus());
         publicKeyBlob = publicKeyBlobStream.toByteArray();

      } else if (publicKey instanceof ECPublicKey) {
          ECPublicKey ecPublicKey = (ECPublicKey)publicKey;
          ECPoint w = ecPublicKey.getW();
          byte[] r = w.getAffineX().toByteArray();
          algorithm = SSHConstants.ECDSA_SHA2_NISTP_521;
          if (r.length <= 33)
        	  algorithm = SSHConstants.ECDSA_SHA2_NISTP_256;
          else if (r.length <= 49)
        	  algorithm = SSHConstants.ECDSA_SHA2_NISTP_384;
          logger.finer("AuthPublicKey: Using algorithm " + algorithm + ", r.length=" + r.length);
          SSHString.writeString(byteOutputStream, algorithm);

          ByteArrayOutputStream publicKeyBlobStream = new ByteArrayOutputStream();
          SSHString.writeString(publicKeyBlobStream, algorithm);
          SSHString.writeString(publicKeyBlobStream, algorithm.substring(11));
          
          Point point = new Point(r, w.getAffineY().toByteArray());
          SSHMpint.writeBigInteger(publicKeyBlobStream, point.toBigInteger());
 
          publicKeyBlob = publicKeyBlobStream.toByteArray();
          //logger.finer("AuthPublicKey: keyblob: " + bytesToString(publicKeyBlob));
       } else {
         algorithm = SSHConstants.DSS_KEY_FORMAT;
         SSHString.writeString(byteOutputStream, algorithm);

         DSAPublicKey dsaPublicKey = (DSAPublicKey)publicKey;
         DSAParams dsaParams = dsaPublicKey.getParams();
         ByteArrayOutputStream publicKeyBlobStream = new ByteArrayOutputStream();
         SSHString.writeString(publicKeyBlobStream, algorithm);
         SSHMpint.writeBigInteger(publicKeyBlobStream, dsaParams.getP());
         SSHMpint.writeBigInteger(publicKeyBlobStream, dsaParams.getQ());
         SSHMpint.writeBigInteger(publicKeyBlobStream, dsaParams.getG());
         SSHMpint.writeBigInteger(publicKeyBlobStream, dsaPublicKey.getY());
         publicKeyBlob = publicKeyBlobStream.toByteArray();
      }
      SSHString.writeString(byteOutputStream, publicKeyBlob);
      byte[] sigBytes = generateSignature(algorithm, sessionIdentifier, publicKeyBlob, privateKey);
      SSHString.writeString(byteOutputStream, sigBytes);

      return byteOutputStream.toByteArray();
   }

//   private String bytesToString(byte[] blob) {
//	   StringBuilder buf = new StringBuilder();
//	   for (int i=0; i< blob.length; i++) {
//		   buf.append(blob[i]).append(", ");
//	   }
//	   return buf.toString();
//   }

   /**
    * Generate a public key signature for public-key authentication.
    *
    * @param algorithm           public key algorithm
    * @param sessionIdentifier   session identifier
    * @param publicKeyBlob       public key blob
    * @param privateKey          private key
    *
    * @return   signature bytes
    *
    * @exception IOException
    */
   private byte[] generateSignature(String algorithm, byte[] sessionIdentifier, byte[] publicKeyBlob, PrivateKey privateKey) throws IOException {
      byte[] resultBytes = null;

      try {
         Signature signature;
         if (algorithm.equals(SSHConstants.RSA_KEY_FORMAT)) {
             signature = Signature.getInstance("SHA1withRSA");
          } else if (algorithm.equals(SSHConstants.RSA_SHA2_256_ALGORITHM)) {
             signature = Signature.getInstance("SHA256withRSA");
          } else if (algorithm.equals(SSHConstants.RSA_SHA2_512_ALGORITHM)) {
             signature = Signature.getInstance("SHA512withRSA");
          } else if (algorithm.equals(SSHConstants.ECDSA_SHA2_NISTP_256)) {
              signature = Signature.getInstance("SHA256withECDSA");
          } else if (algorithm.equals(SSHConstants.ECDSA_SHA2_NISTP_384)) {
              signature = Signature.getInstance("SHA384withECDSA");
          } else if (algorithm.equals(SSHConstants.ECDSA_SHA2_NISTP_521)) {
              signature = Signature.getInstance("SHA512withECDSA");
          } else {
             signature = Signature.getInstance("SHA1withDSA");
          }

         signature.initSign(privateKey, SSHConstants.SECURE_RANDOM);

         ByteArrayOutputStream signatureStream = new ByteArrayOutputStream();
         SSHString.writeString(signatureStream, sessionIdentifier);
         signatureStream.write(SSHConstants.SSH_MSG_USERAUTH_REQUEST);
         SSHString.writeString(signatureStream, username);
         SSHString.writeString(signatureStream, SSHConstants.CONNECTION_SERVICE);
         SSHString.writeString(signatureStream, PUBLIC_KEY_METHOD);
         SSHBoolean.writeBoolean(signatureStream, true);
         SSHString.writeString(signatureStream, algorithm);
         SSHString.writeString(signatureStream, publicKeyBlob);

         signature.update(signatureStream.toByteArray());
         byte[] sigBytes = signature.sign();

         /* Strip out DER encoding (see KeyExchange) */
         if (algorithm.equals(SSHConstants.DSS_KEY_FORMAT)) {
            sigBytes = removeDerEncoding(sigBytes);;
         } else if (algorithm.startsWith(KeyExchange.ECDSA_SHA2_NISTP_PREFIX)) {
        	 sigBytes = KeyExchange.fromASN1(sigBytes);  
         }

         ByteArrayOutputStream resultStream = new ByteArrayOutputStream();
         SSHString.writeString(resultStream, algorithm);
         SSHString.writeString(resultStream, sigBytes);
         resultBytes = resultStream.toByteArray();

      } catch (InvalidKeyException exception) {
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_BY_APPLICATION, "Invalid key for signature: " + exception.toString());
      } catch (SignatureException exception) {
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_BY_APPLICATION, "Signature exception during update or sign: " + exception.toString());
      } catch (NoSuchAlgorithmException exception) {
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_BY_APPLICATION, "No such algorithm for signature: " + exception.toString());
      }

      return resultBytes;
   }

   /**
    * Strip out the DER encoding from the DSA key
    * signature.
    *
    * @param sigBytes  source byte array with DER encoding
    *
    * @return  byte array without any DER encoding
    */
   private byte[] removeDerEncoding(byte[] sigBytes) {
      byte[] finalSigBytes = new byte[R_SIZE + S_SIZE];

      if ((sigBytes[3] == R_SIZE) && (sigBytes[R_SIZE + 5] == S_SIZE)) {
         /* Signature is already okay */
         System.arraycopy(sigBytes, 4, finalSigBytes, 0, R_SIZE);
         System.arraycopy(sigBytes, 4 + R_SIZE + 2, finalSigBytes, R_SIZE, S_SIZE);
      } else {
         byte[] r = new byte[R_SIZE];
         int rStart = 4;
         /* Fourth byte is the length of R */
         int rSize = sigBytes[3];

         if (rSize == R_SIZE) {
            System.arraycopy(sigBytes, rStart, r, 0, R_SIZE);
         } else if (rSize > R_SIZE) {
            if (sigBytes[rStart] == 0) {
               /* Copy into r */
               System.arraycopy(sigBytes, rStart + 1, r, 0, R_SIZE);
            } else {
               // error
               logger.fine("r size larger than 20, but not zero padded!");
            }
         } else {
            /* Pad R with zero */
            r[0] = 0;
            System.arraycopy(sigBytes, rStart, r, 1, R_SIZE - 1);
         }

         byte[] s = new byte[S_SIZE];
         int sStart = rStart + rSize + 2;
         /* This byte is the length of S */
         int sSize = sigBytes[rStart + rSize + 1];

         if (sSize == S_SIZE) {
            System.arraycopy(sigBytes, sStart, s, 0, S_SIZE);
         } else if (sSize > S_SIZE) {
            if (sigBytes[sStart] == 0) {
               /* Copy into s */
               System.arraycopy(sigBytes, sStart + 1, s, 0, S_SIZE);
            } else {
               // error
               logger.fine("s size larger than 20, but not zero padded!");
            }
         } else {
            /* Pad S with zero */
            s[0] = 0;
            System.arraycopy(sigBytes, sStart, s, 1, S_SIZE - 1);
         }

         /* Copy into final array */
         System.arraycopy(r, 0, finalSigBytes, 0, R_SIZE);
         System.arraycopy(s, 0, finalSigBytes, R_SIZE, S_SIZE);
      }

      return finalSigBytes;
   }

   /**
    * Handle incoming authentication packet.
    *
    * @exception IOException
    */
   AuthMethod handlePacket(int message, ByteBuffer byteBuffer) throws IOException {
      switch (message) {
         case SSHConstants.SSH_MSG_USERAUTH_PK_OK:
            logger.fine("handlePacket: SSH_MSG_USERAUTH_PK_OK");
            handleUserauthPublicKeyOk(byteBuffer);
            break;
         default:
            super.handlePacket(message, byteBuffer);
            break;
      }

      return null;
   }

   /**
    * Handle a user authorization public key ok message.
    *
    * @param byteBuffer
    *
    * @exception IOException
    */
   private void handleUserauthPublicKeyOk(ByteBuffer byteBuffer) throws IOException {
      /* byte      SSH_MSG_USERAUTH_PK_OK                     */
      /* string    public key algorithm name from the request */
      /* string    public key blob from the request           */

      String publicKeyAlgorithm = SSHString.readString(byteBuffer);
      String publicKeyBlob = SSHString.readString(byteBuffer);

      logger.finer("handleUserauthPublicKeyOk: publicKeyAlgorithm = " + publicKeyAlgorithm);
//      logger.finer("handleUserauthPublicKeyOk: publicKeyBlob = " + publicKeyBlob);
   }
}

