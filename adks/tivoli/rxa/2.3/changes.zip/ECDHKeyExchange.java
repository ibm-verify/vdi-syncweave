/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * (C) Copyright IBM Corp. 2019 All Rights Reserved
 *
 * The source code for this program is not published or other-
 * wise divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */
package com.ibm.net.ssh;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import java.math.BigInteger;

import java.nio.ByteBuffer;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECFieldFp;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.ECPublicKeySpec;
import java.security.spec.EllipticCurve;

import javax.crypto.KeyAgreement;

/**
 * This class is responsible for Elliptic-curve Diffie–Hellman
 * key exchange mechanism of the SSH protocol.
 *
 * @author Jens Thomassen
 */
final class ECDHKeyExchange extends KeyExchange {
	/** Copyright statement */
	private static final String COPYRIGHT = Copyright.HEADER + "2019" + Copyright.FOOTER;

	private final static BigInteger TWO = BigInteger.ONE.add(BigInteger.ONE);
	private final static BigInteger THREE = TWO.add(BigInteger.ONE);

	private int keySize;

	private ECPublicKey publicKey;
	private PrivateKey privateKey;

	/**
	 * Constructor
	 */
	ECDHKeyExchange(SecureSession sshSession, String kexAlgorithm, byte[] serverKexInitPayload, byte[] sessionIdentifier) {
		super(sshSession, kexAlgorithm, serverKexInitPayload, sessionIdentifier);

		if (kexAlgorithm.equals(KeyExchange.ECDH_SHA2_NISTP256))
			keySize = 256;
		else if (kexAlgorithm.equals(KeyExchange.ECDH_SHA2_NISTP384))
			keySize = 384;
		else
			keySize = 521;
	}

	/**
	 * Handle incoming connection packet.
	 *
	 * @param message      the packet message number
	 * @param byteBuffer   the packet's payload buffer
	 *
	 * @return    whether the packet message was handled or not
	 * @exception IOException
	 */
	boolean handlePacket(int message, ByteBuffer byteBuffer) throws IOException {
		boolean packetHandled = true;

		switch (message) {
		case SSHConstants.SSH_MSG_KEXINIT:
			logger.fine("handlePacket: ECDHKeyExchange: SSH_MSG_KEXINIT");
			handleKeyExchangeInit(byteBuffer);
			break;
		case SSHConstants.SSH_MSG_KEXDH_REPLY:
			logger.fine("handlePacket: SSH_MSG_KEX_ECDH_REPLY");
			handleKeyExchangeDHReply(byteBuffer);
			break;
		default:
			packetHandled = super.handlePacket(message, byteBuffer);
			break;
		}

		return packetHandled;
	}

	/**
	 * Handle the key exchange initialize message.
	 *
	 * @param byteBuffer
	 *
	 * @exception IOException
	 */
	protected void handleKeyExchangeInit(ByteBuffer byteBuffer) throws IOException {
		super.handleKeyExchangeInit(byteBuffer);

		/* Send key exchange */
		byteOutputStream.reset();
		byteOutputStream.write(SSHConstants.SSH_MSG_KEXDH_INIT);
		generateClientKey();
		SSHMpint.writeBigInteger(byteOutputStream, clientE);

		sshSession.socketChannel.write(ByteBuffer.wrap(byteOutputStream.toByteArray()));
	}

	/**
	 * Handle the key exchange diffie-hellman reply message.
	 *
	 * @param byteBuffer
	 *
	 * @exception IOException
	 */
	private void handleKeyExchangeDHReply(ByteBuffer byteBuffer) throws IOException {
		/* Read the server public host key and certificates */
		byte[] serverHostKeyCertData = SSHString.readStringAsBytes(byteBuffer);

		/* Read the f */
		serverF = SSHMpint.readBigInteger(byteBuffer);

		if(!validate(serverF)){
			throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "Server's f value not validated!");
		}

		try {
			sharedSecretK = normalize(getSecret(serverF));
		} catch (Exception e) {
			throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "While unpacking shared secret: " + e.toString());
		}

		/* Read the signature */
		byte[] signatureOfH = SSHString.readStringAsBytes(byteBuffer);

//		logger.finer("serverHostKeyCertData = " + SSHString.bytesToString(serverHostKeyCertData));
//		logger.finer("serverF = " + SSHString.bytesToString(serverF.toByteArray()));
//		logger.finer("signatureOfH = " + SSHString.bytesToString(signatureOfH));

		/* Compute exchange hash H */
		ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
		SSHString.writeString(byteArray, sshSession.clientVersion);
		SSHString.writeString(byteArray, sshSession.serverVersion);
		SSHString.writeString(byteArray, clientKexInitPayload);
		SSHString.writeString(byteArray, serverKexInitPayload);
		SSHString.writeString(byteArray, serverHostKeyCertData);

		SSHMpint.writeBigInteger(byteArray, clientE);
		SSHMpint.writeBigInteger(byteArray, serverF);
		SSHMpint.writeBigInteger(byteArray, new BigInteger(1, sharedSecretK));  // needs to always be positive big int

		//   logger.finer("exchange data = " + SSHString.bytesToString(byteArray.toByteArray()));

		shaDigest.reset();
		shaDigest.update(byteArray.toByteArray());
		exchangeHashH = shaDigest.digest();

		//   logger.finer("exchangeHashH = " + SSHString.bytesToString(exchangeHashH));

		if (sessionIdentifier == null) {
			sessionIdentifier = new byte[exchangeHashH.length];
			System.arraycopy(exchangeHashH, 0, sessionIdentifier, 0, exchangeHashH.length);
			sshSession.setSessionIdentifier(sessionIdentifier);
		}

		boolean isVerified = verifySignature(serverHostKeyCertData, signatureOfH);
		if (isVerified) {
			logger.finer("handleKeyExchangeDHReply: Server signature verified");
		} else {
			logger.fine("handleKeyExchangeDHReply: Server signature wrong!");
			throw new DisconnectException(SSHConstants.SSH_DISCONNECT_HOST_KEY_NOT_VERIFIABLE, "handleKeyExchangeDHReply: Server signature wrong!");
		}

		/* Compute the IV and keys */
		computeKeys();

		/* Send new keys message */
		sendNewKeys();
	}

	public void generateClientKey() throws IOException {
		try {
			String name="secp"+keySize+"r1";
			ECGenParameterSpec ecsp = new ECGenParameterSpec(name);

			byte[]r = null;
			byte[]s = null;
			KeyPair kp = null;

			for (int i = 0; i<1000; i++) {
				KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
				kpg.initialize(ecsp);
				kp = kpg.genKeyPair();
				publicKey = (ECPublicKey)kp.getPublic();
				ECPoint w = publicKey.getW();
				r = w.getAffineX().toByteArray();
				s = w.getAffineY().toByteArray();
				if (r.length != s.length) 
					continue;
				if (keySize==256 && r.length==32) break;
				if (keySize==384 && r.length==48) break;
				if (keySize==521 && r.length==66) break;
			}

			clientE = new Point(r, s).toBigInteger();
			privateKey = kp.getPrivate();

		} catch (NoSuchAlgorithmException exception) {
			throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "No EC KeyPairGenerator (use newer JVM): " + exception);
		} catch (InvalidAlgorithmParameterException exception) {
			throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "Invalid KeyPair algorithm param: " + exception);
		}


	}

	public boolean validate(BigInteger big){
		Point point = new Point(big);
		BigInteger x = point.getX(true);
		BigInteger y = point.getY(true);

		ECPoint w = new ECPoint(x, y);
		if (w.equals(ECPoint.POINT_INFINITY)) {
			return false;
		}

		EllipticCurve curve = publicKey.getParams().getCurve();
		BigInteger p = ((ECFieldFp)curve.getField()).getP();

		// xQ and yQ should be integers in the interval [0, p-1]
		if(!(x.compareTo(BigInteger.ZERO) >= 0 && x.compareTo(p) < 0)){
			return false;
		}

		if(!(y.compareTo(BigInteger.ZERO) >= 0 && y.compareTo(p) < 0)){
			return false;
		}

		// y^2 = x^3 + x*a + b (mod p)
		BigInteger tmp=x.multiply(curve.getA()).add(curve.getB()).
				add(x.modPow(THREE, p)).mod(p);
		BigInteger y_2=y.modPow(TWO, p);
		if(!(y_2.equals(tmp))){
			logger.finer("ECDHKeyExchange.validate failed because y^2 != x^3 + x*a + b (mod p)");
			return false;
		}

		return true;
	}

	private byte[] getSecret(BigInteger f) throws Exception{
		Point point = new Point(f);
		ECPoint w = new ECPoint(point.getX(true), point.getY(true));
		ECPublicKeySpec spec = new ECPublicKeySpec(w, publicKey.getParams());
		PublicKey publicKey = KeyFactory.getInstance("EC").generatePublic(spec);
		KeyAgreement keyAgreement = KeyAgreement.getInstance("ECDH");
		keyAgreement.init(privateKey);
		keyAgreement.doPhase(publicKey, true);
		return keyAgreement.generateSecret();
	}

	/**
	 * Remove leading 0's.
	 * @param secret
	 * @return
	 */
	private byte[] normalize(byte[] secret) {
		int i = 0;
		while (i+1 < secret.length && secret[i] == 0 && (secret[i+1] & 0x80) == 0)
			i++;
		if (i == 0)
			return secret;
		byte[] ret=new byte[secret.length - i];
		System.arraycopy(secret, i, ret, 0, ret.length);
		return ret;
	}
	
	static class Point {
		private byte[] r;
		private byte[] s;

		public Point(byte[] r, byte[] s) {
			this.r = r;
			this.s = s;
		}

		public Point(BigInteger blob){
			this(blob.toByteArray());
		}
		
		public Point(byte[] q){
			int i = 0;
			while (q[i++] != 4)
				;
			int len = (q.length - i) / 2;
			r = new byte[len];
			s = new byte[len];
			System.arraycopy(q, i, r, 0, len);
			System.arraycopy(q, i + len, s, 0, len);
		}

		public BigInteger toBigInteger() {
			byte[] q = new byte[1 + r.length + s.length];
			q[0] = 4;
			System.arraycopy(r, 0, q, 1, r.length);
			System.arraycopy(s, 0, q, 1 + r.length, s.length);
			return new BigInteger(q);
		}

		public BigInteger getX(boolean positive) {
			if (positive)
				return new BigInteger(1, r);
			else
				return new BigInteger(r);
		}

		public BigInteger getY(boolean positive ) {
			if (positive)
				return new BigInteger(1, s);
			else
				return new BigInteger(s);
		}
	}

}
