/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * (C) Copyright IBM Corp. 2005, 2019 All Rights Reserved
 *
 * The source code for this program is not published or other-
 * wise divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */
package com.ibm.net.ssh;

import java.io.IOException;

import java.nio.ByteBuffer;

import java.util.logging.Logger;

/**
 * This is the base class for all authentication
 * methods.  The only common requirement is the
 * user name.
 *
 * @author Eric W. Brown
 */
public abstract class AuthMethod {
   /** Copyright statement */
   private static final String COPYRIGHT = Copyright.HEADER + "2005, 2019" + Copyright.FOOTER;

   /** User name string */
   protected String username;

   /** Public key to copy */
   protected PublicKeyFile publicKeyFile;

   /** Whether or not public key copy succeeded */
   private boolean isPublicKeyCopied;

   /** Debugging object */
   protected static final Logger logger = Logger.getLogger("com.ibm.net.ssh");

   /** Whether authentication succeeded or failed */
   protected boolean isAuthenticated;

   /** List of supported authentications */
   private String[] authentications;

   /** Whether authentication partially succeeded or not */
   private boolean partialSuccess;

   /** The login banner message */
   private String bannerMessage;

   /** Host Key Algorithms supported by server */
   private String[] serverHostKeyAlgorithmList;

   /**
    * Construct an authentication method.
    *
    * @param username   The authentication username.
    */
   protected AuthMethod(String username) {
      if (username != null) {
         this.username = username;
      } else {
         throw new NullPointerException("username is null");
      }
   }

   /**
    * This constructor differs from others in that it copies the
    * public key to server.  That way a second login can
    * use just user name and key pair.
    *
    * @param username        user name string
    * @param publicKeyFile   public key to copy
    */
   protected AuthMethod(String username, PublicKeyFile publicKeyFile) {
      if ((username != null) && (publicKeyFile != null)) {
         this.username = username;
         this.publicKeyFile = publicKeyFile;
      } else {
         throw new NullPointerException("username or publicKey is null");
      }
   }

   /**
    * Return the user name for this authentication
    * method.
    *
    * @return  user name string
    */
   public String getUserName() {
      return username;
   }

   /**
    * Return the public key used to copy to the
    * remote server.
    *
    * @return  public key
    */
   public PublicKeyFile getPublicKeyFile() {
      return publicKeyFile;
   }

   /**
    * Return whether or not the given public key
    * was successfully copied to the remote server.
    *
    * @return  boolean whether or not public key copy succeeded
    */
   public boolean isPublicKeyCopied() {
      return isPublicKeyCopied;
   }

   /**
    * Sets whether the public key copy succeeded or not.
    *
    * @param isPublicKeyCopied   whether or not public key copy succeeded
    */
   void setPublicKeyCopied(boolean isPublicKeyCopied) {
      this.isPublicKeyCopied = isPublicKeyCopied;
   }

   /**
    * Return the authentication method name string.
    *
    * @return  method name string
    */
   public abstract String getMethodName();

   /**
    * Return whether or not user authentication suceeded.
    *
    * @return   true if authentication worked, false otherwise
    */
   public boolean isAuthenticated() {
      return isAuthenticated;
   }

   /**
    * Return whether or not authentication was
    * partially successful.
    *
    * @return   true if authentication was partially successful, false otherwise
    */
   public boolean isPartialSuccess() {
      return partialSuccess;
   }

   /**
    * Returns an array of authentications that are supported
    * by the remote server.
    *
    * @return  string array of supported authentications
    */
   public String[] getAuthentications() {
      return authentications;
   }

   /**
    * Returns the login banner message to display.
    *
    * @return   login banner message string
    */
   public String getBannerMessage() {
      return bannerMessage;
   }

   /**
    * Return the request packet byte array
    * for this authentication method.
    *
    * @param sessionIdentifier   session identifier byte array
    *
    * @return byte array containing host based auth message
    *
    * @exception IOException
    */
   abstract byte[] getRequestPacket(byte[] sessionIdentifier) throws IOException;

   /**
    * Handle incoming authentication packet.
    *
    * @exception IOException
    */
   AuthMethod handlePacket(int message, ByteBuffer byteBuffer) throws IOException {
      switch (message) {
         case SSHConstants.SSH_MSG_USERAUTH_SUCCESS:
            logger.fine("handlePacket: SSH_MSG_USERAUTH_SUCCESS");
            handleUserauthSuccess();
            break;
         case SSHConstants.SSH_MSG_USERAUTH_FAILURE:
            logger.fine("handlePacket: SSH_MSG_USERAUTH_FAILURE");
            handleUserauthFailure(byteBuffer);
            break;
         case SSHConstants.SSH_MSG_USERAUTH_BANNER:
            logger.fine("handlePacket: SSH_MSG_USERAUTH_BANNER");
            handleUserauthBanner(byteBuffer);
            break;
      }

      return null;
   }

   /**
    * Handle a user authorization success.
    *
    * @exception IOException
    */
   private void handleUserauthSuccess() throws IOException {
      /* byte      SSH_MSG_USERAUTH_SUCCESS */
      isAuthenticated = true;
   }

   /**
    * Handle a user authorization failure.
    *
    * @param byteBuffer
    *
    * @exception IOException
    */
   private void handleUserauthFailure(ByteBuffer byteBuffer) throws IOException {
      /* byte         SSH_MSG_USERAUTH_FAILURE          */
      /* name-list    authentications that can continue */
      /* boolean      partial success                   */

      authentications = SSHNameList.readNameList(byteBuffer);
      partialSuccess = SSHBoolean.readBoolean(byteBuffer);

      logger.finer("handleUserauthFailure: authentications = " + SSHNameList.nameListToString(authentications));
      logger.finer("handleUserauthFailure: partialSuccess = " + partialSuccess);

      isAuthenticated = false;
   }

   /**
    * Handle a user authorization banner.
    *
    * @param byteBuffer
    *
    * @exception IOException
    */
   private void handleUserauthBanner(ByteBuffer byteBuffer) throws IOException {
      /* byte      SSH_MSG_USERAUTH_BANNER              */
      /* string    message in ISO-10646 UTF-8 encoding  */
      /* string    language tag as defined in [RFC3066] */

      bannerMessage = SSHString.readStringAsUTF8(byteBuffer);
      String languageTag = SSHString.readString(byteBuffer);

      logger.finer("handleUserauthBanner: bannerMessage = " + bannerMessage);
      logger.finer("handleUserauthBanner: languageTag = " + languageTag);
   }
   
   public void setServerHostKeyAlgorithmList(String[] list) {
	   serverHostKeyAlgorithmList = list;
   }
   
   public String getRSAKeyAlgorithm() {
	   if (serverHostKeyAlgorithmList != null) {
		   String [] good = {SSHConstants.RSA_SHA2_512_ALGORITHM, SSHConstants.RSA_SHA2_256_ALGORITHM};
		   for (String a: good) {
			   for (String s: serverHostKeyAlgorithmList) {
				   if (a.equals(s))
					   return a;
			   }
		   }
	   }
	   return SSHConstants.RSA_KEY_FORMAT;
   }
}

