/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * (C) Copyright IBM Corp. 2010, 2019 All Rights Reserved
 *
 * The source code for this program is not published or other-
 * wise divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */
package com.ibm.net.ssh;

import java.io.BufferedReader;
import java.io.IOException;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.math.BigInteger;

import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;

import java.security.spec.DSAPrivateKeySpec;
import java.security.spec.DSAPublicKeySpec;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.ECPrivateKeySpec;
import java.security.spec.ECPublicKeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPrivateCrtKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.util.logging.Logger;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;

import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.ibm.net.ssh.ECDHKeyExchange.Point;

/**
 * This class loads and stores private keys in OpenSSH
 * file format.
 *
 * @author Eric W. Brown
 */
final class OpensshPrivateKeyReader {
   /** Copyright statement */
   private static final String COPYRIGHT = Copyright.HEADER + "2010, 2019" + Copyright.FOOTER;

   enum KeyType { RSA, DSA, EC };
   
   /** RSA begin marker. */
   static final String RSA_PRIVATE_BEGIN_MARKER = "-----BEGIN RSA PRIVATE KEY-----";

   /** DSA begin marker. */
   static final String DSA_PRIVATE_BEGIN_MARKER = "-----BEGIN DSA PRIVATE KEY-----";

   /** EC begin marker. */
   static final String EC_PRIVATE_BEGIN_MARKER = "-----BEGIN EC PRIVATE KEY-----";

   /** RSA end marker. */
   private static final String RSA_PRIVATE_END_MARKER = "-----END RSA PRIVATE KEY-----";

   /** DSA end marker. */
   private static final String DSA_PRIVATE_END_MARKER = "-----END DSA PRIVATE KEY-----";

   /** EC end marker. */
   private static final String EC_PRIVATE_END_MARKER = "-----END EC PRIVATE KEY-----";

   /** OpenSSH Proc-Type indicates the key is encrypted. */
   private static final String PROC_TYPE = "Proc-Type: 4,ENCRYPTED";

   /** Encrypted OpenSSH DEK-Info line indicates the initialization vector and encryption type. */
   private static final String DEK_INFO = "DEK-Info: ";

   /** Comma. */
   private static final String COMMA = ",";

   /** 3DES encryption algorithm. */
   private static final String DES_EDE3_CBC = "DES-EDE3-CBC";

   /** 3DES CBC cipher algorithm. */
   private static final String DES_EDE_CIPHER = "DESede/CBC/PKCS5Padding";

   /** 3DES encryption algorithm. */
   private static final String TRIPLE_DES = "3DES";

   /** 3DES key factory. */
   private static final String DES_EDE_KEY_FACTORY = "DESede";

   /** AES 128 bit encryption algorithm. */
   private static final String AES_128_CBC = "AES-128-CBC";

   /** AES CBC cipher algorithm. */
   private static final String AES_CIPHER = "AES/CBC/PKCS5Padding";

   /** AES encryption algorithm. */
   private static final String AES = "AES";

   /** AES key length. */
   private static final int AES_KEY_LEN = 16;

   /** Hex or base 16. */
   private static final int BASE_16 = 16;

   /** RSA key factory type. */
   private static final String RSA_KEY_FACTORY = "RSA";

   /** DSA key factory type. */
   private static final String DSA_KEY_FACTORY = "DSA";

   /** DSA key factory type. */
   private static final String EC_KEY_FACTORY = "EC";

   /** MD5 message digest. */
   private static final String MD5_MESSAGE_DIGEST = "MD5";

   /** IV size used in message digest hash. */
   private static final int IV_SIZE = 8;

   /** Length of the RSA DerValue array. */
   private static final int RSA_DER_VALUE_LEN = 9;

   /** Length of the DSA DerValue array. */
   private static final int DSA_DER_VALUE_LEN = 6;

   /** Length of the EC DerValue array. */
   private static final int EC_DER_VALUE_LEN = 4;

   /** Index for the modulus. */
   private static final int MODULUS_INDEX = 1;

   /** Index for the public exponent, e. */
   private static final int E_INDEX = 2;

   /** Index for the private exponent, d. */
   private static final int D_INDEX = 3;

   /** Index for the prime p. */
   private static final int PRIME_P_INDEX = 4;

   /** Index for the prime q. */
   private static final int PRIME_Q_INDEX = 5;

   /** Index for the prime exponent p. */
   private static final int EXP_P_INDEX = 6;

   /** Index for the prime exponent q. */
   private static final int EXP_Q_INDEX = 7;

   /** Index for the coefficient. */
   private static final int COEFFICIENT_INDEX = 8;

   /** Index for the p. */
   private static final int P_INDEX = 1;

   /** Index for the q. */
   private static final int Q_INDEX = 2;

   /** Index for the g. */
   private static final int G_INDEX = 3;

   /** Index for the y. */
   private static final int Y_INDEX = 4;

   /** Index for the x. */
   private static final int X_INDEX = 5;

   /** Public and private key pair. */
   private KeyPair keyPair;

   /** Initialization vector. */
   private IvParameterSpec ivParameterSpec;

   /** Encryption algorithm. */
   private String algorithm;

   private static Logger logger = Logger.getLogger("com.ibm.net.ssh");

   /**
    * Constructor.
    *
    * @param bufferedReader  reader for key file
    * @param passPhrase pass phrase
    * @param keyType  the key is RSA, DSA or EC
    *
    * @throws IOException  if problem reading key from file
    */
   OpensshPrivateKeyReader(final BufferedReader bufferedReader, final char[] passPhrase,
                           KeyType keyType) throws IOException {
      load(bufferedReader, passPhrase, keyType);
   }

   /**
    * Get the public and private key pair.
    *
    * @return   key pair containing public and private key
    */
   KeyPair getKeyPair() {
      return keyPair;
   }

   /**
    * Get initialization vector.
    *
    * @return   initialization vector spec
    */
   IvParameterSpec getIvParameterSpec() {
      return ivParameterSpec;
   }

   /**
    * Get the encryption algorithm used.
    *
    * @return   encryption algorithm
    */
   String getAlgorithm() {
      return algorithm;
   }

   /**
    * Loads a private key in OpenSSH PEM format.
    *
    * @param bufferedReader  reader for key file
    * @param passPhrase pass phrase
    * @param isRsaKeyType  whether or not the key is RSA (or DSA)
    *
    * @throws IOException  if problem reading key from file
    */
   private void load(final BufferedReader bufferedReader, final char[] passPhrase,
                     final KeyType keyType) throws IOException {
      StringBuffer base64String = new StringBuffer();

      // Check if next line is the proc type
      String firstLine = bufferedReader.readLine();

      Cipher decryptCipher = null;

      if ((firstLine != null) && (firstLine.equals(PROC_TYPE))) {
         // Data is encrypted
         String dekInfo = bufferedReader.readLine();

         if (dekInfo != null) {
            if (passPhrase != null) {
               if (dekInfo.startsWith(DEK_INFO + DES_EDE3_CBC + COMMA)) {
                  // 3DES CBC key
                  algorithm = TRIPLE_DES;
                  try {
                     // Get IV
                     String ivString = dekInfo.substring((DEK_INFO + DES_EDE3_CBC + COMMA).length());

                     byte[] iv = new byte[ivString.length() / 2];
                     for (int i = 0; i < ivString.length() / 2; i++) {
                        iv[i] = (byte)Short.parseShort(ivString.substring(i * 2, (i * 2) + 2), BASE_16);
                     }
                     ivParameterSpec = new IvParameterSpec(iv);

                     // Generate secret key
                     byte[] decryptionKey = keyDerivation(passPhrase, iv, DESedeKeySpec.DES_EDE_KEY_LEN);
                     DESedeKeySpec desEdeKeySpec = new DESedeKeySpec(decryptionKey);
                     SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(DES_EDE_KEY_FACTORY);
                     SecretKey secretKey = secretKeyFactory.generateSecret(desEdeKeySpec);

                     // Initialize cipher
                     decryptCipher = Cipher.getInstance(DES_EDE_CIPHER);
                     decryptCipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);
                  } catch (InvalidKeyException exception) {
                     throw new IOException(exception.toString());
                  } catch (GeneralSecurityException exception) {
                     throw new IOException(exception.toString());
                  }
               } else if (dekInfo.startsWith(DEK_INFO + AES_128_CBC + COMMA)) {
                  // AES 128 CBC key
                  algorithm = AES;
                  try {
                     // Get IV
                     String ivString = dekInfo.substring((DEK_INFO + AES_128_CBC + COMMA).length());

                     byte[] iv = new byte[ivString.length() / 2];
                     for (int i = 0; i < ivString.length() / 2; i++) {
                        iv[i] = (byte)Short.parseShort(ivString.substring(i * 2, (i * 2) + 2), BASE_16);
                     }
                     ivParameterSpec = new IvParameterSpec(iv);

                     // Generate secret key
                     byte[] decryptionKey = keyDerivation(passPhrase, iv, AES_KEY_LEN);
                     SecretKeySpec secretKeySpec = new SecretKeySpec(decryptionKey, AES);

                     // Initialize cipher
                     decryptCipher = Cipher.getInstance(AES_CIPHER);
                     decryptCipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivParameterSpec);
                  } catch (InvalidKeyException exception) {
                     throw new IOException(exception.toString());
                  } catch (GeneralSecurityException exception) {
                     throw new IOException(exception.toString());
                  }
               } else {
                  throw new IOException("Key encrypted with unhandled cipher.");
               }
            } else {
               throw new IOException("Pass phrase is null for an encrypted key.");
            }
         } else {
            throw new IOException("DEK-Info line missing or incorrect for an encrypted key.");
         }
      } else if (firstLine != null) {
         // Data is not encrypted
         base64String.append(firstLine);
      } else {
         throw new IOException("Unexpected end of file encountered on first line.");
      }

      // Read base 64 encoded data
      String line;
      do {
         line = bufferedReader.readLine();

         if (line == null) {
             throw new IOException("Unexpected end of file encountered.");        	 
         }
         if (line.equals(RSA_PRIVATE_END_MARKER) ||
             line.equals(DSA_PRIVATE_END_MARKER) ||
             line.equals(EC_PRIVATE_END_MARKER)) {
        	 break;
         }
         base64String.append(line);
      } while (true);

      // Decode base 64 data
      Base64Decoder base64Decoder = new Base64Decoder();
      byte[] keyData = base64Decoder.decodeBuffer(base64String.toString());

      // Decrypt data if encrypted
      if (decryptCipher != null) {
         try {
            byte[] decryptedBytes = decryptCipher.doFinal(keyData, 0, keyData.length);
            keyData = new byte[decryptedBytes.length];
            System.arraycopy(decryptedBytes, 0, keyData, 0, decryptedBytes.length);
         } catch (GeneralSecurityException exception) {
            throw new IOException(exception.toString());
         }
      }

      keyPair = derDecode(keyType, keyData);
   }

   /**
    * DER decode the key data into a private/public key pair.
    *
    * @param isRsaKeyType  whether or not the key is RSA
    * @param keyData   the key data blob
    *
    * @return  the private/public key pair
    *
    * @throws IOException if an error occurs reading the key data
    */
   private static KeyPair derDecode(final KeyType keyType, final byte[] keyData) throws IOException {
      PublicKey publicKey = null;
      PrivateKey privateKey = null;

      // Load DER class
      Class<?> derInputStreamClass = null;
      Class<?> derValueClass = null;
      try {
         derInputStreamClass = Class.forName("com.ibm.security.util.DerInputStream");
         derValueClass = Class.forName("com.ibm.security.util.DerValue");
      } catch (ClassNotFoundException exception) {
         try {
            derInputStreamClass = Class.forName("sun.security.util.DerInputStream");
            derValueClass = Class.forName("sun.security.util.DerValue");
         } catch (ClassNotFoundException cnfException) {
            throw new IOException("No available DerInputStream and/or DerValue.");
         }
      }

      if ((derInputStreamClass != null) && (derValueClass != null)) {
         try {
            Class<?>[] parameters = {byte[].class};
            Constructor<?> derInputStreamConstructor = derInputStreamClass.getConstructor(parameters);
            Object[] args = {keyData};
            Object instance = derInputStreamConstructor.newInstance(args);

            parameters[0] = int.class;
            Method getSequenceMethod = derInputStreamClass.getMethod("getSequence", parameters);
            Method getBigIntegerMethod = derValueClass.getMethod("getBigInteger", (Class[])null);

            switch (keyType) {
            case RSA:
            	args[0] = new Integer(RSA_DER_VALUE_LEN); break;
            case DSA:
            	args[0] = new Integer(DSA_DER_VALUE_LEN); break;
            case EC:
            	args[0] = new Integer(EC_DER_VALUE_LEN); break;
            }
            Object[] derValueObjects = (Object[])getSequenceMethod.invoke(instance, args);

            if (keyType == KeyType.RSA) {
               if (derValueObjects.length == 3) {
                  // PrivateKeyInfo ::= SEQUENCE {
                  //   version Version,
                  //   privateKeyAlgorithm AlgorithmIdentifier {{PrivateKeyAlgorithms}},
                  //   privateKey PrivateKey,
                  //   attributes [0] Attributes OPTIONAL }
                  KeyFactory keyFactory = KeyFactory.getInstance(RSA_KEY_FACTORY);
                  PKCS8EncodedKeySpec rsaPrivateKeySpec = new PKCS8EncodedKeySpec(keyData);
                  privateKey = keyFactory.generatePrivate(rsaPrivateKeySpec);
                  RSAPrivateCrtKeySpec privateCrtKeySpec = (RSAPrivateCrtKeySpec)keyFactory.getKeySpec(privateKey, RSAPrivateCrtKeySpec.class);

                  RSAPublicKeySpec rsaPublicKeySpec = new RSAPublicKeySpec(privateCrtKeySpec.getModulus(), privateCrtKeySpec.getPublicExponent());
                  publicKey = keyFactory.generatePublic(rsaPublicKeySpec);
               } else {
                  // RSAPrivateKey ::= SEQUENCE {
                  //    version          INTEGER { rsaPrivateKeyVer0(0) }(rsaPrivateKeyVer0),
                  //    modulus          INTEGER, -- (Usually large) n
                  //    publicExponent   INTEGER, -- (Usually small) e
                  //    privateExponent  INTEGER, -- (Usually large) d
                  //    prime1           INTEGER, -- (Usually large) p
                  //    prime2           INTEGER, -- (Usually large) q
                  //    exponent1        INTEGER, -- (Usually large) d mod (p-1)
                  //    exponent2        INTEGER, -- (Usually large) d mod (q-1)
                  //    coefficient      INTEGER  -- (Usually large) (inverse of q) mod p
                  // }
                  //int version = ((BigInteger)getBigIntegerMethod.invoke(derValueObjects[0], (Object[])null)).intValue();
                  BigInteger modulus = (BigInteger)getBigIntegerMethod.invoke(derValueObjects[MODULUS_INDEX], (Object[])null);
                  BigInteger publicExponent = (BigInteger)getBigIntegerMethod.invoke(derValueObjects[E_INDEX], (Object[])null);
                  BigInteger privateExponent = (BigInteger)getBigIntegerMethod.invoke(derValueObjects[D_INDEX], (Object[])null);
                  BigInteger primeP = (BigInteger)getBigIntegerMethod.invoke(derValueObjects[PRIME_P_INDEX], (Object[])null);
                  BigInteger primeQ = (BigInteger)getBigIntegerMethod.invoke(derValueObjects[PRIME_Q_INDEX], (Object[])null);
                  BigInteger primeExponentP = (BigInteger)getBigIntegerMethod.invoke(derValueObjects[EXP_P_INDEX], (Object[])null);
                  BigInteger primeExponentQ = (BigInteger)getBigIntegerMethod.invoke(derValueObjects[EXP_Q_INDEX], (Object[])null);
                  BigInteger crtCoefficient = (BigInteger)getBigIntegerMethod.invoke(derValueObjects[COEFFICIENT_INDEX], (Object[])null);

                  KeyFactory keyFactory = KeyFactory.getInstance(RSA_KEY_FACTORY);
                  RSAPublicKeySpec rsaPublicKeySpec = new RSAPublicKeySpec(modulus, publicExponent);
                  publicKey = keyFactory.generatePublic(rsaPublicKeySpec);

                  RSAPrivateCrtKeySpec rsaPrivateKeySpec = new RSAPrivateCrtKeySpec(modulus, publicExponent,
                                                                                    privateExponent, primeP, primeQ,
                                                                                    primeExponentP, primeExponentQ,
                                                                                    crtCoefficient);
                  privateKey = keyFactory.generatePrivate(rsaPrivateKeySpec);
               }
            } else if (keyType == KeyType.DSA) {
               // DSAPrivateKey ::= SEQUENCE {
               //     version INTEGER,
               //     p INTEGER,
               //     q INTEGER,
               //     g INTEGER,
               //     pub_key INTEGER,
               //     priv_key INTEGER
               // }
               //int version = ((BigInteger)getBigIntegerMethod.invoke(derValueObjects[0], (Object[])null)).intValue();
               BigInteger p = (BigInteger)getBigIntegerMethod.invoke(derValueObjects[P_INDEX], (Object[])null);
               BigInteger q = (BigInteger)getBigIntegerMethod.invoke(derValueObjects[Q_INDEX], (Object[])null);
               BigInteger g = (BigInteger)getBigIntegerMethod.invoke(derValueObjects[G_INDEX], (Object[])null);
               BigInteger y = (BigInteger)getBigIntegerMethod.invoke(derValueObjects[Y_INDEX], (Object[])null);
               BigInteger x = (BigInteger)getBigIntegerMethod.invoke(derValueObjects[X_INDEX], (Object[])null);

               KeyFactory keyFactory = KeyFactory.getInstance(DSA_KEY_FACTORY);

               DSAPublicKeySpec dsaPublicKeySpec = new DSAPublicKeySpec(y, p, q, g);
               publicKey = keyFactory.generatePublic(dsaPublicKeySpec);

               DSAPrivateKeySpec dsaPrivateKeySpec = new DSAPrivateKeySpec(x, p, q, g);
               privateKey = keyFactory.generatePrivate(dsaPrivateKeySpec);
            } else if (keyType == KeyType.EC) {
            	// ECDSAPrivateKey ::= Sequence {
            	//    version INTEGER,
            	//    p bytes?
            	//    oid OID
            	//    q   POINT
            	Method getDataBytes = derValueClass.getMethod("getDataBytes", (Class[])null);

            	byte[] p = (byte[]) getDataBytes.invoke(derValueObjects[1], (Object[])null);                 
            	byte[] q = (byte[]) getDataBytes.invoke(derValueObjects[3], (Object[])null);
            	// q is actually DER encoded, but we just let Point remove the tags at the beginning.
            	Point point = new Point(q);               

            	String stdName = "secp521r1";
            	if (p.length <= 32)
            		stdName = "secp256r1";
            	else if (p.length <= 48)
            		stdName = "secp384r1";
            	logger.fine("hostKey ECDSA, curve=" + stdName);

            	KeyFactory keyFactory = KeyFactory.getInstance(EC_KEY_FACTORY);      
            	AlgorithmParameters param = AlgorithmParameters.getInstance("EC");
            	param.init(new ECGenParameterSpec(stdName));
            	ECParameterSpec ecparam = param.getParameterSpec(ECParameterSpec.class);
            	ECPoint w = new ECPoint(point.getX(false), point.getY(false));
            	publicKey = keyFactory.generatePublic(new ECPublicKeySpec(w, ecparam));
            	privateKey = keyFactory.generatePrivate(new ECPrivateKeySpec(new BigInteger(1, p), ecparam));
            }
         } catch (GeneralSecurityException exception) {
            throw new IOException("Error attempting to decode DER formatted key: " + exception.toString());
         } catch (NoSuchMethodException exception) {
            throw new IOException("Error attempting to decode DER formatted key: " + exception.toString());
         } catch (InstantiationException exception) {
            throw new IOException("Error attempting to decode DER formatted key: " + exception.toString());
         } catch (IllegalAccessException exception) {
            throw new IOException("Error attempting to decode DER formatted key: " + exception.toString());
         } catch (IllegalArgumentException exception) {
            throw new IOException("Error attempting to decode DER formatted key: " + exception.toString());
         } catch (InvocationTargetException exception) {
            throw new IOException("Error attempting to decode DER formatted key: " + exception.toString());
         }
      }

      if ((publicKey != null) && (privateKey != null)) {
         return new KeyPair(publicKey, privateKey);
      } else {
         throw new IOException("Could not generate keys from OpenSSH file format.");
      }
   }

   /**
    * Derive a key from a key blob of data.  The key is truncated
    * to the given key length if the computed key is too large.  If
    * the computed is too small, its expanded by rehashing.
    *
    * @param passPhrase  pass phrase
    * @param iv  initialization vector
    * @param keyLen  desired key length
    *
    * @return  key as byte array
    *
    * @throws GeneralSecurityException if there is a problem getting message
    *         digest
    */
   private static byte[] keyDerivation(final char[] passPhrase, final byte[] iv,
                                       final int keyLen) throws GeneralSecurityException {
      byte[] passPhraseBytes = String.valueOf(passPhrase).getBytes();

      MessageDigest md5Digest = MessageDigest.getInstance(MD5_MESSAGE_DIGEST);

      byte[] keyData = new byte[keyLen];

      // Compute K1
      md5Digest.reset();
      md5Digest.update(passPhraseBytes, 0, passPhraseBytes.length);
      // Only use first 8 bytes of IV (AES is 16, 3DES is 8)
      md5Digest.update(iv, 0, IV_SIZE);
      byte[] kN = md5Digest.digest();

      int totalKeyLength = kN.length;
      if (totalKeyLength < keyLen) {
         System.arraycopy(kN, 0, keyData, 0, kN.length);
      } else {
         System.arraycopy(kN, 0, keyData, 0, keyLen);
      }

      // This is for variable-length keys

      // Compute K2, K3, ...
      while (totalKeyLength < keyLen) {
         md5Digest.reset();
         md5Digest.update(keyData, 0, totalKeyLength);
         md5Digest.update(passPhraseBytes, 0, passPhraseBytes.length);
         // Only use first 8 bytes of IV (AES is 16, 3DES is 8)
         md5Digest.update(iv, 0, IV_SIZE);
         kN = md5Digest.digest();

         totalKeyLength += kN.length;

         if (totalKeyLength < keyLen) {
            System.arraycopy(kN, 0, keyData, totalKeyLength - kN.length, kN.length);
         } else {
            System.arraycopy(kN, 0, keyData, totalKeyLength - kN.length, keyLen - totalKeyLength + kN.length);
         }
      }

      return keyData;
   }
}
