/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * (C) Copyright IBM Corp. 2005, 2019 All Rights Reserved
 *
 * The source code for this program is not published or other-
 * wise divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */
package com.ibm.net.ssh;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.interfaces.DSAPublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.DSAPublicKeySpec;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.ECPublicKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPublicKeySpec;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.interfaces.DHPrivateKey;
import javax.crypto.interfaces.DHPublicKey;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.DHParameterSpec;
import javax.crypto.spec.DHPublicKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.ibm.net.ssh.ECDHKeyExchange.Point;

/**
 * This class is responsible for key exchange
 * mechanism of the SSH protocol.
 *
 * @author Eric W. Brown
 */
abstract class KeyExchange {
   /** Copyright statement */
   private static final String COPYRIGHT = Copyright.HEADER + "2005, 2019" + Copyright.FOOTER;

   static final String DH_GROUP_EXCHANGE_SHA1 = "diffie-hellman-group-exchange-sha1";
   static final String DH_GROUP_EXCHANGE_SHA256 = "diffie-hellman-group-exchange-sha256";
   static final String DH_GROUP1_SHA1 = "diffie-hellman-group1-sha1";
   static final String DH_GROUP14_SHA1 = "diffie-hellman-group14-sha1";
   static final String DH_GROUP14_SHA256 = "diffie-hellman-group14-sha256";
   static final String DH_GROUP16_SHA512 = "diffie-hellman-group16-sha512";
   static final String DH_GROUP18_SHA512 = "diffie-hellman-group18-sha512";
   static final String ECDH_SHA2_NISTP256 = "ecdh-sha2-nistp256";
   static final String ECDH_SHA2_NISTP384 = "ecdh-sha2-nistp384";
   static final String ECDH_SHA2_NISTP521 = "ecdh-sha2-nistp521";
   static final String ECDSA_SHA2_NISTP_PREFIX = "ecdsa-sha2-nistp";

   private static final String X509V3_SIGN_RSA_HOST_KEY = "x509v3-sign-rsa";
   private static final String X509V3_SIGN_DSS_HOST_KEY = "x509v3-sign-dss";

   static final String NO_COMPRESSION   = "none";
   static final String ZLIB_COMPRESSION = "zlib";

   /** Key exchange preferred algorithms. */
   static final String[] PREFERRED_KEX_ALGORITHMS = Configuration.getKexAlgorithms();
   static final String[] PREFERRED_SERVER_HOST_KEY_ALGORITHMS = Configuration.getServerHostKeyAlgorithms();
   static final String[] PREFERRED_ENCRYPTION_ALGORITHMS = Configuration.getEncryptionAlgorithms();
   static final String[] PREFERRED_MAC_ALGORITHMS = Configuration.getMacAlgorithms();
   static final String[] PREFERRED_COMPRESSION_ALGORITHMS = Configuration.getCompressionAlgorithms();

   /** SSH server host key name, Java signature/certificate name, Java key/cert name, C for certificate and K for public key based. */
   private static final String[][] SERVER_HOST_KEY_MAPPING = {{SSHConstants.RSA_KEY_FORMAT, "SHA1withRSA", "RSA", "K"},
                                                              {SSHConstants.DSS_KEY_FORMAT, "SHA1withDSA", "DSA", "K"},
                                                              {SSHConstants.RSA_SHA2_256_ALGORITHM, "SHA256withRSA", "RSA", "K"},
                                                              {SSHConstants.RSA_SHA2_512_ALGORITHM, "SHA512withRSA", "RSA", "K"},
                                                              {SSHConstants.ECDSA_SHA2_NISTP_256, "SHA256withECDSA", "EC", "K"},
                                                              {SSHConstants.ECDSA_SHA2_NISTP_384, "SHA384withECDSA", "EC", "K"},
                                                              {SSHConstants.ECDSA_SHA2_NISTP_521, "SHA512withECDSA", "EC", "K"},
                                                              {X509V3_SIGN_RSA_HOST_KEY, "SHA1withRSA", "X.509", "C"},
                                                              {X509V3_SIGN_DSS_HOST_KEY, "SHA1withDSA", "X.509", "C"},
                                                              {"pgp-sign-rsa", "SHA1withRSA", "?", "C"},
                                                              {"pgp-sign-dss", "SHA1withDSA", "?", "C"}};

   /** SSH encryption name, Java encryption name, Java short name, and bytes per key. */
   private static final String[][] ENCRYPTION_MAPPING = {{"3des-cbc", "DESede/CBC/NoPadding", "DESede", "24"},
                                                         {"3des-ctr", "DESede/CTR/NoPadding", "DESede", "24"},
                                                         {"aes128-cbc", "AES/CBC/NoPadding", "AES", "16"},
                                                         {"aes128-ctr", "AES/CTR/NoPadding", "AES", "16"},
                                                         {"aes192-cbc", "AES/CBC/NoPadding", "AES", "24"},
                                                         {"aes192-ctr", "AES/CTR/NoPadding", "AES", "24"},
                                                         {"aes256-cbc", "AES/CBC/NoPadding", "AES", "32"},
                                                         {"aes256-ctr", "AES/CTR/NoPadding", "AES", "32"},
                                                         {"arcfour", "RC4", "RC4", "16"},
                                                         {"blowfish-cbc", "Blowfish/CBC/NoPadding", "Blowfish", "16"},
                                                         {"blowfish-ctr", "Blowfish/CTR/NoPadding", "Blowfish", "16"},
                                                         {"cast128-cbc", "?/CBC/NoPadding", "?", "16"},
                                                         {"cast128-ctr", "?/CTR/NoPadding", "?", "16"},
                                                         {"idea-cbc", "?/CBC/NoPadding", "?", "?"},
                                                         {"idea-ctr", "?/CTR/NoPadding", "?", "?"},
                                                         {"serpent128-cbc", "Serpent/CBC/NoPadding", "Serpent", "16"},
                                                         {"serpent128-ctr", "Serpent/CTR/NoPadding", "Serpent", "16"},
                                                         {"serpent192-cbc", "Serpent/CBC/NoPadding", "Serpent", "24"},
                                                         {"serpent192-ctr", "Serpent/CTR/NoPadding", "Serpent", "24"},
                                                         {"serpent256-cbc", "Serpent/CBC/NoPadding", "Serpent", "32"},
                                                         {"serpent256-ctr", "Serpent/CTR/NoPadding", "Serpent", "32"},
                                                         {"twofish128-cbc", "Twofish/CBC/NoPadding", "Twofish", "16"},
                                                         {"twofish128-ctr", "Twofish/CTR/NoPadding", "Twofish", "16"},
                                                         {"twofish192-cbc", "Twofish/CBC/NoPadding", "Twofish", "24"},
                                                         {"twofish192-ctr", "Twofish/CTR/NoPadding", "Twofish", "24"},
                                                         {"twofish-cbc", "Twofish/CBC/NoPadding", "Twofish", "32"},
                                                         {"twofish256-cbc", "Twofish/CBC/NoPadding", "Twofish", "32"},
                                                         {"twofish256-ctr", "Twofish/CTR/NoPadding", "Twofish", "32"}};

   /** SSH MAC name, Java MAC name, digest length. */
   private static final String[][] MAC_MAPPING = {{"hmac-sha1", "HmacSHA1", "20"},
                                                  {"hmac-sha1-96", "HmacSHA1", "12"},
                                                  {"hmac-md5", "HmacMD5", "16"},
                                                  {"hmac-md5-96", "HmacMD5", "12"},
                                                  {"hmac-ripemd160", "HMAC-RIPEMD160", "20"},
                                                  {"hmac-sha2-256", "HmacSHA256", "32"},
                                                  {"hmac-sha2-512", "HmacSHA512", "64"}};


   /** Key exchange cookie size. */
   static final int COOKIE_SIZE = 16;

   /** Group key exchange constants. */

   /** Maximum diffie-hellman key size Java's JCE can handle. */
   private static final int JCE_MAX_BITS   = 1024;

   /** Raw DSS constants */
   private static final byte R_SIZE = 0x14;
   private static final byte S_SIZE = 0x14;
   private static final byte R_S_SIZE = R_SIZE + S_SIZE;
   private static final byte R_S_DER_SIZE = R_S_SIZE + 4;
   private static final byte SEQUENCE_TAG = 0x30;
   private static final byte INTEGER_TAG  = 0x02;
   private static final int ONE_BYTE_LENGTH  = (byte)0x81;

   /** Debugging object */
   protected static Logger logger = Logger.getLogger("com.ibm.net.ssh");   

   /** SSH session. */
   protected SecureSession sshSession;

   /** Master byte output stream used for writing packets. */
   protected ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();

   /** Saved client and server key exchange init payloads. */
   protected byte[] clientKexInitPayload;
   protected byte[] serverKexInitPayload;

   /** Client and server public keys. */
   protected BigInteger clientE;
   protected BigInteger serverF;

   protected BigInteger primeP;

   /** Our private key. */
   private DHPrivateKey clientDHPrivateKey;

   /** The shared secret K. */
   protected byte[] sharedSecretK;

   /** The exchange hash H. */
   protected byte[] exchangeHashH;

   /** Send/receive byte blobs for iv, encryption keys, and mac keys. */
   private byte[] sendInitialIV;
   private byte[] recvInitialIV;
   private byte[] sendEncryptionKey;
   private byte[] recvEncryptionKey;
   private byte[] sendIntegrityKey;
   private byte[] recvIntegrityKey;

   /** Send/receive iv, encryption keys, and mac keys. */
   private IvParameterSpec sendIvParameterSpec;
   private IvParameterSpec recvIvParameterSpec;
   private SecretKey encryptKey;
   private SecretKey decryptKey;
   private SecretKeySpec sendMacKey;
   private SecretKeySpec recvMacKey;

   /** Server host key signer. */
   private KeyFactory serverHostKeyFactory;
   private Signature signature;
   private CertificateFactory certificateFactory;

   /** Encrypt and decrypt ciphers */
   private Cipher encryptCipher;
   private Cipher decryptCipher;

   /** Send and receive message authenications */
   private Mac sendMAC;
   private Mac recvMAC;

   /** Send and receive compression */
   private Deflater sendCompression;
   private Inflater recvCompression;

   /** Message digest algorithm. */
   protected MessageDigest shaDigest;

   /** Indexes into mappings. */
   int serverHostKeyIndex;
   int encryptionIndex;
   int decryptionIndex;
   int sendMACIndex;
   int recvMACIndex;

   /** Key exchange server supported algorithms. */
   String[] kexAlgorithmList;
   String[] serverHostKeyAlgorithmList;
   String[] encryptionAlgorithmClientToServerList;
   String[] encryptionAlgorithmServerToClientList;
   String[] macAlgorithmClientToServerList;
   String[] macAlgorithmServerToClientList;
   String[] compressionAlgorithmClientToServerList;
   String[] compressionAlgorithmServerToClientList;
   String[] languageClientToServerList;
   String[] languageServerToClientList;

   /** Decided algorithm names. */
   String kexAlgorithm;
   String serverHostKeyAlgorithm;
   String encryptionAlgorithmClientToServer;
   String encryptionAlgorithmServerToClient;
   String macAlgorithmClientToServer;
   String macAlgorithmServerToClient;
   String compressionAlgorithmClientToServer;
   String compressionAlgorithmServerToClient;

   /** Session identifier (1st shared secret). */
   byte[] sessionIdentifier;

   /** The server's host key. */
   PublicKey serverHostKey;

   /** The server's host key fingerprint */
   Fingerprint fingerprint;

   /**
    * Constructor.
    */
   KeyExchange(SecureSession sshSession, String kexAlgorithm, byte[] serverKexInitPayload, byte[] sessionIdentifier) {
      this.sshSession = sshSession;
      this.kexAlgorithm = kexAlgorithm;
      this.serverKexInitPayload = serverKexInitPayload;
      this.sessionIdentifier = sessionIdentifier;

      /* Initialize SHA message digest */
      try {
         if (kexAlgorithm.equals(DH_GROUP_EXCHANGE_SHA256) || kexAlgorithm.equals(DH_GROUP14_SHA256)
        		 || kexAlgorithm.equals(ECDH_SHA2_NISTP256)) {
            shaDigest = MessageDigest.getInstance("SHA-256");
         } else if (kexAlgorithm.equals(DH_GROUP16_SHA512) || kexAlgorithm.equals(DH_GROUP18_SHA512)
        		 || kexAlgorithm.equals(ECDH_SHA2_NISTP521)) {
            shaDigest = MessageDigest.getInstance("SHA-512");
         } else if (kexAlgorithm.equals(ECDH_SHA2_NISTP384)) {
            shaDigest = MessageDigest.getInstance("SHA-384");
         } else {
            shaDigest = MessageDigest.getInstance("SHA-1");
         }
      } catch (NoSuchAlgorithmException exception) {
         logger.fine("No such message digest algorithm: " + exception);
      }
   }

   /**
    * Send the new keys message to start encryption.
    *
    * @exception IOException
    */
   protected void sendNewKeys() throws IOException {
      /* Send new keys message */
      byteOutputStream.reset();

      /* Write the message type */
      byteOutputStream.write(SSHConstants.SSH_MSG_NEWKEYS);

      sshSession.socketChannel.write(ByteBuffer.wrap(byteOutputStream.toByteArray()));
   }

   /**
    * Send a service request message to start authentication.
    *
    * @exception IOException
    */
   private void sendServiceRequest() throws IOException {
      /* Send service request message */
      byteOutputStream.reset();

      /* Write the message type */
      byteOutputStream.write(SSHConstants.SSH_MSG_SERVICE_REQUEST);

      SSHString.writeString(byteOutputStream, SSHConstants.USERAUTH_SERVICE);

      sshSession.socketChannel.write(ByteBuffer.wrap(byteOutputStream.toByteArray()));
   }

   /**
    * Handle incoming connection packet.
    *
    * @param message      the packet message number
    * @param byteBuffer   the packet's payload buffer
    *
    * @return    whether the packet message was handled or not
    * @exception IOException
    */
   boolean handlePacket(int message, ByteBuffer byteBuffer) throws IOException {
      boolean packetHandled = true;

      switch (message) {
         case SSHConstants.SSH_MSG_KEXINIT:
            handleKeyExchangeInit(byteBuffer);
            break;
         case SSHConstants.SSH_MSG_NEWKEYS:
            logger.fine("handlePacket: SSH_MSG_NEWKEYS");
            handleNewKeys();
            break;
         default:
            packetHandled = false;
            break;
      }

      return packetHandled;
   }

   /**
    * Handle the key exchange initialize message.
    *
    * @param byteBuffer
    *
    * @exception IOException
    */
   protected void handleKeyExchangeInit(ByteBuffer byteBuffer) throws IOException {
      /* Read the server host key algorithms */
      serverHostKeyAlgorithmList = SSHNameList.readNameList(byteBuffer);

      /* Read the encryption algorithms for client to server */
      encryptionAlgorithmClientToServerList = SSHNameList.readNameList(byteBuffer);

      /* Read the encryption algorithms for server to client */
      encryptionAlgorithmServerToClientList = SSHNameList.readNameList(byteBuffer);

      /* Read the mac algorithms for client to server */
      macAlgorithmClientToServerList = SSHNameList.readNameList(byteBuffer);

      /* Read the mac algorithms for server to client */
      macAlgorithmServerToClientList = SSHNameList.readNameList(byteBuffer);

      /* Read the compression algorithms for client to server */
      compressionAlgorithmClientToServerList = SSHNameList.readNameList(byteBuffer);

      /* Read the compression algorithms for server to client */
      compressionAlgorithmServerToClientList = SSHNameList.readNameList(byteBuffer);

      /* Read the languages for client to server */
      languageClientToServerList = SSHNameList.readNameList(byteBuffer);

      /* Read the languages for server to client */
      languageServerToClientList = SSHNameList.readNameList(byteBuffer);

      /* Read whether the first key exchange packet follows */
      boolean firstKexPacketFollows = SSHBoolean.readBoolean(byteBuffer);

      int reserved;
      try {
         reserved = byteBuffer.getInt();
      } catch (BufferUnderflowException exception) {
         throw new IOException(exception.toString());
      }

      if (logger.isLoggable(Level.FINER)) {
         logger.finer("handleKeyExchangeInit: serverHostKeyAlgorithmList = " + SSHNameList.nameListToString(serverHostKeyAlgorithmList));
         logger.finer("handleKeyExchangeInit: encryptionAlgorithmClientToServerList = " + SSHNameList.nameListToString(encryptionAlgorithmClientToServerList));
         logger.finer("handleKeyExchangeInit: encryptionAlgorithmServerToClientList = " + SSHNameList.nameListToString(encryptionAlgorithmServerToClientList));
         logger.finer("handleKeyExchangeInit: macAlgorithmClientToServerList = " + SSHNameList.nameListToString(macAlgorithmClientToServerList));
         logger.finer("handleKeyExchangeInit: macAlgorithmServerToClientList = " + SSHNameList.nameListToString(macAlgorithmServerToClientList));
         logger.finer("handleKeyExchangeInit: compressionAlgorithmClientToServerList = " + SSHNameList.nameListToString(compressionAlgorithmClientToServerList));
         logger.finer("handleKeyExchangeInit: compressionAlgorithmServerToClientList = " + SSHNameList.nameListToString(compressionAlgorithmServerToClientList));
         logger.finer("handleKeyExchangeInit: languageClientToServerList = " + SSHNameList.nameListToString(languageClientToServerList));
         logger.finer("handleKeyExchangeInit: languageServerToClientList = " + SSHNameList.nameListToString(languageServerToClientList));
         logger.finer("handleKeyExchangeInit: firstKexPacketFollows = " + firstKexPacketFollows);
         logger.finer("handleKeyExchangeInit: reserved = " + reserved);
      }

      /* Decide on algorithms to use */
      while (((serverHostKeyFactory == null) && ((signature == null) || (certificateFactory == null))) ||
             (encryptCipher == null) || (decryptCipher == null) || (sendMAC == null) || (recvMAC == null) ||
             ((compressionAlgorithmClientToServer.equals(NO_COMPRESSION) == false) && (sendCompression == null)) ||
             ((compressionAlgorithmServerToClient.equals(NO_COMPRESSION) == false) && (recvCompression == null))) {

         serverHostKeyAlgorithm = decideAlgorithm(PREFERRED_SERVER_HOST_KEY_ALGORITHMS, serverHostKeyAlgorithmList);
         encryptionAlgorithmClientToServer = decideAlgorithm(PREFERRED_ENCRYPTION_ALGORITHMS, encryptionAlgorithmClientToServerList);
         encryptionAlgorithmServerToClient = decideAlgorithm(PREFERRED_ENCRYPTION_ALGORITHMS, encryptionAlgorithmServerToClientList);
         macAlgorithmClientToServer = decideAlgorithm(PREFERRED_MAC_ALGORITHMS, macAlgorithmClientToServerList);
         macAlgorithmServerToClient = decideAlgorithm(PREFERRED_MAC_ALGORITHMS, macAlgorithmServerToClientList);
         compressionAlgorithmClientToServer = decideAlgorithm(PREFERRED_COMPRESSION_ALGORITHMS, compressionAlgorithmClientToServerList);
         compressionAlgorithmServerToClient = decideAlgorithm(PREFERRED_COMPRESSION_ALGORITHMS, compressionAlgorithmServerToClientList);

         //if (sshSession.locale != null) {
         //   String[] preferredLanguage = new String[] {sshSession.locale.getLanguage() + "-" + sshSession.locale.getCountry()};
         //}
         //languageClientToServerList = decideAlgorithm(preferredLanguage, languageClientToServerList);
         //languageServerToClientList = decideAlgorithm(preferredLanguage, languageServerToClientList);

         /* Shutdown if server does not support our kex method */
         if ((serverHostKeyAlgorithm == null) || (encryptionAlgorithmClientToServer == null) ||
             (encryptionAlgorithmServerToClient == null) || (macAlgorithmClientToServer == null) || (macAlgorithmServerToClient == null) ||
             (compressionAlgorithmClientToServer == null) || (compressionAlgorithmServerToClient == null)) {
            throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "Couldn't find an algorithm match");
         }

         serverHostKeyIndex = getMappingIndex(serverHostKeyAlgorithm, SERVER_HOST_KEY_MAPPING);
         encryptionIndex = getMappingIndex(encryptionAlgorithmClientToServer, ENCRYPTION_MAPPING);
         decryptionIndex = getMappingIndex(encryptionAlgorithmServerToClient, ENCRYPTION_MAPPING);
         sendMACIndex = getMappingIndex(macAlgorithmClientToServer, MAC_MAPPING);
         recvMACIndex = getMappingIndex(macAlgorithmServerToClient, MAC_MAPPING);

         if (logger.isLoggable(Level.FINER)) {
            logger.finer("handleKeyExchangeInit: trying kexAlgorithm = " + kexAlgorithm);
            logger.finer("handleKeyExchangeInit: trying serverHostKeyAlgorithm = " + serverHostKeyAlgorithm);
            logger.finer("handleKeyExchangeInit: trying encryptionAlgorithmClientToServer = " + encryptionAlgorithmClientToServer);
            logger.finer("handleKeyExchangeInit: trying encryptionAlgorithmServerToClient = " + encryptionAlgorithmServerToClient);
            logger.finer("handleKeyExchangeInit: trying macAlgorithmClientToServer = " + macAlgorithmClientToServer);
            logger.finer("handleKeyExchangeInit: trying macAlgorithmServerToClient = " + macAlgorithmServerToClient);
            logger.finer("handleKeyExchangeInit: trying compressionAlgorithmClientToServer = " + compressionAlgorithmClientToServer);
            logger.finer("handleKeyExchangeInit: trying compressionAlgorithmServerToClient = " + compressionAlgorithmServerToClient);
         }

         /* Make sure Java has algorithms of choice */
         if ((serverHostKeyFactory == null) && ((signature == null) || (certificateFactory == null))) {
            if (SERVER_HOST_KEY_MAPPING[serverHostKeyIndex][3].equals("K") == true) {
               /* Public key based */
               try {
                  serverHostKeyFactory = KeyFactory.getInstance(SERVER_HOST_KEY_MAPPING[serverHostKeyIndex][2]);
               } catch (NoSuchAlgorithmException exception) {
                  logger.fine("No such key factory: " + exception);
               }
            } else {
               /* Certificate based */
               try {
                  certificateFactory = CertificateFactory.getInstance(SERVER_HOST_KEY_MAPPING[serverHostKeyIndex][2]);
               } catch (CertificateException exception) {
                  logger.fine("No such certificate factory type: " + exception);
               }
            }
            try {
               signature = Signature.getInstance(SERVER_HOST_KEY_MAPPING[serverHostKeyIndex][1]);
            } catch (NoSuchAlgorithmException exception) {
               logger.fine("No such algorithm for signature: " + exception);
            }

            if ((serverHostKeyFactory == null) && ((signature == null) || (certificateFactory == null))) {
               removeAlgorithm(serverHostKeyAlgorithmList, serverHostKeyAlgorithm);
            }
         }
         if (encryptCipher == null) {
            if (((sshSession.protocolErrorFlags & SecureSession.ERROR_BAD_AES) != 0) && (ENCRYPTION_MAPPING[encryptionIndex][2].equals("AES"))) {
               encryptCipher = null;
            } else {
               encryptCipher = getCipherInstance(ENCRYPTION_MAPPING[encryptionIndex][1]);
            }
            if (encryptCipher == null) {
               removeAlgorithm(encryptionAlgorithmClientToServerList, encryptionAlgorithmClientToServer);
            }
         }
         if (decryptCipher == null) {
            if (((sshSession.protocolErrorFlags & SecureSession.ERROR_BAD_AES) != 0) && (ENCRYPTION_MAPPING[encryptionIndex][2].equals("AES"))) {
               decryptCipher = null;
            } else {
               decryptCipher = getCipherInstance(ENCRYPTION_MAPPING[decryptionIndex][1]);
            }
            if (decryptCipher == null) {
               removeAlgorithm(encryptionAlgorithmServerToClientList, encryptionAlgorithmServerToClient);
            }
         }
         if (sendMAC == null) {
            sendMAC = getMACInstance(MAC_MAPPING[sendMACIndex][1]);
            if (sendMAC == null) {
               removeAlgorithm(macAlgorithmClientToServerList, macAlgorithmClientToServer);
            }
         }
         if (recvMAC == null) {
            recvMAC = getMACInstance(MAC_MAPPING[recvMACIndex][1]);
            if (recvMAC == null) {
               removeAlgorithm(macAlgorithmServerToClientList, macAlgorithmServerToClient);
            }
         }
         if ((compressionAlgorithmClientToServer.equals(NO_COMPRESSION) == false) && (sendCompression == null)) {
            if (compressionAlgorithmClientToServer.equals(ZLIB_COMPRESSION) == true) {
               sendCompression = new Deflater();
            }
            if (sendCompression == null) {
               removeAlgorithm(compressionAlgorithmClientToServerList, compressionAlgorithmClientToServer);
            }
         }
         if ((compressionAlgorithmServerToClient.equals(NO_COMPRESSION) == false) && (recvCompression == null)) {
            if (compressionAlgorithmServerToClient.equals(ZLIB_COMPRESSION) == true) {
               recvCompression = new Inflater();
            }
            if (recvCompression == null) {
               removeAlgorithm(compressionAlgorithmServerToClientList, compressionAlgorithmServerToClient);
            }
         }
      }

      /* Create a response packet */
      byteOutputStream.reset();
      byteOutputStream.write(SSHConstants.SSH_MSG_KEXINIT);

      /* Write the cookie */
      byte[] randomCookie = new byte[COOKIE_SIZE];
      SSHConstants.SECURE_RANDOM.nextBytes(randomCookie);
      byteOutputStream.write(randomCookie, 0, randomCookie.length);

      /* Write the key exchange algorithms */
      SSHString.writeString(byteOutputStream, kexAlgorithm);

      /* Write the server host key algorithms */
      SSHString.writeString(byteOutputStream, serverHostKeyAlgorithm);

      /* Write the encryption algorithms for client to server */
      SSHString.writeString(byteOutputStream, encryptionAlgorithmClientToServer);

      /* Write the encryption algorithms for server to client */
      SSHString.writeString(byteOutputStream, encryptionAlgorithmServerToClient);

      /* Write the mac algorithms for client to server */
      SSHString.writeString(byteOutputStream, macAlgorithmClientToServer);

      /* Write the mac algorithms for server to client */
      SSHString.writeString(byteOutputStream, macAlgorithmServerToClient);

      /* Write the compression algorithms for client to server */
      SSHString.writeString(byteOutputStream, compressionAlgorithmClientToServer);

      /* Write the compression algorithms for server to client */
      SSHString.writeString(byteOutputStream, compressionAlgorithmServerToClient);

      /* Write the languages for client to server */
      SSHString.writeString(byteOutputStream, "");

      /* Write the languages for server to client */
      SSHString.writeString(byteOutputStream, "");

      /* Write whether the first key exchange packet follows */
      SSHBoolean.writeBoolean(byteOutputStream, false);

      /* Write reserved int */
      SSHUint32.writeInt(byteOutputStream, 0);

      /* Save client's key exchange payload for later */
      clientKexInitPayload = byteOutputStream.toByteArray();

      sshSession.socketChannel.write(ByteBuffer.wrap(clientKexInitPayload));
   }

   /**
    * Handle the new keys message.
    *
    * @exception IOException
    */
   private void handleNewKeys() throws IOException {
      if (ENCRYPTION_MAPPING[encryptionIndex][0].startsWith("3des-") || ENCRYPTION_MAPPING[decryptionIndex][0].startsWith("3des-")) {
         try {
            SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DESede");

            if (ENCRYPTION_MAPPING[encryptionIndex][0].startsWith("3des-") == true) {
               DESedeKeySpec desEdeKeySpec = new DESedeKeySpec(sendEncryptionKey);
               encryptKey = secretKeyFactory.generateSecret(desEdeKeySpec);
            }
            if (ENCRYPTION_MAPPING[decryptionIndex][0].startsWith("3des-") == true) {
               DESedeKeySpec desEdeKeySpec = new DESedeKeySpec(recvEncryptionKey);
               decryptKey = secretKeyFactory.generateSecret(desEdeKeySpec);
            }
         } catch (NoSuchAlgorithmException exception) {
            throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "No such algorithm for secret key factory");
         } catch (InvalidKeyException exception) {
            throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "Invalid triple des key");
         } catch (InvalidKeySpecException exception) {
            throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "Invalid key spec for secret key factory");
         }
      } else {
         encryptKey = new SecretKeySpec(sendEncryptionKey, ENCRYPTION_MAPPING[encryptionIndex][2]);
         decryptKey = new SecretKeySpec(recvEncryptionKey, ENCRYPTION_MAPPING[decryptionIndex][2]);
      }

      /* Create keys */
      sendIvParameterSpec = new IvParameterSpec(sendInitialIV);
      recvIvParameterSpec = new IvParameterSpec(recvInitialIV);
      sendMacKey = new SecretKeySpec(sendIntegrityKey, MAC_MAPPING[sendMACIndex][1]);
      recvMacKey = new SecretKeySpec(recvIntegrityKey, MAC_MAPPING[recvMACIndex][1]);

      /* Initialize the ciphers */
      try {
         encryptCipher.init(Cipher.ENCRYPT_MODE, encryptKey, sendIvParameterSpec);
         decryptCipher.init(Cipher.DECRYPT_MODE, decryptKey, recvIvParameterSpec);
      } catch (InvalidKeyException exception) {
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "Invalid key for cipher");
      } catch (InvalidAlgorithmParameterException exception) {
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "Invalid algorithm parm for cipher");
      }

      /* Initialize the MACs */
      int sendDigestLength = Integer.parseInt(MAC_MAPPING[sendMACIndex][2]);
      int recvDigestLength = Integer.parseInt(MAC_MAPPING[recvMACIndex][2]);
      try {
         sendMAC.init(sendMacKey);
         recvMAC.init(recvMacKey);
      } catch (InvalidKeyException exception) {
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "Invalid key for Mac");
      }

      /* Begin using encryption, MAC, and compression */
      sshSession.socketChannel.setCiphers(encryptCipher, decryptCipher);
      sshSession.socketChannel.setMACs(sendMAC, sendDigestLength, recvMAC, recvDigestLength);
      sshSession.socketChannel.setCompression(sendCompression, recvCompression);

      /* Send service request message */
      sendServiceRequest();
   }

   /**
    * Decide on a common algorithm to use between client and server.
    *
    * @param clientList  the client's preferred algorithm list
    * @param serverList  the server's preferred algorithm list
    *
    * @return  the decided algorithm or null if none in common
    */
   static String decideAlgorithm(String[] clientList, String[] serverList) {
      for (int i = 0; i < clientList.length; i++) {
         for (int j = 0; j < serverList.length; j++) {
            if (serverList[j].equals(clientList[i]) == true) {
               /* Found match */
               return serverList[j];
            }
         }
      }

      logger.fine("No match between" + Arrays.toString(clientList) + " and " + Arrays.toString(serverList));
      return null;
   }

   /**
    * Return the index within the mapping of the algorithm string.
    *
    * @param sshAlgorithm   algorithm to lookup in mapping
    * @param mapping        mapping to search
    *
    * @return  the index in the mapping to the algorithm
    */
   private static int getMappingIndex(String sshAlgorithm, String[][] mapping) {
      if (sshAlgorithm != null) {
         for (int i = 0; i < mapping.length; i++) {
            if (sshAlgorithm.equals(mapping[i][0]) == true) {
               return i;
            }
         }
      }
      return -1;
   }

   /**
    * Remove specified algorithm from algorithm list for the
    * next try when deciding algorithms.
    *
    * @param algorithmList
    * @param algorithm
    */
   private static void removeAlgorithm(String[] algorithmList, String algorithm) {
      for (int i = 0; i < algorithmList.length; i++) {
         if (algorithmList[i].equals(algorithm) == true) {
            algorithmList[i] = "";
         }
      }
   }

   /**
    * Create an instance of the specified cipher algorithm.
    *
    * @param algorithm   cipher algorithm to create
    *
    * @return   cipher object
    */
   private Cipher getCipherInstance(String algorithm) {
      Cipher cipher = null;
      try {
         cipher = Cipher.getInstance(algorithm);
      } catch (NoSuchAlgorithmException exception) {
         logger.fine("No such algorithm for cipher: " + exception);
      } catch (NoSuchPaddingException exception) {
         logger.fine("No such padding for cipher: " + exception);
      }
      return cipher;
   }

   /**
    * Create an instance of the specified MAC algorithm.
    *
    * @param algorithm   MAC algorithm to create
    *
    * @return   MAC object
    */
   private Mac getMACInstance(String algorithm) {
      Mac mac = null;
      try {
         mac = Mac.getInstance(algorithm);
      } catch (NoSuchAlgorithmException exception) {
         logger.fine("No such algorithm for Mac: " + exception);
      }
      return mac;
   }

   /**
    * Generate the client's public key, e.
    *
    * @return   client's public key e
    */
   protected BigInteger generateE(BigInteger g) throws IOException {
      BigInteger e = null;

      /* Generate exchange value e */
      if (primeP.bitLength() <= JCE_MAX_BITS) {
         /* Java's JCE only handles a max of 1024 bits for diffie-hellman keys */
         DHParameterSpec dhParameterSpec = new DHParameterSpec(primeP, g);
         try {
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("DiffieHellman");
            keyPairGenerator.initialize(dhParameterSpec);
            KeyPair keyPair = keyPairGenerator.generateKeyPair();

            DHPublicKey clientDHPublicKey = (DHPublicKey)keyPair.getPublic();
            clientDHPrivateKey = (DHPrivateKey)keyPair.getPrivate();

            e = clientDHPublicKey.getY();

         } catch (NoSuchAlgorithmException exception) {
            throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "No such key pair algorithm: " + exception);
         } catch (InvalidAlgorithmParameterException exception) {
            throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "Invalid key pair algorithm parm: " + exception);
         }
      } else {
         /* Compute a key ourselves */

         /* Check that prime is a multiple of 64 */
         //if ((primeP.bitLength() % 64) == 0) {
            /* Generate random number x = (1 < x < (p - 1) / 2) */
            BigInteger max = primeP.subtract(BigInteger.ONE).divide(BigInteger.valueOf(2));
            BigInteger x;
            do {
               x = new BigInteger(primeP.bitLength(), SSHConstants.SECURE_RANDOM);
            } while ((x.compareTo(BigInteger.ONE) <= 0) || (x.compareTo(max) >= 0));

            /* Create diffie hellman public key */
            clientDHPrivateKey = new DiffHellmanPrivateKey(x, primeP, g);

            /* Compute e = g^x mod p */
            e = g.modPow(x, primeP);
         //} else {
         //   throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "Prime p is not a multiple of 64");
         //}
      }

      //   logger.finer("e = " + SSHString.bytesToString(e.toByteArray()));

      return e;
   }

   /**
    * Verify the f is within range [1, p-1]
    *
    * @param value   value to compare
    *
    * @return   true if within range, false otherwise
    */
   protected boolean verifyValueRange(BigInteger value) {
      if (value == null) {
         logger.fine("verifyValueRange: value = null");
         return false;
      }
      if (primeP == null) {
         logger.fine("verifyValueRange: primeP = null");
         return false;
      }
      if ((value.compareTo(BigInteger.ZERO) == 1) && (value.compareTo(primeP) == -1)) {
         return true;
      } else {
         return false;
      }
   }

   /**
    * Compute the shared secret value K.
    *
    * @return   value k
    */
   protected byte[] computeSharedSecret(BigInteger g) {
      byte[] k = null;
      try {
         KeyFactory dhKeyFactory = KeyFactory.getInstance("DiffieHellman");
         DHPublicKeySpec serverPublicKeySpec = new DHPublicKeySpec(serverF, primeP, g);
         DHPublicKey serverDHPubicKey = (DHPublicKey)dhKeyFactory.generatePublic(serverPublicKeySpec);

         KeyAgreement dhKeyAgreement = KeyAgreement.getInstance("DiffieHellman");
         dhKeyAgreement.init(clientDHPrivateKey);
         dhKeyAgreement.doPhase(serverDHPubicKey, true);

         k = dhKeyAgreement.generateSecret();

         //   logger.finer("sharedSecretK = " + SSHString.bytesToString(sharedSecretK));
         //   logger.finer("clientKexInitPayload = " + SSHString.bytesToString(clientKexInitPayload));
         //   logger.finer("serverKexInitPayload = " + SSHString.bytesToString(serverKexInitPayload));

      } catch (NoSuchAlgorithmException exception) {
         logger.fine("NoSuchAlgorithmException creating keyfactory: " + exception);
      } catch (InvalidKeySpecException exception) {
         logger.fine("InvalidKeySpecException creating keyfactory: " + exception);
      } catch (InvalidKeyException exception) {
         logger.fine("InvalidKeyException creating keyfactory: " + exception);
      }
      return k;
   }

   /**
    * Generate the server host key and certificates and verify on the signature.
    *
    * @param serverHostKeyCertData
    *               server host key and certificate data
    * @param signatureOfH
    *               server signature of the HASH
    *
    * @return true if signature verified, false otherwise
    * @exception IOException
    */
   protected boolean verifySignature(byte[] serverHostKeyCertData, byte[] signatureOfH) throws IOException {
      boolean isVerified = false;
      int keySize = 0;

      /* Generate the server host key/certificate */
      //Certificate serverCertificate = null;
      ByteArrayInputStream hostKeyCertStream = new ByteArrayInputStream(serverHostKeyCertData);
      String hostKeyCertFormat = SSHString.readString(hostKeyCertStream);
      //   logger.finer("hostKeyCertFormat = " + hostKeyCertFormat);

      if (hostKeyCertFormat.indexOf("rsa") != -1) {
         try {
            BigInteger e = SSHMpint.readBigInteger(hostKeyCertStream);
            BigInteger n = SSHMpint.readBigInteger(hostKeyCertStream);

            RSAPublicKeySpec rsaPublicKeySpec = new RSAPublicKeySpec(n, e);
            serverHostKey = (RSAPublicKey)serverHostKeyFactory.generatePublic(rsaPublicKeySpec);

            keySize = ((n.bitLength() + 1) / 8) * 8;
         } catch (InvalidKeySpecException exception) {
            logger.fine("InvalidKeySpecException generating RSA key: " + exception);
         }
      } else if (hostKeyCertFormat.indexOf("dss") != -1) {
         try {
            BigInteger p = SSHMpint.readBigInteger(hostKeyCertStream);
            BigInteger q = SSHMpint.readBigInteger(hostKeyCertStream);
            BigInteger g = SSHMpint.readBigInteger(hostKeyCertStream);
            BigInteger y = SSHMpint.readBigInteger(hostKeyCertStream);

            DSAPublicKeySpec dsaPublicKeySpec = new DSAPublicKeySpec(y, p, q, g);
            serverHostKey = (DSAPublicKey)serverHostKeyFactory.generatePublic(dsaPublicKeySpec);

            keySize = ((p.bitLength() + 1) / 8) * 8;
         } catch (InvalidKeySpecException exception) {
            logger.fine("InvalidKeySpecException generating DSA key: " + exception);
         }
      //} else if ((hostKeyCertFormat.equals(X509V3_SIGN_RSA_HOST_KEY) == true) || (hostKeyCertFormat.equals(X509V3_SIGN_DSS_HOST_KEY) == true)) {
      //   many certificates possible
      //   try {
      //      serverCertificate = certificateFactory.generateCertificate(hostKeyCertStream);
      //   /} catch (CertificateException exception) {
      //      throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "CertificateException generating X.509 certificate");
      //   }
      } else if (hostKeyCertFormat.startsWith(ECDSA_SHA2_NISTP_PREFIX)) {
    	  try {
    		  SSHString.readString(hostKeyCertStream); // curve name, e.g. "nistp256"
    		  BigInteger q = SSHMpint.readBigInteger(hostKeyCertStream);
    		  Point point = new Point(q);
    		  ECPoint w = new ECPoint(point.getX(true), point.getY(true));

        	  String name = "secp256r1";
        	  if (hostKeyCertFormat.equals(SSHConstants.ECDSA_SHA2_NISTP_256)) {
        		  keySize = 256;
        		  name = "secp256r1";
        	  } else if (hostKeyCertFormat.equals(SSHConstants.ECDSA_SHA2_NISTP_384)) {
        		  keySize = 384;
        		  name = "secp384r1";
        	  } else if (hostKeyCertFormat.equals(SSHConstants.ECDSA_SHA2_NISTP_521)) {
        		  keySize = 521;
        		  name = "secp521r1";
        	  } else {
        		  logger.fine("Invalid server host key certificate format + " + hostKeyCertFormat);
        	  }
        	  AlgorithmParameters param = AlgorithmParameters.getInstance("EC");
    		  param.init(new ECGenParameterSpec(name));
    		  ECParameterSpec ecparam = param.getParameterSpec(ECParameterSpec.class);
    		  serverHostKey = serverHostKeyFactory.generatePublic(new ECPublicKeySpec(w, ecparam));
    	  } catch (Exception exception) {
              logger.fine("Exception generating ECDSA key: " + exception);
    	  }

      } else {
         logger.fine("Invalid server host key format");
      }

      /* Generate the fingerprint */
      fingerprint = Fingerprint.computeFingerprint(keySize, serverHostKeyCertData);
      logger.fine("KeyExchange: server fingerprint = " + fingerprint);
      /* Verify the signature on the exchange hash */
      try {
         if (SERVER_HOST_KEY_MAPPING[serverHostKeyIndex][3].equals("K") == true) {
            /* Public key based */
            signature.initVerify(serverHostKey);
         } else {
            /* Certificate based */
            // ?
            //signature.initVerify(serverCertificate);
         }
         signature.update(exchangeHashH, 0, exchangeHashH.length);

         byte[] sig;
         String signatureFormat = "";
         if ((serverHostKeyAlgorithm.equals(SSHConstants.DSS_KEY_FORMAT)) && (signatureOfH.length == R_S_SIZE)) {
            /* Signature is formatted as raw bytes */
            logger.fine("verifySignature: Signature is missing format name and data length!");
            sig = signatureOfH;
         } else {
            /* Signature is formatted with format name and length */
            ByteArrayInputStream signatureStream = new ByteArrayInputStream(signatureOfH);
            signatureFormat = SSHString.readString(signatureStream);
            logger.finer("signatureFormat = " + signatureFormat);
//            logger.finer("serverHostKeyAlgorithm = " + serverHostKeyAlgorithm);

            if (!signatureFormat.equals(serverHostKeyAlgorithm) &&
            	!SSHConstants.RSA_SHA2_256_ALGORITHM.equals(signatureFormat) &&
            	!SSHConstants.RSA_SHA2_512_ALGORITHM.equals(signatureFormat)) {
               /* Signature format doesn't match agreed key algorithm */
               throw new DisconnectException(SSHConstants.SSH_DISCONNECT_HOST_KEY_NOT_VERIFIABLE, "verifySignature: Non-matching signature formats!");
            }

            sig = SSHString.readStringAsBytes(signatureStream);
         }

         if (signatureFormat.equals(SSHConstants.RSA_KEY_FORMAT) ||
             signatureFormat.equals(SSHConstants.RSA_SHA2_256_ALGORITHM) ||
             signatureFormat.equals(SSHConstants.RSA_SHA2_512_ALGORITHM)) {

        	 isVerified = signature.verify(sig);
         } else if (signatureFormat.startsWith(ECDSA_SHA2_NISTP_PREFIX)) {

        	 isVerified = signature.verify(toASN1(sig));
         } else if (serverHostKeyAlgorithm.equals(SSHConstants.DSS_KEY_FORMAT)) {
            /* Reformat the raw DSS signature into DER encoding */
            if (sig.length == R_S_SIZE) {
               byteOutputStream.reset();
               byteOutputStream.write(SEQUENCE_TAG);
               byteOutputStream.write(R_S_DER_SIZE);
               byteOutputStream.write(INTEGER_TAG);
               byteOutputStream.write(R_SIZE);
               byteOutputStream.write(sig, 0, R_SIZE);
               byteOutputStream.write(INTEGER_TAG);
               byteOutputStream.write(S_SIZE);
               byteOutputStream.write(sig, R_SIZE, S_SIZE);

               isVerified = signature.verify(byteOutputStream.toByteArray());
            } else {
               logger.fine("Signature length wrong!");
            }
         }
      } catch (InvalidKeyException exception) {
         logger.fine("InvalidKeyException during signature: " + exception);
      } catch (SignatureException exception) {
         logger.fine("SignatureException during signature: " + exception);
      }

      return isVerified;
   }
   
   /**
    * Convert a signature to ASN.1 encoding
    * @param sig
    * @return ASN.1 encoded signature
    * @throws IOException 
    */
   public byte[] toASN1(byte[] sig) throws IOException {
	   if (sig == null || sig.length == 0 || sig[0] == SEQUENCE_TAG)
		   return sig;
	   ByteArrayInputStream sigStream = new ByteArrayInputStream(sig);
	   byte[] r = SSHMpint.readPositiveBigInteger(sigStream).toByteArray();
	   byte[] s = SSHMpint.readPositiveBigInteger(sigStream).toByteArray();

	   ByteArrayOutputStream bos = new ByteArrayOutputStream();
	   bos.write(SEQUENCE_TAG);
	   // if the total length is >= 128, write a byte to specify the number of bytes in the length.
	   // We assume that the total length will always be less than 256, so we can always use
	   // only one byte for the length.
	   if(r.length + s.length + 4 >= 0x80)
		   bos.write(ONE_BYTE_LENGTH);
	   bos.write(r.length + s.length + 4);
	   bos.write(INTEGER_TAG);
	   bos.write(r.length);
	   bos.write(r);
	   bos.write(INTEGER_TAG);
	   bos.write(s.length);
	   bos.write(s);
	   return bos.toByteArray();
   }

   /**
    * Convert ASN.1 encoded signature
    * @param sig
    * @return
    */
   public static byte[] fromASN1(byte[] sig) {
	   if (sig[0] != SEQUENCE_TAG)
		   return sig;
	   // It seems that the output is in ASN.1,
	   // so we have to convert it.
	   try {
		   int index = 3;
		   if (sig[1] == ONE_BYTE_LENGTH)
			   index = 4;
		   int rLength = sig[index];
		   byte[] r = new byte[rLength];
		   System.arraycopy(sig, index + 1, r, 0, rLength);

		   int sLength = sig[index + 2 + rLength];
		   byte[] s = new byte[sLength];
		   System.arraycopy(sig, index + 3 + rLength, s, 0, sLength);

		   ByteArrayOutputStream sigStream = new ByteArrayOutputStream();
		   SSHMpint.writeBigInteger(sigStream, new BigInteger(1, r));
		   SSHMpint.writeBigInteger(sigStream, new BigInteger(1, s));
		   return sigStream.toByteArray();
	   } catch (Exception e) {
		   logger.fine("Unable to convert signature from ASN.1: " + e.getMessage());
		   return sig;
	   }
   }

   /**
    * Generate the initialization vectors, encryption keys, and integrity keys
    */
   protected void computeKeys() throws IOException {
      /* Compute initial initialization vector */
      sendInitialIV = keyDerivation('A', encryptCipher.getBlockSize());
      recvInitialIV = keyDerivation('B', decryptCipher.getBlockSize());

      /* Compute the encryption key */
      sendEncryptionKey = keyDerivation('C', Integer.parseInt(ENCRYPTION_MAPPING[encryptionIndex][3]));
      recvEncryptionKey = keyDerivation('D', Integer.parseInt(ENCRYPTION_MAPPING[decryptionIndex][3]));

      /* Compute the integrity key */
      sendIntegrityKey = keyDerivation('E', sendMAC.getMacLength());
      recvIntegrityKey = keyDerivation('F', recvMAC.getMacLength());

      //   logger.finer("sendInitialIV = " + SSHString.bytesToString(sendInitialIV));
      //   logger.finer("recvInitialIV = " + SSHString.bytesToString(recvInitialIV));
      //   logger.finer("sendEncryptionKey = " + SSHString.bytesToString(sendEncryptionKey));
      //   logger.finer("recvEncryptionKey = " + SSHString.bytesToString(recvEncryptionKey));
      //   logger.finer("sendIntegrityKey = " + SSHString.bytesToString(sendIntegrityKey));
      //   logger.finer("recvIntegrityKey = " + SSHString.bytesToString(recvIntegrityKey));
   }

   /**
    * Derive a key from a key blob of data.  The key is truncated
    * to the given key length if the computed key is too large.  If
    * the computed is too small, its expanded by rehashing.
    *
    * @param specialChar
    * @param keyLength
    *
    * @return
    * @exception IOException
    */
   private byte[] keyDerivation(char specialChar, int desiredKeyLength) throws IOException {
      byte[] keyData = new byte[desiredKeyLength];
      ByteArrayOutputStream byteArray = new ByteArrayOutputStream();

      /* Compute K1 */
      SSHMpint.writeBigInteger(byteArray, new BigInteger(1, sharedSecretK));
      byteArray.write(exchangeHashH, 0, exchangeHashH.length);
      byteArray.write((byte)specialChar);
      byteArray.write(sessionIdentifier, 0, sessionIdentifier.length);
      shaDigest.reset();
      shaDigest.update(byteArray.toByteArray());
      byte[] kN = shaDigest.digest();

      int totalKeyLength = kN.length;
      if (totalKeyLength < desiredKeyLength) {
         System.arraycopy(kN, 0, keyData, 0, kN.length);
      } else {
         System.arraycopy(kN, 0, keyData, 0, desiredKeyLength);
      }

      /* This is for variable-length keys */

      /* Compute K2, K3, ... */
      while (totalKeyLength < desiredKeyLength) {
         byteArray.reset();
         SSHMpint.writeBigInteger(byteArray, new BigInteger(1, sharedSecretK));
         byteArray.write(exchangeHashH, 0, exchangeHashH.length);
         byteArray.write(keyData, 0, totalKeyLength);
         shaDigest.reset();
         shaDigest.update(byteArray.toByteArray());
         kN = shaDigest.digest();

         totalKeyLength += kN.length;

         if (totalKeyLength < desiredKeyLength) {
            System.arraycopy(kN, 0, keyData, totalKeyLength - kN.length, kN.length);
         } else {
            System.arraycopy(kN, 0, keyData, totalKeyLength - kN.length, desiredKeyLength - totalKeyLength + kN.length);
         }
      }

      return keyData;
   }

   /**
    * This represents a diffie-hellman private key.  It
    * had to be created since the JCE doesn't support
    * diffie-hellman key lengths greater than 1024 bits.
    *
    * @author Eric W. Brown
    */
   private static class DiffHellmanPrivateKey implements DHPrivateKey {
	private static final long serialVersionUID = -1737409561836132983L;
	private DHParameterSpec parameterSpec;
      private BigInteger x;

      private DiffHellmanPrivateKey(BigInteger x, BigInteger p, BigInteger g) {
         parameterSpec = new DHParameterSpec(p, g);
         this.x = x;
      }

      public BigInteger getX() {
         return x;
      }

      public DHParameterSpec getParams() {
         return parameterSpec;
      }

      public String getAlgorithm() {
         return "DiffieHellman";
      }

      public String getFormat() {
         return null;
      }

      public byte[] getEncoded() {
         return null;
      }
   }
}
