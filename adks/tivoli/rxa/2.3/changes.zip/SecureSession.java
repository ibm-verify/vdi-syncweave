/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * (C) Copyright IBM Corp. 2005, 2019 All Rights Reserved
 *
 * The source code for this program is not published or other-
 * wise divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */
package com.ibm.net.ssh;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;

import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;

import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.security.PublicKey;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.ibm.net.ssh.spi.SubSystem;

/**
 * This class represents an SSH session.  This
 * is the basis for all SSH communication.  From here,
 * a channel can be opened to execute commands, open
 * a remote shell, or transfer files.  The SecureSession
 * must be disconnected to clean up resources.
 *
 * @author Eric W. Brown
 */
public class SecureSession implements Runnable {
   /** Copyright statement */
   private static final String COPYRIGHT = Copyright.HEADER + "2005, 2019" + Copyright.FOOTER;

   /** The default port number for SSH */
   public static final int DEFAULT_PORT = Configuration.getPort();

   /** The default connection timeout (15 seconds) */
   public static final int DEFAULT_TIMEOUT = Configuration.getTimeout();

   /** Starting state of session */
   public static final int NO_CONNECTION          = 0;

   /** Connection successfully established */
   public static final int CONNECTION_SUCCESS     = 1;

   /** No SSH server was found at the given address/port */
   public static final int NO_SSH_SERVER          = 2;

   /** The SSH server requires an unsupported version */
   public static final int UNSUPPORTED_VERSION    = 3;

   /** Connection failed */
   public static final int CONNECTION_FAILED      = 4;

   /** Authentication failed.  Use retryAuth(). */
   public static final int AUTHENTICATION_FAILED  = 5;

   /**
    * Signals the channel you interested in neither 
    * getInputStream() or getErrorStream()
    */
   public static final int NO_OUTPUT            = 0x00000000;

   /**
    * Signals the channel you are interested in stardard output
    * via getInputStream().
    */
   public static final int STANDARD_OUTPUT      = 0x00000001;

   /** 
    *  Signals the channel you are interested in stardard error
    *  via getErrorStream().
    */
   public static final int STANDARD_ERROR       = 0x00000002;

   /** 
    *  Signals the channel you are interested in stardard output
    *  via getInputStream() and standard error should be redirected
    *  to standard out.
    */
   public static final int REDIRECT_ERR_TO_OUT  = STANDARD_OUTPUT | 0x00000004;

   SSHSocketChannel socketChannel;
   private Thread receiveThread;

   private boolean closed;

   String clientVersion;
   String serverVersion;

   AuthMethod authMethod;
   Locale locale;

   /** Debugging variables */
   private static Logger logger = Logger.getLogger("com.ibm.net.ssh");

   /** The connection status */
   private boolean connectionDontWait;
   private Object connectionSemaphore;
   private int connectionStatus;

   /** SSH key exchange */
   private KeyExchange keyExchange;

   /** SSH connection */
   SSHConnection connection;

   /** Master byte output stream used for writing packets */
   private ByteArrayOutputStream byteOutputStream;

   private boolean isConnected;

   /** Whether or not the disconnect message was already sent */
   private boolean sentDisconnect;

   /** Session identifier (1st shared secret) */
   private byte[] sessionIdentifier;

   /** Default properties */
   //private Properties properties;

   static final int ERROR_BAD_AES         = 0x00000001;
   static final int ERROR_OLD_GEX         = 0x00000002;
   static final int ERROR_INT_EXIT_SIGNAL = 0x00000004;

   int protocolErrorFlags;

   /** Hash map of forwarded addresses */
   private Map forwardingMap = Collections.synchronizedMap(new HashMap());

   /**
    * Constructor (does not automatically connect)
    */
   public SecureSession() {
      connectionSemaphore = new Object();
      byteOutputStream = new ByteArrayOutputStream();
   }

   /**
    * Turn debugging on.
    *
    * @param debugEnabled  true to turn debugging on, false to turn off
    * @param handler       logging handler
    */
   public void setDebugEnabled(boolean debugEnabled, Handler handler) {
      if (debugEnabled == true) {
         final Handler logHandler = handler;
         try {
            AccessController.doPrivileged(
                                         new PrivilegedExceptionAction() {
                                            public Object run() throws Exception
                                            {
                                               logger.addHandler(logHandler);
                                               logger.setLevel(Level.ALL);

                                               return null;
                                            }
                                         }
                                         );
         } catch (PrivilegedActionException exception) {
         }
      } else {
         try {
            AccessController.doPrivileged(
                                         new PrivilegedExceptionAction() {
                                            public Object run() throws Exception
                                            {
                                               Handler[] handlers = logger.getHandlers();
                                               for (int i = 0; i < handlers.length; i++) {
                                                  logger.removeHandler(handlers[i]);
                                               }
                                               logger.setLevel(Level.OFF);

                                               return null;
                                            }
                                         }
                                         );
         } catch (PrivilegedActionException exception) {
         }
      }
   }

   /**
    * Open a full SSH connection.  This will do the key
    * exchange and authenticate.  This method uses the
    * default port and locale.
    *
    * @param address       The address to connect to.
    * @param authMethod    The authentication method object.
    *
    * @return  the returned status of the connection
    *
    * @see AuthMethod
    * @see AuthPassword
    * @see AuthPublicKey
    * @see AuthKeyInteractive
    */
   public int connect(InetAddress address, AuthMethod authMethod) {
      return connect(new InetSocketAddress(address, DEFAULT_PORT), DEFAULT_TIMEOUT, authMethod, null);
   }

   /**
    * Open a full SSH connection.  This will do the key
    * exchange and authenticate.
    *
    * @param inetSocketAddress   The address to connect to.
    * @param timeout             The timeout value for socket connection in milliseconds.
    * @param authMethod          The authentication method object.
    * @param locale              The locale for the language on the client side. Only set to non-null if needed.
    *
    * @return  the returned status of the connection
    *
    * @see AuthMethod
    * @see AuthPassword
    * @see AuthPublicKey
    * @see AuthKeyInteractive
    */
   public int connect(InetSocketAddress inetSocketAddress, int timeout, AuthMethod authMethod, Locale locale) {
      int returnCode = NO_SSH_SERVER;

      sentDisconnect = false;

      try {
         /* Open socket channel */
         socketChannel = (SSHSocketChannel)SSHSocketChannel.open();
         socketChannel.connect(inetSocketAddress, timeout);

         logger.fine("Socket connected");

         /* Read version */
         serverVersion = socketChannel.readLine(timeout);

         logger.fine("SSH serverVersion: " + serverVersion);

         if (serverVersion.startsWith(SSHConstants.SSH_VERSION_HEADING)) {
            /* Check version */
            int majorVersion = 0;
            int minorVersion = 0;
            try {
               String versionString = serverVersion.substring(4);
               majorVersion = Integer.parseInt(versionString.substring(0, versionString.indexOf('.')));
               minorVersion = Integer.parseInt(versionString.substring(versionString.indexOf('.') + 1, (versionString.indexOf('-'))));
            } catch (NumberFormatException exception) {
            } catch (IndexOutOfBoundsException exception) {
            }

            /* We only support 2.0 or 1.99 (1 & 2 compatible) */
            if (((majorVersion == 2) && (minorVersion == 0)) || (majorVersion == 1) && (minorVersion == 99)) {
               clientVersion = SSHConstants.SSH_VERSION_HEADING + SSHConstants.VERSION_TWO + SSHConstants.IBM_VERSION_IDENTITY;

               /* Save the authentication method */
               this.authMethod = authMethod;

               /* Send our version string */
               socketChannel.sendLine(clientVersion);

               /* Set the flags for server bugs */
               setProtocolErrorFlags();

               /* Create the authentication */
               connection = new SSHConnection();

               /* Process data received from SSH server */
               receiveThread = new Thread(this, "SSH");
               // TODO: security exception needs to be caught here
               receiveThread.setDaemon(true);
               receiveThread.start();

               /* Wait until the connection is established */
               try {
                  synchronized (connectionSemaphore) {
                     while (connectionDontWait == false) {
                        connectionSemaphore.wait(timeout);
                        if (connectionDontWait == true) {
                           logger.fine("connectionSemaphore notified");
                        } else {
                           logger.fine("connectionSemaphore timed out");
                        }
                        connectionDontWait = true;
                     }
                  }
               } catch (InterruptedException exception) {
                  Thread.currentThread().interrupt();
               }

               returnCode = connectionStatus;

               if (returnCode == CONNECTION_SUCCESS) {
                  /* Copy public key if given */
                  if (authMethod.getPublicKeyFile() != null) {
                     if (SecurePublicKeyExchange.writePublicKey(this, authMethod.getPublicKeyFile()) == true) {
                        authMethod.setPublicKeyCopied(true);
                     } else {
                        logger.fine("Couldn't copy public key to SSH server!");
                     }
                  }

                  isConnected = true;
               }
            } else {
               returnCode = UNSUPPORTED_VERSION;
               String errorString = "Unsupported SSH version " + majorVersion + '.' + minorVersion;
               disconnect(SSHConstants.SSH_DISCONNECT_PROTOCOL_VERSION_NOT_SUPPORTED, errorString);
            }
         } else {
            disconnect(SSHConstants.SSH_DISCONNECT_PROTOCOL_ERROR, "Non-SSH communication");
         }
      } catch (SocketTimeoutException exception) {
         logger.fine("SSH timeout on connect: " + exception);
      } catch (IOException exception) {
         logger.fine("SSH connect failed: " + exception);
      }

      return returnCode;
   }

   /**
    * If an authentication failure was received when
    * performing a connect(), then this method can be
    * used to retry authentication using a different
    * password, public key, etc.  The user name may
    * not be changed for a retry.  Otherwise authentication
    * will fail.
    *
    * @param authMethod   authentication method
    *
    * @return  the returned status of the connection
    */
   public int retryAuth(AuthMethod authMethod) {
      if (connectionStatus == AUTHENTICATION_FAILED) {
         logger.fine("retryAuth: retrying authentication");

         this.authMethod = authMethod;

         try {
            sendAuthenticationRequest();

            /* Wait until the connection is established */
            synchronized (connectionSemaphore) {
               connectionDontWait = false;
               try {
                  while (connectionDontWait == false) {
                     connectionSemaphore.wait();
                     connectionDontWait = true;
                  }
               } catch (InterruptedException exception) {
                  Thread.currentThread().interrupt();
               }
            }
         } catch (IOException exception) {
            logger.fine("retryAuth: retry of auth request failed.");
         }

         /* Copy public key if given */
         if ((authMethod.getPublicKeyFile() != null) && (connectionStatus == CONNECTION_SUCCESS)) {
            if (SecurePublicKeyExchange.writePublicKey(this, authMethod.getPublicKeyFile()) == true) {
               authMethod.setPublicKeyCopied(true);
            } else {
               logger.fine("Couldn't copy public key to SSH server!");
            }
         }
      }

      return connectionStatus;
   }

   /**
    * Get the client version string.
    *
    * @return   the SSH client version string
    */
   public String getClientVersion() {
      return clientVersion;
   }

   /**
    * Get the server version string.
    *
    * @return   the SSH server version string
    */
   public String getServerVersion() {
      return serverVersion;
   }

   /**
    * Get the client's list of key exchange algorithms
    * that it supports.
    *
    * @return   string array of key exchange algorithm names
    */
   public String[] getClientKexList() {
      return KeyExchange.PREFERRED_KEX_ALGORITHMS;
   }

   /**
    * Get the server's list of key exchange algorithms
    * that it supports.
    *
    * @return   string array of key exchange algorithm names
    */
   public String[] getServerKexList() {
      if (keyExchange != null) {
         return keyExchange.kexAlgorithmList;
      } else {
         return null;
      }
   }

   /**
    * Get the key exchange algorithm decided
    * for use by the server and client.
    *
    * @return   string of the key exchange algorithm name
    */
   public String getDecidedKex() {
      if (keyExchange != null) {
         return keyExchange.kexAlgorithm;
      } else {
         return null;
      }
   }

   /**
    * Get the client's list of host key algorithms
    * that it supports.
    *
    * @return   string array of server host key algorithm names
    */
   public String[] getClientHostKeyList() {
      return KeyExchange.PREFERRED_SERVER_HOST_KEY_ALGORITHMS;
   }

   /**
    * Get the server's list of host key algorithms
    * that it supports.
    *
    * @return   string array of server host key algorithm names
    */
   public String[] getServerHostKeyList() {
      if (keyExchange != null) {
         return keyExchange.serverHostKeyAlgorithmList;
      } else {
         return null;
      }
   }

   /**
    * Get the server host key algorithm decided
    * for use by the server and client.
    *
    * @return   string of the server host key algorithm name
    */
   public String getDecidedServerHostKey() {
      if (keyExchange != null) {
         return keyExchange.serverHostKeyAlgorithm;
      } else {
         return null;
      }
   }

   /**
    * Get the client's list of encryption algorithms
    * that it supports.
    *
    * @return   string array of encryption algorithm names
    */
   public String[] getClientEncryptionList() {
      return KeyExchange.PREFERRED_ENCRYPTION_ALGORITHMS;
   }

   /**
    * Get the server's list of client to server encryption algorithms
    * that it supports.
    *
    * @return   string array of encryption algorithm names
    */
   public String[] getServerEncryptionLocalList() {
      if (keyExchange != null) {
         return keyExchange.encryptionAlgorithmClientToServerList;
      } else {
         return null;
      }
   }

   /**
    * Get the client to server encryption algorithm decided
    * for use by the server and client.
    *
    * @return   string of the encryption algorithm name
    */
   public String getDecidedLocalEncryption() {
      if (keyExchange != null) {
         return keyExchange.encryptionAlgorithmClientToServer;
      } else {
         return null;
      }
   }

   /**
    * Get the server's list of server to client encryption algorithms
    * that it supports.
    *
    * @return   string array of encryption algorithm names
    */
   public String[] getServerEncryptionRemoteList() {
      if (keyExchange != null) {
         return keyExchange.encryptionAlgorithmServerToClientList;
      } else {
         return null;
      }
   }

   /**
    * Get the server to client encryption algorithm decided
    * for use by the server and client.
    *
    * @return   string of the encryption algorithm name
    */
   public String getDecidedRemoteEncryption() {
      if (keyExchange != null) {
         return keyExchange.encryptionAlgorithmServerToClient;
      } else {
         return null;
      }
   }

   /**
    * Get the client's list of encryption algorithms
    * that it supports.
    *
    * @return   string array of MAC algorithm names
    */
   public String[] getClientMacList() {
      return KeyExchange.PREFERRED_MAC_ALGORITHMS;
   }

   /**
    * Get the server's list of client to server MAC algorithms
    * that it supports.
    *
    * @return   string array of MAC algorithm names
    */
   public String[] getServerMacLocalList() {
      if (keyExchange != null) {
         return keyExchange.macAlgorithmClientToServerList;
      } else {
         return null;
      }
   }

   /**
    * Get the server to client MAC algorithm decided
    * for use by the server and client.
    *
    * @return   string of the MAC algorithm name
    */
   public String getDecidedLocalMac() {
      if (keyExchange != null) {
         return keyExchange.macAlgorithmClientToServer;
      } else {
         return null;
      }
   }

   /**
    * Get the server's list of server to client MAC algorithms
    * that it supports.
    *
    * @return   string array of MAC algorithm names
    */
   public String[] getServerMacRemoteList() {
      if (keyExchange != null) {
         return keyExchange.macAlgorithmServerToClientList;
      } else {
         return null;
      }
   }

   /**
    * Get the server to client MAC algorithm decided
    * for use by the server and client.
    *
    * @return   string of the MAC algorithm name
    */
   public String getDecidedRemoteMac() {
      if (keyExchange != null) {
         return keyExchange.macAlgorithmServerToClient;
      } else {
         return null;
      }
   }

   /**
    * Get the client's list of compression algorithms
    * that it supports.
    *
    * @return   string array of compression algorithm names
    */
   public String[] getClientCompressionList() {
      return KeyExchange.PREFERRED_COMPRESSION_ALGORITHMS;
   }

   /**
    * Get the server's list of client to server compression algorithms
    * that it supports.
    *
    * @return   string array of compression algorithm names
    */
   public String[] getServerCompressionLocalList() {
      if (keyExchange != null) {
         return keyExchange.compressionAlgorithmClientToServerList;
      } else {
         return null;
      }
   }

   /**
    * Get the server to client compression algorithm decided
    * for use by the server and client.
    *
    * @return   string of the compression algorithm name
    */
   public String getDecidedLocalCompression() {
      if (keyExchange != null) {
         return keyExchange.compressionAlgorithmClientToServer;
      } else {
         return null;
      }
   }

   /**
    * Get the server's list of server to client compression algorithms
    * that it supports.
    *
    * @return   string array of compression algorithm names
    */
   public String[] getServerCompressionRemoteList() {
      if (keyExchange != null) {
         return keyExchange.compressionAlgorithmServerToClientList;
      } else {
         return null;
      }
   }

   /**
    * Get the server to client compression algorithm decided
    * for use by the server and client.
    *
    * @return   string of the compression algorithm name
    */
   public String getDecidedRemoteCompression() {
      if (keyExchange != null) {
         return keyExchange.compressionAlgorithmServerToClient;
      } else {
         return null;
      }
   }

   /**
    * Get the server's list of client to server languages
    * that it supports.
    *
    * @return   string array of language names
    */
   public String[] getServerLanguageLocalList() {
      if (keyExchange != null) {
         return keyExchange.languageClientToServerList;
      } else {
         return null;
      }
   }

   /**
    * Get the server's list of server to client languages
    * that it supports.
    *
    * @return   string array of language names
    */
   public String[] getServerLanguageRemoteList() {
      if (keyExchange != null) {
         return keyExchange.languageServerToClientList;
      } else {
         return null;
      }
   }

   /**
    * Get the server's host public key
    *
    * @return   public key of the server
    */
   public PublicKey getHostKey() {
      if (keyExchange != null) {
         return keyExchange.serverHostKey;
      } else {
         return null;
      }
   }

   /**
    * Get the server's public key fingerprint.
    *
    * @return   fingerprint object (e.g. ssh-rsa 1024 16:10:cd:85:c4:e9:e2:f3:5e:14:84:4d:cd:2b:2a:ec)
    */
   public Fingerprint getFingerprint() {
      if (keyExchange != null) {
         return keyExchange.fingerprint;
      } else {
         return null;
      }
   }

   /**
    * This method will execute a remote command through
    * the SSH channel.
    *  
    * Note: By default standard out and standard err of the 
    *       remote process must be read via getInputStream
    *       and getErrorStream.  If not read, the SSH client
    *       can possibly hang because of a block on the write
    *       side of the pipe input stream.
    *  
    *  
    * @param command   command to execute
    *
    * @return   a SecureProcess object or null if the execute failed
    *
    * @see SecureProcess
    */
   public SecureProcess executeCommand(String command) {
      return executeCommand(command, SSHConstants.US_ASCII, SecureShell.DEFAULT_TERMINAL, SecureShell.DEFAULT_ROWS, SecureShell.DEFAULT_COLUMNS, null, STANDARD_OUTPUT | STANDARD_ERROR);
   }

   /**
    * This method will execute a remote command through
    * the SSH channel.
    *  
    * Note: By default standard out and standard err of the 
    *       remote process must be read via getInputStream
    *       and getErrorStream.  If not read, the SSH client
    *       can possibly hang because of a block on the write
    *       side of the pipe input stream.
    *  
    * @param command   command to execute
    * @param usePty    true to use a pseudo terminal, false to not
    *
    * @return a SecureProcess object or null if the execute failed
    *
    * @see SecureProcess
    */
   public SecureProcess executeCommand(String command, boolean usePty) {
      if (usePty == true) {
         return executeCommand(command);
      } else {
         return executeCommand(command, SSHConstants.US_ASCII, null, 0, 0, null, STANDARD_OUTPUT | STANDARD_ERROR);
      }
   }

   /**
    * This method will execute a remote command through
    * the SSH channel.  This method will set the environment
    * of the process also.
    *  
    * Note: By default standard out and standard err of the 
    *       remote process must be read via getInputStream
    *       and getErrorStream.  If not read, the SSH client
    *       can possibly hang because of a block on the write
    *       side of the pipe input stream.
    *  
    * Also Note: Some SSH implementations don't support setting the
    *            environment. 
    *
    * @param command      command to execute
    * @param terminal     terminal type to use (VT100, XTERM, etc)
    * @param rows         number of rows for the terminal
    * @param columns      number of columns for the terminal
    * @param environment  environmental variables for the command.
    *                     This should be one or more name/value pairs.
    *
    * @return a SecureProcess object or null if the execute failed
    *
    * @see SecureProcess
    */
   public SecureProcess executeCommand(String command, String terminal, int rows, int columns, String[] environment) {
      return executeCommand(command, SSHConstants.US_ASCII, terminal, rows, columns, environment, STANDARD_OUTPUT | STANDARD_ERROR);
   }

   /**
    * This method will execute a remote command through
    * the SSH channel.  This method will set the environment
    * of the process also.
    *  
    * Note: By default standard out and standard err of the 
    *       remote process must be read via getInputStream
    *       and getErrorStream.  If not read, the SSH client
    *       can possibly hang because of a block on the write
    *       side of the pipe input stream.
    *  
    * Also Note: Some SSH implementations don't support setting the
    *            environment. 
    *
    * @param command      command to execute
    * @param terminal     terminal type to use (VT100, XTERM, etc)
    * @param rows         number of rows for the terminal
    * @param columns      number of columns for the terminal
    * @param environment  environmental variables for the command.
    *                     This should be one or more name/value pairs.
    * @param streamFlags  Tells the channel which streams you will 
    *                     use.  Either getInputStream(),
    *                     getErrorStream(), both, or both in
    *                     getInputStream().  Use combination of
    *                     STANDARD_OUTPUT, STANDARD_ERROR, and REDIRECT_ERR_TO_OUT 
    *
    * @return a SecureProcess object or null if the execute failed
    *
    * @see SecureProcess
    */
   public SecureProcess executeCommand(String command, String terminal, int rows, int columns, String[] environment, int streamFlags) {
      return executeCommand(command, SSHConstants.US_ASCII, terminal, rows, columns, environment, streamFlags);
   }

   /**
    * This method will execute a remote command through
    * the SSH channel.  This method will set the environment
    * of the process also.
    *  
    * Note: By default standard out and standard err of the 
    *       remote process must be read via getInputStream
    *       and getErrorStream.  If not read, the SSH client
    *       can possibly hang because of a block on the write
    *       side of the pipe input stream.
    *  
    * Also Note: Some SSH implementations don't support setting the
    *            environment. 
    *
    * @param command      command to execute
    * @param charsetName  name of the {@linkplain java.nio.charset.Charset} for the command
    * @param terminal     terminal type to use (VT100, XTERM, etc)
    * @param rows         number of rows for the terminal
    * @param columns      number of columns for the terminal
    * @param environment  environmental variables for the command.
    *                     This should be one or more name/value pairs.
    * @param streamFlags  Tells the channel which streams you will 
    *                     use.  Either getInputStream(),
    *                     getErrorStream(), both, or both in
    *                     getInputStream().  Use combination of
    *                     STANDARD_OUTPUT, STANDARD_ERROR, and REDIRECT_ERR_TO_OUT 
    *
    * @return a SecureProcess object or null if the execute failed
    *
    * @see SecureProcess
    */
   public SecureProcess executeCommand(String command, String charsetName, String terminal, int rows, int columns, String[] environment, int streamFlags) {
      if (connectionStatus == CONNECTION_SUCCESS) {
         SecureProcess process = new SecureProcess(this);
         process.setStreamFlags(streamFlags);
         boolean returnCode = connection.createChannel(process);

         if (returnCode == true) {
            try {
               if (terminal != null) {
                  returnCode = process.sendPtyReqChannelRequest(terminal, rows, columns, 0, 0, true);
               }

               if ((returnCode == true) && (environment != null)) {
                  returnCode = process.sendEnvChannelRequest(environment, true);
               }

               if (returnCode == true) {
                  returnCode = process.sendExecChannelRequest(command, charsetName, true);
               }
            } catch (IOException exception) {
               logger.fine("SecureSession.executeCommand() IOException: " + exception.toString());
               returnCode = false;
            }
         }

         if (returnCode == true) {
            return process;
         } else {
            try {
               process.close();
            } catch (IOException exception) {
               logger.fine("SecureSession.executeCommand() process.close() IOException: " + exception.toString());
            }
            process = null;
         }
      }
      return null;
   }

   /**
    * Open a shell using the default terminal, row,
    * and column settings.  The environment remains
    * unchanged.
    *  
    * Note: By default standard out of the remote process must be 
    *       read via getInputStream.  If not read, the SSH client
    *       can possibly hang because of a block on the write side
    *       of the pipe input stream.
    *  
    * @return   a SecureShell object or null if the open failed
    *
    * @see SecureShell
    */
   public SecureShell openShell() {
      return openShell(SecureShell.DEFAULT_TERMINAL, SecureShell.DEFAULT_ROWS, SecureShell.DEFAULT_COLUMNS, null, STANDARD_OUTPUT);
   }

   /**
    * Open a shell using the specified terminal, row,
    * column, and environment settings.
    *  
    * Note: By default standard out of the remote process must be 
    *       read via getInputStream.  If not read, the SSH client
    *       can possibly hang because of a block on the write side
    *       of the pipe input stream.
    *  
    * @param terminal     terminal type to use (VT100, XTERM, etc)
    * @param rows         number of rows for the terminal
    * @param columns      number of columns for the terminal
    * @param environment  environmental variables for this terminal.
    * @param streamFlags  Tells the channel which streams you will 
    *                     use.  Either getInputStream(),
    *                     getErrorStream(), both, or both in
    *                     getInputStream().  Use combination of
    *                     STANDARD_OUTPUT, STANDARD_ERROR, and REDIRECT_ERR_TO_OUT 
    *
    * Note: The environment should contain name value pairs, so an
    *       even number strings in array is required.
    *
    * @return   a SecureShell object or null if the open failed
    *
    * @see SecureShell
    */
   public SecureShell openShell(String terminal, int rows, int columns, String[] environment, int streamFlags) {
      if (connectionStatus == CONNECTION_SUCCESS) {
         SecureShell shell = new SecureShell(this);
         shell.setStreamFlags(streamFlags);
         boolean returnCode = connection.createChannel(shell);

         if (returnCode == true) {
            shell.rows = rows;
            shell.columns = columns;

            try {
               returnCode = shell.sendPtyReqChannelRequest(terminal, rows, columns, 0, 0, true);

               if ((returnCode == true) && (environment != null)) {
                  returnCode = shell.sendEnvChannelRequest(environment, true);
               }

               if (returnCode == true) {
                  returnCode = shell.sendShellChannelRequest(true);
               }
            } catch (IOException exception) {
               logger.fine("SecureSession.openShell() IOException: " + exception.toString());
               returnCode = false;
            }
         }

         if (returnCode == true) {
            return shell;
         } else {
            try {
               shell.close();
            } catch (IOException exception) {
               logger.fine("SecureSession.openShell() shell.close() IOException: " + exception.toString());
            }
            shell = null;
         }
      }
      return null;
   }

   /**
    * Return a secure FTP channel.  This
    * channel is used to securely transfer files
    * between the client and server.
    *
    * @return  a SecureFTP object or null if the open failed
    *
    * @see SecureFTP
    */
   public SecureFTP openSFTP() {
      if (connectionStatus == CONNECTION_SUCCESS) {
         SecureFTP sftp = new SecureFTP(this);
         boolean returnCode = connection.createChannel(sftp);

         if ((returnCode == true) && (sftp.initialize() == true)) {
            return sftp;
         } else {
            try {
               sftp.close();
            } catch (IOException exception) {
               logger.fine("SecureSession.openSFTP() sftp.close() IOException: " + exception.toString());
            }
            sftp = null;
         }
      }
      return null;
   }

   /**
    * Forward a locally connected address and port to remote address
    * and port.
    *
    * @param originAddress   originator IP address and port of connections
    * @param hostAddress     host address and port of connected port
    *
    * @return   whether the forwarding was successful or not
    */
   public boolean forwardRemotePort(InetSocketAddress originAddress, InetSocketAddress hostAddress) {
      return portForward(false, originAddress, hostAddress);
   }

   /**
    * Forward local address and port connections to a remotely connected
    * address and port.
    *
    * @param originAddress   originator IP address and port of connections
    * @param hostAddress     host address and port of connected port
    *
    * @return   whether the forwarding was successful or not
    */
   public boolean forwardLocalPort(InetSocketAddress originAddress, InetSocketAddress hostAddress) {
      return portForward(true, originAddress, hostAddress);
   }

   /**
    * Common port forwarding method.
    *
    * @param channelType     channel type
    * @param originAddress   originator IP address and port of connections
    * @param hostAddress     host address and port of connected port
    *
    * @return   whether the forwarding was successful or not
    */
   private boolean portForward(boolean isLocal, InetSocketAddress originAddress, InetSocketAddress hostAddress) {
      if (connectionStatus == CONNECTION_SUCCESS) {
         Thread thread = SecurePortForwarding.createThread(this, isLocal, originAddress, hostAddress);

         if (thread != null) {
            /* Store this forwarding in a map */
            forwardingMap.put(originAddress, thread);
            return true;
         }
      }
      return false;
   }

   /**
    * Cancel a currently connected remote forwarding.
    * 
    * @param remoteAddress   remote address
    * 
    * @return   true if forwarding was cancelled
    */
   boolean cancelRemoteForward(InetSocketAddress remoteAddress) {
      if (connectionStatus == CONNECTION_SUCCESS) {
      }
      return false;
   }

   /**
    * Cancel a currently connected local forwarding.
    * 
    * @param localAddress   local address
    * 
    * @return   true if forwarding was cancelled
    */
   public boolean cancelLocalForward(InetSocketAddress localAddress) {
	   SecurePortForwarding.ServerSocketThread thread = (SecurePortForwarding.ServerSocketThread)forwardingMap.remove(localAddress);
	   if ((thread != null)) {
		   thread.stopThread();
		   return true;
	   }
	   return false;
   }

   /**
    * Return a secure public key channel.  This
    * channel is used to add, remove, list, and
    * command action on public keys of the server.
    *
    * @return  a SecurePublicKeyExchange object or null if the open failed
    *
    * @see SecurePublicKeyExchange
    */
   public SecurePublicKeyExchange openPublicKeyExchange() {
      if (connectionStatus == CONNECTION_SUCCESS) {
         SecurePublicKeyExchange publicKeyEx = new SecurePublicKeyExchange(this);
         boolean returnCode = connection.createChannel(publicKeyEx);

         if ((returnCode == true) && (publicKeyEx.initialize() == true)) {
            return publicKeyEx;
         } else {
            try {
               publicKeyEx.close();
            } catch (IOException exception) {
               logger.fine("SecureSession.openPublicKeyExchange() publicKeyEx.close() IOException: " + exception.toString());
            }
            publicKeyEx = null;
         }
      }
      return null;
   }

   /**
    * Open a new subsystem channel of the specified name.
    * 
    * @param subSystemName  name of subsystem to open
    * 
    * @return  a new subsystem
    */
   public SubSystem openSubSystem(String subSystemName) {
      if (connectionStatus == CONNECTION_SUCCESS) {
         if (subSystemName != null) {
            List subSystemList = SubSystem.providers();

            for (Iterator iterator = subSystemList.iterator(); iterator.hasNext();) {
               SubSystem subSystemProvider = (SubSystem)iterator.next();
               if (subSystemProvider.getSubSystemName().equals(subSystemName)) {
                  subSystemProvider.setSecureSession(this);
                  boolean returnCode = connection.createChannel(subSystemProvider);

                  if ((returnCode == true) && (subSystemProvider.initialize() == true)) {
                     return subSystemProvider;
                  } else {
                     try {
                        subSystemProvider.close();
                     } catch (IOException exception) {
                        logger.fine("SecureSession.openSubSystem() subSystemProvider.close() IOException: " + exception.toString());
                     }
                     subSystemProvider = null;
                  }
               }
            }
         }
      }
      return null;
   }

   /**
    * Close the SSH connection (if open)
    */
   public void disconnect() {
      disconnect(SSHConstants.SSH_DISCONNECT_CONNECTION_LOST, "General disconnection");
   }

   /**
    * Close the SSH connection (if open).  This
    * version of disconnect will take a reason for
    * the disconnection as parameters.
    *
    * @param reasonCode    one of the reason codes for disconnection
    * @param description   description of the reason for a disconnect in UTF-8 [RFC2279]
    *
    * @see SSHConstants
    */
   public void disconnect(int reasonCode, String description) {
      closed = true;

      /* Close forwarded Ports */
	  for (Object fwdThread : forwardingMap.values()) {
	  	 ((SecurePortForwarding.ServerSocketThread) fwdThread).stopThread();
	  }
	  forwardingMap.clear();
		
	  /* Close all channels */
      if (connection != null) {
         try {
            connection.closeAllChannels();
         } catch (IOException exception) {
         }
      }

      if (socketChannel != null) {
         sendDisconnect(reasonCode, description);
      }

      if (socketChannel != null) {
         try {
            socketChannel.socket().shutdownInput();
         } catch (IOException exception) {
         }
         try {
            socketChannel.socket().shutdownOutput();
         } catch (IOException exception) {
         }
         if (socketChannel != null) {
            try {
               socketChannel.socket().close();
            } catch (IOException exception) {
            } catch (Error error) {
               // Catching error here because on rare occasion
               // Director recevied the following error:
               // java.lang.Error: Untranslated exception
               // Caused by: java.io.IOException: An operation was attempted on something that is not a socket.
            }
            try {
               socketChannel.close();
            } catch (IOException exception) {
            }
         }
      }
   }

   /**
    * Returns the state of the current connection.
    *
    * @return  connection status
    */
   public int getConnectionStatus() {
      return connectionStatus;
   }

   void setConnectionStatus(int connectionStatus) {
      this.connectionStatus = connectionStatus;

      if (logger.isLoggable(Level.INFO) == true) {
         StringBuffer connectString = new StringBuffer("setConnectionStatus: connectionStatus = ");
         switch (connectionStatus) {
            case NO_CONNECTION:
               connectString.append("NO_CONNECTION");
               break;
            case CONNECTION_SUCCESS:
               connectString.append("CONNECTION_SUCCESS");
               break;
            case NO_SSH_SERVER:
               connectString.append("NO_SSH_SERVER");
               break;
            case UNSUPPORTED_VERSION:
               connectString.append("UNSUPPORTED_VERSION");
               break;
            case CONNECTION_FAILED:
               connectString.append("CONNECTION_FAILED");
               break;
            case AUTHENTICATION_FAILED:
               connectString.append("AUTHENTICATION_FAILED");
               break;
         }
         logger.fine(connectString.toString());
      }

      synchronized (connectionSemaphore) {
         connectionDontWait = true;
         connectionSemaphore.notifyAll();
         logger.finer("notifing connectionSemaphore");
      }
   }

   /**
    * Tell server we are disconnecting due to an error.
    *
    * @param reasonCode      code indicating type of error
    * @param description     error description
    */
   void sendDisconnect(int reasonCode, String description) {
      if (sentDisconnect == false) {
         sentDisconnect = true;

         logger.fine("SecureSession.sendDisconnect() reasonCode = " + getReasonCodeAsString(reasonCode));
         logger.fine("SecureSession.sendDisconnect() description = " + description);

         /* Send channel request message */
         ByteArrayOutputStream disconnectStream = new ByteArrayOutputStream();

         /* Write the message type */
         disconnectStream.write(SSHConstants.SSH_MSG_DISCONNECT);

         try {
            SSHUint32.writeInt(disconnectStream, reasonCode);
            SSHString.writeString(disconnectStream, description);
            SSHString.writeString(disconnectStream, "");

            socketChannel.write(ByteBuffer.wrap(disconnectStream.toByteArray()));
         } catch (IOException exception) {
         }
      }
   }

   /**
    * Thread to receive and process data from SSH server
    */
   public void run() {
      ByteBuffer readByteBuffer = ByteBuffer.allocate(35000 * 2);

      try {
         while (!closed && socketChannel.read(readByteBuffer) > 0) {
            /* Handle new packet */
            handlePacket(readByteBuffer);
         }

         disconnect();
      } catch (EOFException exception) {
         /* Close connection */
         disconnect(SSHConstants.SSH_DISCONNECT_PROTOCOL_ERROR, exception.toString());
      } catch (DisconnectException exception) {
         setConnectionStatus(CONNECTION_FAILED);
         /* Something went wrong: send a disconnect message */
         disconnect(exception.getReasonCode(), exception.getMessage());
      } catch (IOException exception) {
         setConnectionStatus(CONNECTION_FAILED);

         /* Something went wrong: send a disconnect message */
         disconnect(SSHConstants.SSH_DISCONNECT_PROTOCOL_ERROR, exception.toString());
      } catch (Exception exception) {
         setConnectionStatus(CONNECTION_FAILED);

         /* Something went wrong: send a disconnect message */
         disconnect(SSHConstants.SSH_DISCONNECT_PROTOCOL_ERROR, exception.toString());
      }
   }

   /**
    * Send a user authentication request.
    *
    * @exception IOException
    */
   private void sendAuthenticationRequest() throws IOException {
      if (authMethod != null) {
         /* Send authentication request message */
         logger.fine("sendAuthenticationRequest: method name = " + authMethod.getMethodName());
         authMethod.setServerHostKeyAlgorithmList(getServerHostKeyList());
         socketChannel.write(ByteBuffer.wrap(authMethod.getRequestPacket(sessionIdentifier)));
      } else {
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_AUTH_CANCELLED_BY_USER, "Authentication method is null");
      }
   }

   /**
    * Handle incoming packet.
    *
    * @param payload
    *
    * @exception IOException
    */
   private void handlePacket(ByteBuffer payload) throws IOException {
      boolean packetHandled = true;

      /* Read message type */
      int message = payload.get();

      if ((message >= 1) && (message <= 19)) {
         /* 1-19 Transport layer generic messages */
         switch (message) {
            case SSHConstants.SSH_MSG_DISCONNECT:
               logger.fine("handlePacket: SSH_MSG_DISCONNECT");
               handleDisconnect(payload);
               break;
            case SSHConstants.SSH_MSG_IGNORE:
               logger.fine("handlePacket: SSH_MSG_IGNORE");
               handleIgnore(payload);
               break;
            case SSHConstants.SSH_MSG_UNIMPLEMENTED:
               logger.fine("handlePacket: SSH_MSG_UNIMPLEMENTED");
               handleUnimplemented(payload);
               break;
            case SSHConstants.SSH_MSG_DEBUG:
               logger.fine("handlePacket: SSH_MSG_DEBUG");
               handleDebug(payload);
               break;
            case SSHConstants.SSH_MSG_SERVICE_ACCEPT:
               logger.fine("handlePacket: SSH_MSG_SERVICE_ACCEPT");
               handleServiceAccept(payload);
               break;
            default:
               packetHandled = false;
               break;
         }
      } else if ((message >= 20) && (message <= 29)) {
         /* 20-29 Algorithm negotiation messages */
         switch (message) {
            case SSHConstants.SSH_MSG_KEXINIT:
               logger.fine("handlePacket: SSH_MSG_KEXINIT");

               /* Save server's key exchange payload for later */
               byte[] serverKexInitPayload = new byte[payload.limit() - payload.position() + 1];
               System.arraycopy(payload.array(), payload.position() - 1, serverKexInitPayload, 0, serverKexInitPayload.length);

               /* Read the cookie */
               byte[] cookie = new byte[KeyExchange.COOKIE_SIZE];
               payload.get(cookie, 0, cookie.length);

               /* Read the key exchange algorithms */
               String[] kexAlgorithmList = SSHNameList.readNameList(payload);
               logger.finer("handleKeyExchangeInit: kexAlgorithmList = " + SSHNameList.nameListToString(kexAlgorithmList));
               String kexAlgorithm = KeyExchange.decideAlgorithm(KeyExchange.PREFERRED_KEX_ALGORITHMS, kexAlgorithmList);

               if (kexAlgorithm != null) {
                  if (kexAlgorithm.equals(KeyExchange.DH_GROUP_EXCHANGE_SHA1) || kexAlgorithm.equals(KeyExchange.DH_GROUP_EXCHANGE_SHA256)) {
                     keyExchange = new DHGroupKeyExchange(this, kexAlgorithm, serverKexInitPayload, sessionIdentifier);
                  } else if (kexAlgorithm.startsWith("ecdh")) {
                     keyExchange = new ECDHKeyExchange(this, kexAlgorithm, serverKexInitPayload, sessionIdentifier);
                  } else {
                     keyExchange = new DHKeyExchange(this, kexAlgorithm, serverKexInitPayload, sessionIdentifier);
                  }
               } else {
                  throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "Could not agree on a key exchange algorithm");
               }

               /* Purposely passthrough */
            default:
               packetHandled = keyExchange.handlePacket(message, payload);
               break;
         }
      } else if ((message >= 30) && (message <= 49)) {
         /* 30-49 Key exchange method specific messages */
         packetHandled = keyExchange.handlePacket(message, payload);
      } else if ((message >= 50) && (message <= 79)) {
         /* 50-59 User authentication generic messages */
         /* 60-79 User authentication method specific messages */
         if (authMethod != null) {
            AuthMethod retryAuthMethod = authMethod.handlePacket(message, payload);

            if (message != SSHConstants.SSH_MSG_USERAUTH_BANNER) {
               if (retryAuthMethod == null) {
                  if (authMethod.isAuthenticated() == true) {
                     setConnectionStatus(CONNECTION_SUCCESS);
                  } else {
                     setConnectionStatus(AUTHENTICATION_FAILED);
                  }
               } else {
                  this.authMethod = retryAuthMethod;
                  sendAuthenticationRequest();
               }
            }
         }
      } else if ((message >= 80) && (message <= 89)) {
         /* 80-89 Connection specific messages */
         packetHandled = connection.handlePacket(message, payload);
      } else if ((message >= 90) && (message <= 127)) {
         /* 90-127 Channel specific messages */
         packetHandled = connection.handlePacket(message, payload);
      } else if ((message >= 128) && (message <= 191)) {
         /* 128-191 Reserved */
         packetHandled = false;
      } else if ((message >= 192) && (message <= 255)) {
         /* 192-255 Local extensions */
         packetHandled = false;
      } else {
         packetHandled = false;
      }

      if (packetHandled == false) {
         /* Unrecognized message */
         logger.fine("handlePacket: Unrecognized message = " + message);
         byteOutputStream.reset();
         byteOutputStream.write(SSHConstants.SSH_MSG_UNIMPLEMENTED);
         SSHUint32.writeUnsignedInt(byteOutputStream, socketChannel.getReadSequenceNum());

         socketChannel.write(ByteBuffer.wrap(byteOutputStream.toByteArray()));
      }
   }

   /**
    * Handle the service accepted message.
    *
    * @param byteBuffer
    *
    * @exception IOException
    */
   private void handleServiceAccept(ByteBuffer byteBuffer) throws IOException {
      /* Read the service name */
      if (byteBuffer.remaining() > 0) {
         String serviceName = SSHString.readString(byteBuffer);

         logger.finer("handleServiceAccept: serviceName = " + serviceName);
      } else {
         logger.fine("handleServiceAccept: No service name!");
      }

      sendAuthenticationRequest();
   }

   /**
    * Handle the ignore message.
    *
    * @param byteBuffer
    *
    * @exception IOException
    */
   private void handleIgnore(ByteBuffer byteBuffer) throws IOException {
      /* Read the data */
      String data = SSHString.readString(byteBuffer);

      logger.finer("handleIgnore: data = " + data);
   }

   /**
    * Handle the unimplemented message.
    *
    * @param byteBuffer
    *
    * @exception IOException
    */
   private void handleUnimplemented(ByteBuffer byteBuffer) throws IOException {
      /* Read the data */
      long packetSequenceNumber = SSHUint32.readUnsignedInt(byteBuffer);

      logger.finer("handleUnimplemented: packetSequenceNumber = " + packetSequenceNumber);
   }

   /**
    * Handle the debug message.
    *
    * @param byteBuffer
    *
    * @exception IOException
    */
   private void handleDebug(ByteBuffer byteBuffer) throws IOException {
      /* Read the always display */
      boolean alwaysDisplay = SSHBoolean.readBoolean(byteBuffer);

      /* Read the message */
      String message = SSHString.readString(byteBuffer);

      /* Read languageTag */
      String languageTag = SSHString.readString(byteBuffer);

      logger.finer("handleDebug: alwaysDisplay = " + alwaysDisplay);
      logger.finer("handleDebug: message = " + message);
      logger.finer("handleDebug: languageTag = " + languageTag);
   }

   /**
    * Handle the disconnect message.
    *
    * @param byteBuffer
    *
    * @exception IOException
    */
   private void handleDisconnect(ByteBuffer byteBuffer) throws IOException {
      /* Read the reason code */
      int reasonCode;
      try {
         reasonCode = byteBuffer.getInt();
      } catch (BufferUnderflowException exception) {
         throw new IOException(exception.toString());
      }

      /* Read the description */
      String description = SSHString.readString(byteBuffer);

      /* Read the language tag */
      String languageTag = SSHString.readString(byteBuffer);

      logger.finer("handleDisconnect: reasonCode = " + getReasonCodeAsString(reasonCode));
      logger.finer("handleDisconnect: description = " + description);
      logger.finer("handleDisconnect: languageTag = " + languageTag);

      throw new IOException(description);
   }

   /**
    * Return the disconnect reason code as a string.
    *
    * @param reasonCode   reason code number
    *
    * @return   reason code as string
    */
   private static String getReasonCodeAsString(int reasonCode) {
      switch (reasonCode) {
         case SSHConstants.SSH_DISCONNECT_HOST_NOT_ALLOWED_TO_CONNECT:
            return "SSH_DISCONNECT_HOST_NOT_ALLOWED_TO_CONNECT";
         case SSHConstants.SSH_DISCONNECT_PROTOCOL_ERROR:
            return "SSH_DISCONNECT_PROTOCOL_ERROR";
         case SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED:
            return "SSH_DISCONNECT_KEY_EXCHANGE_FAILED";
         case SSHConstants.SSH_DISCONNECT_RESERVED:
            return "SSH_DISCONNECT_RESERVED";
         case SSHConstants.SSH_DISCONNECT_MAC_ERROR:
            return "SSH_DISCONNECT_MAC_ERROR";
         case SSHConstants.SSH_DISCONNECT_COMPRESSION_ERROR:
            return "SSH_DISCONNECT_COMPRESSION_ERROR";
         case SSHConstants.SSH_DISCONNECT_SERVICE_NOT_AVAILABLE:
            return "SSH_DISCONNECT_SERVICE_NOT_AVAILABLE";
         case SSHConstants.SSH_DISCONNECT_PROTOCOL_VERSION_NOT_SUPPORTED:
            return "SSH_DISCONNECT_PROTOCOL_VERSION_NOT_SUPPORTED";
         case SSHConstants.SSH_DISCONNECT_HOST_KEY_NOT_VERIFIABLE:
            return "SSH_DISCONNECT_HOST_KEY_NOT_VERIFIABLE";
         case SSHConstants.SSH_DISCONNECT_CONNECTION_LOST:
            return "SSH_DISCONNECT_CONNECTION_LOST";
         case SSHConstants.SSH_DISCONNECT_BY_APPLICATION:
            return "SSH_DISCONNECT_BY_APPLICATION";
         case SSHConstants.SSH_DISCONNECT_TOO_MANY_CONNECTIONS:
            return "SSH_DISCONNECT_TOO_MANY_CONNECTIONS";
         case SSHConstants.SSH_DISCONNECT_AUTH_CANCELLED_BY_USER:
            return "SSH_DISCONNECT_AUTH_CANCELLED_BY_USER";
         case SSHConstants.SSH_DISCONNECT_NO_MORE_AUTH_METHODS_AVAILABLE:
            return "SSH_DISCONNECT_NO_MORE_AUTH_METHODS_AVAILABLE";
         case SSHConstants.SSH_DISCONNECT_ILLEGAL_USER_NAME:
            return "SSH_DISCONNECT_ILLEGAL_USER_NAME";
         default:
            return "Unknown (" + reasonCode + ")";
      }
   }

   /**
    * Set the session identifer.
    * 
    * @param sessionIdentifier  byte array session identifer
    */
   void setSessionIdentifier(byte[] sessionIdentifier) {
       this.sessionIdentifier = sessionIdentifier;
   }

   private void setProtocolErrorFlags() {
      if ((serverVersion.indexOf("OpenSSH_2.3") != -1) || 
          (serverVersion.indexOf("OpenSSH_2.5.0p1") != -1) ||
          (serverVersion.indexOf("OpenSSH_2.5.1p1") != -1)) {
         protocolErrorFlags |= ERROR_BAD_AES;
      }
      if ((serverVersion.indexOf("OpenSSH-2.0") != -1) || 
          (serverVersion.indexOf("OpenSSH-2.1") != -1) ||
          (serverVersion.indexOf("OpenSSH_2.1") != -1) || 
          (serverVersion.indexOf("OpenSSH_2.2") != -1) ||
          (serverVersion.indexOf("OpenSSH_2.3") != -1) || 
          (serverVersion.indexOf("OpenSSH_2.5.0") != -1) ||
          (serverVersion.indexOf("OpenSSH_2.5.1") != -1) || 
          (serverVersion.indexOf("OpenSSH_2.5.2") != -1)) {
         protocolErrorFlags |= ERROR_OLD_GEX;
      }
      if ((serverVersion.indexOf("OpenSSH-2") != -1) || 
          (serverVersion.indexOf("OpenSSH_2") != -1) ||
          (serverVersion.indexOf("OpenSSH_3.0") != -1) || 
          (serverVersion.indexOf("OpenSSH_3.1") != -1) ||
          (serverVersion.indexOf("OpenSSH_3.2") != -1) || 
          (serverVersion.indexOf("OpenSSH_3.3") != -1) ||
          (serverVersion.indexOf("OpenSSH_3.4") != -1)) {
         protocolErrorFlags |= ERROR_INT_EXIT_SIGNAL;
      }
   }
}
