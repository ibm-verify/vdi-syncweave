/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * (C) Copyright IBM Corp. 2005, 2019 All Rights Reserved
 *
 * The source code for this program is not published or other-
 * wise divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */
package com.ibm.net.ssh;

import java.security.SecureRandom;

/**
 * This class contains the constants used for SSH.
 *
 * @author Eric W. Brown
 */
final class SSHConstants {
   /** Copyright statement */
   private static final String COPYRIGHT = Copyright.HEADER + "2005, 2019" + Copyright.FOOTER;

   static final String SSH_VERSION_HEADING = "SSH-";
   static final String VERSION_TWO         = "2.0";
   static final String IBM_VERSION_IDENTITY = "-IBM_SSH_Client_" + "2019_06_03";

   /** 1-19 Transport layer generic messages */
   static final byte SSH_MSG_DISCONNECT      = 1;
   static final byte SSH_MSG_IGNORE          = 2;
   static final byte SSH_MSG_UNIMPLEMENTED   = 3;
   static final byte SSH_MSG_DEBUG           = 4;
   static final byte SSH_MSG_SERVICE_REQUEST = 5;
   static final byte SSH_MSG_SERVICE_ACCEPT  = 6;

   /** 20-29 Algorithm negotiation messages */
   static final byte SSH_MSG_KEXINIT         = 20;
   static final byte SSH_MSG_NEWKEYS         = 21;

   /** 30-49 Key exchange method specific messages */
   static final byte SSH_MSG_KEXDH_INIT      = 30;
   static final byte SSH_MSG_KEXDH_REPLY     = 31;

   /** Group exchange specific key exchange methods */
   static final byte SSH_MSG_KEX_DH_GEX_REQUEST_OLD = 30;
   static final byte SSH_MSG_KEX_DH_GEX_GROUP       = 31;
   static final byte SSH_MSG_KEX_DH_GEX_INIT        = 32;
   static final byte SSH_MSG_KEX_DH_GEX_REPLY       = 33;
   static final byte SSH_MSG_KEX_DH_GEX_REQUEST     = 34;

   /** GSSAPI specific key exchange methods */
   static final byte SSH_MSG_KEXGSS_INIT            = 30;
   static final byte SSH_MSG_KEXGSS_CONTINUE        = 31;
   static final byte SSH_MSG_KEXGSS_COMPLETE        = 32;
   static final byte SSH_MSG_KEXGSS_HOSTKEY         = 33;
   static final byte SSH_MSG_KEXGSS_ERROR           = 34;
   static final byte SSH_MSG_KEXGSS_GROUPREQ        = 40;
   static final byte SSH_MSG_KEXGSS_GROUP           = 41;

   /** 50-59 User authentication generic messages */
   static final byte SSH_MSG_USERAUTH_REQUEST = 50;
   static final byte SSH_MSG_USERAUTH_FAILURE = 51;
   static final byte SSH_MSG_USERAUTH_SUCCESS = 52;
   static final byte SSH_MSG_USERAUTH_BANNER  = 53;

   /** 60-79 User authentication method specific messages */

   /** Public key authentication specific */
   static final byte SSH_MSG_USERAUTH_PK_OK                    = 60;

   /** Password authentication specific */
   static final byte SSH_MSG_USERAUTH_PASSWD_CHANGEREQ         = 60;

   /** Keyboard interactive authentication specific */
   static final byte SSH_MSG_USERAUTH_INFO_REQUEST             = 60;
   static final byte SSH_MSG_USERAUTH_INFO_RESPONSE            = 61;

   /** GSSAPI authentication specific */
   static final byte SSH_MSG_USERAUTH_GSSAPI_RESPONSE          = 60;
   static final byte SSH_MSG_USERAUTH_GSSAPI_TOKEN             = 61;
   static final byte SSH_MSG_USERAUTH_GSSAPI_EXCHANGE_COMPLETE = 63;
   static final byte SSH_MSG_USERAUTH_GSSAPI_ERROR             = 64;
   static final byte SSH_MSG_USERAUTH_GSSAPI_ERRTOK            = 65;
   static final byte SSH_MSG_USERAUTH_GSSAPI_MIC               = 66;

   /** 80-89 Connection specific messages */
   static final byte SSH_MSG_GLOBAL_REQUEST            = 80;
   static final byte SSH_MSG_REQUEST_SUCCESS           = 81;
   static final byte SSH_MSG_REQUEST_FAILURE           = 82;

   /** 90-127 Channel specific messages */
   static final byte SSH_MSG_CHANNEL_OPEN              = 90;
   static final byte SSH_MSG_CHANNEL_OPEN_CONFIRMATION = 91;
   static final byte SSH_MSG_CHANNEL_OPEN_FAILURE      = 92;
   static final byte SSH_MSG_CHANNEL_WINDOW_ADJUST     = 93;
   static final byte SSH_MSG_CHANNEL_DATA              = 94;
   static final byte SSH_MSG_CHANNEL_EXTENDED_DATA     = 95;
   static final byte SSH_MSG_CHANNEL_EOF               = 96;
   static final byte SSH_MSG_CHANNEL_CLOSE             = 97;
   static final byte SSH_MSG_CHANNEL_REQUEST           = 98;
   static final byte SSH_MSG_CHANNEL_SUCCESS           = 99;
   static final byte SSH_MSG_CHANNEL_FAILURE           = 100;

   /** Disconnection reason codes */
   static final byte SSH_DISCONNECT_HOST_NOT_ALLOWED_TO_CONNECT    = 1;
   static final byte SSH_DISCONNECT_PROTOCOL_ERROR                 = 2;
   static final byte SSH_DISCONNECT_KEY_EXCHANGE_FAILED            = 3;
   static final byte SSH_DISCONNECT_RESERVED                       = 4;
   static final byte SSH_DISCONNECT_MAC_ERROR                      = 5;
   static final byte SSH_DISCONNECT_COMPRESSION_ERROR              = 6;
   static final byte SSH_DISCONNECT_SERVICE_NOT_AVAILABLE          = 7;
   static final byte SSH_DISCONNECT_PROTOCOL_VERSION_NOT_SUPPORTED = 8;
   static final byte SSH_DISCONNECT_HOST_KEY_NOT_VERIFIABLE        = 9;
   static final byte SSH_DISCONNECT_CONNECTION_LOST                = 10;
   static final byte SSH_DISCONNECT_BY_APPLICATION                 = 11;
   static final byte SSH_DISCONNECT_TOO_MANY_CONNECTIONS           = 12;
   static final byte SSH_DISCONNECT_AUTH_CANCELLED_BY_USER         = 13;
   static final byte SSH_DISCONNECT_NO_MORE_AUTH_METHODS_AVAILABLE = 14;
   static final byte SSH_DISCONNECT_ILLEGAL_USER_NAME              = 15;

   /** Service names */
   static final String USERAUTH_SERVICE   = "ssh-userauth";
   static final String CONNECTION_SERVICE = "ssh-connection";
   static final String SERVICE_NONE = "none";

   /** SSH key formats */
   static final String DSS_KEY_FORMAT = "ssh-dss";
   static final String RSA_KEY_FORMAT = "ssh-rsa";
   
   /** SSH key algorithms */
   static final String RSA_SHA2_256_ALGORITHM = "rsa-sha2-256";
   static final String RSA_SHA2_512_ALGORITHM = "rsa-sha2-512";
   
   /** ECC public key formats */
   static final String ECDSA_SHA2_NISTP_256 = "ecdsa-sha2-nistp256";
   static final String ECDSA_SHA2_NISTP_384 = "ecdsa-sha2-nistp384";
   static final String ECDSA_SHA2_NISTP_521 = "ecdsa-sha2-nistp521";

   /** UTF-8 encoding constant */
   static final String UTF_8    = "UTF-8";

   /** US-ASCII encoding constant */
   static final String US_ASCII = "US-ASCII";

   /** Our secure random number generator */
   static final SecureRandom SECURE_RANDOM = new SecureRandom();

   /**
    * Empty Constructor
    */
   private SSHConstants() {
   }
}
