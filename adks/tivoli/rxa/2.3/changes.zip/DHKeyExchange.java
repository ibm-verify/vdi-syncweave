/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * (C) Copyright IBM Corp. 2005, 2019 All Rights Reserved
 *
 * The source code for this program is not published or other-
 * wise divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */
package com.ibm.net.ssh;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import java.math.BigInteger;

import java.nio.ByteBuffer;

/**
 * This class is responsible for diffie hellman
 * key exchange mechanism of the SSH protocol.
 *
 * @author Eric W. Brown
 */
final class DHKeyExchange extends KeyExchange {
   /** Copyright statement */
   private static final String COPYRIGHT = Copyright.HEADER + "2005, 2019" + Copyright.FOOTER;

   private static final BigInteger OAKLEY_GROUP2 = new BigInteger("FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1" +
                                                                  "29024E088A67CC74020BBEA63B139B22514A08798E3404DD" +
                                                                  "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245" +
                                                                  "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED" +
                                                                  "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE65381" +
                                                                  "FFFFFFFFFFFFFFFF", 16);

   private static final BigInteger OAKLEY_GROUP14 = new BigInteger("FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1" +
                                                                   "29024E088A67CC74020BBEA63B139B22514A08798E3404DD" +
                                                                   "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245" +
                                                                   "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED" +
                                                                   "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D" +
                                                                   "C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F" +
                                                                   "83655D23DCA3AD961C62F356208552BB9ED529077096966D" +
                                                                   "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B" +
                                                                   "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9" +
                                                                   "DE2BCBF6955817183995497CEA956AE515D2261898FA0510" +
                                                                   "15728E5A8AACAA68FFFFFFFFFFFFFFFF", 16);

   private static final BigInteger OAKLEY_GROUP16 = new BigInteger("FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1" +
		   														   "29024E088A67CC74020BBEA63B139B22514A08798E3404DD" +
		   														   "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245" +
		   														   "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED" +
		   														   "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D" +
		   														   "C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F" +
		   														   "83655D23DCA3AD961C62F356208552BB9ED529077096966D" +
		   														   "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B" +
		   														   "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9" +
		   														   "DE2BCBF6955817183995497CEA956AE515D2261898FA0510" +
		   														   "15728E5A8AAAC42DAD33170D04507A33A85521ABDF1CBA64" +
		   														   "ECFB850458DBEF0A8AEA71575D060C7DB3970F85A6E1E4C7" +
		   														   "ABF5AE8CDB0933D71E8C94E04A25619DCEE3D2261AD2EE6B" +
		   														   "F12FFA06D98A0864D87602733EC86A64521F2B18177B200C" +
		   														   "BBE117577A615D6C770988C0BAD946E208E24FA074E5AB31" +
		   														   "43DB5BFCE0FD108E4B82D120A92108011A723C12A787E6D7" +
		   														   "88719A10BDBA5B2699C327186AF4E23C1A946834B6150BDA" +
		   														   "2583E9CA2AD44CE8DBBBC2DB04DE8EF92E8EFC141FBECAA6" +
		   														   "287C59474E6BC05D99B2964FA090C3A2233BA186515BE7ED" +
		   														   "1F612970CEE2D7AFB81BDD762170481CD0069127D5B05AA9" +
		   														   "93B4EA988D8FDDC186FFB7DC90A6C08F4DF435C934063199" +
		   														   "FFFFFFFFFFFFFFFF", 16);
   
   private static final BigInteger OAKLEY_GROUP18 = new BigInteger("FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1" +
		   														   "29024E088A67CC74020BBEA63B139B22514A08798E3404DD" +
		   														   "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245" +
		   														   "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED" +
		   														   "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D" +
		   														   "C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F" +
		   														   "83655D23DCA3AD961C62F356208552BB9ED529077096966D" +
		   														   "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B" +
		   														   "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9" +
		   														   "DE2BCBF6955817183995497CEA956AE515D2261898FA0510" +
		   														   "15728E5A8AAAC42DAD33170D04507A33A85521ABDF1CBA64" +
		   														   "ECFB850458DBEF0A8AEA71575D060C7DB3970F85A6E1E4C7" +
		   														   "ABF5AE8CDB0933D71E8C94E04A25619DCEE3D2261AD2EE6B" +
		   														   "F12FFA06D98A0864D87602733EC86A64521F2B18177B200C" +
		   														   "BBE117577A615D6C770988C0BAD946E208E24FA074E5AB31" +
		   														   "43DB5BFCE0FD108E4B82D120A92108011A723C12A787E6D7" +
		   														   "88719A10BDBA5B2699C327186AF4E23C1A946834B6150BDA" +
		   														   "2583E9CA2AD44CE8DBBBC2DB04DE8EF92E8EFC141FBECAA6" +
		   														   "287C59474E6BC05D99B2964FA090C3A2233BA186515BE7ED" +
		   														   "1F612970CEE2D7AFB81BDD762170481CD0069127D5B05AA9" +
		   														   "93B4EA988D8FDDC186FFB7DC90A6C08F4DF435C934028492" +
		   														   "36C3FAB4D27C7026C1D4DCB2602646DEC9751E763DBA37BD" +
		   														   "F8FF9406AD9E530EE5DB382F413001AEB06A53ED9027D831" +
		   														   "179727B0865A8918DA3EDBEBCF9B14ED44CE6CBACED4BB1B" +
		   														   "DB7F1447E6CC254B332051512BD7AF426FB8F401378CD2BF" +
		   														   "5983CA01C64B92ECF032EA15D1721D03F482D7CE6E74FEF6" +
		   														   "D55E702F46980C82B5A84031900B1C9E59E7C97FBEC7E8F3" +
		   														   "23A97A7E36CC88BE0F1D45B7FF585AC54BD407B22B4154AA" +
		   														   "CC8F6D7EBF48E1D814CC5ED20F8037E0A79715EEF29BE328" +
		   														   "06A1D58BB7C5DA76F550AA3D8A1FBFF0EB19CCB1A313D55C" +
		   														   "DA56C9EC2EF29632387FE8D76E3C0468043E8F663F4860EE" +
		   														   "12BF2D5B0B7474D6E694F91E6DBE115974A3926F12FEE5E4" +
		   														   "38777CB6A932DF8CD8BEC4D073B931BA3BC832B68D9DD300" +
		   														   "741FA7BF8AFC47ED2576F6936BA424663AAB639C5AE4F568" +
		   														   "3423B4742BF1C978238F16CBE39D652DE3FDB8BEFC848AD9" +
		   														   "22222E04A4037C0713EB57A81A23F0C73473FC646CEA306B" +
		   														   "4BCBC8862F8385DDFA9D4B7FA2C087E879683303ED5BDD3A" +
		   														   "062B3CF5B3A278A66D2A13F83F44F82DDF310EE074AB6A36" +
		   														   "4597E899A0255DC164F31CC50846851DF9AB48195DED7EA1" +
		   														   "B1D510BD7EE74D73FAF36BC31ECFA268359046F4EB879F92" +
		   														   "4009438B481C6CD7889A002ED5EE382BC9190DA6FC026E47" +
		   														   "9558E4475677E9AA9E3050E2765694DFC81F56E880B96E71" +
		   														   "60C980DD98EDD3DFFFFFFFFFFFFFFFFF", 16);
 
   /**
    * Constructor
    */
   DHKeyExchange(SecureSession sshSession, String kexAlgorithm, byte[] serverKexInitPayload, byte[] sessionIdentifier) {
      super(sshSession, kexAlgorithm, serverKexInitPayload, sessionIdentifier);
   }

   /**
    * Handle incoming connection packet.
    *
    * @param message      the packet message number
    * @param byteBuffer   the packet's payload buffer
    *
    * @return    whether the packet message was handled or not
    * @exception IOException
    */
   boolean handlePacket(int message, ByteBuffer byteBuffer) throws IOException {
      boolean packetHandled = true;

      switch (message) {
         case SSHConstants.SSH_MSG_KEXINIT:
            handleKeyExchangeInit(byteBuffer);
            break;
         case SSHConstants.SSH_MSG_KEXDH_REPLY:
            logger.fine("handlePacket: SSH_MSG_KEXDH_REPLY");
            handleKeyExchangeDHReply(byteBuffer);
            break;
         default:
            packetHandled = super.handlePacket(message, byteBuffer);
            break;
      }

      return packetHandled;
   }

   /**
    * Handle the key exchange initialize message.
    *
    * @param byteBuffer
    *
    * @exception IOException
    */
   protected void handleKeyExchangeInit(ByteBuffer byteBuffer) throws IOException {
      super.handleKeyExchangeInit(byteBuffer);

      /* Diffie Hellman group1 or group14 sha1 */

      /* Send key exchange */
      byteOutputStream.reset();
      byteOutputStream.write(SSHConstants.SSH_MSG_KEXDH_INIT);

      if (kexAlgorithm.equals(DH_GROUP1_SHA1)) {
         primeP = OAKLEY_GROUP2;
      } else if (kexAlgorithm.equals(DH_GROUP14_SHA1) || kexAlgorithm.equals(DH_GROUP14_SHA256)) {
         primeP = OAKLEY_GROUP14;
      } else if (kexAlgorithm.equals(DH_GROUP16_SHA512)) {
          primeP = OAKLEY_GROUP16;
      } else if (kexAlgorithm.equals(DH_GROUP18_SHA512)) {
          primeP = OAKLEY_GROUP18;
      }
      clientE = generateE(BigInteger.valueOf(2));
      SSHMpint.writeBigInteger(byteOutputStream, clientE);

      sshSession.socketChannel.write(ByteBuffer.wrap(byteOutputStream.toByteArray()));
   }

   /**
    * Handle the key exchange diffie-hellman reply message.
    *
    * @param byteBuffer
    *
    * @exception IOException
    */
   private void handleKeyExchangeDHReply(ByteBuffer byteBuffer) throws IOException {
      /* Read the server public host key and certificates */
      byte[] serverHostKeyCertData = SSHString.readStringAsBytes(byteBuffer);

      /* Read the f */
      serverF = SSHMpint.readBigInteger(byteBuffer);

      /* Read the signature */
      byte[] signatureOfH = SSHString.readStringAsBytes(byteBuffer);

      //   logger.finer("serverHostKeyCertData = " + SSHString.bytesToString(serverHostKeyCertData));
      //   logger.finer("serverF = " + SSHString.bytesToString(serverF.toByteArray()));
      //   logger.finer("signatureOfH = " + SSHString.bytesToString(signatureOfH));

      /* Verify the f is within range [1, p-1] */
      boolean rangeOkay = verifyValueRange(serverF);
      if (rangeOkay == false) {
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "Server's f value out of range!");
      }

      /* Compute the shared secret K */
      sharedSecretK = computeSharedSecret(BigInteger.valueOf(2));
      rangeOkay = verifyValueRange(new BigInteger(1, sharedSecretK));
      if (rangeOkay == false) {
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_KEY_EXCHANGE_FAILED, "Shared secret k value out of range!");
      }

      /* Compute exchange hash H */
      ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
      SSHString.writeString(byteArray, sshSession.clientVersion);
      SSHString.writeString(byteArray, sshSession.serverVersion);
      SSHString.writeString(byteArray, clientKexInitPayload);
      SSHString.writeString(byteArray, serverKexInitPayload);
      SSHString.writeString(byteArray, serverHostKeyCertData);
      SSHMpint.writeBigInteger(byteArray, clientE);
      SSHMpint.writeBigInteger(byteArray, serverF);
      SSHMpint.writeBigInteger(byteArray, new BigInteger(1, sharedSecretK));  // needs to always be positive big int

      //   logger.finer("exchange data = " + SSHString.bytesToString(byteArray.toByteArray()));

      shaDigest.reset();
      shaDigest.update(byteArray.toByteArray());
      exchangeHashH = shaDigest.digest();

      //   logger.finer("exchangeHashH = " + SSHString.bytesToString(exchangeHashH));

      if (sessionIdentifier == null) {
         sessionIdentifier = new byte[exchangeHashH.length];
         System.arraycopy(exchangeHashH, 0, sessionIdentifier, 0, exchangeHashH.length);
         sshSession.setSessionIdentifier(sessionIdentifier);
      }

      boolean isVerified = verifySignature(serverHostKeyCertData, signatureOfH);
      if (isVerified == true) {
         logger.fine("handleKeyExchangeDHReply: Server signature verified");
      } else {
         logger.fine("handleKeyExchangeDHReply: Server signature wrong!");
         throw new DisconnectException(SSHConstants.SSH_DISCONNECT_HOST_KEY_NOT_VERIFIABLE, "handleKeyExchangeDHReply: Server signature wrong!");
      }

      /* Compute the IV and keys */
      computeKeys();

      /* Send new keys message */
      sendNewKeys();
   }
}
