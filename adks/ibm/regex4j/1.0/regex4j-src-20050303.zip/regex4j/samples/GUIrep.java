/*
 * (C) Copyright IBM Corp. 1999,2000  All rights reserved.
 *
 * US Government Users Restricted Rights Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

import java.awt.Color;
import java.awt.Font;
import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import javax.swing.WindowConstants;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import com.ibm.regex.RegularExpression;
import com.ibm.regex.Match;

/**
 * A sample for Regex for Java.
 * This requires JDK 1.1 + Swing 1.1.
 *
 * @version $Id: GUIrep.java,v 1.2 2000/11/08 06:05:34 kent Exp $
 * @author TAMURA Kent &lt;kent@trl.ibm.co.jp&gt;
 */
public class GUIrep {
    static void show(RegularExpression regex, Match m, String fname, int x, int y) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(fname));
            StringBuffer buffer = new StringBuffer();
            String line;
            while ((line = br.readLine()) != null) {
                buffer.append(line);
                buffer.append("\n");
            }
            String text = buffer.toString();
            
            JTextPane textPane = new JTextPane();
            textPane.setFont(new Font("Monospaced", Font.PLAIN, 14));
            textPane.setText(text);

            SimpleAttributeSet emphasis = new SimpleAttributeSet();
            StyleConstants.setForeground(emphasis, Color.red);
            StyleConstants.setBold(emphasis, true);

            int len = text.length();
            int pos = 0;
            int n = 0;                          // The number of matches
            while (pos < len) {
                if (!regex.matches(text, pos, len, m))
                    break;
                n ++;
                int begin = m.getBeginning(0);
                int next = m.getEnd(0);
                if (next == begin) {            // Skips zero-width match.
                    pos = next+1;
                } else {                        // Paints matched region.
                    textPane.getStyledDocument().setCharacterAttributes(begin, next-begin,
                                                                        emphasis, false);
                    pos = next;
                }
            }
            System.err.println(n == 0 ? "No match." : n+" matches.");
            if (n > 0) {
                JFrame frame = new JFrame("GUIrep: "+fname);
                frame.getContentPane().add(new JScrollPane(textPane));
                frame.setSize(640, 480);
                frame.setLocation(new Point(x, y));
                frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
                frame.show();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] argv) {
        try {
            String pattern = argv[0];

            System.err.println("Pattern: "+pattern);
            RegularExpression regex = new RegularExpression(pattern);
            Match m = new Match();
            for (int i = 1;  i < argv.length;  i ++) {
                show(regex, m, argv[i], i*16, i*16);
            }
            System.err.println("Done.");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
