/*
 * (C) Copyright IBM Corp. 1999-2000  All rights reserved.
 *
 * US Government Users Restricted Rights Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

import com.ibm.regex.Match;
import com.ibm.regex.ParseException;
import com.ibm.regex.RegularExpression;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Vector;

/**
 * A Grep utility.
 *
 * @version $Id: Grep.java,v 1.2 2000/11/08 06:05:34 kent Exp $
 * @author TAMURA Kent &lt;kent@trl.ibm.co.jp&gt;
 */
public class Grep {
    static String EMPHASIS_START = "";//"\u001b[7m";
    static String EMPHASIS_END = "";//"\u001b[0m";

    static final int O_BYTE_OFFSET = 1<<0;      // -b *
    static final int O_COUNT = 1<<1;            // -c *
    static final int O_NO_FILENAME = 1<<2;      // -h
    static final int O_FILES_WITHOUT_MATCH = 1<<3; // -L
    static final int O_FILES_WITH_MATCHES = 1<<6; // -l
    static final int O_LINE_NUMBER = 1<<5;      // -n
    static final int O_QUIET = 1<<6;            // -q
    static final int O_RECURSIVE = 1<<7;        // -r *
    static final int O_NO_MESSAGES = 1<<8;      // -s
    static final int O_REVERT_MATCH = 1<<9;     // -v
    static final int O_WORD_REGEXP = 1<<10;     // -w
    static final int O_LINE_REGEXP = 1<<11;     // -x

    static private boolean isSet(int opts, int flag) {
        return (opts&flag) == flag;
    }

    static boolean grep(String name, BufferedReader br, RegularExpression reg,
                        int opts, int before, int after)
        throws IOException {
        String[] lineBuffer = null;
        if (before > 0) {
            lineBuffer = new String[before];
            for (int i = 0;  i < before;  i ++)  lineBuffer[i] = null;
        }
            
        boolean found = false;
        int linenum = 0;
        String line;
        Match match = new Match();
        int matchedLine = -1;
        int lastPrintedLine = 0;
        while ((line = br.readLine()) != null) {
            linenum ++;
            if (isSet(opts, O_FILES_WITH_MATCHES)) {
                if (reg.matches(line)) {
                    found = true;
                    System.out.println(name);
                    break;
                }
            } else if (isSet(opts, O_FILES_WITHOUT_MATCH)) {
                if (reg.matches(line)) {
                    found = true;
                    break;
                }
            } else if (!isSet(opts, O_REVERT_MATCH) && reg.matches(line, match)) {
                found = true;
                matchedLine = linenum;
                if (isSet(opts, O_QUIET))  break;
                if ((before > 0 || after > 0) && linenum-before > lastPrintedLine+1)
                    System.out.println("--");
                for (int i = 0;  i < before;  i ++) {
                    print(name, linenum-before+i, "-", lineBuffer[i], opts);
                    lineBuffer[i] = null;
                }
                printNameAndLine(name, linenum, ":", opts);
                System.out.print(line.substring(0, match.getBeginning(0)));
                System.out.print(EMPHASIS_START);
                System.out.print(line.substring(match.getBeginning(0), match.getEnd(0)));
                System.out.print(EMPHASIS_END);
                System.out.println(line.substring(match.getEnd(0)));
                lastPrintedLine = linenum;
            } else if (isSet(opts, O_REVERT_MATCH) && !reg.matches(line)) {
                found = true;
                matchedLine = linenum;
                if (isSet(opts, O_QUIET))  break;
                if ((before > 0 || after > 0) && linenum-before > lastPrintedLine+1)
                    System.out.println("--");
                for (int i = 0;  i < before;  i ++) {
                    print(name, linenum-before+i, "-", lineBuffer[i], opts);
                    lineBuffer[i] = null;
                }
                print(name, linenum, ":", line, opts);
                lastPrintedLine = linenum;
            } else {
                if (matchedLine >= 0 && linenum <= matchedLine+after) {
                    print(name, linenum, "-", line, opts);
                    lastPrintedLine = linenum;
                } else if (lineBuffer != null) {
                    System.arraycopy(lineBuffer, 1, lineBuffer, 0, before-1);
                    lineBuffer[before-1] = line;
                }
            }
        } // while
        if (isSet(opts, O_FILES_WITHOUT_MATCH) && !found)
            System.out.println(name);
        return found;
    }
    static void print(String name, int linenum, String sep, String line, int opts) {
        if (line == null)  return;
        printNameAndLine(name, linenum, sep, opts);
        System.out.println(line);
    }
    static void printNameAndLine(String name, int linenum, String sep, int opts) {
        if (name != null) {
            System.out.print(name);
            System.out.print(sep);
        }
        if (isSet(opts, O_LINE_NUMBER)) {
            System.out.print(linenum);
            System.out.print(sep);
        }
    }

    static void usage() {
        System.out.println("USAGE: java Grep [options] pattern filenames...");
        System.out.println("Process Type:");
        System.out.println("\t-l\t");
        System.out.println("\t-L\t");
        System.out.println("\t-v\t");
        //System.out.println("Input:");
        //System.out.println("\t-r\t");
        System.out.println("Output:");
        System.out.println("\t-A n\t");
        System.out.println("\t-B n\t");
        System.out.println("\t-C\t");
        System.out.println("\t-Cn\t");
        System.out.println("\t-h\t");
        System.out.println("\t-n\t");
        System.out.println("\t-q\t");
        System.out.println("Regular Expression:");
        System.out.println("\t-w\t");
        System.out.println("\t-x\t");
        System.out.println("\t-i\tCase-insensitive matching");
        System.out.println("\t-Xu\tUnicode shorthands");
        System.out.println("\t-Xw\tUnicode word boundary");
        System.out.println("\t-XX\tXML Schema Regular Expression");
        System.out.println("\t-X,\tCommas are separators in character classes");
        System.exit(2);
    }

    public static void main(String[] argv) throws Exception {
        //try {
        int opts = 0;
        String options = "s";   // for LS and PS
        String pattern = null;
        Vector fnames = new Vector();
        int after = 0, before = 0;
        for (int i = 0;  i < argv.length;  i ++) {
            if (argv[i].charAt(0) != '-') {
                if (pattern == null)
                    pattern = argv[i];
                else
                    fnames.addElement(argv[i]);
            } else if (argv[i].equals("-A")) {
                if (i+1 >= argv.length) {
                    System.err.println("-A requires one number.");
                    System.exit(2);
                }
                after = Integer.parseInt(argv[++i]);
                if (after <= 0) {
                    System.err.println("-A requires one number more than one.");
                    System.exit(2);
                }
            } else if (argv[i].equals("-B")) {
                if (i+1 >= argv.length) {
                    System.err.print("-B requires one number.");
                    System.exit(2);
                }
                before = Integer.parseInt(argv[++i]);
                if (before <= 0) {
                    System.err.println("-B requires one number more than one.");
                    System.exit(2);
                }
            } else if (argv[i].startsWith("-C")) {
                after = before = 2;
                if (argv[i].length() > 2) {
                    after = before = Integer.parseInt(argv[i].substring(2));
                    if (after <= 0) {
                        System.err.println("A number less than 1 is invalid for -C: "+after);
                        System.exit(2);
                    }
                }
            } else if (argv[i].equals("-b")) {
                opts |= O_BYTE_OFFSET;
            } else if (argv[i].equals("-c")) {
                opts |= O_COUNT;
            } else if (argv[i].equals("-h")) {
                opts |= O_NO_FILENAME;
            } else if (argv[i].equals("-L")) {
                opts |= O_FILES_WITHOUT_MATCH;
            } else if (argv[i].equals("-l")) {
                opts |= O_FILES_WITH_MATCHES;
            } else if (argv[i].equals("-n")) {
                opts |= O_LINE_NUMBER;
            } else if (argv[i].equals("-q")) {
                opts |= O_QUIET;
            } else if (argv[i].equals("-r")) {
                opts |= O_RECURSIVE;
            } else if (argv[i].equals("-v")) {
                opts |= O_REVERT_MATCH;
            } else if (argv[i].equals("-w")) {
                opts |= O_WORD_REGEXP;
            } else if (argv[i].equals("-x")) {
                opts |= O_LINE_REGEXP;
            } else if (argv[i].equals("-i")) {
                options += "i";
            } else if (argv[i].equals("-Xu")) {
                options += "u";
            } else if (argv[i].equals("-Xw")) {
                options += "w";
            } else if (argv[i].equals("-XX")) {
                options += "X";
            } else if (argv[i].equals("-X,")) {
                options += ",";
            } else if (argv[i].equals("--help")) {
                usage();
            } else {
                System.err.println("Unknown option: "+argv[i]);
            }
        }
        if (pattern == null)
            usage();

        boolean found = false;
        if (isSet(opts, O_LINE_REGEXP))
            pattern = "^"+pattern+"$";
        if (isSet(opts, O_WORD_REGEXP))
            pattern = "(?:^|(?<=\\W))"+pattern+"(?:$|(?>=\\W))";
        RegularExpression reg = null;
        try {
            reg = new RegularExpression(pattern, options);
        } catch (ParseException pe) {
            System.err.println("Pattern Error: "+pe.getMessage());
            System.err.println("        "+pattern);
            int loc = pe.getLocation();
            if (loc >= 0) {
                System.err.print("        ");
                for (int i = 0;  i < loc;  i ++)  System.err.print("-");
                System.err.println("^");
            }
            System.exit(2);
        }
        if (fnames.size() == 0) {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            found = grep(null, br, reg, opts, before, after);
            br.close();
        } else {
            for (int i = 0;  i < fnames.size();  i ++) {
                String fname = (String)fnames.elementAt(i);
                try {
                    BufferedReader br = new BufferedReader(new FileReader(fname));
                    if (!isSet(opts, O_FILES_WITHOUT_MATCH)
                        && !isSet(opts, O_FILES_WITH_MATCHES)
                        && (fnames.size() == 1 || isSet(opts, O_NO_FILENAME)))
                        fname = null;
                    found |= grep(fname, br, reg, opts, before, after);
                    br.close();
                } catch (IOException ioe) {
                    if (!isSet(opts, O_NO_MESSAGES))
                        System.err.println(ioe);
                }
            }
        }
        System.exit(found ? 0 : 1);
        /*} catch (Exception e) {
            e.printStackTrace();
        }*/
    }
}
