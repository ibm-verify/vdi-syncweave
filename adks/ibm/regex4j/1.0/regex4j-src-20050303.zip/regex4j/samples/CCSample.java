/* 
 * (C) Copyright IBM Corp. 2001  All rights reserved.
 *
 * US Government Users Restricted Rights Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

import com.ibm.regex.CharacterClass;
import com.ibm.regex.RegularExpression;
import java.util.Hashtable;

/**
 * @version $Id: CCSample.java,v 1.1 2001/03/22 07:39:47 kent Exp $
 * @author TAMURA Kent &lt;kent@trl.ibm.co.jp&gt;
 */
public class CCSample {
    public static void main(String[] argv) throws Exception {
        if (argv.length != 2) {
            System.err.println("CCSample <regex> <text>");
            System.err.println("You can use \\p{Metachars} in the regex.");
            System.exit(1);
        }
        CharacterClass cc = new CharacterClass(".*+?{[()|\\^$");
        Hashtable hash = new Hashtable();
        hash.put("Metachars", cc);
        RegularExpression re = new RegularExpression(null, hash, argv[0], "");
        if (re.matches(argv[1])) {
            System.err.println("Matched.");
        } else {
            System.err.println("Unmatched.");
        }
    }
}
