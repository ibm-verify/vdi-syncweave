/* 
 * (C) Copyright IBM Corp. 2000,2001  All rights reserved.
 *
 * US Government Users Restricted Rights Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

import com.ibm.regex.REUtil;
import com.ibm.regex.RegularExpression;

/**
 * @version $Id: Test.java,v 1.4 2002/05/20 07:40:48 kent Exp $
 * @author TAMURA Kent &lt;kent@trl.ibm.co.jp&gt;
 */
public class Test {
    int total = 0;
    int passed = 0;

    void test(String pattern, String options, String target, boolean expected) {
        RegularExpression re = new RegularExpression(pattern, options);
        this.total++;
        boolean actual = re.matches(target);
        if (expected == actual) {
            this.passed++;
            System.err.print(".");
        } else {
            System.err.print("*");
            System.err.print(" actual="+actual);
            System.err.print(" '"+re+"' '"+target+"' ");
        }
        System.err.flush();
    }

    void testSubst(String pattern, String source, String expected) {
        String result = REUtil.substitute(pattern, source);
        this.total++;
        if (result.equals(expected)) {
            this.passed++;
            System.err.print(".");
        } else {
            System.err.print("*");
            System.err.print(" "+result+" ");
            //System.err.println("expected-length="+expected.length()
            //+", result-length="+result.length());
        }
        System.err.flush();
    }

    void testSplit(String pattern, String source, int limit, String[] expected) {
        String[] result = REUtil.split(pattern, source, limit);
        this.total++;
        if (result.length != expected.length) {
            System.err.print("*");
            dumpResult(result);
        } else {
            int i;
            for (i = 0;  i < result.length;  i++) {
                if (!result[i].equals(expected[i]))
                    break;
            }
            if (i == result.length) {
                this.passed++;
                System.err.print(".");
            } else {
                System.err.print("*");
                dumpResult(result);
            }
        }
        System.err.flush();
    }

    void testQuote(String source, String expected) {
        this.total ++;
        String result = REUtil.quoteMeta(source);
        if (result.equals(expected)) {
            this.passed ++;
            System.err.print(".");
        } else {
            System.err.print("*("+result+")");
        }
        System.err.flush();
    }

    void testQuoteReplacement(String source, String expected) {
        this.total ++;
        String result = REUtil.quoteReplacement(source);
        if (result.equals(expected)) {
            this.passed ++;
            System.err.print(".");
        } else {
            System.err.print("*("+result+")");
        }
        System.err.flush();
    }

    static final int MIN_JAVA = 0;
    static final int MIN_UNICODE = 1;
    static final int MAX_JAVA = 2;
    static final int MAX_UNICODE = 3;
    void testLength(String pattern, int type, int expected) {
        RegularExpression re = new RegularExpression(pattern);
        int actual = -1;
        switch (type) {
          case MIN_JAVA:
            actual = re.getMinLength();
            break;
          case MIN_UNICODE:
            actual = re.getMinUnicodeLength();
            break;
          case MAX_JAVA:
            actual = re.getMaxLength();
            break;
          case MAX_UNICODE:
            actual = re.getMaxUnicodeLength();
            break;
        }
        this.total++;
        if (actual == expected) {
            this.passed++;
            System.err.print(".");
        } else {
            System.err.print("*(expected="+expected+", actual="+actual+")");
        }
        System.err.flush();
    }

    private void dumpResult(String[] array) {
        System.err.print(" ");
        for (int i = 0;  i < array.length;  i++) {
            System.err.print("'");
            System.err.print(array[i]);
            System.err.print("' ");
        }
    }

    public static void main(String[] argv) throws Exception {
        Test stat = new Test();
                     // pattern/to,  source,   expected
        stat.testSubst("s/foo/bar/", "foofoo", "barfoo");
        stat.testSubst("s/foo/bar/", "aaafoo", "aaabar");
        stat.testSubst("s/foo/bar/", "aaafoofoo", "aaabarfoo");
        stat.testSubst("s/foo/bar/g", "aaafoofoo", "aaabarbar");
        stat.testSubst("s/(\\d+) dollars/\\$\\1/g", "10 dollars", "$10");
        stat.testSubst("s/(\\d+)000 dollars/\\$${1}000/g", "20000 dollars", "$20000");
        stat.testSubst("s/ */:/g", "a  bc", ":a::b:c:");
        stat.testSubst("s/^(.*\\/)?(lib)?([^\\/]*)\\.so$/$1lib$3.a/",
                       "/usr/pkg/lib/libpng.so",
                       "/usr/pkg/lib/libpng.a");
        stat.testSubst("s/^(.*\\/)?(lib)?([^\\/]*)\\.so$/$1lib$3.a/",
                       "kernel32.so",
                       "libkernel32.a");
        stat.testSubst("s/\\G0/ /g", "000010", "    10");
        System.err.println("");

        stat.testSplit("/, */", "foo, bar, baz", -1, new String[] {"foo", "bar", "baz"});
        stat.testSplit("/, */", "foo, bar, baz", 2, new String[] {"foo", "bar, baz"});
        stat.testSplit("/ */", "a b  c   ", -1, new String[] {"a", "b", "c", ""});
        stat.testSplit("/ */", "abc", -1, new String[] {"a", "b", "c", ""});
        System.err.println("");

        stat.testQuote("aaaa", "aaaa");
        stat.testQuote("aa+a", "aa\\+a");
        stat.testQuote("*bbbb", "\\*bbbb");
        stat.testQuote("bbbb.", "bbbb\\.");
        stat.testQuote("bbbb*.", "bbbb\\*\\.");
        System.err.println("");

        stat.testQuoteReplacement("aaaa", "aaaa");
        stat.testQuoteReplacement("a\\aaa", "a\\\\aaa");
        stat.testQuoteReplacement("aaa$1a", "aaa\\$1a");
        stat.testQuoteReplacement("aaab$", "aaab\\$");
        System.err.println("");

        stat.testLength("....", MIN_JAVA, 4);
        stat.testLength("....", MIN_UNICODE, 4);
        stat.testLength("....", MAX_JAVA, 8);
        stat.testLength("....", MAX_UNICODE, 4);
        stat.testLength("\ud800\udc00", MIN_JAVA, 2);
        stat.testLength("\ud800\udc00", MIN_UNICODE, 1);
        stat.testLength("\ud800\udc00", MAX_JAVA, 2);
        stat.testLength("\ud800\udc00", MAX_UNICODE, 1);
        System.err.println("");

        stat.test("a\ud800\udc00", "", "a\ud800\udc00", true);
        stat.test("^a\ud800\udc00+$", "", "a\ud800\udc00\udc00", false);
        stat.test("^a\ud800\udc00+$", "", "a\ud800\udc00\ud800\udc00", true);
        stat.test("a.\ud800\udc00", "", "a\ud800\udc00\ud800\udc00", true);
        stat.test("foo(?=bar)", "", "foobar", true);
        stat.test("foo(?=bar)", "", "foobab", false);
        stat.test("foo(?!bar)", "", "foobar", false);
        stat.test("foo(?!bar)", "", "foobab", true);
        stat.test("(?<=bar)foo", "", "barfoo", true);
        stat.test("(?<=bar)foo", "", "babfoo", false);
        stat.test("(?<!bar)foo", "", "barfoo", false);
        stat.test("(?<!bar)foo", "", "babfoo", true);

        stat.test("\\d{1,4}\\.\\d{2}", "", "12345.99", true);
        stat.test("\\d{1,4}\\.\\d{2}", "X", "12345.99", false);
        stat.test("\\p{Pi}", "", "\u00ab", true); // U+00AB LEFT-POINTING DOUBLE ANGLE QUOTATION MARK
        stat.test("\\p{Pf}", "", "\u00bb", true); // U+00BB RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK

        stat.test("(abc)?(?(1)def|ghi)", "", "abcdef", true);
        stat.test("(abc)?(?(1)def|ghi)", "", "cccdef", false);
        stat.test("^(abc)?(?(1)def|ghi)", "", "abcghi", false);
        stat.test("(?(?<=abc)def|ghi)", "", "abcdef", true);
        stat.test("(?(?<=abc)def|ghi)", "", "cccdef", false);
        stat.test("(?(?<=abc)def|ghi)", "", "ghi", true);
        stat.test("(?(^)def|ghi)", "", "def", true);
        stat.test("(?(^)def|ghi)", "", "abcdef", false);
        stat.test("(?(^)def|ghi)", "", "abcghi", true);

	String optionalEraRegex="(?:BC|AD)?";
	String centuryRegex="\\d{2,}";
	String yearRegex="\\d{2}";
	String monthRegex="(?:(?:0[1-9])|(?:1[0-2]))"; 
	String dayRegex="(?:(?:0[1-9])|(?:[1-2][0-9])|(?:3[0-1]))";   
	String hourRegex="(?:(?:[0-1][0-9])|(?:2[0-3]))";
	String minRegex="(?:[0-5][0-9])"; 
	String secWithoutMillisRegex="(?:[0-5][0-9])";
	String secWithMillisRegex=secWithoutMillisRegex+"\\.\\d+";
	String optionalTimeZoneRegex="(?:Z|(?:[-+]"+hourRegex+"(?::"
            +minRegex+"(?::"+secWithoutMillisRegex+"(?:\\.\\d+)?)?)?)?)?";
	stat.test("^"+optionalEraRegex+centuryRegex+yearRegex+optionalTimeZoneRegex+"$", "", "0002", true);
	String NAMETEST = "(\\i\\c*:)?((\\i\\c*)|\\*)";
	String STEP = "(child::)?"+NAMETEST+"|\\.";
	String ATTRIBUTE_STEP = "(attribute::|@)"+NAMETEST;
	String PATH = "(\\.//)?(("+STEP+")/)*("+STEP+"|"+ATTRIBUTE_STEP+")";
	String XPATH_REGEX_STR= PATH+"(\\|"+PATH+")*";
        stat.test(XPATH_REGEX_STR, "X", "@ab:cd", true);
	stat.test("a?|@", "X", "@", true);
        System.err.println("");

        System.err.println("Passed/total: "+stat.passed+"/"+stat.total);
    }
}
