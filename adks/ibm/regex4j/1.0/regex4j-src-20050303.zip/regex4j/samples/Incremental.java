/*
 * (C) Copyright IBM Corp. 2001  All rights reserved.
 *
 * US Government Users Restricted Rights Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

import com.ibm.regex.Match;
import com.ibm.regex.RegularExpression;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

/**
 * A sample for Regex for Java.
 * This requires Swing.
 *
 * @version $Id: Incremental.java,v 1.2 2001/06/13 08:30:44 kent Exp $
 * @author TAMURA Kent &lt;kent@trl.ibm.co.jp&gt;
 */
public class Incremental {

    public static void main(String[] argv) {
        if (argv.length != 1) {
            System.err.println("Incremental <pattern>");
            System.exit(1);
        }
        String pattern = argv[0];
        if (pattern.charAt(0) != '^')
            pattern = "^"+pattern;
        if (pattern.charAt(pattern.length()-1) != '$')
            pattern = pattern+"$";
        RegularExpression regex = new RegularExpression(pattern, "P");

        JFrame frame = new JFrame("Incremental Match");
        frame.getContentPane().setLayout(new GridLayout(2, 1));

        JLabel patternField = new JLabel("The pattern is '"+regex.getPattern()+"'."
                                         +"  Type matching text or non-matching text"
                                         +" into the box below.");
        frame.getContentPane().add(patternField);

        frame.getContentPane().add(new MatchingTextPane(regex));

        frame.setSize(512, 120);
        frame.setLocation(new Point(0, 0));
        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        frame.show();
    }


    static class MatchingTextPane extends JTextPane implements DocumentListener {
        Match match;
        RegularExpression pattern;
        StyledDocument document = null;
        Runnable normal;
        Runnable matched;
        Runnable invalid;

        MatchingTextPane(RegularExpression regex) {
            super();
            this.pattern = regex;
            this.match = new Match();
            this.normal = new NormalStylist();
            this.matched = new MatchedStylist();
            this.invalid = new InvalidStylist();

            this.setFont(new Font("Monospaced", Font.PLAIN, 20));
            this.getStyledDocument().addDocumentListener(this);
        }

        protected void check(Document doc) {
            this.document = (StyledDocument)doc;
            try {
                String text = doc.getText(0, doc.getLength());
                if (this.pattern.matches(text, this.match)) {
                    SwingUtilities.invokeLater(this.normal);
                    SwingUtilities.invokeLater(this.matched);
                } else {
                    SwingUtilities.invokeLater(this.normal);
                    if (this.match.getEnd(0) >= 0
                        && this.match.getEnd(0) < this.document.getLength()) {
                        SwingUtilities.invokeLater(this.invalid);
                    }
                }
            } catch (BadLocationException ex) {
                ex.printStackTrace();
            }
        }

                                // DocumentListener
        public void changedUpdate(DocumentEvent e) {
            //System.err.println("changedUpdate(): "+e);
        }
                                // DocumentListener
        public void insertUpdate(DocumentEvent e) {
            //System.err.println("insertUpdate(): "+e);
            this.check(e.getDocument());
        }
                                // DocumentListener
        public void removeUpdate(DocumentEvent e) {
            //System.err.println("removeUpdate(): "+e);
            this.check(e.getDocument());
        }

        class NormalStylist implements Runnable {
            SimpleAttributeSet style;
            NormalStylist() {
                this.style = new SimpleAttributeSet();
            }
            public void run() {
                document.setCharacterAttributes(0, document.getLength(),
                                                this.style, true);
            }
        }

        class MatchedStylist implements Runnable {
            SimpleAttributeSet style;
            MatchedStylist() {
                this.style = new SimpleAttributeSet();
                StyleConstants.setForeground(this.style, Color.blue);
                StyleConstants.setBold(this.style, true);
            }
            public void run() {
                document.setCharacterAttributes(match.getBeginning(0),
                                                match.getEnd(0)-match.getBeginning(0),
                                                this.style, true);
            }
        }

        class InvalidStylist implements Runnable {
            SimpleAttributeSet style;
            InvalidStylist() {
                this.style = new SimpleAttributeSet();
                StyleConstants.setForeground(this.style, Color.red);
                StyleConstants.setBold(this.style, true);
            }
            public void run() {
                int end = match.getEnd(0);
                int len = document.getLength() - end;
                document.setCharacterAttributes(end, len, this.style, true);
            }
        }
    }
}
