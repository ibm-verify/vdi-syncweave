/* 
 * (C) Copyright IBM Corp. 2001  All rights reserved.
 *
 * US Government Users Restricted Rights Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

package com.ibm.regex;

/**
 *
 * @version $Id: Version.java,v 1.3 2001/12/10 08:26:04 kent Exp $
 * @author TAMURA Kent &lt;kent@trl.ibm.co.jp&gt;
 */
public class Version {
    private Version() {
    }

    /**
     * "1.0.2"
     */
    public static final String VERSION_STRING = "1.0.2";

    /**
     * 1
     */
    public static final int MAJOR_VERSION = 1;
    /**
     * 0
     */
    public static final int MINOR_VERSION = 0;
    /**
     * 2
     */
    public static final int FIX_LEVEL = 2;
    /**
     * 0x20011210.
     */
    public static final int RELEASE_DATE = 0x20011210;

    /**
     * Prints <code>VERSION_STRING\n</code>.
     */
    public static void main(String[] argv) {
        System.out.println(VERSION_STRING);
    }
}
