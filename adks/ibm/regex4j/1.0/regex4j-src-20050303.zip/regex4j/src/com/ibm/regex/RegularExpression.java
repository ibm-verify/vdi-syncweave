/* -*- java -*-
 *
 * (C) Copyright IBM Corp. 1998,1999,2000,2001  All rights reserved.
 *
 * US Government Users Restricted Rights Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

package com.ibm.regex;

import java.text.CharacterIterator;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;

/**
 * A regular expression matching engine using Non-deterministic Finite Automaton (NFA).
 * This engine does not conform to the POSIX regular expression.
 *
 * <hr width="50%">
 * <h3>How to use</h3>
 *
 * <dl>
 *   <dt>A. Standard way
 *   <dd>
 * <pre>
 * RegularExpression re = new RegularExpression(<var>regex</var>);
 * if (re.matches(text)) { ... }
 * </pre>
 *
 *   <dt>B. Capturing groups
 *   <dd>
 * <pre>
 * RegularExpression re = new RegularExpression(<var>regex</var>);
 * Match match = new Match();
 * if (re.matches(text, match)) {
 *     ... // You can refer captured texts with methods of the <code>Match</code> class.
 * }
 * </pre>
 *
 * </dl>
 *
 * <h4>Case-insensitive matching</h4>
 * <pre>
 * RegularExpression re = new RegularExpression(<var>regex</var>, "i");
 * if (re.matches(text)) { ...}
 * </pre>
 *
 * <h4><a name="OPTIONS">Options</a></h4>
 *    This <var>options</var> parameter consists of the following characters.
 * </p>
 * <dl>
 *   <dt><a name="I_OPTION"><code>"i"</code></a>
 *   <dd>This option indicates case-insensitive matching.
 *   <dt><a name="M_OPTION"><code>"m"</code></a>
 *   <dd class="REGEX"><kbd>^</kbd> and <kbd>$</kbd> consider the EOL characters within the text.
 *   <dt><a name="S_OPTION"><code>"s"</code></a>
 *   <dd class="REGEX"><kbd>.</kbd> matches any one character.
 *   <dt><a name="U_OPTION"><code>"u"</code></a>
 *   <dd class="REGEX">Redefines <Kbd>\d \D \w \W \s \S \b \B \&lt; \></kbd> as becoming to Unicode.
 *   <dt><a name="W_OPTION"><code>"w"</code></a>
 *   <dd class="REGEX">By this option, <kbd>\b \B \&lt; \></kbd> are processed with the method of
 *      'Unicode Regular Expression Guidelines' Revision 4.
 *      When "w" and "u" are specified at the same time,
 *      <kbd>\b \B \&lt; \></kbd> are processed for the "w" option.
 *   <dt><a name="COMMA_OPTION"><code>","</code></a>
 *   <dd>The parser treats a comma in a character class as a range separator.
 *      <kbd class="REGEX">[a,b]</kbd> matches <kbd>a</kbd> or <kbd>,</kbd> or <kbd>b</kbd> without this option.
 *      <kbd class="REGEX">[a,b]</kbd> matches <kbd>a</kbd> or <kbd>b</kbd> with this option.
 *
 *   <dt><a name="X_OPTION"><code>"X"</code></a>
 *   <dd class="REGEX">
 *       The <code>match()</code> method does not do subsring matching
 *       but entire string matching.
 *
 *   <dt><a name="P_OPTION"><code>"P"</code></a>
 *   <dd class="REGEX">
 *       By this option, even if the matching fails,
 *       <code>getBeginning(0)</code> and <code>getEnd(0)</code> of
 *       a <code>Match</code> class return a matched region as possible.
 *       This option disables some optimizations.
 *       <p>For example, a pattern is <code>"foobar"</code> and target text is
 *       "foobaz".  In this case, of course, the matching fails.
 *       But if the <code>"P"</code> option is specified, <code>Match</code>
 *       instance returns <code>"fooba"</code> as 0th region.
 *       <p>This feature is experimental.
 *	 
 *
 * </dl>
 * 
 * <hr width="50%">
 * <h3>Syntax</h3>
 *   <tr>
 *    <td>
 *     <h4>Differences from the Perl 5 regular expression</h4>
 *     <ul>
 *      <li>There is 6-digit hexadecimal character representation  (<kbd>\u005cv</kbd><var>HHHHHH</var>.)
 *      <li>Supports subtraction, union, and intersection operations for character classes.
 *      <li>Not supported: <kbd>\</kbd><var>ooo</var> (Octal character representations),
 *          <kbd>\C</kbd>, <kbd>\l</kbd><var>c</var>,
 *          <kbd>\u005cu</kbd><var>c</var>, <kbd>\L</kbd>, <kbd>\U</kbd>,
 *          <kbd>\E</kbd>, <kbd>\Q</kbd>, <kbd>\N{</kbd><var>name</var><kbd>}</kbd>,
 *          <Kbd>(?{<kbd><var>code</var><kbd>})</kbd>, <Kbd>(??{<kbd><var>code</var><kbd>})</kbd>
 *     </ul>
 *    </td>
 *   </tr>
 * </table>
 *
 * <P>Meta characters are `<KBD>. * + ? { [ ( ) | \ ^ $</KBD>'.</P>
 * <ul>
 *   <li>Character
 *     <dl>
 *       <dt class="REGEX"><kbd>.</kbd> (A period)
 *       <dd>Matches any one character except the following characters.
 *       <dd>LINE FEED (U+000A), CARRIAGE RETURN (U+000D),
 *           PARAGRAPH SEPARATOR (U+2029), LINE SEPARATOR (U+2028)
 *       <dd>This expression matches one code point in Unicode. It can match a pair of surrogates.
 *           it matches any character including the above four characters.
 *
 *       <dt class="REGEX"><Kbd>\e \f \n \r \t</kbd>
 *       <dd>Matches ESCAPE (U+001B), FORM FEED (U+000C), LINE FEED (U+000A),
 *           CARRIAGE RETURN (U+000D), HORIZONTAL TABULATION (U+0009)
 *
 *       <dt class="REGEX"><kbd>\c</kbd><var>C</var>
 *       <dd>Matches a control character.
 *           The <var>C</var> must be one of '<kbd>@</kbd>', '<kbd>A</kbd>'-'<kbd>Z</kbd>',
 *           '<kbd>[</kbd>', '<kbd>\u005c</kbd>', '<kbd>]</kbd>', '<kbd>^</kbd>', '<kbd>_</kbd>'.
 *           It matches a control character of which the character code is less than
 *           the character code of the <var>C</var> by 0x0040.
 *       <dd class="REGEX">For example, a <kbd>\cJ</kbd> matches a LINE FEED (U+000A),
 *           and a <kbd>\c[</kbd> matches an ESCAPE (U+001B).
 *
 *       <dt class="REGEX">a non-meta character
 *       <dd>Matches the character.
 *
 *       <dt class="REGEX"><KBD>\</KBD> + a meta character
 *       <dd>Matches the meta character.
 *
 *       <dt class="REGEX"><kbd>\u005cx</kbd><var>HH</var> <kbd>\u005cx{</kbd><var>HHHH</var><kbd>}</kbd>
 *       <dd>Matches a character of which code point is <var>HH</var> (Hexadecimal) in Unicode.
 *           You can write just 2 digits for <kbd>\u005cx</kbd><var>HH</var>, and
 *           variable length digits for <kbd>\u005cx{</kbd><var>HHHH</var><kbd>}</kbd>.
 *
 *       <!--
 *       <dt class="REGEX"><kbd>\u005cu</kbd><var>HHHH</var>
 *       <dd>Matches a character of which code point is <var>HHHH</var> (Hexadecimal) in Unicode.
 *       -->
 *
 *       <dt class="REGEX"><kbd>\u005cv</kbd><var>HHHHHH</var>
 *       <dd>Matches a character of which code point is <var>HHHHHH</var> (Hexadecimal) in Unicode.
 *
 *       <dt class="REGEX"><kbd>\g</kbd>
 *       <dd>Matches a grapheme.
 *       <dd class="REGEX">It is equivalent to <kbd>(?[\p{ASSIGNED}]-[\p{M}\p{C}])?(?:\p{M}|[\x{094D}\x{09CD}\x{0A4D}\x{0ACD}\x{0B3D}\x{0BCD}\x{0C4D}\x{0CCD}\x{0D4D}\x{0E3A}\x{0F84}]\p{L}|[\x{1160}-\x{11A7}]|[\x{11A8}-\x{11FF}]|[\x{FF9E}\x{FF9F}])*</kbd>
 *
 *       <dt class="REGEX"><kbd>\X</kbd>
 *       <dd class="REGEX">Matches a combining character sequence.
 *       It is equivalent to <kbd>(?:\PM\pM*)</kbd>
 *     </dl>
 *   </li>
 *
 *   <li>Character class
 *     <dl>
 *       <dd>Positive character class.  It matches a character in ranges.
 *       <dd><var>R<sub>n</sub></var>:
 *       <ul>
 *         <li class="REGEX">A character (including <Kbd>\e \f \n \r \t</kbd> <kbd>\u005cx</kbd><var>HH</var> <kbd>\u005cx{</kbd><var>HHHH</var><kbd>}</kbd> <!--kbd>\u005cu</kbd><var>HHHH</var--> <kbd>\u005cv</kbd><var>HHHHHH</var>)
 *             <p>This range matches the character.
 *         <li class="REGEX"><var>C<sub>1</sub></var><kbd>-</kbd><var>C<sub>2</sub></var>
 *             <p>This range matches a character which has a code point that is >= <var>C<sub>1</sub></var>'s code point and &lt;= <var>C<sub>2</sub></var>'s code point.
 *         <li class="REGEX">A POSIX character class: <Kbd>[:alpha:] [:alnum:] [:ascii:] [:cntrl:] [:digit:] [:graph:] [:lower:] [:print:] [:punct:] [:space:] [:upper:] [:xdigit:]</kbd>,
 *             and negative POSIX character classes in Perl like <kbd>[:^alpha:]</kbd>
 *             <p>...
 *         <li class="REGEX"><kbd>\d \D \s \S \w \W \p{</kbd><var>name</var><kbd>} \P{</kbd><var>name</var><kbd>}</kbd>
 *             <p>These expressions specifies the same ranges as the following expressions.
 *       </ul>
 *       <p class="REGEX">Enumerated ranges are merged (union operation).
 *          <kbd>[a-ec-z]</kbd> is equivalent to <kbd>[a-z]</kbd>
 *
 *       <dd>Negative character class.  It matches a character not in ranges.
 *
 *       <dt class="REGEX"><kbd>(?[</kbd><var>ranges</var><kbd>]</kbd><var>op</var><kbd>[</kbd><var>ranges</var><kbd>]</kbd><var>op</var><kbd>[</kbd><var>ranges</var><kbd>]</kbd> ... <Kbd>)</kbd>
 *       (<var>op</var> is <kbd>-</kbd> or <kbd>+</kbd> or <kbd>&</kbd>.)
 *       <!--dd class="WARNING">This feature is highly experimental.</dd-->
 *       <dd>Subtraction or union or intersection for character classes.
 *       <dd class="REGEX">For exmaple, <kbd>(?[A-Z]-[CF])</kbd> is equivalent to <kbd>[A-BD-EG-Z]</kbd>, and <kbd>(?[\x00-\x7f]-[K]&[\p{Lu}])</kbd> is equivalent to <kbd>[A-JL-Z]</kbd>.
 *       <dd>The result of this operations is a <u>positive character class</u>
 *           even if an expression includes any negative character classes.
 *           You have to take care on this in case-insensitive matching.
 *           For instance, <kbd>(?[^b])</kbd> is equivalent to <kbd>[\x00-ac-\x{10ffff}]</kbd>,
 *           which is equivalent to <kbd>[^b]</kbd> in case-sensitive matching.
 *           But, in case-insensitive matching, <kbd>(?[^b])</kbd> matches any character because
 *           it includes '<kbd>B</kbd>' and '<kbd>B</kbd>' matches '<kbd>b</kbd>'
 *           though <kbd>[^b]</kbd> is processed as <kbd>[^Bb]</kbd>.
 *
 *       <dd>Character class subtraction for the XML Schema.
 *           
 *
 *       <dt class="REGEX"><kbd>\d</kbd>
 *       <dd class="REGEX">Equivalent to <kbd>[0-9]</kbd>.
 *           <span class="REGEX"><kbd>\p{Nd}</kbd></span>.
 *
 *       <dt class="REGEX"><kbd>\D</kbd>
 *       <dd class="REGEX">Equivalent to <kbd>[^0-9]</kbd>
 *           <span class="REGEX"><kbd>\P{Nd}</kbd></span>.
 *
 *       <dt class="REGEX"><kbd>\s</kbd>
 *       <dd class="REGEX">Equivalent to <kbd>[ \f\n\r\t]</kbd>
 *           <span class="REGEX"><kbd>[ \f\n\r\t\p{Z}]</kbd></span>.
 *
 *       <dt class="REGEX"><kbd>\S</kbd>
 *       <dd class="REGEX">Equivalent to <kbd>[^ \f\n\r\t]</kbd>
 *           <span class="REGEX"><kbd>[^ \f\n\r\t\p{Z}]</kbd></span>.
 *
 *       <dt class="REGEX"><kbd>\w</kbd>
 *       <dd class="REGEX">Equivalent to <kbd>[a-zA-Z0-9_]</kbd>
 *           <span class="REGEX"><kbd>[\p{Lu}\p{Ll}\p{Lo}\p{Nd}_]</kbd></span>.
 *
 *       <dt class="REGEX"><kbd>\W</kbd>
 *       <dd class="REGEX">Equivalent to <kbd>[^a-zA-Z0-9_]</kbd>
 *           <span class="REGEX"><kbd>[^\p{Lu}\p{Ll}\p{Lo}\p{Nd}_]</kbd></span>.
 *
 *       <dt class="REGEX"><kbd>\p{</kbd><var>name</var><kbd>}</kbd>
 *       <dd>Matches one character in the specified General Category (the second field in <a href="ftp://ftp.unicode.org/Public/UNIDATA/UnicodeData.txt"><kbd>UnicodeData.txt</kbd></a>) or the specified <a href="ftp://ftp.unicode.org/Public/UNIDATA/Blocks.txt">Block</a>.
 *       The following names are available:
 *       <dl>
 *         <dt>Unicode General Categories:
 *         <dd><kbd>
 *       L, M, N, Z, C, P, S, Lu, Ll, Lt, Lm, Lo, Mn, Me, Mc, Nd, Nl, No, Zs, Zl, Zp,
 *       Cc, Cf, Cn, Co, Cs, Pd, Ps, Pe, Pc, Po, Pf, Pi, Sm, Sc, Sk, So,
 *         </kbd>
 *         <table border="1">
 *           <tr><td>
 *             <p>Note: Category information is created with the
 *               <code>java.lang.Character</code> class.  The latest Java2,
 *               v1.3.0 at this moment, does not support Pf and Pi categories and
 *               Pf/Pi characters defined in Unicode 3.0.1 belong to other categories
 *               in the latest Java2.
 *               Character data for Pf/Pi are hard-coded in this package.
 *               So a character in Pf/Pi may belong to two categories.</p>
 *             <p>Note: Currently the Cn category includes U+10000-U+10FFFF characters.</p>
 *           </td></tr>
 *         </table>
 *         <dt>Unicode Blocks:
 *         <dd><kbd>
 *       Basic Latin, Latin-1 Supplement, Latin Extended-A, Latin Extended-B,
 *       IPA Extensions, Spacing Modifier Letters, Combining Diacritical Marks, Greek,
 *       Cyrillic, Armenian, Hebrew, Arabic, Devanagari, Bengali, Gurmukhi, Gujarati,
 *       Oriya, Tamil, Telugu, Kannada, Malayalam, Thai, Lao, Tibetan, Georgian,
 *       Hangul Jamo, Latin Extended Additional, Greek Extended, General Punctuation,
 *       Superscripts and Subscripts, Currency Symbols, Combining Marks for Symbols,
 *       Letterlike Symbols, Number Forms, Arrows, Mathematical Operators,
 *       Miscellaneous Technical, Control Pictures, Optical Character Recognition,
 *       Enclosed Alphanumerics, Box Drawing, Block Elements, Geometric Shapes,
 *       Miscellaneous Symbols, Dingbats, CJK Symbols and Punctuation, Hiragana,
 *       Katakana, Bopomofo, Hangul Compatibility Jamo, Kanbun,
 *       Enclosed CJK Letters and Months, CJK Compatibility, CJK Unified Ideographs,
 *       Hangul Syllables, High Surrogates, High Private Use Surrogates, Low Surrogates,
 *       Private Use, CJK Compatibility Ideographs, Alphabetic Presentation Forms,
 *       Arabic Presentation Forms-A, Combining Half Marks, CJK Compatibility Forms,
 *       Small Form Variants, Arabic Presentation Forms-B, Specials,
 *       Halfwidth and Fullwidth Forms
 *         </kbd>
 *         <dd><p>(You may write space-omitted names such as <kbd>BasicLatin</kbd>
 *                 instead of <kbd>Basic Latin</kbd>.)</p></dd>
 *         <dt>Others:
 *         <dd><kbd>ALL</kbd> (Equivalent to <kbd>[\x00-\u005cv10FFFF]</kbd>)
 *         <dd><kbd>ASSGINED</kbd> (<kbd>\p{ASSIGNED}</kbd> is equivalent to <kbd>\P{Cn}</kbd>)
 *         <dd><kbd>UNASSGINED</kbd>
 *             (<kbd>\p{UNASSIGNED}</kbd> is equivalent to <kbd>\p{Cn}</kbd>)
 *       </dl>
 *
 *       <dt class="REGEX"><kbd>\P{</kbd><var>name</var><kbd>}</kbd>
 *       <dd>Matches one character not in the specified General Category or the specified Block.
 *     </dl>
 *   </li>
 *
 *   <li>Selection and Quantifier
 *     <dl>
 *       <dt class="REGEX"><VAR>X</VAR><kbd>|</kbd><VAR>Y</VAR>
 *       <dd>...
 *
 *       <dt class="REGEX"><VAR>X</VAR><kbd>*</KBD>
 *       <dd>Matches 0 or more <var>X</var>.
 *
 *       <dt class="REGEX"><VAR>X</VAR><kbd>+</KBD>
 *       <dd>Matches 1 or more <var>X</var>.
 *
 *       <dt class="REGEX"><VAR>X</VAR><kbd>?</KBD>
 *       <dd>Matches 0 or 1 <var>X</var>.
 *
 *       <dt class="REGEX"><var>X</var><kbd>{</kbd><var>number</var><kbd>}</kbd>
 *       <dd>Matches <var>number</var> times.
 *
 *       <dt class="REGEX"><var>X</var><kbd>{</kbd><var>min</var><kbd>,}</kbd>
 *       <dd>...
 *
 *       <dt class="REGEX"><var>X</var><kbd>{</kbd><var>min</var><kbd>,</kbd><var>max</var><kbd>}</kbd>
 *       <dd>...
 *
 *       <dt class="REGEX"><VAR>X</VAR><kbd>*?</kbd>
 *       <dt class="REGEX"><VAR>X</VAR><kbd>+?</kbd>
 *       <dt class="REGEX"><VAR>X</VAR><kbd>??</kbd>
 *       <dt class="REGEX"><var>X</var><kbd>{</kbd><var>min</var><kbd>,}?</kbd>
 *       <dt class="REGEX"><var>X</var><kbd>{</kbd><var>min</var><kbd>,</kbd><var>max</var><kbd>}?</kbd>
 *       <dd>Non-greedy matching.
 *     </dl>
 *   </li>
 *
 *   <li>Grouping, Capturing, and Back-reference
 *     <dl>
 *       <dt class="REGEX"><KBD>(?:</kbd><VAR>X</VAR><kbd>)</KBD>
 *       <dd>Grouping. "<KBD>foo+</KBD>" matches "<KBD>foo</KBD>" or "<KBD>foooo</KBD>".
 *       If you want it matches "<KBD>foofoo</KBD>" or "<KBD>foofoofoo</KBD>",
 *       you have to write "<KBD>(?:foo)+</KBD>".
 *
 *       <dt class="REGEX"><KBD>(</kbd><VAR>X</VAR><kbd>)</KBD>
 *       <dd>Grouping with capturing.
 * It make a group and applications can know
 * where in target text a group matched with methods of a <code>Match</code> instance
 * The 0th group means whole of this regular expression.
 * The <VAR>N</VAR>th gorup is the inside of the <VAR>N</VAR>th left parenthesis.
 * 
 *   <p>For instance, a regular expression is
 *   "<FONT color=blue><KBD> *([^&lt;:]*) +&lt;([^&gt;]*)&gt; *</KBD></FONT>"
 *   and target text is
 *   "<FONT color=red><KBD>From: TAMURA Kent &lt;kent@trl.ibm.co.jp&gt;</KBD></FONT>":
 *   <ul>
 *     <li><code>Match.getCapturedText(0)</code>:
 *     "<FONT color=red><KBD> TAMURA Kent &lt;kent@trl.ibm.co.jp&gt;</KBD></FONT>"
 *     <li><code>Match.getCapturedText(1)</code>: "<FONT color=red><KBD>TAMURA Kent</KBD></FONT>"
 *     <li><code>Match.getCapturedText(2)</code>: "<FONT color=red><KBD>kent@trl.ibm.co.jp</KBD></FONT>"
 *   </ul>
 *
 *       <dt class="REGEX"><kbd>\1 \2 \3 \4 \5 \6 \7 \8 \9</kbd>
 *       <dd>
 *
 *       <dt class="REGEX"><kbd>(?></kbd><var>X</var><kbd>)</kbd>
 *       <dd>Independent expression group. ................
 *
 *       <dt class="REGEX"><kbd>(?</kbd><var>options</var><kbd>:</kbd><var>X</var><kbd>)</kbd>
 *       <dt class="REGEX"><kbd>(?</kbd><var>options</var><kbd>-</kbd><var>options2</var><kbd>:</kbd><var>X</var><kbd>)</kbd>
 *       <dd>............................
 *       <dd>The <var>options</var> or the <var>options2</var> consists of 'i' 'm' 's' 'w'.
 *           Note that it can not contain 'u'.
 *
 *       <dt class="REGEX"><kbd>(?</kbd><var>options</var><kbd>)</kbd>
 *       <dt class="REGEX"><kbd>(?</kbd><var>options</var><kbd>-</kbd><var>options2</var><kbd>)</kbd>
 *       <dd>......
 *       <dd>These expressions must be at the beginning of a group.
 *     </dl>
 *   </li>
 *
 *   <li>Anchor
 *     <dl>
 *       <dt class="REGEX"><kbd>\A</kbd>
 *       <dd>Matches the beginnig of the text.
 *
 *       <dt class="REGEX"><kbd>\G</kbd>
 *       <dd>Matches the beginnig of the text.
 *
 *       <dt class="REGEX"><kbd>\Z</kbd>
 *       <dd>Matches the end of the text, or before an EOL character at the end of the text,
 *           or CARRIAGE RETURN + LINE FEED at the end of the text.
 *
 *       <dt class="REGEX"><kbd>\z</kbd>
 *       <dd>Matches the end of the text.
 *
 *       <dt class="REGEX"><kbd>^</kbd>
 *       <dd>Matches the beginning of the text.  It is equivalent to <span class="REGEX"><Kbd>\A</kbd></span>.
 *           it matches the beginning of the text, or after one of EOL characters (
 *           LINE FEED (U+000A), CARRIAGE RETURN (U+000D), LINE SEPARATOR (U+2028),
 *           PARAGRAPH SEPARATOR (U+2029).)
 *
 *       <dt class="REGEX"><kbd>$</kbd>
 *       <dd>Matches the end of the text, or before an EOL character at the end of the text,
 *           or CARRIAGE RETURN + LINE FEED at the end of the text.
 *           it matches the end of the text, or before an EOL character.
 *
 *       <dt class="REGEX"><kbd>\b</kbd>
 *       <dd>Matches word boundary.
 *
 *       <dt class="REGEX"><kbd>\B</kbd>
 *       <dd>Matches non word boundary.
 *
 *       <dt class="REGEX"><kbd>\&lt;</kbd>
 *       <dd>Matches the beginning of a word.
 *
 *       <dt class="REGEX"><kbd>\&gt;</kbd>
 *       <dd>Matches the end of a word.
 *     </dl>
 *   </li>
 *   <li>Lookahead and lookbehind
 *     <dl>
 *       <dt class="REGEX"><kbd>(?=</kbd><var>X</var><kbd>)</kbd>
 *       <dd>Lookahead.
 *
 *       <dt class="REGEX"><kbd>(?!</kbd><var>X</var><kbd>)</kbd>
 *       <dd>Negative lookahead.
 *
 *       <dt class="REGEX"><kbd>(?&lt;=</kbd><var>X</var><kbd>)</kbd>
 *       <dd>Lookbehind.
 *           Unlike Perl5, there is no limitation of patterns used in the lookbehind.
 *       <dd>(Note for text capturing order......)
 *
 *       <dt class="REGEX"><kbd>(?&lt;!</kbd><var>X</var><kbd>)</kbd>
 *       <dd>Negative lookbehind.
 *     </dl>
 *   </li>
 *
 *   <li>Misc.
 *     <dl>
 *       <dt class="REGEX"><kbd>(?(</Kbd><var>condition</var><Kbd>)</kbd><var>yes-pattern</var><kbd>|</kbd><var>no-pattern</var><kbd>)</kbd>,
 *       <dt class="REGEX"><kbd>(?(</kbd><var>condition</var><kbd>)</kbd><var>yes-pattern</var><kbd>)</kbd>
 *       <dd>......
 *       <dd>Comment.  A comment string consists of characters except '<kbd>)</kbd>'.
 *           You can not write comments in character classes and before quantifiers.
 *     </dl>
 *   </li>
 * </ul>
 *
 *
 * <hr width="50%">
 * <h3>BNF for the regular expression</h3>
 * <p>The following is BNF expression of the regular expression.
 * The syntax is different in XML Schema mode.</p>
 * <pre>
 * regex ::= ('(?' options ')')? term ('|' term)*
 * term ::= factor+
 * factor ::= anchors | atom (('*' | '+' | '?' | minmax ) '?'? )?
 * minmax ::= '{' ([0-9]+ | [0-9]+ ',' | ',' [0-9]+ | [0-9]+ ',' [0-9]+) '}'
 * atom ::= char | '.' | char-class | '(' regex ')' | '(?:' regex ')' | '\' [0-9]
 *          | '\w' | '\W' | '\d' | '\D' | '\s' | '\S' | category-block | '\X'
 *          | '(?>' regex ')' | '(?' options ':' regex ')'
 *          | '(?' ('(' [0-9] ')' | '(' anchors ')' | looks) term ('|' term)? ')'
 * options ::= [imsw]* ('-' [imsw]+)?
 * anchors ::= '^' | '$' | '\A' | '\G' | '\Z' | '\z' | '\b' | '\B' | '\&lt;' | '\>'
 * looks ::= '(?=' regex ')'  | '(?!' regex ')'
 *           | '(?&lt;=' regex ')' | '(?&lt;!' regex ')'
 * char ::= '\\' | '\' [efnrtv] | '\c' [@-_] | code-point | character-1
 * category-block ::= '\' [pP] category-symbol-1
 *                    | ('\p{' | '\P{') (category-symbol | block-name
 *                                       | other-properties) '}'
 * category-symbol-1 ::= 'L' | 'M' | 'N' | 'Z' | 'C' | 'P' | 'S'
 * category-symbol ::= category-symbol-1 | 'Lu' | 'Ll' | 'Lt' | 'Lm' | Lo'
 *                     | 'Mn' | 'Me' | 'Mc' | 'Nd' | 'Nl' | 'No'
 *                     | 'Zs' | 'Zl' | 'Zp' | 'Cc' | 'Cf' | 'Cn' | 'Co' | 'Cs'
 *                     | 'Pd' | 'Ps' | 'Pe' | 'Pc' | 'Po' | 'Pi' | 'Pf'
 *                     | 'Sm' | 'Sc' | 'Sk' | 'So'
 * block-name ::= (See above)
 * other-properties ::= 'ALL' | 'ASSIGNED' | 'UNASSIGNED'
 * character-1 ::= (any character except meta-characters)
 *
 * char-class ::= '[' ranges ']'
 *                | '(?[' ranges ']' ([-+&] '[' ranges ']')? ')'
 * range ::= '\d' | '\w' | '\s' | '\D' | '\W' | '\S' | category-block
 *           | range-char | range-char '-' range-char
 * range-char ::= '\[' | '\]' | '\\' | '\' [,-efnrtv] | code-point | character-2
 * code-point ::= '\x' hex-char hex-char
 *                | '\x{' hex-char+ '}'
 *                | '\v' hex-char hex-char hex-char hex-char hex-char hex-char
 * hex-char ::= [0-9a-fA-F]
 * character-2 ::= (any character except \[]-,)
 * </pre>
 *
 * <hr width="50%">
 * <h3>TODO</h3>
 * <ul>
 *   <li><a href="http://www.unicode.org/unicode/reports/tr18/">Unicode Regular Expression Guidelines</a>
 *     <ul>
 *       <li>2.4 Canonical Equivalents
 *       <li>Level 3
 *     </ul>
 *   <li>Parsing performance
 * </ul>
 *
 * <hr width="50%">
 *
 * @version $Id: RegularExpression.javapp,v 1.15 2001/06/13 08:32:09 kent Exp $
 * @author TAMURA Kent &lt;kent@trl.ibm.co.jp&gt;
 */
public class RegularExpression implements java.io.Serializable {
    static final boolean DEBUG = false;

    /**
     * Compiles a token tree into an operation flow.
     */
    private synchronized void compile(Token tok) {
        if (this.operations != null)
            return;
        this.numberOfClosures = 0;
        this.operations = this.compile(tok, null, this.options, false);
    }

    /**
     * Converts a token to an operation.
     */
    private Op compile(Token tok, Op next, int flags, boolean reverse) {
        Op ret = null;
        switch (tok.type) {
          case Token.DOT:
            ret = Op.createDot();
            ret.next = next;
            break;

          case Token.CHAR:
            ret = isSet(flags, IGNORE_CASE0)
                ? Op.createCaseInsensitiveChar(tok.getChar())
                : Op.createChar(tok.getChar());
            ret.next = next;
            break;

          case Token.ANCHOR:
            ret = Op.createAnchor(tok.getChar());
            ret.next = next;
            break;

          case Token.RANGE:
          case Token.NRANGE:
            ret = Op.createRange(tok);
            ret.next = next;
            break;

          case Token.CONCAT:
            ret = next;
            if (!reverse) {
                for (int i = tok.size()-1; i >= 0; i --) {
                    ret = compile(tok.getChild(i), ret, flags, false);
                }
            } else {
                for (int i = 0; i < tok.size(); i ++) {
                    ret = compile(tok.getChild(i), ret, flags, true);
                }
            }
            break;

          case Token.UNION:
            Op.UnionOp uni = Op.createUnion(tok.size());
            for (int i = 0; i < tok.size(); i ++) {
                uni.addElement(compile(tok.getChild(i), next, flags, reverse));
            }
            ret = uni; // ret.next is null.
            break;

          case Token.CLOSURE:
          case Token.NONGREEDYCLOSURE:
            Token child = tok.getChild(0);
            int min = tok.getMin();
            int max = tok.getMax();
            if (min >= 0 && min == max) { // {n}
                ret = next;
                for (int i = 0; i < min; i ++) {
                    ret = compile(child, ret, flags, reverse);
                }
                break;
            }
            if (min > 0 && max > 0)
                max -= min;
            if (max > 0) {
                                                // X{2,6} -> XX(X(X(XX?)?)?)?
                ret = next;
                for (int i = 0; i < max; i ++) {
                    Op.ChildOp q = Op.createQuestion(tok.type == Token.NONGREEDYCLOSURE);
                    q.next = next;
                    q.setChild(compile(child, ret, flags, reverse));
                    ret = q;
                }
            } else {
                Op.ChildOp op;
                Op childOp;
                if (tok.type == Token.NONGREEDYCLOSURE) {
                    op = Op.createNonGreedyClosure();
                } else { // Token.CLOSURE
                    if (child.getMinLength() == 0)
                        op = Op.createClosure(this.numberOfClosures++);
                    else
                        op = Op.createClosure(-1);
                }
                op.next = next;
                op.setChild(childOp = compile(child, op, flags, reverse));
                ret = op;

                if (op.type == Op.CLOSURE) {
                    if (childOp.type == Op.DOT) {
                        ret = Op.createDotClosure();
                        ret.next = next;
                        ret.setData(searchForNextChar(next, flags));
                    } else if (childOp.type == Op.RANGE || childOp.type == Op.NRANGE) {
                        ret = Op.createRangeClosure(childOp.getToken());
                        ret.next = next;
                        ret.setData(searchForNextChar(next, flags));
                    }
                }
            }
            if (min > 0) {
                for (int i = 0; i < min; i ++) {
                    ret = compile(child, ret, flags, reverse);
                }
            }
            break;

          case Token.EMPTY:
            ret = next;
            break;

          case Token.STRING:
            if (isSet(flags, IGNORE_CASE0)) {
                String str = tok.getString();
                for (int i = str.length()-1; i >= 0; i--) {
                    int ch = str.charAt(i);
                    if (isLowSurrogate(ch) && i > 0) {
                        ret = Op.createString(str.substring(i-1, i+1));
                        i--;
                    } else {
                        ret = Op.createCaseInsensitiveChar(ch);
                    }
                    ret.next = next;
                    next = ret;
                }
            } else {
                ret = Op.createString(tok.getString());
                ret.next = next;
            }
            break;

          case Token.BACKREFERENCE:
            ret = Op.createBackReference(tok.getReferenceNumber());
            ret.next = next;
            break;

          case Token.PAREN:
            if (tok.getParenNumber() == 0) {
                ret = compile(tok.getChild(0), next, flags, reverse);
            } else if (reverse) {
                next = Op.createCapture(tok.getParenNumber(), next);
                next = compile(tok.getChild(0), next, flags, reverse);
                ret = Op.createCapture(-tok.getParenNumber(), next);
            } else {
                next = Op.createCapture(-tok.getParenNumber(), next);
                next = compile(tok.getChild(0), next, flags, reverse);
                ret = Op.createCapture(tok.getParenNumber(), next);
            }
            break;

          case Token.LOOKAHEAD:
            ret = Op.createLook(Op.LOOKAHEAD, next,
                                compile(tok.getChild(0), null, flags, false));
            break;
          case Token.NEGATIVELOOKAHEAD:
            ret = Op.createLook(Op.NEGATIVELOOKAHEAD, next,
                                compile(tok.getChild(0), null, flags, false));
            break;
          case Token.LOOKBEHIND:
            ret = Op.createLook(Op.LOOKBEHIND, next,
                                compile(tok.getChild(0), null, flags, true));
            break;
          case Token.NEGATIVELOOKBEHIND:
            ret = Op.createLook(Op.NEGATIVELOOKBEHIND, next,
                                compile(tok.getChild(0), null, flags, true));
            break;

          case Token.INDEPENDENT:
            ret = Op.createIndependent(next, compile(tok.getChild(0), null, flags, reverse));
            break;

          case Token.MODIFIERGROUP:
            int addoptions = ((Token.ModifierToken)tok).getOptions();
            int suboptions = ((Token.ModifierToken)tok).getOptionsMask();
            flags |= addoptions;
            flags &= ~suboptions;
            ret = Op.createModifier(next, compile(tok.getChild(0), null, flags, reverse),
                                    addoptions, suboptions);
            break;

          case Token.CONDITION:
            Token.ConditionToken ctok = (Token.ConditionToken)tok;
            int ref = ctok.refNumber;
            Op condition = ctok.condition == null
                ? null : compile(ctok.condition, null, flags, reverse);
            Op yes = compile(ctok.yes, next, flags, reverse);
            Op no = ctok.no == null ? null : compile(ctok.no, next, flags, reverse);
            ret = Op.createCondition(next, ref, condition, yes, no);
            break;

          default:
            throw new RuntimeException("Unknown token type: "+tok.type);
        } // switch (tok.type)
        return ret;
    }

    // ================================================================

/* -*- java -*-
 *
 * (C) Copyright IBM Corp. 1998-2000  All rights reserved.
 *
 * US Government Users Restricted Rights Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

// $Id: matches.javapp,v 1.13 2001/08/21 05:07:46 kent Exp $

// TODO: return values of Op.STRING, fixesStringMatch()
    /**
     * Checks whether the <var>target</var> text <strong>contains</strong> this pattern or not.
     *
     * @return true if the target is matched to this regular expression.
     */
    public boolean matches(char[] target) {
        return this.matches(target, 0, target.length, (Match)null);
    }

    /**
     * Checks whether the <var>target</var> text <strong>contains</strong> this pattern
     * in specified range or not.
     *
     * @param start Start offset of the range.
     * @param end  End offset +1 of the range.
     * @return true if the target is matched to this regular expression.
     */
    public boolean matches(char[] target, int start, int end) {
        return this.matches(target, start, end, (Match)null);
    }

    /**
     * Checks whether the <var>target</var> text <strong>contains</strong> this pattern or not.
     *
     * @param match A Match instance for storing matching result.
     * @return true if the target is matched to this regular expression.
     */
    public boolean matches(char[] target, Match match) {
        return this.matches(target, 0, target.length, match);
    }
    /**
     * Checks whether the <var>target</var> text <strong>contains</strong> this pattern
     * in specified range or not.
     *
     * @param start Start offset of the range.
     * @param end  End offset +1 of the range.
     * @param match A Match instance for storing matching result.
     * @return true if the target is matched to this regular expression.
     */
    public boolean matches(char[] target, int start, int end, Match match) {
        return matches(target, start, start, end, match);
    }


    /**
     *
     */
    boolean matches(char[] target, int head, int start, int end, Match match) {
        Context con = null;
        synchronized (this) {
            if (this.operations == null)
                this.prepare();
            if (this.context == null)
                this.context = new Context();
        }
        synchronized (this.context) {
            con = this.context.inuse ? new Context() : this.context;
            con.reset(target, head, start, end, this.numberOfClosures);
        }
        if (match != null) {
            match.setNumberOfGroups(this.nofparen);
            match.setSource(target);
        } else if (this.hasBackReferences) {
            match = new Match();
            match.setNumberOfGroups(this.nofparen);
                                                // Need not to call setSource() because
                                                // a caller can not access this match instance.
        }
        con.match = match;

        if (this.isSet(this.options, XMLSCHEMA_MODE)) {
            int matchEnd = this.matchCharArray(con,this.operations,con.start,1,this.options);
            if (matchEnd == con.limit) {
                if (con.match != null) {
                    con.match.setBeginning(0, con.start);
                    con.match.setEnd(0, matchEnd);
                }
                con.inuse = false;



                return true;
            }
            if (con.match != null) {
                con.match.setBeginning(0, con.start);
                con.match.setEnd(0, -matchEnd-1);
            }
            con.inuse = false;
            return false;
        }

        /*
         * The pattern has only fixed string.
         * The engine uses Boyer-Moore.
         */
        if (this.fixedStringOnly && !this.isSet(this.options, ERROR_POSITION)) {
            int o = this.fixedStringTable.matches(target, con.start, con.limit);
            if (o >= 0) {
                if (con.match != null) {
                    con.match.setBeginning(0, o);
                    con.match.setEnd(0, o+this.fixedString.length());
                }
                con.inuse = false;



                return true;
            }
            if (con.match != null) {
                //con.match.setBeginning(0, oXXX);
                con.match.setEnd(0, -o-1);
            }
            con.inuse = false;
            return false;
        }

        /*
         * The pattern contains a fixed string.
         * The engine checks with Boyer-Moore whether the text contains the fixed string or not.
         * If not, it return with false.
         */
        if (this.fixedString != null && con.length > 20 && this.matched*2 <= this.tried
            && !this.isSet(this.options, ERROR_POSITION)) {
            int o = this.fixedStringTable.matches(target, con.start, con.limit);
            if (o < 0) {
                if (con.match != null) {
                    //con.match.setBeginning(0, con.startXXX);
                    con.match.setEnd(0, -o-1);
                }
                con.inuse = false;
                this.tried++;
                if (this.tried <= 0) {
                    this.tried = 1;
                    this.matched = 0;
                }
                return false;
            }
        }

        int limit = con.limit-this.minLength;
        if (this.isSet(this.options, ERROR_POSITION))
            limit = con.limit;
        int matchStart;
        int matchEnd = -1;

        /*
         * Checks whether the expression starts with ".*".
         */
        Op op = this.operations;
        if (op != null
            && ((op.type == Op.CLOSURE && op.getChild().type == Op.DOT)
                || op.type == Op.DOT_CLOSURE)) {
            if (isSet(this.options, SINGLE_LINE)) {
                matchStart = con.start;
                matchEnd = this.matchCharArray(con,this.operations,con.start,1,this.options);
            } else {
                boolean previousIsEOL = true;
                for (matchStart = con.start; matchStart <= limit; matchStart ++) {
                    if ( matchStart < limit && isEOLChar(target[matchStart])) {
                        previousIsEOL = true;
                    } else {
                        if (previousIsEOL) {



                            matchEnd = this.matchCharArray(con,this.operations,matchStart,1,this.options);




                            if (0 <= matchEnd)
                                break;
                        }
                        previousIsEOL = false;
                    }
                }
            }
        }

        /**
         * Optimization against ^, \A \G at the beginning of the pattern.
         */
        else if (op != null
                 && op.type == Op.ANCHOR
                 && ((op.getData() == '^' && !isSet(this.options, MULTIPLE_LINES))
                     || op.getData() == 'A'
                     || op.getData() == 'G')) {
            matchStart = con.start;
            matchEnd = this.matchCharArray(con,this.operations,con.start,1,this.options);
        }

        /*
         * Optimization against the first character.
         */
        else if (this.firstChar != null) {
            //if (DEBUG)  System.err.println("DEBUG: with firstchar-matching: "+this.firstChar);
            RangeToken range = this.firstChar;
            if (this.isSet(this.options, IGNORE_CASE0)) {
                range = this.firstChar.getCaseInsensitiveToken();
                for (matchStart = con.start; matchStart <= limit; matchStart ++) {
                    if (matchStart < limit) {
                        int ch = target[matchStart];
                        if (isHighSurrogate(ch) && matchStart+1 < con.limit) {
                            ch = composeFromSurrogates(ch, target[matchStart+1]);
                            if (!range.match(ch)) continue;
                        } else {
                            if (!range.match(ch)) {
                                char ch1 = Character.toUpperCase((char)ch);
                                if (!range.match(ch1))
                                    if (!range.match(Character.toLowerCase(ch1)))
                                        continue;
                            }
                        }
                    }
                    if (0 <= (matchEnd = this.matchCharArray(con,this.operations,matchStart,1,this.options)))

                        break;
                }
            } else {
                for (matchStart = con.start; matchStart <= limit; matchStart ++) {
                    if (matchStart < limit) {
                        int ch = target[matchStart];
                        if (isHighSurrogate(ch) && matchStart+1 < con.limit)
                            ch = composeFromSurrogates(ch, target[matchStart+1]);
                        if (!range.match(ch)) continue;
                    }
                    if (0 <= (matchEnd = this.matchCharArray(con,this.operations,matchStart,1,this.options)))

                        break;
                }
            }
        }
        /*
         * Straightforward matching.
         */
        else {
            if (DEBUG) System.err.println("DEBUG: No pre-match optimizations.");
            for (matchStart = con.start; matchStart <= limit; matchStart ++) {
                if (0 <= (matchEnd = this.matchCharArray(con,this.operations,matchStart,1,this.options)))

                    break;
            }
        }

        this.tried++;
        if (this.tried <= 0) {
            this.tried = 1;
            this.matched = 0;
        }
        if (matchEnd >= 0) {
            if (con.match != null) {
                con.match.setBeginning(0, matchStart);
                con.match.setEnd(0, matchEnd);
            }
            con.inuse = false;



            this.matched++;
            if (this.matched >= Integer.MAX_VALUE/2) {
                this.matched = 0;
                this.tried = 0;
            }
            return true;
        } else {
            if (con.match != null)
                con.match.setEnd(0, -matchEnd-1);
            con.inuse = false;
            return false;
        }
    }

    /**
     * @return -1 when not match; offset of the end of matched string when match.
     */
    private final int matchCharArray(Context con,Op op,int offset,int dx,int opts) {





        char[] target = con.charTarget;

        int limit = con.limit;

        while (true) {





            if (op == null) {
                return isSet(opts, XMLSCHEMA_MODE) && offset != limit ? -offset-1 : offset;
            }
            if (offset > limit || offset < con.start)
                return offset < 0 ? -1 : -offset-1;
            switch (op.type) {

              case Op.CHAR: // A surrogate pair is represented as STRING.
                if (isSet(opts, IGNORE_CASE)) {
                    int ch = op.getData();
                    if (dx > 0) {
                        if (offset >= limit || !matchIgnoreCase(ch, target[offset]))
                            return -offset-1;
                        offset ++;
                    } else {
                        int o1 = offset-1;
                        if (o1 >= limit || o1 < 0 || !matchIgnoreCase(ch, target[o1]))
                            return o1 < 0 ? -offset-1 : -o1-1;
                        offset = o1;
                    }
                } else {
                    int ch = op.getData();
                    if (dx > 0) {
                        if (offset >= limit || ch != target[offset])
                            return -offset-1;
                        offset ++;
                    } else {
                        int o1 = offset-1;
                        if (o1 >= limit || o1 < 0 || ch != target[o1])
                            return o1 < 0 ? -offset-1 : -o1-1;
                        offset = o1;
                    }
                }
                op = op.next;
                break;

              case Op.DOT:
                if (dx > 0) {
                    if (offset >= limit)
                        return -offset-1;
                    int ch = target[offset];
                    if (isHighSurrogate(ch) && offset+1 < limit)
                        offset ++;
                    if (!isSet(opts, SINGLE_LINE)) {
                        if (isEOLChar(ch)) // EOL must not be a surrogate character.
                            return -offset-1;
                    }
                    offset ++;
                } else {
                    int o1 = offset-1;
                    if (o1 >= limit || o1 < 0)
                        return -offset-1;
                    int ch = target[o1];
                    if (isLowSurrogate(ch) && o1-1 >= 0)
                        o1 --;
                    if (!isSet(opts, SINGLE_LINE)) {
                        if (!isEOLChar(ch)) // EOL must not be a surrogate character.
                            return -o1-1;
                    }
                    offset = o1;
                }
                op = op.next;
                break;

              case Op.RANGE:
              case Op.NRANGE:
                if (dx > 0) {
                    if (offset >= limit)
                        return -offset-1;
                    int ch = target[offset];
                    if (isHighSurrogate(ch) && offset+1 < limit)
                        ch = composeFromSurrogates(ch, target[++offset]);
                    RangeToken tok = op.getToken();
                    if (isSet(opts, IGNORE_CASE)) {
                        tok = tok.getCaseInsensitiveToken();
                        if (!tok.match(ch)) {
                                // Gives up for non-BMP characters.
                                // Java has no case DB for non-BMP characters.
                            if (ch >= 0x10000)
                                return -offset-1;
                                // Converts case and try to match.
                            char uch;
                            if (!tok.match(uch = Character.toUpperCase((char)ch))
                                && !tok.match(Character.toLowerCase(uch)))
                                return -offset-1;
                        }
                    } else {
                        if (!tok.match(ch))
                            return -offset-1;
                    }
                    offset ++;
                } else {
                    int o1 = offset-1;
                    if (o1 >= limit || o1 < 0)
                        return -offset-1;
                    int ch = target[o1];
                    if (isLowSurrogate(ch) && o1-1 >= 0)
                        ch = composeFromSurrogates(target[--o1], ch);
                    RangeToken tok = op.getToken();
                    if (isSet(opts, IGNORE_CASE)) {
                        tok = tok.getCaseInsensitiveToken();
                        if (!tok.match(ch)) {
                            if (ch > BMP_MAX)
                                return -offset-1;
                            char uch;
                            if (!tok.match(uch = Character.toUpperCase((char)ch))
                                && !tok.match(Character.toLowerCase(uch)))
                                return -offset-1;
                        }
                    } else {
                        if (!tok.match(ch))
                            return -offset-1;
                    }
                    offset = o1;
                }
                op = op.next;
                break;

              case Op.ANCHOR:
                boolean go = false;
                switch (op.getData()) {
                  case '^':
                    if (isSet(opts, MULTIPLE_LINES)) {
                        if (!(offset == con.head
                              || offset > con.head && isEOLChar(target[offset-1])))
                            return -offset-1;
                    } else {
                        if (offset != con.head)
                            return -offset-1;
                    }
                    break;

                  case '@': // Internal use only.
                                                // The @ always matches line beginnings.
                    if (!(offset == con.head
                          || offset > con.head && isEOLChar(target[offset-1])))
                        return -offset-1;
                    break;

                  case '$':
                    if (isSet(opts, MULTIPLE_LINES)) {
                        if (!(offset == limit
                              || offset < limit && isEOLChar(target[offset])))
                            return -offset-1;
                    } else {
                        if (!(offset == limit
                              || offset+1 == limit && isEOLChar(target[offset])
                              || offset+2 == limit && target[offset] == CARRIAGE_RETURN
                              && target[offset+1] == LINE_FEED))
                            return -offset-1;
                    }
                    break;

                  case 'A':
                    if (offset != con.head) return -offset-1;
                    break;

                  case 'G':
                    if (offset != con.start) return -offset-1;
                    break;

                  case 'Z':
                    if (!(offset == limit
                          || offset+1 == limit && isEOLChar(target[offset])
                          || offset+2 == limit && target[offset] == CARRIAGE_RETURN
                          && target[offset+1] == LINE_FEED))
                        return -offset-1;
                    break;

                  case 'z':
                    if (offset != limit) return -offset-1;
                    break;

                  case 'b':
                    if (con.length == 0) return -offset-1;
                    {
                        int after = getWordType(target, con.head, limit, offset, opts);
                        if (after == WT_IGNORE) return -offset;
                        int before = getPreviousWordType(target, con.head, limit, offset, opts);
                        if (after == before) return -offset-1;
                    }
                    break;

                  case 'B':
                    if (con.length == 0)
                        go = true;
                    else {
                        int after = getWordType(target, con.head, limit, offset, opts);
                        go = after == WT_IGNORE
                            || after == getPreviousWordType(target, con.head, limit, offset, opts);
                    }
                    if (!go) return -offset-1;
                    break;

                  case '<':
                    if (con.length == 0 || offset == limit) return -offset;
                    if (getWordType(target, con.head, limit, offset, opts) != WT_LETTER
                        || getPreviousWordType(target, con.head, limit, offset, opts) != WT_OTHER)
                        return -offset-1;
                    break;

                  case '>':
                    if (con.length == 0 || offset == con.head) return -offset;
                    if (getWordType(target, con.head, limit, offset, opts) != WT_OTHER
                        || getPreviousWordType(target, con.head, limit, offset, opts) != WT_LETTER)
                        return -offset-1;
                    break;
                } // switch anchor type
                op = op.next;
                break;

              case Op.BACKREFERENCE:
                {
                    int refno = op.getData();
                    if (refno <= 0 || refno >= this.nofparen)
                        throw new RuntimeException("Internal Error: Reference number must be more than zero: "+refno);
                    if (con.match.getBeginning(refno) < 0
                        || con.match.getEnd(refno) < 0)
                        return -offset-1; // ********
                    int o2 = con.match.getBeginning(refno);
                    int literallen = con.match.getEnd(refno)-o2;
                    if (!isSet(opts, IGNORE_CASE0)) { // *****
                        if (dx > 0) {
                            if (!regionMatches(target, offset, limit, o2, literallen))
                                return -offset-1;
                            offset += literallen;
                        } else {
                            if (!regionMatches(target, offset-literallen, limit, o2, literallen))
                                return -offset-1;
                            offset -= literallen;
                        }
                    } else {
                        if (dx > 0) {
                            if (!regionMatchesIgnoreCase(target, offset, limit, o2, literallen))
                                return -offset-1;
                            offset += literallen;
                        } else {
                            if (!regionMatchesIgnoreCase(target, offset-literallen, limit,
                                                         o2, literallen))
                                return -offset-1;
                            offset -= literallen;
                        }
                    }

                }
                op = op.next;
                break;

              case Op.STRING:
                {
                    String literal = op.getString();
                    int literallen = literal.length();
                        if (!isSet(opts, IGNORE_CASE)) {
                            if (dx > 0) {
                                if (limit-offset < literallen)
                                    return -offset-1;
                                if (literallen > 0 && target[offset] != literal.charAt(0))
                                    return -offset-1;




                                if (!regionMatches(target, offset, limit, literal, literallen))
                                    return -offset-1;

                                offset += literallen;
                            } else {
                                if (!regionMatches(target, offset-literallen, limit,
                                                   literal, literallen))
                                    return -offset-1;
                                offset -= literallen;
                            }
                        } else {
                            if (dx > 0) {
                                if (!regionMatchesIgnoreCase(target, offset, limit,
                                                             literal, literallen))
                                    return -offset-1;
                                offset += literallen;
                            } else {
                                if (!regionMatchesIgnoreCase(target, offset-literallen, limit,
                                                             literal, literallen))
                                    return -offset-1;
                                offset -= literallen;
                            }
                        }



                }
                op = op.next;
                break;

              case Op.CLOSURE:
                Op childOp = op.getChild();



                if (childOp.type == Op.CHAR && childOp.next == op && dx > 0) { // a*
                    int startOffset = offset;
                    int ch = childOp.getData();
                    if (dx > 0) {
                        if (isSet(opts, IGNORE_CASE)) {
                            while (offset < limit && matchIgnoreCase(ch, target[offset]))
                                offset ++;
                        } else {
                            while (offset < limit && ch == target[offset])
                                offset ++;
                        }
                        op = op.next;
                        int ret;



                        while ((ret = this.matchCharArray(con,op,offset,dx,opts)) < 0) {



                            if (offset <= startOffset) break;
                            offset --;
                        }



                        return ret;
                    } else {
                        if (isSet(opts, IGNORE_CASE)) {
                            while (--offset < limit && offset >= 0 && matchIgnoreCase(ch, target[offset])); // Empty loop
                        } else {
                            while (--offset < limit && offset >= 0 && ch == target[offset]); // Empty loop
                        }
                        op = op.next;
                                // offset points a character that does not match ch.
                        int ret;



                        while ((ret = this.matchCharArray(con,op,++offset,dx,opts)) < 0) {



                            if (offset >= startOffset) break;
                        }



                        return ret;
                    }

                } else if (childOp.type == Op.DOT && childOp.next == op) { // .*
                    throw new RuntimeException("Internal Error: Non-unified .*");

                } else if ((childOp.type == Op.RANGE || childOp.type == Op.NRANGE)
                           && childOp.next == op) { // [...]*
                    throw new RuntimeException("Internal Error: Non-unified [...]*");

                } else { // <anything>*
                    /*
                     * Saves current position to avoid
                     * zero-width repeats.
                     */
                    int id = op.getData();
                    if (id >= 0) {
                        int previousOffset = con.offsets[id];
                        if (previousOffset < 0 || previousOffset != offset) {
                            con.offsets[id] = offset;
                        } else {
                            con.offsets[id] = -1;
                            op = op.next;
                            break;
                        }
                    }

                    int ret = this.matchCharArray(con,op.getChild(),offset,dx,opts);
                    if (id >= 0) con.offsets[id] = -1;
                    if (ret >= 0) return ret;
                    op = op.next;
                }
                break;

              case Op.DOT_CLOSURE: // .*
                {
                    int startOffset = offset;
                    int ret;
                    if (dx > 0) {
                        if (isSet(opts, SINGLE_LINE)) {
                            while (offset < limit) {
                                int ch = target[offset++];
                                if (isHighSurrogate(ch) && offset < limit)
                                    offset ++;
                            }
                        } else {
                            while (offset < limit) {
                                int ch = target[offset++];
                                if (ch < 0x100) {
                                    if (ch == LINE_FEED || ch == CARRIAGE_RETURN)
                                        break;
                                } else {
                                    if (isHighSurrogate(ch) && offset < limit)
                                        offset ++;
                                    else if (isEOLChar(ch))
                                        break;
                                }
                            }
                        }
                                // offset points the next of valid character for .
                        int nextChar = op.getData();
                        op = op.next;
                        if (nextChar >= 0) {
                            ret = -offset-1;
                            do {
                                if (offset < limit && target[offset] == nextChar
                                    && (ret = this.matchCharArray(con,op,offset,dx,opts)) >= 0)
                                    break;
                                if (offset <= startOffset) break;
                                offset --;
                                if (isLowSurrogate(target[offset])
                                    && offset > startOffset)
                                    offset --;
                            } while (true);
                        } else {
                            while ((ret = this.matchCharArray(con,op,offset,dx,opts)) < 0) {
                                if (offset <= startOffset) break;
                                offset --;
                                if (isLowSurrogate(target[offset])
                                    && offset > startOffset)
                                    offset --;
                            }
                        }
                    } else { // DOT_CLOSURE, dx < 0
                        while (--offset < limit && offset >= 0) {
                            int ch = target[offset];
                            if (isLowSurrogate(ch) && offset-1 >= 0)
                                offset --;
                            if (!isSet(opts, SINGLE_LINE) && !isEOLChar(ch))
                                break;
                        }
                        op = op.next;
                        do {
                            offset++;
                            if (offset < limit && isHighSurrogate(target[offset]))
                                offset++;
                            if ((ret = this.matchCharArray(con,op,++offset,dx,opts)) >= 0)
                                break;
                        } while (offset < startOffset);
                    }
                    return ret;
                }

              case Op.RANGE_CLOSURE: // [...]*
                {
                    RangeToken tok = op.getToken();
                    int startOffset = offset;
                    int ret;
                    if (dx > 0) {
                        if (isSet(opts, IGNORE_CASE)) {
                            tok = tok.getCaseInsensitiveToken();
                            while (offset < limit) {
                                int ch = target[offset];
                                if (isHighSurrogate(ch) && offset+1 < limit)
                                    ch = composeFromSurrogates(ch, target[++offset]);
                                if (!tok.match(ch)) {
                                    if (ch > BMP_MAX) break;
                                    char uch;
                                    if (!tok.match(uch = Character.toUpperCase((char)ch))
                                        && !tok.match(Character.toLowerCase(uch)))
                                        break;
                                }
                                offset ++;
                            }
                        } else {
                            while (offset < limit) {
                                int ch = target[offset];
                                if (isHighSurrogate(ch) && offset+1 < limit)
                                    ch = composeFromSurrogates(ch, target[++offset]);
                                if (!tok.match(ch)) break;
                                offset ++;
                            }
                        }
                        int nextChar = op.getData();
                        op = op.next;
                        if (nextChar >= 0) {
                            ret = -offset-1;
                            do {
                                if (offset < limit && target[offset] == nextChar
                                    && (ret = this.matchCharArray(con,op,offset,dx,opts)) >= 0)
                                    break;
                                if (offset <= startOffset) break;
                                offset --;
                                if (isLowSurrogate(target[offset])
                                    && offset > startOffset)
                                    offset --;
                            } while (true);
                        } else {
                            while ((ret = this.matchCharArray(con,op,offset,dx,opts)) < 0) {
                                if (offset <= startOffset) break;
                                offset --;
                                if (isLowSurrogate(target[offset])
                                    && offset > startOffset)
                                    offset --;
                            }
                        }
                    } else { // dx < 0
                        if (!isSet(opts, IGNORE_CASE)) {
                            while (--offset < limit && offset >= 0) {
                                int ch = target[offset];
                                if (isLowSurrogate(ch) && offset-1 >= 0)
                                    ch = composeFromSurrogates(target[--offset], ch);
                                if (!tok.match(ch))
                                    break;
                            }
                        } else {
                            tok = tok.getCaseInsensitiveToken();
                            while (--offset < limit && offset >= 0) {
                                int ch = target[offset];
                                if (isLowSurrogate(ch) && offset-1 >= 0)
                                    ch = composeFromSurrogates(target[--offset], ch);
                                if (!tok.match(ch)) {
                                    if (ch > BMP_MAX) break;
                                    char uch;
                                    if (!tok.match(uch = Character.toUpperCase((char)ch))
                                        && !tok.match(Character.toLowerCase(uch)))
                                        break;
                                }
                            }
                        }
                        op = op.next;
                        do {
                            offset++;
                            if (offset < limit && isHighSurrogate(target[offset]))
                                offset++;
                            if ((ret = this.matchCharArray(con,op,++offset,dx,opts)) >= 0)
                                break;
                        } while (offset < startOffset);
                    }
                    return ret;
                }

              case Op.QUESTION:
                {
                    int ret = this.matchCharArray(con,op.getChild(),offset,dx,opts);
                    if (ret >= 0) return ret;
                    op = op.next;
                }
                break;

              case Op.NONGREEDYCLOSURE:
              case Op.NONGREEDYQUESTION:
                {
                    int ret = this.matchCharArray(con,op.next,offset,dx,opts);
                    if (ret >= 0) return ret;
                    op = op.getChild();
                }
                break;

              case Op.UNION:
                for (int i = 0; i < op.size(); i ++) {
                    int ret = this.matchCharArray(con,op.elementAt(i),offset,dx,opts);
                    //System.err.println("UNION: "+i+", ret="+ret);
                    if (ret >= 0) return ret;
                }
                return -offset-1;

              case Op.CAPTURE:
                int refno = op.getData();
                if (con.match != null && refno > 0) {
                    int save = con.match.beginpos[refno];
                    con.match.beginpos[refno] = offset;
                    int ret = this.matchCharArray(con,op.next,offset,dx,opts);
                    if (ret < 0) con.match.beginpos[refno] = save;
                    return ret;
                } else if (con.match != null && refno < 0) {
                    int index = -refno;
                    int save = con.match.endpos[index];
                    con.match.endpos[index] = offset;
                    int ret = this.matchCharArray(con,op.next,offset,dx,opts);
                    if (ret < 0) con.match.endpos[index] = save;
                    return ret;
                }
                op = op.next;
                break;

              case Op.LOOKAHEAD:
                {
                    int ret = this.matchCharArray(con,op.getChild(),offset,1,opts);
                    if (0 > ret)
                        return ret;
                }
                op = op.next;
                break;
              case Op.NEGATIVELOOKAHEAD:
                {
                    int ret = this.matchCharArray(con,op.getChild(),offset,1,opts);
                    if (0 <= ret)
                        return -offset-1;
                }
                op = op.next;
                break;
              case Op.LOOKBEHIND:
                {
                    int ret = this.matchCharArray(con,op.getChild(),offset,-1,opts);
                    if (0 > ret)
                        return ret;
                }
                op = op.next;
                break;
              case Op.NEGATIVELOOKBEHIND:
                {
                    int ret = this.matchCharArray(con,op.getChild(),offset,-1,opts);
                    if (0 <= ret)
                        return -offset-1;
                }
                op = op.next;
                break;

              case Op.INDEPENDENT:
                {
                    int ret = this.matchCharArray(con,op.getChild(),offset,dx,opts);
                    if (ret < 0)
                        return ret;
                    offset = ret;
                    op = op.next;
                }
                break;

              case Op.MODIFIER:
                {
                    int localopts = opts;
                    localopts |= op.getData();
                    localopts &= ~op.getData2();
                    //System.err.println("MODIFIER: "+Integer.toString(opts, 16)+" -> "+Integer.toString(localopts, 16));
                    int ret = this.matchCharArray(con,op.getChild(),offset,dx,localopts);
                    if (ret < 0) return ret;
                    offset = ret;
                    op = op.next;
                }
                break;

              case Op.CONDITION:
                {
                    Op.ConditionOp cop = (Op.ConditionOp)op;
                    boolean matchp = false;
                    if (cop.refNumber > 0) {
                        if (cop.refNumber >= this.nofparen)
                            throw new RuntimeException("Internal Error: Reference number must be more than zero: "+cop.refNumber);
                        matchp = con.match.getBeginning(cop.refNumber) >= 0
                            && con.match.getEnd(cop.refNumber) >= 0;
                    } else {
                        matchp = 0 <= this.matchCharArray(con,cop.condition,offset,dx,opts);
                    }

                    if (matchp) {
                        op = cop.yes;
                    } else if (cop.no != null) {
                        op = cop.no;
                    } else {
                        op = cop.next;
                    }
                }
                break;

              default:
                throw new RuntimeException("Internal Error: Unknown operation type: "+op.type);
            } // switch (op.type)
        } // while
    }

    private static final int getPreviousWordType(char[] target, int begin, int end,
                                                 int offset, int opts) {
        int ret = getWordType(target, begin, end, --offset, opts);
        while (ret == WT_IGNORE)
            ret = getWordType(target, begin, end, --offset, opts);
        return ret;
    }

    private static final int getWordType(char[] target, int begin, int end,
                                         int offset, int opts) {
        if (offset < begin || offset >= end) return WT_OTHER;
        return getWordType0(target[offset], opts);
    }
    private static final boolean regionMatches(char[] target, int offset, int limit,
                                               String part, int partlen) {
        if (offset < 0) return false;
        if (limit-offset < partlen)
            return false;
        int i = 0;
        while (partlen-- > 0) {
            if (target[offset++] != part.charAt(i++))
                return false;
        }
        return true;
    }

    private static final boolean regionMatches(char[] target, int offset, int limit,
                                               int offset2, int partlen) {
        if (offset < 0) return false;
        if (limit-offset < partlen)
            return false;
        int i = offset2;
        while (partlen-- > 0) {
            if (target[offset++] != target[i++])
                return false;
        }
        return true;
    }

    /**
     */
    private static final boolean regionMatchesIgnoreCase(char[] target, int offset, int limit,
                                                         String part, int partlen) {
        if (offset < 0) return false;
        if (limit-offset < partlen)
            return false;
        int i = 0;
        while (partlen-- > 0) {
            char ch1 = target[offset++];
            char ch2 = part.charAt(i++);
            if (ch1 == ch2)
                continue;
            char uch1 = Character.toUpperCase(ch1);
            char uch2 = Character.toUpperCase(ch2);
            if (uch1 == uch2)
                continue;
            if (Character.toLowerCase(uch1) != Character.toLowerCase(uch2))
                return false;
        }
        return true;
    }

    private static final boolean regionMatchesIgnoreCase(char[] target, int offset, int limit,
                                                         int offset2, int partlen) {
        if (offset < 0) return false;
        if (limit-offset < partlen)
            return false;
        int i = offset2;
        while (partlen-- > 0) {
            char ch1 = target[offset++];
            char ch2 = target[i++];
            if (ch1 == ch2)
                continue;
            char uch1 = Character.toUpperCase(ch1);
            char uch2 = Character.toUpperCase(ch2);
            if (uch1 == uch2)
                continue;
            if (Character.toLowerCase(uch1) != Character.toLowerCase(uch2))
                return false;
        }
        return true;
    }

/* -*- java -*-
 *
 * (C) Copyright IBM Corp. 1998-2000  All rights reserved.
 *
 * US Government Users Restricted Rights Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

// $Id: matches.javapp,v 1.13 2001/08/21 05:07:46 kent Exp $

// TODO: return values of Op.STRING, fixesStringMatch()
    /**
     * Checks whether the <var>target</var> text <strong>contains</strong> this pattern or not.
     *
     * @return true if the target is matched to this regular expression.
     */
    public boolean matches(String target) {
        return this.matches(target, 0, target.length(), (Match)null);
    }

    /**
     * Checks whether the <var>target</var> text <strong>contains</strong> this pattern
     * in specified range or not.
     *
     * @param start Start offset of the range.
     * @param end  End offset +1 of the range.
     * @return true if the target is matched to this regular expression.
     */
    public boolean matches(String target, int start, int end) {
        return this.matches(target, start, end, (Match)null);
    }

    /**
     * Checks whether the <var>target</var> text <strong>contains</strong> this pattern or not.
     *
     * @param match A Match instance for storing matching result.
     * @return true if the target is matched to this regular expression.
     */
    public boolean matches(String target, Match match) {
        return this.matches(target, 0, target.length(), match);
    }
    /**
     * Checks whether the <var>target</var> text <strong>contains</strong> this pattern
     * in specified range or not.
     *
     * @param start Start offset of the range.
     * @param end  End offset +1 of the range.
     * @param match A Match instance for storing matching result.
     * @return true if the target is matched to this regular expression.
     */
    public boolean matches(String target, int start, int end, Match match) {
        return matches(target, start, start, end, match);
    }


    /**
     *
     */
    boolean matches(String target, int head, int start, int end, Match match) {
        Context con = null;
        synchronized (this) {
            if (this.operations == null)
                this.prepare();
            if (this.context == null)
                this.context = new Context();
        }
        synchronized (this.context) {
            con = this.context.inuse ? new Context() : this.context;
            con.reset(target, head, start, end, this.numberOfClosures);
        }
        if (match != null) {
            match.setNumberOfGroups(this.nofparen);
            match.setSource(target);
        } else if (this.hasBackReferences) {
            match = new Match();
            match.setNumberOfGroups(this.nofparen);
                                                // Need not to call setSource() because
                                                // a caller can not access this match instance.
        }
        con.match = match;

        if (this.isSet(this.options, XMLSCHEMA_MODE)) {
            int matchEnd = this.matchString(con,this.operations,con.start,1,this.options);
            if (matchEnd == con.limit) {
                if (con.match != null) {
                    con.match.setBeginning(0, con.start);
                    con.match.setEnd(0, matchEnd);
                }
                con.inuse = false;



                return true;
            }
            if (con.match != null) {
                con.match.setBeginning(0, con.start);
                con.match.setEnd(0, -matchEnd-1);
            }
            con.inuse = false;
            return false;
        }

        /*
         * The pattern has only fixed string.
         * The engine uses Boyer-Moore.
         */
        if (this.fixedStringOnly && !this.isSet(this.options, ERROR_POSITION)) {
            int o = this.fixedStringTable.matches(target, con.start, con.limit);
            if (o >= 0) {
                if (con.match != null) {
                    con.match.setBeginning(0, o);
                    con.match.setEnd(0, o+this.fixedString.length());
                }
                con.inuse = false;



                return true;
            }
            if (con.match != null) {
                //con.match.setBeginning(0, oXXX);
                con.match.setEnd(0, -o-1);
            }
            con.inuse = false;
            return false;
        }

        /*
         * The pattern contains a fixed string.
         * The engine checks with Boyer-Moore whether the text contains the fixed string or not.
         * If not, it return with false.
         */
        if (this.fixedString != null && con.length > 20 && this.matched*2 <= this.tried
            && !this.isSet(this.options, ERROR_POSITION)) {
            int o = this.fixedStringTable.matches(target, con.start, con.limit);
            if (o < 0) {
                if (con.match != null) {
                    //con.match.setBeginning(0, con.startXXX);
                    con.match.setEnd(0, -o-1);
                }
                con.inuse = false;
                this.tried++;
                if (this.tried <= 0) {
                    this.tried = 1;
                    this.matched = 0;
                }
                return false;
            }
        }

        int limit = con.limit-this.minLength;
        if (this.isSet(this.options, ERROR_POSITION))
            limit = con.limit;
        int matchStart;
        int matchEnd = -1;

        /*
         * Checks whether the expression starts with ".*".
         */
        Op op = this.operations;
        if (op != null
            && ((op.type == Op.CLOSURE && op.getChild().type == Op.DOT)
                || op.type == Op.DOT_CLOSURE)) {
            if (isSet(this.options, SINGLE_LINE)) {
                matchStart = con.start;
                matchEnd = this.matchString(con,this.operations,con.start,1,this.options);
            } else {
                boolean previousIsEOL = true;
                for (matchStart = con.start; matchStart <= limit; matchStart ++) {
                    if ( matchStart < limit && isEOLChar(target.charAt(matchStart))) {
                        previousIsEOL = true;
                    } else {
                        if (previousIsEOL) {



                            matchEnd = this.matchString(con,this.operations,matchStart,1,this.options);




                            if (0 <= matchEnd)
                                break;
                        }
                        previousIsEOL = false;
                    }
                }
            }
        }

        /**
         * Optimization against ^, \A \G at the beginning of the pattern.
         */
        else if (op != null
                 && op.type == Op.ANCHOR
                 && ((op.getData() == '^' && !isSet(this.options, MULTIPLE_LINES))
                     || op.getData() == 'A'
                     || op.getData() == 'G')) {
            matchStart = con.start;
            matchEnd = this.matchString(con,this.operations,con.start,1,this.options);
        }

        /*
         * Optimization against the first character.
         */
        else if (this.firstChar != null) {
            //if (DEBUG)  System.err.println("DEBUG: with firstchar-matching: "+this.firstChar);
            RangeToken range = this.firstChar;
            if (this.isSet(this.options, IGNORE_CASE0)) {
                range = this.firstChar.getCaseInsensitiveToken();
                for (matchStart = con.start; matchStart <= limit; matchStart ++) {
                    if (matchStart < limit) {
                        int ch = target.charAt(matchStart);
                        if (isHighSurrogate(ch) && matchStart+1 < con.limit) {
                            ch = composeFromSurrogates(ch, target.charAt(matchStart+1));
                            if (!range.match(ch)) continue;
                        } else {
                            if (!range.match(ch)) {
                                char ch1 = Character.toUpperCase((char)ch);
                                if (!range.match(ch1))
                                    if (!range.match(Character.toLowerCase(ch1)))
                                        continue;
                            }
                        }
                    }
                    if (0 <= (matchEnd = this.matchString(con,this.operations,matchStart,1,this.options)))

                        break;
                }
            } else {
                for (matchStart = con.start; matchStart <= limit; matchStart ++) {
                    if (matchStart < limit) {
                        int ch = target.charAt(matchStart);
                        if (isHighSurrogate(ch) && matchStart+1 < con.limit)
                            ch = composeFromSurrogates(ch, target.charAt(matchStart+1));
                        if (!range.match(ch)) continue;
                    }
                    if (0 <= (matchEnd = this.matchString(con,this.operations,matchStart,1,this.options)))

                        break;
                }
            }
        }
        /*
         * Straightforward matching.
         */
        else {
            if (DEBUG) System.err.println("DEBUG: No pre-match optimizations.");
            for (matchStart = con.start; matchStart <= limit; matchStart ++) {
                if (0 <= (matchEnd = this.matchString(con,this.operations,matchStart,1,this.options)))

                    break;
            }
        }

        this.tried++;
        if (this.tried <= 0) {
            this.tried = 1;
            this.matched = 0;
        }
        if (matchEnd >= 0) {
            if (con.match != null) {
                con.match.setBeginning(0, matchStart);
                con.match.setEnd(0, matchEnd);
            }
            con.inuse = false;



            this.matched++;
            if (this.matched >= Integer.MAX_VALUE/2) {
                this.matched = 0;
                this.tried = 0;
            }
            return true;
        } else {
            if (con.match != null)
                con.match.setEnd(0, -matchEnd-1);
            con.inuse = false;
            return false;
        }
    }

    /**
     * @return -1 when not match; offset of the end of matched string when match.
     */
    private final int matchString(Context con,Op op,int offset,int dx,int opts) {



        String target = con.strTarget;



        int limit = con.limit;

        while (true) {





            if (op == null) {
                return isSet(opts, XMLSCHEMA_MODE) && offset != limit ? -offset-1 : offset;
            }
            if (offset > limit || offset < con.start)
                return offset < 0 ? -1 : -offset-1;
            switch (op.type) {

              case Op.CHAR: // A surrogate pair is represented as STRING.
                if (isSet(opts, IGNORE_CASE)) {
                    int ch = op.getData();
                    if (dx > 0) {
                        if (offset >= limit || !matchIgnoreCase(ch, target.charAt(offset)))
                            return -offset-1;
                        offset ++;
                    } else {
                        int o1 = offset-1;
                        if (o1 >= limit || o1 < 0 || !matchIgnoreCase(ch, target.charAt(o1)))
                            return o1 < 0 ? -offset-1 : -o1-1;
                        offset = o1;
                    }
                } else {
                    int ch = op.getData();
                    if (dx > 0) {
                        if (offset >= limit || ch != target.charAt(offset))
                            return -offset-1;
                        offset ++;
                    } else {
                        int o1 = offset-1;
                        if (o1 >= limit || o1 < 0 || ch != target.charAt(o1))
                            return o1 < 0 ? -offset-1 : -o1-1;
                        offset = o1;
                    }
                }
                op = op.next;
                break;

              case Op.DOT:
                if (dx > 0) {
                    if (offset >= limit)
                        return -offset-1;
                    int ch = target.charAt(offset);
                    if (isHighSurrogate(ch) && offset+1 < limit)
                        offset ++;
                    if (!isSet(opts, SINGLE_LINE)) {
                        if (isEOLChar(ch)) // EOL must not be a surrogate character.
                            return -offset-1;
                    }
                    offset ++;
                } else {
                    int o1 = offset-1;
                    if (o1 >= limit || o1 < 0)
                        return -offset-1;
                    int ch = target.charAt(o1);
                    if (isLowSurrogate(ch) && o1-1 >= 0)
                        o1 --;
                    if (!isSet(opts, SINGLE_LINE)) {
                        if (!isEOLChar(ch)) // EOL must not be a surrogate character.
                            return -o1-1;
                    }
                    offset = o1;
                }
                op = op.next;
                break;

              case Op.RANGE:
              case Op.NRANGE:
                if (dx > 0) {
                    if (offset >= limit)
                        return -offset-1;
                    int ch = target.charAt(offset);
                    if (isHighSurrogate(ch) && offset+1 < limit)
                        ch = composeFromSurrogates(ch, target.charAt(++offset));
                    RangeToken tok = op.getToken();
                    if (isSet(opts, IGNORE_CASE)) {
                        tok = tok.getCaseInsensitiveToken();
                        if (!tok.match(ch)) {
                                // Gives up for non-BMP characters.
                                // Java has no case DB for non-BMP characters.
                            if (ch >= 0x10000)
                                return -offset-1;
                                // Converts case and try to match.
                            char uch;
                            if (!tok.match(uch = Character.toUpperCase((char)ch))
                                && !tok.match(Character.toLowerCase(uch)))
                                return -offset-1;
                        }
                    } else {
                        if (!tok.match(ch))
                            return -offset-1;
                    }
                    offset ++;
                } else {
                    int o1 = offset-1;
                    if (o1 >= limit || o1 < 0)
                        return -offset-1;
                    int ch = target.charAt(o1);
                    if (isLowSurrogate(ch) && o1-1 >= 0)
                        ch = composeFromSurrogates(target.charAt(--o1), ch);
                    RangeToken tok = op.getToken();
                    if (isSet(opts, IGNORE_CASE)) {
                        tok = tok.getCaseInsensitiveToken();
                        if (!tok.match(ch)) {
                            if (ch > BMP_MAX)
                                return -offset-1;
                            char uch;
                            if (!tok.match(uch = Character.toUpperCase((char)ch))
                                && !tok.match(Character.toLowerCase(uch)))
                                return -offset-1;
                        }
                    } else {
                        if (!tok.match(ch))
                            return -offset-1;
                    }
                    offset = o1;
                }
                op = op.next;
                break;

              case Op.ANCHOR:
                boolean go = false;
                switch (op.getData()) {
                  case '^':
                    if (isSet(opts, MULTIPLE_LINES)) {
                        if (!(offset == con.head
                              || offset > con.head && isEOLChar(target.charAt(offset-1))))
                            return -offset-1;
                    } else {
                        if (offset != con.head)
                            return -offset-1;
                    }
                    break;

                  case '@': // Internal use only.
                                                // The @ always matches line beginnings.
                    if (!(offset == con.head
                          || offset > con.head && isEOLChar(target.charAt(offset-1))))
                        return -offset-1;
                    break;

                  case '$':
                    if (isSet(opts, MULTIPLE_LINES)) {
                        if (!(offset == limit
                              || offset < limit && isEOLChar(target.charAt(offset))))
                            return -offset-1;
                    } else {
                        if (!(offset == limit
                              || offset+1 == limit && isEOLChar(target.charAt(offset))
                              || offset+2 == limit && target.charAt(offset) == CARRIAGE_RETURN
                              && target.charAt(offset+1) == LINE_FEED))
                            return -offset-1;
                    }
                    break;

                  case 'A':
                    if (offset != con.head) return -offset-1;
                    break;

                  case 'G':
                    if (offset != con.start) return -offset-1;
                    break;

                  case 'Z':
                    if (!(offset == limit
                          || offset+1 == limit && isEOLChar(target.charAt(offset))
                          || offset+2 == limit && target.charAt(offset) == CARRIAGE_RETURN
                          && target.charAt(offset+1) == LINE_FEED))
                        return -offset-1;
                    break;

                  case 'z':
                    if (offset != limit) return -offset-1;
                    break;

                  case 'b':
                    if (con.length == 0) return -offset-1;
                    {
                        int after = getWordType(target, con.head, limit, offset, opts);
                        if (after == WT_IGNORE) return -offset;
                        int before = getPreviousWordType(target, con.head, limit, offset, opts);
                        if (after == before) return -offset-1;
                    }
                    break;

                  case 'B':
                    if (con.length == 0)
                        go = true;
                    else {
                        int after = getWordType(target, con.head, limit, offset, opts);
                        go = after == WT_IGNORE
                            || after == getPreviousWordType(target, con.head, limit, offset, opts);
                    }
                    if (!go) return -offset-1;
                    break;

                  case '<':
                    if (con.length == 0 || offset == limit) return -offset;
                    if (getWordType(target, con.head, limit, offset, opts) != WT_LETTER
                        || getPreviousWordType(target, con.head, limit, offset, opts) != WT_OTHER)
                        return -offset-1;
                    break;

                  case '>':
                    if (con.length == 0 || offset == con.head) return -offset;
                    if (getWordType(target, con.head, limit, offset, opts) != WT_OTHER
                        || getPreviousWordType(target, con.head, limit, offset, opts) != WT_LETTER)
                        return -offset-1;
                    break;
                } // switch anchor type
                op = op.next;
                break;

              case Op.BACKREFERENCE:
                {
                    int refno = op.getData();
                    if (refno <= 0 || refno >= this.nofparen)
                        throw new RuntimeException("Internal Error: Reference number must be more than zero: "+refno);
                    if (con.match.getBeginning(refno) < 0
                        || con.match.getEnd(refno) < 0)
                        return -offset-1; // ********
                    int o2 = con.match.getBeginning(refno);
                    int literallen = con.match.getEnd(refno)-o2;
                    if (!isSet(opts, IGNORE_CASE0)) { // *****
                        if (dx > 0) {
                            if (!regionMatches(target, offset, limit, o2, literallen))
                                return -offset-1;
                            offset += literallen;
                        } else {
                            if (!regionMatches(target, offset-literallen, limit, o2, literallen))
                                return -offset-1;
                            offset -= literallen;
                        }
                    } else {
                        if (dx > 0) {
                            if (!regionMatchesIgnoreCase(target, offset, limit, o2, literallen))
                                return -offset-1;
                            offset += literallen;
                        } else {
                            if (!regionMatchesIgnoreCase(target, offset-literallen, limit,
                                                         o2, literallen))
                                return -offset-1;
                            offset -= literallen;
                        }
                    }

                }
                op = op.next;
                break;

              case Op.STRING:
                {
                    String literal = op.getString();
                    int literallen = literal.length();
                        if (!isSet(opts, IGNORE_CASE)) {
                            if (dx > 0) {
                                if (limit-offset < literallen)
                                    return -offset-1;
                                if (literallen > 0 && target.charAt(offset) != literal.charAt(0))
                                    return -offset-1;

                                if (!target.regionMatches(offset, literal, 0, literallen))
                                    return -offset-1;




                                offset += literallen;
                            } else {
                                if (!regionMatches(target, offset-literallen, limit,
                                                   literal, literallen))
                                    return -offset-1;
                                offset -= literallen;
                            }
                        } else {
                            if (dx > 0) {
                                if (!regionMatchesIgnoreCase(target, offset, limit,
                                                             literal, literallen))
                                    return -offset-1;
                                offset += literallen;
                            } else {
                                if (!regionMatchesIgnoreCase(target, offset-literallen, limit,
                                                             literal, literallen))
                                    return -offset-1;
                                offset -= literallen;
                            }
                        }



                }
                op = op.next;
                break;

              case Op.CLOSURE:
                Op childOp = op.getChild();



                if (childOp.type == Op.CHAR && childOp.next == op && dx > 0) { // a*
                    int startOffset = offset;
                    int ch = childOp.getData();
                    if (dx > 0) {
                        if (isSet(opts, IGNORE_CASE)) {
                            while (offset < limit && matchIgnoreCase(ch, target.charAt(offset)))
                                offset ++;
                        } else {
                            while (offset < limit && ch == target.charAt(offset))
                                offset ++;
                        }
                        op = op.next;
                        int ret;



                        while ((ret = this.matchString(con,op,offset,dx,opts)) < 0) {



                            if (offset <= startOffset) break;
                            offset --;
                        }



                        return ret;
                    } else {
                        if (isSet(opts, IGNORE_CASE)) {
                            while (--offset < limit && offset >= 0 && matchIgnoreCase(ch, target.charAt(offset))); // Empty loop
                        } else {
                            while (--offset < limit && offset >= 0 && ch == target.charAt(offset)); // Empty loop
                        }
                        op = op.next;
                                // offset points a character that does not match ch.
                        int ret;



                        while ((ret = this.matchString(con,op,++offset,dx,opts)) < 0) {



                            if (offset >= startOffset) break;
                        }



                        return ret;
                    }

                } else if (childOp.type == Op.DOT && childOp.next == op) { // .*
                    throw new RuntimeException("Internal Error: Non-unified .*");

                } else if ((childOp.type == Op.RANGE || childOp.type == Op.NRANGE)
                           && childOp.next == op) { // [...]*
                    throw new RuntimeException("Internal Error: Non-unified [...]*");

                } else { // <anything>*
                    /*
                     * Saves current position to avoid
                     * zero-width repeats.
                     */
                    int id = op.getData();
                    if (id >= 0) {
                        int previousOffset = con.offsets[id];
                        if (previousOffset < 0 || previousOffset != offset) {
                            con.offsets[id] = offset;
                        } else {
                            con.offsets[id] = -1;
                            op = op.next;
                            break;
                        }
                    }

                    int ret = this.matchString(con,op.getChild(),offset,dx,opts);
                    if (id >= 0) con.offsets[id] = -1;
                    if (ret >= 0) return ret;
                    op = op.next;
                }
                break;

              case Op.DOT_CLOSURE: // .*
                {
                    int startOffset = offset;
                    int ret;
                    if (dx > 0) {
                        if (isSet(opts, SINGLE_LINE)) {
                            while (offset < limit) {
                                int ch = target.charAt(offset++);
                                if (isHighSurrogate(ch) && offset < limit)
                                    offset ++;
                            }
                        } else {
                            while (offset < limit) {
                                int ch = target.charAt(offset++);
                                if (ch < 0x100) {
                                    if (ch == LINE_FEED || ch == CARRIAGE_RETURN)
                                        break;
                                } else {
                                    if (isHighSurrogate(ch) && offset < limit)
                                        offset ++;
                                    else if (isEOLChar(ch))
                                        break;
                                }
                            }
                        }
                                // offset points the next of valid character for .
                        int nextChar = op.getData();
                        op = op.next;
                        if (nextChar >= 0) {
                            ret = -offset-1;
                            do {
                                if (offset < limit && target.charAt(offset) == nextChar
                                    && (ret = this.matchString(con,op,offset,dx,opts)) >= 0)
                                    break;
                                if (offset <= startOffset) break;
                                offset --;
                                if (isLowSurrogate(target.charAt(offset))
                                    && offset > startOffset)
                                    offset --;
                            } while (true);
                        } else {
                            while ((ret = this.matchString(con,op,offset,dx,opts)) < 0) {
                                if (offset <= startOffset) break;
                                offset --;
                                if (isLowSurrogate(target.charAt(offset))
                                    && offset > startOffset)
                                    offset --;
                            }
                        }
                    } else { // DOT_CLOSURE, dx < 0
                        while (--offset < limit && offset >= 0) {
                            int ch = target.charAt(offset);
                            if (isLowSurrogate(ch) && offset-1 >= 0)
                                offset --;
                            if (!isSet(opts, SINGLE_LINE) && !isEOLChar(ch))
                                break;
                        }
                        op = op.next;
                        do {
                            offset++;
                            if (offset < limit && isHighSurrogate(target.charAt(offset)))
                                offset++;
                            if ((ret = this.matchString(con,op,++offset,dx,opts)) >= 0)
                                break;
                        } while (offset < startOffset);
                    }
                    return ret;
                }

              case Op.RANGE_CLOSURE: // [...]*
                {
                    RangeToken tok = op.getToken();
                    int startOffset = offset;
                    int ret;
                    if (dx > 0) {
                        if (isSet(opts, IGNORE_CASE)) {
                            tok = tok.getCaseInsensitiveToken();
                            while (offset < limit) {
                                int ch = target.charAt(offset);
                                if (isHighSurrogate(ch) && offset+1 < limit)
                                    ch = composeFromSurrogates(ch, target.charAt(++offset));
                                if (!tok.match(ch)) {
                                    if (ch > BMP_MAX) break;
                                    char uch;
                                    if (!tok.match(uch = Character.toUpperCase((char)ch))
                                        && !tok.match(Character.toLowerCase(uch)))
                                        break;
                                }
                                offset ++;
                            }
                        } else {
                            while (offset < limit) {
                                int ch = target.charAt(offset);
                                if (isHighSurrogate(ch) && offset+1 < limit)
                                    ch = composeFromSurrogates(ch, target.charAt(++offset));
                                if (!tok.match(ch)) break;
                                offset ++;
                            }
                        }
                        int nextChar = op.getData();
                        op = op.next;
                        if (nextChar >= 0) {
                            ret = -offset-1;
                            do {
                                if (offset < limit && target.charAt(offset) == nextChar
                                    && (ret = this.matchString(con,op,offset,dx,opts)) >= 0)
                                    break;
                                if (offset <= startOffset) break;
                                offset --;
                                if (isLowSurrogate(target.charAt(offset))
                                    && offset > startOffset)
                                    offset --;
                            } while (true);
                        } else {
                            while ((ret = this.matchString(con,op,offset,dx,opts)) < 0) {
                                if (offset <= startOffset) break;
                                offset --;
                                if (isLowSurrogate(target.charAt(offset))
                                    && offset > startOffset)
                                    offset --;
                            }
                        }
                    } else { // dx < 0
                        if (!isSet(opts, IGNORE_CASE)) {
                            while (--offset < limit && offset >= 0) {
                                int ch = target.charAt(offset);
                                if (isLowSurrogate(ch) && offset-1 >= 0)
                                    ch = composeFromSurrogates(target.charAt(--offset), ch);
                                if (!tok.match(ch))
                                    break;
                            }
                        } else {
                            tok = tok.getCaseInsensitiveToken();
                            while (--offset < limit && offset >= 0) {
                                int ch = target.charAt(offset);
                                if (isLowSurrogate(ch) && offset-1 >= 0)
                                    ch = composeFromSurrogates(target.charAt(--offset), ch);
                                if (!tok.match(ch)) {
                                    if (ch > BMP_MAX) break;
                                    char uch;
                                    if (!tok.match(uch = Character.toUpperCase((char)ch))
                                        && !tok.match(Character.toLowerCase(uch)))
                                        break;
                                }
                            }
                        }
                        op = op.next;
                        do {
                            offset++;
                            if (offset < limit && isHighSurrogate(target.charAt(offset)))
                                offset++;
                            if ((ret = this.matchString(con,op,++offset,dx,opts)) >= 0)
                                break;
                        } while (offset < startOffset);
                    }
                    return ret;
                }

              case Op.QUESTION:
                {
                    int ret = this.matchString(con,op.getChild(),offset,dx,opts);
                    if (ret >= 0) return ret;
                    op = op.next;
                }
                break;

              case Op.NONGREEDYCLOSURE:
              case Op.NONGREEDYQUESTION:
                {
                    int ret = this.matchString(con,op.next,offset,dx,opts);
                    if (ret >= 0) return ret;
                    op = op.getChild();
                }
                break;

              case Op.UNION:
                for (int i = 0; i < op.size(); i ++) {
                    int ret = this.matchString(con,op.elementAt(i),offset,dx,opts);
                    //System.err.println("UNION: "+i+", ret="+ret);
                    if (ret >= 0) return ret;
                }
                return -offset-1;

              case Op.CAPTURE:
                int refno = op.getData();
                if (con.match != null && refno > 0) {
                    int save = con.match.beginpos[refno];
                    con.match.beginpos[refno] = offset;
                    int ret = this.matchString(con,op.next,offset,dx,opts);
                    if (ret < 0) con.match.beginpos[refno] = save;
                    return ret;
                } else if (con.match != null && refno < 0) {
                    int index = -refno;
                    int save = con.match.endpos[index];
                    con.match.endpos[index] = offset;
                    int ret = this.matchString(con,op.next,offset,dx,opts);
                    if (ret < 0) con.match.endpos[index] = save;
                    return ret;
                }
                op = op.next;
                break;

              case Op.LOOKAHEAD:
                {
                    int ret = this.matchString(con,op.getChild(),offset,1,opts);
                    if (0 > ret)
                        return ret;
                }
                op = op.next;
                break;
              case Op.NEGATIVELOOKAHEAD:
                {
                    int ret = this.matchString(con,op.getChild(),offset,1,opts);
                    if (0 <= ret)
                        return -offset-1;
                }
                op = op.next;
                break;
              case Op.LOOKBEHIND:
                {
                    int ret = this.matchString(con,op.getChild(),offset,-1,opts);
                    if (0 > ret)
                        return ret;
                }
                op = op.next;
                break;
              case Op.NEGATIVELOOKBEHIND:
                {
                    int ret = this.matchString(con,op.getChild(),offset,-1,opts);
                    if (0 <= ret)
                        return -offset-1;
                }
                op = op.next;
                break;

              case Op.INDEPENDENT:
                {
                    int ret = this.matchString(con,op.getChild(),offset,dx,opts);
                    if (ret < 0)
                        return ret;
                    offset = ret;
                    op = op.next;
                }
                break;

              case Op.MODIFIER:
                {
                    int localopts = opts;
                    localopts |= op.getData();
                    localopts &= ~op.getData2();
                    //System.err.println("MODIFIER: "+Integer.toString(opts, 16)+" -> "+Integer.toString(localopts, 16));
                    int ret = this.matchString(con,op.getChild(),offset,dx,localopts);
                    if (ret < 0) return ret;
                    offset = ret;
                    op = op.next;
                }
                break;

              case Op.CONDITION:
                {
                    Op.ConditionOp cop = (Op.ConditionOp)op;
                    boolean matchp = false;
                    if (cop.refNumber > 0) {
                        if (cop.refNumber >= this.nofparen)
                            throw new RuntimeException("Internal Error: Reference number must be more than zero: "+cop.refNumber);
                        matchp = con.match.getBeginning(cop.refNumber) >= 0
                            && con.match.getEnd(cop.refNumber) >= 0;
                    } else {
                        matchp = 0 <= this.matchString(con,cop.condition,offset,dx,opts);
                    }

                    if (matchp) {
                        op = cop.yes;
                    } else if (cop.no != null) {
                        op = cop.no;
                    } else {
                        op = cop.next;
                    }
                }
                break;

              default:
                throw new RuntimeException("Internal Error: Unknown operation type: "+op.type);
            } // switch (op.type)
        } // while
    }

    private static final int getPreviousWordType(String target, int begin, int end,
                                                 int offset, int opts) {
        int ret = getWordType(target, begin, end, --offset, opts);
        while (ret == WT_IGNORE)
            ret = getWordType(target, begin, end, --offset, opts);
        return ret;
    }

    private static final int getWordType(String target, int begin, int end,
                                         int offset, int opts) {
        if (offset < begin || offset >= end) return WT_OTHER;
        return getWordType0(target.charAt(offset), opts);
    }


    private static final boolean regionMatches(String text, int offset, int limit,
                                               String part, int partlen) {
        if (limit-offset < partlen) return false;
        return text.regionMatches(offset, part, 0, partlen);
    }

    private static final boolean regionMatches(String text, int offset, int limit,
                                               int offset2, int partlen) {
        if (limit-offset < partlen) return false;
        return text.regionMatches(offset, text, offset2, partlen);
    }

    private static final boolean regionMatchesIgnoreCase(String text, int offset, int limit,
                                                         String part, int partlen) {
        return text.regionMatches(true, offset, part, 0, partlen);
    }

    private static final boolean regionMatchesIgnoreCase(String text, int offset, int limit,
                                                         int offset2, int partlen) {
        if (limit-offset < partlen) return false;
        return text.regionMatches(true, offset, text, offset2, partlen);
    }


/* -*- java -*-
 *
 * (C) Copyright IBM Corp. 1998-2000  All rights reserved.
 *
 * US Government Users Restricted Rights Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

// $Id: matches.javapp,v 1.13 2001/08/21 05:07:46 kent Exp $

// TODO: return values of Op.STRING, fixesStringMatch()
    /**
     * Checks whether the <var>target</var> text <strong>contains</strong> this pattern or not.
     * The matching starts at <var>target</var><code>.getIndex()</code>.
     * The current index of <var>target</var> moves to the match-ending position if
     * the <var>target</var> is matched.
     *
     * @return true if the target is matched to this regular expression.
     */
    public boolean matches(CharacterIterator target) {
        return this.matches(target, (Match)null);
    }
    /**
     * Checks whether the <var>target</var> text <strong>contains</strong> this pattern or not.
     * The matching starts at <var>target</var><code>.getIndex()</code>.
     * The current index of <var>target</var> moves to the match-ending position if
     * the <var>target</var> is matched.
     *
     * @param match A Match instance for storing matching result.
     * @return true if the target is matched to this regular expression.
     */
    public boolean matches(CharacterIterator target, Match match) {
        return matches(target, target.getBeginIndex(), target.getIndex(),
                       target.getEndIndex(), match);
    }
    /**
     *
     */
    boolean matches(CharacterIterator target, int head, int start, int end, Match match) {
        Context con = null;
        synchronized (this) {
            if (this.operations == null)
                this.prepare();
            if (this.context == null)
                this.context = new Context();
        }
        synchronized (this.context) {
            con = this.context.inuse ? new Context() : this.context;
            con.reset(target, head, start, end, this.numberOfClosures);
        }
        if (match != null) {
            match.setNumberOfGroups(this.nofparen);
            match.setSource(target);
        } else if (this.hasBackReferences) {
            match = new Match();
            match.setNumberOfGroups(this.nofparen);
                                                // Need not to call setSource() because
                                                // a caller can not access this match instance.
        }
        con.match = match;

        if (this.isSet(this.options, XMLSCHEMA_MODE)) {
            int matchEnd = this.matchCharacterIterator(con,this.operations,con.start,1,this.options);
            if (matchEnd == con.limit) {
                if (con.match != null) {
                    con.match.setBeginning(0, con.start);
                    con.match.setEnd(0, matchEnd);
                }
                con.inuse = false;

                target.setIndex(matchEnd);

                return true;
            }
            if (con.match != null) {
                con.match.setBeginning(0, con.start);
                con.match.setEnd(0, -matchEnd-1);
            }
            con.inuse = false;
            return false;
        }

        /*
         * The pattern has only fixed string.
         * The engine uses Boyer-Moore.
         */
        if (this.fixedStringOnly && !this.isSet(this.options, ERROR_POSITION)) {
            int o = this.fixedStringTable.matches(target, con.start, con.limit);
            if (o >= 0) {
                if (con.match != null) {
                    con.match.setBeginning(0, o);
                    con.match.setEnd(0, o+this.fixedString.length());
                }
                con.inuse = false;

                target.setIndex(o+this.fixedString.length());

                return true;
            }
            if (con.match != null) {
                //con.match.setBeginning(0, oXXX);
                con.match.setEnd(0, -o-1);
            }
            con.inuse = false;
            return false;
        }

        /*
         * The pattern contains a fixed string.
         * The engine checks with Boyer-Moore whether the text contains the fixed string or not.
         * If not, it return with false.
         */
        if (this.fixedString != null && con.length > 20 && this.matched*2 <= this.tried
            && !this.isSet(this.options, ERROR_POSITION)) {
            int o = this.fixedStringTable.matches(target, con.start, con.limit);
            if (o < 0) {
                if (con.match != null) {
                    //con.match.setBeginning(0, con.startXXX);
                    con.match.setEnd(0, -o-1);
                }
                con.inuse = false;
                this.tried++;
                if (this.tried <= 0) {
                    this.tried = 1;
                    this.matched = 0;
                }
                return false;
            }
        }

        int limit = con.limit-this.minLength;
        if (this.isSet(this.options, ERROR_POSITION))
            limit = con.limit;
        int matchStart;
        int matchEnd = -1;

        /*
         * Checks whether the expression starts with ".*".
         */
        Op op = this.operations;
        if (op != null
            && ((op.type == Op.CLOSURE && op.getChild().type == Op.DOT)
                || op.type == Op.DOT_CLOSURE)) {
            if (isSet(this.options, SINGLE_LINE)) {
                matchStart = con.start;
                matchEnd = this.matchCharacterIterator(con,this.operations,con.start,1,this.options);
            } else {
                boolean previousIsEOL = true;
                for (matchStart = con.start; matchStart <= limit; matchStart ++) {
                    if ( matchStart < limit && isEOLChar(target.setIndex(matchStart))) {
                        previousIsEOL = true;
                    } else {
                        if (previousIsEOL) {



                            matchEnd = this.matchCharacterIterator(con,this.operations,matchStart,1,this.options);




                            if (0 <= matchEnd)
                                break;
                        }
                        previousIsEOL = false;
                    }
                }
            }
        }

        /**
         * Optimization against ^, \A \G at the beginning of the pattern.
         */
        else if (op != null
                 && op.type == Op.ANCHOR
                 && ((op.getData() == '^' && !isSet(this.options, MULTIPLE_LINES))
                     || op.getData() == 'A'
                     || op.getData() == 'G')) {
            matchStart = con.start;
            matchEnd = this.matchCharacterIterator(con,this.operations,con.start,1,this.options);
        }

        /*
         * Optimization against the first character.
         */
        else if (this.firstChar != null) {
            //if (DEBUG)  System.err.println("DEBUG: with firstchar-matching: "+this.firstChar);
            RangeToken range = this.firstChar;
            if (this.isSet(this.options, IGNORE_CASE0)) {
                range = this.firstChar.getCaseInsensitiveToken();
                for (matchStart = con.start; matchStart <= limit; matchStart ++) {
                    if (matchStart < limit) {
                        int ch = target.setIndex(matchStart);
                        if (isHighSurrogate(ch) && matchStart+1 < con.limit) {
                            ch = composeFromSurrogates(ch, target.setIndex(matchStart+1));
                            if (!range.match(ch)) continue;
                        } else {
                            if (!range.match(ch)) {
                                char ch1 = Character.toUpperCase((char)ch);
                                if (!range.match(ch1))
                                    if (!range.match(Character.toLowerCase(ch1)))
                                        continue;
                            }
                        }
                    }
                    if (0 <= (matchEnd = this.matchCharacterIterator(con,this.operations,matchStart,1,this.options)))

                        break;
                }
            } else {
                for (matchStart = con.start; matchStart <= limit; matchStart ++) {
                    if (matchStart < limit) {
                        int ch = target.setIndex(matchStart);
                        if (isHighSurrogate(ch) && matchStart+1 < con.limit)
                            ch = composeFromSurrogates(ch, target.setIndex(matchStart+1));
                        if (!range.match(ch)) continue;
                    }
                    if (0 <= (matchEnd = this.matchCharacterIterator(con,this.operations,matchStart,1,this.options)))

                        break;
                }
            }
        }
        /*
         * Straightforward matching.
         */
        else {
            if (DEBUG) System.err.println("DEBUG: No pre-match optimizations.");
            for (matchStart = con.start; matchStart <= limit; matchStart ++) {
                if (0 <= (matchEnd = this.matchCharacterIterator(con,this.operations,matchStart,1,this.options)))

                    break;
            }
        }

        this.tried++;
        if (this.tried <= 0) {
            this.tried = 1;
            this.matched = 0;
        }
        if (matchEnd >= 0) {
            if (con.match != null) {
                con.match.setBeginning(0, matchStart);
                con.match.setEnd(0, matchEnd);
            }
            con.inuse = false;

            target.setIndex(matchEnd);

            this.matched++;
            if (this.matched >= Integer.MAX_VALUE/2) {
                this.matched = 0;
                this.tried = 0;
            }
            return true;
        } else {
            if (con.match != null)
                con.match.setEnd(0, -matchEnd-1);
            con.inuse = false;
            return false;
        }
    }

    /**
     * @return -1 when not match; offset of the end of matched string when match.
     */
    private final int matchCharacterIterator(Context con,Op op,int offset,int dx,int opts) {

        CharacterIterator target = con.ciTarget;





        int limit = con.limit;

        while (true) {





            if (op == null) {
                return isSet(opts, XMLSCHEMA_MODE) && offset != limit ? -offset-1 : offset;
            }
            if (offset > limit || offset < con.start)
                return offset < 0 ? -1 : -offset-1;
            switch (op.type) {

              case Op.CHAR: // A surrogate pair is represented as STRING.
                if (isSet(opts, IGNORE_CASE)) {
                    int ch = op.getData();
                    if (dx > 0) {
                        if (offset >= limit || !matchIgnoreCase(ch, target.setIndex(offset)))
                            return -offset-1;
                        offset ++;
                    } else {
                        int o1 = offset-1;
                        if (o1 >= limit || o1 < 0 || !matchIgnoreCase(ch, target.setIndex(o1)))
                            return o1 < 0 ? -offset-1 : -o1-1;
                        offset = o1;
                    }
                } else {
                    int ch = op.getData();
                    if (dx > 0) {
                        if (offset >= limit || ch != target.setIndex(offset))
                            return -offset-1;
                        offset ++;
                    } else {
                        int o1 = offset-1;
                        if (o1 >= limit || o1 < 0 || ch != target.setIndex(o1))
                            return o1 < 0 ? -offset-1 : -o1-1;
                        offset = o1;
                    }
                }
                op = op.next;
                break;

              case Op.DOT:
                if (dx > 0) {
                    if (offset >= limit)
                        return -offset-1;
                    int ch = target.setIndex(offset);
                    if (isHighSurrogate(ch) && offset+1 < limit)
                        offset ++;
                    if (!isSet(opts, SINGLE_LINE)) {
                        if (isEOLChar(ch)) // EOL must not be a surrogate character.
                            return -offset-1;
                    }
                    offset ++;
                } else {
                    int o1 = offset-1;
                    if (o1 >= limit || o1 < 0)
                        return -offset-1;
                    int ch = target.setIndex(o1);
                    if (isLowSurrogate(ch) && o1-1 >= 0)
                        o1 --;
                    if (!isSet(opts, SINGLE_LINE)) {
                        if (!isEOLChar(ch)) // EOL must not be a surrogate character.
                            return -o1-1;
                    }
                    offset = o1;
                }
                op = op.next;
                break;

              case Op.RANGE:
              case Op.NRANGE:
                if (dx > 0) {
                    if (offset >= limit)
                        return -offset-1;
                    int ch = target.setIndex(offset);
                    if (isHighSurrogate(ch) && offset+1 < limit)
                        ch = composeFromSurrogates(ch, target.setIndex(++offset));
                    RangeToken tok = op.getToken();
                    if (isSet(opts, IGNORE_CASE)) {
                        tok = tok.getCaseInsensitiveToken();
                        if (!tok.match(ch)) {
                                // Gives up for non-BMP characters.
                                // Java has no case DB for non-BMP characters.
                            if (ch >= 0x10000)
                                return -offset-1;
                                // Converts case and try to match.
                            char uch;
                            if (!tok.match(uch = Character.toUpperCase((char)ch))
                                && !tok.match(Character.toLowerCase(uch)))
                                return -offset-1;
                        }
                    } else {
                        if (!tok.match(ch))
                            return -offset-1;
                    }
                    offset ++;
                } else {
                    int o1 = offset-1;
                    if (o1 >= limit || o1 < 0)
                        return -offset-1;
                    int ch = target.setIndex(o1);
                    if (isLowSurrogate(ch) && o1-1 >= 0)
                        ch = composeFromSurrogates(target.setIndex(--o1), ch);
                    RangeToken tok = op.getToken();
                    if (isSet(opts, IGNORE_CASE)) {
                        tok = tok.getCaseInsensitiveToken();
                        if (!tok.match(ch)) {
                            if (ch > BMP_MAX)
                                return -offset-1;
                            char uch;
                            if (!tok.match(uch = Character.toUpperCase((char)ch))
                                && !tok.match(Character.toLowerCase(uch)))
                                return -offset-1;
                        }
                    } else {
                        if (!tok.match(ch))
                            return -offset-1;
                    }
                    offset = o1;
                }
                op = op.next;
                break;

              case Op.ANCHOR:
                boolean go = false;
                switch (op.getData()) {
                  case '^':
                    if (isSet(opts, MULTIPLE_LINES)) {
                        if (!(offset == con.head
                              || offset > con.head && isEOLChar(target.setIndex(offset-1))))
                            return -offset-1;
                    } else {
                        if (offset != con.head)
                            return -offset-1;
                    }
                    break;

                  case '@': // Internal use only.
                                                // The @ always matches line beginnings.
                    if (!(offset == con.head
                          || offset > con.head && isEOLChar(target.setIndex(offset-1))))
                        return -offset-1;
                    break;

                  case '$':
                    if (isSet(opts, MULTIPLE_LINES)) {
                        if (!(offset == limit
                              || offset < limit && isEOLChar(target.setIndex(offset))))
                            return -offset-1;
                    } else {
                        if (!(offset == limit
                              || offset+1 == limit && isEOLChar(target.setIndex(offset))
                              || offset+2 == limit && target.setIndex(offset) == CARRIAGE_RETURN
                              && target.setIndex(offset+1) == LINE_FEED))
                            return -offset-1;
                    }
                    break;

                  case 'A':
                    if (offset != con.head) return -offset-1;
                    break;

                  case 'G':
                    if (offset != con.start) return -offset-1;
                    break;

                  case 'Z':
                    if (!(offset == limit
                          || offset+1 == limit && isEOLChar(target.setIndex(offset))
                          || offset+2 == limit && target.setIndex(offset) == CARRIAGE_RETURN
                          && target.setIndex(offset+1) == LINE_FEED))
                        return -offset-1;
                    break;

                  case 'z':
                    if (offset != limit) return -offset-1;
                    break;

                  case 'b':
                    if (con.length == 0) return -offset-1;
                    {
                        int after = getWordType(target, con.head, limit, offset, opts);
                        if (after == WT_IGNORE) return -offset;
                        int before = getPreviousWordType(target, con.head, limit, offset, opts);
                        if (after == before) return -offset-1;
                    }
                    break;

                  case 'B':
                    if (con.length == 0)
                        go = true;
                    else {
                        int after = getWordType(target, con.head, limit, offset, opts);
                        go = after == WT_IGNORE
                            || after == getPreviousWordType(target, con.head, limit, offset, opts);
                    }
                    if (!go) return -offset-1;
                    break;

                  case '<':
                    if (con.length == 0 || offset == limit) return -offset;
                    if (getWordType(target, con.head, limit, offset, opts) != WT_LETTER
                        || getPreviousWordType(target, con.head, limit, offset, opts) != WT_OTHER)
                        return -offset-1;
                    break;

                  case '>':
                    if (con.length == 0 || offset == con.head) return -offset;
                    if (getWordType(target, con.head, limit, offset, opts) != WT_OTHER
                        || getPreviousWordType(target, con.head, limit, offset, opts) != WT_LETTER)
                        return -offset-1;
                    break;
                } // switch anchor type
                op = op.next;
                break;

              case Op.BACKREFERENCE:
                {
                    int refno = op.getData();
                    if (refno <= 0 || refno >= this.nofparen)
                        throw new RuntimeException("Internal Error: Reference number must be more than zero: "+refno);
                    if (con.match.getBeginning(refno) < 0
                        || con.match.getEnd(refno) < 0)
                        return -offset-1; // ********
                    int o2 = con.match.getBeginning(refno);
                    int literallen = con.match.getEnd(refno)-o2;
                    if (!isSet(opts, IGNORE_CASE0)) { // *****
                        if (dx > 0) {
                            if (!regionMatches(target, offset, limit, o2, literallen))
                                return -offset-1;
                            offset += literallen;
                        } else {
                            if (!regionMatches(target, offset-literallen, limit, o2, literallen))
                                return -offset-1;
                            offset -= literallen;
                        }
                    } else {
                        if (dx > 0) {
                            if (!regionMatchesIgnoreCase(target, offset, limit, o2, literallen))
                                return -offset-1;
                            offset += literallen;
                        } else {
                            if (!regionMatchesIgnoreCase(target, offset-literallen, limit,
                                                         o2, literallen))
                                return -offset-1;
                            offset -= literallen;
                        }
                    }

                }
                op = op.next;
                break;

              case Op.STRING:
                {
                    String literal = op.getString();
                    int literallen = literal.length();
                        if (!isSet(opts, IGNORE_CASE)) {
                            if (dx > 0) {
                                if (limit-offset < literallen)
                                    return -offset-1;
                                if (literallen > 0 && target.setIndex(offset) != literal.charAt(0))
                                    return -offset-1;




                                if (!regionMatches(target, offset, limit, literal, literallen))
                                    return -offset-1;

                                offset += literallen;
                            } else {
                                if (!regionMatches(target, offset-literallen, limit,
                                                   literal, literallen))
                                    return -offset-1;
                                offset -= literallen;
                            }
                        } else {
                            if (dx > 0) {
                                if (!regionMatchesIgnoreCase(target, offset, limit,
                                                             literal, literallen))
                                    return -offset-1;
                                offset += literallen;
                            } else {
                                if (!regionMatchesIgnoreCase(target, offset-literallen, limit,
                                                             literal, literallen))
                                    return -offset-1;
                                offset -= literallen;
                            }
                        }



                }
                op = op.next;
                break;

              case Op.CLOSURE:
                Op childOp = op.getChild();



                if (childOp.type == Op.CHAR && childOp.next == op && dx > 0) { // a*
                    int startOffset = offset;
                    int ch = childOp.getData();
                    if (dx > 0) {
                        if (isSet(opts, IGNORE_CASE)) {
                            while (offset < limit && matchIgnoreCase(ch, target.setIndex(offset)))
                                offset ++;
                        } else {
                            while (offset < limit && ch == target.setIndex(offset))
                                offset ++;
                        }
                        op = op.next;
                        int ret;



                        while ((ret = this.matchCharacterIterator(con,op,offset,dx,opts)) < 0) {



                            if (offset <= startOffset) break;
                            offset --;
                        }



                        return ret;
                    } else {
                        if (isSet(opts, IGNORE_CASE)) {
                            while (--offset < limit && offset >= 0 && matchIgnoreCase(ch, target.setIndex(offset))); // Empty loop
                        } else {
                            while (--offset < limit && offset >= 0 && ch == target.setIndex(offset)); // Empty loop
                        }
                        op = op.next;
                                // offset points a character that does not match ch.
                        int ret;



                        while ((ret = this.matchCharacterIterator(con,op,++offset,dx,opts)) < 0) {



                            if (offset >= startOffset) break;
                        }



                        return ret;
                    }

                } else if (childOp.type == Op.DOT && childOp.next == op) { // .*
                    throw new RuntimeException("Internal Error: Non-unified .*");

                } else if ((childOp.type == Op.RANGE || childOp.type == Op.NRANGE)
                           && childOp.next == op) { // [...]*
                    throw new RuntimeException("Internal Error: Non-unified [...]*");

                } else { // <anything>*
                    /*
                     * Saves current position to avoid
                     * zero-width repeats.
                     */
                    int id = op.getData();
                    if (id >= 0) {
                        int previousOffset = con.offsets[id];
                        if (previousOffset < 0 || previousOffset != offset) {
                            con.offsets[id] = offset;
                        } else {
                            con.offsets[id] = -1;
                            op = op.next;
                            break;
                        }
                    }

                    int ret = this.matchCharacterIterator(con,op.getChild(),offset,dx,opts);
                    if (id >= 0) con.offsets[id] = -1;
                    if (ret >= 0) return ret;
                    op = op.next;
                }
                break;

              case Op.DOT_CLOSURE: // .*
                {
                    int startOffset = offset;
                    int ret;
                    if (dx > 0) {
                        if (isSet(opts, SINGLE_LINE)) {
                            while (offset < limit) {
                                int ch = target.setIndex(offset++);
                                if (isHighSurrogate(ch) && offset < limit)
                                    offset ++;
                            }
                        } else {
                            while (offset < limit) {
                                int ch = target.setIndex(offset++);
                                if (ch < 0x100) {
                                    if (ch == LINE_FEED || ch == CARRIAGE_RETURN)
                                        break;
                                } else {
                                    if (isHighSurrogate(ch) && offset < limit)
                                        offset ++;
                                    else if (isEOLChar(ch))
                                        break;
                                }
                            }
                        }
                                // offset points the next of valid character for .
                        int nextChar = op.getData();
                        op = op.next;
                        if (nextChar >= 0) {
                            ret = -offset-1;
                            do {
                                if (offset < limit && target.setIndex(offset) == nextChar
                                    && (ret = this.matchCharacterIterator(con,op,offset,dx,opts)) >= 0)
                                    break;
                                if (offset <= startOffset) break;
                                offset --;
                                if (isLowSurrogate(target.setIndex(offset))
                                    && offset > startOffset)
                                    offset --;
                            } while (true);
                        } else {
                            while ((ret = this.matchCharacterIterator(con,op,offset,dx,opts)) < 0) {
                                if (offset <= startOffset) break;
                                offset --;
                                if (isLowSurrogate(target.setIndex(offset))
                                    && offset > startOffset)
                                    offset --;
                            }
                        }
                    } else { // DOT_CLOSURE, dx < 0
                        while (--offset < limit && offset >= 0) {
                            int ch = target.setIndex(offset);
                            if (isLowSurrogate(ch) && offset-1 >= 0)
                                offset --;
                            if (!isSet(opts, SINGLE_LINE) && !isEOLChar(ch))
                                break;
                        }
                        op = op.next;
                        do {
                            offset++;
                            if (offset < limit && isHighSurrogate(target.setIndex(offset)))
                                offset++;
                            if ((ret = this.matchCharacterIterator(con,op,++offset,dx,opts)) >= 0)
                                break;
                        } while (offset < startOffset);
                    }
                    return ret;
                }

              case Op.RANGE_CLOSURE: // [...]*
                {
                    RangeToken tok = op.getToken();
                    int startOffset = offset;
                    int ret;
                    if (dx > 0) {
                        if (isSet(opts, IGNORE_CASE)) {
                            tok = tok.getCaseInsensitiveToken();
                            while (offset < limit) {
                                int ch = target.setIndex(offset);
                                if (isHighSurrogate(ch) && offset+1 < limit)
                                    ch = composeFromSurrogates(ch, target.setIndex(++offset));
                                if (!tok.match(ch)) {
                                    if (ch > BMP_MAX) break;
                                    char uch;
                                    if (!tok.match(uch = Character.toUpperCase((char)ch))
                                        && !tok.match(Character.toLowerCase(uch)))
                                        break;
                                }
                                offset ++;
                            }
                        } else {
                            while (offset < limit) {
                                int ch = target.setIndex(offset);
                                if (isHighSurrogate(ch) && offset+1 < limit)
                                    ch = composeFromSurrogates(ch, target.setIndex(++offset));
                                if (!tok.match(ch)) break;
                                offset ++;
                            }
                        }
                        int nextChar = op.getData();
                        op = op.next;
                        if (nextChar >= 0) {
                            ret = -offset-1;
                            do {
                                if (offset < limit && target.setIndex(offset) == nextChar
                                    && (ret = this.matchCharacterIterator(con,op,offset,dx,opts)) >= 0)
                                    break;
                                if (offset <= startOffset) break;
                                offset --;
                                if (isLowSurrogate(target.setIndex(offset))
                                    && offset > startOffset)
                                    offset --;
                            } while (true);
                        } else {
                            while ((ret = this.matchCharacterIterator(con,op,offset,dx,opts)) < 0) {
                                if (offset <= startOffset) break;
                                offset --;
                                if (isLowSurrogate(target.setIndex(offset))
                                    && offset > startOffset)
                                    offset --;
                            }
                        }
                    } else { // dx < 0
                        if (!isSet(opts, IGNORE_CASE)) {
                            while (--offset < limit && offset >= 0) {
                                int ch = target.setIndex(offset);
                                if (isLowSurrogate(ch) && offset-1 >= 0)
                                    ch = composeFromSurrogates(target.setIndex(--offset), ch);
                                if (!tok.match(ch))
                                    break;
                            }
                        } else {
                            tok = tok.getCaseInsensitiveToken();
                            while (--offset < limit && offset >= 0) {
                                int ch = target.setIndex(offset);
                                if (isLowSurrogate(ch) && offset-1 >= 0)
                                    ch = composeFromSurrogates(target.setIndex(--offset), ch);
                                if (!tok.match(ch)) {
                                    if (ch > BMP_MAX) break;
                                    char uch;
                                    if (!tok.match(uch = Character.toUpperCase((char)ch))
                                        && !tok.match(Character.toLowerCase(uch)))
                                        break;
                                }
                            }
                        }
                        op = op.next;
                        do {
                            offset++;
                            if (offset < limit && isHighSurrogate(target.setIndex(offset)))
                                offset++;
                            if ((ret = this.matchCharacterIterator(con,op,++offset,dx,opts)) >= 0)
                                break;
                        } while (offset < startOffset);
                    }
                    return ret;
                }

              case Op.QUESTION:
                {
                    int ret = this.matchCharacterIterator(con,op.getChild(),offset,dx,opts);
                    if (ret >= 0) return ret;
                    op = op.next;
                }
                break;

              case Op.NONGREEDYCLOSURE:
              case Op.NONGREEDYQUESTION:
                {
                    int ret = this.matchCharacterIterator(con,op.next,offset,dx,opts);
                    if (ret >= 0) return ret;
                    op = op.getChild();
                }
                break;

              case Op.UNION:
                for (int i = 0; i < op.size(); i ++) {
                    int ret = this.matchCharacterIterator(con,op.elementAt(i),offset,dx,opts);
                    //System.err.println("UNION: "+i+", ret="+ret);
                    if (ret >= 0) return ret;
                }
                return -offset-1;

              case Op.CAPTURE:
                int refno = op.getData();
                if (con.match != null && refno > 0) {
                    int save = con.match.beginpos[refno];
                    con.match.beginpos[refno] = offset;
                    int ret = this.matchCharacterIterator(con,op.next,offset,dx,opts);
                    if (ret < 0) con.match.beginpos[refno] = save;
                    return ret;
                } else if (con.match != null && refno < 0) {
                    int index = -refno;
                    int save = con.match.endpos[index];
                    con.match.endpos[index] = offset;
                    int ret = this.matchCharacterIterator(con,op.next,offset,dx,opts);
                    if (ret < 0) con.match.endpos[index] = save;
                    return ret;
                }
                op = op.next;
                break;

              case Op.LOOKAHEAD:
                {
                    int ret = this.matchCharacterIterator(con,op.getChild(),offset,1,opts);
                    if (0 > ret)
                        return ret;
                }
                op = op.next;
                break;
              case Op.NEGATIVELOOKAHEAD:
                {
                    int ret = this.matchCharacterIterator(con,op.getChild(),offset,1,opts);
                    if (0 <= ret)
                        return -offset-1;
                }
                op = op.next;
                break;
              case Op.LOOKBEHIND:
                {
                    int ret = this.matchCharacterIterator(con,op.getChild(),offset,-1,opts);
                    if (0 > ret)
                        return ret;
                }
                op = op.next;
                break;
              case Op.NEGATIVELOOKBEHIND:
                {
                    int ret = this.matchCharacterIterator(con,op.getChild(),offset,-1,opts);
                    if (0 <= ret)
                        return -offset-1;
                }
                op = op.next;
                break;

              case Op.INDEPENDENT:
                {
                    int ret = this.matchCharacterIterator(con,op.getChild(),offset,dx,opts);
                    if (ret < 0)
                        return ret;
                    offset = ret;
                    op = op.next;
                }
                break;

              case Op.MODIFIER:
                {
                    int localopts = opts;
                    localopts |= op.getData();
                    localopts &= ~op.getData2();
                    //System.err.println("MODIFIER: "+Integer.toString(opts, 16)+" -> "+Integer.toString(localopts, 16));
                    int ret = this.matchCharacterIterator(con,op.getChild(),offset,dx,localopts);
                    if (ret < 0) return ret;
                    offset = ret;
                    op = op.next;
                }
                break;

              case Op.CONDITION:
                {
                    Op.ConditionOp cop = (Op.ConditionOp)op;
                    boolean matchp = false;
                    if (cop.refNumber > 0) {
                        if (cop.refNumber >= this.nofparen)
                            throw new RuntimeException("Internal Error: Reference number must be more than zero: "+cop.refNumber);
                        matchp = con.match.getBeginning(cop.refNumber) >= 0
                            && con.match.getEnd(cop.refNumber) >= 0;
                    } else {
                        matchp = 0 <= this.matchCharacterIterator(con,cop.condition,offset,dx,opts);
                    }

                    if (matchp) {
                        op = cop.yes;
                    } else if (cop.no != null) {
                        op = cop.no;
                    } else {
                        op = cop.next;
                    }
                }
                break;

              default:
                throw new RuntimeException("Internal Error: Unknown operation type: "+op.type);
            } // switch (op.type)
        } // while
    }

    private static final int getPreviousWordType(CharacterIterator target, int begin, int end,
                                                 int offset, int opts) {
        int ret = getWordType(target, begin, end, --offset, opts);
        while (ret == WT_IGNORE)
            ret = getWordType(target, begin, end, --offset, opts);
        return ret;
    }

    private static final int getWordType(CharacterIterator target, int begin, int end,
                                         int offset, int opts) {
        if (offset < begin || offset >= end) return WT_OTHER;
        return getWordType0(target.setIndex(offset), opts);
    }
    private static final boolean regionMatches(CharacterIterator target, int offset, int limit,
                                               String part, int partlen) {
        if (offset < 0) return false;
        if (limit-offset < partlen)
            return false;
        int i = 0;
        while (partlen-- > 0) {
            if (target.setIndex(offset++) != part.charAt(i++))
                return false;
        }
        return true;
    }

    private static final boolean regionMatches(CharacterIterator target, int offset, int limit,
                                               int offset2, int partlen) {
        if (offset < 0) return false;
        if (limit-offset < partlen)
            return false;
        int i = offset2;
        while (partlen-- > 0) {
            if (target.setIndex(offset++) != target.setIndex(i++))
                return false;
        }
        return true;
    }

    /**
     */
    private static final boolean regionMatchesIgnoreCase(CharacterIterator target, int offset, int limit,
                                                         String part, int partlen) {
        if (offset < 0) return false;
        if (limit-offset < partlen)
            return false;
        int i = 0;
        while (partlen-- > 0) {
            char ch1 = target.setIndex(offset++);
            char ch2 = part.charAt(i++);
            if (ch1 == ch2)
                continue;
            char uch1 = Character.toUpperCase(ch1);
            char uch2 = Character.toUpperCase(ch2);
            if (uch1 == uch2)
                continue;
            if (Character.toLowerCase(uch1) != Character.toLowerCase(uch2))
                return false;
        }
        return true;
    }

    private static final boolean regionMatchesIgnoreCase(CharacterIterator target, int offset, int limit,
                                                         int offset2, int partlen) {
        if (offset < 0) return false;
        if (limit-offset < partlen)
            return false;
        int i = offset2;
        while (partlen-- > 0) {
            char ch1 = target.setIndex(offset++);
            char ch2 = target.setIndex(i++);
            if (ch1 == ch2)
                continue;
            char uch1 = Character.toUpperCase(ch1);
            char uch2 = Character.toUpperCase(ch2);
            if (uch1 == uch2)
                continue;
            if (Character.toLowerCase(uch1) != Character.toLowerCase(uch2))
                return false;
        }
        return true;
    }


    // ================================================================

    /**
     * A regular expression.
     * @serial
     */
    String regex;
    /**
     * @serial
     */
    int options;

    /**
     * The number of parenthesis in the regular expression.
     * @serial
     */
    int nofparen;
    /**
     * Internal representation of the regular expression.
     * @serial
     */
    Token tokentree;

    boolean hasBackReferences = false;

    transient int minLength;
    transient int maxLength = Integer.MIN_VALUE;
    transient int minUnicodeLength = Integer.MIN_VALUE;
    transient int maxUnicodeLength = Integer.MIN_VALUE;
    transient Op operations = null;
    transient int numberOfClosures;
    transient Context context = null;
    transient RangeToken firstChar = null;

    transient String fixedString = null;
    transient int fixedStringOptions;
    transient BMPattern fixedStringTable = null;
    transient boolean fixedStringOnly = false;
    transient int tried = 0;
    transient int matched = 0;


    static final class Context {
        CharacterIterator ciTarget;
        String strTarget;
        char[] charTarget;
        int head;
        int start;
        int limit;
        int length;
        Match match;
        boolean inuse = false;
        int[] offsets;
        int dx;
        Vector intarrays = null;

        Context() {
        }

        private void resetCommon(int nofclosures) {
            this.length = this.limit-this.head;
            this.inuse = true;
            this.match = null;
            this.dx = 1;
            if (this.offsets == null || this.offsets.length != nofclosures)
                this.offsets = new int[nofclosures];
            for (int i = 0; i < nofclosures; i ++) this.offsets[i] = -1;
        }
        void reset(CharacterIterator target, int head, int start, int limit, int nofclosures) {
            this.ciTarget = target;
            this.head = head;
            this.start = start;
            this.limit = limit;
            this.resetCommon(nofclosures);
        }
        void reset(String target, int head, int start, int limit, int nofclosures) {
            this.strTarget = target;
            this.head = head;
            this.start = start;
            this.limit = limit;
            this.resetCommon(nofclosures);
        }
        void reset(char[] target, int head, int start, int limit, int nofclosures) {
            this.charTarget = target;
            this.head = head;
            this.start = start;
            this.limit = limit;
            this.resetCommon(nofclosures);
        }

        int[] getIntArray() {
            if (this.intarrays == null) this.intarrays = new Vector();
            int size = this.intarrays.size();
            if (size == 0)
                return new int[10];
            size--;
            int[] ret = (int[])this.intarrays.elementAt(size);
            this.intarrays.removeElementAt(size);
            return ret;
        }
        void registerIntArray(int[] ints) {
            if (this.intarrays == null) this.intarrays = new Vector();
            this.intarrays.addElement(ints);
        }
    }

    /**
     * Prepares for matching.  This method is called just before starting matching.
     */
    void prepare() {
        if (Op.COUNT) Op.nofinstances = 0;
        long compileStart = System.currentTimeMillis();
        this.compile(this.tokentree);
        long compileEnd = System.currentTimeMillis();
        if (DEBUG)
            System.err.println("DEBUG: Compile: "+(compileEnd-compileStart)+" [msec]");
        /*
        if  (this.operations.type == Op.CLOSURE && this.operations.getChild().type == Op.DOT) { // .*
            Op anchor = Op.createAnchor(isSet(this.options, SINGLE_LINE) ? 'A' : '@');
            anchor.next = this.operations;
            this.operations = anchor;
        }
        */
        if (Op.COUNT) System.err.println("DEBUG: The number of operations: "+Op.nofinstances);

        this.minLength = this.tokentree.getMinLength();
        //this.maxLength = this.tokentree.getMaxLength();
        long minmaxEnd = System.currentTimeMillis();
        if (DEBUG)
            System.err.println("DEBUG: MinMax: "+(minmaxEnd-compileEnd)+" [msec]");

        this.firstChar = null;
        if (!isSet(this.options, PROHIBIT_HEAD_CHARACTER_OPTIMIZATION)
            && !isSet(this.options, XMLSCHEMA_MODE)) {
            RangeToken firstChar = Token.createRange();
            int fresult = this.tokentree.analyzeFirstCharacter(firstChar, this.options);
            if (fresult == Token.FC_TERMINAL) {
                firstChar.compactRanges();
                this.firstChar = firstChar;
                if (DEBUG)
                    System.err.println("DEBUG: Use the first character optimization: "+firstChar);
            }
        }

        if (this.operations != null
            && (this.operations.type == Op.STRING || this.operations.type == Op.CHAR)
            && this.operations.next == null) {
            if (DEBUG)
                System.err.print(" *** Only fixed string! *** ");
            this.fixedStringOnly = true;
            if (this.operations.type == Op.STRING)
                this.fixedString = this.operations.getString();
            else if (this.operations.getData() >= 0x10000) { // Op.CHAR
                this.fixedString = REUtil.decomposeToSurrogates(this.operations.getData());
            } else {
                char[] ac = new char[1];
                ac[0] = (char)this.operations.getData();
                this.fixedString = new String(ac);
            }
            this.fixedStringOptions = this.options;
            this.fixedStringTable = new BMPattern(this.fixedString, 256,
                                                  isSet(this.fixedStringOptions, IGNORE_CASE0));
        } else if (!isSet(this.options, PROHIBIT_FIXED_STRING_OPTIMIZATION)
                   && !isSet(this.options, XMLSCHEMA_MODE)) {
            Token.FixedStringContainer container = new Token.FixedStringContainer();
            this.tokentree.findFixedString(container, this.options);
            this.fixedString = container.token == null ? null : container.token.getString();
            this.fixedStringOptions = container.options;
            if (this.fixedString != null && this.fixedString.length() < 2)
                this.fixedString = null;
            // This pattern has a fixed string of which length is more than one.
            if (this.fixedString != null) {
                this.fixedStringTable = new BMPattern(this.fixedString, 256,
                                                      isSet(this.fixedStringOptions, IGNORE_CASE0));
                if (DEBUG) {
                    System.err.println("DEBUG: The longest fixed string: length="
                                       +this.fixedString.length()
                                       +" option="
                                       +REUtil.createOptionString(this.fixedStringOptions));
                    System.err.print("DEBUG:         String: ");
                    REUtil.dumpString(this.fixedString);
                }
            }
        }
        long optimizeEnd = System.currentTimeMillis();
        if (DEBUG)
            System.err.println("DEBUG: Optimize: "+(optimizeEnd-minmaxEnd)+" [msec]");
    }

    /**
     * An option.
     * If you specify this option, <span class="REGEX"><kbd>(</kbd><var>X</var><kbd>)</kbd></span>
     * captures matched text, and <span class="REGEX"><kbd>(:?</kbd><var>X</var><kbd>)</kbd></span>
     * does not capture.
     *
    static final int MARK_PARENS = 1<<0;
     */

    /**
     * "i"
     */
    static final int IGNORE_CASE0 = 1<<1;

    /**
     * "s"
     */
    static final int SINGLE_LINE = 1<<2;

    /**
     * "m"
     */
    static final int MULTIPLE_LINES = 1<<3;

    /**
     * "x"
     */
    static final int EXTENDED_COMMENT = 1<<4;

    /**
     * This option redefines <span class="REGEX"><kbd>\d \D \w \W \s \S</kbd></span>.
     *
     */
    static final int USE_UNICODE_CATEGORY = 1<<5; // "u"

    /**
     * An option.
     * This enables to process locale-independent word boundary for <span class="REGEX"><kbd>\b \B \&lt; \></kbd></span>.
     * <p>By default, the engine considers a position between a word character
     * (<span class="REGEX"><Kbd>\w</kbd></span>) and a non word character
     * is a word boundary.
     * <p>By this option, the engine checks word boundaries with the method of
     * 'Unicode Regular Expression Guidelines' Revision 4.
     *
     */
    static final int UNICODE_WORD_BOUNDARY = 1<<6; // "w"

    /**
     * "H"
     */
    static final int PROHIBIT_HEAD_CHARACTER_OPTIMIZATION = 1<<7;
    /**
     * "F"
     */
    static final int PROHIBIT_FIXED_STRING_OPTIMIZATION = 1<<8;
    /**
     * "X". XML Schema mode.
     */
    static final int XMLSCHEMA_MODE = 1<<9;
    /**
     * ",".
     */
    static final int SPECIAL_COMMA = 1<<10;
    /**
     * "I"
     */
    static final int IGNORE_CASE = 1<<11;
    /**
     * "P".
     */
    static final int ERROR_POSITION = 1<<12;



    private static final boolean isSet(int options, int flag) {
        return (options & flag) == flag;
    }

    /**
     * Creates a new RegularExpression instance.
     *
     * @param regex A regular expression
     * @exception com.ibm.regex.ParseException <VAR>regex</VAR> is not conforming to the syntax.
     */
    public RegularExpression(String regex) throws ParseException {
        this.setPattern(null, null, regex, 0);
    }

    /**
     * Creates a new RegularExpression instance with options.
     *
     * @param regex A regular expression
     * @param options A String consisted of "i" "m" "s" "u" "w" "," "X"
     * @exception com.ibm.regex.ParseException <VAR>regex</VAR> is not conforming to the syntax.
     */
    public RegularExpression(String regex, String options) throws ParseException {
        this.setPattern(null, null, regex, options);
    }

    /**
     * Creates a new RegularExpression instance with parser's locale and options.
     *
     * @deperecated Use RegularExpression(Locale, Hashtable, String, String)
     */
    public RegularExpression(Locale locale, String regex, String options)
        throws ParseException {
        this.setPattern(locale, null, regex, options);
    }

    /**
     * Creates a new RegularExpression instance with parser's locale and options.
     *
     * @param locale A locale of the parser's error messages; <code>null</code> if you want to use default locale.
     * @param addcc A hashtable of that keys are property names and values are instances of <code>CharacterClass</code>; This instance is used in <code>matches()</code> method.  Don't modify this instance after calling this constructor.
     * @param regex A regular expression
     * @param options A String consisted of "i" "m" "s" "u" "w" "," "X"
     * @exception com.ibm.regex.ParseException <VAR>regex</VAR> is not conforming to the syntax.
     * @see com.ibm.regex.CharacterClass
     */
    public RegularExpression(Locale locale, Hashtable addcc, String regex, String options)
        throws ParseException {
        this.setPattern(locale, addcc, regex, options);
    }

    /*
     *
    RegularExpression(String regex, Token tok, int parens, boolean hasBackReferences, int options) {
        this.regex = regex;
        this.tokentree = tok;
        this.nofparen = parens;
        this.options = options;
        this.hasBackReferences = hasBackReferences;
    }
    */

    /**
     * Sets new pattern.  The parser used default locale, and the options is not changed.
     */
    public void setPattern(String newPattern) throws ParseException {
        this.setPattern(null, null, newPattern, this.options);
    }

    /**
     * Sets new pattern.
     *
     * @param locale a locale of the parser's error messages; <code>null</code> if you want to use default locale.
     * @param newPattern A regular expression
     * @param options A String consisted of "i" "m" "s" "u" "w" "," "X"
     * @deprecated Use setPattern(Locale, Hashtable, String, String)
     */
    public void setPattern(Locale locale, String newPattern, String options)
        throws ParseException {
        this.setPattern(locale, null, newPattern, REUtil.parseOptions(options));
    }

    /**
     * Sets new pattern.
     *
     * @param locale A locale of the parser's error messages; <code>null</code> if you want to use default locale.
     * @param addcc A hashtable of that keys are property names and values are instances of <code>CharacterClass</code>; This instance is used in <code>matches()</code> method.  Don't modify this instance after calling this constructor.
     * @param newPattern A regular expression
     * @param options A String consisted of "i" "m" "s" "u" "w" "," "X"
     */
    public void setPattern(Locale locale, Hashtable addcc, String newPattern, String options)
        throws ParseException {
        this.setPattern(locale, addcc, newPattern, REUtil.parseOptions(options));
    }

    private void setPattern(Locale locale, Hashtable addcc, String newPattern, int options) throws ParseException {
        this.regex = newPattern;
        this.options = options;
        if (locale == null) locale = Locale.getDefault();
        long parseStart = System.currentTimeMillis();
        RegexParser rp = this.isSet(this.options, RegularExpression.XMLSCHEMA_MODE)
            ? new ParserForXMLSchema(locale) : new RegexParser(locale);
        this.tokentree = rp.parse(this.regex, this.options, addcc);
        this.nofparen = rp.parennumber;
        this.hasBackReferences = rp.hasBackReferences;
        if (DEBUG)
            System.err.println("DEBUG: Parsing time: "
                               +(System.currentTimeMillis()-parseStart)+" [msec]");

        this.operations = null;
        this.context = null;
    }


    /**
     * Returns a pattern string.
     * The pattern string is the same that was specified at a constructor or <code>setPattern()</code>.
     */
    public String getPattern() {
        return this.regex;
    }

    /**
     * Represents this instence in String.
     */
    public String toString() {
        return this.tokentree.toString(this.options);
    }

    /**
     * Returns a option string.
     * The order of letters in it may be different from a string specified
     * in a constructor or <code>setPattern()</code>.
     *
     */
    public String getOptions() {
        return REUtil.createOptionString(this.options);
    }

    /**
     *  Return true if patterns are the same and the options are equivalent.
     */
    public boolean equals(Object obj) {
        if (obj == null) return false;
        if (!(obj instanceof RegularExpression))
            return false;
        RegularExpression r = (RegularExpression)obj;
        return this.regex.equals(r.regex) && this.options == r.options;
    }

    boolean equals(String pattern, int options) {
        return this.regex.equals(pattern) && this.options == options;
    }

    /**
     *
     */
    public int hashCode() {
        return (this.regex+"/"+this.getOptions()).hashCode();
    }

    /**
     * Return the number of regular expression groups.
     * This method returns 1 when the regular expression has no capturing-parenthesis.
     *
     */
    public int getNumberOfGroups() {
        return this.nofparen;
    }

    /**
     * Returns minimum length of matching string in Java char unit.
     */
    public int getMinLength() {
        if (this.operations == null)
            synchronized (this) {
                if (this.operations == null)
                    this.prepare();
            }
        return this.minLength;
    }

    /**
     * Returns minimum length of matching string in Unicode unit.
     */
    public int getMinUnicodeLength() {
        if (this.operations == null)
            synchronized (this) {
                if (this.operations == null)
                    this.prepare();
            }
        if (this.minUnicodeLength == Integer.MIN_VALUE)
            this.minUnicodeLength = this.tokentree.getMinUnicodeLength();
        return this.minUnicodeLength;
    }

    /**
     * Returns maximum length of matching string in Java char unit.
     * If the mximum length is unbounded, this method returns -1.
     */
    public int getMaxLength() {
        if (this.operations == null)
            synchronized (this) {
                if (this.operations == null)
                    this.prepare();
            }
        if (this.maxLength == Integer.MIN_VALUE)
            this.maxLength = this.tokentree.getMaxLength();
        return this.maxLength;
    }

    /**
     * Returns maximum length of matching string in Unicde unit.
     * If the mximum length is unbounded, this method returns -1.
     */
    public int getMaxUnicodeLength() {
        if (this.operations == null)
            synchronized (this) {
                if (this.operations == null)
                    this.prepare();
            }
        if (this.maxUnicodeLength == Integer.MIN_VALUE)
            this.maxUnicodeLength = this.tokentree.getMaxUnicodeLength();
        return this.maxUnicodeLength;
    }

    // ================================================================

    private static final int WT_IGNORE = 0;
    private static final int WT_LETTER = 1;
    private static final int WT_OTHER = 2;
    transient static Token wordchar = null;
    private static final int getWordType0(char ch, int opts) {
        if (!isSet(opts, UNICODE_WORD_BOUNDARY)) {
            if (isSet(opts, USE_UNICODE_CATEGORY)) {
                if (RegularExpression.wordchar == null)
                    RegularExpression.wordchar = Token.getRange("IsWord", true);
                return RegularExpression.wordchar.match(ch) ? WT_LETTER : WT_OTHER;
            }
            return isWordChar(ch) ? WT_LETTER : WT_OTHER;
        }

        switch (Character.getType(ch)) {
          case Character.UPPERCASE_LETTER: // L
          case Character.LOWERCASE_LETTER: // L
          case Character.TITLECASE_LETTER: // L
          case Character.MODIFIER_LETTER: // L
          case Character.OTHER_LETTER: // L
          case Character.LETTER_NUMBER: // N
          case Character.DECIMAL_DIGIT_NUMBER: // N
          case Character.OTHER_NUMBER: // N
          case Character.COMBINING_SPACING_MARK: // Mc
            return WT_LETTER;

          case Character.FORMAT: // Cf
          case Character.NON_SPACING_MARK: // Mn
          case Character.ENCLOSING_MARK: // Mc
            return WT_IGNORE;

          case Character.CONTROL: // Cc
            switch (ch) {
              case '\t':
              case '\n':
              case '\u000B':
              case '\f':
              case '\r':
                return WT_OTHER;
              default:
                return WT_IGNORE;
            }

          default:
            return WT_OTHER;
        }
    }

    // ================================================================

    static final int LINE_FEED = 0x000A;
    static final int CARRIAGE_RETURN = 0x000D;
    static final int LINE_SEPARATOR = 0x2028;
    static final int PARAGRAPH_SEPARATOR = 0x2029;
    private static final int BMP_MAX = 0xffff;

    private static final boolean isEOLChar(int ch) {
        return ch == LINE_FEED || ch == CARRIAGE_RETURN || ch == LINE_SEPARATOR
            || ch == PARAGRAPH_SEPARATOR;
    }

    private static final boolean isWordChar(int ch) { // Legacy word characters
        if (ch == '_') return true;
        if (ch < '0') return false;
        if (ch > 'z') return false;
        if (ch <= '9') return true;
        if (ch < 'A') return false;
        if (ch <= 'Z') return true;
        if (ch < 'a') return false;
        return true;
    }

    private static final boolean matchIgnoreCase(int chardata, int ch) {
        if (chardata == ch) return true;
        if (chardata > BMP_MAX || ch > BMP_MAX) return false;
        char uch1 = Character.toUpperCase((char)chardata);
        char uch2 = Character.toUpperCase((char)ch);
        if (uch1 == uch2) return true;
        return Character.toLowerCase(uch1) == Character.toLowerCase(uch2);
    }

    static private final int composeFromSurrogates(int high, int low) {
        return 0x10000 + ((high-0xd800)<<10) + low-0xdc00;
    }

    static private final boolean isLowSurrogate(int ch) {
        return (ch & 0xfc00) == 0xdc00;
    }

    static private final boolean isHighSurrogate(int ch) {
        return (ch & 0xfc00) == 0xd800;
    }

    static private final int searchForNextChar(Op op, int opts) {
        if (isSet(opts, IGNORE_CASE0))
            return -1;
        while (true) {
            if (op == null)
                return -1;
            switch (op.type) {
              case Op.DOT:
              case Op.RANGE:
              case Op.NRANGE:
              case Op.CLOSURE:
              case Op.NONGREEDYCLOSURE:
              case Op.QUESTION:
              case Op.NONGREEDYQUESTION:
              case Op.UNION:
              case Op.BACKREFERENCE:
              case Op.INDEPENDENT:
              case Op.MODIFIER:
              case Op.CONDITION:
              case Op.DOT_CLOSURE:
              case Op.RANGE_CLOSURE:
                return -1;

              case Op.CHAR:
                return op.getData();

              case Op.STRING:
                String literal = op.getString();
                if (literal.length() > 0)
                    return literal.charAt(0);
                return -1;

              case Op.ANCHOR:
              case Op.CAPTURE:
              case Op.LOOKAHEAD:
              case Op.NEGATIVELOOKAHEAD:
              case Op.LOOKBEHIND:
              case Op.NEGATIVELOOKBEHIND:
                op = op.next;
                break;
            }
        }
    }
}
