/*
 * (C) Copyright IBM Corp. 1999,2000,2001  All rights reserved.
 *
 * US Government Users Restricted Rights Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

package com.ibm.regex;

import java.text.CharacterIterator;
import java.util.Vector;

/**
 *
 * @version $Id: REUtil.java,v 1.17 2004/12/09 07:55:13 kent Exp $
 * @author TAMURA Kent &lt;kent@trl.ibm.co.jp&gt;
 */
public final class REUtil {
    private REUtil() {
    }

    static final int composeFromSurrogates(int high, int low) {
        return 0x10000 + ((high-0xd800)<<10) + low-0xdc00;
    }

    static final boolean isLowSurrogate(int ch) {
        return (ch & 0xfc00) == 0xdc00;
    }

    static final boolean isHighSurrogate(int ch) {
        return (ch & 0xfc00) == 0xd800;
    }

    static final String decomposeToSurrogates(int ch) {
        char[] chs = new char[2];
        ch -= 0x10000;
        chs[0] = (char)((ch>>10)+0xd800);
        chs[1] = (char)((ch&0x3ff)+0xdc00);
        return new String(chs);
    }

    static final String substring(CharacterIterator iterator, int begin, int end) {
        char[] src = new char[end-begin];
        for (int i = 0;  i < src.length;  i ++)
            src[i] = iterator.setIndex(i+begin);
        return new String(src);
    }

    // ================================================================

    static final int getOptionValue(int ch) {
        int ret = 0;
        switch (ch) {
          case 'i':
            ret = RegularExpression.IGNORE_CASE0;
            break;
          case 'I':
            ret = RegularExpression.IGNORE_CASE;
            break;
          case 'm':
            ret = RegularExpression.MULTIPLE_LINES;
            break;
          case 's':
            ret = RegularExpression.SINGLE_LINE;
            break;
          case 'x':
            ret = RegularExpression.EXTENDED_COMMENT;
            break;
          case 'u':
            ret = RegularExpression.USE_UNICODE_CATEGORY;
            break;
          case 'w':
            ret = RegularExpression.UNICODE_WORD_BOUNDARY;
            break;
          case 'F':
            ret = RegularExpression.PROHIBIT_FIXED_STRING_OPTIMIZATION;
            break;
          case 'H':
            ret = RegularExpression.PROHIBIT_HEAD_CHARACTER_OPTIMIZATION;
            break;
          case 'X':
            ret = RegularExpression.XMLSCHEMA_MODE;
            break;
          case 'P':
            ret = RegularExpression.ERROR_POSITION;
            break;
          case ',':
            ret = RegularExpression.SPECIAL_COMMA;
            break;
          default:
        }
        return ret;
    }

    static final int parseOptions(String opts) throws ParseException {
        if (opts == null)  return 0;
        int options = 0;
        for (int i = 0;  i < opts.length();  i ++) {
            int v = getOptionValue(opts.charAt(i));
            if (v == 0)
                throw new ParseException("Unknown Option: "+opts.substring(i), -1);
            options |= v;
        }
        return options;
    }

    static final String createOptionString(int options) {
        StringBuffer sb = new StringBuffer(9);
        if ((options & RegularExpression.PROHIBIT_FIXED_STRING_OPTIMIZATION) != 0)
            sb.append((char)'F');
        if ((options & RegularExpression.PROHIBIT_HEAD_CHARACTER_OPTIMIZATION) != 0)
            sb.append((char)'H');
        if ((options & RegularExpression.XMLSCHEMA_MODE) != 0)
            sb.append((char)'X');
        if ((options & RegularExpression.IGNORE_CASE0) != 0)
            sb.append((char)'i');
        if ((options & RegularExpression.IGNORE_CASE) != 0)
            sb.append((char)'I');
        if ((options & RegularExpression.MULTIPLE_LINES) != 0)
            sb.append((char)'m');
        if ((options & RegularExpression.SINGLE_LINE) != 0)
            sb.append((char)'s');
        if ((options & RegularExpression.USE_UNICODE_CATEGORY) != 0)
            sb.append((char)'u');
        if ((options & RegularExpression.UNICODE_WORD_BOUNDARY) != 0)
            sb.append((char)'w');
        if ((options & RegularExpression.EXTENDED_COMMENT) != 0)
            sb.append((char)'x');
        if ((options & RegularExpression.ERROR_POSITION) != 0)
            sb.append((char)'P');
        if ((options & RegularExpression.SPECIAL_COMMA) != 0)
            sb.append((char)',');
        return sb.toString().intern();
    }

    // ================================================================

    static String stripExtendedComment(String regex) {
        int len = regex.length();
        StringBuffer buffer = new StringBuffer(len);
        int offset = 0;
        while (offset < len) {
            int ch = regex.charAt(offset++);
                                                // Skips a white space.
            if (ch == '\t' || ch == '\n' || ch == '\f' || ch == '\r' || ch == ' ')
                continue;

            if (ch == '#') {                    // Skips chracters between '#' and a line end.
                while (offset < len) {
                    ch = regex.charAt(offset++);
                    if (ch == '\r' || ch == '\n')
                        break;
                }
                continue;
            }

            int next;                           // Strips an escaped white space.
            if (ch == '\\' && offset < len) {
                if ((next = regex.charAt(offset)) == '#'
                    || next == '\t' || next == '\n' || next == '\f'
                    || next == '\r' || next == ' ') {
                    buffer.append((char)next);
                    offset ++;
                } else {                        // Other escaped character.
                    buffer.append((char)'\\');
                    buffer.append((char)next);
                    offset ++;
                }
            } else                              // As is.
                buffer.append((char)ch);
        }
        return buffer.toString();
    }

    // ================================================================

    /**
     * Sample entry.
     * <div>Usage: <KBD>com.ibm.regex.REUtil &lt;regex&gt; &lt;string&gt;</KBD></div>
     */
    public static void main(String[] argv) {
        String pattern = null;
        try {
            String options = "";
            String target = null;
            for (int i = 0;  i < argv.length;  i ++) {
                if (argv[i].length() == 0 || argv[i].charAt(0) != '-') {
                    if (pattern == null)
                        pattern = argv[i];
                    else if (target == null)
                        target = argv[i];
                    else
                        System.err.println("Unnecessary: "+argv[i]);
                } else if (argv[i].equals("-i")) {
                    options += "i";
                } else if (argv[i].equals("-m")) {
                    options += "m";
                } else if (argv[i].equals("-s")) {
                    options += "s";
                } else if (argv[i].equals("-u")) {
                    options += "u";
                } else if (argv[i].equals("-w")) {
                    options += "w";
                } else if (argv[i].equals("-X")) {
                    options += "X";
                } else if (argv[i].equals("-,")) {
                    options += ",";
                } else {
                    System.err.println("Unknown option: "+argv[i]);
                }
            }
            if (pattern == null || target == null) {
                System.err.println("com.ibm.regex.REUtil [-i|-m|-s|-u|-w|-X|-,] <pattern> <text>");
                System.exit(1);
            }
            RegularExpression reg = new RegularExpression(pattern, options);
            System.out.println("RegularExpression: "+reg);
            System.out.println("\tMinimum matching length: "+reg.getMinLength());
            System.out.println("\tMaximum matching length: "+reg.getMaxLength());
            Match match = new Match();
            if (reg.matches(target, match)) {
                System.out.println("Result:");
                for (int i = 0;  i < match.getNumberOfGroups();  i ++) {
                    if (i == 0 )  System.out.print("Matched range for the whole pattern: ");
                    else System.out.print("["+i+"]: ");
                    if (match.getBeginning(i) < 0)
                        System.out.println("-1");
                    else {
                        System.out.print(match.getBeginning(i)+", "+match.getEnd(i)+", ");
                        System.out.println("\""+match.getCapturedText(i)+"\"");
                    }
                }
            } else
                System.out.println("Result: No match");
        } catch (ParseException pe) {
            if (pattern == null) {
                pe.printStackTrace();
            } else {
                System.err.println("com.ibm.regex.ParseException: "+pe.getMessage());
                String indent = "        ";
                System.err.println(indent+pattern);
                int loc = pe.getLocation();
                if (loc >= 0) {
                    System.err.print(indent);
                    for (int i = 0;  i < loc;  i ++)  System.err.print("-");
                    System.err.println("^");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static final int CACHESIZE = 20;
    static RegularExpression[] regexCache = new RegularExpression[CACHESIZE];
    /**
     * Creates a RegularExpression instance.
     * This method caches created instances.
     *
     * <p>The cache keeps 20 instances.  If you uses many <code>RegularExpression</code>
     * instances, you has better implement another cache.
     *
     * @see com.ibm.regex.RegularExpression#RegularExpression(java.lang.String, java.lang.String)
     */
    public static RegularExpression createRegex(String pattern, String options)
        throws ParseException {
        RegularExpression re = null;
        int intOptions = REUtil.parseOptions(options);
        synchronized (REUtil.regexCache) {
            int i;
            for (i = 0;  i < REUtil.CACHESIZE;  i ++) {
                RegularExpression cached = REUtil.regexCache[i];
                if (cached == null) {
                    i = -1;
                    break;
                }
                if (cached.equals(pattern, intOptions)) {
                    re = cached;
                    break;
                }
            }
            // Substitutes recently used instance to regexCache[0]
            if (re != null) {
                // Requeted pattern exists in the cache.
                if (i != 0) {
                    // Move 0 ~ i-1 to 1 ~ i
                    System.arraycopy(REUtil.regexCache, 0, REUtil.regexCache, 1, i);
                    REUtil.regexCache[0] = re;
                }
            } else {
                // Requeted pattern does not exist in the cache.
                re = new RegularExpression(pattern, options);
                // Move 0 ~ CACHESIZE-2 to 1 ~ CACHESIZE-1
                System.arraycopy(REUtil.regexCache, 0,
                                 REUtil.regexCache, 1, REUtil.CACHESIZE-1);
                REUtil.regexCache[0] = re;
            }
        }
        return re;
    }

    /**
     * Checkes whether the <var>target</var> contains the <var>pattern</var>.
     *
     * <p>This method uses <code>createRegex()</code>.
     *
     * @param pattern A regular expression
     * @param target
     * @see #createRegex
     * @see com.ibm.regex.RegularExpression#matches(java.lang.String)
     */
    public static boolean matches(String pattern, String target) throws ParseException {
        return REUtil.createRegex(pattern, null).matches(target);
    }

    /**
     * Checkes whether the <var>target</var> contains the <var>pattern</var>.
     *
     * <p>This method uses <code>createRegex()</code>.
     *
     * @param pattern A regular expression
     * @param options Regular expression options.  See <a href="RegularExpression.html#OPTIONS">Options</a>.
     * @param target 
     * @see #createRegex
     * @see com.ibm.regex.RegularExpression#matches(java.lang.String)
     */
    public static boolean matches(String pattern, String options, String target) throws ParseException {
        return REUtil.createRegex(pattern, options).matches(target);
    }

    // ================================================================
    // String processings

    /**
     * Eacapes special characters in <var>literal</var> by <kbd>\</kbd>.
     */
    public static String quoteMeta(String literal) {
        int len = literal.length();
        StringBuffer buffer = null;
        for (int i = 0;  i < len;  i ++) {
            char ch = literal.charAt(i);
            if (".*+?{[()|\\^$".indexOf(ch) >= 0) {
                if (buffer == null) {
                    buffer = new StringBuffer(i+(len-i)*2);
                    if (i > 0)  buffer.append(literal.substring(0, i));
                }
                buffer.append((char)'\\');
                buffer.append(ch);
            } else if (buffer != null)
                buffer.append(ch);
        }
        return buffer != null ? buffer.toString() : literal;
    }

    /**
     * Count length of specified string in <strong>Unicode unit</strong>.
     * A surrogate pair is counted as 1.
     */
    public static int unicodeLength(String str) {
        int jlength = str.length();
        int ulength = 0;
        for (int i = 0;  i < jlength;  i++) {
            int ch = str.charAt(i);
            if (isHighSurrogate(ch)
                && i+1 < jlength && isLowSurrogate(str.charAt(i+1)))
                i++;
            ulength++;
        }
        return ulength;
    }

    // ================================================================
    // Substitute
    //

    /**
     * Searches <var>source</var> for <var>pattern</var>,
     * and replaces matched regions with <var>replacement</var>.
     *
     * <p>If <var>options</var> contains <code>"g"</code>,
     * all matched regions are replaced.  Otherwise,
     * only the first matched region is replaced.
     * With the <code>"g"</code> option,
     * <kbd>\G</kbd> in <var>pattern</var> matches the last match-ending position.
     *
     * <p><kbd>\1</kbd>, <kbd>\2</kbd>, ..., <kbd>\9</kbd>,
     * <kbd>$1</kbd>, ..., <kbd>$9</kbd> and <kbd>${<var>number</var>}</kbd>
     * in <var>replacement</var>
     * are interpreted as captured regions with <var>pattern</var>.
     * The literal <kbd>\</kbd> must be written as <kbd>\\</kbd>
     * (in Java source, write <code>"\\\\"</code>.)
     *
     *
     * @param pattern An expression to be replaced.
     * @param replacement Replacemen string.
     * @param options Regular expression options.  See <a href="RegularExpression.html#OPTIONS">Options</a>.
     * @param source Source string.
     */
    public static String substitute(String pattern, String replacement,
                                    String options, String source) {
        RegularExpression re = createRegex(pattern, omit_g(options));
        StringBuffer result = null;
        boolean global = options.indexOf('g') >= 0;
        return substitute(re, replacement, global, source);
    }

    /**
     * Shorthand for <code>substitute(String <var>pattern</var>, String <var>replacement</var>, String <var>options</var>, String <var>source</var>)</code>.
     *
     * <p><var>mixedPattern</var> parameter for this method is equivalent to:
     * <blockquote>
     * <div><strong><kbd>s/</kbd><var>pattern</var><kbd>/</kbd><var>replacement</var><kbd>/</kbd><var>options</var></strong></div>
     * </blockquote>
     *
     * <p>If you want to use <kbd>/</kbd> in <var>pattern</var> or <var>replacement</var>,
     * write <kbd>\/</kbd> instaed of <kbd>/</kbd>, or use another character for delimiter.
     * The second character of <var>mixedPattern</var> is used for delimiter; for example,
     * <kbd>s%&lt;foo>&lt;/foo>%&lt;foo/>%g</kbd>
     *
     * @param mixedPattern <var>pattern</var>, <var>replacement</var>, and <var>options</var>
     * @param source Source string.
     * @see #substitute(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    public static String substitute(String mixedPattern, String source) {
        int patternLength = mixedPattern.length();
        int index = 0;
        if (mixedPattern.charAt(index) == 's')  index++;
        int delim = mixedPattern.charAt(index++);
        int patternStart = index;
        StringBuffer patternBuffer = null;
        while (index < patternLength) {
            int ch = mixedPattern.charAt(index);
            if (ch == '\\') {
                int ch2 = mixedPattern.charAt(++index);
                if (ch2 == delim) {
                    if (patternBuffer == null) {
                        patternBuffer = new StringBuffer(patternLength);
                        patternBuffer.append(mixedPattern.substring(patternStart, index-1));
                    }
                    patternBuffer.append((char)delim);
                } else {
                    if (patternBuffer != null) {
                        patternBuffer.append((char)'\\');
                        patternBuffer.append((char)ch2);
                    }
                }
            } else if (ch == delim)
                break;
            else if (patternBuffer != null)
                patternBuffer.append((char)ch);
            index++;
        }
        if (index >= patternLength)
            throw new ParseException("No delimiter after the pattern.", index);
        String rawPattern = patternBuffer == null
            ? mixedPattern.substring(patternStart, index) : new String(patternBuffer);


        int replacementStart = ++index;
        StringBuffer replacementBuffer = null;
        while (index < patternLength) {
            int ch = mixedPattern.charAt(index);
            if (ch == '\\') {
                int ch2 = mixedPattern.charAt(++index);
                if (ch2 == delim) {
                    if (replacementBuffer == null) {
                        if (patternBuffer == null) {
                            replacementBuffer = new StringBuffer(patternLength);
                        } else {
                            replacementBuffer = patternBuffer;
                            replacementBuffer.setLength(0);
                        }
                        replacementBuffer.append(mixedPattern.substring(patternStart, index-1));
                    }
                    replacementBuffer.append((char)delim);
                } else {
                    if (replacementBuffer != null) {
                        replacementBuffer.append((char)'\\');
                        replacementBuffer.append((char)ch2);
                    }
                }
            } else if (ch == delim)
                break;
            else if (replacementBuffer != null)
                replacementBuffer.append((char)ch);
            index++;
        }
        if (index >= patternLength)
            throw new ParseException("No delimiter after the replacement text.", index);
        String replacement = replacementBuffer == null
            ? mixedPattern.substring(replacementStart, index) : new String(replacementBuffer);

        String options = mixedPattern.substring(++index);

        return substitute(rawPattern, replacement, options, source);
    }

    /**
     * Searches <var>source</var> for <var>re</var>,
     * and replaces matched regions with <var>replacement</var>.
     *
     * @param re An <code>RegularExpression</code> instance
     * @param replacement Replacemen string.
     * @param global Whether substitute all matched strings.
     * @param source Source string.
     * @see #substitute(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    public static String substitute(RegularExpression re, String replacement,
                                    boolean global, String source) {
        StringBuffer result = null;
        Match match = new Match();
        Vector replv = parseReplacement(replacement);
        if (global) {
            int searchStart = 0;
            int substringStart = 0;
            int sourceLength = source.length();
            while (re.matches(source, 0, searchStart, sourceLength, match)) {
                int matchStart = match.getBeginning(0);
                int matchEnd = match.getEnd(0);
                if (result == null)  result = new StringBuffer();
                result.append(source.substring(substringStart, matchStart));
                subst(result, replv, match);
                substringStart = matchEnd;
                searchStart = matchEnd;
                if (matchStart == matchEnd) // Empty match
                    searchStart++;
            }
            if (result != null && substringStart < sourceLength)
                result.append(source.substring(substringStart));
        } else {
            if (re.matches(source, match)) {
                result = new StringBuffer();
                result.append(source.substring(0, match.getBeginning(0)));
                subst(result, replv, match);
                result.append(source.substring(match.getEnd(0)));
            }
        }
        return result == null ? source : new String(result);
    }
    /**
     * Omits <code>'g'</code> in specified string.
     */
    private static String omit_g(String options) {
        StringBuffer buffer = null;
        for (int i = 0;  i < options.length();  i++) {
            int ch = options.charAt(i);
            if (ch == 'g') {
                if (buffer == null) {
                    buffer = new StringBuffer(options.length());
                    buffer.append(options.substring(0, i));
                }
            } else if (buffer != null) {
                buffer.append((char)ch);
            }
        }
        return buffer == null ? options : new String(buffer);
    }

    private static void subst(StringBuffer result, Vector replacement, Match match) {
        for (int i = 0;  i < replacement.size();  i++) {
            Object elem = replacement.elementAt(i);
            if (elem instanceof String) {
                result.append((String)elem);
            } else if (elem instanceof Integer) {
                String matched = match.getCapturedText(((Integer)elem).intValue());
                if (matched != null)
                    result.append(matched);
            } else
                throw new RuntimeException("Internal Error: Unknown type: "
                                           +elem.getClass());
        }
    }

    /**
     * Parses replacement string.
     * "abc\\1def${2}" -> "abc", 1, "def", 2
     */
    private static Vector parseReplacement(String repl) {
        int length = repl.length();
        Vector parsed = new Vector();
        int start = 0;
        int bsindex;
        while ((bsindex = indexOfBSorDollar(repl, start)) >= 0) {
            parsed.addElement(repl.substring(start, bsindex));
            start = bsindex;
            char delim = repl.charAt(start);
            if (++start >= length) {
                char[] delimstr = new char[1];
                delimstr[0] = delim;
                parsed.addElement(new String(delimstr));
            } else if (delim == '\\') {
                int ch = repl.charAt(start);
                if (ch == '\\') { // \\
                    parsed.addElement("\\");
                } else if (ch == '$') { // \$
                    parsed.addElement("$");
                } else if ('1' <= ch && ch <= '9') { // \1 - \9
                    parsed.addElement(new Integer(ch-'0'));
                } else {
                    throw new ParseException("Unknown sequence: \\"+(char)ch, start);
                }
            } else {            // delim -> '$'
                int ch = repl.charAt(start);
                if ('1' <= ch && ch <= '9') {
                    parsed.addElement(new Integer(ch-'0'));
                } else if (ch == '{') {
                    int saved = start-1;
                    int value = 0;
                    int c = 0;
                    while (++start < length) {
                        c = repl.charAt(start);
                        if (c < '0' || '9' < c)
                            break;
                        value = value*10 + c-'0';
                    }
                    if (start >= length || value == 0 || c != '}') {
                        parsed.addElement(repl.substring(saved, start--));
                    } else {
                        parsed.addElement(new Integer(value));
                    }
                } else {
                    parsed.addElement("$");
                }
            }
            start++;
        }
        parsed.addElement(repl.substring(start));
        return parsed;
    }

    /**
     * Replaces <kbd>\</kbd> and <kbd>$</kbd> with <kbd>\\</kbd> and <kbd>\$</kbd>.
     */
    public static String quoteReplacement(String literal) {
        int len = literal.length();
        StringBuffer buffer = null;
        for (int i = 0;  i < len;  i ++) {
            char ch = literal.charAt(i);
            if (ch == '\\' || ch == '$') {
                if (buffer == null) {
                    buffer = new StringBuffer(i+(len-i)*2);
                    if (i > 0)  buffer.append(literal.substring(0, i));
                }
                buffer.append((char)'\\');
                buffer.append(ch);
            } else if (buffer != null)
                buffer.append(ch);
        }
        return buffer != null ? buffer.toString() : literal;
    }

    private static int indexOfBSorDollar(String src, int start) {
        int limit = src.length();
        int ret = -1;
        while (start < limit) {
            int ch = src.charAt(start);
            if (ch == '\\' || ch == '$') {
                ret = start;
                break;
            }
            start++;
        }
        return ret;
    }
    
    // ================================================================
    // Split
    //

    /**
     * Splits <var>source</var> by regions matched to <var>pattern</var>.
     *
     * <p>For example:
     * <blockquote>
     * <div><code>REUtil.split(":", "", "kent:*:1000:1001:TAMURA Kent:/home/kent:/usr/local/bin/zsh", -1);</code></div>
     * </blockquote>
     * <p>This returns an array consisted of seven Strings,
     * <code>"kent"</code>, <code>"*"</code>, <code>"1000"</code>, <code>"1001"</code>,
     * <code>"TAMURA Kent"</code>, <code>"/home/kent"</code>, <code>"/usr/local/bin/zsh"</code>.
     * 
     * <blockquote>
     * <div><code>REUtil.split(":", "", "kent:*:1000:1001:TAMURA Kent:/home/kent:/usr/local/bin/zsh", <u>5</u>);</code></div>
     * </blockquote>
     * <p>This returns an array consisted of <u>five</u> Strings,
     * <code>"kent"</code>, <code>"*"</code>, <code>"1000"</code>, <code>"1001"</code>,
     * <code>"TAMURA Kent:/home/kent:/usr/local/bin/zsh"</code>.
     * 
     *
     * @param options Regular expression options.  See <a href="RegularExpression.html#OPTIONS">Options</a>.
     * @param limit Maximum number of result elements; -1 means no limit.
     */
    public static String[] split(String pattern, String options, String source, int limit) {
        if (limit == 0)  return new String[0];
        RegularExpression re = createRegex(pattern, options);
        return split(re, source, limit);
    }

    /**
     * Shorthand for <code>split(pattern, options, source, limit)</code>.
     *
     * @param mixedPattern <strong><kbd>/</kbd><var>pattern</var><kbd>/</kbd><var>options</var></strong>
     * @see #split(java.lang.String, java.lang.String, java.lang.String, int)
     */
    public static String[] split(String mixedPattern, String source, int limit) {
        int patternLength = mixedPattern.length();
        int index = 0;
        if (mixedPattern.charAt(index) == 'm')  index++;
        int delim = mixedPattern.charAt(index++);
        int patternStart = index;
        StringBuffer patternBuffer = null;
        while (index < patternLength) {
            int ch = mixedPattern.charAt(index);
            if (ch == '\\') {
                int ch2 = mixedPattern.charAt(++index);
                if (ch2 == delim) {
                    if (patternBuffer == null) {
                        patternBuffer = new StringBuffer(patternLength);
                        patternBuffer.append(mixedPattern.substring(patternStart, index-1));
                    }
                    patternBuffer.append((char)delim);
                } else {
                    if (patternBuffer != null) {
                        patternBuffer.append((char)'\\');
                        patternBuffer.append((char)ch2);
                    }
                }
            } else if (ch == delim)
                break;
            else if (patternBuffer != null)
                patternBuffer.append((char)ch);
            index++;
        }
        // index points the terminating delimiter or out of the mixedPattern.
        String rawPattern;
        if (patternBuffer != null) {
            rawPattern = new String(patternBuffer);
        } else {
            if (index >= patternLength) {
                rawPattern = mixedPattern.substring(patternStart);
            } else {
                rawPattern = mixedPattern.substring(patternStart, index);
            }
        }
        String options = "";
        if (++index < patternLength) { // pattern continues
            options = mixedPattern.substring(index);
        }
        return split(rawPattern, options, source, limit);
    }

    /**
     * Equivalent to <code>split(mixedPattern, source, -1)</code>.
     */
    public static String[] split(String mixedPattern, String source) {
        return split(mixedPattern, source, -1);
    }

    /**
     * Splits <var>source</var> by regions matched to <var>re</var>.
     *
     * @param limit Maximum number of result elements; -1 means no limit.
     * @see #split(java.lang.String, java.lang.String, java.lang.String, int)
     */
    public static String[] split(RegularExpression re, String source, int limit) {
        if (limit == 0)  return new String[0];
        int matchLimit = limit < 0 ? Integer.MAX_VALUE : limit-1;
        Vector result = new Vector();
        int sourceLength = source.length();
        Match match = new Match();
        boolean includeDelimiter = re.getNumberOfGroups() > 1;
        int searchStart = 0;
        int substringStart = 0;

        while (matchLimit-- > 0 && re.matches(source, searchStart, sourceLength, match)) {
            int matchStart = match.getBeginning(0);
            int matchEnd = match.getEnd(0);
            if (substringStart == matchStart && matchStart == matchEnd) {
                searchStart++;
                continue;
            }
            result.addElement(source.substring(substringStart, matchStart));
            if (includeDelimiter)  result.addElement(match.getCapturedText(1));
            searchStart = matchEnd;
            substringStart = matchEnd;
        }
        if (substringStart <= sourceLength)
            result.addElement(source.substring(substringStart));

        String[] array = new String[result.size()];
        for (int i = 0;  i < array.length;  i++)
            array[i] = (String)result.elementAt(i);
        return array;
    }

    // ================================================================

    static void dumpString(String v) {
        for (int i = 0;  i < v.length();  i ++) {
            System.out.print("U+");
            System.out.print(Integer.toHexString(v.charAt(i)));
            System.out.print(" ");
        }
        System.out.println();
    }
}
