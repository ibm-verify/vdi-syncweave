/*
 * (C) Copyright IBM Corp. 2001  All rights reserved.
 *
 * US Government Users Restricted Rights Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * IBM will not be liable for any damages suffered by you as a result
 * of using the Program. In no event will IBM be liable for any
 * special, indirect or consequential damages or lost profits even if
 * IBM has been advised of the possibility of their occurrence. IBM
 * will not be liable for any third party claims against you.
 */

package com.ibm.regex;

/**
 * This class represents a set of characters.  An application can use the set in regular
 * expressions with <kbd>\p{</kbd>...<kbd>}</kbd>.
 * <p>Sample code:
 * <pre>
 *   CharacterClass cc = new CharacterClass();
 *   cc.add(...);      // Add a character to this character class.
 *   Hashtable hash = new Hashtable();
 *   hash.put("<font color="blue">myclass</font>", cc);
 *   RegularExpression re = new RegularExpression(null, hash, "^\p{<font color="blue">myclass</font>}+", "");
 *     :
 * </pre>
 * 
 * @version $Id: CharacterClass.java,v 1.2 2001/03/22 08:00:09 kent Exp $
 * @author TAMURA Kent &lt;kent@trl.ibm.co.jp&gt;
 */
public class CharacterClass {
    RangeToken range;

    /**
     * Creates an empty <code>CharacterClass</code> instance.
     */
    public CharacterClass() {
        this.reset();
    }

    /**
     * Creates an <code>CharacterClass</code> instance.
     */
    public CharacterClass(String source) {
        this.reset();
        this.add(source);
    }

    /**
     * Register a code point.
     *
     * @param ch a code point that matches with this <code>CharacterClass</code>. It must be 0 - 0x10ffff.
     */
    public void add(int ch) {
        this.addRange(ch, ch);
    }

    /**
     * Registers a range of code points.
     *
     * @param start It must be 0 - 0x10ffff.
     * @param end It must be 0 - 0x10ffff.
     */
    public void addRange(int start, int end) {
        this.range.addRange(start, end);
    }

    /**
     * Registers all characters in <var>source</var>.
     */
    public void add(String source) {
        for (int i = 0;  i < source.length();  i++) {
            int ch = source.charAt(i);
            this.range.addRange(ch, ch);
        }
    }

    /**
     *
     */
    public void reset() {
        this.range = new RangeToken(Token.RANGE);
    }

    /**
     * internal use.
     */
    RangeToken getRangeToken() {
        return this.range;
    }
}
