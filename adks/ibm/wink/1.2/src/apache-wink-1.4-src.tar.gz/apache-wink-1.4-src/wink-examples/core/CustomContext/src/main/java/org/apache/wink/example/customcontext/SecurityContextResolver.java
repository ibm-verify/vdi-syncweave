/*******************************************************************************
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *  
 *   http://www.apache.org/licenses/LICENSE-2.0
 *  
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 *  
 *******************************************************************************/
package org.apache.wink.example.customcontext;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;

import org.apache.wink.common.annotations.Scope;
import org.apache.wink.common.annotations.Scope.ScopeType;
import org.apache.wink.example.customcontext.SecurityManager.CustomerPermission;

@Provider
@Scope(ScopeType.PROTOTYPE)
public class SecurityContextResolver implements ContextResolver<CustomerPermission> {

    private static final SecurityManager sm          = new SecurityManager();
    private static final String          CUSTOMER_ID = "custId";
    @Context
    UriInfo                              uriInfo;

    public CustomerPermission getContext(Class<?> type) {
        String user = uriInfo.getQueryParameters().getFirst(CUSTOMER_ID);
        if (user == null) {
            return new SecurityManager.CustomerPermission("", SecurityManager.READ_ONLY);
        }
        CustomerPermission permission = sm.getPermission(user);
        if (permission == null) {
            return new SecurityManager.CustomerPermission(user, SecurityManager.READ_ONLY);
        }
        return permission;
    }
}
