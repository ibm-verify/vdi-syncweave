//
// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
// 
//   http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.    
//

namespace java com.example.tutorial

enum PhoneType {
    MOBILE = 0,
    HOME = 1,
    WORK = 2,
}

struct PhoneNumber {
    1: string no,
    2: PhoneType type,
}
  
struct Person {
  1: string name,
  2: i32 id,        // Unique ID number for this person.
  3: string email,
  4: list<PhoneNumber> phone,
}

// Our address book file is just one of these.
struct AddressBook {
  1: list<Person> person,
}
