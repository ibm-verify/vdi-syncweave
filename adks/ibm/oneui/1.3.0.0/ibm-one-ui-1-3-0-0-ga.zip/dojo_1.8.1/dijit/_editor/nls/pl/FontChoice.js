define(
({
	fontSize: "Rozmiar",
	fontName: "Czcionka",
	formatBlock: "Format",
	serif: "szeryfowa",
	"sans-serif": "bezszeryfowa",
	monospace: "czcionka o stałej szerokości",
	cursive: "kursywa",
	fantasy: "fantazyjna",
	noFormat: "Brak",
	p: "Akapit",
	h1: "Nagłówek",
	h2: "Nagłówek 2-go poziomu",
	h3: "Nagłówek 3-go poziomu",
	pre: "Wstępnie sformatowane",
	1: "najmniejsza",
	2: "mniejsza",
	3: "mała",
	4: "średnia",
	5: "duże",
	6: "większa",
	7: "największa"
})
);
