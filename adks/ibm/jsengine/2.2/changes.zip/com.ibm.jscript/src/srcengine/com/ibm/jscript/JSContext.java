/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2008                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.AccessControlContext;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;
import java.lang.ref.WeakReference;

import com.ibm.commons.Platform;
import com.ibm.commons.util.EmptyIterator;
import com.ibm.commons.util.StringUtil;
import com.ibm.commons.util.SystemCache;
import com.ibm.commons.util.io.FastStringReader;
import com.ibm.commons.util.io.json.JsonFactory;
import com.ibm.commons.util.profiler.Profiler;
import com.ibm.commons.util.profiler.ProfilerAggregator;
import com.ibm.commons.util.profiler.ProfilerType;
import com.ibm.jscript.ASTTree.ASTFunction;
import com.ibm.jscript.ASTTree.ASTNodeVisitor;
import com.ibm.jscript.ASTTree.ASTProgram;
import com.ibm.jscript.ASTTree.ASTVariableDecl;
import com.ibm.jscript.ASTTree.DefaultNodeVisitor;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.engine.ProgramContext;
import com.ibm.jscript.json.JsonJavaScriptFactory;
import com.ibm.jscript.parser.FBScript2;
import com.ibm.jscript.parser.ParseException;
import com.ibm.jscript.std.ObjectObject;
import com.ibm.jscript.types.FBSGlobalObject;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSReference;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.JavaWrapperObject;
import com.ibm.jscript.types.Registry;


/**
 * Javascript context.
 */
public class JSContext {
    
    private static final ProfilerType profilerCompileExpr = new ProfilerType("Javascript expression compilation"); //$NON-NLS-1$
    private static final ProfilerType profilerEvaluateCste = new ProfilerType("Javascript evaluate constant"); //$NON-NLS-1$
    
    static final boolean CHECK=false;
    static final boolean MULTIPLE_ERROR_CHECK=true;
    
    public static boolean ENABLE_JSDEBUGGER;    
    static{
        //The user needs to provide this System property for the debugger to be enabled
        String enableJSDebuggerKey = System.getProperty( "enable.jsdebugger" ); // $NON-NLS-1$
        ENABLE_JSDEBUGGER =  enableJSDebuggerKey != null && enableJSDebuggerKey.equalsIgnoreCase("true"); // $NON-NLS-1$
    }

    private Registry registry;
    private Map<String, WeakReference<Object>> exprCache;
    private LibraryInitializer libraryInitializer;
    private PropertyResolver propertyResolver;
    private String version;
    private JsonFactory jsonFactory;
    
    // Until we use JDT, see FBSType
    private ArrayList<FBSType.DesignTimeClassLoader> designTimeClassLoaders;

    // Property resolver
    public static interface PropertyResolver {
	   public IValue getProperty(Object object, String propertyName) throws InterpretException;
	   public boolean putProperty(Object object, String propertyName, IValue value) throws InterpretException;
    }
    
    // ======================================================
    // Static context management
    // ======================================================

    private static JSContext staticContext;

    public static JSContext getStaticContext() {
        if(staticContext==null) {
            String optionsClass = System.getProperty("ibmjs.options"); // $NON-NLS-1$
            if(!StringUtil.isEmpty(optionsClass)) {
                try {
                    Class c = Class.forName(optionsClass);
                    staticContext = (JSContext)c.newInstance();
                } catch(Throwable t ) {
                    t.printStackTrace();
                }
            }
            if(staticContext==null) {
                staticContext = new JSContext(false);
            }
        }
        return staticContext;
    }

    public static void init( JSContext jsContext ) {
        staticContext = jsContext;
    }
    
    public JSContext(boolean useCache) {
        this.registry = new Registry();
        this.registry.init(this); // For an initialization issue
        this.version = "130"; // Rhino version..
        if(useCache) {
            exprCache = new WeakHashMap<String, WeakReference<Object>>();
        }
        this.jsonFactory = new JsonJavaScriptFactory(this);
    }
    
    public Registry getRegistry() {
        return registry;
    }

    public JSExpression getExpression(String expr) throws ParseException {
        return getExpression(expr,JSExpression.DYNAMIC_SOURCE_ID);
    }

    public JSExpression getExpression(String expr, String sourceReferenceID) throws ParseException {
        if(hasExpressionCache()) {
            JSExpression.ExpressionData expression = (JSExpression.ExpressionData)getCachedExpression(expr);
            if(expression==null) {
                //TDiag.trace("Creating cached expression {0}",expr);
                expression=new JSExpression.ExpressionData(this,expr);
                putCachedExpression(expr, expression);
            }
            return new JSExpression(sourceReferenceID,expression);
        } else {
            //TDiag.trace("Expression cache not enabled");
            return new JSExpression(sourceReferenceID,new JSExpression.ExpressionData(this,expr));
        }
     }
    public JSExpression getExpression(Reader is) throws ParseException, IOException {
        return getExpression(is,JSExpression.DYNAMIC_SOURCE_ID);
    }
    public JSExpression getExpression(Reader is, String sourceReferenceID) throws ParseException, IOException {
        StringBuilder b = new StringBuilder();
        char[] c = new char[1024]; int len;
        while( (len=is.read(c))>=0 ) {
            b.append(c,0,len);
        }
        return new JSExpression(sourceReferenceID,new JSExpression.ExpressionData(this,b.toString()));        
    }
    
    public JSExpression getExpression(InputStream is) throws ParseException, IOException {
        return getExpression(is,JSExpression.DYNAMIC_SOURCE_ID);
    }
    public JSExpression getExpression(InputStream is, String sourceReferenceID) throws ParseException, IOException {
        return getExpression(new InputStreamReader(is),sourceReferenceID);
    }

    public JSExpression createExpression(String expr) throws ParseException {
        return createExpression(expr,JSExpression.DYNAMIC_SOURCE_ID);
    }
    public JSExpression createExpression(String expr, String sourceReferenceID) throws ParseException {
        return new JSExpression(sourceReferenceID,new JSExpression.ExpressionData(this,expr));
    }

    public ASTProgram getASTProgram(String text) throws ParseException {
        if(hasExpressionCache()) {
            JSExpression.ExpressionData expression = (JSExpression.ExpressionData)getCachedExpression(text);
            if(expression==null) {
                expression=new JSExpression.ExpressionData(this,text);
            }
            return expression.getMainNode();
        } else {
            JSExpression.ExpressionData expression = new JSExpression.ExpressionData(this,text);
            return expression.getMainNode();
        }
    }

    public ParserResult parseScript(String expr, boolean checkTypes) {
        if( Profiler.isEnabled() ) {
            ProfilerAggregator agg = Profiler.startProfileBlock(profilerCompileExpr,expr);
            long ts = Profiler.getCurrentTime();
            try {
                return _parseScript(expr, checkTypes);
            } finally {
                Profiler.endProfileBlock(agg,ts);
            }
        } else {
            return _parseScript(expr, checkTypes);
        }
    }

    // Expression checker
    private ParserResult _parseScript(String expr, boolean checkTypes) {
        ParserResult ps = new ParserResult();
        if(!StringUtil.isSpace(expr)) {
            try {
            	//30th June 2009 - Piyush : Commenting to NOT invoke trim method inorder to get correct line number information
                FBScript2 exprParser=getParser(expr/*.trim()*/);
                try {
                    if(MULTIPLE_ERROR_CHECK) {
                        exprParser.parsedScript = ps;
                    }
                    ASTProgram mainNode= (ASTProgram)exprParser.program();
                    
                    ASTNodeVisitor myVisitor = new DefaultNodeVisitor () {
                        public Object visitProgram (ASTProgram x, Object param) {
                            // System.out.println("Hello " + x);
                            return this;
                        }
                        
                        public Object visitFunction(ASTFunction x, Object param) {
                            // System.out.println("   Function: " + x.getName() + " on line: "+ x.getBeginLine() );
                            ((ArrayList)param).add(x);
                            return null;
                          }
                        
                        public Object visitVariableDecl(ASTVariableDecl x, Object param) {
                            for (int ctr=0; ctr< x.getEntryCount(); ctr++) {
                                ASTVariableDecl.Entry entry = x.getEntryAt(ctr);
                                // System.out.println("   Variable: " + entry.getName() + " type: " + entry.getType()+ " on line: "+ x.getBeginLine() );
                                ((ArrayList)param).add(x);
                            }
                            return null;
                          }
                    };
                    
                    mainNode.visitAllNodes(myVisitor, ps.getOutlineList());
                    
                    if(checkTypes) {
                        mainNode.check();
                    }
                } finally {
                    exprParser.parsedScript = null;
                }
            } catch(Throwable t) {
                ScriptError err = null;
                if(t instanceof ParseException ) {
                    ParseException pe = (ParseException)t;
                    if ( pe.currentToken != null && pe.currentToken.next != null ){
                        int line = pe.currentToken.next.beginLine;
                        int col = pe.currentToken.next.beginColumn;
                        err = new ScriptError( ScriptError.ERROR, -1, pe.getMessage(), line, col );
                    }
                } 
                if ( err == null ) {
                    err = new ScriptError( ScriptError.ERROR, -1, t.getMessage(), -1, -1);
                }
                ps.addError(err);
            }
        }
        return ps;
    }
    
    public IValue evaluateConstant(String exprText) throws InterpretException, ParseException {
        if( Profiler.isEnabled() ) {
            ProfilerAggregator agg = Profiler.startProfileBlock(profilerEvaluateCste,exprText);
            long ts = Profiler.getCurrentTime();
            try {
                return _evaluateConstant(exprText);
            } finally {
                Profiler.endProfileBlock(agg,ts);
            }
        } else {
            return _evaluateConstant(exprText);
        }
    }
    private IValue _evaluateConstant(String exprText) throws InterpretException, ParseException {
        JSExpression expr=new JSExpression(JSExpression.DYNAMIC_SOURCE_ID,new JSExpression.ExpressionData(this,exprText),true);
        return expr.execute(null);
    }

    public String evaluateConstantAsString(String exprText) throws InterpretException, ParseException {
        IValue v = evaluateConstant(exprText);
        if(v.isNull() || v.isString() || v.isBoolean() || v.isNumber() ) {
            return v.stringValue();
        }
        throw new InterpretException(null,"Constant is not an object"); // $NLS-JSContext.Constantisnotanobject-1$
    }

    // ======================================================================
    // Access to the json factory
    // ======================================================================
    
    public JsonFactory getJsonFactory() {
    	return jsonFactory;
    }
    
    public void setJsonFactory(JsonFactory jsonFactory) {
    	this.jsonFactory = jsonFactory;
    }
    
    
    // ======================================================================
    // Security management
    // ======================================================================
    
    public AccessControlContext getAccessControlContext() {
    	return null;
    }
    
    
    // ======================================================================
    // Rhino like version management
    // ======================================================================
    
    public String getVersion() {
    	return version;
    }
    
    public void setVersion(String version) {
    	this.version = version;
    }
    
    
    // ======================================================================
    // FBScript parser pool
    // ======================================================================

    FBScript2 getParser(String expr) {
        FBScript2 parser = new FBScript2(new FastStringReader(expr));
        parser.initContext(this);
        return parser;
    }

    FBScript2 getParser(InputStream in) {
        FBScript2 parser = new FBScript2(in);
        parser.initContext(this);
        return parser;
    }

    FBScript2 getParser(Reader reader) {
        FBScript2 parser = new FBScript2(reader);
        parser.initContext(this);
        return parser;
    }
    
    
    // Language extensions ///////////////////////////////////////////////////
    
    public boolean hasStringLengthAsMethod() {
        return false;
    }

    public boolean hasStringExtendedMethods() {
        return false;
    }
    
    public boolean hasGlobalObjectExtensions() {
        return false;
    }

    public boolean hasJUnitExtensions() {
        return false;
    }

    public boolean hasObjectPrototypeExtensions() {
        return false;
    }

    public boolean hasMathExtensions() {
        return false;
    }

    public boolean hasRhinoExtensions() {
        return false;
    }

    public boolean hasRhinoProtoExtensions() {
        return false;
    }

    public boolean hasJavaBridge() {
        return true;
    }

    public boolean isJavaFieldAllowed(Field field) {
        return true;
    }

    public boolean isJavaMethodAllowed(Method method) {
        return true;
    }

    public boolean isJavaConstructorAllowed(Constructor<?> ctor) {
        return true;
    }

    public boolean isJavaPropertyAllowed(PropertyDescriptor property) {
        return true;
    }

    public boolean hasJavaBeanAccess() {
        return true;
    }

	public boolean hasDefaultListOp() {
        return false;
    }

    public BeanInfo getBeanInfo(Class<?> clazz) throws IntrospectionException {
        return Introspector.getBeanInfo(clazz);
    }

    public boolean autoConvertJavaArgsToString() {
        return false;
    }

    public boolean ignoreJavaCallAmbiguities() {
        return false;
    }

    public boolean includeCallerFunctionContext() {
        return false;
    }
    
    
    
    // Log ///////////////////////////////////////////////////////////////////
    
    public PrintStream getStandardStream() {
        return Platform.getInstance().getOutputStream();
    }

    public void print(PrintStream ps, String str) {
        ps.print(str);
    }
    
    public void println(PrintStream ps, String str) {
        ps.println(str);
    }


    // Optimization options //////////////////////////////////////////////////

    public boolean isRuntimeOptimized() {
        return true;
    }
    
    
    // Debugger //////////////////////////////////////////////////////////////

    public int getSourceTabSize() {
        return 8;
    }
    
    public static final boolean isDebugAllowed() {
        return ENABLE_JSDEBUGGER;
    }

    
    // Expression cache //////////////////////////////////////////////////////

    public boolean hasExpressionCache() {
        return exprCache!=null;     
    }
    
    public Object getCachedExpression(String expr) {
	WeakReference<Object> w = exprCache.get(expr);
	return w == null ? null : w.get();
    }
    
    public void putCachedExpression(String expr, Object expression) {
        exprCache.put(expr,new WeakReference(expression));
    }

    @Deprecated
    public SystemCache getExpressionCache() {
        return null;     
    }
    
    
    // Libraries resolver  ///////////////////////////////////////////////////
    
    public interface ILibrary {
        public String getName();
        public FBSObject getGlobalObject() throws InterpretException;
        public String getSourceReferenceId();
        public JSExpression getExpression();
        public void checkSecurity();
    }
    
    public boolean hasJSLibrary() {
        return false;
    }
    
    public ILibrary loadLibrary(String libName) throws InterpretException {
        return null;
    }

    
    // Library initialization
    // A global scope can be passed to a library when initializing, so global
    // objects can be consumed there.
    public static interface LibraryInitializer {
        public void evaluateLibrary(ILibrary library, JSExpression expression) throws InterpretException;
    }
    public LibraryInitializer getLibraryInitializer() {
        return libraryInitializer;
    }
    public void setLibraryInitializer(LibraryInitializer libraryInitializer) {
        this.libraryInitializer = libraryInitializer;
    }


    // Java class loader /////////////////////////////////////////////////////
    public Class loadClass( String className ) throws ClassNotFoundException {
        // Default class loader
        ClassLoader c = Thread.currentThread().getContextClassLoader();
        if(c!=null) {
            try {
                return c.loadClass(className);
            } catch(ClassNotFoundException ex) {
                // Fails to the standard class loader
            }
        }
        return Class.forName(className);
    }

    // Generated wrappers
    public boolean useGeneratedWrappers() {
        return false;
    }

    // Custom wrapper creation
    public JavaWrapperObject wrapObject(Object o) {
        return null;
    }

    
    // Custom properties access
    public PropertyResolver getPropertyResolver() {
    	return propertyResolver;
    }
    public void setPropertyResolver(PropertyResolver propertyResolver) {
    	this.propertyResolver = propertyResolver;
    }
    
    public IValue getProperty(Object object, String propertyName) throws InterpretException {
    	if(propertyResolver!=null) {
			IValue v = propertyResolver.getProperty(object, propertyName);
			if(v!=null) {
				return v;
			}
    	}
    	return null;
    }

    public boolean putProperty(Object object, String propertyName, IValue value) throws InterpretException {
    	if(propertyResolver!=null) {
    		if(propertyResolver.putProperty(object, propertyName, value)) {
    			return true;
    		}
    	}
        return false;
    }
    
    // Design time class loaders
    public void addDesignTimeClassLoader(FBSType.DesignTimeClassLoader loader) {
        if(designTimeClassLoaders==null) {
            designTimeClassLoaders = new ArrayList<FBSType.DesignTimeClassLoader>();
        }
        designTimeClassLoaders.add(loader);
    }
    public Iterator<FBSType.DesignTimeClassLoader> getDesignTimeClassLoaders() {
        if(designTimeClassLoaders==null) {
            return EmptyIterator.getInstance();
        }
        return designTimeClassLoaders.iterator();
    }
    
    
    // ======================================================================================
    // Java classinfo cache
    // This cache can be managed at the JSContext level, or when a JSContext is
    // shared by multiple apps (like web module), then that cache should managed by
    // web module.
    // ======================================================================================

    private IdentityHashMap<Class<?>,Object> classInfos;
    
    public Object getClassInfo(Class<?> c) {
        if(classInfos!=null) {
            return classInfos.get(c);
        }
        return null;
    }
    public void putClassInfo(Class<?> c, Object ci) {
        if(classInfos==null) {
            classInfos = new IdentityHashMap<Class<?>,Object>();
        }
        classInfos.put(c,ci);
    }    
    
    
    
    // ======================================================================================
    // Temporary execution context
    // This is for internal use only, for a few functions (getDefaultValue()) that can't 
    // access the current execution context, but actually don't need it.
    // The right solution would be to store the current execution context in a thread local
    // but this has a code and doesn't seems to be needed so far
    // ======================================================================================
    private static class TempContext extends ProgramContext {
    	TempContext(JSContext context) {
    		super(context,null,new FBSGlobalObject(context),new ObjectObject(context),null);
    	}
		@Override
		public FBSReference findGlobalScopeIdentifier(String name) throws InterpretException {
			return null;
		}
		@Override
		public FBSReference findIdentifier(String name) throws InterpretException {
			return null;
		}
		@Override
		public JSExpression getExpression() {
			return null;
		}
    }
    private TempContext tempContext;
    
    public IExecutionContext getTempExecutionContext() {
    	if(tempContext==null) {
    		tempContext = new TempContext(this);
    	}
    	return tempContext;
    }
}
