/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2010                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import java.util.ArrayList;
import java.util.HashMap;

import com.ibm.commons.util.StringUtil;
import com.ibm.commons.util.io.json.JsonGenerator;
import com.ibm.commons.util.io.json.JsonParser;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.ASTTree.ASTArgumentList;
import com.ibm.jscript.ASTTree.ASTConstants;
import com.ibm.jscript.ASTTree.ASTNode;
import com.ibm.jscript.ASTTree.ASTProgram;
import com.ibm.jscript.ASTTree.InterpretResult;
import com.ibm.jscript.JSContext.ILibrary;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.engine.Utility;
import com.ibm.jscript.parser.ParseException;
import com.ibm.jscript.std.AbstractPrototype;
import com.ibm.jscript.std.ErrorObject;
import com.ibm.jscript.std.NumberObject;

public class FBSGlobalObject extends FBSDefaultObject {

    public static final String JAVASCRIPTRESNAME = "JavaScriptResources"; // $NON-NLS-1$

    static class FBPrototype extends AbstractPrototype {
        FBPrototype(JSContext jsContext) {
            super(jsContext);
            
            int attribCste=FBSObject.P_NODELETE|FBSObject.P_NOENUM;
            createProperty("NaN",attribCste,FBSNumber.get(NumberObject.NaN)); // $NON-NLS-1$
            createProperty("Infinity",attribCste,FBSNumber.get(NumberObject.POSITIVE_INFINITY)); // $NON-NLS-1$
            createProperty("undefined",attribCste,FBSUndefined.undefinedValue); // $NON-NLS-1$

            // standard methods
            int attrib=FBSObject.P_NOENUM;
            createMethod("eval",attrib,new GlobalMethod(jsContext,0)); // $NON-NLS-1$
            createMethod("parseInt",attrib,new GlobalMethod(jsContext,1)); // $NON-NLS-1$
            createMethod("parseFloat",attrib,new GlobalMethod(jsContext,2)); // $NON-NLS-1$
            createMethod("isNaN",attrib,new GlobalMethod(jsContext,3)); // $NON-NLS-1$
            createMethod("isFinite",attrib,new GlobalMethod(jsContext,4)); // $NON-NLS-1$
            createMethod("decodeURI",attrib,new GlobalMethod(jsContext,5)); // $NON-NLS-1$
            createMethod("decodeURIComponent",attrib,new GlobalMethod(jsContext,6)); // $NON-NLS-1$
            createMethod("encodeURI",attrib,new GlobalMethod(jsContext,7)); // $NON-NLS-1$
            createMethod("encodeURIComponent",attrib,new GlobalMethod(jsContext,8)); // $NON-NLS-1$

            // extensions
            if( jsContext.hasGlobalObjectExtensions() ) {
                createMethod("print",attrib,new GlobalMethod(jsContext,10)); // $NON-NLS-1$
                createMethod("println",attrib,new GlobalMethod(jsContext,11)); // $NON-NLS-1$
                createMethod("isJavaNative",attrib,new GlobalMethod(jsContext,12)); // $NON-NLS-1$
                createMethod("isUndefined",attrib,new GlobalMethod(jsContext,20)); // $NON-NLS-1$
                createMethod("_dump",attrib,new GlobalMethod(jsContext,21)); // $NON-NLS-1$
                createMethod("_t",attrib,new GlobalMethod(jsContext,22)); // $NON-NLS-1$
                createMethod("toJson",attrib,new GlobalMethod(jsContext,27)); // $NON-NLS-1$
                createMethod("fromJson",attrib,new GlobalMethod(jsContext,28)); // $NON-NLS-1$
                createMethod("isJson",attrib,new GlobalMethod(jsContext,29)); // $NON-NLS-1$
            }
            if( jsContext.hasJUnitExtensions() ) {
                createMethod("assertTrue",attrib,new GlobalMethod(jsContext,13)); // $NON-NLS-1$
                createMethod("assertNull",attrib,new GlobalMethod(jsContext,14)); // $NON-NLS-1$
                createMethod("assertNotNull",attrib,new GlobalMethod(jsContext,15)); // $NON-NLS-1$
                createMethod("assertEquals",attrib,new GlobalMethod(jsContext,16)); // $NON-NLS-1$
                createMethod("assertNotEquals",attrib,new GlobalMethod(jsContext,17)); // $NON-NLS-1$
                createMethod("assertStrictEquals",attrib,new GlobalMethod(jsContext,18)); // $NON-NLS-1$
                createMethod("assertStrictNotEquals",attrib,new GlobalMethod(jsContext,19)); // $NON-NLS-1$
            }
            if( jsContext.hasRhinoExtensions() ) {
                createMethod("importPackage",attrib,new GlobalMethod(jsContext,23)); // $NON-NLS-1$
                createMethod("escape",attrib,new GlobalMethod(jsContext,24)); // $NON-NLS-1$
                createMethod("unescape",attrib,new GlobalMethod(jsContext,25)); // $NON-NLS-1$
                createMethod("version",attrib,new GlobalMethod(jsContext,26)); // $NON-NLS-1$
            }
        }
        public String getTypeAsString(){
            return "global"; //$NON-NLS-1$
        }
    }
    
    static class GlobalMethod extends BuiltinFunction {
        int mIndex=-1;

        public GlobalMethod(JSContext jsContext, int index){
            super(jsContext);
            mIndex=index;
        }
        public String getFunctionName() {
            return "<unknown>"; // $NON-NLS-1$
        }
        protected String[] getCallParameters() {
            switch(mIndex) {
                case 0: { // eval
                    return new String[] {"(expr:T:N):W"}; // $NON-NLS-1$
                }
                case 1: { // parseInt
                    return new String[] {"(text:T):I"}; // $NON-NLS-1$
                }
                case 2: { // parseFloat
                    return new String[] {"(text:T):D"}; // $NON-NLS-1$
                }
                case 3: { // isNaN
                    return new String[] {"(number:D):Z"}; // $NON-NLS-1$
                }
                case 4: { // isFinite
                    return new String[] {"(number:D):Z"}; // $NON-NLS-1$
                }
                case 5: { // decodeURI
                    return new String[] {"(encodedURI:T):T"}; // $NON-NLS-1$
                }
                case 6: { // decodeURIComponent
                    return new String[] {"(encodedURIComponent:T):T"}; // $NON-NLS-1$
                }
                case 7: { // encodeURI
                    return new String[] {"(uri:T):T"}; // $NON-NLS-1$
                }
                case 8: { // encodeURIComponent
                    return new String[] {"(uriComponent:T):T"}; // $NON-NLS-1$
                }
                    
                case 10:   // print
                case 11: { // println
                    return new String[] {"(values:N):V"}; // $NON-NLS-1$
                }
                case 12: { // isJavaNative
                    return new String[] {"(object:W):Z"}; // $NON-NLS-1$
                }
                case 13: { // assertTrue
                    return new String[] {"(condition:Z):V"}; // $NON-NLS-1$
                }
                case 14: { // assertNull
                    return new String[] {"(value:W):V"}; // $NON-NLS-1$
                }
                case 15: { // assertNotNull
                    return new String[] {"(value:W):V"}; // $NON-NLS-1$
                }
                case 16: { // assertEquals
                    return new String[] {"(condition:Z):V"}; // $NON-NLS-1$
                }
                case 17: { // assertNotEquals
                    return new String[] {"(condition:Z):V"}; // $NON-NLS-1$
                }
                case 18: { // assertStrictEquals
                    return new String[] {"(condition:Z):V"}; // $NON-NLS-1$
                }
                case 19: { // assertStrictNotEquals
                    return new String[] {"(condition:Z):V"}; // $NON-NLS-1$
                }
                case 20: { // isUndefined
                    return new String[] {"(value:W):Z"}; // $NON-NLS-1$
                }
                case 21: { // dump
                    return new String[] {"(value:W):V"}; // $NON-NLS-1$
                }
                case 22: { // _t
                    return new String[] {"(text:T):T"}; // $NON-NLS-1$
                }
                case 23: { // importPackage
                    return new String[] {"(package:W):V"}; // $NON-NLS-1$
                }
                case 24: { // escape
                    return new String[] {"(str:T):T"}; // $NON-NLS-1$
                }
                case 25: { // unescape
                    return new String[] {"(str:T):T"}; // $NON-NLS-1$
                }
                case 26: { // version
                    return new String[] {"(version:T):V"}; // $NON-NLS-1$
                }
                case 27: { // toJson
                    return new String[] {"(object:W):T"}; // $NON-NLS-1$
                }
                case 28: { // fromJson
                    return new String[] {"(str:T):W"}; // $NON-NLS-1$
                }
                case 29: { // isJson
                    return new String[] {"(str:T):Z"}; // $NON-NLS-1$
                }
            }
            return super.getCallParameters();
        }
        
        public boolean call(IExecutionContext context, ASTNode caller, ASTArgumentList arguments, FBSObject _this, InterpretResult result) throws JavaScriptException {
        	// Particular case for importPackage
        	// This should not fail when evaluating the argument as it must be a package 
        	if(mIndex==23) {
                FBSValueVector args;
                if (arguments!=null && arguments.getSlotCount()>0){
                    arguments.interpretJavaPackage(caller,context,result);
                    args=(FBSValueVector)result.getFBSValue().toJavaObject();
                }else{
                	args=FBSValueVector.emptyVector; // to avoid sending null object to the function call
                }
                result.setNormal(call(context,args,_this));
        	} else {
        		super.call(context, caller, arguments, _this, result);
        	}
        	return true;
        }
        
        public FBSValue call(IExecutionContext context, FBSValueVector args, FBSObject _this) throws InterpretException {
            switch(mIndex) {
                case 0: { // eval
                    if (args==null || args.getCount() ==0){
                        return FBSUndefined.undefinedValue;
                    }
                    if (args.size()==1){
                        FBSValue v=(FBSValue)args.get(0);
                        if(!(v instanceof FBSString || 
			     (v instanceof JavaWrapperObject && ((JavaWrapperObject)v).getJavaObject() instanceof String))) {
                            return v;
                        }
                        String vs = v.stringValue().trim();
                        if (StringUtil.isEmpty(vs)) {
                            return FBSNull.nullValue;
                        }
                        // PHIL's 1st optimization : check if it is a literal
                        if(vs.equals("true")) { // $NON-NLS-1$
                            //com.ibm.workplace.designer.util.TDiag.getOutputStream().println("Short #1 cut evaluation of='"+vs+"'" );
                            return FBSBoolean.TRUE;
                        }
                        if(vs.equals("false")) { // $NON-NLS-1$
                            //com.ibm.workplace.designer.util.TDiag.getOutputStream().println("Short #2 cut evaluation of='"+vs+"'" );
                            return FBSBoolean.FALSE;
                        }
                        try {
                            double dbl = Double.parseDouble(vs);
                            //com.ibm.workplace.designer.util.TDiag.getOutputStream().println("Short #3 cut evaluation of='"+vs+"'" );
                            return FBSNumber.get(dbl);
                        } catch( Exception e ) {}
                        // PHIL's 2nd optimization: check if it is a well known variable
                        FBSReference r = context.findIdentifier(vs);
                        if(r!=null) {
                            //TDiag.trace( "Optimized evaluation:'{0}'", r.getValue().stringValue() );
                            return r.getValue();
                        }
                    }
                    
                    String text;
                    if(args.size()==1) {
                    	text = args.get(0).stringValue(); 
                    } else {
	                    StringBuilder strBuf= new StringBuilder();
	                    for(int i=0;i<args.size();i++){
	                        FBSValue v=(FBSValue)args.get(i);
	                        if (v!=null){
	                            strBuf.append(v.stringValue());
	                        }
	                    }
	                    text=strBuf.toString();
                    }
                    try {
                        ASTProgram program = context.getJSContext().getASTProgram(text);
                        InterpretResult result= new InterpretResult();
                        if(!program.interpret(null,context,result)) {
                        	if(result.isReturnSignal()) {
                                FBSValue value = context.getReturnValue();
                                return value;
                        	}
                        }
                        //com.ibm.workplace.designer.util.TDiag.getOutputStream().println("Expr='"+text+"' Evaluated, result="+result.getFBSValue().toString() );

                        // get the result but if the value is null, then replace it by a FBSNull value
                        // otherwise it can crash during use of this value in the rest of the javasript expression interpretation
                        FBSValue newResult = result.getFBSValue();
                        if (newResult == null) {
                            newResult = FBSNull.nullValue;
                        }
                        return newResult;
                    } catch (InterpretException e) {
                        throw e;
                    } catch (JavaScriptException e) {
                        throw new InterpretException(e,ErrorObject.EvalErrorObject.create(context.getJSContext(),"Unexpected exception")); // $NLS-FBSGlobalObject.Unexpectedabruptexception-1$
                    } catch (ParseException e) {
                        throw new InterpretException(e,ErrorObject.SyntaxErrorObject.create(context.getJSContext(),"Error while parsing script of eval() method, text {0}",StringUtil.toString(text,64))); // $NLS-FBSGlobalObject.Errorwhileparsingscriptofevalmeth-1$
                    }
                } 
                case 1: { // parseInt
                    if (args.size()==0){
                        return FBSNumber.NaN;
                    }
                    FBSValue a0 = args.get(0);
                    if(a0.isUndefined()) {
                        return FBSNumber.NaN;
                    }
                    //String str=leftTrim(a0.stringValue());
                    //if (StringUtil.isEmpty(str) || str.equals("NaN")) {//$NON-NLS-1$
                    //    return FBSNumber.NaN;
                    //}
                    
                    String str=a0.stringValue();
                	int len = str.length();
                	int ptr = 0;
                	
                	// remove leading spaces
                	while(ptr<len && Character.isSpaceChar(str.charAt(ptr))) {
                		ptr++;
                	}
                	if(ptr==len) {
                		return FBSNumber.NaN;
                	}
                	boolean minus = str.charAt(ptr)=='-';
                	if(str.charAt(ptr)=='-' || str.charAt(ptr)=='+') {
                		ptr++;
                	}
                	if(ptr==len) {
                		return FBSNumber.NaN;
                	}

                	int radix=10;
                	if (args.size()>=2){
                		int r=args.get(1).intValue();
                		if(r!=0) {
                			if(r<2 || r>36) {
                				return FBSNumber.NaN;
                			}
                			radix = r;
                		}
                	} 
                	if(str.charAt(ptr)=='0') {
                        if(str.startsWith("0x",ptr) || str.startsWith("0X",ptr) ) { //$NON-NLS-1$ //$NON-NLS-2$
                        	radix = 16;
                        	ptr += 2;
// This at the implementation discretion (15.1.2.2) 
// No need to do it as base eight is almost never used!                         	
//                        } else {
//                        	radix = 8;
//                        	ptr++;
                        }
                    }
                	if(ptr==len) {
                		return FBSNumber.NaN;
                	}

                	boolean first = true;
                    double result = 0.0;
                	while(ptr<len) {
                		char c=str.charAt(ptr++);
                		int v;
                		if(c>='0' && c<='9') {
                			v = c-'0';
                		} else if(c>='A' && c<='Z') { 
                			v = c-'A'+10;
            			} else if(c>='a' && c<='z') {
                			v = c-'a'+10;
            			} else {
            				break;
            			}
            			if(v>=radix) {
            				break;
            			}
            			if(first) {
                			result = v;
                			first = false;
            			} else {
            				result = result*radix +v;
            			}
                	}
                	if(!first) {
                		return FBSNumber.get(minus ? -result : result);
                	}
                    return FBSNumber.NaN;
                } 
                case 2: { // parseFloat
                    if (args.size()==0){
                        return FBSNumber.NaN;
                    }
                    FBSValue a0 = args.get(0);
                    if(a0.isUndefined()) {
                        return FBSNumber.NaN;
                    }
                    String str=leftTrim(a0.stringValue().trim());
                    if (StringUtil.isEmpty(str) || str.equals("NaN")) {//$NON-NLS-1$
                        return FBSNumber.NaN;
                    }
                    if (StringUtil.equals(str,"Infinity") || StringUtil.equals(str,"+Infinity")) { // $NON-NLS-1$ //$NON-NLS-2$
                        return FBSNumber.POSITIVE_INFINITY;
                    }
                    if (StringUtil.equals(str,"-Infinity")) { // $NON-NLS-1$
                        return FBSNumber.NEGATIVE_INFINITY;
                    }
                    // We must get the largest substring (from the left) containing a parsable number
                    // PHIL: this is not ECMA!
                    int exponentIndicatorPosition=-1;
                    int decimalSeparatorPosition=-1;
                    int i;
                    for (i=0; i<str.length(); i++) {
                        char c=str.charAt(i);
                        if (c>='0' && c<='9') {
                            continue;
                        }
                        if (c=='.') {
                            if (exponentIndicatorPosition == -1) {
                                if (decimalSeparatorPosition == -1) {
                                    decimalSeparatorPosition=i;
                                    continue;
                                } else {
                                    break;  // Only one decimal '.' is allowed
                                }
                            } else {
                                break;  // The exponant can't be decimal
                            }
                        }
                        if (c=='+' || c=='-') {
                            if (i==0) {
                                // The first character may be a + or a -
                                continue;
                            }
                            if ( (exponentIndicatorPosition != -1)  &&
                                 (i == exponentIndicatorPosition + 1) ) {
                                continue;   // There may be a + or a - just after the exponent indicator
                            }
                            break;  // Not expected in that place
                        }
                        if (c=='e' || c=='E') {
                            if (exponentIndicatorPosition == -1) {
                                exponentIndicatorPosition=i;
                                continue;
                            } else {
                                break;  // Only zero or one exponent indicator expected
                            }
                        }
    
                        break;      // Stop the search in all other cases
                    }
                    str=str.substring(0, i);
                    if (!StringUtil.isEmpty(str)) {
                        try {
                            double d=Double.parseDouble(str);
                            return FBSNumber.get(d);
                        } catch (NumberFormatException e) {
                            // It should never occur as we parse a correct string
                            context.exception(e,"");
                        }
                    }
                    return FBSNumber.NaN;
                } 
                case 3: { // isNaN
                    if (args.size()==1) {
                        FBSValue value=(FBSValue)args.get(0);
                        FBSNumber number=value.toFBSNumber();
                        if (number.isNaN()) {
                            return FBSBoolean.TRUE;
                        } 
                        return FBSBoolean.FALSE;
                    }
                    return FBSBoolean.TRUE;
                } 
                case 4: { // isFinite
                    if (args.size()==1) {
                        FBSValue value=(FBSValue)args.get(0);
                        FBSNumber number=value.toFBSNumber();
                        if (number.isNaN()) {
                            return FBSBoolean.FALSE;
                        }
                        if (number.isFinite()) {
                            return FBSBoolean.TRUE;
                        } 
                    }
                    return FBSBoolean.FALSE;
                } 
                case 5: { // decodeURI
                    throw new InterpretException(null,"decodeURI is not implemented"); // $NLS-FBSGlobalObject.decodeURIisnotimplemented-1$
                }
                case 6: { // decodeURIComponent
                    throw new InterpretException(null,"decodeURIComponent is not implemented"); // $NLS-FBSGlobalObject.decodeURIComponentisnotimplemente-1$
                }
                case 7: { // encodeURI
                    throw new InterpretException(null,"encodeURI is not implemented"); // $NLS-FBSGlobalObject.encodeURIisnotimplemented-1$
                }
                case 8: { // encodeURIComponent
                    throw new InterpretException(null,"encodeURIComponent is not implemented"); // $NLS-FBSGlobalObject.encodeURIComponentisnotimplemente-1$
                }

                case 10: { // print
                    int sz = args!=null ? args.size() : 0;
                    if(sz==1) {
                        FBSValue v=(FBSValue)args.get(0);
                        context.print(v.stringValue());
                    } else if(sz>1) {
                        StringBuilder b = new StringBuilder();
                        for(int i=0;args!=null && i<args.size();i++){
                            FBSValue v=(FBSValue)args.get(i);
                            b.append(v.stringValue());
                        }
                        context.print(b.toString());
                    }
                    return FBSUndefined.undefinedValue;
                } 
                case 11: { // println
                    int sz = args!=null ? args.size() : 0;
                    if(sz==1) {
                        FBSValue v=(FBSValue)args.get(0);
                        context.println(v.stringValue());
                    } else if(sz>1) {
                        StringBuilder b = new StringBuilder();
                        for(int i=0;args!=null && i<args.size();i++){
                            FBSValue v=(FBSValue)args.get(i);
                            b.append(v.stringValue());
                        }
                        context.println(b.toString());
                    }
                    return FBSUndefined.undefinedValue;
                } 
                case 12: { // isJavaNative
                    if (args.size()!=1){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'isJavaNative'"); // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling-1$
                    }
                    FBSValue value=(FBSValue)args.get(0);
                    return FBSBoolean.get(value.isJavaNative());
                } 
                case 13: { // assertTrue
                    if (args.size()!=1){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'assertTrue'"); // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.1-1$
                    }
                    FBSValue value=(FBSValue)args.get(0);
                    boolean verified = value.booleanValue();
                    if (!verified){
                        throw new InterpretException(null,"assertTrue failed."); // $NLS-FBSGlobalObject.assertTruefailed-1$
                    }
                    return FBSUndefined.undefinedValue;
                } 
                case 14: { // assertNull
                    if (args.size()!=1){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'assertNull'"); // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.2-1$
                    }
                    FBSValue value=(FBSValue)args.get(0);
                    boolean verified = (value==FBSNull.nullValue);
                    if (!verified){
                        throw new InterpretException(null,"assertNull failed."); // $NLS-FBSGlobalObject.assertNullfailed-1$
                    }
                    return FBSUndefined.undefinedValue;
                } 
                case 15: { // assertNotNull
                    if (args.size()!=1){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'assertNotNull'"); // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.3-1$
                    }
                    FBSValue value=(FBSValue)args.get(0);
                    boolean verified = (value!=FBSNull.nullValue);
                    if (!verified){
                        throw new InterpretException(null,"assertNotNull failed."); // $NLS-FBSGlobalObject.assertNotNullfailed-1$
                    }
                    return FBSUndefined.undefinedValue;
                } 
                case 16: { // assertEquals
                    if (args.size()!=2){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'assertEquals'"); // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.4-1$
                    }
                    FBSValue value1 = (FBSValue)args.get(0);
                    FBSValue value2 = (FBSValue)args.get(1);
                    FBSValue r = FBSUtility.wrap(Utility.equalityOperation(value1,value2,ASTConstants.EQUAL));
                    boolean verified = r.booleanValue();
                    if (!verified){
                        throw new InterpretException(null,"assertEquals failed."); // $NLS-FBSGlobalObject.assertEqualsfailed-1$
                    }
                    return FBSUndefined.undefinedValue;
                } 
                case 17: { // assertNotEquals
                    if (args.size()!=2){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'assertNotEquals'"); // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.5-1$
                    }
                    FBSValue value1 = (FBSValue)args.get(0);
                    FBSValue value2 = (FBSValue)args.get(1);
                    FBSValue r = FBSUtility.wrap(Utility.equalityOperation(value1,value2,ASTConstants.NOT_EQUAL));
                    boolean verified = r.booleanValue();
                    if (!verified){
                        throw new InterpretException(null,"assertNotEquals failed."); // $NLS-FBSGlobalObject.assertNotEqualsfailed-1$
                    }
                    return FBSUndefined.undefinedValue;
                } 
                case 18: { // assertStrictEquals
                    if (args.size()!=2){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'assertStrictEquals'"); // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.6-1$
                    }
                    FBSValue value1 = (FBSValue)args.get(0);
                    FBSValue value2 = (FBSValue)args.get(1);
                    FBSValue r = FBSUtility.wrap(Utility.equalityOperation(value1,value2,ASTConstants.STRICT_EQUAL));
                    boolean verified = r.booleanValue();
                    if (!verified){
                        throw new InterpretException(null,"assertStrictEquals failed."); // $NLS-FBSGlobalObject.assertStrictEqualsfailed-1$
                    }
                    return FBSUndefined.undefinedValue;
                } 
                case 19: { // assertStrictNotEquals
                    if (args.size()!=2){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'assertStrictNotEquals'"); // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.7-1$
                    }
                    FBSValue value1 = (FBSValue)args.get(0);
                    FBSValue value2 = (FBSValue)args.get(1);
                    FBSValue r = FBSUtility.wrap(Utility.equalityOperation(value1,value2,ASTConstants.STRICT_NOT_EQUAL));
                    boolean verified = r.booleanValue();
                    if (!verified){
                        throw new InterpretException(null,"assertStrictNotEquals failed."); // $NLS-FBSGlobalObject.assertStrictNotEqualsfailed-1$
                    }
                    return FBSUndefined.undefinedValue;
                } 
                case 20: { // isUndefined
                    if (args.size()!=1){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'isUndefined'"); // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.11-1$
                    }
                    FBSValue value1 = (FBSValue)args.get(0);
                    return FBSBoolean.get(value1 == FBSUndefined.undefinedValue);
                } 
                case 21: { // dump
                    if (args.size()!=1){
                        throw new InterpretException(null,"Illegal number of parameter in calling '_dump'"); // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.10-1$
                    }
                    FBSValue.dump( context.getStandardStream(), (FBSValue)args.get(0) );
                    return FBSUndefined.undefinedValue;
                } 
                case 22: { // _t
                    if (args.size()!=1){
                        throw new InterpretException(null,"Illegal number of parameter in calling '_t'"); // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.9-1$
                    }
                    return (FBSValue)args.get(0);
                }
                case 23: { // importPackage
                    if (args.size()!=1){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'importPackage'"); // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.8-1$
                    }
                    FBSValue v = args.get(0);
                    if( !(v instanceof JavaPackageObject) ) {
                        throw new InterpretException(null,"Argument for 'importPackage' must be a package"); // $NLS-FBSGlobalObject.ArgumentforimportPackagemustbeapa-1$
                    }
                    context.getGlobalObject().importPackage((JavaPackageObject)v);
                    return FBSUndefined.undefinedValue;
                }
                case 24: { // escape
                    if (args.size()==0){
                    	return FBSUndefined.undefinedValue.toFBSString();
                    }
                    if (args.size()!=1){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'escape'");  // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.14-1$
                    }
                    StringBuilder b = new StringBuilder();
                    String s = args.get(0).stringValue();
                    int count = s.length();
                    for(int i=0; i<count; i++) {
                        char c = s.charAt(i);
                        if(    (c>='A' && c<='Z') 
                            || (c>='a' && c<='z') 
                            || (c>='0' && c<='9') 
                            || c=='@' || c=='*' || c=='_' || c=='+' || c=='-' || c=='.' || c=='/') {
                            b.append(c);
                        } else {
                            int ch = (int)c;
                            if(ch>=256) {
                                b.append("%u"); // $NON-NLS-1$
                                b.append(StringUtil.toUnsignedHex(ch, 4));
                            } else {
                                b.append("%");
                                b.append(StringUtil.toUnsignedHex(ch, 2));
                            }
                        }
                    }
                    return FBSString.get(b.toString());
                }
                case 25: { // unescape
                    if (args.size()==0){
                    	return FBSUndefined.undefinedValue.toFBSString();
                    }
                    if (args.size()!=1){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'unescape'");  // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.15-1$
                    }
                    StringBuilder b = new StringBuilder();
                    String s = args.get(0).stringValue();
                    int count = s.length();
                    for(int i=0; i<count; i++) {
                        char c = s.charAt(i);
                        if(c=='%' && i+1<count) {
                            if(s.charAt(i+1)=='u') {
                            	if(i+6<=count) {
	                            	String hx = s.substring(i+2,i+6);
	                        		b.append((char)(Integer.parseInt(hx, 16)));
	                        		i+=5;
	                        		continue;
                            	}
                            } else if(i+3<=count) {
                                String hx = s.substring(i+1,i+3);
                                b.append((char)(Integer.parseInt(hx, 16)));
                                i+=3;
                                continue;
                            }
                        }
                        b.append(c);
                    }
                    return FBSString.get(b.toString());
                }
                case 26: { // version
                    if (args.size()==1){
                        String ver = args.get(0).stringValue();
                        context.getJSContext().setVersion(ver);
                    } else {
                        return FBSString.get(context.getJSContext().getVersion());
                    }
                    return FBSUndefined.undefinedValue;
                }
                case 27: { // toJson
                    if (args.size()<1){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'toJson'"); // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.16-1$
                    }
                    Object o = args.get(0);
                    boolean compact = args.size()>=2 ? args.get(1).booleanValue() : true;
                    try {
                        String s = JsonGenerator.toJson(context.getJSContext().getJsonFactory(), o, compact);
                        return FBSUtility.wrap(s);
                    } catch(Throwable ex) {
                        throw new InterpretException(ex,"Error while converting to a JSON string"); // $NLS-FBSGlobalObject.ErrorwhileconvertingtoaJSONstring-1$
                    }
                }
                case 28: { // fromJson
                    if (args.size()<1){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'fromJson'");   // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.17-1$
                    }
                    String s = args.get(0).stringValue();
                    try {
                        Object o = JsonParser.fromJson(context.getJSContext().getJsonFactory(), s);
                        return FBSUtility.wrap(context.getJSContext(),o);
                    } catch(Throwable ex) {
                        throw new InterpretException(ex,"Error while converting from a JSON string"); // $NLS-FBSGlobalObject.ErrorwhileconvertingfromaJSONstri-1$
                    }
                }
                case 29: { // isJson
                    if (args.size()<1){
                        throw new InterpretException(null,"Illegal number of parameter in calling 'isJson'");   // $NLS-FBSGlobalObject.Illegalnumberofparameterincalling.18-1$
                    }
                    String s = args.get(0).stringValue();
                    boolean b = JsonParser.isJson(s);
                    return FBSUtility.wrap(b);
                }
            }
            return FBSUndefined.undefinedValue;
        }
        
        // Utility
        private static String leftTrim(String s) {
        	int len = s.length();
        	int n = 0;
            while( n<len && Character.isSpaceChar(s.charAt(n)) ) {
            	n++;
            }
            return n>0 ? s.substring(n) : s; 
        }
    }

    private ILibrary library;
    
    public FBSGlobalObject(JSContext jsContext) {
        super(jsContext,jsContext.getRegistry().globalObjectPrototype);
    }

    public FBSGlobalObject(JSContext jsContext, ILibrary library) {
        super(jsContext,jsContext.getRegistry().globalObjectPrototype);
        this.library = library;
    }
    
    public ILibrary getLibrary() {
    	return library;
    }
    
    public String getTypeAsString(){
        return "global"; //$NON-NLS-1$
    }

    public boolean hasInstance(FBSValue v){
        return v instanceof FBSGlobalObject;
    }

    public boolean isJavaNative(){
        return false;
    }

// This should be enabled if the global object owns the registry objects (Number, String...)    
//    public FBSReference getPropertyReference(String name) throws InterpretException {
//      FBSReference ref = super.getPropertyReference(name);
//      if(ref==null) {
//          FBSObject o = getJSContext().getRegistry().getGlobalObject(name);
//          if(o!=null) {
//              return new FBSReferenceByName.ResolvedReference(this,name,o);
//          }
//      }
//      return ref;
//    }
//    
//    public FBSValue get(String name) throws InterpretException {
//      FBSValue v = super.get(name);
//      if(v==FBSUndefined.undefinedValue) {
//          if(!hasProperty(name)) {
//              v = getJSContext().getRegistry().getRegistryObject().get(name);
//          }
//      }
//      return v;
//    }

    
    // =======================================================================
    // Library management
    // =======================================================================

    private ArrayList<JSContext.ILibrary> libs;

    public void removeLibraries() {
    	libs = null;
    }
    
    public void importLibrary(JSContext jsContext, String name) throws InterpretException {
        if(libs!=null) {
            // Check if the library was already loaded
            int nlib = libs.size();
            for( int i=0; i<nlib; i++ ) {
                JSContext.ILibrary lib = (JSContext.ILibrary)libs.get(i);
                if( lib.getName().equals(name) ) {
                    // Ok, check if we need to reload it
                    // Else, it is ok and loaded!
                    return;
                }
            }
        }

        // Else, load the library from into the global object
        // The lib must be non null - an exception should be thrown if the lib is not found
        JSContext.ILibrary lib = jsContext.loadLibrary(name);
        if(libs==null) {
            libs = new ArrayList<JSContext.ILibrary>();
        }
        libs.add(lib);
    }

    /**
     * Search the library for the first occurence of property name.
     * If found, the object containing the property is returned
     * otherwise null is returned.
     * @return object containing the property
     */
    public FBSReference searchLibrary(String propertyName) throws InterpretException {
        if(libs!=null) {
            int count = libs.size();
            for(int i=0; i<count; i++){
                JSContext.ILibrary lib = (JSContext.ILibrary)libs.get(i);
                if ( lib != null ){
                    // If the library name correspond to the searched name, return the library
                    if( lib.getName().equals(propertyName) ) {
                        return new FBSReferenceByName.ResolvedReference(this,propertyName,lib.getGlobalObject());
                    }
                    // Else, look for a global object in the library itself
                    FBSObject go = lib.getGlobalObject(); 
                    if( go!=null ){
                        if( go.hasProperty(propertyName)){
                            return new FBSReferenceByName(go,propertyName);
                        }
                        // Recursively search the libaries
                        if( go instanceof FBSGlobalObject) {
                            FBSReference o = ((FBSGlobalObject)go).searchLibrary(propertyName);
                            if(o!=null) {
                                return o;
                            }
                        }
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * @param propertyName
     * @return the first library that contains the property
     * @throws InterpretException 
     */
    public JSContext.ILibrary searchForLibraryWithProperty( String propertyName ) throws InterpretException{
        if ( libs == null ){
            return null;
        }
        int count = libs.size();
        for ( int i = 0; i < count; i++ ){
            JSContext.ILibrary lib = (JSContext.ILibrary)libs.get(i);
            if( lib.getGlobalObject()!=null && lib.getGlobalObject().hasProperty(propertyName)){
                return lib;
            }
        }
        return null;
    }
    
    public static FBSObject getLibraryGlobalObject(JSContext jsContext, String name) throws InterpretException {
        JSContext.ILibrary lib =  jsContext.loadLibrary(name);
        return lib.getGlobalObject();
    }
    
    // =======================================================================
    // Java package management
    // =======================================================================

    private HashMap<String,JavaPackageObject> javaPackages;

    public void importPackage( JavaPackageObject jp ) {
        if(javaPackages==null) {
            javaPackages = new HashMap<String,JavaPackageObject>();
        }
        javaPackages.put(jp.getPackageName(),jp);
    }
    
    public boolean hasPackages() {
        return javaPackages!=null;
    }
    
    public JavaPackageObject loadJavaClass(JSContext jsContext, String className) {
        if(javaPackages!=null) {
            for(JavaPackageObject jp: javaPackages.values()) {
                // Try to load it as a class here
                try {
                    String pName = jp.getPackageName();
                    Class<?> c = jsContext.loadClass(StringUtil.isEmpty(pName)?className:pName+"."+className);
                    if(c!=null) {
                        return jp;
                    }
                } catch(Exception e) {
                }
            }
        }
        return null;
    }
}