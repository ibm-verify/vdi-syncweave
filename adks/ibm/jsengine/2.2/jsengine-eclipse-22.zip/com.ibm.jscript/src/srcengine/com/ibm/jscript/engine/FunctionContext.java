/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2010                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.engine;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JSExpression;
import com.ibm.jscript.JSContext.ILibrary;
import com.ibm.jscript.std.FunctionObject;
import com.ibm.jscript.std.FunctionObject.FBSActivationObject;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSGlobalObject;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSReference;

/**
 * Function execution context.
 * ServerThread used by when internally calling a javascript function.
 */
public class FunctionContext extends IExecutionContext {

	FunctionObject functionObject;

    public FunctionContext(JSContext jsContext, IExecutionContext parentContext, FunctionObject functionObject, FBSActivationObject varObject, FBSObject _this) {
        super(jsContext,parentContext,parentContext.getGlobalObject(),varObject,_this);
        this.functionObject = functionObject;
    }

	// BEGIN TDI Change
    IExecutionContext callerContext;

    public FunctionContext(JSContext jsContext, IExecutionContext parentContext, FunctionObject functionObject, FBSActivationObject varObject, FBSObject _this, IExecutionContext callerContext) {
        super(jsContext,parentContext,parentContext.getGlobalObject(),varObject,_this);
        this.functionObject = functionObject;
        this.callerContext = callerContext;
    }

    // For use by debugger
    public IExecutionContext getCallerContext() {
    	return callerContext;
    }
	// END TDI Change

    // Make the function variables available to the functions defined within this function
    public FBSDefaultObject getFunctionParentVariableObject(){
        return varObject;
    }
    
    public FBSDefaultObject getArguments() {
    	try {
	    	FBSDefaultObject var = getVariableObject();
	    	if(var!=null) {
	    		return (FBSDefaultObject)var.getProperty("arguments"); //$NON-NLS-1$
	    	}
    	} catch(InterpretException ex) {}
    	return null;
    }

    /* (non-Javadoc)
     * @see com.ibm.jscript.engine.IExecutionContext#getExpression()
     */
    public JSExpression getExpression() {
        JSContext.ILibrary library = getLibrary();
        if ( library != null ){
            return library.getExpression();
        }
        return parentContext.getExpression();
    }
    
    
    public ILibrary getLibrary() {
        return functionObject.getLibrary();
    }
    
//    /**
//     * @return the ILibrary if this function is from an import
//     */
//    public ILibrary getLibrary() {
//        //If this function coming from a library
//        String funcIdName = 
//            (getFunctionObject() == null || getFunctionObject().getFunctionNode() == null ) ? 
//            null : 
//            getFunctionObject().getFunctionNode().getName();
//        
//        if ( funcIdName == null ){
//            return null;
//        }
//        
//        //Look for a library that has this function
//        IExecutionContext executionContext = this;
//        while ( executionContext != null ){
//            FBSGlobalObject globalObject = executionContext.getGlobalObject();
//            if ( globalObject != null ){
//            	try {
//            		JSContext.ILibrary library = globalObject.searchForLibraryWithProperty( funcIdName );
//            		if ( library != null ){
//            			return library;
//            		}
//            	} catch(InterpretException ex) {}
//            }
//            executionContext = executionContext.parentContext;
//        }
//        return null;
//    }

    /* (non-Javadoc)
     * @see com.ibm.jscript.engine.IExecutionContext#getSourceReferenceID()
     */
    public String getSourceReferenceID() throws InterpretException {
        JSContext.ILibrary library = getLibrary();
        if ( library != null ){
            //System.out.println("FOUND LIBRARY REF ID : " + library.getSourceReferenceId() ); // $NON-NLS-1$
            return library.getSourceReferenceId();
        }
        return super.getSourceReferenceID();            
    }
    
    public FunctionObject getFunctionObject() {
        return functionObject;
    }
    
    public FBSReference findIdentifier(String name) throws InterpretException {
        FBSReference ref;
        
        // 1. Look at the internal scope
        // That scope is changed mainly by with & try/catch statements
        if( scopeCount>0 ) {
            for( int i=scopeCount-1; i>=0; i-- ) {
                ref = scopeData[i].getPropertyReference(name);
                if(ref!=null) {
                    return ref;
                }
            }
        }

        // 2. Look at the local variable object
        // Local variables are specific to function and also maps the parameters
        ref = varObject.getPropertyReference(name);
        if(ref!=null) {
            return ref;
        }

        // 3. Look into the hierarchy of parents vars here
        // This allows functions to get the value of the parent functions that created them
        // or get access to the LibraryContext, when created as part of a library
        // The activation object contains a reference to the parent variables available when created
        for(FBSDefaultObject o = functionObject.getParentVars(); o!=null; o=(o instanceof FBSActivationObject) ? ((FBSActivationObject)o).getParent() : null ) {
        	FBSReference v = o.getPropertyReference(name);
        	if(v!=null) {
        		return v;
        	}
        }

    	// 4. Delegate to the parent context
    	// It should retrieve the global reference through this context.
        if(parentContext!=null) {
        	ref = parentContext.findIdentifier(name);
        	if(ref!=null) {
        		return ref;
        	}
    	}

        // Nothing found...
    	return null;
    }

    public FBSReference findGlobalScopeIdentifier(String name) throws InterpretException {
        return parentContext.findGlobalScopeIdentifier(name);
    }
}
