/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.engine.IExecutionContext;

public abstract class FBSFixedObject extends FBSObject {

    public FBSFixedObject(JSContext jsContext) {
        super(jsContext);
    }

    public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
        throw new InterpretException(null,"Construct not supported for this object"); // $NLS-FBSFixedObject.constructisnotsupportedforthisobj-1$
    }

    public boolean supportConstruct(){
        return false;
    }

    public boolean hasInstance(FBSValue v){
        return false;
    }

    public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this)throws InterpretException{
        return null;
    }

    public boolean supportCall(){
        return true;
    }

    public boolean isJavaNative(){
       return false;
    }

    public boolean isJavaAssignableTo(Class c) {
        return false;
    }

    public Object toJavaObject(Class _class)throws InterpretException{
        throw new InterpretException(null,"Cannot convert {0} to {1}", this.getClass().getName(), _class.getName()); // $NLS-FBSFixedObject.Cantconvert0to1-1$
    }


    /**
     * try to create a property with name , attribute and value.
     * Creation is successfull if the property does not alreay exist.
     */
    public boolean createProperty(String name , int attribute, FBSValue value ) {
        return false;
    }

    public FBSValue get(int index) throws InterpretException {
        throw new InterpretException(null,"get(int index) not supported in FBSFixedObject"); // $NLS-FBSFixedObject.getintindexnotsupportedinFBSFixed-1$
    }
    public void put(int index , FBSValue value) throws InterpretException {
        throw new InterpretException(null,"put(int index,FBSValue value) not supported in FBSFixedObject"); // $NLS-FBSFixedObject.putintindexFBSValuevaluenotsuppor-1$
    }

    public boolean canPut(String name){
        return hasProperty(name);
    }

    public boolean hasProperty(String name) {
        Property[] props = getProperties();
        if( props!=null ) {
            for( int i=0; i<props.length; i++ ) {
                if( props[i].name.equals(name) ) {
                    return true;
                }
            }
        }
        return false;
    }

    public FBSType getFBSType(JSContext context) {
        return FBSType.getTypeFromValue(getJSContext(),this);
    }


    public boolean delete(String name){
        return false;
    }

    public void clear(){
    }

    public Iterator getPropertyKeys() {
        Property[] props = getProperties();
        List list = new ArrayList();
        if( props!=null ) {
            for( int i=0; i<props.length; i++ ) {
                list.add(props[i].name);
            }
        }
        return list.iterator();
    }

    public void getAllPropertiesForHelp(JSContext context, Set members){
        JSContext jsContext = getJSContext();
        Property[] props = getProperties();
        if( props!=null ) {
            for( int i=0; i<props.length; i++ ) {
                Descriptor.Field f = new Descriptor.Field(jsContext,props[i].name,props[i].type,false);
                members.add(f);
            }
        }
    }


    // =======================================================================
    // Methods that should be overloaded
    // =======================================================================

    public static class Property {
        String name;
        FBSType type;
        public Property( String name ) {
            this.name = name;
            this.type = null;
        }
        public Property( JSContext jsContext, String name, Class clazz ) {
            this.name = name;
            this.type = FBSType.getType(jsContext,clazz.getName());
        }
        public Property( String name, FBSType type ) {
            this.name = name;
            this.type = type;
        }
    }

    public abstract Property[] getProperties();
    public abstract FBSValue get(String name) throws InterpretException;

    public void put(String name , FBSValue value) throws InterpretException {
        throw new InterpretException( null, StringUtil.format("Cannot set property '{0}'",name)); // $NLS-FBSFixedObject.Cannotsetproperty0-1$
    }
}
