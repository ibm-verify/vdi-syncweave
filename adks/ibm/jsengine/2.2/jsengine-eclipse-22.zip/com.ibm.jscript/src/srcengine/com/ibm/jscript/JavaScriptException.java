/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript;

import com.ibm.commons.util.AbstractException;

/**
 * Abstract javascript exception
 */
public abstract class JavaScriptException extends AbstractException {

	private static final long serialVersionUID = 1L;

    public JavaScriptException() {
        super(null,"JavaScript exception"); //$NLS-JavaScriptException.JavaScriptException.JavaScript.Exception-1$
    }

    public JavaScriptException(Throwable e) {
        super(e,"JavaScript exception"); //$NLS-JavaScriptException.JavaScriptException.JavaScript.Exception-1$
    }

    public JavaScriptException(String msg, Object... params) {
        super(null,msg,params);
    }

    public JavaScriptException(Throwable e,String msg, Object... params) {
        super(e,msg,params);
    }
}
