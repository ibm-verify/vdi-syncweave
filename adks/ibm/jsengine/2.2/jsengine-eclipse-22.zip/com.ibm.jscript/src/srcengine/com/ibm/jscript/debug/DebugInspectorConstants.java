/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2008                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.debug;

import com.ibm.commons.util.StringUtil;

public class DebugInspectorConstants {
    //Client side actions (make sure these stay in synch with the Client Model!)
    public static final int ACTION_RESUME      = 0;
    public static final int ACTION_SUSPEND     = 1;
    public static final int ACTION_TERMINATE   = 2;
    public static final int ACTION_STEP_OVER   = 3;
    public static final int ACTION_STEP_INTO   = 4;
    public static final int ACTION_STEP_RETURN = 5;
    
    //We rename the current thread to this name.   If you change this, you MUST 
    //make the same change in the client (in RemoteAgentConstants.java)!
    public static String getInterpreterThreadName(){
        return StringUtil.format("{0} JavaScript",  // $NLS-DebugInspectorConstants.0JavaScript-1$[[{0} is the JavaScript debugger product name]]
                "IBM JavaScript Debugger"); // $NON-NLS-1$
    }
    
    public static String getActionString(int action) {
        if (action == ACTION_RESUME)      return "Resume"; // $NLS-DebugInspectorConstants.Resume-1$
        if (action == ACTION_SUSPEND)     return "Suspend"; // $NLS-DebugInspectorConstants.Suspend-1$
        if (action == ACTION_TERMINATE)   return "Terminate"; // $NLS-DebugInspectorConstants.Terminate-1$
        if (action == ACTION_STEP_OVER)   return "Step Over"; // $NLS-DebugInspectorConstants.StepOver-1$
        if (action == ACTION_STEP_INTO)   return "Step Into"; // $NLS-DebugInspectorConstants.StepInto-1$
        if (action == ACTION_STEP_RETURN) return "Step Return"; // $NLS-DebugInspectorConstants.StepReturn-1$
        return StringUtil.format("Unknown Action State: {0}",action); // $NLS-DebugInspectorConstants.UnknownActionState0-1$[[{0} is some number, 6, 7 etc.]]
    }
}
