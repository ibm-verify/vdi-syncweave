/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSValue;

public class ASTFor extends ASTNode implements ILabelledStatement {
    public static final int INIT=0;
    public static final int CONDITION=1;
    public static final int UPDATE=2;
    public static final int STATEMENT=3;

    ASTNode initNode;
    ASTNode conditionNode;
    ASTNode updateNode;
    ASTNode statementNode;
    String labelName;

    public ASTFor() {
    }
    
	public void setLabelName(String label) {
		this.labelName = label;
	}

    public void add(ASTNode init,ASTNode condition,ASTNode update,ASTNode statement){
        initNode=assignParent(init);
        conditionNode=assignParent(condition);
        updateNode=assignParent(update);
        statementNode=assignParent(statement);
    }

    public int getSlotCount(){
        return 4;
    }

    public ASTNode readSlotAt(int index){
        switch(index){
            case INIT: return initNode;
            case CONDITION: return conditionNode;
            case UPDATE: return updateNode;
            case STATEMENT: return statementNode;
        }
        return null;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            // Execute the initialization
            if (initNode!=null){
                if(!initNode.interpret(this,context,result)) {
                	return false;
                }
            }
            FBSValue v=null;
            for(;;){
                // Evaluate the condition
                if (conditionNode!=null ){
                    if(!conditionNode.interpret(this,context,result)) {
                    	return false;
                    }
                    if (!result.getFBSValue().booleanValue()) {
                        break;
                    }
                }

                // Evaluate the statement within the loop
                if(!statementNode.interpret(this, context, result)) {
                	if(result.isBreakSignal()) {
                        String label = context.getProgramContext().getLoopLabel();
                    	if(!StringUtil.isEmpty(label)) {
                    		if(!StringUtil.equals(label,labelName)) {
                    			return false;
                    		}
                    	}
                        // Break the main loop
                    	result.resetSignal();
                        break;
                	} else if(result.isContinueSignal()) {
                        String label = context.getProgramContext().getLoopLabel();
                    	if(!StringUtil.isEmpty(label)) {
                    		if(!StringUtil.equals(label,labelName)) {
                    			return false;
                    		}
                    	}
                        // Continue the main loop
                        // Still execute because the updateNode should be executed
                    	result.resetSignal();
                        //continue;
                	} else {
                		return false;
                	}
                } else {
                    // Store the resulting value
                    FBSValue res = result.getFBSValue(); 
                    if (res!=null) { 
                    	v=res;
                    }
                }

                // And evaluate the third part (update)
                if (updateNode!=null){
                    if(!updateNode.interpret(this,context,result)) {
                    	return false;
                    }
                }
            }
            result.setNormal(v);
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
	return v.visitFor(this, param);
    }
}
