/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.engine;

import com.ibm.jscript.JSContext;

/**
 * Options management.
 * @deprecated
 */
public final class JSOptions {

    public static JSContext getStaticContext() {
        return JSContext.getStaticContext();
    }

    public static void init( JSContext jsContext ) {
        JSContext.init(jsContext);
    }
    
}
