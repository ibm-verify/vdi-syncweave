/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.util;

import java.util.HashMap;
import java.util.Iterator;


/**
 * String set.
 * TODO: optimize that class for using an internal hashtable, directly using Strings
 * prohibiting the use of other nodes.
 */
public final class StringSet  {

    /**
     *
     */
    public StringSet() {
        table = new HashMap();
    }

    /**
     *
     */
    public boolean contains( String string ) {
        return table.containsKey(string);
    }

    /**
     * Get the number of elements.
     */
    public int size() {
        return table.size();
    }

    /**
     *
     */
    public String[] elements() {
        String[] result = new String[size()];
        int i = 0;
        for( Iterator it=table.keySet().iterator(); it.hasNext(); ) {
        	result[i++] = (String)it.next();
        }
        return result;
    }

    /**
     *
     */
    public void add( String string ) {
        table.put(string,string);
    }

    /**
     *
     */
    public void remove( String string ) {
        table.remove(string);
    }

    /**
     *
     */
    public void removeAll() {
        table.clear();
    }

    /*
     *
     */
    private HashMap table;
}
