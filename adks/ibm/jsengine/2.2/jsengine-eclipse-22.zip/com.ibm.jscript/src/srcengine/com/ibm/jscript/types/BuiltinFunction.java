/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;

public abstract class BuiltinFunction extends FBSDefaultObject {

    private static final String PROP_LENGTH = "length"; //$NON-NLS-1$
    
    private String name;
    
    //TODO: remove this constructor and add strng typing
    protected BuiltinFunction(JSContext jsContext, FBSDefaultObject prototype) {
        super(jsContext,prototype);
    }
    public BuiltinFunction(JSContext jsContext) {
        super(jsContext,jsContext.getRegistry().functionPrototype);
    }
    public BuiltinFunction(JSContext jsContext, String functionName) {
        super(jsContext);
        this.name = functionName;
    }

    public String getFunctionName() {
    	return name;
    }

    public void setFunctionName(String name) {
    	this.name = name;
    }

    public String stringValue(){
        return "IBMJS built-in function"; //$NON-NLS-1$
    }
    
    public int getType(){
        return FBSValue.FUNCTION_TYPE;
    }

    public FBSType getFBSType(JSContext context){
        return new FBSType.JSBuiltinFunction(this);
    }

    public String getTypeAsString(){
        return "function"; // $NON-NLS-1$
    }

    public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
        throw new InterpretException(null,"Unsupported method for built-in function"); // $NLS-BuiltinFunction.UnsupportedmethodforBuiltinFuncti-1$
    }
    public boolean supportConstruct(){
        return false;
    }
    public boolean hasInstance(FBSValue v){
        return false;
    }

    public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this) throws JavaScriptException {
        return call(args,_this);
    }
    public FBSValue call(FBSValueVector args,FBSObject _this)throws JavaScriptException {
        throw new InterpretException( null,"Function not implemented" ); // $NLS-BuiltinFunction.Functionnotimplemented-1$
    }

    public boolean supportCall(){
        return true;
    }

//    public boolean createProperty(String name , int attribute, FBSValue value ){
//        return false;
//    }


    public FBSValue get(int index){
        throw new RuntimeException("get(int index) not supported in BuiltinFunction"); // $NLS-BuiltinFunction.getintindexnotsupportedinBuiltinF-1$
    }
    public void put(int index , FBSValue value){
        throw new RuntimeException("put(int index,FBSValue value) not supported in BuiltinFunction"); // $NLS-BuiltinFunction.putintindexFBSValuevaluenotsuppor-1$
    }

    public FBSValue get(String name) throws InterpretException {
        if(name.equals(PROP_LENGTH)) {
            // Compute the minimum number of parameters
            String[] params = getCallParameters();
            if(params!=null && params.length>0) {
                int max = Integer.MIN_VALUE;
                for( int i=0; i<params.length; i++ ) {
                    int np = 0;
                    String s = params[i];
                    int len = s.length();
                    for( int j=0; j<len; j++ ) {
                        char c = s.charAt(j);
                        if(c==')') {
                            break;
                        }
                        if( c==':') {
                            np ++;
                        }
                    }
                    max = Math.max(np,max);
                }
                return FBSNumber.get(max);
            }
            return FBSNumber.Zero;
        }
        return super.get(name);
    }

    public void put(String name , FBSValue value) throws InterpretException {
        if( name.equals(PROP_LENGTH) ){
            return;
        }
        super.put(name,value);
    }
    
    public boolean delete(String name){
        if( name.equals(PROP_LENGTH) ){
            return false;
        }
        return super.delete(name);
    }

//    public boolean canPut(String name){
//        return  false;
//    }

    public boolean hasCustomProperty(String name){
        if(name.equals("length")) { // $NON-NLS-1$
            return true;
        }
        return super.hasCustomProperty(name);
    }

//    public Iterator getPropertyKeys() {
//        return null;
//    }
}
