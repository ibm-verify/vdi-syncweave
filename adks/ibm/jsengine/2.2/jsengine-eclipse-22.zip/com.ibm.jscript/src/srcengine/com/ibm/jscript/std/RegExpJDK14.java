/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSNumber;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.FBSValueVector;

/**
 * RegExp engine based on JDK 1.4 RegExp package. 
 */
public class RegExpJDK14 implements RegExpObject.REImplementation {

    /**
     * Local vars - Java 1.4 Regular Expressions
     */
    private JSContext context;
    private Pattern jdkPattern;
    private RegExpObject _this;
    
    
    RegExpJDK14(JSContext context, RegExpObject _this) {
        this.context = context;
        this._this = _this;
    }
    
    public JSContext getJSContext() {
        return context;
    }

    /**
     * Initialize Java 1.4 regexp
     * 
     * @throws JavaScriptException
     */
    public void init() throws InterpretException {
        try {
            int jdkFlags = 0;
            if (_this.ignoreCase)
                jdkFlags |= Pattern.CASE_INSENSITIVE;
            if (_this.multiline)
                jdkFlags |= Pattern.MULTILINE;
            jdkPattern = Pattern.compile(_this.source, jdkFlags);           
        } catch (Exception e) {
            throw new InterpretException(e,ErrorObject.SyntaxErrorObject.create(getJSContext(),"Error while parsing the Regexp")); // $NLS-RegExpJDK14.ErrorwhileparsingtheRegexp-1$
        }
    }
    
    /**
     * Apply the regexp pattern (from the constructor) to <i>str</i>.
     * 
     * @param str The value to apply this regexp pattern to
     * @return A FBSValueVector with the matched elements
     * @throws JavaScriptException
     */
    public ArrayObject exec(JSContext jsContext, String str) throws JavaScriptException {
        try {
            boolean global = _this.global;
            
            Matcher m = jdkPattern.matcher(str);
            
            int index = global ? _this.lastIndex : 0;
            if(index<0 || index>str.length()) {
                _this.lastIndex = 0;
                return null;
            }
            
            if(m.find(index)) {
                if(global) {
                    _this.lastIndex = m.end();
                }

                int gc = m.groupCount();
                ArrayObject result = new ArrayObject(jsContext,gc+1);
                result.put("index", FBSNumber.get(m.start())); // $NON-NLS-1$
                result.put("input", FBSString.get(str)); // $NON-NLS-1$

                for(int j=0; j<=gc; j++) {
                    result.put(j,FBSUtility.wrap(m.group(j)));
                }
                
                return result;
            }

            // No match found...
            return null;
        } catch (InterpretException err) {
            throw err;
        } catch (Exception e) {
            throw new InterpretException(e, e.toString());
        }
    }

    /**
     * Splits a string based on the regexp from the constructor.
     * 
     * @param str The string to split
     * @return A FBSValueVector with the matched elements
     * @throws JavaScriptException
     */
    public FBSValueVector split(String str, int limit) throws JavaScriptException {
        FBSValueVector result = new FBSValueVector();
        try {
            String[] arr = str.split(_this.source, limit);
            for (int i = 0; i < arr.length; i++) {
                result.add(FBSUtility.wrap(arr[i]));
            }
//        } catch (InterpretException err) {
//          throw err;
        } catch (Exception e) {
            throw new InterpretException(e, e.toString());
        }
        return result;
    }
    
    /**
     * Returns true if str matches this regexp
     * @param str
     * @return
     * @throws JavaScriptException
     */
    public ArrayObject match(JSContext jsContext, String str) throws JavaScriptException {
        try {
            return exec(jsContext,str);
        } catch (InterpretException err) {
            throw err;
        } catch (Exception e) {
            throw new InterpretException(e, e.toString());
        }
    }
    
    /**
     * Returns the index of the first regex match in str
     * 
     * @param str The string to search
     * @return
     * @throws JavaScriptException
     */
    public FBSValue search(String str) throws JavaScriptException {
        try {
            Matcher m = jdkPattern.matcher(str);
            int index = (m.find() ? m.start() : -1);
            return FBSUtility.wrap(index);
//        } catch (InterpretException err) {
//          throw err;
        } catch (Exception e) {
            throw new InterpretException(e, e.toString());
        }
    }
    
    /**
     * Replaces str with replacement using this.jdkRE regexp.
     * 
     * @param str The source string
     * @param replacement The replacement string
     * @return
     * @throws JavaScriptException
     */
    public FBSValue replace(String str, String replacement) throws JavaScriptException {
        String s;
        if (_this.global) {
            s = jdkPattern.matcher(str).replaceAll(replacement);
        } else {
            s = jdkPattern.matcher(str).replaceFirst(replacement);
        }
        return FBSUtility.wrap(s);
    }
    
    /**
     * Replaces str with replacement using this.jdkRE regexp.
     * 
     * @param str The source string
     * @param replacement The replacement string
     * @return
     * @throws JavaScriptException
     */
    public FBSValue replace(IExecutionContext context, String str, FunctionObject cb) throws JavaScriptException {
        Matcher m = jdkPattern.matcher(str);
        boolean result = m.find();
        if (result) {
            StringBuffer sb = new StringBuffer();
            do {
                String found = str.substring(m.start(), m.end());
                
                // Call the function
                final FBSValueVector args = new FBSValueVector();
                args.add(FBSUtility.wrap(found));
                for(int i=1; i<m.groupCount(); i++) {
                    args.add(FBSUtility.wrap(m.group(i)));
                }
                args.add(FBSUtility.wrap(m.start()));
                args.add(FBSUtility.wrap(str));
                
                FBSValue res = cb.call(context,args,null);
                m.appendReplacement(sb, res.stringValue());
                result = _this.global && m.find();
            } while (result);
            m.appendTail(sb);
            return FBSUtility.wrap(sb.toString());
        }
        
        return FBSUtility.wrap(str);
    }
    
   
    /* (non-Javadoc)
     * @see com.ibm.jscript.std.RegExpObject.REImplementation#compile(java.lang.String, java.lang.String)
     */
    public void compile(String re, String flags) throws JavaScriptException {
        try {
            _this.setFlags(flags);
            _this.put("source", FBSUtility.wrap(re)); // $NON-NLS-1$
            init();
        } catch (InterpretException err) {
            throw err;
        } catch (Exception err) {
            throw new InterpretException(err);
        }
    }
}