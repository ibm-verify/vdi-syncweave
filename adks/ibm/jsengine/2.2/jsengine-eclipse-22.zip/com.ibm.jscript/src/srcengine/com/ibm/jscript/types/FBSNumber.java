/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.std.DateObject;
import com.ibm.jscript.util.DToA;

public class FBSNumber extends FBSValue {

    
    public static final String toString(int i) {
    	if(i>=0 && i<=20) {
    		return STR_INT[i];
    	}
    	return Integer.toString(i);
    }
    private static final String[] STR_INT = {"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20"};
    
    private static final int MIN_NUMBERS = -64;
    private static final int MAX_NUMBERS = 256;
    private static final FBSNumber[] _numbers;
    static {
    	_numbers = new FBSNumber[MAX_NUMBERS-MIN_NUMBERS+1];
    	for(int i=MIN_NUMBERS; i<=MAX_NUMBERS; i++) {
    		_numbers[i-MIN_NUMBERS] = new FBSNumberInt(i);
    	}
    }
    public static final FBSNumber NaN       = new FBSNumber(Double.NaN);
    public static final FBSNumber POSITIVE_INFINITY = new FBSNumber(Double.POSITIVE_INFINITY);
    public static final FBSNumber NEGATIVE_INFINITY = new FBSNumber(Double.NEGATIVE_INFINITY);
    public static final FBSNumber MinusOne  = _numbers[-1-MIN_NUMBERS];
    public static final FBSNumber Zero      = _numbers[0-MIN_NUMBERS];
    public static final FBSNumber One       = _numbers[1-MIN_NUMBERS];

    private static final class FBSNumberInt extends FBSNumber {
    	private int intValue;
    	FBSNumberInt(int intValue) {
    		super((double)intValue);
    		this.intValue = intValue;
    	}
        public boolean isInteger() {
            return true;
        }
        public boolean isLong() {
            return true;
        }
        public int intValue(){
            return intValue;
        }
        public short shortValue(){
            return (short)intValue;
        }
        public long longValue(){
            return (long)intValue;
        }
        public String stringValue() {
            return FBSNumber.toString(intValue);
        }
        public FBSNumber incValue(){
            return get(intValue+1);
        }
        public FBSNumber decValue(){
            return get(intValue-1);
        }
    }
    
    public static final FBSNumber get( int v ) {
    	if(v>=MIN_NUMBERS && v<=MAX_NUMBERS) {
    		return _numbers[v-MIN_NUMBERS];
    	}
        return new FBSNumberInt(v);
    }

    public static final FBSNumber get( long v ) {
    	if(v>=MIN_NUMBERS && v<=MAX_NUMBERS) {
    		return _numbers[((int)v)-MIN_NUMBERS];
    	}
        return new FBSNumber(v);
    }

    public static final FBSNumber get( double v ) {
    	if(v==Double.NaN) {
    		return NaN;
    	}
    	if(v==Double.NEGATIVE_INFINITY) {
    		return NEGATIVE_INFINITY;
    	}
    	if(v==Double.POSITIVE_INFINITY) {
    		return POSITIVE_INFINITY;
    	}
        int iv = (int)v;
    	if(v==(double)iv) {
    		return get(iv);
    	}
        return new FBSNumber(v);
    }

    public static final FBSNumber get( String v ) {
        try {
            double d = Double.parseDouble(v);
            return get(d);
        } catch(Exception e) {}
        return NaN;
    }

    
    private double value;

    private FBSNumber() {
    }

    private FBSNumber(FBSNumber v) {
        this.value=v.value;
    }

    private FBSNumber(double d) {
        this.value = d;
    }

    public boolean isList() {
        return false;
    }

    public int getType(){
        return NUMBER_TYPE;
    }

    public FBSType getFBSType(JSContext context) {
        return FBSType.numberType;
    }

    public boolean isNumber() {
        return true;
    }

    public boolean isNaN(){
        return Double.isNaN(value);
    }

    public boolean isFinite(){
        return !Double.isInfinite(value);
    }

    public boolean isByte() {
        return value==(double)(byte)value;
    }

    public boolean isShort() {
        return value==(double)(short)value;
    }

    public boolean isInteger() {
        return value==(double)(int)value;
    }

    public boolean isLong() {
        return value==(double)(long)value;
    }

    public boolean isFloat() {
        return value==(double)(float)value;
    }

    public String stringValue() {
        return stringValue(value);
    }

    public static String stringValue(double value) {
        return DToA.toStandard(value);
    }

    public double numberValue(){
        return value;
    }

    public DateObject dateValueJS(JSContext jsContext) {
        return new DateObject(jsContext,longValue());
    }

    public FBSNumber incValue(){
        return new FBSNumber(value+1.0);
    }

    public FBSNumber decValue(){
        return new FBSNumber(value-1.0);
    }

    public boolean booleanValue(){
        return booleanValue(value);
    }
    public static boolean booleanValue(double value){
        return (Double.isNaN(value)||value==0)?false:true;
    }

    public FBSValue toFBSPrimitive(){
        return this;
    }

    public FBSBoolean toFBSBoolean(){
        return FBSBoolean.get(booleanValue());
    }

    public FBSNumber toFBSNumber(){
        return this;
    }

    public FBSString toFBSString(){
        return FBSString.get(stringValue());

    }

    public String getTypeAsString(){
        return "number"; // $NON-NLS-1$
    }

    public String toString(){
        return "FBSNumber : "+value; // $NON-NLS-1$
    }

    public FBSObject toFBSObject(JSContext context){
        try {
            return new com.ibm.jscript.std.NumberObject(context,this);
        } catch(Exception e){
            com.ibm.commons.util.TDiag.exception(e);
        }
        return null;
    }


    public boolean isJavaAssignableTo(Class c) {
        return    isNumberType(c)
               || c==Byte.class
               || c==Short.class
               || c==Integer.class
               || c==Long.class
               || c==Float.class
               || c==Double.class
               || c==Object.class;
    }
    private static boolean isNumberType( Class c ) {
        return    c==Byte.TYPE
               || c==Short.TYPE
               || c==Integer.TYPE
               || c==Long.TYPE
               || c==Float.TYPE
               || c==Double.TYPE;
    }
    

    public Object toJavaObject(Class _class) throws InterpretException{
        if( _class==null  || _class==Object.class ) {
            return new Double(doubleValue());
        } else if(_class.isPrimitive()) {
            if(_class==double.class) {
                return Double.valueOf(doubleValue());
            } else if(_class==int.class) {
                return Integer.valueOf(intValue());
            } else if(_class==long.class) {
                return Long.valueOf(longValue());
            } else if(_class==byte.class) {
                return Byte.valueOf( (byte)intValue());
            } else if(_class==short.class) {
                return Short.valueOf(shortValue());
            } else if(_class==float.class) {
                return Float.valueOf( (float)doubleValue());
            }
            // Will fail
        } else if(Number.class.isAssignableFrom(_class)) {
            if(_class==Byte.class){
                return Byte.valueOf((byte)intValue());
            } else if (_class==Integer.class) {
                return Integer.valueOf(intValue());
            } else if (_class==Double.class) {
                return Double.valueOf(doubleValue());
            } else if (_class==Long.class) {
                return Long.valueOf(longValue());
            } else if (_class==Short.class) {
                return Short.valueOf(shortValue());
            } else if (_class==Float.class) {
                return Float.valueOf((float)doubleValue());
            }
            // Will fail
        }
        if (_class==String.class) {
            return stringValue();
        }
        throw new InterpretException(null,"Unable to convert FBSNumber to {0}",_class.getName()); // $NLS-FBSNumber.cantconvertFBSNumberto0-1$
    }

    public boolean isJavaNative(){
        return false;
    }
}
