/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.engine.Utility;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSValue;

public class ASTSwitch extends ASTNode{

    private ASTNode expressionNode;
    private NodeVector nodes = new NodeVector();
    private int defaultCaseIndex=-1;

    private static int notEqOp=ASTConstants.STRICT_NOT_EQUAL; // getConstant("!==");
    
    public ASTSwitch() {
    }

    public void addExpression(ASTNode expr){
        expressionNode=assignParent(expr);
    }

    public void addCase(ASTNode node){
        nodes.add(assignParent(node));
        ASTCase caseNode=(ASTCase)node;
        if (caseNode.isDefault()){
            defaultCaseIndex=nodes.size()-1;
        }
    }

    public int getSlotCount(){
        return nodes.size()+1;
    }

    public ASTNode readSlotAt(int index){
        if (index==0) return expressionNode;
        return nodes.get(index-1);
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result ) throws JavaScriptException {
        try {
            if(!expressionNode.interpret(this,context,result)) {
            	return false;
            }
            FBSValue value=result.getFBSValue();

            // Find the node that matches the value
            int matchIndex = -1;
            int count = nodes.size();
            for(int i=0;i<count;i++) {
                if(i!=defaultCaseIndex) {
                    ASTCase caseNode= (ASTCase)nodes.get(i);
                    if(!caseNode.getExpression().interpret(this, context, result)) {
                    	return false;
                    }
                    if( !Utility.operation(context,value, result.getFBSValue(), notEqOp).booleanValue() ) {
                        matchIndex = i;
                        break;
                    }
                }
            }

            // Get the default index if none matches
            if( matchIndex<0 ) {
                matchIndex = defaultCaseIndex;
            }

            // And execute all the statements from that node
            if( matchIndex>=0 ) {
            	count = nodes.size();
                for( int i=matchIndex; i<count; i++ ) {
                    ASTCase caseNode= (ASTCase)nodes.get(i);
                    if(!caseNode.interpretStatementList(this, context, result)) {
                    	if(result.isBreakSignal()) {
                            result.setNormal(result.getFBSValue());
                            result.resetSignal();
                            return true;
                    	}
                    	return false;
                    }
                }
            }

            // No result, undefined...
            result.setNormal(FBSUndefined.undefinedValue);
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitSwitch(this, param);
    }
}
