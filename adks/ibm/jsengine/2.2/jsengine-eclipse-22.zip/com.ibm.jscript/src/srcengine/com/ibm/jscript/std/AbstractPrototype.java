/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import com.ibm.jscript.JSContext;
import com.ibm.jscript.types.FBSDefaultObject;


/**
 * Base class for prototype.
 * This class simply provides helpers that are not available to FBSDefaultObject
 */
public class AbstractPrototype extends FBSDefaultObject implements Prototype {

    public AbstractPrototype(JSContext jsContext){
        super(jsContext,jsContext.getRegistry().objectPrototype);
    }
    
    public AbstractPrototype(JSContext jsContext, FBSDefaultObject prototype){
        super(jsContext,prototype);
    }
}
