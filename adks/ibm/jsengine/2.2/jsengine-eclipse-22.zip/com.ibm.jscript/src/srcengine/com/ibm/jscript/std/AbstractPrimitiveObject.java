/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.types.FBSBoolean;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSNumber;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSValue;

/**
 * Abstract object that wraps a primitive type.
 */
public abstract class AbstractPrimitiveObject extends FBSDefaultObject {
	
    public AbstractPrimitiveObject(JSContext jsContext, FBSDefaultObject prototype) {
    	super(jsContext,prototype);
    }
    
    public abstract FBSValue getPrimitiveValue();
    
    public boolean isBoolean() {
    	return getPrimitiveValue().isBoolean();
    }

    public boolean isNumber() {
    	return getPrimitiveValue().isNumber();
    }
    
    public boolean isString() {
    	return getPrimitiveValue().isString();
    }
    
    public boolean booleanValue(){
        return true;
    }

    public String stringValue(){
       return getPrimitiveValue().stringValue();
    }

    public double numberValue(){
    	return getPrimitiveValue().numberValue();
    }

    public DateObject dateValueJS(JSContext jsContext){
    	return getPrimitiveValue().dateValueJS(jsContext);
    }

    public final FBSValue toFBSPrimitive(){
        return getPrimitiveValue();
    }

    public final FBSBoolean toFBSBoolean(){
        return FBSBoolean.TRUE;
    }

    public final FBSNumber toFBSNumber() throws InterpretException {
        return getPrimitiveValue().toFBSNumber();
    }

    public final FBSString toFBSString() throws InterpretException {
        return getPrimitiveValue().toFBSString();
    }

}
