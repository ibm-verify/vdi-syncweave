/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.ASTTree.binaryop.ASTBinaryAdd;
import com.ibm.jscript.ASTTree.binaryop.ASTBinaryDefaultOp;
import com.ibm.jscript.ASTTree.binaryop.ASTBinaryRelAnd;
import com.ibm.jscript.ASTTree.binaryop.ASTBinaryRelOr;

public class DefaultNodeVisitor implements ASTNodeVisitor {

  public Object visitArgumentList(ASTArgumentList x, Object param) {
    return this;
  }

  public Object visitArrayLiteral(ASTArrayLiteral x, Object param) {
    return this;
  }

  public Object visitArrayMember(ASTArrayMember x, Object param) {
    return this;
  }

  public Object visitAssign(ASTAssign x, Object param) {
    return this;
  }

  public Object visitBinaryAdd(ASTBinaryAdd x, Object param) {
    return this;
  }

  public Object visitBinaryDefaultOp(ASTBinaryDefaultOp x, Object param) {
    return this;
  }

  public Object visitBinaryRelAnd(ASTBinaryRelAnd x, Object param) {
    return this;
  }

  public Object visitBinaryRelOr(ASTBinaryRelOr x, Object param) {
    return this;
  }

  public Object visitBlock(ASTBlock x, Object param) {
    return this;
  }

  public Object visitBreak(ASTBreak x, Object param) {
    return this;
  }

  public Object visitCall(ASTCall x, Object param) {
    return this;
  }

  public Object visitCase(ASTCase x, Object param) {
    return this;
  }

  public Object visitContinue(ASTContinue x, Object param) {
    return this;
  }  

  public Object visitDebug(ASTDebug x, Object param) {
    return this;
  }

  public Object visitDoWhile(ASTDoWhile x, Object param) {
    return this;
  }

  public Object visitExpression(ASTExpression x, Object param) {
    return this;
  }

  public Object visitFor(ASTFor x, Object param) {
    return this;
  }

  public Object visitForIn(ASTForIn x, Object param) {
    return this;
  }

  public Object visitFunction(ASTFunction x, Object param) {
    return this;
  }

  public Object visitIdentifier(ASTIdentifier x, Object param) {
    return this;
  }

  public Object visitIf(ASTIf x, Object param) {
    return this;
  }

  public Object visitImport(ASTImport x, Object param) {
    return this;
  }

  public Object visitLabel(ASTLabel x, Object param) {
    return this;
  }

  public Object visitLiteral(ASTLiteral x, Object param) {
    return this;
  }

  public Object visitMember(ASTMember x, Object param) {
    return this;
  }

  public Object visitNew(ASTNew x, Object param) {
    return this;
  }

  public Object visitObjectLiteral(ASTObjectLiteral x, Object param) {
    return this;
  }

  public Object visitProfile(ASTProfile x, Object param) {
    return this;
  }

  public Object visitProgram(ASTProgram x, Object param) {
    return this;
  }

  public Object visitRegExp(ASTRegExp x, Object param) {
    return this;
  }

  public Object visitReturn(ASTReturn x, Object param) {
    return this;
  }

  public Object visitSwitch(ASTSwitch x, Object param) {
    return this;
  }

  public Object visitSync(ASTSync x, Object param) {
    return this;
  }

  public Object visitTernaryOp(ASTTernaryOp x, Object param) {
    return this;
  }

  public Object visitThis(ASTThis x, Object param) {
    return this;
  }

  public Object visitThrow(ASTThrow x, Object param) {
    return this;
  }

  public Object visitTry(ASTTry x, Object param) {
    return this;
  }

  public Object visitUnaryOp(ASTUnaryOp x, Object param) {
    return this;
  }

  public Object visitVariableDecl(ASTVariableDecl x, Object param) {
    return this;
  }

  public Object visitWhile(ASTWhile x, Object param) {
    return this;
  }

  public Object visitWith(ASTWith x, Object param) {
    return this;
  }
}
