/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.lib;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;

public class FloatArrayWrapper extends AbstractArrayWrapper {

    float[] values;

    public FloatArrayWrapper(JSContext jsContext, float[] o) {
        super(jsContext);
        if (o==null){
            this.values=new float[0];
        } else {
            this.values=o;
        }
    }

    public int getArrayLength() {
        return values.length;
    }

    public Object getJavaObject(){
        return values;
    }

    public void put(int index , FBSValue value){
        if (index>=0 && index<values.length){
            values[index]=(float)value.doubleValue();
        }
    }

    public FBSValue get(int index){
        if (index>=0 && index<values.length){
            return FBSUtility.wrap(values[index]);
        }
        return FBSUndefined.undefinedValue;
    }

    public boolean isJavaAssignableTo(Class c) {
        if( c.isAssignableFrom(float[].class) ) {
            return true;
        }
        return false;
    }

    public Object toJavaObject(Class _class) throws InterpretException{
        if (_class==null || _class.isAssignableFrom(float[].class) ) {
            return values;
        }
        throw new InterpretException(null,"Can't return java object of type '{0}'",_class.getName()); // $NLS-FloatArrayWrapper.Cantreturnjavaobjectoftype0-1$
    }
}
