/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.engine;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;

/**
 * Extended options.
 * This class is mainly enabled for test purposes.
 */
public class ExtendedJSContext extends JSContext{

	public ExtendedJSContext(boolean usecache) {
		super(usecache);
	}

	
	// Language extensions ///////////////////////////////////////////////////
	
	public boolean hasStringLengthAsMethod() {
		return true;
	}

	public boolean hasStringExtendedMethods() {
		return true;
	}
	
	public boolean hasGlobalObjectExtensions() {
		return true;
	}

	public boolean hasObjectPrototypeExtensions() {
		return true;
	}

	public boolean hasMathExtensions() {
		return true;
	}
		
	public boolean hasRhinoExtensions() {
		return true;
	}

	public boolean hasJavaBeanAccess() {
		return true;
	}

	public boolean hasDefaultListOp() {
        return true;
    }
	
	
	// Libraries resolver  ///////////////////////////////////////////////////
	
	public boolean hasJSLibrary() {
		return false;
	}
	
	public JSContext.ILibrary loadLibrary(String libName) throws InterpretException {
		throw new InterpretException();
	}
}
