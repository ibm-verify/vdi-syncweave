/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.types.Descriptor;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSType;

/**
 * Support class for IDE integration.
 * This class, and its inner class, provide IDE support and symbolic information
 * access.
 */
public class IDESupport {

    /**
     * Javascript code completion helper.
     * This class analyzes a javascript source and provides methods to help
     * code completion implementation.
     * It gets the global objects list from:
     * <li>
     *   <ol>The script source file (variable declarartion...)
     *   <ol>A global list of java objects provided via abstract methods
     *   <ol>Global Javascript objects (Standard script lib, Notes functions)
     * </li>
     * as the 
     */
    public static abstract class CodeCompletionHelper implements FBSType.ISymbolCallback {

        private JavaScriptSourceInfo jsInfo;
        private JavaScriptSourceInfo.MemberExpression expr;
        private FBSType exprType;
        private int pos;

        // ====================================================================
        // Constructor that analyzes the script source
        public CodeCompletionHelper(JavaScriptSourceInfo jsInfo) {
            this.jsInfo = jsInfo;
        }
        public CodeCompletionHelper(JSContext jsContext, String scriptText) {
            this(new JavaScriptSourceInfo(jsContext, scriptText));
        }
        
        public JSContext getJSContext() {
            return jsInfo.getJSContext();
        }
        
        public void analyze(int pos, boolean parameter) {
            this.pos = pos;
            this.expr = jsInfo.getMemberExpressionBeforeCursor(pos,parameter);
            if( expr.isNew ) {
                this.exprType = new FBSType.JSNewOperator();
            } else {
                if( StringUtil.isEmpty(expr.expr) ) {
                    this.exprType = new FBSType.JSSymbolCallback(this);
                } else {
                    try {
                        // Use the true javascript compiler and get the result
                        JSExpression jsExpr=jsInfo.getJSContext().createExpression(expr.expr);
                        //jsExpr.getBuiltExpr().dump();
                        exprType = jsExpr.getResultType(this);
                    } catch( Exception e ) {
                        //com.ibm.commons.util.TDiag.exception(e);
                        exprType = null;
                    }
                }
            }
        }
        
        public boolean isExpressionEmpty() {
            return StringUtil.isEmpty(expr.expr);
        }
        
        public FBSType getExpressionType() {
            return exprType;
        }
        
        public String getStartString() {
            return expr.memberStart;
        }

        public String getExpressionAndStartString() {
            if (isExpressionEmpty())
                return getStartString();
            else    //  If we have an expression and no start, it means that we have something like "window."
                return expr.expr + "." + getStartString(); //$NON-NLS-1$
        }
        
        
        // ====================================================================
        // FBSType.ISymbolCallback implementation
        public FBSType getSymbolType( String name ) {
            // Look into the source code
            JavaScriptSourceInfo.JSObject jsObject = jsInfo.getObject(name,pos);
            if(jsObject!=null) {
                if(jsObject instanceof JavaScriptSourceInfo.JSDynamicVariable) {
                    JavaScriptSourceInfo.JSDynamicVariable dv = (JavaScriptSourceInfo.JSDynamicVariable)jsObject;
                    String expr = dv.getExpression();
                    if(!StringUtil.isEmpty(expr)) {
                        int oldPos = pos;
                        try {
                            pos = dv.declStart;
                            JSExpression jsExpr=getJSContext().createExpression(dv.getExpression());
                            return jsExpr.getResultType(this);
                        } catch( Exception e ) {
                            com.ibm.commons.util.TDiag.exception(e);
                        } finally {
                            pos = oldPos;
                        }
                    }
                    return FBSType.undefinedType;
                }
                return jsObject.getType();
            }
            
            //Get prototypes from the object
            Map prototypes = getDataPrototypes();
            if(prototypes!=null && prototypes.size()!=0) {
            	for( Iterator it=prototypes.values().iterator(); it.hasNext(); ) {
                    FBSDefaultObject proto = (FBSDefaultObject)it.next();
                    FBSType type = proto.getPropertyFBSType(getJSContext(),name);
                    if(!type.isInvalid()) {
                        return type;
                    }
            	}
            }
         
            // Then look at the global symbol
            int count = getGlobalCount();
            for( int i=0; i<count; i++ ) {
                String symb = getGlobalAlias(i);
                if( StringUtil.equals(symb,name) ) {
                    return getGlobalObjectType(i);
                }
            }

            // Look into the global object
            FBSType type1 = getJSContext().getRegistry().globalObjectPrototype.getPropertyFBSType(getJSContext(),name);
            if(!type1.isInvalid()) {
                return type1;
            }

            // Look into the global wrappers
            FBSType type2 = getJSContext().getRegistry().getRegistryObject().getPropertyFBSType(getJSContext(),name);
            if(!type2.isInvalid()) {
                return type2;
            }
            
            // Look into globally registered prototypes
            int count2 = getJSContext().getRegistry().getGlobalPrototypeCount();
            for( int i=0; i<count2; i++ ) {
                FBSType type3 = getJSContext().getRegistry().getGlobalPrototype(i).getPropertyFBSType(getJSContext(),name);
                if(!type3.isInvalid()) {
                    return type3;
                }
            }

            return FBSType.invalidType;
        }
        public Descriptor.Member[] getAllSymbols() {
            ArrayList vc = new ArrayList();
            // Look for the objects declared in the source code
            JavaScriptSourceInfo.JSObject[] objects = jsInfo.getAllObjects(pos);
            if(objects!=null) {
                for( int i=0; i<objects.length; i++) {
                    JavaScriptSourceInfo.JSObject jsObject = objects[i];
                    if( jsObject instanceof JavaScriptSourceInfo.JSVariable ) {
                        JavaScriptSourceInfo.JSVariable v = (JavaScriptSourceInfo.JSVariable)jsObject;
                        Descriptor.Field field = new Descriptor.Field(getJSContext(),v.getName(),v.getType(),false);
                        field.setPriority((byte)0);
                        vc.add(field);
                    } if( jsObject instanceof JavaScriptSourceInfo.JSFunction ) {
                        JavaScriptSourceInfo.JSFunction f = (JavaScriptSourceInfo.JSFunction)jsObject;
                        Descriptor.Param[] params = new Descriptor.Param[f.getParameterCount()];
                        for(int j=0; j<params.length; j++) {
                            JavaScriptSourceInfo.JSVariable p = f.getParameter(j);
                            params[j] = new Descriptor.Param(p.getName(),p.getType());
                        }
                        Descriptor.Method method = new Descriptor.Method(getJSContext(),f.getName(),f.getReturnType(),params);
                        method.setPriority((byte)0);
                        vc.add(method);
                    }
                }
            }
            // Get the list of global symbols
            int count=getGlobalCount();
            for( int i=0; i<count; i++ ) {
                String alias = getGlobalAlias(i);
                Descriptor.Field field = new Descriptor.Field(getJSContext(),alias,getGlobalObjectType(i),false);
                field.setPriority((byte)1);
                vc.add(field);
            }
            
            // Look into the wrappers
            Descriptor.Member[] regLib = getJSContext().getRegistry().getRegistryObject().getMembers(getJSContext());
            for( int i=0; i<regLib.length; i++ ) {
                Descriptor.Member m = regLib[i];
                m.setPriority((byte)2);
                vc.add(m);
            }

            // Look into default JS library
            Descriptor.Member[] defLib = getJSContext().getRegistry().globalObjectPrototype.getMembers(getJSContext());
            for( int i=0; i<defLib.length; i++ ) {
                Descriptor.Member m = defLib[i];
                m.setPriority((byte)2);
                vc.add(m);
            }

            // Look into global prototypes
            int countProto = getJSContext().getRegistry().getGlobalPrototypeCount();
            for( int p=0; p<countProto; p++ ) {
                Descriptor.Member[] members = getJSContext().getRegistry().getGlobalPrototype(p).getMembers(getJSContext());
                for( int i=0; i<members.length; i++ ) {
                    Descriptor.Member m = members[i];
                    m.setPriority((byte)3);
                    vc.add(m);
                }
            }
            
            //Get prototypes from the object
            Map prototypes = getDataPrototypes();
            if (prototypes != null && prototypes.size() != 0)
            {
                Collection protoCollection = prototypes.values();
                Iterator protoObjectIter = protoCollection.iterator();
                while (protoObjectIter.hasNext())
                {
                    FBSDefaultObject next = (FBSDefaultObject)protoObjectIter.next();
                    Descriptor.Member[] members = next.getMembers(getJSContext());
                    for( int i=0; i<members.length; i++ ) {
                        Descriptor.Member m = members[i];
                        m.setPriority((byte)4);
                        vc.add(m);
                    }
                }
            }
            
            // Get the list 
            return (Descriptor.Member[])vc.toArray(new Descriptor.Member[vc.size()]);
        }

        protected abstract int getGlobalCount();
        protected abstract FBSType getGlobalObjectType(int index);
        protected abstract String getGlobalAlias(int index);
        protected abstract Map getDataPrototypes();
    }
}
