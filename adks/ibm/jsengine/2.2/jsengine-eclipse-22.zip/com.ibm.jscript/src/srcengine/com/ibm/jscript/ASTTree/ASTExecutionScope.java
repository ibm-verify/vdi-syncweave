/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import java.util.ArrayList;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.std.FunctionObject;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSUndefined;

public abstract class ASTExecutionScope extends ASTNode{

    public static ASTExecutionScope getExecutionScope(ASTNode node) {
    	while(node!=null) {
    		if(node instanceof ASTExecutionScope) {
    			return (ASTExecutionScope)node;
    		}
    		node = node.getParent();
    	}
    	return null;
    }
	
	public static final int USE_STRICT	 		= 1;
	public static final int USE_IBM_LISTOP		= 2;
	public static final int USE_IBM_LISTOP_NO	= 3;

	public static int getDirective(ASTNode node) {
		if(node instanceof ASTLiteral) {
			String s = ((ASTLiteral)node).getStringProlog();
			if(StringUtil.isNotEmpty(s) && s.startsWith("use ")) {
				if(s.equals("use strict")) {
					return USE_STRICT;
				} else if(s.equals("use ibm.listop")) {
					return USE_IBM_LISTOP;
				} else if(s.equals("use ibm.listop=false")) {
					return USE_IBM_LISTOP_NO;
				}
			}
		}
		return 0;
	}
    
	ArrayList<ASTVariableDecl>	variables;
	ArrayList<ASTFunction>	functions;
	
	public ASTExecutionScope() {
	}
	
	public void addVarDecl(ASTVariableDecl vardecl) {
		if(variables==null) {
			variables = new ArrayList<ASTVariableDecl>();
		}
		variables.add(vardecl);
	}
	
	public void addFunction(ASTFunction function) {
		if(functions==null) {
			functions = new ArrayList<ASTFunction>();
		}
		functions.add(function);
	}

	// Create all the variables as undefined
    public void initContext(IExecutionContext context) throws InterpretException {
    	/*
        ECMA Section: 10.1.3: Variable Instantiation
        FunctionDeclarations are processed before VariableDeclarations, and 
        VariableDeclarations don't replace existing values with undefined
        */
		if(functions!=null) {
            FBSDefaultObject vObj=context.getVariableObject();
            for(int i=0;i<functions.size();i++){
            	ASTFunction func = functions.get(i);
        		FunctionObject fobj = func.createFunctionObject(context);
        		// Function are *not* anonymous, per ASTFunction call
        		vObj.propInitialize(func.getName(),FBSObject.P_NODELETE,fobj);
            }
        }
		if(variables!=null) {
            FBSDefaultObject vObj=context.getVariableObject();
            for(int i=0;i<variables.size();i++){
            	ASTVariableDecl var = variables.get(i);
            	for(int j=0; j<var.entries.size(); j++) {
            		String varName = var.entries.get(j).varName;
                    // createProperty creates a property only if it does not exist
                    vObj.propInitialize(varName,FBSObject.P_NODELETE,FBSUndefined.undefinedValue);
            	}
            }
        }
		
		// Initialize the context for this execution scope (assign the directives...)
		context.initExecutionScope(this);
    }
    
    public abstract Boolean isUseStrict();

	public abstract Boolean isUseListOp();
}
