/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.BuiltinConstructor;
import com.ibm.jscript.types.BuiltinFunction;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.FBSValueVector;

/**
 * Error object prototype.
 */
public class ErrorPrototype extends AbstractPrototype {

    // =================================================================
    // Native Error Prototypes
    public abstract static class NativeErrorPrototype extends ErrorPrototype {
        public NativeErrorPrototype(JSContext jsContext,String ctorName){
            super(jsContext,ctorName);
        }
        protected abstract ErrorObject createError(IExecutionContext context, FBSValue msg);
    }
    public static class EvalErrorPrototype extends NativeErrorPrototype {
        public EvalErrorPrototype(JSContext jsContext){
            super(jsContext,"EvalError"); // $NON-NLS-1$
        }
        protected ErrorObject createError(IExecutionContext context, FBSValue msg) {
            return new ErrorObject.EvalErrorObject(getJSContext(),msg);
        }
    }
    public static class RangeErrorPrototype extends NativeErrorPrototype {
        public RangeErrorPrototype(JSContext jsContext){
            super(jsContext,"RangeError"); // $NON-NLS-1$
        }
        protected ErrorObject createError(IExecutionContext context, FBSValue msg) {
            return new ErrorObject.RangeErrorObject(getJSContext(),msg);
        }
    }
    public static class ReferenceErrorPrototype extends NativeErrorPrototype {
        public ReferenceErrorPrototype(JSContext jsContext){
            super(jsContext,"ReferenceError"); // $NON-NLS-1$
        }
        protected ErrorObject createError(IExecutionContext context, FBSValue msg) {
            return new ErrorObject.ReferenceErrorObject(getJSContext(),msg);
        }
    }
    public static class SyntaxErrorPrototype extends NativeErrorPrototype {
        public SyntaxErrorPrototype(JSContext jsContext){
            super(jsContext,"SyntaxError"); // $NON-NLS-1$
        }
        protected ErrorObject createError(IExecutionContext context, FBSValue msg) {
            return new ErrorObject.SyntaxErrorObject(getJSContext(),msg);
        }
    }
    public static class TypeErrorPrototype extends NativeErrorPrototype {
        public TypeErrorPrototype(JSContext jsContext){
            super(jsContext,"TypeError"); // $NON-NLS-1$
        }
        protected ErrorObject createError(IExecutionContext context, FBSValue msg) {
            return new ErrorObject.TypeErrorObject(getJSContext(),msg);
        }
    }
    public static class URIErrorPrototype extends NativeErrorPrototype {
        public URIErrorPrototype(JSContext jsContext){
            super(jsContext,"URIError"); // $NON-NLS-1$
        }
        protected ErrorObject createError(IExecutionContext context, FBSValue msg) {
            return new ErrorObject.URIErrorObject(getJSContext(),msg);
        }
    }

    
    // =================================================================
    // Standard Error Prototypes
    public ErrorPrototype(JSContext jsContext){
        this(jsContext,"Error"); // $NON-NLS-1$
    }
    protected ErrorPrototype(JSContext jsContext, String ctorName){
        super(jsContext);// $NON-NLS-1$
        int attrib=FBSObject.P_NOENUM;
        createConstructor(attrib,new ErrorConstructor(jsContext,this,ctorName));
        createMethod("toString",attrib,new ErrorMethod(jsContext,0)); //$NON-NLS-1$
        createMethod("getCause",attrib,new ErrorMethod(jsContext,1)); //$NON-NLS-1$
        FBSString sCtor = FBSString.get(ctorName);
        createProperty("name",attrib,sCtor); //$NON-NLS-1$
        createProperty("message",attrib,sCtor); //$NON-NLS-1$
    }
    public String getTypeAsString(){
        return "Error"; //$NON-NLS-1$
    }

    protected ErrorObject createError(IExecutionContext context, FBSValue msg) {
        return new ErrorObject(getJSContext(),msg);
    }
    

    ////// Constructor
    static class ErrorConstructor extends BuiltinConstructor{
        public ErrorConstructor(JSContext jsContext, ErrorPrototype prototype, String globalName){
            super(jsContext,prototype,globalName); // $NON-NLS-1$
        }
        public boolean hasInstance(FBSValue v){
            return v instanceof ErrorObject;
        }
        protected String[] getCallParameters() {
            return new String[] {"():T"}; //$NON-NLS-1$
        }
        protected String[] getConstructorParameters() {
            return getCallParameters();
        }
        public boolean supportConstruct(){
            return true;
        }
        public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
            if(args.getCount()==0) {
                return ((ErrorPrototype)getPrototype()).createError(context,null);
            }
            if(args.getCount()>=1) {
                FBSValue msg = args.get(0);
                return ((ErrorPrototype)getPrototype()).createError(context,msg);
            }
            throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Invalid ErrorObject class constructor arguments"));  // $NLS-ErrorPrototype.InvalidErrorObjectclassconstructo-1$
        }
        public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this) throws InterpretException {
            return construct(context, args);
        }
    }
    
    ////// Method
    static class ErrorMethod extends BuiltinFunction{
        int mIndex=-1;

        public ErrorMethod(JSContext jsContext, int index){
            super(jsContext);
            mIndex=index;
        }

        protected String[] getCallParameters() {
            switch(mIndex) {
                case 0: //toString
                    return new String[] {"():T"}; //$NON-NLS-1$
                case 1: //getCause
                    return new String[] {"():Ljava.lang.Throwable;"}; //$NON-NLS-1$
            }
            return super.getCallParameters();
        }


        public FBSValue call(FBSValueVector args, FBSObject _this) throws InterpretException {
            return FBSUndefined.undefinedValue;
        }

        public FBSValue call(IExecutionContext context, FBSValueVector args, FBSObject _this) throws InterpretException {
            switch(mIndex){
            
                ///////////////////////////////////////////////////////////////
                // Standard ECMA functions
                case 0: {     // toString
                    if(_this instanceof ErrorObject) {
                        return ((ErrorObject)_this).getMessage();
                    }
                    if(_this instanceof ErrorPrototype) {
                        return ((ErrorPrototype)_this).get("message"); // $NON-NLS-1$
                    }
                    if(_this==null) {
                        return FBSString.emptyString;
                    }
                    throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Object is not an error, {0}",FBSUtility.getDisplayType(_this))); // $NLS-ErrorPrototype.TypeErrorObjectisnotanerror-1$
                }
                case 1: {     // getCause
                    if(_this instanceof ErrorObject) {
                        return FBSUtility.wrap(context.getJSContext(),((ErrorObject)_this).getCause());
                    }
                    throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Object is not an error, {0}",FBSUtility.getDisplayType(_this))); // $NLS-ErrorPrototype.TypeErrorObjectisnotanerror-1$
                }
            }
            throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Error function not found")); // $NLS-ErrorPrototype.Booleanfunctionnotfound-1$
        }
    }

}