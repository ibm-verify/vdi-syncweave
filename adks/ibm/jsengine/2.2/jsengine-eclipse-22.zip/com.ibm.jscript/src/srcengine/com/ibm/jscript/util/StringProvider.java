/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.util;


/**
 * 
 */
public class StringProvider implements ICharProvider {
    public StringProvider() {
    }
    public StringProvider(String str) {
        setString(str);
    }
    public void setString( String str ) {
        this.str = str;
    }
    public int length() {
        return str.length();
    }
    public char charAt(int pos) {
        return str.charAt(pos);
    }
    public String getString(int fc,int lc) {
        return str.substring(fc,lc);
    }
    public char[] getChars(int fc,int lc,char[] c,int dst) {
        str.getChars(fc,lc,c,dst);
        return c;
    }
    private String str;
}

