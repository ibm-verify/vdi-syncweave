/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import com.ibm.jscript.JSContext;

public class InterfacesWrapperObject extends GeneratedWrapperObject {

	public static class WrapperFactory implements IWrapperFactory {
		private MethodMap map;
		WrapperFactory(MethodMap map) {
			this.map = map;
		}
		public GeneratedWrapperObject wrap(JSContext jsContext, Object o) {
			return new InterfacesWrapperObject(jsContext,o,map);
		}
		public GeneratedWrapperObject.MethodMap getMethodMap(JSContext context) {
			return map;
		}
	}
	
	private MethodMap map;
	
	public InterfacesWrapperObject(JSContext jsContext, Object object, MethodMap map) {
        super(jsContext,object,object.getClass().getName());
		this.map = map;
	}

	public GeneratedWrapperObject.MethodMap getMethodMap() {
		return map;
	}
    
	public Class getWrappedClass() {
		return map.getWrappedClass();
	}
	
	public String getTypeAsString() {
		return getWrappedClass().getName();
	}
}
