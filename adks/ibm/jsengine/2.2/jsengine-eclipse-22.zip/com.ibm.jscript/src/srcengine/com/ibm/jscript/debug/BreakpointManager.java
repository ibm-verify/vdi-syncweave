/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.debug;

import java.util.HashMap;

public class BreakpointManager {
	
	private static BreakpointManager fInstance    = null;
	private static HashMap           fBreakpoints = null;
	
	public BreakpointManager() {
		fBreakpoints = new HashMap(10);
	}
		
	public static BreakpointManager getInstance() {
		if (fInstance == null)
			fInstance = new BreakpointManager();
		return fInstance;
	}
	
	public void addBreakpoint(String sourceID, int lineNumber) {
		//First strip the hashcode off the end of the ID...we don't want it.
        //DTAIEB: I'm not sure we need this anymore
//		int hashCode = sourceID.lastIndexOf(':'); //$NON-NLS-1$  
//		if (hashCode > 0)
//			sourceID = sourceID.substring(0,hashCode);
		
		Breakpoint b = getBreakpoint(sourceID, lineNumber);
		if (b == null) {
			b = new Breakpoint(sourceID, lineNumber);
			fBreakpoints.put(getUniqueID(sourceID, lineNumber), b);
		}
	}
		
	public void removeBreakpoint(String sourceID, int lineNumber) {
		fBreakpoints.remove(getUniqueID(sourceID, lineNumber));
	}
    
	public void clearBreakpoints() {
        fBreakpoints.clear();
    }
	
	//A breakpoint is identified by it's sourceID and lineNumber
	public Breakpoint getBreakpoint(String sourceID, int lineNumber) {
		String uniqueID = getUniqueID(sourceID, lineNumber);
		Object bObj     = fBreakpoints.get(uniqueID);
		if (bObj == null)
			return null;
		return (Breakpoint)bObj;
	}
	
	public boolean enabledBreakpointExists(String sourceID, int lineNumber) {
        //System.out.println("checking bp for " + sourceID + " at line number : " + lineNumber );
        if ( sourceID == null ){
            return false;
        }
		//Strip off the hashcode before comaparing:
        //DTAIEB: this is not needed anymore
//		int hashCode = sourceID.lastIndexOf(':');
//		if (hashCode > 0){
//			sourceID = sourceID.substring(0,hashCode);
//        }
		
		//System.out.println("BreakpointManager.enabledBreakpointExists(\"" + sourceID + "\","+ lineNumber + ")" );
		//System.out.println("  Current Breakpoints: \n      " + fBreakpoints.keySet());
		return getBreakpoint(sourceID, lineNumber) != null;
	}
	
	//To get a unique hash id, we just concatenate the sourceID and lineNumber:
	private String getUniqueID (String sourceID, int lineNumber) {
		return sourceID + "__" + lineNumber; //$NON-NLS-1$
	}
		
	class Breakpoint {
		public String   fSourceID   = null;
		public int      fLineNumber = 0;
		
		public Breakpoint (String sourceID, int lineNumber) {
			fSourceID = sourceID;
			fLineNumber = lineNumber;
		}
	}
}
