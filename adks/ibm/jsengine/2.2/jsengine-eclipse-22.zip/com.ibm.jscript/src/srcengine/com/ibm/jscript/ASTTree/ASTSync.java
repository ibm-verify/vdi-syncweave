/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSValue;

public class ASTSync extends ASTNode{
    public static final int SYNC_EXPR=0;
    public static final int BLOCK=1;

    ASTNode syncExpr;
    ASTNode block;

    public ASTSync() {
    }


    public ASTSync(ASTNode exprNode,ASTNode blockNode) {
        syncExpr=assignParent(exprNode);
        block=assignParent(blockNode);
    }


    public void addSyncExpr(ASTNode exprNode){
        syncExpr=assignParent(exprNode);
    }


    public void addBlock(ASTNode blockNode){
        block=assignParent(blockNode);
    }


    public int getSlotCount(){
        return 2;
    }


    public ASTNode readSlotAt(int index){
        switch(index){
            case SYNC_EXPR: return syncExpr;
            case BLOCK: return block;
        }
        return null;
    }


    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            if(!syncExpr.interpret(this,context,result)) {
            	return false;
            }
            FBSValue syncValue= result.getFBSValue();
            if (!syncValue.canFBSObject()){
                if( syncValue.isNull() ) {
                    throw new InterpretException(null,"'{0}' is null",syncExpr.getTraceString()); //$NLS-ASTSync.ASTSync.SyncValNotNull.Exception-1$
                }
                if( syncValue.isUndefined() ) {
                    throw new InterpretException(null,"'{0}' is undefined",syncExpr.getTraceString()); //$NLS-ASTSync.ASTSync.SyncValUndefined.Exception-1$
                }
                throw new InterpretException(null,"'{0}' is not an object",syncExpr.getTraceString()); //$NLS-ASTSync.ASTSync.SyncValNotAnObj.Exception-1$
            }
            Object syncObject=syncValue.toFBSObject(context.getJSContext()).getSyncObject();

            synchronized(syncObject){
                if(!block.interpret(this,context,result)) {
                	return false;
                }
            }
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
	return v.visitSync(this, param);
    }
}
