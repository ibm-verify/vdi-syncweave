/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.debug;

import java.util.ArrayList;
import java.util.Iterator;

import com.ibm.commons.util.TDiag;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.std.DateObject;
import com.ibm.jscript.std.FunctionObject;
import com.ibm.jscript.std.NumberObject;
import com.ibm.jscript.std.RegExpObject;
import com.ibm.jscript.types.FBSBoolean;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.JavaWrapperObject;

public class ServerVariable 
{
    public static final int TYPE_SIMPLE      = 0;
    public static final int TYPE_JSOBJECT    = 1;
    public static final int TYPE_JAVAOBJECT  = 2;
    public static final String TYPE_SIMPLE_STR      = "0";
    public static final String TYPE_JSOBJECT_STR    = "1";
    public static final String TYPE_JAVAOBJECT_STR  = "2";
    
    
    private  int               fType               = TYPE_SIMPLE;
    private  String            fName               = null;
    private  String            fTypeString         = null;
    private  String            fValueString        = null;
    private  ArrayList         fVariables          = null;
    private  String            fVariablesInfo      = null;
    private  FBSDefaultObject  fFBSObject          = null; 
    private  Object            fJavaObject         = null;
    private  Integer           fUniqueID           = null;
    
    /**************************************************************
     * Constructors
     **************************************************************
     */
    public ServerVariable(String name, String typeString, String valueString) {
        this(TYPE_SIMPLE, name, typeString, valueString);
    }
    
    public ServerVariable(String name, String typeString, String valueString, FBSDefaultObject fbsObject ) {
        this(TYPE_JSOBJECT, name, typeString, valueString);
        fFBSObject = fbsObject;
    }
    
    public ServerVariable(String name, String typeString, String valueString, JavaWrapperObject javaWrapperObject ) {
        this(TYPE_JAVAOBJECT, name, typeString, valueString);
        fJavaObject = javaWrapperObject.getJavaObject();
    }
    private ServerVariable(int type, String name, String typeString, String valueString) {
        fType        = type;
        fName        = name;
        fTypeString  = typeString;
        fValueString = valueString;
        fVariables   = new ArrayList(5);
    }
    
    
    
    /**************************************************************
     * Simple getters
     **************************************************************
     */
    public int    getType() { return fType;}
    public String getName() { return fName;}
    public String getTypeString() { return fTypeString;}
    public String getValue() { return fValueString;}
    public Integer getUniqueID() { return fUniqueID; }
    
    /**************************************************************
     * setUniqueID()
     * The unique ID is an int that can be used to locate this Variable in the 
     * StackFrame's ArrayList of Variables.
     **************************************************************
     */
    public void setUniqueID(int uniqueID) {
        fUniqueID = new Integer(uniqueID);
    }
    
    /**************************************************************
     * THOD CALLED BY DEBUG CLIENT - getObject()
     * For JavaAccessObjects, the client will get the Object 
     * create a JDIValue out of it so that it can be viewed
     * like variables in other Java Debug sessions.
     **************************************************************
     */
    public Object getJavaObject() {
        return fJavaObject;
    }
    
    /**************************************************************
     * METHOD CALLED BY DEBUG CLIENT - getVariables()
     * Construct an ArrayList of Strings that describes all the Variables.  Then convert this 
     * to a String so that the client can read it easily.  This is due to performance hits for 
     * multiple Array reads from the client side. 
     * 
     * The format is as follows:
     *  0 Variable Name
     *  1 Variable Value
     *  2 Variable Type
     *  3 Variable Unique ID
     *  4 Variable isObject() ("0"=false, "1"=true)
     ***************************************************************
    */
   private boolean firstTime = true; 
   public String getVariables() {
       try {
       
       if (firstTime && (fFBSObject != null) && (fFBSObject instanceof FBSDefaultObject)) {
           createVariables((FBSDefaultObject)fFBSObject);
       }
         
       firstTime = false;
       
       if (fVariablesInfo == null) {
           ArrayList theInfo = new ArrayList(fVariables.size() * 5);
           try {
               for (int i=0; i<fVariables.size();i++) {
                   ServerVariable variable = (ServerVariable)fVariables.get(i);
                   theInfo.add(getTypeAsString(variable.getType()));
                   theInfo.add(variable.getName());
                   theInfo.add(variable.getTypeString());
                   theInfo.add(variable.getValue());
                   theInfo.add(new String("" + variable.getUniqueID())); //$NON-NLS-1$
               }
           } catch (Exception e) {
               TDiag.exception(e,""); //$NON-NLS-1$
           }
           fVariablesInfo = ArrayListUtil.arrayListToString(theInfo);
       }
       } catch (Throwable e) {
           TDiag.exception(e);
       }
       return fVariablesInfo; 
   }   
     
       
    /**************************************************************
     * METHOD CALLED BY DEBUG CLIENT - getVariable()
     * Return the ServerVariable based on uniqueID (its place in fVariables)
     **************************************************************
     */
    public Object getVariable(int uniqueID) {
        ServerVariable variable = (ServerVariable)fVariables.get(uniqueID);
        if (variable != null) {
            return variable;
        }
        if ( Util.traceEnabled() ){
            Util.trace("getVariable", "Unable to find variable #" + uniqueID + ".  There are " + fVariables.size() + " variables in fVariables"); // $NON-NLS-1$ $NON-NLS-2$ $NON-NLS-3$ $NON-NLS-4$
        }
        return null;
    }  
    
    /******** PRIVATE METHODS from this point and below ***********/
    
    
    /**************************************************************
     * createVariables()
     * Static method that can be used from both a ServerStackFrame or 
     * a ServerVariable to create ServerVariables
     **************************************************************
     */
    private ArrayList createVariables(FBSDefaultObject variableObject) {
       
        if ( variableObject != null ) {
            Iterator iter = variableObject.getPropertyKeys();
            while (iter.hasNext()) {
                //Get the variable name, and if its the arguments, skip it:
                String variableName = (String)iter.next();
                
                // If we're dealing with the arguments object skip it
               //if (variableName.equals("arguments")) { //$NON-NLS-1$
               //     continue;
               // }
                
                //Now get the VaribleValue and FBSType:
                //FBSValue valueObject = variableObject.getPropertyByName(variableName).getValue();
                //Need to handle Arrays and functions specially:
                FBSValue valueObject = null;
                String typeString = variableObject.getTypeAsString();
                if (typeString.equals("Array")) { //$NON-NLS-1$ 
                try {
                        valueObject = (FBSValue)variableObject.getArrayElement(Integer.parseInt(variableName));
                    } catch (InterpretException e) {
                        //ignore for now
                    }
                } else {
                    valueObject = variableObject.getPropertyByName(variableName).getValue();
                }
                
                if (valueObject == null) {
                    continue;
                }
                           
                //Handle Boolean:
                if (valueObject.isBoolean()) {
                    boolean booleanValue = valueObject.booleanValue();
                    addVariable(new ServerVariable(variableName, valueObject.getTypeAsString(), Boolean.toString(booleanValue)));                
                } 
                //Handle Number:
                else if (valueObject.isNumber()) {
                    String numberValue = valueObject.stringValue();
                    addVariable(new ServerVariable(variableName, "Number", numberValue)); // $NLS-ServerVariable.Number-1$
                } 
                //Handle String:
                else if (valueObject.isString()) {
                    String stringValue = valueObject.stringValue();
                    addVariable(new ServerVariable(variableName, valueObject.getTypeAsString(), stringValue));  
                }
                //Handle Date:
                else if (valueObject instanceof DateObject) {
                    DateObject dateObject = (DateObject)valueObject;
                    String dateString = dateObject.toDateString();
                    addVariable(new ServerVariable(variableName, "Date", dateString)); // $NLS-ServerVariable.Date-1$
                }
                //Handle RegExp:
                else if (valueObject instanceof RegExpObject) {
                    RegExpObject regexpObject = (RegExpObject)valueObject;
                    String regexpString = regexpObject.stringValue();
                    addVariable(new ServerVariable(variableName, "RegExp", regexpString)); // $NLS-ServerVariable.RegExp-1$
                }
               
                           
                
                //If the Value is not an object, handle it:
                else if (!(valueObject instanceof FBSObject)) {
                    addVariable(new ServerVariable(variableName, valueObject.getTypeAsString(), valueObject.stringValue()));
                }
                    
                        
                else if ( valueObject instanceof JavaWrapperObject ) {
                    try {
                        JavaWrapperObject wrapperObject = (JavaWrapperObject)valueObject;
                        addVariable(new ServerVariable(variableName, wrapperObject.getTypeAsString(), "", wrapperObject));
                    } catch (Exception e) {
                    	e.printStackTrace();
                    }
                }
                //Else, the Value is an Object so handle it:
                else if ( (!(valueObject instanceof FunctionObject)) && (valueObject instanceof FBSDefaultObject)){
                    try {
                        FBSDefaultObject fbsDefaultObject = (FBSDefaultObject)valueObject.toFBSObject(variableObject.getJSContext());
                        addVariable(new ServerVariable(variableName, fbsDefaultObject.getTypeAsString(), "", fbsDefaultObject));
                    } catch (InterpretException e) {
                    	e.printStackTrace();
                    }
                }
            }
        }
       
        return fVariables;
    }
    


    /**************************************************************
     * addVariable()
     * Helper method to add a variable to fVariables and update the 
     * unique ID for the variable based on the size of fVariables
     ***************************************************************
     */
    public void addVariable(ServerVariable variable) {
        variable.setUniqueID(fVariables.size());
        fVariables.add(variable);
    }
    
    
    
    private String getTypeAsString(int type) {
        if (type == TYPE_JAVAOBJECT)
            return TYPE_JAVAOBJECT_STR;
        if (type == TYPE_JSOBJECT)
            return TYPE_JSOBJECT_STR;
        return TYPE_SIMPLE_STR;
    }
    
    
}
