/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSReference;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.JavaAccessObject;
import com.ibm.jscript.types.JavaWrapperObject;

public class ASTForIn extends ASTNode implements ILabelledStatement {
    public static final int ITERATOR=0;
    public static final int COLLECTION=1;
    public static final int STATEMENT=2;

    ASTNode iteratorNode;
    ASTNode collectionNode;
    ASTNode statementNode;
    String labelName;

    public ASTForIn() {
    }
    
	public void setLabelName(String label) {
		this.labelName = label;
	}

    public void add(ASTNode iterator,ASTNode collection,ASTNode statement){
        iteratorNode=assignParent(iterator);
        collectionNode=assignParent(collection);
        statementNode=assignParent(statement);
    }

    public int getSlotCount(){
        return 3;
    }

    public ASTNode readSlotAt(int index){
        switch(index){
            case ITERATOR:     return iteratorNode;
            case COLLECTION:   return collectionNode;
            case STATEMENT:    return statementNode;
        }
        return null;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            if (iteratorNode instanceof ASTVariableDecl){
                if(!iteratorNode.interpret(this,context,result)) {
                	return false;
                }
                // after evaluating the declaration, convert the iteratorNode to ASTIdentifier
                // because it will be evaluated repeatedly
                String name=((ASTVariableDecl)iteratorNode).getEntryAt(0).getName();
                iteratorNode=new ASTIdentifier(name,iteratorNode.getBeginCol(),iteratorNode.getBeginLine(),
                                                iteratorNode.getEndCol(),iteratorNode.getEndLine());
            }

            if(!collectionNode.interpret(this,context,result)) {
            	return false;
            }
    /*        if (!result.isFBSValue()){
                throw new InterpretException("Illegal result type. Value expected",getLine(),getCol());
            }
    */
            FBSValue v=null;
            FBSObject obj=result.getFBSValue().toFBSObject(context.getJSContext());
            FBSValue.IValues values=obj.getValues();

            for(;;){
                if (!values.hasNext()){
                    break;
                }

                if(!iteratorNode.interpret(this,context,result)) {
                	return false;
                }

                if (result.isReference()){
                    FBSReference ref=result.getReference();
                    ref.putValue(values.next());
                }else{
                    throw new InterpretException(null,"Illegal result type. Reference expected"); //$NLS-ASTForIn.ASTForIn.IllegalResultType.Exception-1$
                }

                if(!statementNode.interpret(this, context, result)) {
                	if(result.isBreakSignal()) {
                        String label = context.getProgramContext().getLoopLabel();
                    	if(!StringUtil.isEmpty(label)) {
                    		if(!StringUtil.equals(label,labelName)) {
                    			return false;
                    		}
                    	}
                        // Break the loop
                    	result.resetSignal();
                        break;
                	} else if(result.isContinueSignal()) {
                        String label = context.getProgramContext().getLoopLabel();
                    	if(!StringUtil.isEmpty(label)) {
                    		if(!StringUtil.equals(label,labelName)) {
                    			return false;
                    		}
                    	}
                        // Continue the loop
                    	result.resetSignal();
                        //continue;
                	} else {
            			return false;
                	}
                } else {
	                // Store the resulting value
	                FBSValue res = result.getFBSValue(); 
	                if (res!=null) { 
	                	v=res;
	                }
                }
            }
            result.setNormal(v);
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }


    private Object getJavaObject(FBSObject o){
        if (o==null){
            return null;
        }

        if (o instanceof JavaAccessObject){
            return ((JavaAccessObject)o).getJavaObject();
        }

        if (o instanceof JavaWrapperObject){
            return ((JavaWrapperObject)o).getJavaObject();
        }

        return null;
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitForIn(this, param);
    }
}
