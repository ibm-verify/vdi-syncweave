/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import java.util.ArrayList;

import com.ibm.commons.util.FastStringBuffer;
import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.util.StringParser;

public final class Descriptor {

    // V        void
    // C        char
    // B        byte
    // S        short
    // I        int
    // J        long
    // F        float
    // D        double
    // Z        boolean
    // T        string
    // Y        date/time
    // A        Array
    // O        Object
    // U        Function
    // R        RegExp
    // W        any (variant)
    // N        Multiple (...)
    // L<name>; object
    //
    //  ex: (entries:[Lcom.ibm.workplace.designer.server.directory.DirectoryEntry;):V
    public static FBSType getFBSType( JSContext jsContext, String dt ) {
        if( dt.equals("V") ) {
            return FBSType.voidType;
        } else if( dt.equals("C") || dt.equals("T")) {
            return FBSType.stringType;
        } else if( dt.equals("B") || dt.equals("S") || dt.equals("I") || dt.equals("J") || dt.equals("F")|| dt.equals("D") ) {
            return FBSType.numberType;
        } else if( dt.equals("Z") ) {
            return FBSType.booleanType;
        } else if( dt.equals("Y") ) {
            return FBSType.dateType;
        } else if( dt.equals("A") ) {
            return FBSType.jsArrayType;
        } else if( dt.equals("O") ) {
            return FBSType.jsObjectType;
        } else if( dt.equals("U") ) {
            return FBSType.jsFunctionType;
        } else if( dt.equals("R") ) {
            return FBSType.regExpType;
        } else if( dt.equals("N") ) {
            return FBSType.multipleType;
        } else if( dt.startsWith("L") ) {
            String javaClass = dt.substring(1,dt.length()-1);
            return FBSType.getType(jsContext,javaClass);
        }
        return FBSType.undefinedType;
    }

    public static final int CONSTRUCTOR = 0;
    public static final int METHOD      = 1;
    public static final int FIELD       = 2;


    // =======================================================================
    // NEW CODE
    // =======================================================================

    private static final int FLAG_STATIC     = 0x0001;
    private static final int FLAG_HIDDEN     = 0x0002;
    private static final int FLAG_DEPRECATED = 0x0004;
    private static final int FLAG_ADVANCED   = 0x0008;

    public static abstract class Member {
        protected JSContext jsContext;
        protected String name;
        protected int flags;
        
        Member( JSContext jsContext, String name ) {
            this.jsContext = jsContext;
            this.name = name;
        }
        
        public final String getName() {
            return name;
        }
        
        public byte getPriority() {
            return (byte)((flags & 0xFF00) >> 8);
        }
        
        public void setPriority(byte priority) {
            flags = (flags & 0x00FF) | ((priority << 8) & 0xFF00);
        }
        
        public abstract boolean equals(Object o); // Needs to be implemented
        public int hashCode() {
            return getName().hashCode();
        }

        public abstract int getMemberType();
        public abstract FBSType getType();
        public final String toJavaScript() {
            if( jsString==null ) {
                jsString=toJavaScriptString();
            }
            return jsString;
        }
        public abstract String toJavaScriptString();
        public String toString() {
            return toJavaScript();
        }

        public boolean isStatic(){
            return (flags & FLAG_STATIC)!=0;
        }

        public boolean isHidden(){
            return (flags & FLAG_HIDDEN)!=0;
        }

        public boolean isDeprecated(){
            return (flags & FLAG_DEPRECATED)!=0;
        }

        public boolean isAdvanced(){
            return (flags & FLAG_ADVANCED)!=0;
        }

        private String jsString;

    }

    public static class Field extends Member {
        private FBSType type;

        public Field( JSContext jsContext, String name, FBSType type, boolean _static ) {
            super(jsContext,name);
            if(_static) flags |= FLAG_STATIC;
            this.type = type;
        }

        public int getMemberType() {
            return FIELD;
        }

        public boolean equals(Object o) {
            if( o instanceof Field ) {
                Field f = (Field)o;
                // The field signature is the name
                return getName().equals(f.getName());
            }
            return false;
        }

        public String toJavaScriptString() {
            //return getName() + ":" + getType().getType();
            return getName();
        }

        public FBSType getType() {
            return type;
        }
    }

    public interface IMethodParameters {
        public int getParameterCount();
        public FBSType getParameterType(int index);
    }
    
    public static abstract class BaseMethod extends Member implements IMethodParameters {
        FBSType retType;
        Param[] params;

        public BaseMethod( JSContext jsContext, String name, String descAsString ) {
            super(jsContext,name);
            // Ex:
            //"(viewName:Tcolumns:TdistinctCode:Z):[T"
            if( !StringUtil.isEmpty(descAsString) ) {
                StringParser parser = new StringParser(descAsString);
                if( parser.match('*') ) {
                    flags |= FLAG_HIDDEN;
                }
                if( parser.match('s') ) {
                    flags |= FLAG_STATIC;
                }
                if( parser.match('d') ) {
                    flags |= FLAG_DEPRECATED;
                }
                if( parser.match('x') ) {
                    flags |= FLAG_ADVANCED;
                }
                if( parser.match('(') ) {
                    ArrayList v = new ArrayList();
                    // Get the parameters
                    while(parser.getAvailable()>0 && !parser.match(')')) {
                        // Get the param name
                        String pName = parser.upto(':');
                        if( !parser.match(':') ) {
                            throw new IllegalArgumentException( "Missing ':' " ); // $NLS-Descriptor.expected-1$
                        }
                        // Get the parameter type
                        FBSType pType = getType(parser);
                        // And add it the list
                        v.add( new Param(pName,pType) );
                    }
                    params = (Param[])v.toArray( new Param[v.size()] );
                    // Get the return type
                    if( parser.match(':') ) {
                        retType = getType(parser);
                    }
                } else {
                    throw new IllegalArgumentException( "Leading '(' expected" ); // $NLS-Descriptor.leadingexpected-1$
                }
            }
        }

        public BaseMethod( JSContext jsContext, String name, FBSType retType, Param[] params ) {
            super(jsContext, name);
            this.retType = retType;
            this.params = params;
        }

        private FBSType getType( StringParser parser ) {
            String type = "";
            // Recursively compose the array type
            if( parser.match('[') ) {
                FBSType arrayType = getType(parser);
                return FBSType.getArrayType(arrayType);
            }
            // Get the simple type
            switch(parser.nextChar()) {
                case 'A':   return FBSType.jsArrayType;
                case 'B':   return FBSType.byteType;
                case 'C':   return FBSType.charType;
                case 'D':   return FBSType.doubleType;
                case 'F':   return FBSType.floatType;
                case 'I':   return FBSType.intType;
                case 'J':   return FBSType.longType;
                case 'L': {
                    String name = parser.upto(';');
                    parser.nextChar(); // Skip the ';'
                    return FBSType.getType(jsContext,name);
                }
                case 'N':   return FBSType.multipleType;
                case 'O':   return FBSType.jsObjectType;
                case 'S':   return FBSType.shortType;
                case 'T':   return FBSType.stringType;
                case 'V':   return FBSType.voidType;
                case 'W':   return FBSType.undefinedType;
                case 'R':   return FBSType.regExpType;
                case 'U':   return FBSType.jsFunctionType;
                case 'Y':   return FBSType.dateType;
                case 'Z':   return FBSType.booleanType;
            }

            return FBSType.undefinedType;
        }

        public String toJavaScriptString() {
            FastStringBuffer b = new FastStringBuffer();
            b.append( getName().trim() );
            b.append( "(" );
            if( params!=null ) {
                for( int i=0; i<params.length; i++ ) {
                    if( i>0 ) {
                        b.append( ", " );
                    }
                    String name = params[i].getName();
                    FBSType type = params[i].getType();
                    if( !StringUtil.isEmpty(name) && !type.isMultiple() ) {
                        b.append(name);
                        b.append(":");
                    }
                    b.append( type.getJSName() );
                }
            }
            b.append( ")" );
            if( getType()!=null ) {
                FBSType type = getType();
                b.append( " : " );
                b.append( type.getJSName() );
            }
            return b.toString();
        }

        public FBSType getType() {
            return retType;
        }

        public Param[] getParams() {
            return params;
        }
                
        public int getParameterCount() {
            return params!= null ? params.length : 0;
        }
        
        public FBSType getParameterType(int index) {
            return params[index].getType();
        }
        
        public Param getParameter(int index) {
            return params[index];
        }

    }

    public static class Method extends BaseMethod {
        public Method( JSContext jsContext, String name, String descAsString ) {
            super(jsContext,name,descAsString);
        }
        public Method( JSContext jsContext, String name, FBSType retType, Param[] params ) {
            super(jsContext,name,retType,params);
        }
        public Method( JSContext jsContext, String name, FBSType retType, Param[] params, boolean _static, boolean _hidden, boolean _deprecated, boolean _advanced ) {
            super(jsContext,name,retType,params);
            if(_static) flags |= FLAG_STATIC;
            if(_hidden) flags |= FLAG_HIDDEN;
            if(_deprecated) flags |= FLAG_DEPRECATED;
            if(_advanced) flags |= FLAG_ADVANCED;
        }

        public int getMemberType() {
            return METHOD;
        }
        public boolean equals(Object o) {
            if( o instanceof Method ) {
                Method m = (Method)o;
                // The method signature is the name+args
                if( name.equals(m.name) ) {
                    int srcCount = params!=null ? params.length : 0;
                    int tgtCount = m.params!=null ? m.params.length : 0;
                    if( srcCount==tgtCount ) {
                        for( int i=0; i<srcCount; i++ ) {
                            if( !params[i].equals(m.params[i]) ) {
                                return false;
                            }
                        }
                        return true;
                    }
                }
            }
            return false;
        }
    }

    public static class Constructor extends BaseMethod {
        public Constructor( JSContext jsContext, String name, String descAsString ) {
            super(jsContext,name,descAsString);
        }
        public Constructor( JSContext jsContext, String name, Param[] params ) {
            super(jsContext,name,null,params);
        }
        public int getMemberType() {
            return CONSTRUCTOR;
        }
        public boolean equals(Object o) {
            if( o instanceof Constructor ) {
                Constructor m = (Constructor)o;
                // The method signature is the name+args
                if( name.equals(m.name) ) {
                    int srcCount = params!=null ? params.length : 0;
                    int tgtCount = m.params!=null ? m.params.length : 0;
                    if( srcCount==tgtCount ) {
                        for( int i=0; i<srcCount; i++ ) {
                            if( !params[i].equals(m.params[i]) ) {
                                return false;
                            }
                        }
                        return true;
                    }
                }
            }
            return false;
        }
    }

    public static class Param {
        public String name;
        public FBSType type;

        public Param( String name, FBSType type ) {
            this.name = name;
            this.type = type;
        }

        public String toString() {
            return type.toString();
        }

        public boolean equals( Object o ) {
            if( o instanceof Param ) {
                Param p = (Param)o;
                // The param signature is the type
                return type.equals(p.type);
            }
            return false;
        }

        public String getName() {
            return name;
        }

        public FBSType getType() {
            return type;
        }
    }
}
