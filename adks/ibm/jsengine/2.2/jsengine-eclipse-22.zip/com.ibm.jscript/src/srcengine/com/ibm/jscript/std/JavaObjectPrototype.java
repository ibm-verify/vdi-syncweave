/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import java.util.HashMap;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.BuiltinFunction;
import com.ibm.jscript.types.FBSBoolean;
import com.ibm.jscript.types.FBSNull;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.FBSValueVector;

/**
 * Pseudo prototype for Java Object.
 * This is used when an interface wrapper is used, as the basic Object methods won't be
 * wrapped (toString()...)
 * 
 * @author Philippe Riand
 *
 */
public class JavaObjectPrototype extends AbstractPrototype {

    private HashMap<String,JavaObjectMethod> methods = new HashMap<String,JavaObjectMethod>();
    
    public JavaObjectPrototype(JSContext jsContext) {
        super(jsContext);
        createMethod("toString",new JavaObjectMethod(jsContext,0)); //$NON-NLS-1$
        createMethod("equals",new JavaObjectMethod(jsContext,1)); //$NON-NLS-1$
        createMethod("getClass",new JavaObjectMethod(jsContext,2)); //$NON-NLS-1$
    }
    
    private void createMethod(String name, JavaObjectMethod function){
        function.setFunctionName(name);
        methods.put(name, function);
    }
    
    public String getTypeAsString(){
        return "JavaObject"; //$NON-NLS-1$
    }

    public FBSValue get(String name) {
        return methods.get(name);
    }

    private static class JavaObjectMethod extends BuiltinFunction {
        int mIndex=-1;

        public JavaObjectMethod(JSContext jsContext, int index){
            super(jsContext);
            mIndex=index;
        }

        protected String[] getCallParameters() {
            switch(mIndex) {
                case 0: //toString
                    return new String[] {"():T"}; //$NON-NLS-1$
                case 1: //equals
                    return new String[] {"(object:W):Z"}; //$NON-NLS-1$
                case 2: //getClass
                    return new String[] {"():W"}; //$NON-NLS-1$
            }
            return super.getCallParameters();
        }

        public FBSValue call(FBSValueVector args, FBSObject _this) throws JavaScriptException {
            return FBSUndefined.undefinedValue;
        }

        public FBSValue call(IExecutionContext context, FBSValueVector args, FBSObject _this) throws JavaScriptException {
            switch(mIndex){
                case 0: {     // toString
                    Object t = _this.toJavaObject();
                    return t!=null ? FBSString.get(t.toString()) : FBSString.get("null"); // $NON-NLS-1$
                }
                case 1: {     // equals
                    Object t = _this.toJavaObject();
                    Object o = _this.toJavaObject();
                    return t!=null ? FBSBoolean.get(t.equals(o)) : FBSBoolean.FALSE;
                }
                case 2: {     // getClass
                    Object t = _this.toJavaObject();
                    return t!=null ? FBSUtility.wrap(getJSContext(),t.getClass()) : FBSNull.nullValue;
                }
            }
            throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"JavaObject function not found"));  // $NLS-JavaObjectPrototype.JavaObjectfunctionnotfound-1$
        }
    }
}