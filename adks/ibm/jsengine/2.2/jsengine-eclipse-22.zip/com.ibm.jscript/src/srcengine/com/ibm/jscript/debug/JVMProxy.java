/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.debug;
       
/**************************************************************
 * JVMProxy
 * This class is a singleton used to store preferences from the 
 * debug client and to know whether a debug client is connected. 
 **************************************************************
 */
public class JVMProxy {
             
    private static JVMProxy fInstance = null;
    private static boolean fConnected = false;
    private static boolean fStopInJavaScript = false;
    
    /**************************************************************
     * getInstance()
     * Get singleton
     **************************************************************
     */
    public static synchronized JVMProxy getInstance() {
        if (fInstance == null) {
            fInstance = new JVMProxy();
        }
        return fInstance;
    }
    
    /**************************************************************
     * DEBUG CLIENT BREAKPOINT - debuggerConnectionCallBack(...)
     * The debug client has a breakpoint on this method so that it can 
     * get a handle on this object and call our connect() method to 
     * update fConnected and let us know it has.
     **************************************************************
     */
    public boolean debuggerConnectionCallBack(JVMProxy __JVMProxy) {
        if (Util.traceEnabled()){
            Util.trace("JVMProxy", "debuggerConnectionCallBack() interpreter is processing an ASTNode... Connected : "+fConnected); // $NON-NLS-1$ $NON-NLS-2$
        }
        return fConnected;
    }
    
    
    /**************************************************************
     * METHOD CALLED BY DEBUG CLIENT - setConnectedTrue()
     * Tells us that the Debug Client has connected.
	 * Passing in a boolean from the remote side isn't stable 
     * (can get garbage collected before the method is invoked), so 
     * we have separate methods for setting the boolean true or 
     * false. 
     **************************************************************
     */
    public void setConnectedTrue() {
        if (Util.traceEnabled())
            Util.trace("JVMProxy", "setConnectedTrue() called (by client)"); // $NON-NLS-1$ $NON-NLS-2$
        fConnected = true;
    }
    
    /**************************************************************
     * METHOD CALLED BY DEBUG CLIENT - setConnectedFalse()
     * Tells us that the Debug Client has disconnected.
     * Passing in a boolean from the remote side isn't stable 
     * (can get garbage collected before the method is invoked), so 
     * we have separate methods for setting the boolean true or 
     * false. 
     **************************************************************
     */
    public void setConnectedFalse() {
        if (Util.traceEnabled())
            Util.trace("JVMProxy", "setConnectedFalse() called (by client)"); // $NON-NLS-1$ $NON-NLS-2$
        fConnected = false;
    }
    
    /**************************************************************
     * METHOD CALLED BY DEBUG CLIENT - setStopInJavaScriptTrue()
     * Tells us that the Debug Client wants to stop in JavaScript.
     * Passing in a boolean from the remote side isn't stable 
     * (can get garbage collected before the method is invoked), so 
     * we have separate methods for setting the boolean true or 
     * false. 
     **************************************************************
     */
    public void setStopInJavaScriptTrue() {
        if (Util.traceEnabled())
            Util.trace("JVMProxy", "setStopInJavaScriptTrue() called (by client)"); // $NON-NLS-1$ $NON-NLS-2$
        fStopInJavaScript = true;
    }
    
    /**************************************************************
     * METHOD CALLED BY DEBUG CLIENT - setStopInJavaScriptFalse()
     * Tells us that the Debug Client doesn't want to stop in JavaScript.
     * Passing in a boolean from the remote side isn't stable 
     * (can get garbage collected before the method is invoked), so 
     * we have separate methods for setting the boolean true or 
     * false. 
     **************************************************************
     */
    public void setStopInJavaScriptFalse() {
        if (Util.traceEnabled())
            Util.trace("JVMProxy", "setStopInJavaScriptFalse() called (by client)"); // $NON-NLS-1$ $NON-NLS-2$
        fStopInJavaScript = false;
    }
    
    
    
     /**************************************************************
     * METHOD CALLED BY DEBUG CLIENT - addBreakpoint()
     * Tells us to add a Breakpoint to the BreakpointManager
     **************************************************************
     */
    public void addBreakpoint (String sourceID, int lineNumber) {
        if (Util.traceEnabled())
            Util.trace("JVMProxy", "addBreakpoint() values = " + sourceID + " , " + lineNumber); // $NON-NLS-1$ $NON-NLS-2$
        BreakpointManager.getInstance().addBreakpoint(sourceID, lineNumber);
    }
    
    /**************************************************************
     * METHOD CALLED BY DEBUG CLIENT - clearBreakpoints()
     * Tells us to clear the Breakpoints
     **************************************************************
     */
    public void clearBreakpoints() {
        if (Util.traceEnabled())
            Util.trace("JVMProxy", "clearBreakpoints()"); // $NON-NLS-1$ $NON-NLS-2$
        BreakpointManager.getInstance().clearBreakpoints();
    }
    
    /**************************************************************
     * METHOD CALLED BY DEBUG CLIENT - removeBreakpoint()
     * Tells us to remove a Breakpoint from the BreakpointManager
     **************************************************************
     */
    public void removeBreakpoint (String sourceID, int lineNumber) {
        if (Util.traceEnabled())
            Util.trace("JVMProxy", "removeBreakpoint() values = " + sourceID + " , " + lineNumber); // $NON-NLS-1$ $NON-NLS-2$
        BreakpointManager.getInstance().removeBreakpoint(sourceID, lineNumber);
    }
    
    /**************************************************************
     * isConnected()
     * Test whether a debugger client is connected by calling the 
     * debuggerConnectionCallBack method to give the client a chance
     * to tell us they're connected
     **************************************************************
     */
    public boolean isConnected() {
        return debuggerConnectionCallBack(this);
    }
    
    /**************************************************************
     * getStopInJavaScript()
     * Simple getter
     **************************************************************
     */
    public boolean getStopInJavaScript () {
        return fStopInJavaScript;
    }
    
    
}
