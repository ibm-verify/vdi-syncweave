/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import com.ibm.jscript.JSContext;
import com.ibm.jscript.types.FBSDefaultObject;

public class ObjectObject extends FBSDefaultObject implements Externalizable {

	private FunctionObject ctor;
	
	// Serialization only ctor
	public ObjectObject() {
        super(JSContext.getStaticContext(),JSContext.getStaticContext().getRegistry().objectPrototype);
    }

    public ObjectObject(JSContext jsContext) {
        super(jsContext,jsContext.getRegistry().objectPrototype);
    }

    // Used by the function constructor as a function instance prototype
    public ObjectObject(JSContext jsContext, FBSDefaultObject prototype, FunctionObject ctor) {
        super(jsContext,prototype);
        this.ctor = ctor;
    }

    public FunctionObject getConstructor() {
    	return ctor;
    }
    
    
//    public boolean supportConstruct(){
//        return true;
//    }
//
//    public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
//        if(args.getCount()==1) {
//            FBSValue v = args.get(0);
//            if(v.isObject()) {
//                return v.toFBSObject(context.getJSContext());
//            }
//            if(v.isString() || v.isBoolean() || v.isNumber()) {
//                return v.toFBSObject(context.getJSContext());
//            }
//        }
//        return new ObjectObject(getJSContext());
//    }
//
//    protected String[] getCallParameters() {
//        return new String[] {"()","(value:W)"}; //$NON-NLS-1$ //$NON-NLS-2$
//    }
//    
//    public boolean supportCall() {
//        return true;
//    }
//    
//    public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this) throws JavaScriptException {
//        if(args.getCount()==1) {
//            FBSValue v = args.get(0);
//            if(!v.isNull() && !v.isUndefined() ) {
//                return v.toFBSObject(context.getJSContext());
//            }
//        }
//        return new ObjectObject(getJSContext());
//    }

    public boolean equals( Object o ) {
    	return this==o;
    }

    public String getTypeAsString(){
        return "Object"; //$NON-NLS-1$
    }

    public String getName(){
        return "Object"; //$NON-NLS-1$
    }
    

    // ========================================================================
    // Java Object IO.
    // ========================================================================

    public void readExternal( ObjectInput in ) throws IOException {
        super.readExternal(in);
    }

    public void writeExternal( ObjectOutput out ) throws IOException {
        super.writeExternal(out);
    }
}
