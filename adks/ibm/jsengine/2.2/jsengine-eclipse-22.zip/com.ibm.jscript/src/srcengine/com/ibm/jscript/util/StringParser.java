/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.util;


/**
 * String parser class.
 */
public class StringParser {

    /**
     *
     */
    public StringParser() {
    }

    /**
     *
     */
    public StringParser(String s) {
        setString(s);
    }


    /**
     *
     */
    public ICharProvider getCharProvider() {
        return provider;
    }

    /**
     *
     */
    public void setCharProvider( ICharProvider provider ) {
        this.provider = provider;
        this.count = provider.length();
        this.pointer = 0;
    }

    /**
     *
     */
    public void setString( String string ) {
        setCharProvider( new StringProvider(string) );
    }

    /**
     * Check if there is still some characters in the parser.
     * @return true if the end of the parser has been reached
     */
    public boolean isEOF() {
        return pointer>=count;
    }

    /**
     * Get the current parsing position.
     */
    public int getCurrentPosition() {
        return pointer;
    }

    /**
     * Set the new current parsing position.
     */
    public void setCurrentPosition(int pointer) {
        this.pointer = pointer;
    }

    /**
     * Get the next available char.
     * @return the next available char, -1 if out no character is available
     */
    public int getChar() {
        if( pointer<count ) {
            return provider.charAt(pointer);
        }
        return -1;
    }

    /**
     * Get the next available char and increment the pointer.
     * @return the next available char, -1 if out no character is available
     */
    public int nextChar() {
        if( pointer<count ) {
            return provider.charAt(pointer++);
        }
        return -1;
    }

    /**
     * Get an indexed character from the current position.
     * @param index the index position
     * @return the indexed char, -1 if out of range
     */
    public int getChar( int index ) {
        if( pointer+index<count ) {
            return provider.charAt(pointer+index);
        }
        return -1;
    }

    /**
     * Get the number of available characters.
     * @return the number of still available characters
     */
    public int getAvailable() {
        return count-pointer;
    }

    /**
     * Check if the string begin with a specific character.
     */
    public boolean startsWith( char c ) {
        if(pointer+1<=count) {
            return provider.charAt(pointer)==c;
        }
        return false;
    }

    /**
     *
     */
    public boolean match( char c ) {
        if( startsWith(c) ) {
            pointer++;
            return true;
        }
        return false;
    }

    /**
     *
     */
    public boolean startsWith( String s ) {
        int length = s.length();
        if(pointer+length<=count) {
            for( int i=0; i<length; i++ ) {
                if( provider.charAt(pointer+i)!=s.charAt(i) ) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     *
     */
    public boolean startsWithIgnoreCase( String s ) {
        int length = s.length();
        if(pointer+length<=count) {
            for( int i=0; i<length; i++ ) {
                if( Character.toUpperCase(provider.charAt(pointer+i)) != Character.toUpperCase(s.charAt(i)) ) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     *
     */
    public boolean match( String s ) {
        if( startsWith(s) ) {
            pointer+=s.length();
            return true;
        }
        return false;
    }

    /**
     *
     */
    public boolean matchIgnoreCase( String s ) {
        if( startsWithIgnoreCase(s) ) {
            pointer+=s.length();
            return true;
        }
        return false;
    }

    /**
     *
     */
    public boolean startsWithKeyWord( String s ) {
        int length = s.length();
        if(pointer+length<=count) {
            for( int i=0; i<length; i++ ) {
                if( provider.charAt(pointer+i)!=s.charAt(i) ) {
                    return false;
                }
            }
            if(pointer+length<count) {
                char c = provider.charAt(pointer+length);
                if( !Character.isJavaIdentifierPart(c) ) {
                    return true;
                }
            } else {
                return true;
            }
        }
        return false;
    }

    /**
     *
     */
    public boolean matchKeyWord( String s ) {
        if( startsWithKeyWord(s) ) {
            pointer+=s.length();
            return true;
        }
        return false;
    }

    /**
     *
     */
    public String upto( char c ) {
        int begin = pointer;
        for( ; pointer<count; pointer++ ) {
            if( provider.charAt(pointer)==c ) {
                break;
            }
        }
        return provider.getString( begin, pointer );
    }

    /**
     *
     */
    public String uptoEnd() {
        int begin = pointer;
        pointer = count;
        return provider.getString( begin, pointer );
    }

    /**
     *
     */
    public void skip() {
        if( pointer+1<=count ) {
            pointer++;
        }
    }

    /**
     *
     */
    public void skip( int length ) {
        if( pointer+length<=count ) {
            pointer+=length;
        }
    }

    /**
     *
     */
    public void skipUpto( char c ) {
        for( ; pointer<count; pointer++ ) {
            if( provider.charAt(pointer)==c ) {
                break;
            }
        }
    }

    /**
     *
     */
    public void skipUpto( String s ) {
        int length = s.length();
        if( length>0 ) {
            int last = count-length-1;
            char c = s.charAt(0);
    loop:   for( ; pointer<last; pointer++ ) {
                if( provider.charAt(pointer)==c ) {
                    for( int i=1; i<length; i++ ) {
                        if( provider.charAt(pointer+i)!=s.charAt(i) ) {
                            continue loop;
                        }
                    }
                    return;
                }
            }
        }
    }

    /**
     *
     */
    public void skipSpaces() {
        while( pointer<count ) {
            char c = provider.charAt(pointer);
            if( c!=' ' && c!='\t' && c!='\n' && c!='\r' ) {
                break;
            }
            pointer++;
        }
    }

    /**
     *
     */
    public boolean matchJavaIdentifier() {
        if(pointer+1<=count) {
            char c = provider.charAt(pointer);
            if( Character.isJavaIdentifierStart(provider.charAt(pointer)) ) {
                pointer++;
                while(pointer+1<=count && Character.isJavaIdentifierPart(provider.charAt(pointer))) {
                    pointer++;
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Get the next integer.
     */
    public int getNextInteger() {
        int ptr = pointer;
        // Check if it is a negative number
        boolean negate=false;
        if( ptr<count && provider.charAt(ptr)=='-' ) {
            negate = true;
            ptr++;
        }
        // Extract the integer
        int v = 0;
        while( ptr<count ) {
            char c = provider.charAt(ptr);
            if( Character.isDigit(c) ) {
                v = v*10 + (c-'0');
                ptr++;
            } else {
                break;
            }
        }
        // Return the integer if exists, else the min integer valeu
        if( ptr>(pointer+(negate?1:0)) ) {
            pointer = ptr;
            return negate ? -v : v;
        } else {
            return Integer.MIN_VALUE;
        }
    }

    /*
     *
     */
    private ICharProvider provider;
    private int count;
    private int pointer;
}
