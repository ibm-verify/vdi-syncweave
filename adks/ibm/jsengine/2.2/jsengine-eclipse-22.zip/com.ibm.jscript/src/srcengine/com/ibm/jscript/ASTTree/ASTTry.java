/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.std.ObjectObject;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;

public class ASTTry extends ASTNode{

    ASTNode blockNode;
    ASTNode catchNode;
    ASTNode finallyNode;
    String catchId;

    public ASTTry() {
    }

    public void add(ASTNode blockNode,String catchid,ASTNode catchNode,ASTNode finallyNode){
        this.blockNode=assignParent(blockNode);
        this.catchNode=assignParent(catchNode);
        this.finallyNode=assignParent(finallyNode);
        this.catchId=catchid;
    }

    public void addBlock(ASTNode blockNode){
        this.blockNode=assignParent(blockNode);
    }

    public void addCatch(String id,ASTNode catchNode){
        catchId=id;
        this.catchNode=assignParent(catchNode);
    }

    public void addCatch(ASTNode catchNode){
        this.catchNode=assignParent(catchNode);
    }

    public String getCatchId() {
    	return catchId;
    }
    
    public void setCatchId(String catchid){
        catchId=catchid;
    }

    public void addFinally(ASTNode finallyNode){
        this.finallyNode=assignParent(finallyNode);
    }

    public int getSlotCount(){
        return 3;
    }

    public ASTNode readSlotAt(int index){
        switch(index){
            case 0:return blockNode;
            case 1:return catchNode;
            case 2:return finallyNode;
        }
        return null;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        // When we are evaluating a constant, we rely on an exception thrown
        // to detect that it is not a constant.
        // To ensure that this exception won't be caught, we manage a flag
        // at the expression level.
        if( context.getExpression().isEvaluateConstant() ) {
            if(!blockNode.interpret(this, context, result)) {
            	return false;
            }
        } else {
            if(catchNode!=null&&finallyNode!=null) {
                try {
                    if(!blockNode.interpret(this, context, result)) {
                    	return false;
                    }
                } catch(InterpretException ie) {
                    if(!interpretCatch(this, context, result, ie)) {
                    	return false;
                    }
                } finally {
                    InterpretResult tmpResult=new InterpretResult();
                    if(!finallyNode.interpret(this, context, tmpResult)) {
                    	result.setSignal(tmpResult.getSignal());
                    	return false;
                    }
                }
            } else if(catchNode!=null) {
                try {
                    if(!blockNode.interpret(this, context, result)) {
                    	return false;
                    }
                } catch(InterpretException ie) {
                    if(!interpretCatch(this, context, result, ie)) {
                    	return false;
                    }
                }
            } else if(finallyNode!=null) {
                try {
                    if(!blockNode.interpret(this, context, result)) {
                    	return false;
                    }
                } finally {
                    InterpretResult tmpResult=new InterpretResult();
                    if(!finallyNode.interpret(this, context, tmpResult)) {
                    	result.setSignal(tmpResult.getSignal());
                    	return false;
                    }
                }
            } else {
                if(!blockNode.interpret(this, context, result)) {
                	return false;
                }
            }
        }
        return true;
    }

    private boolean interpretCatch(ASTNode caller, IExecutionContext context,InterpretResult result,InterpretException ie) throws JavaScriptException{
        ObjectObject catchObj= new ObjectObject(context.getJSContext());
        FBSValue ex = ie.getExceptionObject(context.getJSContext()); 
        if( ex!=null ) {
            catchObj.createProperty(catchId,FBSObject.P_NODELETE,ex);
        } else {
            //catchObj.createProperty(catchId,FBSObject.P_NODELETE,FBSString.get(ie.getMessage()));
            catchObj.createProperty(catchId,FBSObject.P_NODELETE,FBSUtility.wrapAsObject(context.getJSContext(),ie));
        }
        catchObj.createProperty("errorMsg",FBSObject.P_NODELETE,FBSString.get(ie.getMessage())); //$NON-NLS-1$
        context.pushToScope(catchObj);
        try {
        	if(!catchNode.interpret(this,context,result)) {
        		return false;
        	}
        } finally {
        	context.popFromScope();
        }
        return true;
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitTry(this, param);
    }
}
