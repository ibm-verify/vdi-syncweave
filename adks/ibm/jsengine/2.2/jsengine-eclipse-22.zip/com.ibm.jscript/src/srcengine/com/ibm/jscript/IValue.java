/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript;

/**
 * Javascript value interface.</p>
 * All values in javascript are stored in an object which implements this
 * interface. As stated in JavaScriptEngine documentation, this interface cannot
 * be implemented by custom code, but object are instanciated using JavaScriptEngine.wrap()
 * methods.<br>
 * When calling a Java method from JavaScript, if the method parameter is an IValue
 * object, then the JavaScript value is passed "as is" and the Java code will have
 * the IValue without any conversion. For example, this allows XSP users to send
 * the componentData object to a Java method.
 * @see JavaScriptEngine
 */
public interface IValue {

    /**
     * Check if this value represents an undefined value.</p>
     * 'undefined' is the value assigned to a variable before any value is
     * assigned.
     * @return true if this value is undefined
     */
    public boolean isUndefined();

    /**
     * Check if this value represents a null value.</p>
     * 'null' correspond to a null object.
     * @return true if this value is null
     */
    public boolean isNull();

    /**
     * Check if this value represents a number value.</p>
     * @return true if this value is a number
     */
    public boolean isNumber();

    /**
     * Check if this value represents a boolean value.</p>
     * @return true if this value is a boolean
     */
    public boolean isBoolean();

    /**
     * Check if this value represents a string.</p>
     * @return true if this value is a string
     */
    public boolean isString();

    /**
     * Check if this value represents an array.</p>
     * An array may be either a dynamic JavaScript array, or a Java array.
     * @return true if this value is an array
     */
    public boolean isArray();

    /**
     * Check if this value represents a JavaScript array.</p>
     * @return true if this value is JavaScript array
     */
    public boolean isJSArray();

    /**
     * Check if this value represents a Java array.</p>
     * @return true if this value is Java array
     */
    public boolean isJavaArray();

    /**
     * Check if this value represents a JavaScript date object.</p>
     * @return true if this value is Javascript date
     */
    public boolean isDate();

    /**
     * Check if this value represents an object.</p>
     * An array may be either a dynamic JavaScript object, or a Java object.
     * @return true if this value is an object
     */
    public boolean isObject();

    /**
     * Check if this value represents a JavaScript Object.</p>
     * @return true if this value is a JavaScript Object.
     */
    public boolean isJSObject();

    /**
     * Check if this value represents a Java Object.</p>
     * @return true if this value is a Java Object.
     */
    public boolean isJavaObject();

    /**
     * Convert the value to a Java boolean.</p>
     * @return the converted value
     */
    public boolean booleanValue();

    /**
     * Convert the value to a Java short.</p>
     * @return the converted value
     */
    public short shortValue();

    /**
     * Convert the value to a Java int.</p>
     * @return the converted value
     */
    public int intValue();

    /**
     * Convert the value to a Java long.</p>
     * @return the converted value
     */
    public long longValue();

    /**
     * Convert the value to a Java double.</p>
     * @return the converted value
     */
    public double doubleValue();

    /**
     * Convert the value to a Java string.</p>
     * @return the converted value
     */
    public String stringValue();

    /**
     * Convert the value to a Java date.</p>
     * @return the converted value
     */
    public java.util.Date dateValue();

    /**
     * Gets a java object from an JavaScript value.</p>
     * If the method is not able to convert the value to a java object, an
     * InterpretException is thrown.<br>
     * If the value already contains a Java object, then this object is returned.
     * @return Java object representing FBScript value.
     *
     */
    public Object toJavaObject() throws InterpretException;

    /**
     * Gets a java object from an Javascript value.</p>
     * The type of the returned object must be <code>_class</code> or one of its
     * subclasses.<br>
     * If the value already contains a Java object, then this object is returned.
     * If the method is not able to meet the required criteria an InterpretException
     * is thrown. In case <code>_class</code> is <b>null</b> the method is free
     * to return an object of any type.<br>
     * @param _class required for the returned java object. may be null.
     * @return Java object representing FBScript value.
     *
     */
    public Object toJavaObject(Class _class) throws InterpretException;


    // ========================================================================
    //  Object accessor
    // ========================================================================

    /**
     * Check if a named property is available.</p>
     * Only Objects and Javascript Arrays can have properties. For other kind
     * of values, it returns false.
     * @param name the property name
     * @throws InterpretException
     * @return boolean if the property is available
     */
    public boolean hasProperty(String name) throws InterpretException;

    /**
     * Get the value of a particular property.</p>
     * Only Objects and Javascript Arrays can have properties. For other kind
     * of values, it throws an exception.
     * @param name the property name
     * @throws InterpretException if the value cannot have properties
     * @return the value of the property
     */
    public IValue getProperty( String name ) throws InterpretException;


    /**
     * Set the value of a particular property.</p>
     * Only Objects and Javascript Arrays can have properties. For other kind
     * of values, it throws an exception.
     * @param name the property name
     * @param value the new value
     * @throws InterpretException if the value cannot have properties or if the
     *    property value is not compatible with the property type, when dealing
     *    with java objects.
     * @return the value of the property
     */
    public void putProperty( String name, IValue value ) throws InterpretException;


    // ========================================================================
    //  Array Accessor
    // ========================================================================

    /**
     * Get the number of elements contained in this value.</p>
     * For an array, it returns the size of the array. For other types, it simply
     * returns 1.
     * @return the number of elements contained in this value
     */
    public int getArrayLength();

    /**
     * Get the value of an indexed element.</p>
     * For an array, it returns the indexed element. For other types, it only
     * support the index '0' and return itself.
     * @param index the element index
     * @throws InterpretException
     * @return the indexed element
     */
    public IValue getArrayElement( int index ) throws InterpretException;

    /**
     * Set the value of an indexed element.</p>
     * For an array, it set the indexed element with the new value. For other
     * types, it throws an exception.
     * @param index the element index
     * @throws InterpretException
     * @return the indexed element
     */
    public void setArrayElement( int index, IValue value ) throws InterpretException;
}
