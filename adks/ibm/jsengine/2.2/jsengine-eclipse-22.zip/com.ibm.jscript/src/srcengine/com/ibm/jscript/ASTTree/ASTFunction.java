/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import java.io.PrintStream;
import java.util.ArrayList;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.parser.ParseException;
import com.ibm.jscript.std.FunctionObject;

public class ASTFunction extends ASTExecutionScope {

    public static final class Parameter {
        private String     name;
        private String     type;
        private Parameter( String name, String type ) {
            this.name = name;
            this.type = type;
        }
        public String getName() {
            return name;
        }
        public String getType() {
            return type;
        }
    }

    private int modifiers;
    private ArrayList<Parameter> params;
    private ASTNode[] nodes = ASTNode.EMPTY_ARRAY;
    private String funcName;
    private String retType;
    private boolean isExpression;
    private Boolean useStrict;
    private Boolean useListOp;

    public ASTFunction() {
    }

    public Boolean isUseStrict() {
    	return useStrict;
    }

	public Boolean isUseListOp() {
		return useListOp;
	}

    public boolean getExpression() {
    	return isExpression;
    }

    public void setExpression(boolean isExpression) {
    	this.isExpression = isExpression;
    }

    public int getModifiers() {
        return modifiers;
    }

    public void setModifiers( int modifiers ) {
        this.modifiers = modifiers;
    }

    public void setName(String name){
        funcName=name;
    }

    public String getName(){
        return funcName;
    }

    public void setReturnType(String type){
        retType = type;
    }

    public String getReturnType(){
        return retType;
    }

    public void addParameter(String name, String type){
    	if(params==null) {
    		params = new ArrayList<Parameter>();
    	}
        params.add(new Parameter(name,type));
    }

    public int getParameterCount(){
        return params!=null ? params.size() : 0;
    }

    public Parameter getParameterAt(int index){
        if (params==null || (index<0 || index>=params.size())) return null;
        return (Parameter)params.get(index);
    }

    public int getSlotCount(){
        return nodes.length;
    }

    public ASTNode readSlotAt(int index){
        return nodes[index];
    }
    
    public void initNodes(NodeVector vc) {
    	int count = vc.size();
    	this.nodes = new ASTNode[count];
    	
    	boolean checkDir = true;
    	for(int i=0; i<count; i++) {
			ASTNode n = vc.get(i);
    		if(checkDir) {
    			switch(ASTExecutionScope.getDirective(n)) {
    				case ASTExecutionScope.USE_STRICT: {
    					useStrict = Boolean.TRUE;
    				} break;
    				case ASTExecutionScope.USE_IBM_LISTOP: {
    					useListOp = Boolean.TRUE;
    				} break;
    				case ASTExecutionScope.USE_IBM_LISTOP_NO: {
    					useListOp = Boolean.FALSE;
    				} break;
    				default: {
        				checkDir = false;
    				}
    			}
    		}
    		nodes[i] = assignParent(n);
    	}
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        // create a function object which mission is to execute the function body when it is called.
    	// we still execute the function object, although it might had been added to the variable object
    	// if it is named. So we should not add anymore.
        FunctionObject funcObj= new FunctionObject(context.getJSContext(),context,modifiers,params,this);
//        if(getName()!=null) {
//        	// Looks like it is not always created when named
//        	// So we try to add it again if not present
//            context.getVariableObject().createProperty(getName(),FBSObject.P_NODELETE,funcObj);
//        }        
        result.setNormal(funcObj);
        return true;
    }

    public void optimize(JSContext context) throws ParseException {
		ASTExecutionScope es = ASTExecutionScope.getExecutionScope(getParent());
		if(es!=null) {
			if(StringUtil.isNotEmpty(getName())) {
    			es.addFunction(this);
			}
			// Report the directives from the parent chain
			if(useStrict==null) {
				useStrict = es.isUseStrict();
			}
			if(useListOp==null) {
				useListOp = es.isUseListOp();
			}
    	}
        super.optimize(context);

/*        
    	if(nodes.size()>=1) {
    		int last = nodes.size()-1;
    		ASTNode n = nodes.get(last);
    		
        	// Form 1:
        	//   return xxxx
        	// if we have one node, and this node is a return statement
        	// then evaluate the return content. This avoids throwing an exception
    		if(n instanceof ASTReturn) {
				ASTReturn ret = (ASTReturn)n;
    			ASTNode res = ret.getReturnNode();
    			if(res==null) {
    				nodes.put(last, res);
    				res = new ASTLiteral(); // undefined value...
    			}
				res.assignParent(this);
				nodes.put(last, res);
    			modifiers |= FunctionObject.MOD_RETLAST;
    			return;
    		}
    		
        	// Form 2:
        	//   if(...) return xxxx else return yyyy
    		// Note that xxx or yyy can also be the last statement in a block
    		if(n instanceof ASTIf) {
    			ASTIf ifnode = (ASTIf)n;
    			{
	    			ASTNode ifstat = ifnode.readSlotAt(ASTIf.STATEMENT);
	    			if(ifstat!=null) {
	    				if(ifstat instanceof ASTBlock) {
	    					ASTBlock block = (ASTBlock)ifstat;
	    	    			if(block.readLastSlot() instanceof ASTReturn) {
	    	    				ASTReturn ret = (ASTReturn)block.readLastSlot();
			    				ret.getReturnNode().assignParent(block);
	    	    				block.putSlotAt(block.getSlotCount()-1, ret.getReturnNode());
	    	        			modifiers |= FunctionObject.MOD_RETLAST;
	    					}
	    				} else if(ifstat instanceof ASTReturn) {
		    				ASTReturn ret = (ASTReturn)ifstat;
		    				ret.getReturnNode().assignParent(ifnode);
	    					ifnode.putSlotAt(ASTIf.STATEMENT, ret.getReturnNode());
	            			modifiers |= FunctionObject.MOD_RETLAST;
	    				}
	    			}
    			}
    			{
	    			ASTNode ifelse = n.readSlotAt(ASTIf.ELSESTATEMENT);
	    			if(ifelse!=null) {
	    				if(ifelse instanceof ASTBlock) {
	    					ASTBlock block = (ASTBlock)ifelse;
	    	    			if(block.readLastSlot() instanceof ASTReturn) {
	    	    				ASTReturn ret = (ASTReturn)block.readLastSlot();
			    				ret.getReturnNode().assignParent(block);
	    	    				block.putSlotAt(block.getSlotCount()-1, ret.getReturnNode());
	    	        			modifiers |= FunctionObject.MOD_RETLAST;
	    					}
	    				} else if(ifelse instanceof ASTReturn) {
		    				ASTReturn ret = (ASTReturn)ifelse;
		    				ret.getReturnNode().assignParent(ifnode);
	    					ifnode.putSlotAt(ASTIf.ELSESTATEMENT, ret.getReturnNode());
	            			modifiers |= FunctionObject.MOD_RETLAST;
	    				}
	    			}
    			}
    			return;
    		}
    	}
*/    	
    }

    public FunctionObject createFunctionObject(IExecutionContext context) throws InterpretException {
        // create a function object which mission is to execute the function body when it is called.
        FunctionObject funcObj= new FunctionObject(context.getJSContext(),context,modifiers,params,this);
        return funcObj;
    }

    protected void extraInfo(PrintStream ps,String indent){
        ps.print("name="); //$NON-NLS-1$
        ps.print(funcName);
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitFunction(this, param);
    }
}
