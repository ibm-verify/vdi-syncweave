/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSValue;

public class ASTTernaryOp extends ASTNode{
    public static final int CONDITION=0;
    public static final int TRUESTATEMENT=1;
    public static final int FALSESTATEMENT=2;

    private ASTNode conditionNode;
    private ASTNode trueNode;
    private ASTNode falseNode;

    public ASTTernaryOp() {
    }

    public void add(ASTNode cond,ASTNode truestat, ASTNode falsestat){
        conditionNode=assignParent(cond);
        trueNode=assignParent(truestat);
        falseNode=assignParent(falsestat);
    }

    public int getSlotCount(){
        return 3;
    }

    public ASTNode readSlotAt(int index){
        switch(index){
            case CONDITION:return conditionNode;
            case TRUESTATEMENT:return trueNode;
            case FALSESTATEMENT:return falseNode;
        }
        return null;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            if(!conditionNode.interpret(this,context,result)) {
            	return false;
            }
            FBSValue v=result.getFBSValue();
            boolean b=v.booleanValue();
            if (b){
                if(!trueNode.interpret(this,context,result)) {
                	return false;
                }
            }else{
                if(!falseNode.interpret(this,context,result)) {
                	return false;
                }
            }
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }

    }
    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        FBSType t1 = trueNode.getResultType(jsContext,symbolCallback);
        FBSType t2 = falseNode.getResultType(jsContext,symbolCallback);
        if( t1.equals(t2) ) {
            return t1;
        }
        return FBSType.undefinedType;
    }

    public Object visit(ASTNodeVisitor v, Object param) {
	return v.visitTernaryOp(this, param);
    }
}
