/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.commons.util.profiler.Profiler;
import com.ibm.commons.util.profiler.ProfilerAggregator;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;

public class ASTProfile extends ASTNode{

    public static final int PARAM=0;
    public static final int BLOCK=1;

    private String profileType;
    private ASTNode paramExpr;
    private ASTNode blockExpr;

    public ASTProfile() {
    }


    public ASTProfile(String profileType, ASTNode paramExpr, ASTNode blockExpr) {
        this.profileType = profileType;
        this.paramExpr = assignParent(paramExpr);
        this.blockExpr = assignParent(blockExpr);
    }

    public String getProfileType() {
        return profileType;
    }

    public int getSlotCount(){
        return 2;
    }

    public ASTNode readSlotAt(int index){
        switch(index){
            case PARAM: return paramExpr;
            case BLOCK: return blockExpr;
        }
        return null;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            if( Profiler.isEnabled() ) {
                String pValue = null;
                if( paramExpr!=null ) {
                    if(!paramExpr.interpret(this,context,result)) {
                    	return false;
                    }
                    pValue = result.getFBSValue().stringValue();
                }
                ProfilerAggregator agg = Profiler.startProfileBlock(profileType,pValue);
                long ts = Profiler.getCurrentTime();
                try {
                    if(!blockExpr.interpret(this,context,result)) {
                    	return false;
                    }
                } finally {
                	Profiler.endProfileBlock(agg,ts);
                }
            } else {
                if(!blockExpr.interpret(this,context,result)) {
                	return false;
                }
            }
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitProfile(this, param);
    }
}
