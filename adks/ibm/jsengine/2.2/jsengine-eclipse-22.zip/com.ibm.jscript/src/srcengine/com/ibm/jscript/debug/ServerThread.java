/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.debug;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import com.ibm.commons.util.TDiag;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSExpression;
import com.ibm.jscript.ASTTree.ASTDebug;
import com.ibm.jscript.ASTTree.ASTNode;
import com.ibm.jscript.engine.FunctionContext;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.engine.ProgramContext;
import com.ibm.jscript.std.FunctionObject;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSValue;

public class ServerThread {
    
    private ArrayList fStackFrames         = new ArrayList(10);
    private ArrayList fPreviousStackFrames = null;
    private int fLastUserAction   = DebugInspectorConstants.ACTION_STEP_OVER;
       
    /**************************************************************
     * newContext(...)
     * This is called when the interpreter is working on a new 
     * IExecutionContext. 
     **************************************************************
     */
    public void newContext(IExecutionContext theContext) {
              
        //Reset the Stack Frames, the Global Variables, and This Object.
        fStackFrames.clear();
        
        //Traverse the IExecutionContext and generate StackFrames.  Then, assign them 
        //unique IDs based on where they are in the ArrayList
        createStackFrames(theContext);
        assignUniqueIDs();
        
        
        //Now decide if we should stop.  If so, call stopHere which the client will have a breakpoint on:
        boolean shouldStop = shouldStop();
        if (Util.traceEnabled()) {
            Util.trace("DebugInspector", "Processing " + theContext.getExpression() + ",  shouldStop = " + shouldStop); // $NON-NLS-1$ $NON-NLS-2$ $NON-NLS-3$
        }
        if (shouldStop) {
            //Keep the following lines commented out. They are for debugging ServerThread and go create 
            //the global variables in the first stack frame (because we don't have a client to do it).
            //ServerStackFrame ssf = (ServerStackFrame)fStackFrames.get(0);
            //ssf.getVariables();
            //ServerVariable sv = (ServerVariable)ssf.getVariable(0);
            //sv.getVariables();
                
            fPreviousStackFrames = fStackFrames;
            String stackFrameInfo = generateStackFrameInfo();
            
            //ArrayList globalVariables = getGlobalVariables();
            stopHere(stackFrameInfo); //, globalVariables);
        }
    }
    
    /**************************************************************
     * getStackFrames()
     * Return the current Stack Frames as a ServerStackFrame[]
     **************************************************************
     */
    public ServerStackFrame[] getStackFrames() {
        return (ServerStackFrame[])fStackFrames.toArray(new ServerStackFrame[fStackFrames.size()]);
    }
    
    /**************************************************************
     * DEBUG CLIENT BREAKPOINT - stopHere(...)
     * The debug client has a breakpoint on this method so that it can 
     * know when the execution of the interpreter should be stopped.
     **************************************************************
     */
    public void stopHere(String __StackFrameInfo) { //, Object __GlobalVariables) {
        //Do Nothing
    }
    
    /**************************************************************
     * METHOD CALLED BY DEBUG CLIENT - getStackFrame()
     * Return the ServerStackFrame based on uniqueID (its place in fStackFrames)
     **************************************************************
     */
    public Object getStackFrame(int uniqueID) {
        ServerStackFrame stackFrame = (ServerStackFrame)fStackFrames.get(uniqueID);
        if (stackFrame != null) {
            return stackFrame;
        }
        if ( Util.traceEnabled() ){
            Util.trace("getStackFrame", "Unable to find frame #" + uniqueID + ".  There are " + fStackFrames.size() + " frames in fStackFrames"); // $NON-NLS-1$ $NON-NLS-2$ $NON-NLS-3$ $NON-NLS-4$
        }
        return null;
    }   
    
    /**************************************************************
     * METHOD CALLED BY DEBUG CLIENT - getGlobalVariables()
     * Return a reference to the Array of global objects
     * Should only be called once per thread stop, so we don't 
     * cache anything
     **************************************************************
     */
    /*public ArrayList getGlobalVariables() {
        ArrayList globalVariables = new ArrayList(20);
        FBSDefaultObject registry = fContext.getVariableObject().getJSContext().getRegistry().getRegistryObject();
        Iterator iter = registry.getPropertyKeys();
        while (iter.hasNext()) {
            Property fdo = registry.getPropertyByName((String)iter.next());
            String varName = fdo.getPropertyName();             
            // If we're dealing with the arguments object skip it
            if (varName.equals("arguments")) //$NON-NLS-1$
                continue;
                
            //Now get the VaribleValue:
            FBSValue value = fdo.getValue();
            FBSObject valueObject = null;
            try {
                valueObject = value.toFBSObject(fContext.getJSContext());
            } catch (InterpretException e) {
                fContext.getJSContext().exception(e,""); //$NON-NLS-1$
            }
                
            //If the Value is a JavaAccessObject, add it to fGlobalVariables:
            if ( valueObject instanceof JavaAccessObject ){
                JavaAccessObject javaObject = (JavaAccessObject)valueObject;
                globalVariables.add(javaObject.getJavaObject());
            }
        }
        return globalVariables;
    }   
    */
    
    /**************************************************************
     * METHODS CALLED BY DEBUG CLIENT
     * The followng methods are called directly by the debug client 
     * to tell us what the user just did in the UI.
     **************************************************************
     */
    public void resume()      {fLastUserAction = DebugInspectorConstants.ACTION_RESUME;}
    public void suspend()     {fLastUserAction = DebugInspectorConstants.ACTION_SUSPEND;}
    public void terminate()   {fLastUserAction = DebugInspectorConstants.ACTION_TERMINATE;}
    public void stepOver()    {fLastUserAction = DebugInspectorConstants.ACTION_STEP_OVER;}
    public void stepInto()    {fLastUserAction = DebugInspectorConstants.ACTION_STEP_INTO;}
    public void stepReturn()  {fLastUserAction = DebugInspectorConstants.ACTION_STEP_RETURN;}
    
    
    
     /******** PRIVATE METHODS from this point and below ***********/
       
    
    /**************************************************************
     * createStackFrames()
     * recursive method that walks up parent contexts until it finds
     * the ProgramContext.  For all FunctionContexts and the Program
     * Contexts it calls helper methods to generate ServerStackFrames  
     ***************************************************************
    */
    private void createStackFrames(IExecutionContext theContext) {
        if( theContext instanceof FunctionContext ) {
            // compute the calling frames first
            FunctionContext fctContext = (FunctionContext)theContext;
            createStackFrames(fctContext.getParentContext());
            createFunctionStackFrame(fctContext);
        }
        else if (theContext instanceof ProgramContext) {
            ProgramContext pgmContext = (ProgramContext)theContext;
            createProgramStackFrame(pgmContext);
        }
    }
    
    /**************************************************************
     * createFunctionStackFrame()
     * Creates a ServerStackFrame from a FunctionContext 
     ***************************************************************
    */
    private void createFunctionStackFrame(FunctionContext theContext) {
        String sourceID = getSourceID(theContext);
        int    lineNum  = getLineNumber(theContext);
        String name     = theContext.getFunctionObject().getFunctionNode().getName() + " " + getArgumentSuffix(theContext); //$NON-NLS-1$
        addStackFrame(new ServerStackFrame(theContext, name, sourceID, lineNum));
    }  
    
    /**************************************************************
     * createProgramStackFrame()
     * Creates a ServerStackFrame from a ProgramContext 
     ***************************************************************
    */
     private void createProgramStackFrame(ProgramContext theContext) {
        String sourceID = getSourceID(theContext);
        int    lineNum  = getLineNumber(theContext);
        String name     = sourceID;
        if (sourceID.equals(JSExpression.DYNAMIC_SOURCE_ID))
            name = "Server JavaScript Source"; //$NON-NLS-1$
        else {
            //Trim off the trailing :<unique-identifier>...so span3:0:123123531 becomes span3:0
            int lastColon = name.lastIndexOf(':');
            if (lastColon > 1)
                name = name.substring(0,lastColon);
        }
        addStackFrame(new ServerStackFrame(theContext, name, sourceID, lineNum));
    }
     
     /**************************************************************
      * assignUniqueIDs()
      * Creates a ServerStackFrame from a ProgramContext 
      ***************************************************************
     */
      private void assignUniqueIDs() {
         for (int i=fStackFrames.size()-1; i>=0; i--) {
             ((ServerStackFrame)fStackFrames.get(i)).setUniqueID(i);
         }
     }
        
     /**************************************************************
      * getSourceID()
      * Given an IExecutionContext, return the SourceReferenceID 
      ***************************************************************
     */
     private String getSourceID (IExecutionContext theContext) {
         String sourceId = null;
         try {
             sourceId = theContext.getSourceReferenceID();
         } catch (InterpretException e) {
             //Something went wrong here
             e.printStackTrace();
             sourceId = theContext.getExpression().getSourceReferenceID();
         }finally{
             //Make sure the sourceId is never null
             if ( sourceId == null ){
                 sourceId = "";
             }
         }
         return sourceId;
     }
     
     /**************************************************************
      * getLineNumber()
      * Given an IExecutionContext, return the current line number 
      ***************************************************************
     */
     private int getLineNumber(IExecutionContext theContext) {
         ASTDebug astDebugNode = theContext.getDebugStatement();
         if (astDebugNode == null) {
             return -1;
         }
         ASTNode theStatement = astDebugNode.readSlotAt(0);
         if (theStatement != null)
             return theStatement.getBeginLine();
         return -1;
     }
     
     /**************************************************************
      * addStackFrame()
      * Add a ServerStackFrame to the beginning of the fStackFrames ArrayList 
      ***************************************************************
     */
     private void addStackFrame(ServerStackFrame theFrame) {
         fStackFrames.add(0,theFrame);
     }
     
     /**************************************************************
      * shouldStop()
      * Based on the last user action and the current state of the 
      * StackFrames, decide if we should stop. 
      ***************************************************************
     */
     private boolean shouldStop () {
            
         //Stop if this is the first line of JavaScript (no previous frames) AND 
         //the user preference tells us to:
         if ( (fPreviousStackFrames == null) && (JVMProxy.getInstance().getStopInJavaScript()) ) {
            return true;
         }
          
         //Get the source and line number info for the top stackframe and determine if we 
         //are at an enabled breakpoint...if so we stop:
         ServerStackFrame topStackFrame = (ServerStackFrame)fStackFrames.get(0);
         if (topStackFrame == null) {
            return false;  //Odd condition..no stack frames..don't stop
         }
         String sourceID = topStackFrame.getSourceFileName();
         int    lineNum  = topStackFrame.getLineNumber().intValue(); 
         if (BreakpointManager.getInstance().enabledBreakpointExists(sourceID, lineNum)) {
             return true;
         }
           
         
         //If we get here, then we're not at an enabled breakpoint, so we need to do some
         //work to decide whether to stop:
         
         //Simple decisions:
         if (fLastUserAction == DebugInspectorConstants.ACTION_RESUME) {
             return false;
         }
         if (fLastUserAction == DebugInspectorConstants.ACTION_TERMINATE) {
             return false;
         }
         if (fLastUserAction == DebugInspectorConstants.ACTION_SUSPEND) {
             return true;
         }
         if (fLastUserAction == DebugInspectorConstants.ACTION_STEP_INTO) {
             return true;
         }
         
         //A bit more work required: 
         if (fLastUserAction == DebugInspectorConstants.ACTION_STEP_OVER) {
             //If we are in the same stack frame then it's easy:
             if ( fPreviousStackFrames != null) {
                 if (fStackFrames.get(0).equals(fPreviousStackFrames.get(0))) {
                     return true;
                 }
                 //If we are not in the same stack frame, then we only stop if there are fewer frames:
                 if (fStackFrames.size() < fPreviousStackFrames.size()) {
                     return true;
                 }
             }
             //If we get here, then we shouldn't stop:
             return false;
         }
             
         if (fLastUserAction == DebugInspectorConstants.ACTION_STEP_RETURN) {
             //We should only stop if there are fewer stackframes:
             return (fStackFrames.size() < fPreviousStackFrames.size());
         }
            
         //We shouldn't get here, but return false as a default
         return false;
     }  
    
     /**************************************************************
      * getArgumentSuffix()
      * For a given context, build a string that can be used in a stackframe 
      * name to show the function arguments. 
      ***************************************************************
     */
     private String getArgumentSuffix(IExecutionContext theContext) {
         //Get the variable object
         FBSDefaultObject varObj = theContext.getVariableObject();
         StringBuffer theArgs = new StringBuffer("(");  //$NON-NLS-1$
         try {
             FBSValue args = varObj.get("arguments"); //$NON-NLS-1$
             if( args!=null && !args.isUndefined() && !(args instanceof FunctionObject )) {
                 FBSObject obj = (FBSObject)args;
                 //Get a sorted list of the property keys that are numbers
                 ArrayList argKeys = new ArrayList();
                 for( Iterator it=obj.getPropertyKeys(); it.hasNext(); ) {
                     String theKey = (String)(it.next());
                     try {
                         //Test to see if the property key is a number:
                         Integer.parseInt(theKey);
                         argKeys.add(theKey);
                     } catch (NumberFormatException e) {}
                 }
                 String[] sortedKeys = (String[])argKeys.toArray(new String[argKeys.size()]);
                 Arrays.sort(sortedKeys);
             
                 boolean firstTime = true;
                 for( int i=0; i<sortedKeys.length; i++ ) {
                     FBSValue theArgument = obj.get(sortedKeys[i]);
                     if (firstTime) {
                         theArgs.append(theArgument.getTypeAsString());  
                         firstTime = false;
                     }
                     else 
                         theArgs.append("," + theArgument.getTypeAsString()); //$NON-NLS-1$
                 }
             }
             
         } catch( InterpretException ex ) {   
             ex.printStackTrace();
         }
         theArgs.append(")"); //$NON-NLS-1$
         return theArgs.toString();
     }
     
      
     
     /**************************************************************
      * generateStackFrameInfo()
      * Construct an ArrayList of Strings that describes all the StackFrames.  Then convert this 
      * to a String so that the client can read it easily.  This is due to performance hits for 
      * multiple Array reads from the client side. 
      * 
      * The format is as follows:
      *  0 StackFrame Name
      *  1 StackFrame Source File
      *  2 StackFrame Line Number
      *  3 StackFrame Unique ID
      ***************************************************************
     */
    private String generateStackFrameInfo() {
        ArrayList theInfo = new ArrayList(fStackFrames.size() * 4);
        try {
            for (int i=0; i<fStackFrames.size();i++) {
                ServerStackFrame stackFrame = (ServerStackFrame)fStackFrames.get(i);
                theInfo.add(stackFrame.getName());
                theInfo.add(stackFrame.getSourceFileName());
                theInfo.add(new String("" + stackFrame.getLineNumber())); //$NON-NLS-1$
                theInfo.add(new String("" + stackFrame.getUniqueID())); //$NON-NLS-1$
            }
        } catch (Exception e) {
            TDiag.exception(e,""); //$NON-NLS-1$
        }
        return ArrayListUtil.arrayListToString(theInfo);
    }   
}   
    
