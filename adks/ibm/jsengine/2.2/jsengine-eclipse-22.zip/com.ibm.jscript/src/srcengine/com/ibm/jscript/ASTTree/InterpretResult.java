/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.types.FBSReference;
import com.ibm.jscript.types.FBSValue;

public final class InterpretResult {

	public static final int SIGNAL_NONE			= 0;
	public static final int SIGNAL_RETURN		= 1;
	public static final int SIGNAL_BREAK		= 2;
	public static final int SIGNAL_CONTINUE		= 3;
	
	private boolean ref;
    private FBSReference valueRef;
    private FBSValue fbsValue;
    private int signal;

    public InterpretResult() {
    }
    
    public int getSignal() {
    	return signal;
    }
    
    public void setSignal(int signal) {
    	this.signal = signal;
    }
    
    public boolean isReturnSignal() {
    	return signal==SIGNAL_RETURN;
    }
    
    public boolean isBreakSignal() {
    	return signal==SIGNAL_BREAK;
    }
    
    public boolean isContinueSignal() {
    	return signal==SIGNAL_CONTINUE;
    }
    
    public void resetSignal() {
    	this.signal = SIGNAL_NONE;
    }

    public boolean isFBSValue(){
        return !ref;
    }

    public boolean isReference(){
        return ref;
    }

    public FBSValue getFBSValue() throws InterpretException {
    	if(ref) {
    		return valueRef.getValue();
    	}
    	return fbsValue;
    }

    public FBSReference getReference(){
    	if(ref) {
    		return valueRef;
    	}
        return null;
    }

    public void setNormal(FBSValue value){
        this.fbsValue = value;
        this.ref = false;
    }

    public void setNormal(FBSReference value){
        this.valueRef = value;
        this.ref = true;
    }
}
