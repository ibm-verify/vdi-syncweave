/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSNull;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSValue;

public class ASTThis extends ASTNode{

    public ASTThis() {
    }

    public int getSlotCount(){
        return 0;
    }

    /**
     * reads the slot at position 'index'.
     * Value may be null.
     * @return returns the value of a slot.
     */
    public ASTNode readSlotAt(int index){
        return null;
    }


    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        FBSValue _this = context.getThis();
        if(_this==null) {
            _this = FBSNull.nullValue;
        }
        result.setNormal(_this);
        return true;
    }

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        return FBSType.jsObjectType;
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitThis(this, param);
    }
}
