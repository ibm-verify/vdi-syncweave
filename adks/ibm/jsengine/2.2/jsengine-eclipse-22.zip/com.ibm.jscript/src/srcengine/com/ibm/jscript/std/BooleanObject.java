/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.types.FBSBoolean;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSReference;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.JavaAccessObject;

/**
 * This class allows to manipulate standard JavaScript Boolean objects.
 * <br>This class has helpful method to convert a boolean value into a string (true or false)
 * or an integer (0 or 1).
 */
public class BooleanObject extends AbstractPrimitiveObject implements Externalizable {
    
    private FBSBoolean primitive;

	// Serialization only ctor
	public BooleanObject() {
        super(JSContext.getStaticContext(),JSContext.getStaticContext().getRegistry().booleanPrototype);
    }

	// Prototype only ctor
	protected BooleanObject(JSContext jsContext, FBSDefaultObject prototype) {
        super(jsContext,prototype);
        this.primitive = FBSBoolean.FALSE;
    }

	public BooleanObject(JSContext jsContext, FBSBoolean value) {
        super(jsContext,jsContext.getRegistry().booleanPrototype);
        this.primitive = value;
    }    
    
    public boolean equals( Object o ) {
        if( o instanceof BooleanObject ) {
            BooleanObject w = (BooleanObject)o;
            return primitive.booleanValue()==w.primitive.booleanValue();
        }
        if( o instanceof FBSBoolean ) {
            FBSBoolean w = (FBSBoolean)o;
            return primitive.booleanValue()==w.booleanValue();
        }
        return false;
    }
    
    public String getTypeAsString(){
        return "Boolean"; //$NON-NLS-1$
    }

    public String getName(){
        return "Boolean"; //$NON-NLS-1$
    }

    public FBSValue getPrimitiveValue() {
        return primitive;
    }
    
    public FBSBoolean getFBSBoolean() {
        return primitive;
    }

    //In JavaScript 1.2, new Boolean(false) evaluates to false.
    //In ECMA script it always evaluates to true
    // Rhino ECMA tests enforces the first...
    public boolean booleanValue() {
    	return primitive.booleanValue();
    }


    public boolean isJavaAssignableTo(Class c) {
        return c.isAssignableFrom(Boolean.class) || c==BooleanObject.class;
    }

    public Object toJavaObject(Class c){
        if (c==null || c.isAssignableFrom(Boolean.class) ) {
            return this.primitive.booleanValue() ? Boolean.TRUE : Boolean.FALSE;
        }
        if( c==BooleanObject.class ) { // ??? PHIL: I think this is not needed....
            return this;
        }
        throw new RuntimeException(StringUtil.format("Can't convert {0} to {1}", this.getClass().getName(), c.getName())); // $NLS-BooleanObject.Cantconvert0to1-1$
    }
    
    public FBSReference getPropertyReference(String name) throws InterpretException {
    	FBSReference ref = super.getPropertyReference(name);
    	
    	// if there is not property assigned to the object, look at a Java Boolean property
    	if(ref==null) {
    		ref = JavaAccessObject.getJavaPropertyReference(getJSContext(), Boolean.class, this, booleanValue(), name);
    	}
    	return ref;
    }


    // ========================================================================
    // Java Object IO.
    // ========================================================================

    public void readExternal( ObjectInput in ) throws IOException {
        super.readExternal(in);
        primitive = in.readBoolean() ? FBSBoolean.TRUE : FBSBoolean.FALSE; 
    }

    public void writeExternal( ObjectOutput out ) throws IOException {
        super.writeExternal(out);
        out.writeBoolean(primitive.booleanValue());
    }
}
