/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2008                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.security;

import java.security.Permission;

/**
 * This class checks for java access permission.
 * 
 * It doesn't make a distinction on the classes being called. It just allows
 * or not the JavaBridge.
 * 
 * This permission is currently asked when:
 *   - A new Java object is being constructed
 *   - A call to a method on a native Java object
 * 
 * @author priand
 * May 29, 2008
 * 
 * Unit: JavaBridgePermission.java
 */
public class JavaBridgePermission extends Permission {

    // As this class has no parameters, then a singleton is fine
    public static JavaBridgePermission instance = new JavaBridgePermission(
            "Access Java classes from JavaScript"); // $NLS-JavaBridgePermission.AccessJavaclassesfromJavaScript-1$
    
    public JavaBridgePermission(String name) {
        super(name);
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof JavaBridgePermission) {
            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return 0;
    }

    @Override
    public String getActions() {
        return null;
    }

    @Override
    public boolean implies(Permission permission) {
        // As classes are not checked, always return true here
        return true;
    }
}