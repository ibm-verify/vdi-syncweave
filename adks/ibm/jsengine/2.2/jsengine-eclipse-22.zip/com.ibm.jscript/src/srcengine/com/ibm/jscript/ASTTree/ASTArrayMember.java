/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSReference;
import com.ibm.jscript.types.FBSReferenceByName;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSValue;

public final class ASTArrayMember extends ASTNode{

    public static final int LEFT=0;
    public static final int RIGHT=1;

    private ASTNode leftNode;
    private ASTNode rightNode;

    public ASTArrayMember(ASTNode leftNode, ASTNode rightNode) {
        this.leftNode = assignParent(leftNode);
        this.rightNode = assignParent(rightNode);
    }

    public String getTraceString(){
        return leftNode.getTraceString()+"["+rightNode.getTraceString()+"]"; //$NON-NLS-1$ //$NON-NLS-2$
    }

    public int getSlotCount(){
        return 2;
    }

    public ASTNode readSlotAt(int index){
        switch(index){
            case LEFT: return leftNode;
            case RIGHT: return rightNode;
        }
        return null;
    }

    public ASTNode getLeftNode() {
        return leftNode;
    }

    public ASTNode getRightNode() {
        return rightNode;
    }

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        FBSType t=leftNode.getResultType(jsContext,symbolCallback);
        if( t.isUndefined() ) {
            return t;
        }
        if( t.isInvalid() ) {
        	// TODO...
            if( !(leftNode instanceof ASTIdentifier) ) {
                return t;
            }
            String idn=((ASTIdentifier)leftNode).getIdentifierName();
            t = FBSType.getJavaPackage(idn);
        }
        if( t.isArray() ) {
            return t.getArrayType();
        }

        // if the parameter is a constant, use it as the member name
        if( rightNode.isConstant() ) {
            try {
                FBSValue v = rightNode.evaluateConstant(jsContext.getTempExecutionContext());
                return t.getMember(jsContext,v.stringValue());
            } catch( InterpretException ex ) {}
        }
        return FBSType.undefinedType;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            if(!leftNode.interpret(this,context,result)) {
            	return false;
            }
            FBSValue leftValue = result.getFBSValue();
            if (!leftValue.canFBSObject()){
                if( leftValue.isNull() ) {
                    throw new InterpretException(null,"'{0}' is null and cannot be accessed as an array",leftNode.getTraceString()); //$NLS-ASTArrayMember.ASTArrayMember.LeftSideIsNull.Exception-1$
                }
                if( leftValue.isUndefined() ) {
                    throw new InterpretException(null,"'{0}' is undefined and cannot be accessed as an array",leftNode.getTraceString()); //$NLS-ASTArrayMember.ASTArrayMember.LeftSideIsUndefined.Exception-1$
                }
                throw new InterpretException(null,"'{0}' is not an object and cannot be accessed as an array",leftNode.getTraceString()); //$NLS-ASTArrayMember.ASTArrayMember.LeftSideIsNotAnObj.Exception-1$
            }
            FBSObject leftObject=leftValue.toFBSObject(context.getJSContext());

            if(!rightNode.interpret(this,context,result)) {
            	return false;
            }
            
            FBSValue rightValue= result.getFBSValue();

            // Optimize array access, by using a number property instead of a string
            if( leftObject.hasIndexedProperty() && rightValue.isNumber() ) {
                result.setNormal(leftObject.getPropertyReference(rightValue.intValue()));
            } else {
            	String id = rightValue.stringValue();
            	FBSReference ref = leftObject.getPropertyReference(id);
            	if(ref==null) {
            		// PHIL: there is not here any variable creation, only properties that may return undefined 
            		ref = new FBSReferenceByName(leftObject,id);
            	}
                result.setNormal(ref);
            }
            return true;
        } catch( InterpretException ie ) {
                throw ie.fillException(context,this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitArrayMember(this, param);
    }
}
