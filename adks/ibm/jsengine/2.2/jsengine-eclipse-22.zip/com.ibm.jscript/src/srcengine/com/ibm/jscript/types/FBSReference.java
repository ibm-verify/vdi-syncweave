/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import com.ibm.jscript.InterpretException;

public abstract class FBSReference {

    FBSObject base;
    
    public FBSReference(FBSObject base) {
        this.base=base;
    }
    
    public boolean exists() {
    	return getBase()!=null;
    }
    
    public final FBSObject getBase() {
    	return base;
    }

    public abstract String getPropertyName();
    
    public abstract FBSValue getValue() throws InterpretException;
    public abstract void putValue(FBSValue value) throws InterpretException;
}
