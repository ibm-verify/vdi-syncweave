/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSValue;

public class ASTDoWhile extends ASTNode implements ILabelledStatement {
    public static final int STATEMENT = 0;

    public static final int EXPRESSION = 1;

    private ASTNode statementNode;

    private ASTNode expressionNode;

    private String labelName;

    public ASTDoWhile() {
    }

    public void setLabelName(String label) {
        this.labelName = label;
    }

    public void add(ASTNode statement, ASTNode expression) {
        this.statementNode = assignParent(statement);
        this.expressionNode = assignParent(expression);
    }

    public int getSlotCount() {
        return 2;
    }

    public ASTNode readSlotAt(int index) {
        if (index < 0 || index > 1)
            return null;
        return (index == 0) ? statementNode : expressionNode;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context, InterpretResult result) throws JavaScriptException {
        try {
            FBSValue v = FBSUndefined.undefinedValue;
            FBSValue condition = null;
            do {
                // Evaluate the loop content
                if(!statementNode.interpret(this, context, result)) {
                	if(result.isBreakSignal()) {
                        String label = context.getProgramContext().getLoopLabel();
                        if (!StringUtil.isEmpty(label)) {
                            if (!StringUtil.equals(label, labelName)) {
                                return false;
                            }
                        }
                        // Break the main loop
                        result.resetSignal();
                        break;
                	} else if(result.isContinueSignal()) {
                        String label = context.getProgramContext().getLoopLabel();
                        if (!StringUtil.isEmpty(label)) {
                            if (!StringUtil.equals(label, labelName)) {
                                return false;
                            }
                        }
                        // Just continue and do not execute the condition
                        result.resetSignal();
                        //condition=FBSBoolean.TRUE;
                        //continue;
                	} else {
                		return false;
                	}
                } else {
                	if (result.getFBSValue() != null) {
                		v = result.getFBSValue();
                	}
                }
                // Evaluate the condition
                if(!expressionNode.interpret(this, context, result)) {
                	return false;
                }
                condition = result.getFBSValue();
            } while (condition.booleanValue());
            result.setNormal(v);
            return true;
        } catch (InterpretException ie) {
            throw ie.fillException(context, this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
        return v.visitDoWhile(this, param);
    }
}
