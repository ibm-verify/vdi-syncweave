/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2009                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.macro;

import java.io.PrintStream;
import java.io.StringWriter;

import com.ibm.commons.util.StringUtil;
import com.ibm.commons.util.TextUtil;
import com.ibm.commons.util.io.WriterOutputStream;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JSExpression;
import com.ibm.jscript.engine.ExtendedJSContext;
import com.ibm.jscript.engine.ProgramContext;
import com.ibm.jscript.parser.ParseException;
import com.ibm.jscript.types.FBSGlobalObject;
import com.ibm.jscript.types.FBSObject;


/**
 * JavaScript based generator.
 * This class parses a source file and replaces the following constructs:
 *   <%= ...formula... %>
 *   	Evaluates the formula and replace the construct by the result, converted 
 *   	as a string. Note that the formulas can be evaluated before the JS engine,
 *   	which acts as hooks for custom behaviors (like <%= #ID %>)
 *   <% ...scriplet... %>
 *   	A scriplet is a set of JavaScript statements that are inserted and executed
 *   	when the transformation happens 
 * @author Philippe Riand
 */
public class MacroProcessor { 
    
	public static final String START_TAG = "<%"; //$NON-NLS-1$
	public static final String END_TAG = "%>";  //$NON-NLS-1$
		
	private JSContext _jsContext;
	private FBSGlobalObject _globalObject;
	private FBSObject _prototype;
	private FBSObject _this;
	
	public MacroProcessor(JSContext jsContext) {
		this._jsContext = jsContext;
	}
	
	public String process(String source) throws InterpretException {
		// If no processing is due, just return the source
		if(source.indexOf(START_TAG)<0) {
			return source;
		}
		
		// Else generate the Javascript piece of code
		String jsSource = generateScript(source);
		
		// And execute it
		return executeScript(jsSource);
	}
		
	public JSContext getJsContext() {
		return _jsContext;
	}

	public void setJsContext(JSContext context) {
		_jsContext = context;
	}

	public FBSGlobalObject getGlobalObject() {
		return _globalObject;
	}

	public void setGlobalObject(FBSGlobalObject object) {
		_globalObject = object;
	}

	public FBSObject getPrototype() {
		return _prototype;
	}

	public void setPrototype(FBSObject _prototype) {
		this._prototype = _prototype;
	}

	public FBSObject getThis() {
		return _this;
	}

	public void setThis(FBSObject _this) {
		this._this = _this;
	}

	protected ProgramContext createProgramContext(JSExpression expression) throws InterpretException {
		//FBSObject proto = parameter!=null ? FBSUtility.wrapAsObject(jsContext,parameter) : null;
		ProgramContext ctx = expression.createProgramContext(
				_globalObject,	// GlobalObject 
				_prototype,		// Scope prototypes 
				_this,			// this
				null,			// params
				null			// No imported libraries
		);
		return ctx;
	}

	// Generate the JavaScript code that then output the final text
	protected String generateScript(String source) throws InterpretException {
		int slen = source.length();
		
		// Create the Javascript program
		StringBuilder jsSource = new StringBuilder(2048);
		for(int pos=0; pos<slen; ) {
			int exp = source.indexOf(START_TAG,pos);
			int end = exp>=0 ? exp : slen;
			if(end>pos) {
				addString(jsSource,source,pos,end);
				pos = end;
			}
			if(exp>=0) {
				int stend = source.indexOf(END_TAG,exp+2); 
				if(stend<0) {
					throw new InterpretException((Exception)null,"<% without a closing %>"); // $NLS-MacroProcessor.withoutaclosing-1$
				}
				
				if(source.charAt(exp+2)=='=') { //$NON-NLS-1$
					String sub = source.substring(exp+3,stend);
					jsSource.append("print("); //$NON-NLS-1$
					jsSource.append(sub); //$NON-NLS-1$
					jsSource.append(")\n"); //$NON-NLS-1$
				} else {
					String sub = source.substring(exp+2,stend);
					jsSource.append(sub);
					jsSource.append("\n"); //$NON-NLS-1$
				}
				pos = stend+2;
			}
		}

		return jsSource.toString();
	}
	
	// Execute the piece of JavaScript that had been generated
	protected String executeScript(String jsSource) throws InterpretException {
		JSExpression expression;
		try {
			expression = _jsContext.createExpression(jsSource);
		} catch(ParseException ex) {
			throw new InterpretException(ex,"Error in JavaScript expression"); // $NLS-MacroProcessor.ErrorinJavaScriptExpression-1$
		}
		ProgramContext ctx = createProgramContext(expression);
		StringWriter sw = new StringWriter();
		PrintStream ps = new PrintStream( new WriterOutputStream(sw));
		ctx.setPrintStream(ps);
		expression.evaluateValue(ctx);
		sw.flush();
		return sw.toString();
	}
	
	private void addString(StringBuilder jsSource, String source, int start, int end) {
		jsSource.append("print('"); //$NON-NLS-1$
		jsSource.append(TextUtil.toJavaString(source.substring(start,end),false));
		jsSource.append("')\n"); //$NON-NLS-1$
	}
	
	public static void main(String[] args) {
		test("<test></test>"); //$NON-NLS-1$
		test("<test attr='<%=3+4%>'></test>"); //$NON-NLS-1$
		test("<test attr='<%=3+4%>' attr2='<%=5+6%>'></test>"); //$NON-NLS-1$
		test("<test attr='<%=3+4%>' attr2='<%=5+6%>'><%for(i=0; i<4; i++){%><a attr='<%=i%>'/><%}%></test>"); //$NON-NLS-1$
	}
	private static void test(String s) {
		try {
			System.out.println(StringUtil.format("=======================================================")); //$NON-NLS-1$
			System.out.println(StringUtil.format(">>>>Source:\n{0}\n",s)); //$NON-NLS-1$
			MacroProcessor p = new MacroProcessor(new ExtendedJSContext(false));
			String js = p.generateScript(s);
			System.out.println(StringUtil.format(">>>>JS Source:\n{0}\n",js)); //$NON-NLS-1$
			String res = p.executeScript(js);
			System.out.println(StringUtil.format(">>>>Result:\n{0}\n",res)); //$NON-NLS-1$
		} catch(Exception e) {
			System.out.println(StringUtil.format("Error while processing text")); //$NON-NLS-1$
			e.printStackTrace();
		}
	}
	
}
