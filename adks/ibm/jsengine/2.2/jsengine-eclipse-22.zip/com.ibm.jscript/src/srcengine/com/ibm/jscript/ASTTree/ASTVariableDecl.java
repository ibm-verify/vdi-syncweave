/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import java.util.ArrayList;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.parser.ParseException;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSString;

public class ASTVariableDecl extends ASTNode{

    ArrayList<Entry> entries = new ArrayList<Entry>();

    public ASTVariableDecl() {
    }

    public static final class Entry{
        String varName;
        String varType;
        ASTNode initNode;

        public Entry(String name, String type, ASTNode init){
            varName=name;
            varType=type;
            initNode=init;
        }
        public String getName(){
            return varName;
        }
        public String getType() {
            return varType;
        }
        public ASTNode getInitNode(){
            return initNode;
        }
    }

    public void add(String name, String type, ASTNode initialize){
        entries.add(new Entry(name,type,assignParent(initialize)));
    }

    public int getSlotCount(){
        return getEntryCount();
    }
    public ASTNode readSlotAt(int index){
        return getEntryAt(index).getInitNode();
    }

    public int getEntryCount(){
        return entries.size();
    }

    public Entry getEntryAt(int index){
        return (Entry)entries.get(index);
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
        	String varName = null;
            FBSDefaultObject vObj=context.getVariableObject();
            for(int i=0;i<getEntryCount();i++){
                Entry e= getEntryAt(i);
                ASTNode node=e.getInitNode();
                if (node!=null){
                    if(!node.interpret(this,context,result)) {
                    	return false;
                    }
                    // The property is already created by the execution scope...
                    vObj.propPut(e.getName(),result.getFBSValue());
                }
                varName = e.getName();
            }
            result.setNormal(varName!=null?FBSString.get(varName):null);
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public void optimize(JSContext context) throws ParseException {
    	ASTExecutionScope es = ASTExecutionScope.getExecutionScope(getParent());
    	if(es!=null) {
    		es.addVarDecl(this);
    	}
        super.optimize(context);
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitVariableDecl(this, param);
    }
}
