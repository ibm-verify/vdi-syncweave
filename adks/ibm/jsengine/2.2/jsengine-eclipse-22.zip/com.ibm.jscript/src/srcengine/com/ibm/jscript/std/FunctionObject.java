/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import java.util.List;

import com.ibm.commons.util.profiler.Profiler;
import com.ibm.commons.util.profiler.ProfilerAggregator;
import com.ibm.commons.util.profiler.ProfilerType;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.ASTTree.ASTFunction;
import com.ibm.jscript.ASTTree.ASTNode;
import com.ibm.jscript.ASTTree.InterpretResult;
import com.ibm.jscript.JSContext.ILibrary;
import com.ibm.jscript.engine.FunctionContext;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSGlobalObject;
import com.ibm.jscript.types.FBSNumber;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.FBSValueVector;

public class FunctionObject extends FBSDefaultObject {

    private static final ProfilerType profilerFunctionExec = new ProfilerType("JavaScript Function Exec"); //$NON-NLS-1$
    private static final ProfilerType profilerFunctionCtor = new ProfilerType("JavaScript Function Ctor"); //$NON-NLS-1$

    public static final int MOD_RETLAST    = 0x0001;

    private int modifiers;
    private List<?> formalParams;
    private ASTFunction functionNode;

    // Function parent context
    // This points to the variable in the parent function/library that existed when the function
    // object had been created.
    // We do not hold the full execution context here as we want to release the 'this' object and
    // we don't want to go through the entire chain of search for the context
    private FBSDefaultObject parentVars;
    
	// Prototype only ctor
	protected FunctionObject(JSContext jsContext, FBSDefaultObject proto) {
        super(jsContext,proto);
    }
    
    public FunctionObject(JSContext jsContext, IExecutionContext ctx, int modifiers, List<?> formalParams, ASTFunction func) {
        super(jsContext,jsContext.getRegistry().functionPrototype,false);
        this.parentVars = ctx.getFunctionParentVariableObject();
        this.modifiers = modifiers;
        this.functionNode=func;
        if (formalParams!=null){
            this.formalParams = formalParams;
            createProperty("length",FBSObject.P_NODELETE|FBSObject.P_NOENUM|FBSObject.P_READONLY,FBSNumber.get(formalParams.size())); //$NON-NLS-1$
        } else {
            createProperty("length",FBSObject.P_NODELETE|FBSObject.P_NOENUM|FBSObject.P_READONLY,FBSNumber.Zero); //$NON-NLS-1$
        }
        FBSDefaultObject defaultPrototype = new ObjectObject(getJSContext());
        createProperty("prototype",FBSObject.P_NODELETE,defaultPrototype); //$NON-NLS-1$
        //createProperty("prototype",FBSObject.P_NODELETE,FBSUndefined.undefinedValue); //$NON-NLS-1$
    }
    
    public ILibrary getLibrary() {
    	// We look for a global object in the chain that is a library global one
        for(FBSDefaultObject o = parentVars; o!=null; o=(o instanceof FBSActivationObject) ? ((FBSActivationObject)o).getParent() : null ) {
        	if(o instanceof FBSGlobalObject) {
        		ILibrary lib = ((FBSGlobalObject)o).getLibrary();
        		if(lib!=null) {
        			return lib;
        		}
        	}
        }
        return null;
    }

    public FBSDefaultObject getParentVars() {
    	return parentVars;
    }
    
    public int getType(){
        return FBSValue.FUNCTION_TYPE;
    }

    public String getTypeAsString(){
        return "Function"; //$NON-NLS-1$
    }

    public ASTFunction getFunctionNode() {
        return functionNode;
    }

    public boolean hasInstance(FBSValue v){
        if(v instanceof ObjectObject) {
            return ((ObjectObject) v).getConstructor()==this;
        }
        return false;
    }

    
    public boolean supportConstruct(){
        return true;
    }

    public FBSValue construct(IExecutionContext context, FBSValueVector args) throws InterpretException {
        //FBSValue v = func.executeFunction(context,args,func);
        if( Profiler.isEnabled() ) {
            String param = getFunctionNode()!=null ? getFunctionNode().getName() : "";
            ProfilerAggregator agg = Profiler.startProfileBlock(profilerFunctionCtor,param);
            long ts = Profiler.getCurrentTime();
            try {
                return _construct(context, args);
            } finally {
                Profiler.endProfileBlock(agg,ts);
            }
        } else {
            return _construct(context, args);
        }
    }
    private FBSValue _construct(IExecutionContext context, FBSValueVector args) throws InterpretException {
        FBSValue proto = get("prototype"); // $NON-NLS-1$
        FBSDefaultObject protoObject =  (FBSDefaultObject)proto;
        //FBSDefaultObject protoObject =  proto instanceof FBSDefaultObject ? (FBSDefaultObject)proto : new ObjectObject(getJSContext());
        ObjectObject func = new ObjectObject(getJSContext(),protoObject, this);
        FBSValue v = _executeFunction(context,args,func,true);
        
        // This supports this use case, when a fct ctor actually returns a value
        //      var tagcloud = function () {
        //            function init() {
        //              println("HERE MAN");
        //            }
        //            return {init: init}
        //          }
        //
        //      var v = tagcloud()
        //      v.init()
        if(!v.isUndefined()) {
            return v;
        }
        
        return func;
    }

    protected String[] getCallParameters() {
        return new String[] {"()"}; //$NON-NLS-1$
    }

    public FBSObject call(FBSValueVector args){
        return null;
    }

    public boolean supportCall(){
        return true;
    }

    public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this)throws InterpretException{
        return executeFunction(context,args,_this!=null ? _this : this);
    }

    private FBSValue executeFunction(IExecutionContext context,FBSValueVector args,FBSObject _this)throws InterpretException{
        if( Profiler.isEnabled() ) {
            String param = getFunctionNode()!=null ? getFunctionNode().getName() : "";
            ProfilerAggregator agg = Profiler.startProfileBlock(profilerFunctionExec,param);
            long ts = Profiler.getCurrentTime();
            try {
                return _executeFunction(context,args,_this,false);
            } finally {
                Profiler.endProfileBlock(agg,ts);
            }
        } else {
            return _executeFunction(context,args,_this,false);
        }
    }
    private FBSValue _executeFunction(IExecutionContext context,FBSValueVector args,FBSObject _this,boolean construct)throws InterpretException{
        ObjectObject argObj= new ObjectObject(getJSContext());
        argObj.createProperty("callee",FBSObject.P_NOENUM,this); //$NON-NLS-1$

        // Create the activation object
        // This activation object will hold the local variables as well as the arguments
        // Moreover, the activation object will also delegate to the parent function variables
        // These variables are the parent variables available when the function was created. They
        // can come from an enclosing function or a library.
        FBSActivationObject actObj= new FBSActivationObject(getJSContext(),parentVars);
        actObj.createProperty("arguments",FBSObject.P_NODELETE,argObj); //$NON-NLS-1$
        argObj.createProperty("length",FBSObject.P_NOENUM,FBSNumber.get(args.size())); //$NON-NLS-1$

        // create the function context
        IExecutionContext runtimeContext;			// Transient runtime context used by the function 
    	// The execution context is either the library context or the outer function context.
        // If not null, it becomes the parent context so the function uses it to store its
        // global object. If null, the we should use the current program context
        if(getJSContext().includeCallerFunctionContext()) {
        	// Domino use case is here, through the option above
            // There is a bug in Domino 8.5 that allowed the following kind of construction:
            //   function f() {
            //     var aa = "LLL"
            //     g()
            //   }
            //   function g() {
            //     print("VAR="+aa);
            //   }
            // The variable 'aa' is seen by the g() function as it is called from f(). This
            // is definitively not a construction supported by ECMA 262 so we put it optionally
            // to maintain the Domino compatibility

        	// Note that the caller context can itself be a function context, delegating to its own
        	// execution context. It also makes available the local variables of this function, as
        	// well as the scope of the global context (SPR #MKEE7Y3NWB)
        	runtimeContext = context;
        } else {
        	runtimeContext = context.getProgramContext();
        }
  
    	// BEGIN TDI Change
        IExecutionContext funcContext= new FunctionContext(getJSContext(),runtimeContext,this,actObj,_this, context);
    	// END TDI Change
        
        // First, add all the actual parameters to the args object
        int sz= args.size();
        for (int i=0;i<sz;i++){
            argObj.put(FBSNumber.toString(i),args.get(i));        
        }
        
        // And then publish the formal parameters
        if(formalParams!=null) {
            for(int i=0;i<formalParams.size();i++){
                ASTFunction.Parameter p = (ASTFunction.Parameter)formalParams.get(i);
                if (i<sz){
                    actObj.put(p.getName(),args.get(i));
                }else{
                    actObj.put(p.getName(),FBSUndefined.undefinedValue);
                }
            }
        }
        
        // Create the variables for the function
        if(functionNode!=null) {
            functionNode.initContext(funcContext);
        }

        // Execute the function
        // If a return statement is executed, then a AbruptReturnException is emitted
        try {
            InterpretResult result= new InterpretResult();
            int count = functionNode!=null ? functionNode.getSlotCount() : 0;
            for(int i=0;i<count;i++){
                ASTNode node=functionNode.readSlotAt(i);
                if (node!=null){
                    if(!node.interpret(null, funcContext, result)) {
                    	if(result.isReturnSignal()) {
                            FBSValue value = funcContext.getReturnValue();
                            return value;
                    	}
                    	// We just swallow the other signals..
                    	return FBSUndefined.undefinedValue;
                    }
                }
            }
            // Return the last evaluated node
            if( (modifiers & MOD_RETLAST)!=0 ) {
                FBSValue v=result.getFBSValue();
                if(v!=null) {
                    return v;
                }
            }
        } catch( InterpretException ie ) {
            throw ie;
        } catch( JavaScriptException ie ) {
            // In case of break/continue
            return FBSUndefined.undefinedValue;
        }

        return FBSUndefined.undefinedValue;
    }

    // just an identifier of an activation object
    public static class FBSActivationObject extends FBSDefaultObject{
    	FBSDefaultObject parent;
        FBSActivationObject(JSContext jsContext,FBSDefaultObject parent){
            super(jsContext);
            this.parent = parent;
        }
        public FBSDefaultObject getParent() {
        	return parent;
        }
    }
}