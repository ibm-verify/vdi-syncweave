/*
 * IBM Confidential 
 * OCO Source Materials 
 * 
 * $$FILENAME$$
 * 
 * (C) Copyright IBM Corp. 2004, 2005
 * The source code for this program is not published or otherwise 
 * divested of its trade secrets, irrespective of what has been 
 * deposited with the U. S. Copyright Office. 
 * All rights reserved.
 */
package com.ibm.jscript.std;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JSExpression;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.parser.ParseException;
import com.ibm.jscript.types.BuiltinConstructor;
import com.ibm.jscript.types.BuiltinFunction;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSNull;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.FBSValueVector;

/**
 * 
 */
public class FunctionPrototype extends FunctionObject implements Prototype {

    private static final String ANONYMOUS_FUNCTION_NAME = "anonymous"; // $NON-NLS-1$
    
    public FunctionPrototype(JSContext jsContext) {
        super(jsContext,jsContext.getRegistry().objectPrototype);
        int attrib=FBSObject.P_NOENUM;
        createConstructor(attrib,new FunctionConstructor(jsContext,this)); //$NON-NLS-1$
        createProperty("toString",attrib,new FunctionMethod(jsContext,0)); //$NON-NLS-1$
        createProperty("apply",attrib,new FunctionMethod(jsContext,1)); //$NON-NLS-1$
        createProperty("call",attrib,new FunctionMethod(jsContext,2)); //$NON-NLS-1$
    }
    public FBSValue construct(IExecutionContext context, FBSValueVector args) throws InterpretException {
    	return FBSUndefined.undefinedValue;
    }
    public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this)throws InterpretException{
    	return FBSUndefined.undefinedValue;
    }

    ////// Constructor
    static class FunctionConstructor extends BuiltinConstructor{
        public FunctionConstructor(JSContext jsContext, FBSDefaultObject prototype){
            super(jsContext,prototype,"Function"); // $NON-NLS-1$
        }
        public boolean hasInstance(FBSValue v){
            return v instanceof FunctionObject;
        }
        public boolean supportConstruct(){
            return true;
        }
        protected String[] getConstructorParameters() {
            return new String[] {"(parameters:Nbody:T)"}; //$NON-NLS-1$
        }

        public FBSObject construct(IExecutionContext context, FBSValueVector args) throws InterpretException {
            String body = args.size()>0 ? args.get(args.size()-1).stringValue() : "";
            StringBuilder b = new StringBuilder();
            b.append("function "); // $NON-NLS-1$
            b.append(ANONYMOUS_FUNCTION_NAME);
            b.append("(");
            for( int i=0; i<args.size()-1; i++ ) {
                if(i>0) {
                    b.append(',');
                }
                b.append(args.get(i).stringValue());
            }
            b.append(") {\n"); // $NON-NLS-1$
            b.append(body);
            b.append("\n}"); // $NON-NLS-1$
            
            String code = b.toString();
            
            // Compile the code
            try {
                JSExpression exp = context.getJSContext().createExpression(code);
                exp.evaluateLibrary(null);
                return (FBSObject)exp.getGlobalObject().getProperty(ANONYMOUS_FUNCTION_NAME);
            } catch (ParseException e) {
                throw new InterpretException(e,ErrorObject.SyntaxErrorObject.create(context.getJSContext(),"Error while parsing script of Function(), {0}",StringUtil.toString(code,64)));  // $NLS-FunctionPrototype.ErrorwhileparsingscriptofFunction-1$[[Function() should not be translated]]
            }
        }
        public boolean supportCall(){
            return true;
        }
        public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this)throws InterpretException{
            return construct(context,args);
        }
        protected String[] getCallParameters() {
            return new String[] {"(parameters:Nbody:T):U"}; //$NON-NLS-1$
        }
    }


    static class FunctionMethod extends BuiltinFunction {
        int mIndex=-1;

        public FunctionMethod(JSContext jsContext, int index){
            super(jsContext);
            mIndex=index;
        }

        protected String[] getCallParameters() {
            switch(mIndex) {
                case 0: //toString
                    return new String[] {"():T"}; //$NON-NLS-1$
                case 1: //apply
                    return new String[] {"(thisArg:WargArray:W):T"}; //$NON-NLS-1$
                case 2: //call
                    return new String[] {"(thisArg:Wargs:N):T"}; //$NON-NLS-1$
            }
            return super.getCallParameters();
        }


        public FBSValue call(FBSValueVector args, FBSObject _this) throws InterpretException {
            return FBSUndefined.undefinedValue;
        }

        public FBSValue call(IExecutionContext context, FBSValueVector args, FBSObject _this) throws InterpretException {
            switch(mIndex){
                case 0: {     // toString
                    if(_this instanceof FunctionObject) {
                        return FBSString.get("[function "+_this.getTypeAsString()+"]"); //$NON-NLS-1$ //$NON-NLS-2$
                    }
                    throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"This toString() function must be applied to a Function object, {0}",FBSUtility.getDisplayType(_this))); // $NLS-FunctionPrototype.ThistoStringfunctionmustbeapplied-1$
                }
                case 1: {     // apply
                    if(_this instanceof FunctionObject) {
                        int argsCount = args.getCount();
                        FBSObject thisObj;
                        FBSValue thisArg = argsCount>=1 ? args.get(0) : FBSUndefined.undefinedValue;
                        if(thisArg.isNull() || thisArg.isUndefined()) {
                            thisObj = context.getGlobalObject();
                        } else {
                            thisObj = thisArg.toFBSObject(getJSContext());
                        }
                        FBSValueVector fctArgs = new FBSValueVector();
                        FBSValue argsArray = argsCount>=2 ? args.get(1) : FBSNull.nullValue;
                        if(!argsArray.isNull()) {
                            if(!argsArray.isArray()) {
                                throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"apply() needs an array as the second parameter")); // $NLS-FunctionPrototype.applyneedsanarrayasthesecondparam-1$
                            }
                            int count = argsArray.getArrayLength();
                            for(int i=0; i<count; i++ ) {
                                fctArgs.add(argsArray.getArrayValue(i));
                            }
                        }
                        FunctionObject fct = (FunctionObject)_this;
                        return fct.call(context, fctArgs, thisObj);
                    }
                } break;
                case 2: {     // call
                    if(_this instanceof FunctionObject) {
                        int argsCount = args.getCount();
                        FBSObject thisObj;
                        FBSValue thisArg = argsCount>=1 ? args.get(0) : FBSUndefined.undefinedValue;
                        if(thisArg.isNull() || thisArg.isUndefined()) {
                            thisObj = context.getGlobalObject();
                        } else {
                            thisObj = thisArg.toFBSObject(getJSContext());
                        }
                        FBSValueVector fctArgs = new FBSValueVector();
                        if(args.size()>1) {
                            int count = args.size();
                            for(int i=1; i<count; i++ ) { // Ignore thisAr
                                fctArgs.add(args.get(i));
                            }
                        }
                        FunctionObject fct = (FunctionObject)_this;
                        return fct.call(context, fctArgs, thisObj);
                    }
                } break;
            }
            throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Function function not found")); // $NLS-FunctionPrototype.Functionfunctionnotfound-1$
        }
    }
}