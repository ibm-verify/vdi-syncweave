/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import java.util.ArrayList;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.std.ObjectObject;
import com.ibm.jscript.types.FBSType;

public class ASTObjectLiteral extends ASTNode{
    private ArrayList fieldInitializers = new ArrayList();

    public ASTObjectLiteral() {
    }

    public final static class Initializer {
		final public ASTLiteral field;
		final public ASTNode init;
	
		Initializer(ASTLiteral field, ASTNode init) {
		    this.field = field;
		    this.init = init;
		}
    };

    public void add(ASTLiteral field, ASTNode initializer){
    	assignParent(field);
    	assignParent(initializer);
        fieldInitializers.add(new Initializer(field, initializer));
    }

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        return FBSType.jsObjectType;
    }

    public int getSlotCount(){
        return fieldInitializers.size();
    }

    public Initializer readInitAt(int index) {
        return (Initializer)fieldInitializers.get(index);
    }

    public ASTNode readSlotAt(int index){
        return ((Initializer)fieldInitializers.get(index)).init;
    }

    public boolean interpret(ASTNode caller,IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            ObjectObject obj = new ObjectObject(context.getJSContext());
            int count = fieldInitializers.size();
            for(int i=0;i<count;i++){
                Initializer n=(Initializer)fieldInitializers.get(i);
				ASTLiteral f = n.field;
				ASTNode v = n.init;
				if(!v.interpret(this,context,result)) {
					return false;
				}
				obj.put( f.toString(), result.getFBSValue() );
		    }
            result.setNormal( obj );
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }
    
    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitObjectLiteral(this, param);
    }
}
