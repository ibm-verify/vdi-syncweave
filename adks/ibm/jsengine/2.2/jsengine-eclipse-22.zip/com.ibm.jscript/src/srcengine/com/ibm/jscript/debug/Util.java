/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.debug;

import java.text.DateFormat;
import java.util.Date;

public class Util {
    
   /*********************************************************************************
     * TRACING 
     *********************************************************************************/
        
    private static boolean    traceEnabled = false;
    private static boolean    firstTime = true;
    private static DateFormat dateFormat  = null;
        
    //Clients should call traceEnabled() before calling this metohd so that 
    //an unnecessary String parameters for this method aren't created.
    //id: name of the class
    public static void trace(String id, String message) {
        if (traceEnabled())
            System.out.println(dateFormat.format(new Date()) + " [" + id + "]:  " + message);
        
    }
    
    public static void trace(Exception e) {
        if (traceEnabled())
            e.printStackTrace();
    }
    
    //Only check the Java Property once
    public static boolean traceEnabled() {
        if (firstTime) {
            firstTime = false;
            String traceProperty = System.getProperty("jsdebug.trace"); // $NON-NLS-1$
            if (traceProperty != null) {
                if (traceProperty.toLowerCase().equals("true")) { // $NON-NLS-1$
                    traceEnabled = true;
                    dateFormat = DateFormat.getTimeInstance(DateFormat.MEDIUM);
                }
        
            }
        }
        return traceEnabled;
    }
}
