/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.engine;

import com.ibm.jscript.ASTTree.ASTNode;
import com.ibm.jscript.ASTTree.InterpretResult;

public class DebugEvent {
    ASTNode sender;
    IExecutionContext context;
    InterpretResult result;

    public DebugEvent(ASTNode sender,IExecutionContext context,InterpretResult result) {
        setSender(sender);
        setContext(context);
        setResult(result);
    }

    public void setSender(ASTNode sender){
        this.sender=sender;
    }

    public void setContext(IExecutionContext context){
        this.context=context;
    }

    public void setResult(InterpretResult result){
        this.result=result;
    }

    public ASTNode getSender(){
        return sender;
    }

    public IExecutionContext getContext(){
        return context;
    }

    public InterpretResult getResult(){
        return result;
    }
}
