/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.debug;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSDefaultObject;

public class ServerStackFrame {
    private String              fName           = null;
    private String              fSourceFile     = null;
    private Integer             fLineNumber     = null;
    private Integer             fUniqueID       = null;
    private IExecutionContext   fContext        = null;
    private ServerVariable      fLocalVariables = null;
        
    /**************************************************************
     * Constructor
     **************************************************************
     */
    public ServerStackFrame(IExecutionContext theContext, String theName, String theFileName, int theLineNumber) {
        fContext = theContext;
        fName   = theName;
        fSourceFile = theFileName;
        fLineNumber = new Integer(theLineNumber);     
    }
    
    /**************************************************************
     * setUniqueID()
     * The unique ID is an int that can be used to locate this StackFrame in the 
     * ServerThread's ArrayList of StackFrames.
     **************************************************************
     */
    public void setUniqueID(int uniqueID) {
        fUniqueID = new Integer(uniqueID);
    }
    
    /**************************************************************
     * Simple getters
     **************************************************************
     */
    public String  getName()           { return fName; }    
    public String  getSourceFileName() { return fSourceFile;}
    public Integer getLineNumber()     { return fLineNumber; }
    public Integer getUniqueID()       { return fUniqueID; }
    
    /**************************************************************
     * equals()
     * To compare, we'll just use the name
     **************************************************************
     */
    public boolean equals(ServerStackFrame theFrame) {
        return theFrame.getName().equals(fName);
    }
    
    /**************************************************************
     * getVariables()
     * Create a "hidden" parent variable and then use it to generate
     * the variable info String
     **************************************************************
     */
    public String getVariables() {
        if (fLocalVariables == null) {
            fLocalVariables = new ServerVariable("Context Variable", "", "",fContext.getVariableObject()); // $NLS-ServerStackFrame.ContextVariable-1$
            FBSDefaultObject registry = fContext.getVariableObject().getJSContext().getRegistry().getRegistryObject();
            ServerVariable globalVariables = new ServerVariable("Global Variables", "", "", registry); // $NLS-ServerStackFrame.GlobalVariables-1$
            fLocalVariables.addVariable(globalVariables);
        }
        return fLocalVariables.getVariables();
    }
    
    /**************************************************************
     * getVariable()
     * Get a variable based on its unique ID.   Delegate this 
     * task to the hidden ServerVariable. 
     **************************************************************
     */
    public Object getVariable(int uniqueID) {
        if (fLocalVariables == null) {
            getVariables(); 
        }
        return fLocalVariables.getVariable(uniqueID);
    }
    
    
    /**************************************************************
     * METHOD CALLED BY DEBUG CLIENT - getSource()
     * Return the Expression Source for the current context
     **************************************************************
     */
    public String getSource() {
        return fContext.getExpression().getExpr();
    }

    
        
    
    /******** PRIVATE METHODS from this point and below ***********/
    
    
    
    /*
    
    
      public static ArrayList getVariables (FBSObject varObject) {
            //addVariableObjects( VAR_CAT_GLOBAL, fUnderlyingVariable.getJSContext().getRegistry().getRegistryObject() );
            if (varObject == null) {
                return null;
            }
            
            ArrayList variables = new ArrayList(10);
            try {
                Iterator subVars = varObject.getPropertyKeys();
                if (subVars != null) {
                    while (subVars.hasNext()) {
                        String varName = (String)subVars.next();
                        FBSValue subValue = (FBSValue)varObject.getProperty(varName);
                        if (!subValue.isObject()) {
                            ServerVariable sv = new ServerVariable(null, varName, subValue.getTypeAsString(), subValue.stringValue());
                            variables.add(sv);
                        }   
                        else if (subValue.getTypeAsString().equals("Boolean")) { //$NON-NLS-1$
                            ServerVariable sv = new ServerVariable(null, varName, subValue.getTypeAsString(), subValue.stringValue());
                            variables.add(sv);
                        }
                        else {
                            ServerVariable sv = new ServerVariable(subValue.toFBSObject(varObject.getJSContext()), varName, subValue.getTypeAsString(), null);
                            variables.add(sv);
                        }
                    }
                } 
            } catch (InterpretException e) {
                varObject.getJSContext().exception(e,""); //$NON-NLS-1$
            }
            return variables;
      }
      
      */

    
}
