/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import java.util.Iterator;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.engine.IExecutionContext;

public abstract class FBSConstructor extends FBSObject{

    public FBSConstructor(JSContext jsContext) {
        super(jsContext);
    }
    
    public int getType(){
        return FBSValue.FUNCTION_TYPE;
    }

    public String getTypeAsString(){
        return "constructor"; // $NON-NLS-1$
    }

//    public abstract FBSObject construct(FBSValueVector args)throws InterpretException;

    public boolean supportConstruct(){
        return true;
    }

    public boolean hasInstance(FBSValue v){
        return false;
    }

    public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this)throws InterpretException{
        throw new InterpretException(null,"Unsupported method for BuiltinFunction"); // $NLS-FBSConstructor.UnsupportedmethodforBuiltinFuncti-1$
    }

    public boolean supportCall(){
        return false;
    }

    public Object toJavaObject(Class _class)throws InterpretException{
    	return null;
        //throw new InterpretException(null,"toJavaObject() not implemented for this object"); // $NLS-FBSConstructor.methodtoJavaObjectisnotyetimpleme-1$
    }

    public boolean createProperty(String name , int attribute, FBSValue value ){
        return false;
    }


    public FBSValue get(int index){
        throw new RuntimeException("get(int index) not supported in BuiltinFunction"); // $NLS-FBSConstructor.getintindexnotsupportedinBuiltinF-1$
    }
    public void put(int index , FBSValue value){
        throw new RuntimeException("put(int index,FBSValue value) not supported in BuiltinFunction"); // $NLS-FBSConstructor.putintindexFBSValuevaluenotsuppor-1$
    }

    public void put(String name , FBSValue value){
    }

    public FBSValue get(String name){
        return FBSUndefined.undefinedValue;
    }


    public boolean canPut(String name){
        return  false;
    }

    public boolean hasProperty(String name){
        return false;
    }

    public boolean delete(String name){
        return false;
    }

    public Iterator getPropertyKeys() {
        return null;
    }
}
