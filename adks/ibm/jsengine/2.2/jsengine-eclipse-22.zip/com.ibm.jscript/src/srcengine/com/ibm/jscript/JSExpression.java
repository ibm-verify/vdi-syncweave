/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript;

import java.io.PrintStream;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.List;

import com.ibm.commons.Platform;
import com.ibm.commons.util.StringUtil;
import com.ibm.commons.util.profiler.Profiler;
import com.ibm.commons.util.profiler.ProfilerAggregator;
import com.ibm.commons.util.profiler.ProfilerType;
import com.ibm.jscript.ASTTree.ASTArrayMember;
import com.ibm.jscript.ASTTree.ASTAssign;
import com.ibm.jscript.ASTTree.ASTBlock;
import com.ibm.jscript.ASTTree.ASTCall;
import com.ibm.jscript.ASTTree.ASTFunction;
import com.ibm.jscript.ASTTree.ASTIdentifier;
import com.ibm.jscript.ASTTree.ASTLiteral;
import com.ibm.jscript.ASTTree.ASTMember;
import com.ibm.jscript.ASTTree.ASTNode;
import com.ibm.jscript.ASTTree.ASTProgram;
import com.ibm.jscript.ASTTree.ASTVariableDecl;
import com.ibm.jscript.ASTTree.InterpretResult;
import com.ibm.jscript.JSContext.ILibrary;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.engine.LibraryContext;
import com.ibm.jscript.engine.ProgramContext;
import com.ibm.jscript.parser.FBScript2;
import com.ibm.jscript.parser.ParseException;
import com.ibm.jscript.std.FunctionObject;
import com.ibm.jscript.types.FBSGlobalObject;
import com.ibm.jscript.types.FBSNull;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.FBSValueVector;
import com.ibm.jscript.util.StringSet;

/**
 * Expression evaluator class.
 */
public class JSExpression implements IFormula {

	private static final ProfilerType profilerExecuteExpr = new ProfilerType("JavaScript expression"); //$NON-NLS-1$
	private static final ProfilerType profilerExecuteFunc = new ProfilerType("JavaScript function"); //$NON-NLS-1$

    public static final String DYNAMIC_SOURCE_ID = "__dynamic_source_id__"; //$NON-NLS-1$
    
    public static String composeSourceReference(String fileName, String id) {
        if(!StringUtil.isEmpty(id)) {
            return fileName + "#" + id; //$NON-NLS-1$
        }
        return fileName;
    }
    
    private FBSGlobalObject globalObject;
    private boolean evaluateConstant;


    static class ExpressionData {
        private String expr;
        private ASTProgram mainNode;
        private JSContext jsContext;
        ExpressionData(JSContext jsContext, String expr) throws ParseException {
            this.jsContext = jsContext;
            this.expr = expr;
            if(!StringUtil.isSpace(expr)) {
                try {
                	String exTrim = expr;
                    FBScript2 exprParser=jsContext.getParser(exTrim);
                    mainNode= (ASTProgram)exprParser.program();
                    mainNode.setExpr(exTrim);
                    mainNode.optimize(jsContext);
                    if(JSContext.CHECK) {
                        mainNode.check();
                    }
                } catch(Throwable t) {
                    if(! (t instanceof ParseException)) {
                        //com.ibm.workplace.designer.util.TDiag.exception(t);
                        throw new ParseException(t.getMessage());
                    }
                    throw(ParseException)t;
                }
            }
            //TDiag.trace( "Resulting type={0}", getResultType(null).toString() );
            //dump();
        }

        ExpressionData(String expr, ASTProgram mainNode) {
            this.expr = expr;
            this.mainNode = mainNode;
            mainNode.setExpr(expr);
        }

        JSContext getJSContext() {
            return jsContext;
        }

        ASTProgram getMainNode() {
            return mainNode;
        }
    }

    /**
     * Constructor.
     */
    JSExpression(String sourceReferenceID, ExpressionData data, boolean evaluateConstant) {
        this.sourceReferenceID = sourceReferenceID;
        this.data = data;
        this.evaluateConstant = evaluateConstant;
    }
    JSExpression(String sourceReferenceID, ExpressionData data) {
        this.sourceReferenceID = sourceReferenceID;
        this.data = data;
    }

    /**
     * Get the current global object.
     * @return
     */
    public FBSObject getGlobalObject() {
        return globalObject;
    }
    
    /**
     * Get the source reference ID.
     */
    public String getSourceReferenceID() {
        return sourceReferenceID;
    }

    /**
     * Set the source reference ID.
     */
    public void setSourceReferenceID(String sourceReferenceID) {
        this.sourceReferenceID = sourceReferenceID;
    }
    
    /**
     * Check if the expression is in constant evaluation mode.
     */
    public boolean isEvaluateConstant() {
        return evaluateConstant;
    }
    
    /**
     * Get the expression context
     * @return
     */
    public JSContext getJSContext() {
        return data.getJSContext();
    }
    
    /**
     * Get the main node
     */
    public ASTProgram getMainNode() {
        return data.mainNode;
    }

    /**
     * Get the expression text.
     * @return the expression text
     */
    public String getExpr() {
        return data.expr;
    }

    /**
     * Get the expression result type.
     * It can be one of the following:
     * <ul>
     *   <li>variant (undefined)
     *   <li>boolean
     *   <li>number
     *   <li>string
     *   <li>object
     * </ul>
     */
    public FBSType getResultType(FBSType.ISymbolCallback symbolCallback) {
        ASTProgram mainNode = getMainNode();
        return mainNode!=null?
            mainNode.getResultType(getJSContext(),symbolCallback)
            :FBSType.undefinedType;
    }

    public void dump() {
        dump(null);
    }

    public void dump(PrintStream ps) {
        if(ps==null) {
            ps=getJSContext().getStandardStream();
        }
        ASTProgram mainNode = getMainNode();
        if(mainNode!=null) {
            if(!StringUtil.isEmpty(getExpr())) {
                ps.println("\n"+getExpr()); //$NON-NLS-1$
            } else {
                ps.println(""); //$NON-NLS-1$
            }
            mainNode.dump(getJSContext(),ps);
        } else {
            ps.print("empty expression\n"); //$NON-NLS-1$
        }
    }

 
    /**
     * Evaluate the expression and returns a FBSValue.
     * Used with multiple values
     * @exception thrown when a execution (runtime) error occurs
     */
    public FBSValue evaluateValue(FBSGlobalObject globalObject, FBSObject scope, FBSObject _this, FBSObject params, List<String> importedLibraries) throws InterpretException {
    	ProgramContext ctx = createProgramContext(globalObject, scope, _this, params, importedLibraries);
    	return evaluateValue(ctx);
    }
    public FBSValue evaluateValue(FBSGlobalObject globalObject, FBSObject scope, FBSObject _this, List<String> importedLibraries) throws InterpretException {
    	ProgramContext ctx = createProgramContext(globalObject, scope, _this, null, importedLibraries);
    	return evaluateValue(ctx);
    }
    public FBSValue evaluateValue(FBSGlobalObject globalObject, FBSObject scope, List<String> importedLibraries) throws InterpretException {
        return evaluateValue(globalObject, scope, null, importedLibraries);
    }
    public FBSValue evaluateValue(FBSObject scope, List<String> importedLibraries) throws InterpretException {
        return evaluateValue(null,scope,importedLibraries);    
    }
    public FBSValue evaluateValue(IExecutionContext ctx) throws InterpretException {
        ASTProgram mainNode = getMainNode();
        try {
            if(mainNode!=null) {
                InterpretResult iresult=new InterpretResult();
                interpretExpression(ctx, iresult);
                FBSValue v=iresult.getFBSValue();
                return v!=null?v:FBSNull.nullValue;
            }
            return FBSNull.nullValue;
        } catch(InterpretException e) {
            e.setExpressionText(getExpr());
            throw e;
        }
    }

    public void evaluateLibrary(ILibrary library) throws InterpretException {
        evaluateLibrary(library,null);
    }
    public void evaluateLibrary(final ILibrary library, final FBSObject scope) throws InterpretException {
    	AccessControlContext acc = getJSContext().getAccessControlContext();
    	if(acc!=null) {
    		try {
        		AccessController.doPrivileged(new PrivilegedExceptionAction<Object>() {
        	    	public Object run() throws Exception {
        	            _evaluateLibrary(library,scope);
        	            return null;
        	    	}
        		}, acc);
    		} catch(PrivilegedActionException ex) {
    			throw (InterpretException)ex.getException();
    		}
    	} else {
            _evaluateLibrary(library,scope);
    	}
    }
    private void _evaluateLibrary(ILibrary library, FBSObject scope) throws InterpretException {
        ASTProgram mainNode = getMainNode();
        try {
            if(mainNode!=null) {
                InterpretResult iresult=new InterpretResult();
                // PHIL: we do not call the normal expression evaluation, mainly
                // to bypass the profiler if any is activated. This prevent having
                // a fancy entry, saying that we evaluated source code as an expression
                //globalObject=interpretExpression(null,null,null,iresult);
                IExecutionContext ctx = createLibraryContext(library, scope, null, null);
                globalObject=mainNode.interpretEx(ctx, iresult);
            } else {
                throw new InterpretException(null,"No script found"); //$NLS-JSExpression.JSExpression.NoScriptFound.Exception-1$
            }
        } catch(InterpretException e) {
            e.setExpressionText(getExpr());
            throw e;
        }
    }

    public FBSValue evaluateFunction(FBSObject scope, String name, FBSValueVector args) throws InterpretException {
        ASTProgram mainNode = getMainNode();
        try {
            if(mainNode!=null) {
                // This an evaluation for getting all the global variables
                // as well as the function definitions.
                if(globalObject==null) {
                    // PHIL: that evaluation cannot access the objects in the scope
                    // because it is done once, and it should not depend on any context
                    // Finally, it is like a library
                    //evaluate(null,scope,null,r);
                    evaluateLibrary(null);
                }

                // Search for the function name, in the global object
                FBSValue pfunc=globalObject.get(name);
                if(! (pfunc instanceof FunctionObject)) {
                    if(pfunc==null||pfunc==FBSUndefined.undefinedValue) {
                        throw new InterpretException(null,"Function '{0}' not found"); //$NLS-JSExpression.JSExpression.FunctionNotFound.Exception-1$
                    }
                    throw new InterpretException(null,"'{0}' is not a function"); //$NLS-JSExpression.JSExpression.IsNotAFunction.Exception-1$
                }
                FunctionObject func= (FunctionObject)pfunc;

                // Global object
                // In fact, we use a temporary object that points to the global object as a prototype
                // This GlobalObject wrapper owns all the global variables created while executing the function
                //FBSGlobalObject functionGlobalObject=new FBSGlobalObject((FBSGlobalObject)libraryObject);
                
                // create an execution context and set its scope
                // properties are already set in the globalObject by previous executions.
                IExecutionContext context=new ProgramContext(this, globalObject, scope, null, null, null);
                return interpretFunction(func, context, args, context.getGlobalObject());
            }
            throw new InterpretException(null,"Function '{0}' not found"); //$NLS-JSExpression.JSExpression.FunctionNotFound.Exception-1$
        } catch(InterpretException e) {
            e.setExpressionText(getExpr());
            throw e;
        }
    }

    public FBSValue evaluateFunction(String name) throws InterpretException {
        return evaluateFunction(null, name, null);
    }

    public void registerFunctions(FBSGlobalObject globalObject) throws InterpretException {
    	// nothing here
//        ASTProgram mainNode = getMainNode();
//        try {
//            if(mainNode!=null) {
//                for( int i=0; i<mainNode.getSlotCount(); i++ ) {
//                    if( mainNode.readSlotAt(i) instanceof ASTFunction ) {
//                        ((ASTFunction)mainNode.readSlotAt(i)).register(getJSContext(),globalObject);
//                    }
//                }
//            }
//        } catch(InterpretException e) {
//            e.setExpressionText(getExpr());
//            throw e;
//        }
    }
    
    // ========================================================================
    // IFormula evaluation methods
    // ========================================================================

    public IValue execute(IValue globalObject) throws InterpretException {
        FBSObject scope = null;
        if( globalObject!=null ) {
            if(! (globalObject instanceof FBSObject)) {
                throw new InterpretException(null,"GlobalObject must be an object"); //$NLS-JSExpression.JSExpression.GlobalObjectNotAnObj.Exception-1$
            }
            scope = (FBSObject)globalObject;
        }
        return evaluateValue( scope, null );
    }

    public IValue execute() throws InterpretException {
        return execute(null);
    }

    public IValue callFunction(IValue globalObject, String functionName, IValue[] args) throws InterpretException {
        FBSObject scope=null;
        if(globalObject!=null) {
            if(! (globalObject instanceof FBSObject)) {
                throw new InterpretException(null,"GlobalObject must be an object"); //$NLS-JSExpression.JSExpression.GlobalObjectNotAnObj.Exception-1$
            }
            scope=(FBSObject)globalObject;
        }
        FBSValueVector fctArgs=FBSValueVector.emptyVector;
        if( args!=null && args.length>0 ) {
            fctArgs = new FBSValueVector(args);
        }
        return evaluateFunction( scope, functionName, fctArgs );
    }

    public IValue callFunction(String functionName, IValue[] args) throws InterpretException {
        return callFunction( null, functionName, args );
    }

    public IValue callFunction(String functionName) throws InterpretException {
        return callFunction( null, functionName, null );
    }

    private FBSGlobalObject interpretExpression(final IExecutionContext ctx, final InterpretResult result) throws InterpretException {
    	AccessControlContext acc = ctx.getAccessControlContext();
    	if(acc!=null) {
    		try {
    			return (FBSGlobalObject)AccessController.doPrivileged(new PrivilegedExceptionAction<Object>() {
    		    	public Object run() throws Exception {
    		    		//TraceFile.trace("c:\\expression.txt", "-----------------------------------");
    		    		//TraceFile.trace("c:\\expression.txt", "{0}", getExpr());
    		            return _interpretExpression(ctx, result);
    		    	}
    			}, acc);
    		} catch(PrivilegedActionException ex) {
    			throw (InterpretException)ex.getException();
    		}
    	} else {
            return _interpretExpression(ctx, result);
    	}
    }
    private FBSGlobalObject _interpretExpression(IExecutionContext ctx, InterpretResult result) throws InterpretException {
    	ASTProgram mainNode = getMainNode();
        if(Profiler.isEnabled()) {
            ProfilerAggregator agg=Profiler.startProfileBlock(profilerExecuteExpr, getExpr()); // $NLS-JSExpression.Javascriptexpression-1$
            long startProfiler=Profiler.getCurrentTime();
            try {
                return(FBSGlobalObject)mainNode.interpretEx(ctx, result);
            } finally {
                Profiler.endProfileBlock(agg, startProfiler);
            }
        } else {
            return(FBSGlobalObject)mainNode.interpretEx(ctx, result);
        }
    }

    private FBSValue interpretFunction(final FunctionObject func, final IExecutionContext context, final FBSValueVector args, final FBSObject _this) throws InterpretException {
    	AccessControlContext acc = context.getAccessControlContext();
    	if(acc!=null) {
    		try {
        		return (FBSValue)AccessController.doPrivileged(new PrivilegedExceptionAction<Object>() {
        	    	public Object run() throws Exception {
        	            return _interpretFunction(func, context, args, _this);
        	    	}
        		}, acc);
    		} catch(PrivilegedActionException ex) {
    			throw (InterpretException)ex.getException();
    		}
    	} else {
            return _interpretFunction(func, context, args, _this);
    	}
    }
    private FBSValue _interpretFunction(FunctionObject func, IExecutionContext context, FBSValueVector args, FBSObject _this) throws InterpretException {
    	if(Profiler.isEnabled()) {
            ProfilerAggregator agg=Profiler.startProfileBlock(profilerExecuteFunc, func.getFunctionNode().getName()); // $NLS-JSExpression.Javascriptfunction-1$
            long startProfiler=Profiler.getCurrentTime();
            try {
                return func.call(context, args, _this);
            } finally {
                Profiler.endProfileBlock(agg, startProfiler);
            }
        } else {
            return func.call(context, args, _this);
        }
    }

    /**
     * Creation of a program context.
     */
    public ProgramContext createProgramContext(FBSGlobalObject globalObject, FBSObject scopePrototypes, FBSObject _this, FBSObject params, List<String> importedLibraries) throws InterpretException {
        // Create the execution context
    	if(globalObject==null) {
        	globalObject= new FBSGlobalObject(getJSContext());
    	}
    	ProgramContext prgContext= new ProgramContext(this,globalObject,scopePrototypes,_this,params,importedLibraries);
        return prgContext;
    }
    public LibraryContext createLibraryContext(ILibrary library, FBSObject scopePrototypes, FBSObject _this, List<String> importedLibraries) throws InterpretException {
        // Create the execution context
    	FBSGlobalObject globalObject= new FBSGlobalObject(getJSContext(),library);
        LibraryContext libContext= new LibraryContext(this,globalObject,scopePrototypes,_this,importedLibraries);
        return libContext;
    }

    /**
     * Returns all fields used in the javascript expression, including fields name that are
     * used as parameters of Notes functions such as @Field, @TextField, ...
     * TODO: externalize these functions. Should be in a particular class, and the Notes function 
     * not available here.
     */
    public String[] getGlobalSymbols() {
        ASTProgram mainNode = getMainNode();
        if(mainNode!=null) {
            StringSet vec=new StringSet();
            scanNodes(mainNode, new StringSet(), vec);
            int sz=vec.size();
            if(sz==0) {
                return null;
            }
            String[] symbols=vec.elements();
            return symbols;
        }
        return null;
    }

    private void scanNodes(ASTNode node, StringSet var, StringSet vec) {
        if(node instanceof ASTCall) {   // Ignore function calls
            ASTCall astCall = (ASTCall)node;
            ASTNode astArgs= astCall.getASTArgumentList();
            if(astArgs!=null) {
                // Notes @functions
                // Some functions take a string parameter that is a field name.
                if( astCall.getLeftNode() instanceof ASTIdentifier ) {
                    String idName = ((ASTIdentifier)astCall.getLeftNode()).getIdentifierName();
                    if(    idName.equals("@GetField") //$NON-NLS-1$
                        || idName.equals("@GetTextField") //$NON-NLS-1$
                        || idName.equals("@GetDateField") //$NON-NLS-1$
                        || idName.equals("@GetNumberField") //$NON-NLS-1$
                        || idName.equals("@GetAuthorField") //$NON-NLS-1$
                        || idName.equals("@GetEditorField") //$NON-NLS-1$
                        || idName.equals("@IsAvailable") //$NON-NLS-1$
                        || idName.equals("@IsUnavailable") ) { //$NON-NLS-1$
                        if( astArgs.getSlotCount()==1 ) {
                            ASTNode arg=astArgs.readSlotAt(0);
                            if(arg instanceof ASTLiteral) {
                                ASTLiteral lit= (ASTLiteral)arg;
                                if(lit.getValue().isString()) {
                                    String symb=lit.getValue().stringValue();
                                    if(!var.contains(symb)) {
                                        vec.add(symb);
                                    }
                                    return;
                                }
                            }
                        }
                    }
                    if(    idName.equals("@SetField") //$NON-NLS-1$
                        || idName.equals("@SetTextField") //$NON-NLS-1$
                        || idName.equals("@SetDateField") //$NON-NLS-1$
                        || idName.equals("@SetNumberField") //$NON-NLS-1$
                        || idName.equals("@SetAuthorField") //$NON-NLS-1$
                        || idName.equals("@SetEditorField") ) { //$NON-NLS-1$
                        if( astArgs.getSlotCount()==2 ) {
                            ASTNode arg=astArgs.readSlotAt(0);
                            if(arg instanceof ASTLiteral) {
                                ASTLiteral lit= (ASTLiteral)arg;
                                if(lit.getValue().isString()) {
                                    String symb=lit.getValue().stringValue();
                                    if(!var.contains(symb)) {
                                        vec.add(symb);
                                    }
                                    return;
                                }
                            }
                        }
                    }
                }

                // Scan all the functions parameters
                scanNodes(astArgs, var, vec);
            }
        } else {
            // Check variable assignment
            if(node instanceof ASTAssign) {
                ASTAssign a= (ASTAssign)node;
                ASTNode leftNode = a.getLeftNode();
                while(true) {
                    if( leftNode instanceof ASTMember ) {
                        leftNode = ((ASTMember)leftNode).getLeftNode();
                    } else if( leftNode instanceof ASTArrayMember ) {
                        leftNode = ((ASTArrayMember)leftNode).getLeftNode();
                    } else {
                        break;
                    }
                }
                if(leftNode instanceof ASTIdentifier) {
                    ASTIdentifier idn= (ASTIdentifier)leftNode;
                    var.add(idn.getIdentifierName());
                }
            }
            // Check variable declaration
            if(node instanceof ASTVariableDecl) {
                ASTVariableDecl v= (ASTVariableDecl)node;
                for(int i=0; i<v.getEntryCount(); i++) {
                    ASTVariableDecl.Entry e=v.getEntryAt(i);
                    var.add(e.getName());
                }
            }
            // And now, store identifier
            if(node instanceof ASTIdentifier) {
                ASTIdentifier idn= (ASTIdentifier)node;
                String symb=idn.getIdentifierName();
                // Should not be part of the global variable list
                if(!var.contains(symb)) {
                    vec.add(symb);
                }
            }
            int sz=node.getSlotCount();
            for(int i=0; i<sz; i++) {
                ASTNode node1=node.readSlotAt(i);
                if(node1!=null) {
                    scanNodes(node1, var, vec);
                }
            }
        }
    }

// SYMBOL EXTRACTION CHECKING
//    public static void main(String args[]) {
//        extract( "toto" );
//        extract( "s; toto" );
//        extract( "var s, t=2; toto" );
//        extract( "s=3; s; titi" );
//        extract( "s[i]=3; toto" );
//        extract( "s.b[u].k.z[i]=3; toto" );
//        extract( "bb=2; @GetField('titi'); @GetField(bb);");
//    }
//    private static void extract( String exp ) {
//        try {
//            TExpression expression = new TExpression();
//            expression.setExpr(exp);
//            TDiag.trace( "Symbols: {0}", expression.getGlobalSymbols() );
//        } catch( Exception e ) {
//            com.ibm.workplace.designer.util.TDiag.exception(e);
//        }
//    }

    /**
     * Check if a formula has an empty body.
     */
    public static boolean isEmptyFormula(String formula) {
        if(!StringUtil.isEmpty(formula)) {
            int pos1=0;
            int pos2=formula.length();
            int fctPos = formula.indexOf("function "); //$NON-NLS-1$
            if( fctPos>=0 ) {
                pos1=formula.indexOf('{')+1;
                pos2=formula.lastIndexOf('}');
            }
            if(pos1>=0&&pos2>pos1) {
                String body=formula.substring(pos1, pos2);
                int len=body.length();
                for(int i=0; i<len; i++) {
                    char c=body.charAt(i);
                    // Skip the comment
                    if(c=='/'&&i<len-1) {
                        if(body.charAt(i+1)=='/') {
                            for(i+=2; i<len; i++) {
                                if(body.charAt(i)=='\n'||body.charAt(i)=='\r') {
                                    break;
                                }
                            }
                        } else if(body.charAt(i+1)=='*') {
                        // TODO...
                        }
                    } else {
                        // If it is not a space, then it is not empty
                        if(c!=' '&&c!='\t'&&c!='\n'&&c!='\r') {
                            return false;
                        }
                    }
                }
                return true;
            }
            return false;
        }
        return true;
    }

    public boolean isEmptyExpression(String functionName) {
        return isEmptyNode(getMainNode(), functionName);
    }

    private static boolean isEmptyNode(ASTNode node, String functionName) {
        if(node==null) {
            return true;
        } else if(node instanceof ASTProgram) {
            ASTProgram prg= (ASTProgram)node;
            for(int i=0; i<prg.getSlotCount(); i++) {
                ASTNode n=prg.readSlotAt(i);
                if(!isEmptyNode(n, functionName)) {
                    return false;
                }
            }
            return true;
        } else if(node instanceof ASTBlock) {
            ASTBlock blk= (ASTBlock)node;
            for(int i=0; i<blk.getSlotCount(); i++) {
                ASTNode n=blk.readSlotAt(i);
                if(!isEmptyNode(n, functionName)) {
                    return false;
                }
            }
            return true;
        } else if(node instanceof ASTFunction) {
            ASTFunction fct= (ASTFunction)node;
            if(functionName!=null&&fct.getName().equals(functionName)) {
                return isEmptyNode(fct, null);
            }
            return true;
        }
        // If we check the body of a function, then ignore these node
        if(!StringUtil.isEmpty(functionName)) {
            return true;
        }
        // Else, the expression is not empty
        return false;
    }

// EMPTY NODE CHECKING
//    public static void main( String args[] ) {
//        checkEmpty("",null);
//        checkEmpty("// Comment",null);
//        checkEmpty("{\n// Comment\n}",null);
//        checkEmpty("{\n// Comment\n//true;\n}",null);
//        checkEmpty("a=10",null);
//        checkEmpty("true",null);
//    }
//    private static void checkEmpty(String exp, String fctName) {
//        try {
//            TExpression expression = new TExpression();
//            expression.setExpr(exp);
//            TDiag.trace( "{0}\nIS EMPTY={1}\n\n", exp, TString.toString(expression.isEmptyExpression(fctName)) );
//        } catch( Exception e ) {
//            com.ibm.workplace.designer.util.TDiag.exception(e);
//        }
//    }


    /*
     * Instance variables.
     */
    private String sourceReferenceID;
    private ExpressionData data;
    private FBSGlobalObject functionGlobalObject;
}
