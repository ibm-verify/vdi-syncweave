/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import java.util.List;
import java.util.Set;

import com.ibm.commons.util.QuickSort;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.*;


/**
 * This class allows to manipulate standard JavaScript Array objects.
 * @fbscript Array
 */
public class ArrayPrototype extends ArrayObject implements Prototype {

    public ArrayPrototype(JSContext jsContext){
        super(jsContext,jsContext.getRegistry().objectPrototype);
        int attrib=FBSObject.P_NOENUM;
        createConstructor(attrib,new ArrayConstructor(jsContext,this)); //$NON-NLS-1$
        createMethod("toString",attrib,new ArrayMethod(jsContext,0)); //$NON-NLS-1$
        createMethod("toLocaleString",attrib,new ArrayMethod(jsContext,1)); //$NON-NLS-1$
        createMethod("concat",attrib,new ArrayMethod(jsContext,2)); //$NON-NLS-1$
        createMethod("join",attrib,new ArrayMethod(jsContext,3)); //$NON-NLS-1$
        createMethod("pop",attrib,new ArrayMethod(jsContext,4)); //$NON-NLS-1$
        createMethod("push",attrib,new ArrayMethod(jsContext,5)); //$NON-NLS-1$
        createMethod("reverse",attrib,new ArrayMethod(jsContext,6)); //$NON-NLS-1$
        createMethod("shift",attrib,new ArrayMethod(jsContext,7)); //$NON-NLS-1$
        createMethod("slice",attrib,new ArrayMethod(jsContext,8)); //$NON-NLS-1$
        createMethod("sort",attrib,new ArrayMethod(jsContext,9)); //$NON-NLS-1$
        createMethod("splice",attrib,new ArrayMethod(jsContext,10)); //$NON-NLS-1$
        createMethod("unshift",attrib,new ArrayMethod(jsContext,11)); //$NON-NLS-1$
    }
    public boolean isArray() {
        return true;
    }
    public int getArrayLength() {
        return 0;
    }

    ////// Constructor
    static class ArrayConstructor extends BuiltinConstructor {
        public ArrayConstructor(JSContext jsContext, FBSDefaultObject prototype){
            super(jsContext,prototype,"Array"); // $NON-NLS-1$
        }
        public boolean hasInstance(FBSValue v){
            return v instanceof ArrayObject;
        }
        public FBSValue get(String name) throws InterpretException {
            return super.get(name);
        }
        protected String[] getConstructorParameters() {
            return new String[] {"()","(size:I)","(values:N)"}; //$NON-NLS-1$ //$NON-NLS-2$
        }
        public boolean supportConstruct(){
            return true;
        }
        public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
            return new ArrayObject(context.getJSContext(),args);
        }
        protected String[] getCallParameters() {
            return new String[] {"():A","(size:I):A","(values:N):A"}; //$NON-NLS-1$ //$NON-NLS-2$ $NON-NLS-3$
        }
        public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this) throws InterpretException {
            return new ArrayObject(context.getJSContext(),args);
        }
        
        public void getAllPropertiesForHelp(JSContext context, Set set){
            JSContext jsContext = getJSContext();
//            Descriptor.Method m0 = new Descriptor.Method("length","():I");
            Descriptor.Field f0 = new Descriptor.Field(jsContext,"length",FBSType.intType,false); //$NON-NLS-1$
            set.add(f0);
            
            super.getAllPropertiesForHelp(context, set);
//            Iterator it=getPropertyKeys();
//            if( it!=null ) {
//                while(it.hasNext() ) {
//                    String key = (String)it.next();
//                    try {
//                        FBSValue v=get(key);
//                        if(v instanceof ArrayMethod) {
//                            ArrayMethod f= (ArrayMethod)v;
//                            String[] args=f.getCallParameters();
//                            if(args!=null) {
//                                for(int i=0; i<args.length; i++) {
//                                    Descriptor.Method m=new Descriptor.Method(jsContext,key, args[i]);
//                                    set.add(m);
//                                }
//                            } else {
//                                Descriptor.Method m = new Descriptor.Method(jsContext,key,FBSType.undefinedType,null);
//                                set.add(m);
//                            }
//                        }
//                    } catch( InterpretException e ) {}
//                }
//            }
        }
    }


    static class ArrayMethod extends BuiltinFunction{
        int mIndex=-1;

        public ArrayMethod(JSContext jsContext, int index){
            super(jsContext);
            mIndex=index;
        }

        protected String[] getCallParameters() {
                switch(mIndex) {
                    case 0: // toString
                    case 1: // toLocaleString
                        return new String[] {"():T"}; //$NON-NLS-1$
                    case 2: // concat
                        return new String[] {"(objects:Ljava.lang.Object;):Lcom.ibm.jscript.std.ArrayObject;"}; //$NON-NLS-1$
                    case 3: // join
                        return new String[] {"(separator:C):T"}; //$NON-NLS-1$
                    case 4: // pop
                        return new String[] {"():Ljava.lang.Object;"}; //$NON-NLS-1$
                    case 5: // push
                        return new String[] {"(objects:Ljava.lang.Object;):I"}; //$NON-NLS-1$
                    case 6: // reverse
                        return new String[] {"():Lcom.ibm.jscript.std.ArrayObject;"}; //$NON-NLS-1$
                    case 7: // shift
                        return new String[] {"():Ljava.lang.Object;"}; //$NON-NLS-1$
                    case 8: // slice
                        return new String[] {"(start:Iend:I):Lcom.ibm.jscript.std.ArrayObject;"}; //$NON-NLS-1$
                    case 9: // sort
                        return new String[] {"(comparefn:Ljava.lang.Object;):Lcom.ibm.jscript.std.ArrayObject;"}; //$NON-NLS-1$
                    case 10: // splice
                        return new String[] {"(start:Ideletecount:I):Lcom.ibm.jscript.std.ArrayObject;"}; //$NON-NLS-1$
                    case 11: // unshift
                        return new String[] {"(objects:Ljava.lang.Object;):Lcom.ibm.jscript.std.ArrayObject;"}; //$NON-NLS-1$
                }
                return super.getCallParameters();
        }


        public FBSValue call(FBSValueVector args, FBSObject _this) throws InterpretException {
            return FBSUndefined.undefinedValue;
        }

        //Unlike other objects, here it is important to pass the context !!!
        //Because of a call back function in the sort() method, that function must execute
        // in the context.
        public FBSValue call(IExecutionContext context, FBSValueVector args, FBSObject _this) throws InterpretException {
            switch(mIndex){
                case 0:     // toString
                case 1: {     // toLocaleString
                    if(_this!=null && _this.isArray()) {
                        int l = _this.getArrayLength();
                        StringBuilder sb = new StringBuilder();
                        for(int i=0; i<l; i++){
                            FBSValue av = _this.getArrayValue(i);
                            if(!(av.isNull() || av.isUndefined())) {
                                sb.append(av.toFBSString().stringValue());
                            }
                            if (i<l-1){
                                sb.append(',');
                            }
                        }
                        String str = sb.toString();
                        return FBSString.get(str);
                    }
                    throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"This toString() function must be applied to an Array object, {0}",FBSUtility.getDisplayType(_this))); // $NLS-ArrayPrototype.ThistoStringfunctionmustbeapplied-1$
                }

                case 2:{     // concat
                    ArrayObject newArray = new ArrayObject(context.getJSContext());
                    int index=0;
                    if(_this!=null && _this.isArray()) {
                        int l = _this.getArrayLength();
                        for(int i=0; i<l; i++){
                            FBSValue tmpv = _this.getArrayValue(i);
                            newArray.put(index++,tmpv);
                        }
                    } else {
                        newArray.put(index++,_this);
                    }
                    int s = args.size();
                    for(int i=0; i<s; i++){
                        FBSValue tmpv = args.getFBSValue(i);
                        if (tmpv.isArray()){
                            int l = tmpv.getArrayLength();
                            for(int j=0; j<l; j++){
                                newArray.put(index++,tmpv.getArrayValue(j));
                            }
                        }else{
                            newArray.put(index++,tmpv);
                        }
                    }
                    return newArray;
                }
                case 3: {     // join
                    if(_this!=null && _this.isArray()) {
                        String sep = ","; //$NON-NLS-1$
                        if (args.size()>0){
                            FBSValue vsep = args.getFBSValue(0);
                            if(!vsep.isUndefined()) {
                                sep=vsep.stringValue();
                            }
                        }
                        int l = _this.getArrayLength();
                        StringBuilder sb = new StringBuilder();
                        for(int i=0; i<l; i++){
                            FBSValue av = _this.getArrayValue(i);
                            if(!(av.isNull() || av.isUndefined())) {
                                sb.append(av.toFBSString().stringValue());
                            }
                            if (i<l-1){
                                sb.append(sep);
                            }
                        }
                        String str = sb.toString();
                        return FBSString.get(str);
                    }
                    return FBSUndefined.undefinedValue;
                }
                    
                case 4: {     // pop
                    if(_this!=null && _this.isArray()) {
                        if(_this instanceof ArrayObject) {
                            ArrayObject array=(ArrayObject)_this;
                            int l = array.getArrayLength();
                            if (l<=0){
                                return FBSUndefined.undefinedValue;
                            }
                            FBSValue v = array.get(l-1);
                            array.setArrayLength(l-1);
                            return v;
                        }
                        if(_this instanceof JavaWrapperObject) {
                            Object jo = _this.toJavaObject();
                            if(jo instanceof List) {
                                List array=(List)jo;
                                int l = array.size();
                                if (l<=0){
                                    return FBSUndefined.undefinedValue;
                                }
                                FBSValue v = FBSUtility.wrap(getJSContext(),array.get(l-1));
                                array.remove(l-1);
                                return v;
                            }
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }
                
                case 5: {     // push
                    if(_this!=null && _this.isArray()) {
                        if(_this instanceof ArrayObject) {
                            ArrayObject array=(ArrayObject)_this;
                            int l = array.getArrayLength();
                            for(int i=0; i<args.size(); i++){
                                array.put(l+i,args.getFBSValue(i));
                            }
                            return FBSNumber.get(array.getArrayLength());
                        }
                        if(_this instanceof JavaWrapperObject) {
                            Object jo = _this.toJavaObject();
                            if(jo instanceof List) {
                                List array=(List)jo;
                                for(int i=0; i<args.size(); i++){
                                    array.add(args.getFBSValue(i).toJavaObject());
                                }
                                return FBSNumber.get(array.size());
                            }
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }
                
                case 6: {    // reverse
                    if(_this!=null && _this.isArray()) {
                        int l = _this.getArrayLength();
                        int m = (int)Math.floor(l/2);
                        for(int i=0; i<m; i++){
                            int i1 = l-i-1;
                            FBSValue v0 = _this.getArrayValue(i);
                            FBSValue v1 = _this.getArrayValue(i1);
                            _this.setArrayValue(i,v1);
                            _this.setArrayValue(i1,v0);
                        }
                        return this;
                    }
                    return FBSUndefined.undefinedValue;
                }
                case 7: {     // shift
                    if(_this!=null && _this.isArray()) {
                        if(_this instanceof ArrayObject) {
                            ArrayObject array=(ArrayObject)_this;
                            int L = array.getArrayLength();
                            if (L<=0){
                                return FBSUndefined.undefinedValue;
                            }
                            FBSValue v = array.get(0);
                            for(int i=1; i<L; i++){
                                FBSValue v0 = array.get(i);
                                array.put(i-1,v0);
                            }
                            array.setArrayLength(L-1); //$NON-NLS-1$
                            return v;
                        }
                        if(_this instanceof JavaWrapperObject) {
                            Object jo = _this.toJavaObject();
                            if(jo instanceof List) {
                                List array=(List)jo;
                                if(!array.isEmpty()) {
                                    Object o = array.get(0);
                                    array.remove(0);
                                    return FBSUtility.wrap(getJSContext(),o);
                                }
                            }
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }
                case 8:{     // slice
                    if(_this!=null && _this.isArray()) {
                        if (args.size()==0){
                            return FBSUndefined.undefinedValue;
                        }
                        if (args.size()==1){
                            args.add(FBSUndefined.undefinedValue);
                        }
                        int l = _this.getArrayLength();
                        int s = args.getFBSValue(0).intValue();
                        if (s<0){
                            s = Math.max(l+s,0);
                        }else{
                            s = Math.min(s,l);
                        }

                        int e;
                        if (args.getFBSValue(1)==FBSUndefined.undefinedValue){
                            e = l;
                        }else{
                            e = args.getFBSValue(1).intValue();
                        }

                        if (e<0){
                            e = Math.max(l+e,0);
                        }else{
                            e = Math.min(e,l);
                        }
                        ArrayObject newArray = new ArrayObject(getJSContext(),e-s);
                        for(int i=s; i<e; i++){
                            FBSValue v0 = _this.getArrayValue(i);
                            newArray.put(i-s,v0);
                        }
                        return newArray;
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 9: {     // sort
/*                        if (args.size()<1){
                            return array;
                        }*/
//                        if (args.getFBSValue(0) instanceof FBSObject){
                    if(_this!=null && _this.isArray()) {

                        FBSObject function = args.size()>0?(FBSObject)args.getFBSValue(0):null;

                        JavaScriptException ex = (new QuickSort(){
                            int size;
                            FBSObject function;
                            FBSValue array;
                            FBSValueVector args;
                            IExecutionContext context;
                            JavaScriptException exception;

                            public JavaScriptException sortArray(IExecutionContext context, FBSValue array, FBSObject function){
                                this.context = context;
                                this.array = array;
                                this.function = function;
                                if(function!=null){
                                    args = new FBSValueVector(2);
                                    args.add(FBSUndefined.undefinedValue);
                                    args.add(FBSUndefined.undefinedValue);
                                }
                                this.size = array.getArrayLength();
                                this.sort();
                                return exception;
                            }

                            public int getCount(){
                                return size;
                            }

                            public int compare(int idx1, int idx2){
                                if (exception!=null){
                                    return 0; // avoid problems if an exception occurred;
                                }
                                try{
                                    if(function!=null){
                                        args.set(0,array.getArrayValue(idx1));
                                        args.set(1,array.getArrayValue(idx2));
                                        FBSValue v = function.call(context,args,(FBSObject)array);
                                        return v.intValue();
                                    }else{
                                        String val1=array.getArrayValue(idx1).stringValue();
                                        String val2=array.getArrayValue(idx2).stringValue();
                                        return val1.compareTo(val2);
                                    }
                                }catch(JavaScriptException e){
                                    size = 0; // cancel the sort operation
                                    exception = e;
                                }
                                return 0;
                            }

                            public void exchange(int idx1, int idx2){
                                try{
                                    if (exception!=null){
                                        return ; // avoid problems if an exception occured;
                                    }
                                    FBSValue v = array.getArrayValue(idx1);
                                    array.setArrayValue(idx1,array.getArrayValue(idx2));
                                    array.setArrayValue(idx2,v);
                                }catch(JavaScriptException e){
                                    size = 0; // cancel the sort operation
                                    exception = e;
                                }
                            }
                        }).sortArray(context,_this,function);

                        if (ex!=null){
                            throw new InterpretException(ex,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Error while sorting Array")); // $NLS-ArrayPrototype.ErrorwhilesortingArray-1$
                        }
                        return _this;
                    }
                    return FBSUndefined.undefinedValue;
                }
                
                case 10:{    // splice
                    if(_this!=null && _this.isArray()) {
                        if (args.size()<2){
                            return FBSUndefined.undefinedValue;
                        }
                        int len = _this.getArrayLength();
                        int start = args.getFBSValue(0).intValue();
                        if(start<0) {
                            start = Math.max(len+start,0);
                        } else {
                            start = Math.min(start, len);
                        }
                        int delcnt = Math.min(Math.max(args.getFBSValue(1).intValue(),0),len-start);
                        int argCnt = args.size()-2;
                        ArrayObject newArray = new ArrayObject(getJSContext(),len-delcnt+argCnt);
                        int j=0;
                        for (int i=0; i<start; i++){
                            FBSValue v1 = _this.getArrayValue(i);
                            newArray.put(j++,v1);
                        }
                        for (int i=0; i<argCnt; i++){
                            FBSValue v1 = args.getFBSValue(i+2);
                            newArray.put(j++,v1);
                        }
                        for (int i=start+delcnt; i<len; i++){
                            FBSValue v1 = _this.getArrayValue(i);
                            newArray.put(j++,v1);
                        }
//                            newArray.put("length",FBSNumber.get(l-cnt+argCnt));
                        return newArray;
                    }
                }
                return FBSUndefined.undefinedValue;

                case 11:{    // unshift
                    if(_this!=null && _this.isArray()) {
                        if(_this instanceof ArrayObject) {
                            ArrayObject array=(ArrayObject)_this;
                            int l = array.getArrayLength();
                            int s = args.size();
                            if (s==0){
                                return _this;
                            }

                            for (int i=l-1; i>=0; i--){
                                FBSValue v1 = array.get(i);
                                array.delete(String.valueOf(i));
                                array.put(i+s,v1);
                            }

                            for( int j=0; j<s; j++){
                                array.put(j,args.getFBSValue(j));
                            }

                            array.setArrayLength(s+l); //$NON-NLS-1$
                            return _this;
                        }
                        if(_this instanceof JavaWrapperObject) {
                            Object jo = _this.toJavaObject();
                            if(jo instanceof List) {
                                List array=(List)jo;
                                for (int i=args.size()-1; i>=0; i--){
                                    FBSValue v1 = args.get(i);
                                    array.add(0,v1.toJavaObject());
                                }
                                return _this;
                            }
                        }
                    }
                }
                return FBSUndefined.undefinedValue;
            }
            throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Function of Array not found")); //$NLS-ArrayPrototype.ArrayPrototype.ArrayFunctionNotFound.Exception-1$
        }
    }

    public String getName(){
        return "Array"; //$NON-NLS-1$
    }

//------------------------------------------------------------------------------
// dummy methods for help
    public static class Array{}

    /**
    * @fbscript
    */
    public String toString(){return null;}

    /**
    * @fbscript
    */
    public String toLocaleString(){return null;}
    /**
    * @return an array containing the array elements of the object followed by the array elements of each argument in order.
    * @fbscript
    */
    public Array concat(){return null;}

    /**
    * The elements of the array are converted to strings, and these strings are then concatenated,
    *  separated by occurrences of the separator.
    *  If no separator is provided, a single comma is used as the separator.
    *  @param separator to be used between 2 elemets.
    *  @return a string resulting form the concatenation of all elements
    *  @fbscript
    */
    public String join(char separator){return null;}

    /**
    * The last element of the array is removed from the array and returned.
    * @return the last element of the array
    * @fbscript
    */
    public Object pop(){return null;}

    /**
    * Appends the arguments to the end of the array, in the order in which they appear.
    * The new length of the array is returned as the result of the call.
    * @return the new length o fthe array
    * @fbscript
    */
    public int push(){return 0;}

    /**
    * The elements of the array are rearranged so as to reverse their order.
    * @return the array itself.
    * @fbscript
    */
    public Array reverse(){return null;}

    /**
    * The first element of the array is removed from the array and returned.
    * @return the first element of the array
    * @fbscript
    */
    public Object shift(){return null;}

    /**
    * Extracts a subarray from this array.
    * The slice method takes two arguments, start and end, and returns
    * an array containing the elements of the array from element start up to,
    * but not including, element end (or through the end of the array if end is undefined).
    * If start is negative, it is treated as (length+start) where length is the length of the array.
    * If end is negative, it is treated as (length+end) where length is the length of the array.
    * @return array
    * @fbscript
    */
    public Array slice(int start, int end){return null;}

    /**
    * The elements of this array are sorted.
    * The sort is not necessarily stable (that is, elements that compare equal do not necessarily remain in their original order).
    * If comparefn is not undefined, it should be a function that accepts two arguments x and y and returns a negative value if x < y, zero if x = y, or a positive value if x > y.
    * @fbscript
    */
    public Array sort(Object comparefn){return null;}

    /**
     * When the splice method is called with two or more arguments start, deleteCount and (optionally) item1, item2,
     * etc., the deleteCount elements of the array starting at array index start are replaced by the arguments item1, item2,
     * etc.
     * @fbscript
     */
    public Array splice(int start, int deletcount){return null;}

    /**
     * The arguments are prepended to the start of the array, such that their order
     * within the array is the same as the order in which they appear in the argument list.
     * @fbscript
     */
    public Array unshift(){return null;}

}