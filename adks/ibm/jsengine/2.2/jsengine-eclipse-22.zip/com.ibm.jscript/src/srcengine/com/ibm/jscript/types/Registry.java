/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.ibm.commons.util.QuickSort;
import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.std.ArrayPrototype;
import com.ibm.jscript.std.BooleanPrototype;
import com.ibm.jscript.std.DatePrototype;
import com.ibm.jscript.std.ErrorPrototype;
import com.ibm.jscript.std.FunctionPrototype;
import com.ibm.jscript.std.JavaObjectPrototype;
import com.ibm.jscript.std.MathObject;
import com.ibm.jscript.std.NumberPrototype;
import com.ibm.jscript.std.ObjectObject;
import com.ibm.jscript.std.ObjectPrototype;
import com.ibm.jscript.std.RegExpPrototype;
import com.ibm.jscript.std.StringPrototype;
import com.ibm.jscript.types.GeneratedWrapperObject.MethodMap;

public final class Registry {

    private IdentityHashMap<Class<?>,IWrapperFactory> wrapperMap;
    private RegistryObject regObject;
    private ArrayList<PrototypeItem> prototypes;
    private ArrayList<Package> packages;

    // Tag this class for the profiler...
    public static class RegistryObject extends ObjectObject {
    	private RegistryObject(JSContext context) {
    		super(context);
    	}
    }
	
    // Public & standard prototypes
    public ArrayPrototype arrayPrototype;
    public BooleanPrototype booleanPrototype;
    public DatePrototype datePrototype;
    public NumberPrototype numberPrototype;
    public ObjectPrototype objectPrototype;
    public RegExpPrototype regExpPrototype;
    public StringPrototype stringPrototype;
    public FunctionPrototype functionPrototype;
    public ErrorPrototype errorPrototype;
    public ErrorPrototype evalErrorPrototype;
    public ErrorPrototype rangeErrorPrototype;
    public ErrorPrototype referenceErrorPrototype;
    public ErrorPrototype syntaxErrorPrototype;
    public ErrorPrototype typeErrorPrototype;
    public ErrorPrototype uriErrorPrototype;
    public FBSDefaultObject globalObjectPrototype;
    public JavaObjectPrototype javaObjectPrototype;

    public Registry() {
    }
    public void init(JSContext jsContext) {        
        // Create the prototypes
        this.objectPrototype = new ObjectPrototype(jsContext);
        this.arrayPrototype = new ArrayPrototype(jsContext);
        this.booleanPrototype = new BooleanPrototype(jsContext);
        this.datePrototype = new DatePrototype(jsContext);
        this.numberPrototype = new NumberPrototype(jsContext);
        this.regExpPrototype = new RegExpPrototype(jsContext);
        this.stringPrototype = new StringPrototype(jsContext);
        this.functionPrototype = new FunctionPrototype(jsContext);
        this.errorPrototype = new ErrorPrototype(jsContext);
        this.evalErrorPrototype = new ErrorPrototype.EvalErrorPrototype(jsContext);
        this.rangeErrorPrototype = new ErrorPrototype.RangeErrorPrototype(jsContext);
        this.referenceErrorPrototype = new ErrorPrototype.ReferenceErrorPrototype(jsContext);
        this.syntaxErrorPrototype = new ErrorPrototype.SyntaxErrorPrototype(jsContext);
        this.typeErrorPrototype = new ErrorPrototype.TypeErrorPrototype(jsContext);
        this.uriErrorPrototype = new ErrorPrototype.URIErrorPrototype(jsContext);
        this.globalObjectPrototype = new FBSGlobalObject.FBPrototype(jsContext);
        this.javaObjectPrototype = new JavaObjectPrototype(jsContext);

        // Initialize the global object
        this.wrapperMap=new IdentityHashMap<Class<?>,IWrapperFactory>();
        this.regObject= new RegistryObject(jsContext);
        this.prototypes = new ArrayList<PrototypeItem>();
        this.packages = new ArrayList<Package>();
        
        // Register the std java classes
        int pckgID = (3<<20);// 3 is the number of the standard package
        //int attrib = FBSObject.P_READONLY + pckgID;
        registerPackage("Standard",pckgID); // $NON-NLS-1$

        // Standard classes
        registerStandard(objectPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(functionPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(arrayPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(stringPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(booleanPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(numberPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(datePrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(regExpPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(errorPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(evalErrorPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(rangeErrorPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(referenceErrorPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(syntaxErrorPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(typeErrorPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard(uriErrorPrototype.getConstructor()); // $NON-NLS-1$
        registerStandard("Math",new MathObject(jsContext)); // $NON-NLS-1$

//        // Register the java array wrapper classes
//        registerWrapper(byte[].class,new ArrayWrapper(0));
//        registerWrapper(short[].class,new ArrayWrapper(1));
//        registerWrapper(int[].class,new ArrayWrapper(2));
//        registerWrapper(long[].class,new ArrayWrapper(3));
//        registerWrapper(float[].class,new ArrayWrapper(4));
//        registerWrapper(double[].class,new ArrayWrapper(5));
//        registerWrapper(boolean[].class,new ArrayWrapper(6));
//        registerWrapper(char[].class,new ArrayWrapper(7));
//        registerWrapper(Object[].class,new ArrayWrapper(8));
        
        if( jsContext.hasRhinoExtensions() ) {
            int attrib2=FBSObject.P_NODELETE|FBSObject.P_READONLY;
            regObject.createProperty(JavaPackageObject.PACKAGES,attrib2,JavaPackageObject.getPackage(jsContext,null,true));
        }
    }
    
//    private class ArrayWrapper implements IWrapperFactory {
//      private int idx;
//      ArrayWrapper(int idx) {
//          this.idx = idx;
//      }
//      public JavaWrapperObject wrap(JSContext jsContext, Object o) {
//          switch(idx) {
//              case 0:     return new ByteArrayWrapper(jsContext,(byte[])o);
//              case 1:     return new ShortArrayWrapper(jsContext,(short[])o);
//              case 2:     return new IntArrayWrapper(jsContext,(int[])o);
//              case 3:     return new LongArrayWrapper(jsContext,(long[])o);
//              case 4:     return new FloatArrayWrapper(jsContext,(float[])o);
//              case 5:     return new DoubleArrayWrapper(jsContext,(double[])o);
//              case 6:     return new BooleanArrayWrapper(jsContext,(boolean[])o);
//              case 7:     return new CharArrayWrapper(jsContext,(char[])o);
//              case 8:     return new ObjectArrayWrapper(jsContext,(Object[])o);
//          }
//          throw new IllegalStateException("Unknown wrapper");
//      }
//    }

    
    // ------------------------------------------------------------------------
    // Global Object registry
    // All the properties of these prototypes are available directly
    // ------------------------------------------------------------------------


    public void registerStandard(FBSValue v){
    	registerStandard(null,v);
    }
    public void registerStandard(String name ,FBSValue v){
        synchronized(regObject) {
            try {
            	if(name==null && (v instanceof BuiltinConstructor)) {
            		name = ((BuiltinConstructor)v).getGlobalName();
            	}
                int pckgID = (3<<20);// 3 is the number of the standard package
                int attrib = FBSObject.P_READONLY + pckgID;
                regObject.createProperty(name,attrib,v);
            } catch( Exception e ) {}
        }
    }

    public FBSDefaultObject getRegistryObject(){
        return regObject;
    }


    
    // ------------------------------------------------------------------------
    // Global prototypes
    // All the properties of these prototypes are available directly
    // ------------------------------------------------------------------------

    private static class PrototypeItem {
        String name;
        FBSObject object;
        PrototypeItem(String name, FBSObject object) {
            this.name = name;
            this.object = object;
        }
    }
    public void registerGlobalPrototype(String name, FBSObject object){
        synchronized(prototypes) {
            try {
                prototypes.add(new PrototypeItem(name,object));
            } catch( Exception e ) {}
        }
    }
    
    public int getGlobalPrototypeCount() {
        return prototypes.size();
    }
    
    public String getGlobalPrototypeName( int index ) {
        return ((PrototypeItem)prototypes.get(index)).name;
    }
    
    public FBSObject getGlobalPrototype( int index ) {
        return ((PrototypeItem)prototypes.get(index)).object;
    }


    // ------------------------------------------------------------------------
    // Java wrapper registry
    // ------------------------------------------------------------------------

    private static IWrapperFactory NOWRAPPER = new IWrapperFactory() {
		public MethodMap getMethodMap(JSContext jsContext) {
			return null;
		}
		public GeneratedWrapperObject wrap(JSContext jsContext, Object o) {
			return null;
		}
    };
    
    public void registerWrapper(Class<?> javaClass,IWrapperFactory factory){
        synchronized(this) {
            wrapperMap.put(javaClass,factory);
        }
    }

    public IWrapperFactory searchWrapper(JSContext context, Class<?> c){
        // Fast look to this particular class
        IWrapperFactory cwrapper=wrapperMap.get(c);
        if(cwrapper!=null) {
        	if(cwrapper==NOWRAPPER) {
        	    return null;
        	}
            return (IWrapperFactory)cwrapper;
        }
        synchronized (this) {
        	return _searchWrapper(context, c);
        }
    }
    private IWrapperFactory _searchWrapper(JSContext context, Class<?> c){
        // Ensure that another thread not already added it
        IWrapperFactory cwrapper=wrapperMap.get(c);
        if(cwrapper!=null) {
        	if(cwrapper==NOWRAPPER) {
        	    return null;
        	}
            return (IWrapperFactory)cwrapper;
        }
        
        // Look a super class that has a direct parent wrapped statically
        // This applies, for example, to the XspContext class, as we are
        // in fact using one of its descendant (ServletXspContext) 
        for( Class<?> sc=c.getSuperclass(); sc!=null && sc!=Object.class; ) {
            IWrapperFactory o=wrapperMap.get(sc);
            if(o!=null) {
            	if(o==NOWRAPPER) {
            		return null;
            	}
            	IWrapperFactory wrapper = (IWrapperFactory)o;
            	if(!(wrapper instanceof InterfacesWrapperObject.WrapperFactory) ) {
            		wrapperMap.put(c,wrapper);
            		return wrapper;
            	}
            }
            sc = sc.getSuperclass();
        }
        
        // Then we create a dynamic wrapper if this class inherits from a generated interface
        // Find the list of the high level interfaces implemented by this object
	    ArrayList<Class<?>> ifc = null;
loop:   for( Iterator<Map.Entry<Class<?>, IWrapperFactory>> it=wrapperMap.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<Class<?>, IWrapperFactory> entry = it.next();
			
			// Ignore the empty wrapper and the dynamic interfaces
        	IWrapperFactory w = entry.getValue();
        	if(w==NOWRAPPER || (w instanceof InterfacesWrapperObject.WrapperFactory) ) {
        		continue;
        	}
            Class<?> wrapped = entry.getKey();
            if(wrapped.isInterface()) {
                if(wrapped.isAssignableFrom(c)) {
                	if(ifc!=null) {
                		for(int i=0; i<ifc.size(); i++) {
                			Class<?> cc = ifc.get(i);
                			// If this class is a super class of an existing, registered one
                			// then use the super class instead (like XML Node & Element)
                            if( cc.isAssignableFrom(wrapped) ) {
                            	ifc.set(i, wrapped);
                            	continue loop;
                            }
                            // If a super class is already assigned, we don't need to assign
                            // the current one
                            if( wrapped.isAssignableFrom(cc) ) {
                            	continue loop;
                            }
                		}
                	} else {
                		ifc = new ArrayList<Class<?>>();
                	}
                	// Ok, this class should be used for this object
                	ifc.add(wrapped);
                }
            }
        }
        if(ifc!=null) {
        	Class<?>[] cc = (Class<?>[])ifc.toArray(new Class[ifc.size()]);
        	GeneratedWrapperObject.MethodMap map = new GeneratedWrapperObject.MethodMap(context,c,cc);
        	IWrapperFactory fac = new InterfacesWrapperObject.WrapperFactory(map);
            wrapperMap.put(c,fac);
            return fac;
        	
        }
	        
        // Else, no wrapper exist for this class
        wrapperMap.put(c,NOWRAPPER);

        return null;
    }
    
    public IWrapperFactory getWrapper(String javaClass){
        for( Iterator<Map.Entry<Class<?>,IWrapperFactory>> it=wrapperMap.entrySet().iterator(); it.hasNext(); ) {
        	Map.Entry<Class<?>,IWrapperFactory> entry = it.next();
            Class<?> wrapped = entry.getKey();
            if(javaClass.equals(wrapped.getName())) {
            	Object o = entry.getValue();
            	if(o==NOWRAPPER) {
            		return null;
            	}
                return (IWrapperFactory)entry.getValue();
            }
        }
        //TDiag.trace( "Found wrapper '{0}' for {1}", (Class)map.get(javaClass), javaClass );
        return null;
    }

    public IWrapperFactory getWrapper(Class<?> javaClass){
        IWrapperFactory o = wrapperMap.get(javaClass);
    	if(o==NOWRAPPER) {
    		o = null;
    	}
        //TDiag.trace( "Found wrapper '{0}' for {1}", (Class)map.get(javaClass), javaClass );
        return (IWrapperFactory)o;
    }

    public Class<?> getClassForAlias(String alias) throws InterpretException {
        if (!StringUtil.isSpace(alias)) {
            FBSValue v = getRegistryObject().get(alias);
            if (v instanceof GeneratedWrapperObject.Constructor) {
                return ((GeneratedWrapperObject.Constructor)v).getWrappedClass();
            }
        }
        return null;
    }

    public void clear(){
    	synchronized(this) {
            wrapperMap.clear();
		}
    }


    // ======================================================================================
    // User help support (inspector)
    // ======================================================================================

    public void registerPackage( String packName, int packageID ) {
        for (int i=0;i<packages.size();i++){
            Package p = (Package)packages.get(i);
            if (p.getID()==packageID){
                p.setName(packName);
                return;
            }
        }
        packages.add(new Package(packName,packageID));
    }

    public Package getPackage(int packageID ) {
        for(int i=0;i<packages.size();i++){
            Package pkg=(Package)packages.get(i);
            if (pkg.id==packageID){
                return pkg;
            }
        }
        return null;
    }

    public static class Package {
        String name;
        int id;
        public Package( String name, int id ) {
            this.name = name;
            this.id = id&0xFFFF0000;
        }
        public String getName() {
            return name;
        }
        public void setName(String name){
            this.name = name;
        }
        public int getID(){
            return id;
        }
        public boolean isAdvanced() {
            return false;
        }
    }

    public static class JSClass {
        protected String name;
        protected FBSObject object;
        
        public JSClass( String name, FBSObject object ) {
            this.name = name;
            this.object = object;
        }
        
        public String getName() {
            return name;
        }
        
        public FBSObject getObject() {
            return object;
        }
    }


    public Package[] getRegisteredPackages() {
        Package[] array = (Package[])packages.toArray(new Package[packages.size()]);
        new QuickSort.ObjectArray(array) {
            public int compare(Object o1, Object o2) {
                Package p1 = (Package)o1;
                Package p2 = (Package)o2;
                return compareString(p1.getName(),p2.getName());
            }
        }.sort();
        return array;
    }

    public Package getPackageForObject(FBSObject o) {
        if( o!=null ) {
            // Browse the registry object and get the classes with the desired id
            for( Iterator<FBSDefaultObject.JSProperty> it=regObject.getPropertyIterator(); it.hasNext(); ) {
                FBSDefaultObject.JSProperty p=it.next();
                if( p.getValue()==o ) {
                    int id = p.getAttributes()&0xFFFF0000;
                    // Find the package with the ID
                    for( int i=0; i<packages.size(); i++ ) {
                        Package pack = (Package)packages.get(i);
                        if( pack.id==id ) {
                            return pack;
                        }
                    }
                    return null;
                }
            }
        }
        return null;
    }

    public FBSObject getGlobalObject(String objectName) {
        FBSDefaultObject.JSProperty p=regObject.getPropertyByName(objectName);
        if(p!=null) {
            FBSValue v = (FBSValue)p.getValue();
            if( v instanceof FBSObject ) {
                return (FBSObject)v;
            }
        }
        return null;
    }

    public JSClass[] getRegisteredClasses(Package pack) {
        try {
            if(pack!=null) {
                int id=pack.id;
                // Browse the registry object and get the classes with the desired if
                ArrayList<JSClass> list = new ArrayList<JSClass>();
                for( Iterator<FBSDefaultObject.JSProperty> it=regObject.getPropertyIterator(); it.hasNext(); ) {
                    FBSDefaultObject.JSProperty p=it.next();
                    if( (p.getAttributes()&0xFFFF0000)==id) {
                        JSClass d = new JSClass(p.getPropertyName(),(FBSObject)regObject.get(p.getPropertyName()));
                        list.add(d);
                    }
                }
                JSClass[] classes = (JSClass[])list.toArray(new JSClass[list.size()]);
                new QuickSort.ObjectArray(classes) {
                    public int compare(Object o1, Object o2) {
                        JSClass c1 = (JSClass)o1;
                        JSClass c2 = (JSClass)o2;
                        return compareString(c1.getName(),c2.getName());
                    }
                }.sort();
                return classes;
            }
        } catch( Exception e ) {}
        return null;
    }

    public static Descriptor.Member[] getMethods(JSContext jsContext, FBSObject o) {
        // Get all the descriptors
        Set<Descriptor.Member> set = new HashSet<Descriptor.Member>();
        o.getAllPropertiesForHelp(jsContext, set);
        if (set.size()==0){
            if (o instanceof GeneratedWrapperObject){
                GeneratedWrapperObject gwo=(GeneratedWrapperObject)o;
                //fillAllPropertiesForHelp(set,gwo.getMethodMap());
                gwo.getAllPropertiesForHelp(jsContext, set);
            }
        }

        // Convert it to a sorted array
        Descriptor.Member[] members = (Descriptor.Member[])set.toArray(new Descriptor.Member[set.size()]);
        new QuickSort.ObjectArray(members) {
            public int compare(Object o1, Object o2) {
                Descriptor.Member m1 = (Descriptor.Member)o1;
                Descriptor.Member m2 = (Descriptor.Member)o2;
                int r = m1.getMemberType() - m2.getMemberType();
                if( r!=0 ) {
                    return r;
                }
                if( m1.isStatic()!=m2.isStatic() ) {
                    return m1.isStatic() ? 1 : -1;
                }
                return compareString(m1.getName(),m2.getName());
            }
        }.sort();
        return members;
    }
    
    public static int compareString(String s1, String s2) {
        // Take care of the "Notes" extension with @Functions
        int len1=s1.length();
        int len2=s2.length();
        for (int i1=0, i2=0; i1<len1 && i2<len2; i1++, i2++) {
            char c1 = s1.charAt(i1);
            char c2 = s2.charAt(i2);
            if (c1 != c2) {
                if(c1=='@' && c2!='@') return 1;
                if(c1!='@' && c2=='@') return -1;
                c1 = Character.toLowerCase(c1);
                c2 = Character.toLowerCase(c2);
                if (c1 != c2) {
                    return c1 - c2;
                }
            }
        }
        return len1 - len2;
    }
}
