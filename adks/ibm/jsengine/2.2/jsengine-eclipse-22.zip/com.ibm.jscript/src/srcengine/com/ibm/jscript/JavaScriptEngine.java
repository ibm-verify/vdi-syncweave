/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript;

import com.ibm.jscript.parser.ParseException;
import com.ibm.jscript.std.ArrayObject;
import com.ibm.jscript.std.ObjectObject;
import com.ibm.jscript.types.FBSBoolean;
import com.ibm.jscript.types.FBSNull;
import com.ibm.jscript.types.FBSNumber;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSUtility;

/**
 * JavaScript engine utilities.</p>
 *
 * This class contains a set of public utilities used to access javascript
 * features from Java.<br>
 *
 * JavaScript value are handled as IValue objects. This means that each value
 * passed to the engine must be an IValue, and each result returned by the
 * engine will also be an IValue. IValue classes cannot be implemented by custom
 * code but instances can be create using the set of <code>wrap()</code> methods
 * available in this class.
 *
 * Here is an example of code for executing a sample code and passing global
 * variables (a & b) to it:<br>
 * <pre><code>
 *   try {
 *       // Compile the JS formula
 *       IFormula fmt = JavaScriptEngine.compile("1+3+a+b");
 *
 *       // Create the global object which holds all the variables as properties
 *       IValue global = JavaScriptEngine.newObject();
 *       global.putProperty("a",JavaScriptEngine.wrap(1));
 *       global.putProperty("b",JavaScriptEngine.wrap(5));
 *
 *       // Evaluate the result
 *       IValue result = fmt.evaluateValue(global);
 *       System.out.println(result.stringValue());
 *   } catch( Exception e ) {
 *       // Maybe ParserException or InterpretException
 *       e.printStackTrace();
 *   }
 * </code></pre>
 *
 */
public class JavaScriptEngine {

	private JSContext jsContext;
	
	public JavaScriptEngine(JSContext jsContext) {
		this.jsContext = jsContext;
	}
    
    public JSContext getJSContext() {
        return jsContext;
    }
	
    // =======================================================================
    // Some statically allocated IValues
    // =======================================================================

    /**
     * Javascript 'null' Object.</p>
     */
    public static IValue NULL = FBSNull.nullValue;

    /**
     * Javascript 'undefined' Object.</p>
     */
    public static IValue UNDEFINED = FBSUndefined.undefinedValue;

    /**
     * Javascript boolean 'true'.</p>
     * This variable is equivalent to JavaScript.wrap(true)
     */
    public static IValue TRUE = FBSBoolean.TRUE;

    /**
     * Javascript boolean 'false'.</p>
     * This variable is equivalent to JavaScript.wrap(false)
     */
    public static IValue FALSE = FBSBoolean.FALSE;

    /**
     * Javascript number '0'.</p>
     * This variable is equivalent to JavaScript.wrap(0)
     */
    public static IValue ZERO = FBSNumber.Zero;

    /**
     * Javascript number 'NaN'.</p>
     * This variable is equivalent to JavaScript.wrap(Double.NaN)
     */
    public static IValue NaN = FBSNumber.NaN;


    // =======================================================================
    // Basic java primitive type wrappers
    // =======================================================================

    /**
     * Wrap a java character to a JavaScript string.</p>
     * @param c the character to warp
     * @return the wrapped character
     */
    public IValue wrap(char c){
        return FBSUtility.wrap(c);
    }

    /**
     * Wrap a java byte to a JavaScript number.</p>
     * @param b the byte to warp
     * @return the wrapped byte
     */
    public IValue wrap(byte b){
        return FBSUtility.wrap(b);
    }

    /**
     * Wrap a java short integer to a JavaScript number.</p>
     * @param b the short to warp
     * @return the wrapped short
     */
    public IValue wrap(short s){
        return FBSUtility.wrap(s);
    }

    /**
     * Wrap a java integer to a JavaScript number.</p>
     * @param b the int to warp
     * @return the wrapped int
     */
    public IValue wrap(int i){
        return FBSUtility.wrap(i);
    }

    /**
     * Wrap a java long integer to a JavaScript number.</p>
     * @param b the long to warp
     * @return the wrapped long
     */
    public IValue wrap(long l){
        return FBSUtility.wrap(l);
    }

    /**
     * Wrap a java float to a JavaScript number.</p>
     * @param b the float to warp
     * @return the wrapped float
     */
    public IValue wrap(float f){
        return FBSUtility.wrap(f);
    }

    /**
     * Wrap a java double to a JavaScript number.</p>
     * @param b the double to warp
     * @return the wrapped double
     */
    public IValue wrap(double d){
        return FBSUtility.wrap(d);
    }

    /**
     * Wrap a java boolean to a JavaScript boolean.</p>
     * @param b the boolean to warp
     * @return the wrapped boolean
     */
    public IValue wrap(boolean b){
        return FBSUtility.wrap(b);
    }


    // =======================================================================
    // Basic java primitive array wrappers
    // =======================================================================

    /**
     * Wrap a java boolean array.</p>
     * The java array is not converted to a javascript array, but simply wrapped.<br>
     * Thus, changing a IValue will change the underlying array.<br>
     * @param array the array to warp
     * @return the wrapped array
     */
    public IValue wrap(boolean[] array){
        return FBSUtility.wrap(jsContext,array);
    }

    /**
     * Wrap a java char array.</p>
     * The java array is not converted to a javascript array, but simply wrapped.<br>
     * Thus, changing a IValue will change the underlying array.<br>
     * @param array the array to warp
     * @return the wrapped array
     */
    public IValue wrap(char[] array){
        return FBSUtility.wrap(jsContext,array);
    }

    /**
     * Wrap a java byte array.</p>
     * The java array is not converted to a javascript array, but simply wrapped.<br>
     * Thus, changing a IValue will change the underlying array.<br>
     * @param array the array to warp
     * @return the wrapped array
     */
    public IValue wrap(byte[] array){
        return FBSUtility.wrap(jsContext,array);
    }

    /**
     * Wrap a java short array.</p>
     * The java array is not converted to a javascript array, but simply wrapped.<br>
     * Thus, changing a IValue will change the underlying array.<br>
     * @param array the array to warp
     * @return the wrapped array
     */
    public IValue wrap(short[] array){
        return FBSUtility.wrap(jsContext,array);
    }

    /**
     * Wrap a java int array.</p>
     * The java array is not converted to a javascript array, but simply wrapped.<br>
     * Thus, changing a IValue will change the underlying array.<br>
     * @param array the array to warp
     * @return the wrapped array
     */
    public IValue wrap(int[] array){
        return FBSUtility.wrap(jsContext,array);
    }

    /**
     * Wrap a java long array.</p>
     * The java array is not converted to a javascript array, but simply wrapped.<br>
     * Thus, changing a IValue will change the underlying array.<br>
     * @param array the array to warp
     * @return the wrapped array
     */
    public IValue wrap(long[] array){
        return FBSUtility.wrap(jsContext,array);
    }

    /**
     * Wrap a java float array.</p>
     * The java array is not converted to a javascript array, but simply wrapped.<br>
     * Thus, changing a IValue will change the underlying array.<br>
     * @param array the array to warp
     * @return the wrapped array
     */
    public IValue wrap(float[] array){
        return FBSUtility.wrap(jsContext,array);
    }

    /**
     * Wrap a java double array.</p>
     * The java array is not converted to a javascript array, but simply wrapped.<br>
     * Thus, changing a IValue will change the underlying array.<br>
     * @param array the array to warp
     * @return the wrapped array
     */
    public IValue wrap(double[] array){
        return FBSUtility.wrap(jsContext,array);
    }

    /**
     * Wrap a java Object array.</p>
     * The java array is not converted to a javascript array, but simply wrapped.<br>
     * Thus, changing a IValue will change the underlying array.<br>
     * @param array the array to warp
     * @return the wrapped array
     */
    public IValue wrap(Object[] array){
        return FBSUtility.wrap(jsContext,array);
    }


    // =======================================================================
    // Javascript primitive wrappers
    // =======================================================================

    /**
     * Wrap a java String to a javascript string.</p>
     * @param s the String to warp
     * @return the wrapped string
     */
    public IValue wrap(String s){
        return FBSUtility.wrap(s);
    }

    /**
     * Wrap a java Date to a javascript Date.</p>
     * @param b the date to warp
     * @return the wrapped date
     */
    public IValue wrap(java.util.Date IValue){
        return FBSUtility.wrap(jsContext,IValue);
    }



    // =======================================================================
    // Javascript Object
    // =======================================================================

    /**
     * Create a Javascript object.</p>
     * A JavaScript Object is equivalent, in JavaScript, to <code>new Object</code>.
     * It can have dynamic properties, accessed with <code>getProperty()</code> &
     * <code>setProperty()</code>.
     * @return the JavaScript object
     */
    public IValue newObject() {
        return new ObjectObject(jsContext);
    }


    // =======================================================================
    // Javascript Array
    // =======================================================================

    /**
     * Create a Javascript array without any initial values.</p>
     * This method is equivalent to the JavaScript statement <code>new Array()</code>.
     * @return the JavaScript array
     */
    public IValue newArray() throws InterpretException {
        return new ArrayObject(jsContext);
    }

    /**
     * Create a Javascript array with an initial set of values set to 'undefined'.</p>
     * This method is equivalent to the JavaScript statement <code>new Array(length)</code>.
     * @return the JavaScript array
     */
    public IValue newArray(int length) throws InterpretException {
        return new ArrayObject(jsContext,length);
    }


    // =======================================================================
    // IValue wrappers
    // =======================================================================

    /**
     * Wrap a java Object to a JavaScript IValue.</p>
     * The Java Object is wrapped differently depending on its type:<br>
     * <ul>
     *   <li>null: wrapped to JavaScript null IValue
     *   <li>java.lang.String: wrapped to a JavaScript string
     *   <li>java.lang.Number: wrapped to a JavaScript number if corresponding to
     *           a primitive type (Integer, Short, Double...), and wrap as object
     *           the other type (BigDecimal, BigInteger...)
     *   <li>java.util.Date: wrapped to a JavaScript date
     *   <li>Any Java Array: wrapped to the correct java array type
     *   <li>Any other Object: wrap the object for access using either reflexion or FlowBuilder optimized access
     *   <li>IValue: no wrapping done, simply return the IValue as is
     * </ul>
     * @param o the Object to warp
     * @return the wrapped object
     */
    public IValue wrap(Object o) throws InterpretException {
        return FBSUtility.wrap(jsContext,o);
    }


    // =======================================================================
    // Javascript execution
    // =======================================================================

    /**
     * Compile a JavaScript expression from a string.</p>
     * The IFormula object can then be used to actually evaluate the formula
     * result.<br>
     * @param expr the javascript to parse
     * @throws ParseException if the javascript contains erros
     * @return the compiled expression
     */
    public IFormula compile( String expr ) throws ParseException {
        return jsContext.createExpression(expr);
    }

    /**
     * Compile a JavaScript expression from a string.</p>
     * The IFormula object can then be used to actually evaluate the formula
     * result.<br>
     * @param expr the javascript to parse
     * @param sourceReferenceID the source referenceID, for debug purposes
     * @throws ParseException if the javascript contains erros
     * @return the compiled expression
     */
    public IFormula compile( String expr, String sourceReferenceID ) throws ParseException {
        return jsContext.createExpression(expr,sourceReferenceID);
    }

    /**
     * Get a Javascript expression from the global cache.</p>
     * If the cache does not already contains this expression, then it compiles
     * it and add it to the cache.<br>
     * The IFormula object can then be used to actually evaluate the formula
     * result.<br>
     * @param expr the javascript to parse
     * @throws ParseException if the javascript contains erros
     * @return the compiled expression
     */
    public IFormula getCachedExpression( String expr ) throws ParseException {
        return jsContext.getExpression(expr);
    }
    /**
     * Get a Javascript expression from the global cache.</p>
     * If the cache does not already contains this expression, then it compiles
     * it and add it to the cache.<br>
     * The IFormula object can then be used to actually evaluate the formula
     * result.<br>
     * @param expr the javascript to parse
     * @param sourceReferenceID the source referenceID, for debug purposes
     * @throws ParseException if the javascript contains erros
     * @return the compiled expression
     */
    public IFormula getCachedExpression( String expr, String sourceReferenceID ) throws ParseException {
        return jsContext.getExpression(expr,sourceReferenceID);
    }
}
