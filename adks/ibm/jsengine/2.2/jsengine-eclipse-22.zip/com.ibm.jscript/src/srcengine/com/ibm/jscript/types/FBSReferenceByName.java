/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.std.ErrorObject;

public class FBSReferenceByName extends FBSReference {

    public static class ResolvedReference extends FBSReferenceByName {
        private FBSValue resolved;
        public ResolvedReference(FBSObject globalObject, String propertyName, FBSValue resolved) {
            super(globalObject,propertyName);
            this.resolved = resolved;
        }
        public boolean exists() {
            return true;
        }
        public FBSValue getValue() throws InterpretException {
            return resolved;
        }
        public void putValue(FBSValue value) throws InterpretException{
            super.putValue(value);
            resolved = value;
        }
    }
    
    public static class UndefinedVariable extends FBSReferenceByName {
        public UndefinedVariable(FBSObject globalObject, String propertyName) {
            super(globalObject,propertyName);
        }
        public boolean exists() {
            return false;
        }
        public FBSValue getValue() throws InterpretException {
            throw new InterpretException(null,ErrorObject.ReferenceErrorObject.create(base.getJSContext(),"'{0}' not found",getPropertyName())); // $NLS-FBSReferenceByName.ReferenceError0notfound-1$
        }
    }

    public static class JavaPackageVariable extends UndefinedVariable {
        public JavaPackageVariable(FBSObject globalObject, String propertyName) {
            super(globalObject,propertyName);
        }
        public FBSValue getJavaPackage(JSContext jsContext) throws InterpretException {
            String varName = getPropertyName();
            if(getBase() instanceof JavaPackageObject) {
            	JavaPackageObject p = (JavaPackageObject)getBase();
            	return p.get(varName);
            }
            return JavaPackageObject.getPackage(jsContext, varName, false);
        }
        public FBSValue getValue() throws InterpretException {
            String varName = getPropertyName();
            if(getBase() instanceof JavaPackageObject) {
                String s = ((JavaPackageObject)getBase()).getPackageName();
                if(s!=null) {
                    int pos = s.indexOf('.');
                    varName = pos>=0 ? s.substring(0,pos) : s;
                }
            }
            throw new InterpretException(null,ErrorObject.ReferenceErrorObject.create(base.getJSContext(),"'{0}' not found",varName));  // $NLS-FBSReferenceByName.Referenceerror0notfound-1$
        }
    }

    private String propertyName;

    public FBSReferenceByName(FBSObject base, String propertyName) {
        super(base);
        this.propertyName=propertyName;
    }

    public String getPropertyName(){
        return propertyName;
    }

    public FBSValue getValue() throws InterpretException {
        if(base==null) {
            throw new InterpretException(null,ErrorObject.ReferenceErrorObject.create(base.getJSContext(),"'{0}' not found",propertyName)); // $NLS-FBSReferenceByName.ReferenceError0notfound.1-1$
        }
        return base.get(propertyName);
    }

    public void putValue(FBSValue value) throws InterpretException {
        base.put(propertyName,value);
    }
}