/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;

public class ASTExpression extends ASTNode{
    private NodeVector nodes= new NodeVector();

    public ASTExpression() {
    }

    public void add(ASTNode node){
        nodes.add(assignParent(node));
    }

    public int getSlotCount(){
        return nodes.size();
    }

    public ASTNode readSlotAt(int index){
        return nodes.get(index);
    }

    public String getTraceString(){
        StringBuffer bufstr= new StringBuffer();
        for(int i=0;i<getSlotCount();i++){
            ASTNode n=readSlotAt(i);
            if (n!=null){
                bufstr.append(n.getTraceString());
            }
        }
        return bufstr.toString();
    }


    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            int count = getSlotCount();
            for(int i=0;i<count;i++){
                ASTNode n=readSlotAt(i);
                if (n!=null){
                    if(!n.interpret(this,context,result)) {
                    	return false;
                    }
                }
            }
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitExpression(this, param);
    }
}
