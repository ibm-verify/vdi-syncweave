/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.std.ErrorObject;

public final class FBSUndefined extends FBSValue{

    public static FBSUndefined undefinedValue= new FBSUndefined();

    private FBSUndefined() {
    }

    public boolean isList() {
        return false;
    }

    public int getType(){
        return UNDEFINED_TYPE;
    }

    public FBSType getFBSType(JSContext context){
        return FBSType.undefinedType;
    }

    public String stringValue(){
        return "undefined"; //$NON-NLS-1$
    }

    public double numberValue(){
        return Double.NaN;
    }

    public boolean booleanValue(){
        return false;
    }

    public boolean isUndefined() {
        return true;
    }

    public boolean canFBSObject(){
        return false;
    }

    public FBSValue toFBSPrimitive(){
        return this;
    }

    public FBSBoolean toFBSBoolean(){
        return FBSBoolean.get(booleanValue());
    }

    public FBSNumber toFBSNumber(){
        return FBSNumber.get(numberValue());
    }

    public String getTypeAsString(){
        return "undefined"; //$NON-NLS-1$
    }

    public FBSString toFBSString(){
        return FBSString.get(stringValue());
    }

    public String toString(){
        return "FBSUndefined"; //$NON-NLS-1$
    }

    public FBSObject toFBSObject(JSContext context) throws InterpretException{
        throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context,"Cannot convert undefined to an object")); // $NLS-FBSUndefined.CantconvertUndefinedtoanObject-1$
    }

    public boolean isJavaAssignableTo(Class c) {
        if (c==null){
            return true;
        }
        return false;
    }

    public Object toJavaObject(Class _class) throws InterpretException{
        if (_class==null){
            return null;
        }
        if (_class==String.class) {
            return stringValue();
        }
        throw new InterpretException(null,"Cannot convert FBSUndefined to {0}",_class.getName()); // $NLS-FBSUndefined.cantconvertFBSUndefinedto0-1$
    }

    public boolean isJavaNative(){
        return false;
    }
}
