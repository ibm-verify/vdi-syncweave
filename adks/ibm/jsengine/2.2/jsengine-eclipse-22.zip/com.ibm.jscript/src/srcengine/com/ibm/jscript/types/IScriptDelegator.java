/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

/**
 * Script delegation interface.
 * This interface is implemented by scriptable java objects that can delegate some functionalities
 * to another script object.
 */
public interface IScriptDelegator {

    /**
     * Get the object to delegate to.
     * @return the object to delegate to
     */
    public Object getScriptSingleDelegate();

    /**
     * Get the object to delegate to.
     * @return the list of objects to delegate to
     */
    public Object[] getScriptMultipleDelegate();
}
