/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSValue;

/**
 * This class allows to manipulate standard JavaScript Error objects.
 */
public class ErrorObject extends FBSDefaultObject {

    // =================================================================
    // Native Error Objects
    public abstract static class NativeErrorObject extends ErrorObject {
        public NativeErrorObject(JSContext jsContext,FBSDefaultObject proto,FBSValue message){
            super(jsContext,proto,message);
        }
    }
    public static class EvalErrorObject extends NativeErrorObject {
        public EvalErrorObject(JSContext jsContext,FBSValue message){
            super(jsContext,jsContext.getRegistry().evalErrorPrototype,message);
        }
        public static EvalErrorObject create(JSContext jsContext,String message,Object...params){
            return new EvalErrorObject(jsContext,FBSString.get(StringUtil.format(message,params)));
        }
    }
    public static class RangeErrorObject extends NativeErrorObject {
        public RangeErrorObject(JSContext jsContext,FBSValue message){
            super(jsContext,jsContext.getRegistry().rangeErrorPrototype,message);
        }
        public static RangeErrorObject create(JSContext jsContext,String message,Object...params){
            return new RangeErrorObject(jsContext,FBSString.get(StringUtil.format(message,params)));
        }
    }
    public static class ReferenceErrorObject extends NativeErrorObject {
        public ReferenceErrorObject(JSContext jsContext,FBSValue message){
            super(jsContext,jsContext.getRegistry().referenceErrorPrototype,message);
        }
        public static ReferenceErrorObject create(JSContext jsContext,String message,Object...params){
            return new ReferenceErrorObject(jsContext,FBSString.get(StringUtil.format(message,params)));
        }
    }
    public static class SyntaxErrorObject extends NativeErrorObject {
        public SyntaxErrorObject(JSContext jsContext,FBSValue message){
            super(jsContext,jsContext.getRegistry().syntaxErrorPrototype,message);
        }
        public static SyntaxErrorObject create(JSContext jsContext,String message,Object...params){
            return new SyntaxErrorObject(jsContext,FBSString.get(StringUtil.format(message,params)));
        }
    }
    public static class TypeErrorObject extends NativeErrorObject {
        public TypeErrorObject(JSContext jsContext,FBSValue message){
            super(jsContext,jsContext.getRegistry().typeErrorPrototype,message);
        }
        public static TypeErrorObject create(JSContext jsContext,String message,Object...params){
            return new TypeErrorObject(jsContext,FBSString.get(StringUtil.format(message,params)));
        }
    }
    public static class URIErrorObject extends NativeErrorObject {
        public URIErrorObject(JSContext jsContext,FBSValue message){
            super(jsContext,jsContext.getRegistry().uriErrorPrototype,message);
        }
        public static URIErrorObject create(JSContext jsContext,String message,Object...params){
            return new URIErrorObject(jsContext,FBSString.get(StringUtil.format(message,params)));
        }
    }
    
    // In case it has a Java exception cause
    private Throwable cause;
    
    // =================================================================
    // Standard Error Object
    public ErrorObject(JSContext jsContext,FBSValue message) {
        this(jsContext,jsContext.getRegistry().errorPrototype,message);
    }

    public ErrorObject(JSContext jsContext, FBSDefaultObject proto, FBSValue message) {
        super(jsContext,proto);
        try {
            if(message!=null) {
                if(!message.isUndefined()) {
                    putProperty("message", message.toFBSString()); // $NON-NLS-1$
                } else {
                    putProperty("message", message); // $NON-NLS-1$
                }
            }
        } catch(InterpretException ex) {}
    }
    
    public Throwable getCause() {
    	return cause;
    }

    public void setCause(Throwable cause) {
    	this.cause = cause;
    }
    
    public boolean equals( Object o ) {
        if(o!=null) {
            if( o.getClass()==getClass() ) {
                return true;
            }
        }
        return false;
    }

    public String getTypeAsString(){
        return "Error"; //$NON-NLS-1$
    }

    public FBSValue getName() {
        try {
            return (FBSValue)getProperty("name"); // $NON-NLS-1$
        } catch(InterpretException ex) {
            return FBSString.emptyString;
        }
    }

    public FBSValue getMessage() {
        try {
            return (FBSValue)getProperty("message"); // $NON-NLS-1$
        } catch(InterpretException ex) {
            return FBSString.emptyString;
        }
    }
}