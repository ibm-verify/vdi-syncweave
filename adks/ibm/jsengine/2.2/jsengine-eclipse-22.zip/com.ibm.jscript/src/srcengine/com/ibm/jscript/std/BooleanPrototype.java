/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.BuiltinConstructor;
import com.ibm.jscript.types.BuiltinFunction;
import com.ibm.jscript.types.FBSBoolean;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.FBSValueVector;

/**
 * Boolean object prototype.
 */
public class BooleanPrototype extends BooleanObject implements Prototype {

    public BooleanPrototype(JSContext jsContext){
        super(jsContext,jsContext.getRegistry().objectPrototype);
        int attrib=FBSObject.P_NOENUM;
        createConstructor(attrib,new BooleanConstructor(jsContext,this)); //$NON-NLS-1$
        createMethod("toString",attrib,new BooleanMethod(jsContext,0)); //$NON-NLS-1$
        createMethod("valueOf",attrib,new BooleanMethod(jsContext,1)); //$NON-NLS-1$
    }

    ////// Constructor
    static class BooleanConstructor extends BuiltinConstructor{
        public BooleanConstructor(JSContext jsContext, FBSDefaultObject prototype){
            super(jsContext,prototype,"Boolean"); // $NON-NLS-1$
        }
        public boolean hasInstance(FBSValue v){
            return v instanceof BooleanObject;
        }
        protected String[] getCallParameters() {
            return new String[] {"():Z","(value:W):Z"}; //$NON-NLS-1$ $NON-NLS-2$
        }
        protected String[] getConstructorParameters() {
            return new String[] {"()","(value:W)"}; //$NON-NLS-1$
        }
        public boolean supportConstruct(){
            return true;
        }
        public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
            if(args.getCount()>=1) {
                boolean b = args.get(0).booleanValue();
                return new BooleanObject(getJSContext(),FBSBoolean.get(b));
            }
            return new BooleanObject(getJSContext(),FBSBoolean.FALSE);
        }
        public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this) throws InterpretException {
            if(args.getCount()==0) {
                return FBSBoolean.FALSE;
            }
            return args.get(0).toFBSBoolean();
        }
    }
    
    ////// Method
    static class BooleanMethod extends BuiltinFunction{
        int mIndex=-1;

        public BooleanMethod(JSContext jsContext, int index){
            super(jsContext);
            mIndex=index;
        }

        protected String[] getCallParameters() {
            switch(mIndex) {
                case 0: //toString
                    return new String[] {"():T"}; //$NON-NLS-1$
                case 1: //valueOf
                    return new String[] {"():T"}; //$NON-NLS-1$
            }
            return super.getCallParameters();
        }


        public FBSValue call(FBSValueVector args, FBSObject _this) throws InterpretException {
            return FBSUndefined.undefinedValue;
        }

        public FBSValue call(IExecutionContext context, FBSValueVector args, FBSObject _this) throws InterpretException {
            switch(mIndex){
            
                ///////////////////////////////////////////////////////////////
                // Standard ECMA functions
                case 0: {     // toString
                    if(_this instanceof BooleanObject) {
                        return FBSString.get(_this.booleanValue()?"true":"false"); //$NON-NLS-1$ //$NON-NLS-2$
                    }
                    if(_this==null) {
                        return FBSString.emptyString;
                    }
                    throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Object is not a boolean, {0}",FBSUtility.getDisplayType(_this))); //$NLS-BooleanPrototype.BooleanPrototype.NotAString.Exception-1$
                }
                case 1: {     // valueOf
                    if(_this instanceof BooleanObject) {
                        return ((BooleanObject)_this).getFBSBoolean();
                    }
                    throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Object is not a boolean, {0}",FBSUtility.getDisplayType(_this))); //$NLS-BooleanPrototype.BooleanPrototype.NotAString.Exception-1$
                }
            }
            throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Boolean function not found")); //$NLS-BooleanPrototype.BooleanPrototype.BoolFuncNotFound.Exception-1$
        }
    }

}