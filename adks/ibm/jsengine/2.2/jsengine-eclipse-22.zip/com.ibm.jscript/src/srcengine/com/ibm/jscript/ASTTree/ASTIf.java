/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSUndefined;

public class ASTIf extends ASTNode{
	
    public static final int CONDITION=0;
    public static final int STATEMENT=1;
    public static final int ELSESTATEMENT=2;

    ASTNode conditionNode;
    ASTNode statementNode;
    ASTNode elseStatementNode;

    public ASTIf() {
    }

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        FBSType t1 = statementNode.getResultType(jsContext,symbolCallback);
        if( elseStatementNode!=null ) {
            FBSType t2 = statementNode.getResultType(jsContext,symbolCallback);
            if( t1.equals(t2) ) {
                return t1;
            }
            return FBSType.undefinedType;
        }
        return t1;
    }

    public void add(ASTNode condition,ASTNode statement, ASTNode elsestatement){
        conditionNode=assignParent(condition);
        statementNode=assignParent(statement);
        elseStatementNode=assignParent(elsestatement);
    }

    public int getSlotCount(){
        return 3;
    }

    public ASTNode readSlotAt(int index){
        switch(index){
            case CONDITION: return conditionNode;
            case STATEMENT: return statementNode;
            case ELSESTATEMENT: return elseStatementNode;
        }
        return null;
    }
    
    // Used by optimizer
    public void putSlotAt(int index, ASTNode node) {
        switch(index){
        	case CONDITION: 	conditionNode=node; break;
        	case STATEMENT: 	statementNode=node; break;
        	case ELSESTATEMENT: elseStatementNode=node; break;
        }
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            if(!conditionNode.interpret(this,context,result)) {
            	return false;
            }
            boolean istrue=result.getFBSValue().booleanValue();

            if (istrue){
                if(!statementNode.interpret(this,context,result)) {
                	return false;
                }
            }else{
                if (elseStatementNode!=null){
                    if(!elseStatementNode.interpret(this,context,result)) {
                    	return false;
                    }
                } else {
                    result.setNormal(FBSUndefined.undefinedValue);
                }
            }
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitIf(this, param);
    }
}
