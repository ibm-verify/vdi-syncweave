/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.engine;

import java.io.PrintStream;
import java.util.List;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JSExpression;
import com.ibm.jscript.debug.DebugInspector;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSGlobalObject;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSReference;
import com.ibm.jscript.types.FBSReferenceByName;
import com.ibm.jscript.types.JavaPackageObject;

/**
 * Program execution context.
 * Main context directly used by programs/global fct calls
 */
public class ProgramContext extends IExecutionContext {

    private JSExpression expression;
    private FBSObject scopePrototypes;
    private FBSObject registryObject;
    private FBSObject params;
    private DebugInspector debugInspector;
    private PrintStream printStream;
    private String loopLabel;

    // Ctor used by the temporary context (for default values evaluation)
    protected ProgramContext(JSContext jsContext, IExecutionContext parentContext, FBSGlobalObject globalObject, FBSDefaultObject varObject, FBSObject _this) {
        super(jsContext, parentContext, globalObject, varObject, _this);
        this.registryObject = jsContext.getRegistry().getRegistryObject();
    }
    
    public ProgramContext(JSExpression expression, FBSGlobalObject globalObject, FBSObject scopePrototypes, FBSObject _this, FBSObject params, List<String> importedLibraries) throws InterpretException {
        super(expression.getJSContext(),null,globalObject,globalObject,_this);
        JSContext jsContext = getJSContext(); 
        this.expression = expression;
        this.scopePrototypes = scopePrototypes;
        this.registryObject = jsContext.getRegistry().getRegistryObject();
        this.params = params;
        //JEFF: Everytime we enter a new ProgramContext, I need to reset the DebugInspector:
        if( jsContext.isDebugAllowed() ) {
            this.debugInspector = DebugInspector.newDebugInspector();
        }

        // Import libraries
        if( importedLibraries!=null ) {
        	int len = importedLibraries.size(); // ArrayList<> is the most efficient 
            for( int i=0; i<len; i++ ) {
                globalObject.importLibrary(jsContext,importedLibraries.get(i));
            }
        }
    }    

    public ProgramContext getProgramContext() {
        return this;
    }

    public JSExpression getExpression() {
        return expression;
    }
    
    public PrintStream getPrintStream() {
    	return printStream;
    }
    
    public void setPrintStream(PrintStream printStream) {
    	this.printStream = printStream;
    }

    public PrintStream getStandardStream() {
    	if(printStream!=null) {
    		return printStream;
    	}
        return super.getStandardStream(); 
    }

    public String getLoopLabel() {
        return loopLabel;
    }

    public void setLoopLabel(String loopLabel) {
        this.loopLabel = loopLabel;
    }

    public FBSReference findIdentifier(String name) throws InterpretException {
    	FBSReference ref;
    	
        // 1. Look at the internal scope
        // That scope is changed mainly by with & try statement
        if( scopeCount>0 ) {
            for( int i=scopeCount-1; i>=0; i-- ) {
            	ref = scopeData[i].getPropertyReference(name);
            	if(ref!=null) {
            		return ref;
            	}
            }
        }

        // 2. Look into the params map
        // Params are used as "pseudo" parameters when an expression is executed
        // Those params have a greater priority than the variables 
        if(params!=null) {
            ref = params.getPropertyReference(name);
            if(ref!=null){
                return ref;
            }
        }
        
        // 3. Look in the global object scope
        // That scope carries all the global symbols
        ref = globalObject.getPropertyReference(name);
        if(ref!=null){
            return ref;
        }

        return findGlobalScopeIdentifier(name);
    }

    public FBSReference findGlobalScopeIdentifier(String name) throws InterpretException {
    	FBSReference ref;

    	// 3. Look in the scope prototypes
        // These prototypes are
        if( scopePrototypes!=null ) {
            ref = scopePrototypes.getPropertyReference(name);
            if(ref!=null){
                return ref;
            }
        }

        // 4. Look in the global registry
        ref = registryObject.getPropertyReference(name);
        if(ref!=null){
            return ref;
        }
        
        // 5. Look for a library entry
        ref = globalObject.searchLibrary(name);
        if (ref!=null){
            return ref;
        }

        // 6. Look in the global objects list
        int globalCount = getJSContext().getRegistry().getGlobalPrototypeCount();
        for( int i=0; i<globalCount; i++ ) {
	        FBSObject object = getJSContext().getRegistry().getGlobalPrototype(i);
	        ref = object.getPropertyReference(name);
	        if(ref!=null){
	            return ref;
	        }
        }
        
        // 7. Look into the registered packages
        // We do that at the end as using class loaders can be time consuming...
        JavaPackageObject jp = globalObject.loadJavaClass(getJSContext(),name);
        if(jp!=null) {
	        ref = new FBSReferenceByName(jp,name);
	        if(ref!=null){
	            return ref;
	        }
        }

        // Not found...
        return null;
    }
    
    //JEFF: This lets an ASTDebug node get the current DebugInspector 
    public DebugInspector getDebugInspector() {
    	return debugInspector;
    }
}
