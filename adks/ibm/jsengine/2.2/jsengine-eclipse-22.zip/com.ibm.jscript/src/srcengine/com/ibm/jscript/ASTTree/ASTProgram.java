/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.engine.ProgramContext;
import com.ibm.jscript.parser.ParseException;
import com.ibm.jscript.types.FBSGlobalObject;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSValue;

public class ASTProgram extends ASTExecutionScope {

	private String expr;
    private ASTNode[] nodes = ASTNode.EMPTY_ARRAY;
    private Boolean useStrict;
    private Boolean useListOp;
   
    public ASTProgram() {
    }

    public Boolean isUseStrict() {
    	return useStrict;
    }

	public Boolean isUseListOp() {
		return useListOp;
	}

    public String getExpr() {
    	return expr;
    }
    
    public void setExpr(String expr) {
    	this.expr = expr;
    }
    
    public ASTProgram getRootNode() {
    	return this;
    }

    public int getSlotCount(){
        return nodes.length;
    }

    public ASTNode readSlotAt(int index){
        return nodes[index];
    }
    
    public void initNodes(NodeVector vc) {
    	int count = vc.size();
    	this.nodes = new ASTNode[count];
    	
    	boolean checkDir = true;
    	for(int i=0; i<count; i++) {
			ASTNode n = vc.get(i);
    		if(checkDir) {
    			switch(ASTExecutionScope.getDirective(n)) {
    				case ASTExecutionScope.USE_STRICT: {
    					useStrict = Boolean.TRUE;
    				} break;
    				case ASTExecutionScope.USE_IBM_LISTOP: {
    					useListOp = Boolean.TRUE;
    				} break;
    				case ASTExecutionScope.USE_IBM_LISTOP_NO: {
    					useListOp = Boolean.FALSE;
    				} break;
    				default: {
        				checkDir = false;
    				}
    			}
    		}
    		nodes[i] = assignParent(n);
    	}
    }

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        int count = nodes.length;
        if( count>0 ) {
            FBSType t = null;
            for( int i=0; i<count; i++ ) {
                if( t==null ) {
                    t = ((ASTNode)nodes[i]).getResultType(jsContext,symbolCallback);
                } else {
                    FBSType t2 = ((ASTNode)nodes[i]).getResultType(jsContext,symbolCallback);
                    if( !t.equals(t2) ) {
                        return FBSType.undefinedType;
                    }
                }
            }
            return t;
        }
        return FBSType.undefinedType;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
        	initContext(context);
        	int count = nodes.length;
            for(int i=0;i<count;i++){
                ASTNode n=nodes[i];
                if (n!=null){
                	if(!n.interpret(this, context, result)) {
                        return false;
                	}
                }
            }
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        } catch( JavaScriptException ie ) {
            // Should not arrive!!!
            throw new InterpretException( ie, "Unexpected exception" ); //$NLS-ASTProgram.ASTProgram.Unexpected.Exception-1$
        }
    }

    /**
     * extended interpret method that returns at the end the GlobalObject.
     * This method is useful for libraries.
     */
    public FBSGlobalObject interpretEx(IExecutionContext prgContext, InterpretResult result) throws InterpretException{
        try {
        	if(!interpret(this, prgContext, result)) {
        		if(result.isReturnSignal()) {
                    result.resetSignal();
                    FBSValue value = prgContext.getReturnValue();
                    result.setNormal(value);
        		} else {
        			result.resetSignal();
        			result.setNormal(FBSUndefined.undefinedValue);
        		}
        	}
        } catch( InterpretException ie ) {
            throw ie.fillException(prgContext,this);
        } catch( JavaScriptException ie ) {
            // Should not arrive!!!
            throw new InterpretException( ie, "Unexpected exception" ); //$NLS-ASTProgram.ASTProgram.Unexpected.Exception-1$
        }
        if(prgContext instanceof ProgramContext) { // Not true in case of eval()
        	if( JSContext.isDebugAllowed() ) {
        		((ProgramContext)prgContext).getDebugInspector().endOfProgram();
        	}
        }
        return prgContext.getGlobalObject();
    }

    
    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitProgram(this, param);
    }    
}
