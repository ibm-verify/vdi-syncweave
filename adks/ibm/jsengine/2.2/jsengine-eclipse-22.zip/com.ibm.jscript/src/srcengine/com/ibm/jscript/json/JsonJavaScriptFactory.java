/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2008, 2009                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.json;

import java.util.Iterator;
import java.util.List;

import com.ibm.commons.util.io.json.JsonException;
import com.ibm.commons.util.io.json.JsonFactory;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.std.ArrayObject;
import com.ibm.jscript.std.ObjectObject;
import com.ibm.jscript.types.FBSBoolean;
import com.ibm.jscript.types.FBSNull;
import com.ibm.jscript.types.FBSNumber;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSValue;


/**
 *
 */
public class JsonJavaScriptFactory implements JsonFactory {
	
	private JSContext context;
	
	public JsonJavaScriptFactory(JSContext context) {
		this.context = context;
	}
	
	public Object createNull() throws JsonException {
		return FBSNull.nullValue;
	}
	
	public Object createString(String value) throws JsonException {
		return FBSString.get(value);
	}
	
	public Object createNumber(double value) throws JsonException {
		return FBSNumber.get(value);
	}
	
	public Object createBoolean(boolean value) throws JsonException {
		return FBSBoolean.get(value);
	}

	public Object createObject(Object parent, String propertyName) throws JsonException {
		return new ObjectObject(context);
	}
	
	public Object createArray(Object parent, String propertyName, List<Object> values) throws JsonException {
		ArrayObject a = new ArrayObject();
		for(int i=0; i<values.size(); i++) {
			a.put(i,(FBSValue)values.get(i));
		}
		return a;
	}
	
	public void setProperty(Object parent, String propertyName, Object value) throws JsonException {
		try {
			((ObjectObject)parent).put(propertyName, (FBSValue)value);
		} catch(InterpretException ex) {
			throw new JsonException(ex,"Error while parsing Json stream, property {0}", propertyName); // $NLS-JsonJavaScriptFactory.ErrorwhileparsingJSONstreamproper-1$
		}
	}
	
	
	public Object getProperty(Object parent, String propertyName) throws JsonException {
		try {
			return ((ObjectObject)parent).get(propertyName);
		} catch(InterpretException ex) {
			throw new JsonException(ex,"Error while accessing object property {0}", propertyName); // $NLS-JsonJavaScriptFactory.Errorwhileaccessingobjectproperty-1$
		}
	}
	
	public boolean isNull(Object value) throws JsonException {
		return ((FBSValue)value).isNull();
	}
	
	public boolean isString(Object value) throws JsonException {
		return ((FBSValue)value).isString();
	}

	public String getString(Object value) throws JsonException {
		return ((FBSValue)value).stringValue();
	}
	
	public boolean isNumber(Object value) throws JsonException {
		return ((FBSValue)value).isNumber();
	}

	public double getNumber(Object value) throws JsonException {
		return ((FBSValue)value).numberValue();
	}
	
	public boolean isBoolean(Object value) throws JsonException {
		return ((FBSValue)value).isBoolean();
	}

	public boolean getBoolean(Object value) throws JsonException {
		return ((FBSValue)value).booleanValue();
	}
	
	public boolean isObject(Object value) throws JsonException {
		return ((FBSValue)value).isObject() && !((FBSValue)value).isArray();
	}

	public Iterator<String> iterateObjectProperties(Object object) throws JsonException {
		FBSObject o = (FBSObject)object;
		return o.getPropertyKeys();
	}
	
	public boolean isArray(Object value) throws JsonException {
		return ((FBSValue)value).isArray();
	}

	public Iterator<Object> iterateArrayValues(Object array) throws JsonException {
		ArrayObject o = (ArrayObject)array;
		return o.iterateValues();
	}	
}
