/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2008                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import java.io.PrintStream;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.parser.Token;
import com.ibm.jscript.types.FBSBoolean;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSNumber;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSReference;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSValue;

public class ASTUnaryOp extends ASTNode{
    private int typeId;
    private boolean ispostfix;
    private ASTNode node;

    public ASTUnaryOp(Token t, int typeId, ASTNode node) {
    	super(t);
        this.typeId=typeId;
        this.node = assignParent(node);
    }

    public ASTUnaryOp(Token t, int typeId, ASTNode node, boolean postfix) {
    	super(t);
        this.typeId=typeId;
        this.node = assignParent(node);
        this.ispostfix=postfix;
    }

    public int getOperator(){
    	return typeId;
    }

    public boolean isPostfix(){
        return ispostfix;
    }

    public int getSlotCount(){
        return 1;
    }

    public ASTNode readSlotAt(int index){
        return node;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            if (ispostfix){
                if(!node.interpret(this,context,result)) {
                	return false;
                }
                FBSNumber numVal=result.getFBSValue().toFBSNumber();
                if (typeId==ASTConstants.INC){
                    result.getReference().putValue(numVal.incValue());
                } else if (typeId==ASTConstants.DEC){
                    result.getReference().putValue(numVal.decValue());
                }
                result.setNormal(numVal);
                return true;
            }

            if(!node.interpret(this,context,result)) {
            	return false;
            }
            
            double dblValue;
            FBSNumber num;
            switch(typeId){
                case ASTConstants.DELETE: {
                        if (!result.isReference()){
                            result.setNormal(FBSBoolean.TRUE);
                            return true;
                        }
                        FBSObject object=result.getReference().getBase();
                        if( object instanceof FBSDefaultObject ) {
                            String pName=result.getReference().getPropertyName();
                            boolean b= ( (FBSDefaultObject)object).delete(pName);
                            result.setNormal(FBSBoolean.get(b));
                        } else {
                            result.setNormal(FBSBoolean.FALSE);
                        }
                } break;

                case ASTConstants.VOID: {
                        result.setNormal(FBSUndefined.undefinedValue);
                } break;

                case ASTConstants.TYPEOF: {
                        if (result.isReference()){
                        	FBSReference ref = result.getReference(); 
                            if (!ref.exists()){
                                result.setNormal(FBSString.get("undefined")); //$NON-NLS-1$
                                return true;
                            }
                        }
                        FBSValue value=result.getFBSValue();
                        switch(value.getType()){
                            case FBSValue.UNDEFINED_TYPE: result.setNormal(FBSString.get("undefined"));break; //$NON-NLS-1$
                            case FBSValue.NULL_TYPE: result.setNormal(FBSString.get("object"));break; //$NON-NLS-1$
                            case FBSValue.BOOLEAN_TYPE: result.setNormal(FBSString.get("boolean"));break; //$NON-NLS-1$
                            case FBSValue.NUMBER_TYPE: result.setNormal(FBSString.get("number"));break; //$NON-NLS-1$
                            case FBSValue.STRING_TYPE: result.setNormal(FBSString.get("string"));break; //$NON-NLS-1$
                            case FBSValue.FUNCTION_TYPE:result.setNormal(FBSString.get("function"));break; //$NON-NLS-1$
                            case FBSValue.OBJECT_TYPE: {
                                if(value instanceof FBSDefaultObject) {
                                    result.setNormal(FBSString.get("object")); //$NON-NLS-1$
                                } else {
                                    result.setNormal(FBSString.get(value.getTypeAsString()));
                                }
                            }
                        }
                } break;

                case ASTConstants.INC: {
                    	FBSValue value=result.getFBSValue();
                        num=value.toFBSNumber().incValue();
                        result.getReference().putValue(num);
                        result.setNormal(num);
                } break;

                case ASTConstants.DEC: {
                		FBSValue value=result.getFBSValue();
                        num=value.toFBSNumber().decValue();
                        result.getReference().putValue(num);
                        result.setNormal(num);
                } break;

                case ASTConstants.ADD: {
                		FBSValue value=result.getFBSValue();
                        dblValue=value.numberValue();
                        num=FBSNumber.get(dblValue);
                        result.setNormal(num);
                } break;

                case ASTConstants.SUBTRACT: {
                		FBSValue value=result.getFBSValue();
                        dblValue=value.numberValue();
                		if(dblValue==Double.NEGATIVE_INFINITY) {
                            result.setNormal(FBSNumber.POSITIVE_INFINITY);
                		} else if(dblValue==Double.POSITIVE_INFINITY) {
                            result.setNormal(FBSNumber.NEGATIVE_INFINITY);
                		} else {
                			num=FBSNumber.get(-dblValue);
                            result.setNormal(num);
                		}
                } break;

                case ASTConstants.INV: {
                		FBSValue value=result.getFBSValue();
                        long longValue=value.longValue() & 0xFFFFFFFF;
                        num=FBSNumber.get((int)~longValue);
                        result.setNormal(num);
                } break;

                case ASTConstants.NEG: {
                		FBSValue value=result.getFBSValue();
                        boolean boolValue=value.booleanValue();
                        result.setNormal(FBSBoolean.get(!boolValue));
                } break;
            }
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }
    protected void extraInfo(PrintStream ps,String indent){
        ps.print("\""); //$NON-NLS-1$
        ps.print(ASTConstants.getToken(this.typeId));
        ps.print("\""); //$NON-NLS-1$
    }

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        FBSType t = node.getResultType(jsContext,symbolCallback);
         switch(typeId){
            case ASTConstants.DELETE:
                    return FBSType.undefinedType;

            case ASTConstants.VOID:
                    return FBSType.undefinedType;

            case ASTConstants.TYPEOF:
                    return FBSType.stringType;

            case ASTConstants.INC:
            case ASTConstants.DEC:
                    return FBSType.numberType;

            case ASTConstants.ADD:
            case ASTConstants.SUBTRACT:
                    return FBSType.numberType;

            case ASTConstants.INV:
                    return FBSType.numberType;

            case ASTConstants.NEG:
                    return FBSType.booleanType;
        }
        return FBSType.invalidType;
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitUnaryOp(this, param);
    }
}
