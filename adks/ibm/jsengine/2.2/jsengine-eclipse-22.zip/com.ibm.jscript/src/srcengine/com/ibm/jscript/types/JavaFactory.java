/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import java.lang.reflect.Array;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;

public final class JavaFactory {

    public static FBSObject instantiate(JSContext jsContext, String className,int[] dim)throws InterpretException{
        try{
            // Create the actual java array object
            Class c=getBasicTypeClass(className);
            if (c==null){
                c = jsContext.loadClass(className);
            }
            if(c!=null) {
                Object o=Array.newInstance(c,dim);
                // And create the wrapper
                return FBSUtility.wrapArray(jsContext,o);
            }
        }catch(ClassNotFoundException e){
        }
        throw new InterpretException(null,StringUtil.format("Cannot find Java class '{0}' while instantiating array",className)); //$NLS-JavaFactory.JavaFactory.ArrayClassNotFound.Exception-1$
    }

    public static Class getJavaClass(JSContext jsContext, String className, int dim)throws InterpretException{
        try{
            // Create the actual java array object
            Class c=getBasicTypeClass(className);
            if (c==null){
                c = jsContext.loadClass(className);
            }
            if(c!=null) {
                if( dim>0 ) {
                    int[] v = new int[dim];
                    Object o=Array.newInstance(c,v);
                    return o.getClass();
                }
                return c;
            }
        }catch(ClassNotFoundException e){
        }
        throw new InterpretException(null,StringUtil.format("Cannot find Java class '{0}'",className)); //$NLS-JavaFactory.JavaFactory.ClassNotFound.Exception-1$
    }

    private static Class getBasicTypeClass(String className) {
        if (className==null){
            return null;
        }
        switch(className.charAt(0)) {
            case 'b': {
                if (className.equals("boolean")){ //$NON-NLS-1$
                    return boolean.class;
                }
                if (className.equals("byte")){ //$NON-NLS-1$
                    return byte.class;
                }
            } break;
            case 'c': {
                if (className.equals("char")){ //$NON-NLS-1$
                    return char.class;
                }
            } break;
            case 'd': {
                if (className.equals("double")){ //$NON-NLS-1$
                    return double.class;
                }
            } break;
            case 'f': {
                if (className.equals("float")){ //$NON-NLS-1$
                    return float.class;
                }
            } break;
            case 'i': {
                if (className.equals("int")){ //$NON-NLS-1$
                    return int.class;
                }
            } break;
            case 'l': {
                if (className.equals("long")){ //$NON-NLS-1$
                    return long.class;
                }
            } break;
            case 's': {
                if (className.equals("short")){ //$NON-NLS-1$
                    return short.class;
                }
            } break;
        }
        return null;
    }
}
