/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import java.text.DateFormat;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.BuiltinConstructor;
import com.ibm.jscript.types.BuiltinFunction;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSNumber;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.FBSValueVector;

/**
 * Date object prototype.
 */
public class DatePrototype extends DateObject implements Prototype {

    public DatePrototype(JSContext jsContext){
        super(jsContext,jsContext.getRegistry().objectPrototype);
        
        int attrib=FBSObject.P_NOENUM;
        createConstructor(attrib,new DateConstructor(jsContext,this)); //$NON-NLS-1$
        createMethod("toString",attrib,new DateMethod(jsContext,0)); //$NON-NLS-1$
        createMethod("valueOf",attrib,new DateMethod(jsContext,1)); //$NON-NLS-1$

        createMethod("parseISO",attrib,new DateMethod(jsContext,2)); //$NON-NLS-1$
        createMethod("parse",attrib,new DateMethod(jsContext,3)); //$NON-NLS-1$
        createMethod("UTC",attrib,new DateMethod(jsContext,4)); //$NON-NLS-1$
        createMethod("getTime",attrib,new DateMethod(jsContext,5)); //$NON-NLS-1$
        createMethod("getYear",attrib,new DateMethod(jsContext,6)); //$NON-NLS-1$
        createMethod("getFullYear",attrib,new DateMethod(jsContext,7)); //$NON-NLS-1$
        createMethod("getUTCFullYear",attrib,new DateMethod(jsContext,8)); //$NON-NLS-1$
        createMethod("getMonth",attrib,new DateMethod(jsContext,9)); //$NON-NLS-1$
        createMethod("getUTCMonth",attrib,new DateMethod(jsContext,10)); //$NON-NLS-1$
        createMethod("getDate",attrib,new DateMethod(jsContext,11)); //$NON-NLS-1$
        createMethod("getUTCDate",attrib,new DateMethod(jsContext,12)); //$NON-NLS-1$
        createMethod("getDay",attrib,new DateMethod(jsContext,13)); //$NON-NLS-1$
        createMethod("getUTCDay",attrib,new DateMethod(jsContext,14)); //$NON-NLS-1$
        createMethod("getHour",attrib,new DateMethod(jsContext,15)); //$NON-NLS-1$
        createMethod("getHours",attrib,new DateMethod(jsContext,16)); //$NON-NLS-1$
        createMethod("getUTCHours",attrib,new DateMethod(jsContext,17)); //$NON-NLS-1$
        createMethod("getMinute",attrib,new DateMethod(jsContext,18)); //$NON-NLS-1$
        createMethod("getMinutes",attrib,new DateMethod(jsContext,19)); //$NON-NLS-1$
        createMethod("getUTCMinutes",attrib,new DateMethod(jsContext,20)); //$NON-NLS-1$
        createMethod("getSeconds",attrib,new DateMethod(jsContext,21)); //$NON-NLS-1$
        createMethod("getSecond",attrib,new DateMethod(jsContext,22)); //$NON-NLS-1$
        createMethod("getUTCSeconds",attrib,new DateMethod(jsContext,23)); //$NON-NLS-1$
        createMethod("getMilliseconds",attrib,new DateMethod(jsContext,24)); //$NON-NLS-1$
        createMethod("getUTCMilliseconds",attrib,new DateMethod(jsContext,25)); //$NON-NLS-1$
        createMethod("getTimezoneOffset",attrib,new DateMethod(jsContext,26)); //$NON-NLS-1$
        createMethod("setTime",attrib,new DateMethod(jsContext,27)); //$NON-NLS-1$
        createMethod("setMilliseconds",attrib,new DateMethod(jsContext,28)); //$NON-NLS-1$
        createMethod("setUTCMilliseconds",attrib,new DateMethod(jsContext,29)); //$NON-NLS-1$
        createMethod("setSeconds",attrib,new DateMethod(jsContext,30)); //$NON-NLS-1$
        createMethod("setUTCSeconds",attrib,new DateMethod(jsContext,31)); //$NON-NLS-1$
        createMethod("setMinutes",attrib,new DateMethod(jsContext,32)); //$NON-NLS-1$
        createMethod("setUTCMinutes",attrib,new DateMethod(jsContext,33)); //$NON-NLS-1$
        createMethod("setHours",attrib,new DateMethod(jsContext,34)); //$NON-NLS-1$
        createMethod("setUTCHours",attrib,new DateMethod(jsContext,35)); //$NON-NLS-1$
        createMethod("setDate",attrib,new DateMethod(jsContext,36)); //$NON-NLS-1$
        createMethod("setUTCDate",attrib,new DateMethod(jsContext,37)); //$NON-NLS-1$
        createMethod("setMonth",attrib,new DateMethod(jsContext,38)); //$NON-NLS-1$
        createMethod("setUTCMonth",attrib,new DateMethod(jsContext,39)); //$NON-NLS-1$
        createMethod("setFullYear",attrib,new DateMethod(jsContext,40)); //$NON-NLS-1$
        createMethod("setUTCFullYear",attrib,new DateMethod(jsContext,41)); //$NON-NLS-1$
        createMethod("toDateString",attrib,new DateMethod(jsContext,42)); //$NON-NLS-1$
        createMethod("toTimeString",attrib,new DateMethod(jsContext,43)); //$NON-NLS-1$
        createMethod("toLocaleString",attrib,new DateMethod(jsContext,44)); //$NON-NLS-1$
        createMethod("toLocaleDateString",attrib,new DateMethod(jsContext,45)); //$NON-NLS-1$
        createMethod("toLocaleTimeString",attrib,new DateMethod(jsContext,46)); //$NON-NLS-1$
        createMethod("toUTCString",attrib,new DateMethod(jsContext,47)); //$NON-NLS-1$
        createMethod("toISOString",attrib,new DateMethod(jsContext,48)); //$NON-NLS-1$
        createMethod("toGMTString",attrib,new DateMethod(jsContext,49)); //$NON-NLS-1$
    }

    ////// Constructor
    static class DateConstructor extends BuiltinConstructor{
        public DateConstructor(JSContext jsContext, FBSDefaultObject prototype){
            super(jsContext,prototype,"Date"); // $NON-NLS-1$
        }
        public boolean hasInstance(FBSValue v){
            return v instanceof DateObject;
        }
        public boolean supportConstruct(){
            return true;
        }
        protected String[] getCallParameters() {
            return new String[] {"():Y"  //$NON-NLS-1$
                    ,"(value:J):Y" //$NON-NLS-1$
                    ,"(value:T):Y" //$NON-NLS-1$
                    ,"(year:Imonth:I):Y" //$NON-NLS-1$
                    ,"(year:Imonth:Idate:I):Y" //$NON-NLS-1$
                    ,"(year:Imonth:Idate:Ihours:I):Y" //$NON-NLS-1$
                    ,"(year:Imonth:Idate:Ihours:Iminutes:I):Y" //$NON-NLS-1$
                    ,"(year:Imonth:Idate:Ihours:Iminutes:Iseconds:I):Y" //$NON-NLS-1$
                    ,"(year:Imonth:Idate:Ihours:Iminutes:Iseconds:Ims:I):Y"};  //$NON-NLS-1$
        }
        protected String[] getConstructorParameters() {
            return new String[] {"()"  //$NON-NLS-1$
                    ,"(value:J)" //$NON-NLS-1$
                    ,"(value:T)" //$NON-NLS-1$
                    ,"(year:Imonth:I)" //$NON-NLS-1$
                    ,"(year:Imonth:Idate:I)" //$NON-NLS-1$
                    ,"(year:Imonth:Idate:Ihours:I)" //$NON-NLS-1$
                    ,"(year:Imonth:Idate:Ihours:Iminutes:I)" //$NON-NLS-1$
                    ,"(year:Imonth:Idate:Ihours:Iminutes:Iseconds:I)" //$NON-NLS-1$
                    ,"(year:Imonth:Idate:Ihours:Iminutes:Iseconds:Ims:I)"};  //$NON-NLS-1$
        }

        public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
            // Default ctor, today's date
            if(args.getCount()==0) {
                return new DateObject(getJSContext());
            }
            // Parametrized ctor
            if(args.getCount()==1) {
                FBSValue v = args.get(0);
                if( v instanceof DateObject) {
                    return new DateObject(getJSContext(),((DateObject)v).getTime());
                }
                if( v.isString() ) {
                    String s = v.stringValue();
                    return new DateObject(getJSContext(),s);
                }
                double d = v.doubleValue();
                return new DateObject(getJSContext(),d);
            }

            int year = args.get(0).intValue();
            int month = args.get(1).intValue();
            int date = args.isUndefined(2) ? 1 : args.get(2).intValue();
            int hours = args.isUndefined(3) ? 0 : args.get(3).intValue();
            int minutes = args.isUndefined(4) ? 0 : args.get(4).intValue();
            int seconds = args.isUndefined(5) ? 0 : args.get(5).intValue();
            int ms = args.isUndefined(6) ? 0 : args.get(6).intValue();
            return new DateObject(getJSContext(),year,month,date,hours,minutes,seconds,ms);
        }
        
        public boolean supportCall() {
            return true;
        }

        public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this) throws InterpretException {
            return FBSUtility.wrap((new DateObject(getJSContext())).toString());
        }
    }


    ////// Methods
    static class DateMethod extends BuiltinFunction{
        int mIndex=-1;

        public DateMethod(JSContext jsContext, int index){
            super(jsContext);
            mIndex=index;
        }

        protected String[] getCallParameters() {
            switch(mIndex) {
                case 0: //toString
                    return new String[] {"():T"}; //$NON-NLS-1$
                case 1: //valueOf
                    return new String[] {"():T"}; //$NON-NLS-1$
                case 2:  // DateObject parseISO(String str)throws com.ibm.jscript.InterpretException{
                case 3:  // DateObject parse(String str){
                    return new String[] {"(str:T):Y"}; //$NON-NLS-1$
                case 4:  // long UTC(int year, int month, int date, int hours, int minutes, int seconds, int ms){
                    return new String[] {"(year:Imonth:I):J","(year:Imonth:Idate:I):J","(year:Imonth:Idate:Ihours:I):J","(year:Imonth:Idate:Ihours:Iminutes:I):J","(year:Imonth:Idate:Ihours:Iminutes:Iseconds:I):J","(year:Imonth:Idate:Ihours:Iminutes:Iseconds:Ims:I):J"}; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
                case 5:  // long getTime(){
                    return new String[] {"():J"}; //$NON-NLS-1$
                case 6:  // int getYear(){
                case 7:  // int getFullYear(){
                case 8:  // int getUTCFullYear(){
                case 9:  // int getMonth(){
                case 10:  // int getUTCMonth(){
                case 11:  // int getDate(){
                case 12:  // int getUTCDate(){
                case 13:  // int getDay(){
                case 14:  // int getUTCDay(){
                case 15:  // int getHour(){
                case 16:  // int getHours(){
                case 17:  // int getUTCHours(){
                case 18:  // int getMinute(){
                case 19:  // int getMinutes(){
                case 20:  // int getUTCMinutes(){
                case 21:  // int getSeconds(){
                case 22:  // int getSecond(){
                case 23:  // int getUTCSeconds(){
                case 24:  // int getMilliseconds(){
                case 25:  // int getUTCMilliseconds(){
                case 26:  // int getTimezoneOffset(){
                    return new String[] {"():I"}; //$NON-NLS-1$
                case 27:  // long setTime(long time){
                    return new String[] {"(time:J):J"}; //$NON-NLS-1$
                case 28:  // long setMilliseconds(int ms){
                case 29:  // long setUTCMilliseconds(int ms){
                    return new String[] {"(ms:I):J"}; //$NON-NLS-1$
                case 30:  // long setSeconds(int sec, int ms){
                case 31:  // long setUTCSeconds(int sec, int ms){
                    return new String[] {"(sec:Ims:I):J","(sec:I):J"}; //$NON-NLS-1$ //$NON-NLS-2$
                case 32:  // long setMinutes(int min, int sec, int ms){
                case 33:  // long setUTCMinutes(int min, int sec, int ms){
                    return new String[] {"(min:Isec:Ims:I):J","(min:Isec:I):J","(min:I):J"}; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                case 34:  // long setHours(int hour, int min, int sec, int ms){
                case 35:  // long setUTCHours(int hour, int min, int sec, int ms){
                    return new String[] {"(hours:Imin:Isec:Ims:I):J","(hours:Imin:Isec:I):J","(hours:Imin:I):J","(hours:I):J"}; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                case 36:  // long setDate(int date){
                case 37:  // long setUTCDate(int date){
                    return new String[] {"(date:I):J"}; //$NON-NLS-1$
                case 38:  // long setMonth(int month, int date){
                case 39:  // long setUTCMonth(int month, int date){
                    return new String[] {"(month:Idate:I):J","(month:I):J"}; //$NON-NLS-1$ //$NON-NLS-2$
                case 40:  // long setFullYear(int year, int month, int date){
                case 41:  // long setUTCFullYear(int year, int month, int date){
                    return new String[] {"(year:Imonth:Idate:I):J","(year:Imonth:I):J","(year:I):J"}; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                case 42:  // String toDateString(){
                case 43:  // String toTimeString(){
                case 44:  // String toLocaleString(){
                case 45:  // String toLocaleDateString(){
                case 46:  // String toLocaleTimeString(){
                case 47:  // String toUTCString(){
                case 48:  // String toISOString(){
                case 49:  // String toGMTString(){
                    return new String[] {"():T"}; //$NON-NLS-1$
            }
            return super.getCallParameters();
        }


        public FBSValue call(FBSValueVector args, FBSObject _this) throws InterpretException {
            return FBSUndefined.undefinedValue;
        }

        public FBSValue call(IExecutionContext context, FBSValueVector args, FBSObject _this) throws InterpretException {
            switch(mIndex){

                ///////////////////////////////////////////////////////////////
                // Standard ECMA functions
                case 0: {     // toString
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    String s = dt.toString();
                    return FBSString.get(_this.toString());
                }
                case 1: {     // valueOf
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getTime());
                }

                case 2: { // DateObject parseISO(String str)throws com.ibm.jscript.InterpretException{
                    if(args.size()>=1) {
                        String str = args.get(0).stringValue();
                        return FBSNumber.get(com.ibm.jscript.ASTTree.ASTLiteral.parseDate(str));
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 3: { // DateObject parse(String str){
                    if(args.size()>=1) {
                        String str = args.get(0).stringValue();
                        try{
                            DateFormat df = DateFormat.getInstance();
                            return FBSNumber.get(df.parse(str).getTime());
                        }catch(Exception e){
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 4: { // long UTC(int year, int month, int date, int hours, int minutes, int seconds, int ms){
                    if(args.size()>=2) {
                        int year = args.get(0).intValue();
//                        if (year>=0 && year<=99){
//                            year += 1900;
//                        }
                        int month = args.get(1).intValue();
                        int date = args.isUndefined(2) ? 1 : args.get(2).intValue();
                        int hours = args.isUndefined(3) ? 0 : args.get(3).intValue();
                        int minutes = args.isUndefined(4) ? 0 : args.get(4).intValue();
                        int seconds = args.isUndefined(5) ? 0 : args.get(5).intValue();
                        int ms = args.isUndefined(6) ? 0 : args.get(6).intValue();
                        return new DateObject(getJSContext(),DateObject.UTC(year,month,date,hours,minutes,seconds,ms));
                    }
                }

                case 5: { // long getTime(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getTime());
                }

                case 6: { // int getYear(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getYear());
                }

                case 7: { // int getFullYear(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getFullYear());
                }

                case 8: { // int getUTCFullYear(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getUTCFullYear());
                }

                case 9: { // int getMonth(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getMonth());
                }

                case 10: { // int getUTCMonth(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getUTCMonth());
                }

                case 11: { // int getDate(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getDate());
                }

                case 12: { // int getUTCDate(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getUTCDate());
                }

                case 13: { // int getDay(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getDay());
                }

                case 14: { // int getUTCDay(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getUTCDay());
                }

                case 15: { // int getHour(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getHour());
                }

                case 16: { // int getHours(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getHours());
                }

                case 17: { // int getUTCHours(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getUTCHours());
                }

                case 18: { // int getMinute(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getMinute());
                }

                case 19: { // int getMinutes(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getMinutes());
                }

                case 20: { // int getUTCMinutes(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getUTCMinutes());
                }

                case 21: { // int getSeconds(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getSeconds());
                }

                case 22: { // int getSecond(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getSecond());
                }

                case 23: { // int getUTCSeconds(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getUTCSeconds());
                }

                case 24: { // int getMilliseconds(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getMilliseconds());
                }

                case 25: { // int getUTCMilliseconds(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getUTCMilliseconds());
                }

                case 26: { // getTimezoneOffset(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSNumber.get(dt.getTimezoneOffset());
                }

                case 27: { // long setTime(long time){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        double time = args.get(0).longValue();
                        return FBSNumber.get(dt.setTime(time));
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 28: { // long setMilliseconds(int ms){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int time = args.get(0).intValue();
                        return FBSNumber.get(dt.setMilliseconds(time));
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 29: { // long setUTCMilliseconds(int ms){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int time = args.get(0).intValue();
                        return FBSNumber.get(dt.setUTCMilliseconds(time));
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 30: { // long setSeconds(int sec, int ms){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int time = args.get(0).intValue();
                        if(args.isUndefined(1)) {
                            return FBSNumber.get(dt.setSeconds(time));
                        } else {
                            int ms = args.get(1).intValue();
                            return FBSNumber.get(dt.setSeconds(time,ms));
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 31: { // long setUTCSeconds(int sec, int ms){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int time = args.get(0).intValue();
                        if(args.isUndefined(1)) {
                            return FBSNumber.get(dt.setUTCSeconds(time));
                        } else {
                            int ms = args.get(1).intValue();
                            return FBSNumber.get(dt.setUTCSeconds(time,ms));
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 32: { // long setMinutes(int min, int sec, int ms){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int min = args.get(0).intValue();
                        if(args.isUndefined(1)) {
                            return FBSNumber.get(dt.setMinutes(min));
                        } else {
                            int sec = args.get(1).intValue();
                            if(args.isUndefined(2)) {
                                return FBSNumber.get(dt.setMinutes(min,sec));
                            } else {
                                int ms = args.get(2).intValue();
                                return FBSNumber.get(dt.setMinutes(min,sec,ms));
                            }
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 33: { // long setUTCMinutes(int min, int sec, int ms){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int min = args.get(0).intValue();
                        if(args.isUndefined(1)) {
                            return FBSNumber.get(dt.setUTCMinutes(min));
                        } else {
                            int sec = args.get(1).intValue();
                            if(args.isUndefined(2)) {
                                return FBSNumber.get(dt.setUTCMinutes(min,sec));
                            } else {
                                int ms = args.get(2).intValue();
                                return FBSNumber.get(dt.setUTCMinutes(min,sec,ms));
                            }
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 34: { // long setHours(int hour, int min, int sec, int ms){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int hour = args.get(0).intValue();
                        if(args.isUndefined(1)) {
                            return FBSNumber.get(dt.setHours(hour));
                        } else {
                            int min = args.get(1).intValue();
                            if(args.isUndefined(2)) {
                                return FBSNumber.get(dt.setHours(hour,min));
                            } else {
                                int sec = args.get(2).intValue();
                                if(args.isUndefined(3)) {
                                    return FBSNumber.get(dt.setHours(hour,min,sec));
                                } else {
                                    int ms = args.get(3).intValue();
                                    return FBSNumber.get(dt.setHours(hour,min,sec,ms));
                                }
                            }
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 35: { // long setUTCHours(int hour, int min, int sec, int ms){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int hour = args.get(0).intValue();
                        if(args.isUndefined(1)) {
                            return FBSNumber.get(dt.setUTCHours(hour));
                        } else {
                            int min = args.get(1).intValue();
                            if(args.isUndefined(2)) {
                                return FBSNumber.get(dt.setUTCHours(hour,min));
                            } else {
                                int sec = args.get(2).intValue();
                                if(args.isUndefined(3)) {
                                    return FBSNumber.get(dt.setUTCHours(hour,min,sec));
                                } else {
                                    int ms = args.get(3).intValue();
                                    return FBSNumber.get(dt.setUTCHours(hour,min,sec,ms));
                                }
                            }
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 36: { // long setDate(int date){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int time = args.get(0).intValue();
                        return FBSNumber.get(dt.setDate(time));
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 37: { // long setUTCDate(int date){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int time = args.get(0).intValue();
                        return FBSNumber.get(dt.setUTCDate(time));
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 38: { // long setMonth(int month, int date){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int month = args.get(0).intValue();
                        if(args.isUndefined(1)) {
                            return FBSNumber.get(dt.setMonth(month));
                        } else {
                            int date = args.get(1).intValue();
                            return FBSNumber.get(dt.setMonth(month,date));
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 39: { // long setUTCMonth(int month, int date){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int month = args.get(0).intValue();
                        if(args.isUndefined(1)) {
                            return FBSNumber.get(dt.setUTCMonth(month));
                        } else {
                            int date = args.get(1).intValue();
                            return FBSNumber.get(dt.setUTCMonth(month,date));
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 40: { // long setFullYear(int year, int month, int date){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int year = args.get(0).intValue();
                        if(args.isUndefined(1)) {
                            return FBSNumber.get(dt.setFullYear(year));
                        } else {
                            int month = args.get(1).intValue();
                            if(args.isUndefined(2)) {
                                return FBSNumber.get(dt.setFullYear(year,month));
                            } else {
                                int date = args.get(2).intValue();
                                return FBSNumber.get(dt.setFullYear(year,month,date));
                            }
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 41: { // long setUTCFullYear(int year, int month, int date){
                	checkDate(context,_this);
                    if(args.size()>=1) {
                        DateObject dt = (DateObject)_this;
                        int year = args.get(0).intValue();
                        if(args.isUndefined(1)) {
                            return FBSNumber.get(dt.setUTCFullYear(year));
                        } else {
                            int month = args.get(1).intValue();
                            if(args.isUndefined(2)) {
                                return FBSNumber.get(dt.setUTCFullYear(year,month));
                            } else {
                                int date = args.get(2).intValue();
                                return FBSNumber.get(dt.setUTCFullYear(year,month,date));
                            }
                        }
                    }
                    return FBSUndefined.undefinedValue;
                }

                case 42: { // String toDateString(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSString.get(dt.toDateString());
                }

                case 43: { // String toTimeString(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSString.get(dt.toTimeString());
                }

                case 44: { // String toLocaleString(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSString.get(dt.toLocaleString());
                }

                case 45: { // String toLocaleDateString(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSString.get(dt.toLocaleDateString());
                }

                case 46: { // String toLocaleTimeString(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSString.get(dt.toLocaleTimeString());
                }

                case 47: { // String toUTCString(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSString.get(dt.toUTCString());
                }

                case 48: { // String toISOString(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSString.get(dt.toISOString());
                }

                case 49: { // String toGMTString(){
                	checkDate(context,_this);
                    DateObject dt = (DateObject)_this;
                    return FBSString.get(dt.toGMTString());
                }
            }
            throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Date function not found")); //$NLS-DatePrototype.DatePrototype.StringFuncNotFound.Exception-1$
        }
    }

    private static void checkDate(IExecutionContext context, FBSObject _this) throws InterpretException{
        if(!(_this instanceof DateObject)) {
            throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Object is not a date, {0}",FBSUtility.getDisplayType(_this))); //$NLS-DatePrototype.DatePrototype.NotADateType.Exception-1$
        }
    }
}