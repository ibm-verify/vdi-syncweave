/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSValue;

public class ASTWhile extends ASTNode implements ILabelledStatement {
    public static final int CONDITION=0;
    public static final int STATEMENT=1;

    private ASTNode conditionNode;
    private ASTNode statementNode;
    private String labelName;

    public ASTWhile() {
    }
    
	public void setLabelName(String label) {
		this.labelName = label;
	}

    public void add(ASTNode cond, ASTNode statement){
        conditionNode=assignParent(cond);
        statementNode=assignParent(statement);
    }

    public int getSlotCount(){
        return 2;
    }

    public ASTNode readSlotAt(int index){
        switch(index){
            case CONDITION: return conditionNode;
            case STATEMENT: return statementNode;
        }
        return null;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result ) throws JavaScriptException {
        try {
            FBSValue v=FBSUndefined.undefinedValue;
            while(true) {
                // Evaluate the condition and stop the loop if false
                if(!conditionNode.interpret(this,context,result)) {
                	return false;
                }
                if(!result.getFBSValue().booleanValue()) {
                    break;
                }

                // Evaluate the statement
                if(!statementNode.interpret(this, context, result)) {
                	if(result.isBreakSignal()) {
                        String label = context.getProgramContext().getLoopLabel();
                    	if(!StringUtil.isEmpty(label)) {
                    		if(!StringUtil.equals(label,labelName)) {
                    			return false;
                    		}
                    	}
                        // Break the main loop
                    	result.resetSignal();
                        break;
                	} else if(result.isBreakSignal()) {
                        String label = context.getProgramContext().getLoopLabel();
                    	if(!StringUtil.isEmpty(label)) {
                    		if(!StringUtil.equals(label,labelName)) {
                    			return false;
                    		}
                    	}
                        // Continue the main loop
                    	result.resetSignal();
                        continue;
                	} else {
                		return false;
                	}
                }
                if (result.getFBSValue()!=null) v=result.getFBSValue();
            }
            result.setNormal(v);
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
	return v.visitWhile(this, param);
    }
}
