/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript;

/**
 * JavaScript Formula Interface.</p>
 * FlowBuilder JavaScript implementation is a compiler which first compiles the
 * the JavaScript code to an intermediate language, and then interprets this
 * compiled form when needed.<br>
 * This interface points to a compiled JavaScript code, and is used to actually
 * execute the code. To compile JavaScript code, see JavaScriptEngine object.
 * @see JavaScriptEngine
 */
public interface IFormula {

    /**
     * Get the JavaScript text for this formula.</p>
     * This method return the JavaScript source code for this compiled formula.
     * @return a String representing the JavaScript text
     */
    public String getExpr();

    /**
     * Check if this formula evaluate as a constant.</p>
     * A formula evaluates as a constant if it does not depend on any external
     * values. For example, "1+2" evaluates as a constant, while "a+2" does'nt.
     * @return true if it evaluates as a constant
     */
    public boolean isEvaluateConstant();

    /**
     * Evaluate the global formula and returns the result.</p>
     * This method uses a global object to carry properties that are globally exposed
     * when the formula is evaluated. This IValue must be either null, or an object
     * with some properties set.
     * @param globalObject object having the global properties
     * @throws InterpretException if a error occurred
     * @return the result of the evaluation
     */
    public IValue execute(IValue globalObject) throws InterpretException;
    public IValue execute() throws InterpretException;

    /**
     * Evaluate a function within the formula and returns the result.</p>
     * This method uses a global object to carry properties that are globally exposed
     * when the formula is evaluated. This IValue must be either null, or an object
     * with some properties set.
     * @param globalObject object having the global properties
     * @param functionName the function to evaluate
     * @param args object having the global properties
     * @throws InterpretException if a error occurred
     * @return the result of the evaluation
     */
    public IValue callFunction(IValue globalObject, String functionName, IValue[] args) throws InterpretException;
    public IValue callFunction(String functionName, IValue[] args) throws InterpretException;
    public IValue callFunction(String functionName) throws InterpretException;
}
