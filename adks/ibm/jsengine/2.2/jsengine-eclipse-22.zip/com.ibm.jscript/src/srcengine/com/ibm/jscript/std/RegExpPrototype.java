/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.BuiltinConstructor;
import com.ibm.jscript.types.BuiltinFunction;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSNull;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.FBSValueVector;


/**
 * This class allows to manipulate standard JavaScript Array objects.
 * @fbscript Array
 */
public class RegExpPrototype extends AbstractPrototype {

    public RegExpPrototype(JSContext jsContext){
        super(jsContext);
        int attrib=FBSObject.P_NOENUM;
        createConstructor(attrib,new RegExpConstructor(jsContext,this)); //$NON-NLS-1$
        createMethod("toString", attrib, new RegExpMethod(jsContext,0)); //$NON-NLS-1$
        createMethod("valueOf", attrib, new RegExpMethod(jsContext,1)); //$NON-NLS-1$
        createMethod("exec", attrib, new RegExpMethod(jsContext,2)); //$NON-NLS-1$
        createMethod("match", attrib, new RegExpMethod(jsContext,3)); //$NON-NLS-1$
        createMethod("split", attrib, new RegExpMethod(jsContext,4)); //$NON-NLS-1$
        createMethod("search", attrib, new RegExpMethod(jsContext,5)); //$NON-NLS-1$
        createMethod("replace", attrib, new RegExpMethod(jsContext,6)); //$NON-NLS-1$
        createMethod("compile", attrib, new RegExpMethod(jsContext,7)); //$NON-NLS-1$
        createMethod("test", attrib, new RegExpMethod(jsContext,8)); //$NON-NLS-1$
    }
    public String getTypeAsString(){
        return "RegExp"; //$NON-NLS-1$
    }

    ////// Constructor
    static class RegExpConstructor extends BuiltinConstructor{
        public RegExpConstructor(JSContext jsContext, FBSDefaultObject prototype){
            super(jsContext,prototype,"RegExp"); // $NON-NLS-1$
        }
        public boolean hasInstance(FBSValue v){
            return v instanceof RegExpObject;
        }
        public boolean supportConstruct(){
            return true;
        }
        protected String[] getConstructorParameters() {
            return new String[] {"(regexp:T)","(regexp:Tmodifiers:T)"}; //$NON-NLS-1$ //$NON-NLS-2$
        }
        public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
            if (args.size() == 1) {
                return new RegExpObject(getJSContext(),args.get(0).stringValue());
            } else if (args.size() == 2) {
                return new RegExpObject(getJSContext(),args.get(0).stringValue(), args.get(1).stringValue());
            } else if (args.size() == 0) {
                return new RegExpObject(getJSContext(),"");
            }
            throw new InterpretException(null,"Invalid number of arguments"); //$NLS-RegExpObject.RegExpObject.InvalidNumArgs.Exception-1$
        }
        public boolean supportCall() {
            return true;
        }
        public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this) throws JavaScriptException {
            if(args.getCount()==2) {
                FBSValue v1 = args.get(0);
                if( v1.isJavaObject() ) {
                    if( v1.toJavaObject() instanceof RegExpObject ) {
                        FBSValue v2 = args.get(0);
                        if(v2.isUndefined()) {
                            return v1;
                        }
                    }
                }
            }
            return construct(context,args);
        }
        protected String[] getCallParameters() {
            return new String[] {"(regexp:T):R","(regexp:Tmodifiers:T):R"}; //$NON-NLS-1$ //$NON-NLS-2$
        }
    }


    static class RegExpMethod extends BuiltinFunction{
        int mIndex=-1;

        public RegExpMethod(JSContext jsContext, int index){
            super(jsContext);
            mIndex=index;
        }

        protected String[] getCallParameters() {
            switch(mIndex) {
            case 0: //toString
            case 1: //valueOf
                return new String[] {"():T"}; //$NON-NLS-1$
            case 2: //exec
            case 3: //match
                return new String[] {"(string:T):[T"}; //$NON-NLS-1$
            case 4: //split
                return new String[] {"(separator:Tlimit:I):[T","(separator:Rlimit:I):[T"}; //$NON-NLS-1$ //$NON-NLS-2$
            case 5: //search
                return new String[] {"(string:T):I"}; //$NON-NLS-1$
            case 6: //replace
                return new String[] {"(regExp:RrepStr:T):T", "(regExp:TrepStr:T):T"}; //$NON-NLS-1$ //$NON-NLS-2$
            case 8: //test
                return new String[] {"(string:T):Z"}; //$NON-NLS-1$
            case 7: //compile
                return new String[] {"(re:Tflags:T):T"}; //$NON-NLS-1$ //$NON-NLS-2$
            }
            return super.getCallParameters();
        }
        
        public FBSValue call(FBSValueVector args, FBSObject _this) throws JavaScriptException {
            return FBSUndefined.undefinedValue;
        }

        public FBSValue call(IExecutionContext context, FBSValueVector args, FBSObject _this) throws JavaScriptException {
            RegExpObject re = (RegExpObject)_this;
            switch(mIndex){
            
                ///////////////////////////////////////////////////////////////
                // Standard ECMA functions
                case 0:       // toString
                case 1:       // valueOf
                    return re.getFBSString();

                case 2:       // exec
                case 3:       // match
                case 4:       // split
                case 5:       // search
                case 6:       // replace
                case 7:       // compile
                case 8:       // test
                    if(!(_this instanceof RegExpObject)) {
                        throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Object is not a RegExpObject, {0}",FBSUtility.getDisplayType(_this))); // $NLS-RegExpPrototype.TypeErrorObjectisnotaRegExpObject-1$
                    }
                    
                    String jstring = ""; //$NON-NLS-1$
                    if (args.size()>=1) {
                        jstring = args.get(0).stringValue();
                    }
                    if (mIndex == 2 || mIndex == 3) {
                        ArrayObject v = re.exec(jstring);
                        if (v == null) {
                            return FBSNull.nullValue;
                        }
                        return v;
                    }
                    else if (mIndex == 8)
                        return re.test(jstring);
                    else if (mIndex == 4)
                        return new ArrayObject(getJSContext(),re.split(jstring));
                    else if (mIndex == 5)
                        return re.search(jstring);
                    else if (mIndex == 6)
                        return re.replace(args.get(0).stringValue(), args.get(1).stringValue());
                    else if (mIndex == 7) {
                        return re.compile(args.get(0).stringValue(), args.get(1).stringValue());
                    }
            }
            throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Regular expression function not found: index={0}s", Integer.toString(mIndex))); // $NLS-RegExpPrototype.RegExpfunctionnotfoundindex0s-1$
        }
    }
}