/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSReference;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.JavaAccessObject;

/**
 * Javascript String object.
 */
public class StringObject extends AbstractPrimitiveObject implements Externalizable {
    
    private static final String PROP_LENGTH = "length"; //$NON-NLS-1$
    
    private FBSString primitive;

	// Serialization only ctor
	public StringObject() {
        super(JSContext.getStaticContext(),JSContext.getStaticContext().getRegistry().stringPrototype);
    }

	// Prototype only ctor
	protected StringObject(JSContext jsContext, FBSDefaultObject proto) {
        super(jsContext,proto);
        this.primitive = FBSString.emptyString;
    }

	public StringObject(JSContext jsContext, FBSString str) {
        super(jsContext,jsContext.getRegistry().stringPrototype);
        this.primitive = str;
    }
    ////// Constructor
//    public boolean supportConstruct(){
//        return true;
//    }
//    public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
//        if(args.getCount()==0) {
//            return new StringObject(getJSContext(),FBSString.emptyString);
//        }
//        FBSString s = args.get(0).toFBSString();
//        return new StringObject(getJSContext(),s);
//    }
//
//    
//    public boolean supportCall() {
//        return true;
//    }
//    public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this) throws JavaScriptException {
//        if(args.getCount()==0) {
//            return FBSString.emptyString;
//        }
//        return args.get(0).toFBSString();
//    }
//    protected String[] getCallParameters() {
//        return new String[] {"()","(value:T)"}; //$NON-NLS-1$ //$NON-NLS-2$
//    }



    public boolean equals( Object o ) {
        if( o instanceof FBSValue ) {
            FBSValue w = (FBSValue)o;
            return primitive.stringValue()==w.stringValue();
        }
        if( o instanceof FBSString ) {
            FBSString w = (FBSString)o;
            return primitive.stringValue()==w.stringValue();
        }
        return false;
    }

    public String getTypeAsString(){
        return "String"; //$NON-NLS-1$
    }

    public FBSValue getPrimitiveValue() {
        return primitive;
    }
    
    public FBSString getFBSString() {
        return primitive;
    }

    public boolean isJavaAssignableTo(Class c) {
        return c.isAssignableFrom(String.class) || c==StringObject.class;
    }

    public boolean hasCustomProperty(String name){
        if( name.equals(PROP_LENGTH) ){
            return true;
        }
        return super.hasCustomProperty(name);
    }

    public FBSValue get(String name) throws InterpretException {
        if( name.equals(PROP_LENGTH) ){
            return FBSUtility.wrap(primitive.stringValue().length());
        }
        return super.get(name);
    }

    public void put(String name , FBSValue value) throws InterpretException {
        if( name.equals(PROP_LENGTH) ){
            return;
        }
        super.put(name,value);
    }
    
    public boolean delete(String name){
        if( name.equals(PROP_LENGTH) ){
            return false;
        }
        return super.delete(name);
    }

    public Object toJavaObject(Class c){
        if (c==null || c.isAssignableFrom(String.class) ) {
            return this.primitive.stringValue();
        }
        if( c==StringObject.class ) { // ??? PHIL: I think this is not needed....
            return this;
        }
        throw new RuntimeException(StringUtil.format("Can't convert {0} to {1}", this.getClass().getName(), c.getName())); // $NLS-StringObject.Cantconvert0to1-1$
    }

    public FBSReference getPropertyReference(String name) throws InterpretException {
    	FBSReference ref = super.getPropertyReference(name);
    
    	// if there is not property assigned to the object, look at a Java String property
    	if(ref==null) {
    		ref = JavaAccessObject.getJavaPropertyReference(getJSContext(), String.class, this, stringValue(), name);
    	}
    	return ref;
    }

    // ========================================================================
    // Java Object IO.
    // ========================================================================

    public void readExternal( ObjectInput in ) throws IOException {
        super.readExternal(in);
        primitive = FBSString.get(in.readUTF()); 
    }

    public void writeExternal( ObjectOutput out ) throws IOException {
        super.writeExternal(out);
        out.writeUTF(primitive.stringValue());
    }
}
