/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.debug;

import java.util.ArrayList;

import com.ibm.commons.util.StringUtil;

/* 
 * This class can convert an ArrayList to a String and then back again.
 * It does so by using a simple delimiter.  This class exists on both the 
 * Client and Server...so don't modify unless you are modifying in both 
 * places.
 */

public final class ArrayListUtil {
    
    //This is the String that denotes the start of a Variable Section in the 
    //Array of Strings.
    public static String VARIABLE_SECTION        = "__VARSECTION__"; //$NON-NLS-1$
    
    // Delimiter is just a semicolon, and the escapedDelimiter is just a made-up
    // set of characters (%IoBoM%) that is very very unlikely to appear in the user data:
    private static char   fDelimiter              = ';';
    private static char[] fEscapedDelimiter       = {'%','I','o','B','o','M','%'};
    private static String fEscapedDelimiterString = new String(fEscapedDelimiter);
    private static String fDelimiterString        = StringUtil.toString(fDelimiter);
    
    public static String arrayListToString(ArrayList theList) {
        //Take the list size and estimate that each entry is 15 characters long
        //to create a StringBuffer with a reasonable starting size:
        int listSize = theList.size();
        StringBuffer theString = new StringBuffer(listSize*15);
        
        for (int i=0;i<listSize;i++){
            theString.append(escape((String)theList.get(i)) + fDelimiter);
        }
        
        if ( Util.traceEnabled() ){
            Util.trace( "arrayListToString", theString.toString() ); // $NON-NLS-1$
        }
        return theString.toString();
    }
    
    public static ArrayList stringToArrayList(String theString) {
        //Take the string length and estimate that every 15 characters is 
        //a String to get an ArrayList with a reasonable starting capacity:
        int stringLength=theString.length();
        ArrayList theList = new ArrayList(stringLength/15);
        
        int delimiter1 = 0;
        int delimiter2 = 0;
        for (int i=0;i<stringLength;i++) {
            if (theString.charAt(i) == fDelimiter) {
                delimiter2 = i;
                theList.add(unescape(theString.substring(delimiter1, delimiter2)));
                delimiter1 = delimiter2+1;
            }
        }
        return theList;
    }
    
    /*
     * There should be very few semicolons in the user code, so this method
     * (and unescape) should rarely have to do anything, so while there are ways 
     * to optimize them, they're likely sufficient
     */
    private static String escape(String theString) {
        if (theString == null)
            return ""; //$NON-NLS-1$
        int stringLength = theString.length();
        //Here we walk through each char looking for the delimiter.  If we 
        //don't find one, then we don't pay the replaceAll regex performance cost:
        for (int i=0; i<stringLength; i++)
            if (theString.charAt(i) == fDelimiter)
                return StringUtil.replace(theString,StringUtil.toString(fDelimiter), new String(fEscapedDelimiter));
        return theString;
    }
    
    private static String unescape(String theString) {
        if (theString == null)
            return ""; //$NON-NLS-1$
        int stringLength = theString.length();
        //Here we walk through each char looking for the escapedDelimiter.  
        //If we find the first 3 characters, then we'll pay the replaceAll 
        //regex performance cost:
        for (int i=0; i<stringLength; i++)
            if (theString.charAt(i) == fEscapedDelimiter[0])
                if (theString.charAt(i+1) == fEscapedDelimiter[1])
                    if (theString.charAt(i+2) == fEscapedDelimiter[2])
                        StringUtil.replace(theString, fEscapedDelimiterString, fDelimiterString);
                    
                        
                    
        return theString;
    }
    
    /*
    public static void main(String args[]) {
        ArrayList testData = new ArrayList();
        testData.add("Hello");
        testData.add("123");
        testData.add("null");
        testData.add("ABC;DEF;GHI");
        testData.add("");
        testData.add("My Name is \" Jeff \"");
        testData.add("Bye");
        
        System.out.println("Original Array Elements:");
        for (int i=0; i<testData.size(); i++) 
            System.out.println(" - " + (String)testData.get(i));
            
        String testString = arrayListToString(testData);
        System.out.println("\nGenerated String:\n - " + testString);

        ArrayList newData = stringToArrayList(testString);
        System.out.println("\nNew Array Elements:"); // $NON-NLS-1$
        for (int i=0; i<newData.size(); i++) 
            System.out.println(" - " + (String)newData.get(i));
    }
    */
}
