/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import com.ibm.jscript.InterpretException;

/**
 * Interface implemented by all 'indexable' array.
 * This is implemented by std javascript arrays, as well as by java array wrappers.
 */
public interface IFBSArray {

    public int getArrayLength();
    public FBSValue getArrayValue(int index) throws InterpretException;
    public void setArrayValue(int index, FBSValue value) throws InterpretException;
}
