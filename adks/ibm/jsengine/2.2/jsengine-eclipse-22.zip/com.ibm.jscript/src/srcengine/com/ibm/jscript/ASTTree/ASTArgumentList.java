/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSReferenceByName;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValueVector;

public class ASTArgumentList extends ASTNode {
	
    private NodeVector nodes= new NodeVector();

    public ASTArgumentList() {
    }

    public int getSlotCount(){
        return nodes.size();
    }

    public ASTNode readSlotAt(int index){
        return nodes.get(index);
    }

    public void add(ASTNode node){
        nodes.add(assignParent(node));
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            FBSValueVector args=interpretArguments(caller, context, result);
            if(args==null) {
            	return false;
            }
            result.setNormal(FBSUtility.wrapAsObject(context.getJSContext(),args));
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public FBSValueVector interpretArguments(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        int count = nodes.size();
        if(count>0) {
        	try {
		        FBSValueVector args=new FBSValueVector(count);
		        for(int i=0;i<count;i++){
		            ASTNode node=nodes.get(i);
		            if(!node.interpret(this,context,result)) {
		            	return null;
		            }
		            args.add(result.getFBSValue());
		        }
		        return args;
	        } catch( InterpretException ie ) {
	            throw ie.fillException(context,this);
	        }
        }
        return FBSValueVector.emptyVector;
    }

    // Evaluate the arguments but returns a JavaPackage without emitting an error
    // This is used by the importPackage() method
    public void interpretJavaPackage(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            int count = nodes.size();
            FBSValueVector args=new FBSValueVector(count);
            for(int i=0;i<count;i++){
                ASTNode node=nodes.get(i);
                node.interpret(this,context,result);
                if(result.isReference() && result.getReference() instanceof FBSReferenceByName.JavaPackageVariable) {
                	// Push the JavaPackage to the args
                	args.add(((FBSReferenceByName.JavaPackageVariable)result.getReference()).getJavaPackage(context.getJSContext()));
                } else {
                	// Just the regular behavior, evaluate the value
                	args.add(result.getFBSValue());
                }
            }
            result.setNormal(FBSUtility.wrapAsObject(context.getJSContext(),args));
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitArgumentList(this, param);
    }
}
