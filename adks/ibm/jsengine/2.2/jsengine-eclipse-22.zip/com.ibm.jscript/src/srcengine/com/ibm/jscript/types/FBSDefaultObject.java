/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2008                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;

public abstract class FBSDefaultObject extends FBSObject {

    private static final String CONSTRUCTOR_NAME = "constructor"; // $NON-NLS-1$
    
    
    public static class JSProperty extends FBSReference {
        
        private JSProperty next;
        private JSProperty prev;
        
        private long hashCode;
        private String name;
        private int attributes;
        private FBSValue value;
        
        JSProperty(FBSDefaultObject base, long hashCode, String name, int attributes, FBSValue value) {
            super(base);
            this.hashCode = hashCode;
            this.name = name;
            this.attributes = attributes;
            this.value = value;
        }
        public String getPropertyName() {
            return name;
        }
        
        public FBSValue getValue() {
            return value;
        }
        
        public void putValue(FBSValue value) {
            if(!isReadOnly()) {
                this.value = value;
            }
        }
        public int getAttributes() {
            return attributes;
        }

        public boolean isReadOnly(){
            return (attributes & P_READONLY )!=0;
        }

        public boolean isNoDelete(){
            return (attributes & P_NODELETE )!=0;
        }

        public boolean isNoEnum(){
            return (attributes & P_NOENUM)!=0;
        }

        public boolean isTransient(){
            return (attributes & P_TRANSIENT)!=0;
        }

        public boolean isInternal(){
            return (attributes & P_INTERNAL )!=0;
        }

        public boolean isHidden(){
            return (attributes & P_HIDDEN )!=0;
        }

        public void setReadOnly(boolean readonly){
            if (readonly){
                attributes = (attributes | P_READONLY);
            }else{
                attributes = (attributes & ~P_READONLY);
            }
        }

        public void setNoDelete(boolean nodelete){
            if (nodelete){
                attributes = (attributes | P_NODELETE);
            }else{
                attributes = (attributes & ~P_NODELETE);
            }
        }

        public void setNoEnum(boolean noenum){
            if (noenum){
                attributes = (attributes | P_NOENUM);
            }else{
                attributes = (attributes & ~P_NOENUM);
            }
        }

        public void setInternal(boolean internal){
            if (internal){
                attributes = (attributes | P_INTERNAL);
            }else{
                attributes = (attributes & ~P_INTERNAL);
            }
        }

        public void setHidden(boolean hidden){
            if (hidden){
                attributes = (attributes | P_HIDDEN);
            }else{
                attributes = (attributes & ~P_HIDDEN);
            }
        }
    }
    
    
    // Property management is no longer an intermediate MAP object
    private static final int MAP_LENGTH = 13;
    
    private int propCount;
    private JSProperty[] propEntries = new JSProperty[MAP_LENGTH];
    
    public final int propSize() {
        return propCount;
    }
    
    public final JSProperty propGetEntry(String key) {
        long h = key.hashCode();
        int slot = (((int)h) & 0x7FFFFFFF) % MAP_LENGTH;
        for( JSProperty e=propEntries[slot]; e!=null; e=e.next ) {
            if( e.hashCode==h && e.name.equals(key) ) {
                return e;
            }
        }
        return null;
    }
    
    public final FBSValue propGet(String key) {
        JSProperty p = propGetEntry(key);
        return p!=null ? p.value : null;
    }
    
    public final void propPut( String key, FBSValue value ) {
        long h = key.hashCode();
        int slot = (((int)h) & 0x7FFFFFFF) % MAP_LENGTH;
        // Search for an existing property
        for( JSProperty e=propEntries[slot]; e!=null; e=e.next ) {
            if( e.hashCode==h && e.name.equals(key) ) {
                if(e.isReadOnly()) {
                    return; // Don't update it
                }
                e.value = value;
                //e.attributes = P_NONE;
                return;
            }
        }
        // Insert the new property
        JSProperty p = new JSProperty(FBSDefaultObject.this, h,key,0,value);
        if(propEntries[slot]!=null) {
            propEntries[slot].prev = p;
            p.next = propEntries[slot];
        }
        propEntries[slot] = p;
        propCount++;
    }
    
    public final boolean propCreate( String key, int attributes, FBSValue value ) {
        long h = key.hashCode();
        int slot = (((int)h) & 0x7FFFFFFF) % MAP_LENGTH;
        // Search for an existing property, and ignore if it already exists
        for( JSProperty e=propEntries[slot]; e!=null; e=e.next ) {
            if( e.hashCode==h && e.name.equals(key) ) {
                return false;
            }
        }
        // Insert the new property
        JSProperty p = new JSProperty(FBSDefaultObject.this,h,key,attributes,value);
        if(propEntries[slot]!=null) {
            propEntries[slot].prev = p;
            p.next = propEntries[slot];
        }
        propEntries[slot] = p;
        propCount++;
        return true;
    }
    
    // Like propCreate, but can change an existing property
    // Used by the ExecutionScope for initializing the var & functions with
    // the P_NODELETE flag
    public final void propInitialize( String key, int attributes, FBSValue value ) {
        long h = key.hashCode();
        int slot = (((int)h) & 0x7FFFFFFF) % MAP_LENGTH;
        // Search for an existing property, and change it if it already exists
        for( JSProperty e=propEntries[slot]; e!=null; e=e.next ) {
            if( e.hashCode==h && e.name.equals(key) ) {
            	if(value!=FBSUndefined.undefinedValue) {
            		e.value = value;
            		e.attributes = attributes;
            	}
                return;
            }
        }
        // Insert the new property
        JSProperty p = new JSProperty(FBSDefaultObject.this,h,key,attributes,value);
        if(propEntries[slot]!=null) {
            propEntries[slot].prev = p;
            p.next = propEntries[slot];
        }
        propEntries[slot] = p;
        propCount++;
        return;
    }

    public final void propRemove( String key ) {
        long h = key.hashCode();
        int slot = (((int)h) & 0x7FFFFFFF) % MAP_LENGTH;
        // Search for an existing property
        for( JSProperty e=propEntries[slot]; e!=null; e=e.next ) {
            if( e.hashCode==h && e.name.equals(key) ) {
                if(e.prev!=null) {
                    e.prev.next = e.next;
                } else {
                    propEntries[slot] = e.next;
                }
                if(e.next!=null) {
                    e.next.prev = e.prev;
                }
                propCount--;
                return;
            }
        }
    }

    public final void propCleanNonJSProperties() {
    	for( int slot=0; slot<MAP_LENGTH; slot++ ) {
	        for( JSProperty e=propEntries[slot]; e!=null; e=e.next ) {
	        	FBSValue v = e.value;
	            if( v.isJavaObject() ) {
	            	try {
		                Object o = e.value.toJavaObject();
		                if(o instanceof String) {
		                	continue;
		                }
		                if(o instanceof Number) {
		                	continue;
		                }
		                if(o instanceof Boolean) {
		                	continue;
		                }
		                if(o instanceof Date) {
		                	continue;
		                }
	            	} catch(InterpretException ex) {}
	                e.value = FBSUndefined.undefinedValue;
	            }
	        }
    	}
    }
    
    public final Iterator<JSProperty> propEntryIterator() {
        return new MapIterator(this);
    }
        
    private static class MapIterator implements Iterator<JSProperty> {
        private FBSDefaultObject map;
        private int currentSlot;
        private JSProperty currentProperty;
        MapIterator(FBSDefaultObject map) {
            findFirstProperty(map);
        }
        private void findFirstProperty(FBSDefaultObject map) {
            while(map!=null) {
                this.map = map;
                for( int i=0; i<map.propEntries.length; i++ ) {
                    if(map.propEntries[i]!=null) {
                        currentSlot = i;
                        currentProperty = map.propEntries[i]; 
                        return;
                    }
                }
                map = map.prototype;
            }
        }
        public boolean hasNext() {
            return currentProperty!=null;
        }
        public JSProperty next() {
            if(currentProperty!=null) {
                JSProperty p = currentProperty;
                currentProperty = currentProperty.next;
                if(currentProperty==null) {
                    for( currentSlot++; currentSlot<map.propEntries.length; currentSlot++ ) {
                        if(map.propEntries[currentSlot]!=null) {
                            currentProperty = map.propEntries[currentSlot]; 
                            break;
                        }
                    }
                    if(currentProperty==null) {
                        findFirstProperty(map.prototype);
                    }
                }
                return p;
            }
            return null;
        }
        public void remove() {}
    }
    
    
    
    private FBSDefaultObject prototype;

    public FBSDefaultObject(JSContext jsContext) {
        super(jsContext);
    }

    public FBSDefaultObject(JSContext jsContext, FBSDefaultObject prototype) {
        this(jsContext,prototype,true);
    }

    public FBSDefaultObject(JSContext jsContext, FBSDefaultObject prototype, boolean addPrototype) {
        super(jsContext);
        this.prototype = prototype;
        if(addPrototype) {
            if(prototype==null) {
                createProperty("prototype",FBSObject.P_NODELETE|FBSObject.P_NOENUM|FBSObject.P_READONLY,FBSNull.nullValue); //$NON-NLS-1$
            } else {
                createProperty("prototype",FBSObject.P_NODELETE|FBSObject.P_NOENUM|FBSObject.P_READONLY,prototype); //$NON-NLS-1$
            }
        }
    }

    public boolean isJSObject(){
       return true;
    }

    public String getTypeAsString(){
        return "Object"; //$NON-NLS-1$
    }

    public FBSType getFBSType(JSContext context) {
// PHIL: publishing the prototype is not sufficient for global objects like Math
//      FBSObject o = getPrototype();
//      if(o!=null) {
//          return FBSType.getJSObject(o);
//      }
//        return FBSType.jsObjectType;
        return FBSType.getJSObject(this);
    }

    public IValues getValues(){
        return new ObjectValues();
    }
    private class ObjectValues implements FBSValue.IValues{
        java.util.Iterator<?> it;
        private ObjectValues() {
            this.it = getPropertyKeys();
        }
        public boolean hasNext() {
            return it.hasNext();
        }
        public FBSValue next() {
            String o = (String)it.next();
            return o!=null ? (FBSValue)FBSUtility.wrap(o) : (FBSValue)FBSNull.nullValue;
        }
    }

    public final FBSDefaultObject getPrototype(){
        return prototype;
    }

    public FBSValue construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
        throw new InterpretException(null,"Cannot create an instance of this object or class"); // $NLS-FBSDefaultObject.constructisnotsupportedforthisobj-1$
    }

    public boolean supportConstruct(){
        return false;
    }

    public boolean hasInstance(FBSValue v){
        return false;
    }

    public FBSValue call(IExecutionContext context, FBSValueVector args, FBSObject _this) throws JavaScriptException {
        return null;
    }

    public boolean supportCall(){
        return false;
    }

    public boolean isJavaNative(){
       return false;
    }

    public boolean isJavaAssignableTo(Class c) {
        if( c==null || c.isAssignableFrom(Map.class) ) {
            return true;
        }
        if( c.isAssignableFrom(FBSDefaultObject.class) ) {
            return true;
        }
        return false;
    }

    public Object toJavaObject(Class _class)throws InterpretException{
        if( _class==null || _class.isAssignableFrom(FBSDefaultObject.class) ) {
            return this;
        }
        if( _class.isAssignableFrom(Map.class) ) {
            // Get the list of properties
            HashMap map = new HashMap();
            for( Iterator it=propEntryIterator(); it.hasNext(); ) {
                JSProperty e = (JSProperty)it.next();
                if(!e.isNoEnum()) {
	                FBSValue value = (FBSValue)e.getValue();
	                if( value.isPrimitive() ) {
	                    map.put( e.getPropertyName(), value.stringValue() );
	                } else if( value.isJavaNative() ) {
	                    map.put( e.getPropertyName(), value.toJavaObject(Object.class) );
	                }
                }
            }
            return map;
        }
        throw new InterpretException(null,"Can't convert {0} to {1}", this.getClass().getName(), _class.getName()); // $NLS-FBSDefaultObject.Cantconvert0to1-1$
    }

    /**
     * try to create a property with name , attribute and value.
     * Creation is successful if the property does not already exist.
     */
    public boolean createProperty(String name , int attribute, FBSValue value ){
        return propCreate(name,attribute,value);
    }

    public boolean createConstructor(int attribute, BuiltinFunction function){
        function.setFunctionName(CONSTRUCTOR_NAME);
        return createProperty(CONSTRUCTOR_NAME,attribute,function);
    }

    public FBSObject getConstructor() {
        try {
            return (FBSObject)getProperty(CONSTRUCTOR_NAME);
        } catch(InterpretException ex) {
        }
        return null;
    }

    public boolean createMethod(String name , int attribute, BuiltinFunction function){
        function.setFunctionName(name);
        return createProperty(name,attribute,function);
    }

    public FBSValue get(int index) throws InterpretException {
        throw new InterpretException(null,"get(int index) not supported in FBSDefaultObject"); // $NLS-FBSDefaultObject.getintindexnotsupportedinFBSDefau-1$
    }
    public void put(int index , FBSValue value) throws InterpretException {
        throw new InterpretException(null,"put(int index,FBSValue value) not supported in FBSDefaultObject"); // $NLS-FBSDefaultObject.putintindexFBSValuevaluenotsuppor-1$
    }

    /**
     * Assign a property 'name' with 'value'.
     * If property does not exist it is created.
     */
    public void put(String name , FBSValue value) throws InterpretException {
        if(getJSContext().hasRhinoProtoExtensions() && name.equals("__proto__")) { // $NON-NLS-1$
            JSProperty pt = propGetEntry("prototype"); // $NON-NLS-1$
            if(pt!=null && (value instanceof FBSDefaultObject)) {
                pt.value = value;
                prototype = (FBSDefaultObject)value;
            }
            return;
        }
        if(prototype!=null) {
            if(!prototype.canPut(name)) {
                return;
            }
        }
        
        // Checking if a property can be updated is done in propPut()
        propPut(name,value);
    }

    /**
     * Get the value of the property determined by name.
     * First the current object is searched if not found then the prototype of the
     * object is searched.
     * If not found FBSUndefined is returned
     * @return the value of the property
     */
    public FBSValue get(String name) throws InterpretException {
        if(getJSContext().hasRhinoProtoExtensions() && name.equals("__proto__")) { // $NON-NLS-1$
        	if(prototype!=null) {
                return prototype; 
        	}
    		return FBSNull.nullValue;
        }
        JSProperty p = propGetEntry(name);
        if (p!=null){
            return p.value;
        }
        if (prototype==null) {
            return FBSUndefined.undefinedValue;
        } else {
            return prototype.get(name);
        }
    }

    public boolean canPut(String name){
        JSProperty p = (JSProperty) propGetEntry(name);
        if (p!=null){
            return !p.isReadOnly();
        }
        if (prototype!=null) {
            return prototype.canPut(name);
        }
        return true;
    }

    public final boolean hasProperty(String name){
        if (propGetEntry(name)!=null) {
            return true;
        }
        if(hasCustomProperty(name)) {
            return true;
        }
        if (prototype!=null) {
            return prototype.hasProperty(name);
        }
        return false;
    }
    public boolean hasCustomProperty(String name) {
        return false;
    }

    public boolean delete(String name){
        JSProperty p=(JSProperty) propGetEntry(name);
        if(p!=null) {
            if (p.isNoDelete()){
                return false;
            }
            propRemove(name);
            return true;
        }
        // In case it is defined in the prototype... 
        if(hasProperty(name)) { 
            return false;
        }
        return true;
    }

    public void clear(){
        propCount = 0;
        propEntries = new JSProperty[MAP_LENGTH];
    }

    public JSProperty getPropertyByName(String name){
        return propGetEntry(name);
    }

    public FBSReference getPropertyReference(String name) throws InterpretException {
        // Look at the object properties
        // Those properties are already defined as references, pointing the
        // correct object
        JSProperty p = propGetEntry(name);
        if(p!=null) {
            return p;
        }

        // Then, try the custom properties
        // We look here only at the properties that are not in the properties list
        // => performance optimization
        if(hasCustomProperty(name)) {
            return new FBSReferenceByName(this,name);
        }

        // If the method is in the prototype, then the reference should
        // point to this and we cannot return the prototype reference as is
        for( FBSDefaultObject proto = prototype; proto!=null; proto=proto.prototype) {
            p = proto.propGetEntry(name);
            if(p!=null) {
                return new FBSReferenceByName.ResolvedReference(this,name,p.value);
            }
            if(proto.hasCustomProperty(name)) {
                return new FBSReferenceByName(this,name);
            }
        }
        return null;
    }


    public Iterator getPropertyKeys() {
        return new com.ibm.commons.util.FilteredIterator(propEntryIterator()) {
            protected boolean accept( Object object ) {
                JSProperty p=(JSProperty)object;
                return !p.isNoEnum();
            }
            public Object next() {
                JSProperty p=(JSProperty)super.next();
                if( p!=null ) {
                    return p.name;
                }
                return null;
            }
        };
    }

    public void getAllPropertiesForHelp(JSContext context, Set members) {
        getAllPropertiesForHelp(this,members);
    }
    public void getAllPropertiesForHelp(FBSDefaultObject obj, Set members){
        JSContext jsContext = getJSContext();
        
        // And then the object properties
        for( Iterator it=obj.propEntryIterator(); it.hasNext(); ) {
            boolean added = false;
            JSProperty p = (JSProperty)it.next();
            if( p.getValue() instanceof FBSObject ) {
                FBSObject op = (FBSObject)p.getValue();
                // Add the object constructors
                // Also, only shows the contructors for the current object (ex: Boolean should not show the Object construcotr)
                if( op.supportConstruct() && (op instanceof BuiltinConstructor) && op==this ){
                    if( !(op instanceof BuiltinConstructor) || op==this ){
                        String ctorName = ((BuiltinConstructor)op).getGlobalName(); 
                        String[] params = op.getConstructorParameters();
                        if( params!=null ) {
                            for( int i=0; i<params.length; i++ ) {
                                Descriptor.Constructor c = new Descriptor.Constructor(jsContext,ctorName,params[i]);
                                members.add(c);
                            }
                        } else {
                            Descriptor.Constructor c = new Descriptor.Constructor(jsContext,ctorName,(Descriptor.Param[])null);
                            members.add(c);
                        }
                    }
                    added = true;
                } 
                
                // And the function calls
                // Also, only shows the contructors for the current object (ex: Boolean should not show the Object construcotr)
                if( op.supportCall() ){
                    if( !(op instanceof BuiltinConstructor) || op==this) {
                        // Builtin construtors can be called as a function
                        // -> display them as just a name, and add "constructor" as a field
                        String propName = p.name;
                        if( op instanceof BuiltinConstructor ){
                            Descriptor.Field m = new Descriptor.Field(jsContext,propName,FBSType.jsObjectType,false);
                            members.add(m);
                            propName = ((BuiltinConstructor)op).getGlobalName(); 
                        }
                        String[] params = op.getCallParameters();
                        if( params!=null ) {
                            for( int i=0; i<params.length; i++ ) {
                                Descriptor.Method m = new Descriptor.Method(jsContext,propName,params[i]);
                                members.add(m);
                            }
                        } else {
                            Descriptor.Method m = new Descriptor.Method(jsContext,propName,FBSType.undefinedType,null);
                            members.add(m);
                        }
                    }
                    added = true;
                }
            }
            
            // If it is not a function/ctor, then it is a field
            if(!added) {
                Descriptor.Field f = new Descriptor.Field(jsContext,p.name,FBSType.undefinedType,false);
                members.add(f);
            }
        }
        FBSObject proto = obj.getPrototype();
        if( proto instanceof FBSDefaultObject ) {
            getAllPropertiesForHelp((FBSDefaultObject)proto, members);
        }
    }


    public Iterator<JSProperty> getPropertyIterator() {
        return new com.ibm.commons.util.FilteredIterator<JSProperty>(propEntryIterator()) {
            protected boolean accept( Object object ) {
                JSProperty p=(JSProperty)object;
                return !p.isNoEnum();
            }
        };
    }
//
//    public HashMap getProperties(){
//        return properties;
//    }



    // ========================================================================
    // Java Object IO.
    // ========================================================================

    public void readExternal( ObjectInput in ) throws IOException {
        int count = in.readInt();
        if( count>=0 ) {
            for( int i=0; i<count; i++ ) {
                String name = in.readUTF();
                int attribute = in.readInt();
                FBSValue value = FBSValue.readValue(in);
                //TDiag.trace( "Deserializing '{0}'='{1}' ({2})'", name, value.getClass(), value );
                propCreate(name,attribute,value);
            }
        }
    }

    public void writeExternal( ObjectOutput out ) throws IOException {
        int size = 0;
        for( Iterator it=propEntryIterator(); it.hasNext(); ) {
            JSProperty p = (JSProperty)it.next();
            if(!p.isNoEnum() && !p.isTransient()) {
                size++;
            }
        }
        out.writeInt(size);
        for( Iterator it=propEntryIterator(); it.hasNext(); ) {
            JSProperty p = (JSProperty)it.next();
            if(!p.isNoEnum() && !p.isTransient()) {
                //TDiag.trace( "Serializing '{0}'='{1}' ({2})'", p.getName(), p.getValue().getClass(), p.getValue() );
                out.writeUTF(p.getPropertyName());
                out.writeInt(p.getAttributes());
                FBSValue.writeValue(out,p.getValue());
            }
        }
    }
    
    
}