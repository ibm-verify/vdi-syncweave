/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.engine;

import java.util.List;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSExpression;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSGlobalObject;
import com.ibm.jscript.types.FBSObject;

/**
 * Library execution context.
 * Context used when a library is executed.
 */
public final class LibraryContext extends ProgramContext {

    public LibraryContext(JSExpression expression, FBSGlobalObject globalObject, FBSObject scopePrototypes, FBSObject _this, List<String> importedLibraries) throws InterpretException {
        super(expression,globalObject,scopePrototypes,_this,null,importedLibraries);
    }
    
    public LibraryContext getLibraryContext() {
    	return this;
    }

    // Make the library variables available to the functions defined in the library
    public FBSDefaultObject getFunctionParentVariableObject(){
        return varObject;
    }    
}
