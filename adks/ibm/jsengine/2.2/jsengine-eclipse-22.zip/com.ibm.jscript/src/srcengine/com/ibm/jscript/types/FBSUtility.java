/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2010                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import java.util.Calendar;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.lib.BooleanArrayWrapper;
import com.ibm.jscript.lib.ByteArrayWrapper;
import com.ibm.jscript.lib.CharArrayWrapper;
import com.ibm.jscript.lib.DoubleArrayWrapper;
import com.ibm.jscript.lib.FloatArrayWrapper;
import com.ibm.jscript.lib.IntArrayWrapper;
import com.ibm.jscript.lib.LongArrayWrapper;
import com.ibm.jscript.lib.ObjectArrayWrapper;
import com.ibm.jscript.lib.ShortArrayWrapper;
import com.ibm.jscript.std.DateObject;

public final class FBSUtility {

	/**
	 * Get the display type of a value.
	 * @param value the value to test
	 * @return
	 */
	public static final String getDisplayType(FBSValue value) {
		if(value==null) {
			return "<null>"; //$NON-NLS-1$
		}
		return value.getTypeAsString();
	}
	
    // =======================================================================
    // Basic java primitive type wrappers
    // =======================================================================

    public static FBSValue wrap(char c){
        return FBSString.get(c);
    }
    public static FBSValue wrap(JSContext jsContext, char c){
        return FBSString.get(c);
    }

    public static FBSValue wrap(byte b){
        return FBSNumber.get((int)b);
    }
    public static FBSValue wrap(JSContext jsContext, byte b){
        return FBSNumber.get((int)b);
    }

    public static FBSValue wrap(short s){
        return FBSNumber.get((int)s);
    }
    public static FBSValue wrap(JSContext jsContext, short s){
        return FBSNumber.get((int)s);
    }

    public static FBSValue wrap(int i){
        return FBSNumber.get(i);
    }
    public static FBSValue wrap(JSContext jsContext, int i){
        return FBSNumber.get(i);
    }

    public static FBSValue wrap(long l){
        return FBSNumber.get(l);
    }
    public static FBSValue wrap(JSContext jsContext, long l){
        return FBSNumber.get(l);
    }

    public static FBSValue wrap(float f){
        return FBSNumber.get((double)f);
    }
    public static FBSValue wrap(JSContext jsContext, float f){
        return FBSNumber.get((double)f);
    }

    public static FBSValue wrap(double d){
        return FBSNumber.get(d);
    }
    public static FBSValue wrap(JSContext jsContext, double d){
        return FBSNumber.get(d);
    }

    public static FBSValue wrap(boolean b){
        return b ? FBSBoolean.TRUE : FBSBoolean.FALSE;
    }
    public static FBSValue wrap(JSContext jsContext, boolean b){
        return b ? FBSBoolean.TRUE : FBSBoolean.FALSE;
    }


    // =======================================================================
    // Basic java primitive array wrappers
    // =======================================================================

    public static FBSObject wrap(JSContext jsContext, boolean[] array){
        return new BooleanArrayWrapper(jsContext,array);
    }

    public static FBSObject wrap(JSContext jsContext, char[] array){
        return new CharArrayWrapper(jsContext,array);
    }

    public static FBSObject wrap(JSContext jsContext, byte[] array){
        return new ByteArrayWrapper(jsContext,array);
    }

    public static FBSObject wrap(JSContext jsContext, short[] array){
        return new ShortArrayWrapper(jsContext,array);
    }

    public static FBSObject wrap(JSContext jsContext, int[] array){
        return new IntArrayWrapper(jsContext,array);
    }

    public static FBSObject wrap(JSContext jsContext, long[] array){
        return new LongArrayWrapper(jsContext,array);
    }

    public static FBSObject wrap(JSContext jsContext, float[] array){
        return new FloatArrayWrapper(jsContext,array);
    }

    public static FBSObject wrap(JSContext jsContext, double[] array){
        return new DoubleArrayWrapper(jsContext,array);
    }

    public static FBSObject wrap(JSContext jsContext, Object[] array){
        return new ObjectArrayWrapper(jsContext,array);
    }

    public static FBSObject wrapArray(JSContext jsContext, Object array) {
        Class<?> c=array.getClass().getComponentType();
        if(c.isPrimitive()) {
            if(array instanceof char[]) {
                return wrap( jsContext, (char[])array);
            } else if(array instanceof byte[]) {
                return wrap( jsContext, (byte[])array);
            } else if(array instanceof short[]) {
                return wrap( jsContext, (short[])array);
            } else if(array instanceof int[]) {
                return wrap( jsContext, (int[])array);
            } else if(array instanceof long[]) {
                return wrap( jsContext, (long[])array);
            } else if(array instanceof float[]) {
                return wrap( jsContext, (float[])array);
            } else if(array instanceof double[]) {
                return wrap( jsContext, (double[])array);
            } else if(array instanceof boolean[]) {
                return wrap( jsContext, (boolean[])array);
            } else {
                // Should fail....
            }
        }
        return wrap( jsContext, (Object[])array);
    }


    // =======================================================================
    // Javascript primitive wrappers
    // =======================================================================

    public static FBSValue wrap(String s){
        return FBSString.get(s);
    }

    public static FBSValue wrap(JSContext jsContext, java.util.Date value){
        if (value==null){
            return FBSNull.nullValue;
        }
        try{
            return new DateObject(jsContext,value);
        }catch(Exception e){
        }
        return FBSUndefined.undefinedValue;
    }

    public static FBSValue wrap(JSContext jsContext, Calendar value){
        if (value==null){
            return FBSNull.nullValue;
        }
        try{
            return new DateObject(jsContext,value.getTimeInMillis());
        }catch(Exception e){
        }
        return FBSUndefined.undefinedValue;
    }

//    public static FBSValue wrap(java.sql.Timestamp value){
//        if (value==null){
//            return FBSNull.nullValue;
//        }
//        try{
//            return wrap(new DateObject(value!=null ? new java.util.Date(value.getTime()) : (java.util.Date)null));
//        }catch(Exception e){
//        }
//        return FBSUndefined.undefinedValue;
//    }
//
//    public static FBSValue wrap(java.sql.Time value){
//        if (value==null){
//            return FBSNull.nullValue;
//        }
//        try{
//            return wrap(new DateObject(value!=null ? new java.util.Date(value.getTime()) : (java.util.Date)null));
//        }catch(Exception e){
//        }
//        return FBSUndefined.undefinedValue;
//
//    }
//
//    public static FBSValue wrap(java.sql.Date value){
//        if (value==null){
//            return FBSNull.nullValue;
//        }
//        try{
//            return wrap(new DateObject(value!=null ? new java.util.Date(value.getTime()) : (java.util.Date)null));
//        }catch(Exception e){
//        }
//        return FBSUndefined.undefinedValue;
//
//    }


    // =======================================================================
    // Object wrappers
    // =======================================================================

    public static FBSValue wrap(JSContext jsContext, Object o) throws InterpretException {
        // Null object wraps to null...
        if (o==null) {
            return FBSNull.nullValue;
        }

        // If a Java function already returns a FBSValue, do not convert it
        if( o instanceof FBSValue ) {
            return (FBSValue)o;
        }
        
        // Std types
        Class<?> _class = o.getClass();
        if( _class==String.class ) {
            return wrap( (String)o );
        }
        if( _class==Character.class ) {
            return wrap( StringUtil.toString(((Character)o).charValue()) );
        }
        if( o instanceof Number ) {
            // Standard Java numbers are converted to FBSNUmber
            if(    _class==Byte.class
                || _class==Integer.class
                || _class==Short.class
                || _class==Long.class
                || _class==Float.class
                || _class==Double.class) {
                return wrap( ((Number)o).doubleValue() );
            }
            // Other are left as java objects (like BigDecimal, BigInteger...)
            return new JavaAccessObject(jsContext,o.getClass(),o);
        }
        if( _class==Boolean.class ) {
            return wrap( ((Boolean)o).booleanValue() );
        }
        if( o instanceof java.util.Date ) {
            return wrap( jsContext, (java.util.Date)o );
        }
        if( o instanceof java.util.Calendar ) {
            return wrap( jsContext, (java.util.Calendar)o );
        }

        return wrapAsObject(jsContext,o);
    }
    public static final FBSObject wrapAsObject( JSContext context, Object o ) {
        Class<?> _class = o.getClass();

        // If a Java function already returns a FBSValue, do not convert it
        if( o instanceof FBSObject ) {
            return (FBSObject)o;
        }
        
        // Custom wrapper
        JavaWrapperObject ja = context.wrapObject(o);
        if(ja!=null) {
            return ja;
        }

        // Arrays
        if( _class.isArray() ) {
            return wrapArray(context,o);
        }

        // Search for a registered wrapper
        if(context.useGeneratedWrappers()) {
            IWrapperFactory wrapper=context.getRegistry().searchWrapper(context,_class);
            if(wrapper!=null) {
                return wrapper.wrap(context,o);
            }
        }
        
        // Standard introspection based wrapper
        return new JavaAccessObject(context,_class,o);
    }

    public static final IWrapperFactory searchWrapper(JSContext context, Class c){
        return context.getRegistry().searchWrapper(context,c);
    }
}
