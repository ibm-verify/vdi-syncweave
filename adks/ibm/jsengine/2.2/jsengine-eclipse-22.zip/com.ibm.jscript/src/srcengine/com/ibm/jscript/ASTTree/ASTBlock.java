/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSUndefined;

public class ASTBlock extends ASTNode implements ILabelledStatement {
    
    private ASTNode[] nodes = ASTNode.EMPTY_ARRAY;
    private String labelName;

    public ASTBlock() {
    }

    public ASTNode getOptimizedNode(JSContext context) {
    	if(context.isRuntimeOptimized()) {
	    	// Labelled blocks can not be optimized
	    	if(labelName!=null) {
	    		return this;
	    	}
	    	
	     	// if block is only made of one node, then ignore the block itself
	    	if(nodes.length==1) {
	    		return nodes[0];
	    	}
    	}
    	
    	// Ok, just itself...
    	return this;
    }
    
    public void setLabelName(String label) {
        this.labelName = label;
    }

    public int getSlotCount() {
        return nodes.length;
    }

    public ASTNode readSlotAt(int index) {
        return nodes[index];
    }
    
    public void initNodes(NodeVector vc) {
    	int count = vc.size();
    	this.nodes = new ASTNode[count];
    	
    	for(int i=0; i<count; i++) {
			ASTNode n = vc.get(i);
    		nodes[i] = assignParent(n);
    	}
    }

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
    	int count = nodes.length; 
        if (count > 0) {
            FBSType t = null;
            for (int i = 0; i < count; i++) {
                if (t == null) {
                    t = ((ASTNode) nodes[i]).getResultType(jsContext,symbolCallback);
                } else {
                    FBSType t2 = ((ASTNode) nodes[i])
                            .getResultType(jsContext,symbolCallback);
                    if (!t.equals(t2)) {
                        return FBSType.undefinedType;
                    }
                }
            }
            return t;
        }
        return FBSType.undefinedType;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context, InterpretResult result) throws JavaScriptException {
        try {
        	int count = nodes.length; 
            if (count == 0) {
                result.setNormal(FBSUndefined.undefinedValue);
            } else {
                for (int i = 0; i < count; i++) {
                    ASTNode node = nodes[i];
                    if(!node.interpret(this, context, result)) {
                    	if(result.isBreakSignal()) {
                            // Break this block...
                    		// Continue to propate the signal is the blocked is not named or does not
                    		// match the loop label
                            String label = context.getProgramContext().getLoopLabel();
                            if(!StringUtil.isEmpty(label)) {
                                if(!StringUtil.equals(label,labelName)) {
                                    return false;
                                }
                            } else {
                                return false;
                            }
                            result.resetSignal();
                            return true;
                    	}
                    	return false;
                    }
                }
            }
            return true;
        } catch (InterpretException ie) {
            throw ie.fillException(context, this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
        return v.visitBlock(this, param);
    }
}
