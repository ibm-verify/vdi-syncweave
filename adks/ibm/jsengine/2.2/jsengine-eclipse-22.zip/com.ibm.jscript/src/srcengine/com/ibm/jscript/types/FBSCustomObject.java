/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.engine.IExecutionContext;

/**
 * Custom object type.
 * 
 * This class is used as an abstract base class for custom object implementation.
 * 
 * @author priand
 *
 */
public abstract class FBSCustomObject extends FBSObject {

    public FBSCustomObject(JSContext jsContext) {
        super(jsContext);
    }

    // =========================================================================
    // Constructor
    // =========================================================================

    public boolean supportConstruct(){
        return false;
    }
    
    public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
        throw new InterpretException(null,"Construct not supported for this object"); // $NLS-FBSCustomObject.Constructnotsupportedforthisobjec-1$
    }


    // =========================================================================
    // Property access
    // =========================================================================

    public boolean hasProperty(String name) {
        return false;
    }

    public FBSValue get(String name) throws InterpretException {
        throw new InterpretException(null,"Unknown property {0}",name); // $NLS-FBSCustomObject.Unknownproperty0-1$
    }
    
    public FBSValue get(int index) throws InterpretException {
        throw new InterpretException(null,"Unknown indexed property [{0}]",index); // $NLS-FBSCustomObject.Unknownindexedproperty0-1$
    }


    public boolean canPut(String name){
        return hasProperty(name);
    }

    public void put(String name , FBSValue value) throws InterpretException {
        throw new InterpretException(null,"Cannot set property value {0}",name); // $NLS-FBSCustomObject.Cannotsetpropertyvalue0-1$
    }
    
    public void put(int index , FBSValue value) throws InterpretException {
        throw new InterpretException(null,"Cannot set indexed property [{0}]",index); // $NLS-FBSCustomObject.Cannotsetindexedproperty0-1$
    }

    
    // =========================================================================
    // Property meta data
    // =========================================================================
    
    public FBSType getFBSType(JSContext context) {
        return FBSType.getTypeFromValue(getJSContext(),this);
    }

    
    // =========================================================================
    // Function call
    // =========================================================================

    public boolean supportCall(){
        return false;
    }

    public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this)throws InterpretException{
        return null;
    }


    public boolean hasInstance(FBSValue v){
        return false;
    }

    
    // =========================================================================
    // Conversion to a java object
    // =========================================================================
    
    public boolean isJavaNative(){
       return false;
    }

    public boolean isJavaAssignableTo(Class c) {
        return false;
    }

    public Object toJavaObject(Class _class)throws InterpretException{
        throw new InterpretException(null,"Cannot convert {0} to {1}", this.getClass().getName(), _class.getName()); // $NLS-FBSCustomObject.Cannotconvert0to1-1$
    }
}