/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.BuiltinConstructor;
import com.ibm.jscript.types.BuiltinFunction;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSNumber;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.FBSValueVector;

/**
 * Number object prototype.
 */
public class NumberPrototype extends NumberObject implements Prototype {

    public NumberPrototype(JSContext jsContext){
        super(jsContext,jsContext.getRegistry().objectPrototype);
        int attrib=FBSObject.P_NOENUM;
        createConstructor(attrib,new NumberConstructor(jsContext,this)); //$NON-NLS-1$
        createMethod("toString",attrib,new NumberMethod(jsContext,0)); //$NON-NLS-1$
        createMethod("valueOf",attrib,new NumberMethod(jsContext,1)); //$NON-NLS-1$
        createMethod("toLocaleString",attrib,new NumberMethod(jsContext,2)); //$NON-NLS-1$
        createMethod("toFixed",attrib,new NumberMethod(jsContext,3)); //$NON-NLS-1$
        createMethod("toExponential",attrib,new NumberMethod(jsContext,4)); //$NON-NLS-1$
        createMethod("toPrecision",attrib,new NumberMethod(jsContext,5)); //$NON-NLS-1$

        int attrib2=FBSObject.P_NODELETE|FBSObject.P_READONLY|FBSObject.P_NOENUM;
        createProperty("MAX_VALUE",attrib2,FBSNumber.get(NumberObject.MAX_VALUE)); //$NON-NLS-1$
        createProperty("MIN_VALUE",attrib2,FBSNumber.get(NumberObject.MIN_VALUE)); //$NON-NLS-1$
        createProperty("NaN",attrib2,FBSNumber.get(NumberObject.NaN)); //$NON-NLS-1$
        createProperty("NEGATIVE_INFINITY",attrib2,FBSNumber.get(NumberObject.NEGATIVE_INFINITY)); //$NON-NLS-1$
        createProperty("POSITIVE_INFINITY",attrib2,FBSNumber.get(NumberObject.POSITIVE_INFINITY)); //$NON-NLS-1$
    }

    ////// Constructor
    static class NumberConstructor extends BuiltinConstructor{
        public NumberConstructor(JSContext jsContext, FBSDefaultObject prototype){
            super(jsContext,prototype,"Number"); // $NON-NLS-1$
        }
        public boolean supportConstruct(){
            return true;
        }
        public boolean hasInstance(FBSValue v){
            return v instanceof NumberObject;
        }
        protected String[] getCallParameters() {
            return new String[] {"():D","(value:W):D"}; //$NON-NLS-1$ $NON-NLS-2$
        }
        protected String[] getConstructorParameters() {
            return new String[] {"()","(value:W)"}; //$NON-NLS-1$
        }

        public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
            if(args.getCount()==0) {
                return new NumberObject(getJSContext(),FBSNumber.Zero);
            }
            if(args.getCount()>=1) {
                FBSNumber d = args.get(0).toFBSNumber();
                return new NumberObject(getJSContext(),d);
            }
            throw new InterpretException(null,"Invalid NumberObject class constructor arguments"); //$NLS-NumberObject.NumberObject.InvalidArgs.Exception-1$
        }

        public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this) throws JavaScriptException {
            if(args.getCount()==0) {
                return FBSNumber.Zero;
            }
            return args.get(0).toFBSNumber();
        }
        
        public boolean supportCall() {
            return true;
        }
    }

    static class NumberMethod extends BuiltinFunction{
        int mIndex=-1;

        public NumberMethod(JSContext jsContext, int index){
            super(jsContext);
            mIndex=index;
        }

        protected String[] getCallParameters() {
            switch(mIndex) {
                case 0: //toString
                    return new String[] {"():T"}; //$NON-NLS-1$
                case 1: //valueOf
                    return new String[] {"():D"}; //$NON-NLS-1$
                case 2: // toLocaleString(int radix)
                    return new String[] {"(radix:I):T","():T"}; //$NON-NLS-1$ //$NON-NLS-2$
                case 3: // String toFixed(int precision)
                case 4: // String toExponential(int precision)
                case 5: // String toPrecision(int precision)
                    return new String[] {"(precision:I):T","():T"}; //$NON-NLS-1$ //$NON-NLS-2$
            }
            return super.getCallParameters();
        }


        public FBSValue call(FBSValueVector args, FBSObject _this) throws JavaScriptException {
            return FBSUndefined.undefinedValue;
        }

        public FBSValue call(IExecutionContext context, FBSValueVector args, FBSObject _this) throws JavaScriptException {
            switch(mIndex){
            
                ///////////////////////////////////////////////////////////////
                // Standard ECMA functions
                case 0: {     // toString
                    if(_this instanceof NumberObject ) {
                        if(args.getCount()==0) {
                            return FBSString.get(((NumberObject)_this).toString());
                        }
                        int radix = args.get(0).intValue();
                        return FBSString.get(((NumberObject)_this).toString(radix));
                    }
                    if(_this==null) {
                        return FBSString.emptyString;
                    }
                    throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Object is not a number, {0}",FBSUtility.getDisplayType(_this))); //$NLS-NumberPrototype.NumberPrototype.NotANumber.Exception-1$
                }
                case 1: {     // valueOf
                    if(_this instanceof NumberObject ) {
                        return ((NumberObject)_this).getFBSNumber();
                    }
                    throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Object is not a string, {0}",FBSUtility.getDisplayType(_this))); //$NLS-NumberPrototype.NumberPrototype.NotAString.Exception-1$
                }
                case 2: {     // toLocaleString(int radix){
                    if(_this instanceof NumberObject ) {
                    	NumberObject number = (NumberObject)_this;
                    	int radix = args.isUndefined(0) ? 10 : args.get(0).intValue();
                    	return FBSString.get(number.toLocaleString(radix));
                    }
                    if(_this==null) {
                        return FBSString.emptyString;
                    }
                    throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Object is not a number, {0}",FBSUtility.getDisplayType(_this))); //$NLS-NumberPrototype.NumberPrototype.NotANumber.Exception-1$
                }
                case 3: {     // String toFixed(int precision){
                    NumberObject number = (NumberObject)_this;
                    if(args.isUndefined(0)) {
                        return FBSString.get(number.toFixed());
                    }
                    int precision = args.get(0).intValue();
                    return FBSString.get(number.toFixed(precision));
                }
                case 4: {     // String toExponential(int precision){
                    NumberObject number = (NumberObject)_this;
                    if(args.isUndefined(0)) {
                        return FBSString.get(number.toExponential());
                    }
                    int precision = args.get(0).intValue();
                    return FBSString.get(number.toExponential(precision));
                }
                case 5: {     // String toPrecision(int precision){
                    NumberObject number = (NumberObject)_this;
                    if(args.isUndefined(0)) {
                        return FBSString.get(number.toPrecision());
                    }
                    int precision = args.get(0).intValue();
                    return FBSString.get(number.toPrecision(precision));
                }
            }
            throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Number function not found")); //$NLS-NumberPrototype.NumberPrototype.NumbFuncNotFound.Exception-1$
        }
    }

}