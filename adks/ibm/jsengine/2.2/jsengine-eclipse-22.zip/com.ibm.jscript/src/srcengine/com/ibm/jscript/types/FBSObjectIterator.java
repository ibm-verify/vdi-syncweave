/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */


/**
 * Title:        <p>
 * Description:  <p>
 * @author
 * @version 1.0
 */
package com.ibm.jscript.types;
import java.util.Iterator;
import java.util.Stack;

public class FBSObjectIterator implements Iterator{
    Stack stack;
    int index;
    public FBSObjectIterator(Stack stack) {
        this.stack=stack;
        index=0;//stack.size();
    }

    public boolean hasNext(){
        return index<stack.size();//)>0;
    }

    public Object next(){
        //index--;
        return stack.get(index++);
    }

    public FBSObject nextFBSObject(){
        return (FBSObject)next();
    }

    public void remove(){
        throw new RuntimeException("Remove method is unsupported in FBSObjectIterator"); // $NLS-FBSObjectIterator.removemethodisunsupportedinFBSObj-1$
    }

}
