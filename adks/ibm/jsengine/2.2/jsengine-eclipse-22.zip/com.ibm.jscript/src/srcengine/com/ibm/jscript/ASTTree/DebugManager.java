/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import java.util.Vector;
import java.util.WeakHashMap;

import com.ibm.jscript.engine.DebugEvent;
import com.ibm.jscript.engine.IDebugListener;
import com.ibm.jscript.engine.IExecutionContext;

public class DebugManager {

    static WeakHashMap debugMap= new WeakHashMap();


    public static void addListener(Thread thread,IDebugListener listener){
        DebugEntry entry=(DebugEntry)debugMap.get(thread);
        Vector listeners;

        if (entry==null){
            entry= new DebugEntry();
            debugMap.put(thread,entry);
        }

        listeners=entry.getListeners();

        if (!listeners.contains(listener)){
            listeners.add(listener);
        }
    }

    public static void removeListener(Thread thread,IDebugListener listener){
        DebugEntry entry=(DebugEntry)debugMap.get(thread);
        if (entry!=null){
            Vector listeners=entry.getListeners();
            listeners.remove(listener);
        }
    }

    public static void removeAllListeners(Thread thread){
        DebugEntry entry=(DebugEntry)debugMap.get(thread);
        if (entry!=null){
            Vector listeners=entry.getListeners();
            listeners.clear();
            debugMap.remove(thread);
        }
    }

    public static void notifyNodeEntered(Thread thread,ASTNode sender,IExecutionContext context,InterpretResult result){
        DebugEntry entry=(DebugEntry)debugMap.get(thread);
        if (entry!=null && entry.isDebugMode()){
            DebugEvent ev= new DebugEvent(sender,context,result);
            Vector listeners=entry.getListeners();
            for(int i=0;i<listeners.size();i++){
                IDebugListener listener=(IDebugListener)listeners.get(i);
                if (listener!=null){
                    listener.nodeEntered(ev);
                }
            }
        }
    }


    public static void notifyNodeExited(Thread thread,ASTNode sender,IExecutionContext context,InterpretResult result){
        DebugEntry entry=(DebugEntry)debugMap.get(thread);
        if (entry!=null && entry.isDebugMode()){
            DebugEvent ev= new DebugEvent(sender,context,result);
            Vector listeners=entry.getListeners();
            for(int i=0;i<listeners.size();i++){
                IDebugListener listener=(IDebugListener)listeners.get(i);
                if (listener!=null){
                    listener.nodeExited(ev);
                }
            }
        }
    }

    public static void notifyExecutingNode(Thread thread,ASTNode sender,IExecutionContext context,InterpretResult result){
        DebugEntry entry=(DebugEntry)debugMap.get(thread);
        if (entry!=null && entry.isDebugMode()){
            DebugEvent ev= new DebugEvent(sender,context,result);
            Vector listeners=entry.getListeners();
            for(int i=0;i<listeners.size();i++){
                IDebugListener listener=(IDebugListener)listeners.get(i);
                if (listener!=null){
                    listener.executingNode(ev);
                }
            }
        }
    }

    public static class DebugEntry{
        boolean debugMode=true;
        Vector listeners= new Vector();

        public void setDebugMode(boolean b){
            debugMode=b;
        }

        public boolean isDebugMode(){
            return debugMode;
        }

        public Vector getListeners(){
            return listeners;
        }
    }
}
