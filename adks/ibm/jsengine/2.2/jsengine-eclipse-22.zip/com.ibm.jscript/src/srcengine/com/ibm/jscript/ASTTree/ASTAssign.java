/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import java.io.PrintStream;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.engine.Utility;
import com.ibm.jscript.parser.Token;
import com.ibm.jscript.types.FBSReference;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSValue;

public class ASTAssign extends ASTNode{
    public static final int LEFT=0;
    public static final int RIGHT=1;

    private int typeId;
    private ASTNode leftNode;
    private ASTNode rightNode;

    public ASTAssign(Token t, int typeId, ASTNode leftNode, ASTNode rightNode) {
    	super(t);
        this.typeId=typeId;
        this.leftNode=assignParent(leftNode);
        this.rightNode=assignParent(rightNode);
    }

    public ASTAssign(int type) {
        typeId=type;
    }

    public int getType(){
        return typeId;
    }

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        if( rightNode!=null ) {
            return rightNode.getResultType(jsContext,symbolCallback);
        }
        return FBSType.undefinedType;
    }

    public String getTraceString(){
        return leftNode.getTraceString()+ASTConstants.getToken(typeId)+rightNode.getTraceString();
    }

    public ASTNode getLeftNode() {
        return leftNode;
    }

    public ASTNode getRightNode() {
        return rightNode;
    }

    public int getSlotCount(){
        return 2;
    }

    public ASTNode readSlotAt(int index){
        if (index<0 || index>1) return null;
        return (index==0)?leftNode:rightNode;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            if(!leftNode.interpret(this,context,result)) {
            	return false;
            }
            FBSReference ref=result.getReference();
            if( ref==null ) {
                throw new InterpretException(null," Left part of '{0}' cannot be assigned.",ASTConstants.getToken(typeId)); //$NLS-ASTAssign.ASTAssign.CannotAssign.Exception-1$
            }

            if(!rightNode.interpret(this,context,result)) {
            	return false;
            }
            FBSValue v2=result.getFBSValue();

            if (typeId==ASTConstants.ASSIGN){
                ref.putValue(v2);
                result.setNormal(v2);
                return true;
            }
            FBSValue v1=ref.getValue();
            FBSValue r=FBSUndefined.undefinedValue;

            switch(typeId){
                case ASTConstants.ADD_ASSIGN:
                    r=Utility.operation(context,v1,v2,ASTConstants.ADD);
                    break;

                case ASTConstants.SUB_ASSIGN:
                    r=Utility.operation(context,v1,v2,ASTConstants.SUBTRACT);
                    break;

                case ASTConstants.MUL_ASSIGN:
                    r=Utility.operation(context,v1,v2,ASTConstants.MULTIPLY);
                    break;

                case ASTConstants.DIV_ASSIGN:
                    r=Utility.operation(context,v1,v2,ASTConstants.DIVIDE);
                    break;

                case ASTConstants.MOD_ASSIGN:
                    r=Utility.operation(context,v1,v2,ASTConstants.MODULO);
                    break;

                case ASTConstants.LSH_ASSIGN:
                    r=Utility.operation(context,v1,v2,ASTConstants.SHIFT_LEFT);
                    break;

                case ASTConstants.RSH_ASSIGN:
                    r=Utility.operation(context,v1,v2,ASTConstants.SHIFT_RIGHT);
                    break;

                case ASTConstants.URSH_ASSIGN:
                    r=Utility.operation(context,v1,v2,ASTConstants.USHIFT_RIGHT);
                    break;

                case ASTConstants.AND_ASSIGN:
                    r=Utility.operation(context,v1,v2,ASTConstants.BITWISE_AND);
                    break;

                case ASTConstants.XOR_ASSIGN:
                    r=Utility.operation(context,v1,v2,ASTConstants.BITWISE_XOR);
                    break;

                case ASTConstants.OR_ASSIGN:
                    r=Utility.operation(context,v1,v2,ASTConstants.BITWISE_OR);
                    break;
            }
            ref.putValue(r);
            result.setNormal(r);
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    protected void extraInfo(PrintStream ps,String indent){
        ps.print("\""); //$NON-NLS-1$
        ps.print(ASTConstants.getToken(this.typeId));
        ps.print("\""); //$NON-NLS-1$
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitAssign(this, param);
    }
}
