/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree.binaryop;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.ASTTree.*;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.engine.Utility;
import com.ibm.jscript.parser.Token;
import com.ibm.jscript.types.FBSValue;

public class ASTBinaryDefaultOp extends ASTBinaryOp {

    private int op;

//    public ASTBinaryDefaultOp(Token t, ASTNode leftNode, ASTNode rightNode) {
//        super(t,leftNode,rightNode);
//        this.op=ASTConstants.getConstant(t.image);
//    }

    public ASTBinaryDefaultOp(Token t, int op, ASTNode leftNode, ASTNode rightNode) {
        super(t,leftNode,rightNode);
        this.op=op;
    }

    public ASTBinaryDefaultOp(int type) {
        this.op=type;
    }

    public int getOperator(){
        return op;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            if(!leftNode.interpret(this,context,result)) {
            	return false;
            }
            FBSValue v1=result.getFBSValue();

            if(!rightNode.interpret(this,context,result)) {
            	return false;
            }
            FBSValue v2=result.getFBSValue();

            FBSValue r=Utility.operation(context,v1,v2,op);
            result.setNormal(r);
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitBinaryDefaultOp(this, param);
    }
}
