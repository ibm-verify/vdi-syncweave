/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import java.io.PrintStream;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.engine.Utility;
import com.ibm.jscript.parser.Token;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSValue;

public abstract class ASTBinaryOp extends ASTNode {

    public static final int LEFT=0;
    public static final int RIGHT=1;

    protected ASTNode leftNode;
    protected ASTNode rightNode;

    public ASTBinaryOp() {
    }

    public ASTBinaryOp(Token t, ASTNode leftNode, ASTNode rightNode) {
        super(t);
        this.leftNode = assignParent(leftNode);
        this.rightNode = assignParent(rightNode);
    }

    public final ASTNode getLeftNode() {
        return leftNode;
    }

    public final ASTNode getRightNode() {
        return rightNode;
    }

    public String getTraceString(){
        return leftNode.getTraceString()+ASTConstants.getToken(getOperator())+rightNode.getTraceString();
    }

    public int getSlotCount(){
        return 2;
    }

    public ASTNode readSlotAt(int index){
        if (index<0 || index>1) return null;
        return (index==0)?leftNode:rightNode;
    }

    protected void extraInfo(PrintStream ps,String indent){
        ps.print("\""); //$NON-NLS-1$
        ps.print(ASTConstants.getToken(this.getOperator()));
        ps.print("\""); //$NON-NLS-1$
    }

    public abstract int getOperator();
    public abstract boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException;

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        FBSType type1 = leftNode.getResultType(jsContext,symbolCallback);
        FBSType type2 = rightNode.getResultType(jsContext,symbolCallback);
        return Utility.operationType(type1,type2,getOperator());
    }

    public boolean isConstant() {
        return leftNode.isConstant() && rightNode.isConstant();
    }

    public FBSValue evaluateConstant(IExecutionContext context) throws InterpretException {
        FBSValue v1 = leftNode.evaluateConstant(context);
        FBSValue v2 = rightNode.evaluateConstant(context);
        return Utility.operation(context,v1,v2,getOperator());
    }
}
