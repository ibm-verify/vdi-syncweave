/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.ibm.commons.util.FastStringBuffer;
import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.engine.IExecutionContext;

public abstract class GeneratedWrapperObject extends JavaWrapperObject {

    // The following strings are used by the generated classes
    // This prevents the generated classes to have some localizable strings
    public static final String STRING_1 = "Exception occurred constructing instance of class {0}"; // $NLS-GeneratedWrapperObject.Exceptionwhileconstructinganinsta-1$
    public static final String STRING_2 = "Cannot construct instance of class {0}"; // $NLS-GeneratedWrapperObject.Cannotconstructaninstanceofclass0.1-1$
    public static final String STRING_3 = "Exception occurred calling method {0}.{1}"; // $NLS-GeneratedWrapperObject.Exceptionwhilecallingmethod01-1$
    public static final String STRING_4 = "Method {0}.{1} not found, or illegal parameters"; // $NLS-GeneratedWrapperObject.Method01notfoundorillegalparamete-1$
    
    
    
    // the FieldFlag class is a flag to indicate that the object in the MethodMap
    // is not a method but a field.
    //PHIL: this should be changed and use the same mechanism than method
    public static abstract class AbstractField {
        JSContext jsContext;
        FBSType type;
        public AbstractField(JSContext jsContext, String typeName) {
            this.jsContext = jsContext;
            this.type = FBSType.getType(jsContext,typeName);
        }
        public FBSType getType() {
            return type;
        }
    }
    public static class StaticField extends AbstractField {
        public StaticField(JSContext jsContext, String typeName) {
            super(jsContext, typeName);
        }
    }
    public static class Field extends AbstractField {
        public Field(JSContext jsContext, String typeName) {
            super(jsContext, typeName);
        }
    }

    public static class MethodMap { //extends HashMap {
        private HashMap _map;
        private JSContext _jsContext;
        private Class _wrappedClass;
        private MethodMap[] _superMap;
        private Class[] _delegateTargets;
        private MethodMap[] _delegateMap;
        public MethodMap(JSContext jsContext, Class wrappedClass, Class[] delegateTargets) {
            this._map = new HashMap(); 
            this._jsContext = jsContext;
            this._wrappedClass = wrappedClass;
            this._delegateTargets = delegateTargets;
            
            // Temporarily debug code
            if(_wrappedClass==java.util.Map.class) {
                StringBuilder b = new StringBuilder();
                if(delegateTargets!=null) {
                    for(int i=0; i<delegateTargets.length; i++) {
                        b.append(delegateTargets[i].getName());
                    }
                } else {
                    b.append("<null>"); // $NON-NLS-1$
                }
                throw new RuntimeException(StringUtil.format("Wrapping Java MAP, {0}",b.toString())); // $NON-NLS-1$
            }
        }
        public Class<?> getWrappedClass() {
            return _wrappedClass;
        }
        public Class<?>[] getDelegateTargets() {
            return _delegateTargets;
        }
        final void fillAllPropertiesForHelp(Set set, boolean onlyNames) {
            // 1. Browse all the properties within this object
            for( Iterator it=_map.entrySet().iterator(); it.hasNext(); ) {
                Map.Entry e = (Map.Entry)it.next();
                String key = (String)e.getKey();
                if(onlyNames) {
                    set.add(key);
                } else {
                    Object o = e.getValue();
                    if (o instanceof AbstractField){
                        Descriptor.Field f = new Descriptor.Field(_jsContext,key,((AbstractField)o).type,(o instanceof StaticField));
                        if( !f.isHidden() ) {
                            set.add(f);
                        }
                    }else{
                        Function f = (Function)o;
                        String[] args = f.getCallParameters();
                        if( args!=null ) {
                            for( int i=0; i<args.length; i++ ) {
                                Descriptor.Method m = new Descriptor.Method(_jsContext,key,args[i]);
                                if( !m.isHidden() ) {
                                    set.add(m);
                                }
                            }
                        } else {
                            Descriptor.Method m = new Descriptor.Method(_jsContext,key,FBSType.undefinedType,null);
                            set.add(m);
                        }
                    }
                }
            }
            
            // 2. Add the ancestor methods
            MethodMap[] supers = getSuperClasses();
            if(supers!=null) {
                for( int i=0; i<supers.length; i++ ) {
                    supers[i].fillAllPropertiesForHelp(set,onlyNames);
                }
            }
            
            // 3. Add the delegated methods
            MethodMap[] delegates = getDelegateClasses();
            if(delegates!=null) {
                for( int i=0; i<delegates.length; i++ ) {
                    delegates[i].fillAllPropertiesForHelp(set,onlyNames);
                }
            }
        }
        
        public Object get(String pName) {
            // Look inside the map itself
            Object func = _map.get(pName);
            if(func!=null) {
                return func;
            }
            
            // Look for the ancestor
            MethodMap[] ancestors = getSuperClasses();
            for( int i=0; i<ancestors.length; i++ ) {
                // Get the method map of that wrapper
                try {
                    MethodMap map = ancestors[i];
                    FBSValue f = (FBSValue)map.get(pName);
                    if( f!=null && !f.isUndefined() ) {
                        return f;
                    }
                } catch( Exception ex ) {}
            }

            // Look inside the delegated classes
            MethodMap[] delegates = getDelegateClasses();
            if( delegates!=null ) {
                for( int i=0; i<delegates.length; i++ ) {
                    MethodMap map = delegates[i];
                    FBSValue f = (FBSValue)map.get(pName);
                    if( f!=null && !f.isUndefined() ) {
                        return f;
                    }
                }
            }
            
            // Look for the basic, common object methods
            Object o = _jsContext.getRegistry().javaObjectPrototype.get(pName);
            return o;
        }

        public boolean containsKey(String pName) {
            // Look inside the map itself
            if(_map.containsKey(pName)) {
                return true;
            }
            
            // Look for the ancestor
            MethodMap[] ancestors = getSuperClasses();
            for( int i=0; i<ancestors.length; i++ ) {
                // Get the method map of that wrapper
                try {
                    MethodMap map = ancestors[i];
                    if(map.containsKey(pName)) {
                        return true;
                    }
                } catch( Exception ex ) {}
            }

            // Look inside the delegated classes
            MethodMap[] delegates = getDelegateClasses();
            if( delegates!=null ) {
                for( int i=0; i<delegates.length; i++ ) {
                    MethodMap map = delegates[i];
                    if(map.containsKey(pName)) {
                        return true;
                    }
                }
            }
            return false;
        }
        
        public void put(String pName, Object object) {
            _map.put(pName, object);
        }
        
        private MethodMap[] getSuperClasses() {
            if(_superMap==null) {
                synchronized(this) {
                    if(_superMap==null) {
                        Class wc = _wrappedClass;
                        if(wc.isInterface()) {
                            Class[] ci = wc.getInterfaces();
                            if(ci!=null) {
                                ArrayList supers = null;
                                for( int i=0; i<ci.length; i++ ) {
                                    IWrapperFactory wrapper=_jsContext.getRegistry().getWrapper(ci[i]);
                                    if( wrapper!=null ) { // There's a wrapper for that class
                                        // Get the method map of that wrapper
                                        try {
                                            MethodMap obj = wrapper.getMethodMap(_jsContext);
                                            if(supers==null) {
                                                supers = new ArrayList();
                                            }
                                            supers.add(obj);
                                        } catch( Exception ex ) {}
                                    }
                                }
                                if(supers!=null) {
                                    _superMap = (MethodMap[])supers.toArray(new MethodMap[supers.size()]);
                                }
                            }
                        } else {
                            Class c = _wrappedClass.getSuperclass();
                            while( c!=null ) {
                                IWrapperFactory wrapper=_jsContext.getRegistry().getWrapper(c);
                                if( wrapper!=null ) { // There's a wrapper for that class
                                    // Get the method map of that wrapper
                                    try {
                                        MethodMap obj = wrapper.getMethodMap(_jsContext);
                                        _superMap = new MethodMap[]{obj};
                                        return _superMap;
                                    } catch( Exception ex ) {}
                                }
                                c = c.getSuperclass();
                            }
                        }
                        if(_superMap==null) {
                            _superMap = noClasses;
                        }
                    }
                }
            }
            return _superMap;
        }
        private MethodMap[] getDelegateClasses() {
            if (_delegateMap==null) {
                synchronized(this) {
                    if (_delegateMap==null) {
                        if(_delegateTargets!=null) {
                            ArrayList l = new ArrayList();
                            for (int i = 0; i<_delegateTargets.length; i++) {
                                IWrapperFactory wrapper = _jsContext.getRegistry().getWrapper(_delegateTargets[i]);
                                if (wrapper != null) {
                                    try {
                                        MethodMap m = wrapper.getMethodMap(_jsContext);
                                        l.add(m);
                                    } catch (Exception ex) {
                                    }
                                }
                            }
                            if(l.size()>0) {
                                _delegateMap = (MethodMap[])l.toArray(new MethodMap[l.size()]);
                            }
                        }
                        if(_delegateMap==null) {
                            _delegateMap = noClasses;
                        }
                    }
                }
            }
            return _delegateMap;
        }
        
        private static final MethodMap[] noClasses = new MethodMap[0]; 
    }

    
    /**
     * Constructor definition.
     * This class is extended by the generated constructors.
     */
    public static abstract class Constructor extends FBSConstructor {
        
        private String name;
        
        protected Constructor(JSContext jsContext, String name) {
            super(jsContext);
            this.name = name;
        }
        
        public String getName() {
            return name;
        }

        public FBSType getFBSType(JSContext context){
            return new FBSType.JSWrappedJavaClass(this);
        }

        protected final boolean canCall( FBSValueVector args, Class c0 ) {
            return args.getFBSValue(0).isJavaAssignableTo(c0);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3, Class c4 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3)
                   && args.getFBSValue(4).isJavaAssignableTo(c4);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3, Class c4, Class c5 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3)
                   && args.getFBSValue(4).isJavaAssignableTo(c4)
                   && args.getFBSValue(5).isJavaAssignableTo(c5);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3, Class c4, Class c5, Class c6 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3)
                   && args.getFBSValue(4).isJavaAssignableTo(c4)
                   && args.getFBSValue(5).isJavaAssignableTo(c5)
                   && args.getFBSValue(6).isJavaAssignableTo(c6);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3, Class c4, Class c5, Class c6, Class c7 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3)
                   && args.getFBSValue(4).isJavaAssignableTo(c4)
                   && args.getFBSValue(5).isJavaAssignableTo(c5)
                   && args.getFBSValue(6).isJavaAssignableTo(c6)
                   && args.getFBSValue(7).isJavaAssignableTo(c7);
        }
        public void getAllPropertiesForHelp(JSContext context, Set members) {
            JSContext jsContext = getJSContext();
            // Fill the available ctors
            String[] cArgs = getCallParameters();
            if( cArgs!=null ) {
                for( int i=0; i<cArgs.length; i++ ) {
                    Descriptor.Constructor c = new Descriptor.Constructor(jsContext,getName(),cArgs[i]);
                    members.add(c);
                }
            }
            try {
                GeneratedWrapperObject gw=(GeneratedWrapperObject)jsContext.getRegistry().getWrapper(getWrappedClass()).wrap(jsContext,null);
                gw.getAllPropertiesForHelp(context, members);
            } catch(Exception e) {
                e.printStackTrace();
            }
        }

        public GeneratedWrapperObject getWrapperObject(JSContext jsContext) {
            try {
                GeneratedWrapperObject gw=(GeneratedWrapperObject)jsContext.getRegistry().getWrapper(getWrappedClass()).wrap(jsContext,null);
                return gw;
            } catch(Exception e) {}
            return null;
        }
        // We allow a call to static methods
        public boolean supportCall(){
            return true;
        }

        // gets static fields
        public FBSValue getField(String pName){
            return FBSUndefined.undefinedValue;
        }

        public FBSValue get(String pName) {
            Object o = getMethodMap().get(pName);
            if (o instanceof GeneratedWrapperObject.AbstractField){
                return getField(pName);
            }
            FBSValue func = (FBSValue)o;
            if( func!=null ) {
                return func;
            }
// TODO: get the parent static methods...
            return FBSUndefined.undefinedValue;
        }

        public boolean hasInstance(FBSValue v){
            if( v instanceof JavaWrapperObject ) {
                Object o = ((JavaWrapperObject)v).getJavaObject();
                if( o!=null && getWrappedClass().isAssignableFrom(o.getClass()) ) {
                    return true;
                }
            }
            return false;
        }

        protected abstract MethodMap getMethodMap();
        protected abstract Class getWrappedClass();

        protected String getConstructorString(FBSValueVector args) {
            FastStringBuffer b = new FastStringBuffer();
            b.append( getName() );
            b.append( "(" );
            if( args!=null ) {
                for( int i=0; i<args.size(); i++ ){
                    if( i>0 ) {
                        b.append( ", " );
                    }
                    b.append( StringUtil.format( "{0}", args.getFBSValue(i).getTypeAsString() ));
                }
            }
            b.append( ")" );
            return b.toString();
        }
    }
    // An empty construtor
    // This ensure that a class cannot be constructed.
    public static abstract class EmptyConstructor extends Constructor {
        public EmptyConstructor(JSContext jsContext, String name) {
            super(jsContext,name);
        }
        public FBSObject construct(IExecutionContext context, FBSValueVector args) throws InterpretException {
            throw new InterpretException(null,StringUtil.format("Cannot construct an instance of class '{0}'",getConstructorString(args))); // $NLS-GeneratedWrapperObject.Cannotconstructaninstanceofclass0-1$
        }
    }

    /**
     * Function definition.
     * This class is extended by the generated functions.
     */
    public static abstract class Function extends BuiltinFunction {

        protected Function( JSContext jsContext, String name, int index ) {
            super(jsContext,name);
            this.index = index;
        }
        public FBSType getFBSType(JSContext context){
            return new FBSType.JSWrappedJavaMethodType(this);
        }
        protected final boolean canCall( FBSValueVector args, Class c0 ) {
            return args.getFBSValue(0).isJavaAssignableTo(c0);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3, Class c4 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3)
                   && args.getFBSValue(4).isJavaAssignableTo(c4);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3, Class c4, Class c5 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3)
                   && args.getFBSValue(4).isJavaAssignableTo(c4)
                   && args.getFBSValue(5).isJavaAssignableTo(c5);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3, Class c4, Class c5, Class c6 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3)
                   && args.getFBSValue(4).isJavaAssignableTo(c4)
                   && args.getFBSValue(5).isJavaAssignableTo(c5)
                   && args.getFBSValue(6).isJavaAssignableTo(c6);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3, Class c4, Class c5, Class c6, Class c7 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3)
                   && args.getFBSValue(4).isJavaAssignableTo(c4)
                   && args.getFBSValue(5).isJavaAssignableTo(c5)
                   && args.getFBSValue(6).isJavaAssignableTo(c6)
                   && args.getFBSValue(7).isJavaAssignableTo(c7);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3, Class c4, Class c5, Class c6, Class c7, Class c8 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3)
                   && args.getFBSValue(4).isJavaAssignableTo(c4)
                   && args.getFBSValue(5).isJavaAssignableTo(c5)
                   && args.getFBSValue(6).isJavaAssignableTo(c6)
                   && args.getFBSValue(7).isJavaAssignableTo(c7)
                   && args.getFBSValue(8).isJavaAssignableTo(c8);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3, Class c4, Class c5, Class c6, Class c7, Class c8, Class c9 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3)
                   && args.getFBSValue(4).isJavaAssignableTo(c4)
                   && args.getFBSValue(5).isJavaAssignableTo(c5)
                   && args.getFBSValue(6).isJavaAssignableTo(c6)
                   && args.getFBSValue(7).isJavaAssignableTo(c7)
                   && args.getFBSValue(8).isJavaAssignableTo(c8)
                   && args.getFBSValue(9).isJavaAssignableTo(c9);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3, Class c4, Class c5, Class c6, Class c7, Class c8, Class c9, Class c10 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3)
                   && args.getFBSValue(4).isJavaAssignableTo(c4)
                   && args.getFBSValue(5).isJavaAssignableTo(c5)
                   && args.getFBSValue(6).isJavaAssignableTo(c6)
                   && args.getFBSValue(7).isJavaAssignableTo(c7)
                   && args.getFBSValue(8).isJavaAssignableTo(c8)
                   && args.getFBSValue(9).isJavaAssignableTo(c9)
                   && args.getFBSValue(10).isJavaAssignableTo(c10);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3, Class c4, Class c5, Class c6, Class c7, Class c8, Class c9, Class c10, Class c11 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3)
                   && args.getFBSValue(4).isJavaAssignableTo(c4)
                   && args.getFBSValue(5).isJavaAssignableTo(c5)
                   && args.getFBSValue(6).isJavaAssignableTo(c6)
                   && args.getFBSValue(7).isJavaAssignableTo(c7)
                   && args.getFBSValue(8).isJavaAssignableTo(c8)
                   && args.getFBSValue(9).isJavaAssignableTo(c9)
                   && args.getFBSValue(10).isJavaAssignableTo(c10)
                   && args.getFBSValue(11).isJavaAssignableTo(c11);
        }
        protected final boolean canCall( FBSValueVector args, Class c0, Class c1, Class c2, Class c3, Class c4, Class c5, Class c6, Class c7, Class c8, Class c9, Class c10, Class c11, Class c12 ) {
            return    args.getFBSValue(0).isJavaAssignableTo(c0)
                   && args.getFBSValue(1).isJavaAssignableTo(c1)
                   && args.getFBSValue(2).isJavaAssignableTo(c2)
                   && args.getFBSValue(3).isJavaAssignableTo(c3)
                   && args.getFBSValue(4).isJavaAssignableTo(c4)
                   && args.getFBSValue(5).isJavaAssignableTo(c5)
                   && args.getFBSValue(6).isJavaAssignableTo(c6)
                   && args.getFBSValue(7).isJavaAssignableTo(c7)
                   && args.getFBSValue(8).isJavaAssignableTo(c8)
                   && args.getFBSValue(9).isJavaAssignableTo(c9)
                   && args.getFBSValue(10).isJavaAssignableTo(c10)
                   && args.getFBSValue(11).isJavaAssignableTo(c11)
                   && args.getFBSValue(12).isJavaAssignableTo(c12);
        }

        protected abstract MethodMap getMethodMap();
        protected abstract Class getWrappedClass();

        protected String getFunctionString(FBSValueVector args) {
            FastStringBuffer b = new FastStringBuffer();
            b.append( getFunctionName() );
            b.append( "(" );
            if( args!=null ) {
                for( int i=0; i<args.size(); i++ ){
                    if( i>0 ) {
                        b.append( ", " );
                    }
                    b.append( StringUtil.format( "{0}", args.getFBSValue(i).getTypeAsString() ));
                }
            }
            b.append( ")" );
            return b.toString();
        }

        protected int index;
    }

    private Object object;
    private String name;
    
    protected GeneratedWrapperObject( JSContext jsContext, Object object, String name ) {
        super(jsContext);
        this.object = object;
        this.name = name;
    }
    
    public String getName() {
        return name;
    }


    public abstract MethodMap getMethodMap();

    public abstract Class getWrappedClass();


    public Class getDelegateTarget() {
        return null;
    }

    public boolean canPut(String name){
        return false;
    }

    public void put(String name,FBSValue v){
    }

    public boolean supportConstruct(){
        return true;
    }

    public FBSObject construct(IExecutionContext context, FBSValueVector args) throws InterpretException {
        throw new InterpretException( null,"construct() method not implemented in {0}", getClass().getName() ); // $NLS-GeneratedWrapperObject.constructmethodisnotimplementedin-1$
    }

    /**
     * Gets the value of a FIELD
     * Does not search a method, just fields.
     * To be implemented by subclasses.
     * @return the value of a field.
     */
    public FBSValue getField(String pName){
        return null;
    }

    /**
     * Gets a help string on a FIELD
     * To be implemented by subclasses.
     * @return help string.
     */
    public String getHelpOnField( String name ) {
        return null;
    }

    public FBSValue get(String pName){
        Object o = getMethodMap().get(pName);
        if (o!=null){
            if (o instanceof AbstractField){
                return getField(pName);
            }
            FBSValue func = (FBSValue)o;
            return func;
        }
        
        // Ok, we don't know that property!
        return FBSUndefined.undefinedValue;
    }

    public boolean hasProperty(String pName){
        return getMethodMap().containsKey(pName);
    }

    public FBSReference getPropertyReference(String name) throws InterpretException {
        Object o = getMethodMap().get(name);
        if (o instanceof FBSValue){
            return new FBSReferenceByName.ResolvedReference(this,name,(FBSValue)o);
        }
        if(o!=null) {
            // This is a field - return a reference by name
            return new FBSReferenceByName(this,name);
        }
        return null;
    }

    public Object getJavaObject() {
        return object;
    }


    // A java object can just have fixed properties
    public void getAllPropertiesForHelp(JSContext context, Set members) {
        getMethodMap().fillAllPropertiesForHelp(members,false);
    }

    public Iterator getPropertyKeys() {
        Set set = new HashSet();
        getMethodMap().fillAllPropertiesForHelp(set,true);
        return set.iterator();
    }
    
    
    public String getDebugString() {
        StringBuilder b = new StringBuilder();
        b.append(getMethodMap().getWrappedClass().getName());
        Class[] delegate = getMethodMap().getDelegateTargets();
        if(delegate!=null) {
            b.append(": ");
            for(int i=0; i<delegate.length; i++) {
                if(i>0) {
                    b.append(',');
                }
                b.append(delegate[i].getName());
            }
        }
        return b.toString();
    }
}