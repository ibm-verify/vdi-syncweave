/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2008                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import java.io.PrintStream;
import java.util.GregorianCalendar;

import com.ibm.commons.util.DateTime;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.parser.ParseException;
import com.ibm.jscript.std.DateObject;
import com.ibm.jscript.types.FBSBoolean;
import com.ibm.jscript.types.FBSNull;
import com.ibm.jscript.types.FBSNumber;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSValue;

public class ASTLiteral extends ASTNode {

	private FBSType type;
	private FBSValue fbsValue;

	public ASTLiteral() {
		this.type = FBSType.undefinedType;
		this.fbsValue = FBSUndefined.undefinedValue;
	}

	public ASTLiteral(int v) {
		this.type = FBSType.numberType;
		this.fbsValue = FBSNumber.get(v);
	}

	public ASTLiteral(long v) {
		this.type = FBSType.numberType;
		this.fbsValue = FBSNumber.get(v);
	}

	public ASTLiteral(double v) {
		this.type = FBSType.numberType;
		this.fbsValue = FBSNumber.get(v);
	}

	public ASTLiteral(boolean v) {
		this.type = FBSType.booleanType;
		this.fbsValue = FBSBoolean.get(v);
	}

	public ASTLiteral(String v) {
		this.type = FBSType.stringType;
		// Similarly to the String constants in a class, we intern the strings
		this.fbsValue = FBSString.get(v.intern());
	}
	
	public String getStringProlog() {
		if(type==FBSType.stringType) {
			return fbsValue.stringValue();
		}
		return null;
	}

	public String getTraceString() {
		return getValue().stringValue();
	}

	public FBSValue getValue() {
		return fbsValue;
	}

	private static int hexval(char c) throws ParseException {
		switch (c) {
			case '0':
				return 0;
			case '1':
				return 1;
			case '2':
				return 2;
			case '3':
				return 3;
			case '4':
				return 4;
			case '5':
				return 5;
			case '6':
				return 6;
			case '7':
				return 7;
			case '8':
				return 8;
			case '9':
				return 9;
	
			case 'a':
			case 'A':
				return 10;
			case 'b':
			case 'B':
				return 11;
			case 'c':
			case 'C':
				return 12;
			case 'd':
			case 'D':
				return 13;
			case 'e':
			case 'E':
				return 14;
			case 'f':
			case 'F':
				return 15;
		}
        throw new ParseException("Internal error when evaluating hexadecimal escape sequence"); // $NLS-ASTLiteral.Internalerrorwhenevaluatinghexade-1$
	}

	private static int octval(char c) throws ParseException {
		switch (c) {
			case '0':
				return 0;
			case '1':
				return 1;
			case '2':
				return 2;
			case '3':
				return 3;
			case '4':
				return 4;
			case '5':
				return 5;
			case '6':
				return 6;
			case '7':
				return 7;
			case '8':
				return 8;
			case '9':
				return 9;
		}
        throw new ParseException("Internal error when evaluating octal escape sequence"); // $NLS-ASTLiteral.Internalerrorwhenevaluatingoctale-1$
	}

	public void setStringValue(String image) throws ParseException {
		this.type = FBSType.stringType;

		if ((image.startsWith("\"") && image.endsWith("\"")) //$NON-NLS-1$ //$NON-NLS-2$
				|| (image.startsWith("'") && image.endsWith("'"))) { //$NON-NLS-1$ //$NON-NLS-2$
			image = image.substring(1, image.length() - 1);
		}
		int l = image.length();
		StringBuilder sb = new StringBuilder(l);
		for (int i = 0; i < l; i++) {
			char c = image.charAt(i);
			if (c == '\\') {
				i++;
				if(i<l) {
					c = image.charAt(i);
					if (c == 'n')
						c = '\n';
					else if (c == 'b')
						c = '\b';
					else if (c == 'f')
						c = '\f';
					else if (c == 'r')
						c = '\r';
					else if (c == 't')
						c = '\t';
					else if (c == 'v')
						c = 0x000b;
					else if (c == 'x' && i+2<l && isHexaDigit(image.charAt(i+1)) && isHexaDigit(image.charAt(i+2))) {
						c = (char) (hexval(image.charAt(i+1)) << 4 
								  | hexval(image.charAt(i+2)));
						i += 2;
					} else if (c == 'u' && i+4<l && isHexaDigit(image.charAt(i+1)) && isHexaDigit(image.charAt(i+2)) && isHexaDigit(image.charAt(i+3)) && isHexaDigit(image.charAt(i+4))) {
						c = (char) (hexval(image.charAt(i+1)) << 12
								  | hexval(image.charAt(i+2)) << 8
								  | hexval(image.charAt(i+3)) << 4 
								  | hexval(image.charAt(i+4)));
						i += 4;
					} else if ( i+1<l && isOctalDigit(c) && isOctalDigit(image.charAt(i+1)) ) {
						c = (char) (octval(c) << 3
						          | octval(image.charAt(i+1)));
						i += 1;
					}
				}
			}
			sb.append(c);
		}
		// Similarly to the String constants in a class, we intern the strings
		fbsValue = FBSString.get(sb.toString().intern());
	}
	private static boolean isOctalDigit(char c) {
		return c>='0' && c<='7';
	}
	private static boolean isHexaDigit(char c) {
		return (c>='0' && c<='9') || (c>='A' && c<='F') || (c>='a' && c<='f');
	}

	public void setDecimalValue(String image) {
		this.type = FBSType.numberType;
		this.fbsValue = FBSNumber.get(image);
	}

	public void setOctalValue(String image) {
		this.type = FBSType.numberType;
		if(image.equals("0")) {
			fbsValue = FBSNumber.Zero;
		} else {
			try {
				String imageWithout0 = image.substring(1);
				this.fbsValue = FBSNumber.get(Long.parseLong(imageWithout0, 8));
			} catch (NumberFormatException e) {
				fbsValue = FBSNumber.get(image);
			}
		}
	}

	public void setHexValue(String image) {
		this.type = FBSType.numberType;
		try {
			String imageWithout0x = image.substring(2);
			this.fbsValue = FBSNumber.get(Long.parseLong(imageWithout0x, 16));
		} catch (NumberFormatException e) {
			fbsValue = FBSNumber.get(image);
		}
	}

	public void setBooleanValue(boolean value) {
		this.type = FBSType.booleanType;
		this.fbsValue = FBSBoolean.get(value);
	}

	public void setDateValue(JSContext jsContext,String image)
			throws com.ibm.jscript.parser.ParseException {
		this.type = FBSType.dateType;
        this.fbsValue = DateObject.parse(jsContext,image);
	}

	public static long parseDate(String image) throws InterpretException {
		DateParser dp = new DateParser();
		try {
			return dp.parseDate(image);
		} catch (com.ibm.jscript.parser.ParseException e) {
			throw new InterpretException(null,
					"Illegal date"); //$NLS-ASTLiteral.ASTLiteral.IllegalDate.Exception-1$
		}
	}

	static class DateParser {
		int pos = 0;

		StringBuffer buf;

		char dateSep = '0';

		char timeSep = '0';

		static final String dateSeparators = ";,./- \t"; //$NON-NLS-1$

		static final String timeSeparators = ":. \t"; //$NON-NLS-1$

		static final String dateTimeSeparators = "- Tt"; //$NON-NLS-1$

		public long parseDate(String image)
				throws com.ibm.jscript.parser.ParseException {
			buf = new StringBuffer(image);
			// strip # if present
			if (buf.length() > 1) {
				if (!Character.isDigit(buf.charAt(0))) {
					buf.deleteCharAt(0);
				}
				if (!Character.isDigit(buf.charAt(buf.length() - 1))) {
					buf.deleteCharAt(buf.length() - 1);
				}
			}
			int year = 2000;
			int month = 0;
			int day = 1;
			int hour = 0;
			int min = 0;
			int sec = 0;

			int sz = buf.length();
			skipSpace();
			year = getYear();
			if (year <= 99 && year >= 40) {
				year += 1900;
			} else if (year < 40) {
				year += 2000;
			}
			if (pos < sz) {// 1
				getSep(0);
				// the month in java Date is between 0 and 11
				month = get2Digit() - 1;
				if (pos < sz) {// 2
					getSep(0);
					day = get2Digit();
					if (pos < sz) {// 3
						getSep(1);
						hour = get2Digit();
						if (pos < sz) {// 4
							getSep(2);
							min = get2Digit();
							if (pos < sz) {// 5
								getSep(2);
								sec = get2Digit();
							}// 5
						}// 4
					}// 3
				}// 2
			}// 1
			DateTime.TGregorianCalendar c = DateTime.getCalendar();
			try {
				c.set(year, month, day, hour, min, sec);
				c.set(GregorianCalendar.MILLISECOND, 0);
				return c.getMillis();
			} finally {
				DateTime.recycleCalendar(c,false);
			}
		}

		private void getSep(int sepType)
				throws com.ibm.jscript.parser.ParseException {
			skipSpace();
			char c = buf.charAt(pos);
			if (Character.isDigit(c)) {
				c = ' ';
			} else {
				pos++;
			}

			if (sepType == 0) {// date separator
				if (dateSeparators.indexOf(c) < 0) {
					throw new com.ibm.jscript.parser.ParseException(
									"Illegal separator"); //$NLS-ASTLiteral.ASTLiteral.IllegalSeparator.Exception-1$
				}
				if (dateSep == '0') {
					dateSep = c;
				} else if (dateSep != c) {
					throw new com.ibm.jscript.parser.ParseException(
									"Use same separator in date"); //$NLS-ASTLiteral.ASTLiteral.ParseDateError.Exception-1$
				}
			} else if (sepType == 1) {// dateTime separator
				if (dateTimeSeparators.indexOf(c) < 0) {
					throw new com.ibm.jscript.parser.ParseException(
									"Illegal separator"); //$NLS-ASTLiteral.ASTLiteral.IllegalSeparator.Exception-1$
				}
			} else if (sepType == 2) {// time separator
				if (timeSeparators.indexOf(c) < 0) {
					throw new com.ibm.jscript.parser.ParseException(
									"Illegal separator"); //$NLS-ASTLiteral.ASTLiteral.IllegalSeparator.Exception-1$
				}
				if (timeSep == '0') {
					timeSep = c;
				} else if (timeSep != c) {
					throw new com.ibm.jscript.parser.ParseException(
									"Use same separator in time"); //$NLS-ASTLiteral.ASTLiteral.ParseTimeError.Exception-1$
				}
			}
			skipSpace();
		}

		private void skipSpace() {
			int sz = buf.length();
			while (pos < sz) {
				char c = buf.charAt(pos);
				if (!Character.isSpaceChar(c)) {
					return;
				}
				pos++;
			}
		}

		private int getYear() throws com.ibm.jscript.parser.ParseException {
			int cnt = 0;
			int year = 0;
			int sz = buf.length();
			while (cnt <= 4 && pos < sz) {
				cnt++;
				char c = buf.charAt(pos);
				if (!Character.isDigit(c)) {
					return year;
				}
				year = (year * 10) + Character.getNumericValue(c);
				pos++;
			}
			if (pos >= sz)
				return year;
			throw new com.ibm.jscript.parser.ParseException(
					"Illegal year"); //$NLS-ASTLiteral.ASTLiteral.IllegalYear.Exception-1$
		}

		private int get2Digit() throws com.ibm.jscript.parser.ParseException {
			int cnt = 0;
			int val = 0;
			int sz = buf.length();
			while (cnt <= 2 && pos < sz) {
				cnt++;
				char c = buf.charAt(pos);
				if (!Character.isDigit(c)) {
					return val;
				}
				val = (val * 10) + Character.getNumericValue(c);
				pos++;
			}
			if (pos >= sz)
				return val;
			throw new com.ibm.jscript.parser.ParseException(
					"Illegal date"); //$NLS-ASTLiteral.ASTLiteral.IllegalDate.Exception-1$
		}

	}

	public void setNullValue() {
		this.type = FBSType.undefinedType;
		this.fbsValue = FBSNull.nullValue;
	}

	public void setUndefinedValue() {
		this.type = FBSType.undefinedType;
		this.fbsValue = FBSUndefined.undefinedValue;
	}

	public int getSlotCount() {
		return 0;
	}

	public ASTNode readSlotAt(int index) {
		return null;
	}

	public String toString() {
		return fbsValue.stringValue();
	}

	public boolean interpret(ASTNode caller, IExecutionContext context, InterpretResult result) throws JavaScriptException {
		result.setNormal(fbsValue);
		return true;
	}

	public FBSType getResultType(JSContext jsContext,
			FBSType.ISymbolCallback symbolCallback) {
		return type;
	}

	public boolean isConstant() {
		return true;
	}

	public FBSValue evaluateConstant(IExecutionContext context)
			throws InterpretException {
		return fbsValue;
	}

	protected void extraInfo(PrintStream ps, String indent) {
		ps.print("value="); //$NON-NLS-1$
		ps.print(fbsValue.stringValue());
	}

	public Object visit(ASTNodeVisitor v, Object param) {
		return v.visitLiteral(this, param);
	}
}
