/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2010                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript;

import java.io.PrintWriter;
import java.util.ArrayList;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.ASTTree.ASTNode;
import com.ibm.jscript.JSContext.ILibrary;
import com.ibm.jscript.engine.FunctionContext;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.std.ErrorObject;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.JavaAccessObject;
import com.ibm.jscript.util.JSErrorReport;

/**
 * Javascript Interpreter Exception.
 * This exception is thrown when the interpret encounters a runtime exception,
 * for example when calling a method that does not exist.<br>
 * This exception shoud only be instanciated by the engine, not by custom code.
 */
public class InterpretException extends JavaScriptException {

	public static class CallStack {
		private ILibrary library;
		private String method;
		private FBSDefaultObject arguments;
		CallStack(ILibrary library, String method, FBSDefaultObject arguments) {
			this.library = library;
			this.method = method;
			this.arguments = arguments;
		}
		public ILibrary getLibrary() {
			return library;
		}
		public String getMethod() {
			return method;
		}
		public FBSValue getArguments() {
			return arguments;
		}
		public String toString() {
			StringBuilder b = new StringBuilder();
			if(library!=null) {
				String libName = library.getName();
				if(StringUtil.isNotEmpty(libName)) {
					b.append("[");
					b.append(library);
					b.append("].");
				}
			}
			if(StringUtil.isNotEmpty(method)) {
				b.append(method);
			} else {
				b.append("<anonymous>"); //$NON-NLS-1$
			}
			b.append("(");
			if(arguments!=null) {
				try {
					int length = arguments.getProperty("length").intValue(); //$NON-NLS-1$
					for(int i=0; i<length; i++) {
						if(i>0) {
							b.append(",");
						}
						IValue v = arguments.getProperty(Integer.toString(i));
						if(v!=null) { // Should not happen...
							b.append(StringUtil.toString(v.stringValue(),20));
						}
					}
				} catch(InterpretException ex) {}
			}
			b.append(")");
			return b.toString();
		}
	}
	
	
    /**
     * 
     */
    private static final long serialVersionUID = 1026764134195109561L;

    // Execution points
    private int errorLine;
    private int errorLineEnd;
    private int errorCol;
    private int errorColEnd;
    private String message;
    private String expressionText;
    private CallStack[] callStack;

    private transient ASTNode node;
    private transient Object exceptionObject;

    
    public InterpretException() {
        super((Exception)null, "Interpret exception"); //$NLS-InterpretException.InterpretException.Interpret.Exception-1$
    }

    public InterpretException(Throwable e) {
        super(e, "Interpret exception"); //$NLS-InterpretException.InterpretException.Interpret.Exception-1$
        if( e!=null ) {
            this.exceptionObject=e;
        }
    }

    public InterpretException(Throwable e, String msg, Object...params) {
        super(e,msg,params);
        if( e!=null ) {
            this.exceptionObject=e;
        }
    }

    public InterpretException(Throwable e, FBSValue exceptionObject) {
        super(e,(exceptionObject instanceof ErrorObject)?((ErrorObject)exceptionObject).getMessage().stringValue():"JavaScript exception"); // $NON-NLS-1$
        this.exceptionObject = exceptionObject;
    }

    public String getMessage() {
        if( StringUtil.isEmpty(message) ) {
            return super.getMessage();
        }
        return message;
    }

    public String getExpressionText() {
        return expressionText;
    }
    
    public void setExpressionText(String expressionText) {
        // If the text has already been set by node, ignore the neew one
        if(StringUtil.isEmpty(this.expressionText)) {
            this.expressionText = expressionText;
        }
    }

    /**
     * Get the line number where the error occurred.
     * @return the error line number
     */
    public int getErrorLine() {
        return errorLine;
    }

    /**
     * Get the column number where the error occurred.
     * @return the error column number
     */
    public int getErrorCol() {
        return errorCol;
    }

    /**
     * Get the line number where the error occurred ends.
     * @return the error line number
     */
    public int getErrorLineEnd() {
        return errorLineEnd;
    }

    /**
     * Get the column number where the error occurred ends.
     * @return the error column number
     */
    public int getErrorColEnd() {
        return errorColEnd;
    }
    
    /**
     * Get the exception stack trace.
     * @param context
     * @param node
     * @return
     */
    public CallStack[] getCallStack() {
    	return callStack;
    }

    public InterpretException fillException(IExecutionContext context, ASTNode node ) {
        if( this.node==null ) {
            this.node = node;
            this.expressionText = node.getExpr();
            this.errorLine = node.getBeginLine();
            this.errorLineEnd = node.getEndLine();
            this.errorCol = node.getBeginCol();
            this.errorColEnd = node.getEndCol();
            String msg = super.getMessage();
            if(exceptionObject instanceof ErrorObject) {
                msg = "[" + ((ErrorObject)exceptionObject).getName().stringValue() + "] " + msg; 
            }
            message = StringUtil.format( "Script interpreter error, line={0}, col={1}: {2}", //$NLS-InterpretException.InterpretException.ScriptError.Exception-1$
                        StringUtil.toString(errorLine),
                        StringUtil.toString(errorCol),
                        msg );
            ArrayList<CallStack> st = new ArrayList<CallStack>();
            for(IExecutionContext c=context; c!=null; c=c.getParentContext()) {
            	if(c instanceof FunctionContext) {
            		FunctionContext fc = (FunctionContext)c;
            		ILibrary lib = fc.getLibrary();
            		String method = fc.getFunctionObject().getFunctionNode().getName();
            		CallStack cs = new CallStack(lib,method,fc.getArguments());
            		st.add(cs);
            	}
            }
            if(st.size()>0) {
            	callStack = (CallStack[])st.toArray(new CallStack[st.size()]); 
            }
        }
        return this;
    }
    
    public static InterpretException fillException(Exception t, IExecutionContext context, ASTNode node ) {
    	if(!(t instanceof InterpretException)) {
    		t = new InterpretException(t);
    		((InterpretException)t).fillException(context, node);
    	}
		return ((InterpretException)t).fillException(context, node);
    }

    public ASTNode getNode() {
        return node;
    }

    public FBSValue getExceptionObject(JSContext context) {
        if(exceptionObject!=null) {
            if( exceptionObject instanceof FBSValue ) {
                return (FBSValue)exceptionObject;
            }
            return new JavaAccessObject(context,exceptionObject.getClass(),exceptionObject);
        }
        return null;
    }

    public void printExtraInformation(PrintWriter err) {
    	err.println(getMessage());
    	JSErrorReport.printCallStack(err, this);
    	JSErrorReport.printExpressionText(err, this, false);
    }
    
}