/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.util;

import java.io.PrintStream;
import java.io.PrintWriter;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.InterpretException.CallStack;

/**
 * This is a class that displays information about a Javascript error.
 */
public final class JSErrorReport {
	
    static public void printCallStack(PrintStream out, InterpretException iex) {
    	CallStack[] cs = iex.getCallStack();
    	if(cs!=null) {
    		for(int i=0; i<cs.length; i++) {
    			String s = cs[i].toString();
                out.print("   at "); //$NON-NLS-1$
                out.println(s); //$NON-NLS-1$
    		}
    	}
    }
    static public void printCallStack(PrintWriter out, InterpretException iex) {
    	CallStack[] cs = iex.getCallStack();
    	if(cs!=null) {
    		for(int i=0; i<cs.length; i++) {
    			String s = cs[i].toString();
                out.print("   at "); //$NON-NLS-1$
                out.println(s); //$NON-NLS-1$
    		}
    	}
    }
    
    static public void printExpressionText(PrintStream out, InterpretException iex, boolean alltext) {
        String code = iex.getExpressionText();
        if(code==null) {
        	return;
        }
        code = code.trim();
        if (StringUtil.isNotEmpty(code)) {
            int codeLength = code.length();
            int pos = 0;
            int errline = iex.getErrorLine();
            for (int line = 1; pos < codeLength; line++) {
                int start = pos;
                while (pos < codeLength && code.charAt(pos) != '\n'
                        && code.charAt(pos) != '\r') {
                    pos++;
                }
                boolean show = alltext || Math.abs(line-errline)<3; // 5 lines being displayed 
                boolean iserr = errline == line; 
                if(show) {
	                if (iserr) {
	                    out.print("->"); //$NON-NLS-1$
	                } else {
	                	out.print("  "); //$NON-NLS-1$
	                }
	            	String sLine = StringUtil.toString(line);
	                for (int i = 0; i < 4 - sLine.length(); i++) {
	                    out.print(" "); //$NON-NLS-1$
	                }
	                out.print(sLine);
	                out.print(": "); //$NON-NLS-1$
	                out.print(code.substring(start, pos));
                }
                if (pos < codeLength) {
                    if (code.charAt(pos) == '\n') {
                        pos++;
                        if (pos < codeLength && code.charAt(pos) == '\r') {
                            pos++;
                        }
                    }
                    else if (code.charAt(pos) == '\r') {
                        pos++;
                        if (pos < codeLength && code.charAt(pos) == '\n') {
                            pos++;
                        }
                    }
                }
                if(show) {
	                out.println(""); //$NON-NLS-1$
                }
            }
        }
    }
    
    static public void printExpressionText(PrintWriter out, InterpretException iex, boolean alltext) {
        String code = iex.getExpressionText();
        if(code==null) {
        	return;
        }
        code = code.trim();
        if (StringUtil.isNotEmpty(code)) {
            int codeLength = code.length();
            int pos = 0;
            int errline = iex.getErrorLine();
            for (int line = 1; pos < codeLength; line++) {
                int start = pos;
                while (pos < codeLength && code.charAt(pos) != '\n'
                        && code.charAt(pos) != '\r') {
                    pos++;
                }
                boolean show = alltext || Math.abs(line-errline)<3; // 5 lines being displayed 
                boolean iserr = errline == line; 
                if(show) {
	                if (iserr) {
	                    out.print("->"); //$NON-NLS-1$
	                } else {
	                	out.print("  "); //$NON-NLS-1$
	                }
	            	String sLine = StringUtil.toString(line);
	                for (int i = 0; i < 4 - sLine.length(); i++) {
	                    out.print(" "); //$NON-NLS-1$
	                }
	                out.print(sLine);
	                out.print(": "); //$NON-NLS-1$
	                out.print(code.substring(start, pos));
                }
                if (pos < codeLength) {
                    if (code.charAt(pos) == '\n') {
                        pos++;
                        if (pos < codeLength && code.charAt(pos) == '\r') {
                            pos++;
                        }
                    }
                    else if (code.charAt(pos) == '\r') {
                        pos++;
                        if (pos < codeLength && code.charAt(pos) == '\n') {
                            pos++;
                        }
                    }
                }
                if(show) {
	                out.println(""); //$NON-NLS-1$
                }
            }
        }
    }
}
