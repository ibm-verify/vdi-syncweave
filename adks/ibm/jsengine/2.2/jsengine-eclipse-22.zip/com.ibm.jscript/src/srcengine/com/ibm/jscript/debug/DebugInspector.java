/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.debug;

import com.ibm.jscript.ASTTree.ASTDebug;
import com.ibm.jscript.engine.IExecutionContext;

public class DebugInspector {

    private ServerThread fServerThread = null;
    
    /**************************************************************
     * Constructor
     * Do nothing
     **************************************************************
     */
    //private DebugInspector() {
       //No Public Constructor. 
    //}
    
    //This shouldn't be necessary, while debugging the vm 
    //would occasionally hang in the public constructor (which is called
    //from ProgramContext).  So I changed to use this synchronized method
    //of getting a new DebugInspector, and it seems to have fixed the 
    //problem.
    public static DebugInspector newDebugInspector() {
        try {
            //System.out.println("About to create a new Debug Inspector"); // $NON-NLS-1$
            DebugInspector di = new DebugInspector();
            //System.out.println("Created a new Debug Inspector"); // $NON-NLS-1$
            return di;
        } catch (Throwable t) {
            t.printStackTrace();
        }
        return null;
    }
      
    /**************************************************************
     * INTERPRETER CALLBACK - setExecutionContext(...)
     * This is called from the interpreter before every statement
     * is about to be interpreted.  Since this is called for 
     * every statement, we need to make sure we return 
     * immediately if not debugging
     **************************************************************
     */
    public void setExecutionContext(IExecutionContext theContext, ASTDebug debugNode) {
           
        //Delete the following code:
        //fServerThread = new ServerThread();
        //fServerThread.newContext(theContext);   
        
        
        
        //Quickly return if the debugger is not connected:
        if (!isDebuggerConnected()) {
            return;
        }
        
        //Create a new ServerThread if we don't already have one and call a method 
        //that lets the debugger client get a handle to it:
        if (fServerThread == null) {
            fServerThread = new ServerThread();
            registerWithClient(fServerThread);
        }
                
        //Tell the thread about the new context and let it continue:
        fServerThread.newContext(theContext);   
    }
    
    /**************************************************************
     * INTERPRETER CALLBACK - endOfProgram()
     * This is called from the interpreter to tell us that the interpreter 
     * job is finished. 
     **************************************************************
     */
    public void endOfProgram() {
       fServerThread = null;
       deregisterWithClient();
    }
        
    /**************************************************************
     * DEBUG CLIENT BREAKPOINT - registerWithClient(...)
     * The debug client has a breakpoint on this method so that it can 
     * get a reference to the DebugInspector, ServerThread and Thread.
     **************************************************************
     */
    public void registerWithClient(ServerThread __ServerThread) {
        //System.out.println("REGISTERWITHCLIENT!!!"); //Do Nothing $NON-NLS-1$
    }
     
    /**************************************************************
     * DEBUG CLIENT BREAKPOINT - deregisterWithClient(...)
     * The debug client has a breakpoint on this method so that it can 
     * know when the DebugInspector has finished his job.
     **************************************************************
     */
    public void deregisterWithClient() {
        //Do Nothing
    }
    
    /**************************************************************
     * isDebuggerConnected()
     * Static method that is used by ASTDebug and in this class 
     * to determine if JVMProxy is connected.
     **************************************************************
     */
    public static boolean isDebuggerConnected() {
        return JVMProxy.getInstance().isConnected();
    }
    
    
}
