/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2008                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import java.io.PrintStream;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;

public class ASTCase extends ASTNode {
    boolean _default=false;
    NodeVector nodes = new NodeVector();
    ASTNode expression;

    public ASTCase() {
    }

    public ASTCase(boolean isdefault) {
        setDefault(isdefault);
    }

    public boolean isDefault(){
        return _default;
    }

    public void setDefault(boolean _default){
        this._default=_default;
    }

    public int getSlotCount(){
        return nodes.size();
    }

    public ASTNode readSlotAt(int index){
        return nodes.get(index);
    }

    public ASTNode getExpression(){
        return expression;
    }

    public void setExpression(ASTNode expression){
        this.expression=assignParent(expression);
    }


    public void add(ASTNode node){
        nodes.add(assignParent(node));
    }


    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result ) throws JavaScriptException {
        try {
            // mail from Philippe Riand/Westford/IBM 23/07/2008 20:56
            // Internal error - should not be translated
            throw new InterpretException(null,"Interpret must not be called on ASTCase"); //$NON-NLS-1$
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public boolean interpretStatementList(ASTNode caller, IExecutionContext context,InterpretResult result ) throws JavaScriptException{
        try {
            int count = nodes.size();
            for(int i=0; i<count; i++) {
                if(!nodes.get(i).interpret(this, context, result)) {
                	return false;
                }
            }
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }

    }

    protected void extraInfo(PrintStream ps,String indent){
        ps.print("expr="); // $NON-NLS-1$
        ps.print( expression!=null? expression.toString(): "<empty>" ); // $NON-NLS-1$
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitCase(this, param);
    }
}
