/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.util;

/**
 * Character provider.
 */
public interface ICharProvider {
    public int length();
    public char charAt(int pos);
    public String getString(int fc,int lc);
    public char[] getChars(int fc,int lc,char[] c,int dst);
}

