/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.ASTTree.binaryop.ASTBinaryAdd;
import com.ibm.jscript.ASTTree.binaryop.ASTBinaryDefaultOp;
import com.ibm.jscript.ASTTree.binaryop.ASTBinaryRelAnd;
import com.ibm.jscript.ASTTree.binaryop.ASTBinaryRelOr;

public interface ASTNodeVisitor {

	Object visitArgumentList(ASTArgumentList x, Object param);

	Object visitArrayLiteral(ASTArrayLiteral x, Object param);

	Object visitArrayMember(ASTArrayMember x, Object param);

	Object visitAssign(ASTAssign x, Object param);

	Object visitBinaryAdd(ASTBinaryAdd x, Object param);

	Object visitBinaryDefaultOp(ASTBinaryDefaultOp x, Object param);

	Object visitBinaryRelAnd(ASTBinaryRelAnd x, Object param);

	Object visitBinaryRelOr(ASTBinaryRelOr x, Object param);

	Object visitBlock(ASTBlock x, Object param);

	Object visitBreak(ASTBreak x, Object param);

	Object visitCall(ASTCall x, Object param);

	Object visitCase(ASTCase x, Object param);

	Object visitContinue(ASTContinue x, Object param);

	Object visitDebug(ASTDebug x, Object param);

	Object visitDoWhile(ASTDoWhile x, Object param);

	Object visitExpression(ASTExpression x, Object param);

	Object visitFor(ASTFor x, Object param);

	Object visitForIn(ASTForIn x, Object param);

	Object visitFunction(ASTFunction x, Object param);

	Object visitIdentifier(ASTIdentifier x, Object param);

	Object visitIf(ASTIf x, Object param);

	Object visitImport(ASTImport x, Object param);

	Object visitLabel(ASTLabel x, Object param);

	Object visitLiteral(ASTLiteral x, Object param);

	Object visitMember(ASTMember x, Object param);

	Object visitNew(ASTNew x, Object param);

	Object visitObjectLiteral(ASTObjectLiteral x, Object param);

	Object visitProfile(ASTProfile x, Object param);

	Object visitProgram(ASTProgram x, Object param);

	Object visitRegExp(ASTRegExp x, Object param);

	Object visitReturn(ASTReturn x, Object param);

	Object visitSwitch(ASTSwitch x, Object param);

	Object visitSync(ASTSync x, Object param);

	Object visitTernaryOp(ASTTernaryOp x, Object param);

	Object visitThis(ASTThis x, Object param);

	Object visitThrow(ASTThrow x, Object param);

	Object visitTry(ASTTry x, Object param);

	Object visitUnaryOp(ASTUnaryOp x, Object param);

	Object visitVariableDecl(ASTVariableDecl x, Object param);

	Object visitWhile(ASTWhile x, Object param);

	Object visitWith(ASTWith x, Object param);
}
