/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript;

import java.util.ArrayList;
import java.util.HashSet;

import com.ibm.commons.util.FastStringBuffer;
import com.ibm.commons.util.TDiag;
import com.ibm.jscript.types.Descriptor;
import com.ibm.jscript.types.FBSGlobalObject;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.util.StringParser;

public class JavaScriptSourceInfo {

    private JSContext jsContext;
    private String sourceCode;
    private JSLibrary library;

    public JavaScriptSourceInfo(JSContext jsContext) {
        this.jsContext = jsContext;
    }

    public JavaScriptSourceInfo(JSContext jsContext, String scriptText) {
        this.jsContext = jsContext;
        parse("",scriptText); //$NON-NLS-1$
    }
    
    public JSContext getJSContext() {
        return jsContext;
    }

    public void parse(String name, String sourceCode) {
        this.sourceCode = sourceCode;
        this.library = new JSLibrary(name);
        TJavascriptParser parser = new TJavascriptParser();
        parser.parse(library);
    }

    public JSObject[] getAllObjects(int pos) {
        HashSet <JSObject> set = new HashSet <JSObject> ();
        getAllObjects(set,pos);
        return (JSObject[])set.toArray(new JSObject[set.size()]);
    }
    
    public String getName(){
        return library == null ? "" : library.name;
    }

    private void getAllObjects(HashSet <JSObject> set, int pos) {
        int count = library.getObjectCount();
        for( int i=0; i<count; i++ ) {
            JSObject o = library.getObject(i);
            if( o.isValidAtPos(pos) ) {
                // If it is a function, do it recursively
                if( o instanceof JSFunction ) {
                    JSFunction f = (JSFunction)o;
                    for( int j=0; j<f.getObjectCount(); j++ ) {
                        JSObject o2 = f.getObject(j);
                        if( o2.isValidAtPos(pos) ) {
                            set.add(o2);
                        }
                    }
                }
                // Return the object itself, even if it is a function
                set.add(o);
            }
        }
        // Look into the imported librraies
        count = library.getImportCount();
        for( int i=0; i<count; i++ ) {
            JSImport imp = library.getImport(i);
            // PHIL: TODO
        }
    }
    
    public JSImport[] getAllImports(){
        if ( library == null )
            return new JSImport[0];
        JSImport[] imports = new JSImport[ library.getImportCount() ];
        for( int i=0; i<library.getImportCount(); i++ ) {
            imports[i] = library.getImport( i );
        }
        return imports;
    }

    public JSObject getObject( String name, int pos ) {
        if ( library == null )
            return null;
        int count = library.getObjectCount();
        for( int i=count-1; i>=0; i-- ) {
            JSObject o = library.getObject(i);
            if( o.isValidAtPos(pos) ) {
                // If it is a function, do it recursively
                if( o instanceof JSFunction ) {
                    JSFunction f = (JSFunction)o;
                    int fc = f.getObjectCount();
                    for( int j=fc-1; j>=0; j-- ) {
                        JSObject o2 = f.getObject(j);
                        if( o2.isValidAtPos(pos) && o2.getName().equals(name) ) {
                            return o2;
                        }
                    }
                }
                // Return the object itself, even if it is a function
                if( o.getName().equals(name) ) {
                    return o;
                }
            }
        }
        // Nothing matches...
        return null;
    }

    public static class MemberExpression {
        public String expr;
        public String memberStart;
        public boolean isNew;
        MemberExpression(String expr, String memberStart, boolean isNew) {
            this.expr = expr;
            this.memberStart = memberStart;
            this.isNew = isNew;
        }
    }
    public MemberExpression getMemberExpressionBeforeCursor(int pos, boolean parameter) {
        // Go up to the previous parenthesis
        if(parameter) {
            pos = (new MemberAnalyzer() {
                boolean acceptChar(char c) {
                    return true;
                }
            }).analyze(sourceCode,pos);
            if(pos>0 && sourceCode.charAt(pos-1)=='(' ) {
                pos--;
            }
        }
        
        // Get the member part
        int memberEnd = pos;
        while( pos>0 && isIdentifierPart(sourceCode.charAt(pos-1)) ) {
            pos--;
        }
        int memberStart = pos;

        // And get the expression
        int exprStart = pos;
        int exprEnd   = pos;
        if( pos>0 && sourceCode.charAt(pos-1)=='.' ) {
            pos -=1; exprEnd--;
            pos = (new MemberAnalyzer() {
                boolean acceptChar(char c) {
                    return c=='.' || isIdentifierPart(c);
                    //return c=='@' || c=='.' || (c>='a' && c<='z') || (c>='A' && c<='Z') || (c>='0' && c<='9');
                }
            }).analyze(sourceCode,pos);
            exprStart = pos;
        }

        boolean isNew = false;
        if(!parameter) {
            // Look if it is in the form new...
            if( pos>4 && isSpace(sourceCode.charAt(pos-1))
                      && sourceCode.charAt(pos-4)=='n'
                      && sourceCode.charAt(pos-3)=='e'
                      && sourceCode.charAt(pos-2)=='w' ) {
                if( pos==5 || !isIdentifierPart(sourceCode.charAt(pos-5)) ) {
                    isNew =true;
                }
            }
        }

        String expr = sourceCode.substring(exprStart,exprEnd);
        String start = memberStart<memberEnd ? sourceCode.substring(memberStart,memberEnd) : ""; //$NON-NLS-1$
        return new MemberExpression(expr,start,isNew);
    }
    private boolean isSpace(char c) {
        return c==' ' || c=='\t' || c=='\r' || c== '\n';
    }
    private boolean isIdentifierPart(char c) {
        return Character.isJavaIdentifierPart(c) || c=='@';
    }
    
    // Utility parser class
    private static abstract class MemberAnalyzer {
        MemberAnalyzer()  {
        }
        int analyze(String sourceCode, int pos) {
            int paren = 0;
            int bracket = 0;
            boolean squote = false;
            boolean dquote = false;
            for(;pos>=1;pos--) {
                char c = sourceCode.charAt(pos-1);
                if( c==')' ) {
                    if( !squote && !dquote ) {
                        paren++;
                    }
                } else if( c=='(' ) {
                    if( !squote && !dquote ) {
                        paren--;
                        if(paren<0) {
                            break;
                        }
                    }
                } else if( c==']' ) {
                    if( !squote && !dquote ) {
                        bracket++;
                    }
                } else if( c=='[' ) {
                    if( !squote && !dquote ) {
                        bracket--;
                        if(bracket<0) {
                            break;
                        }
                    }
                } else if( c=='\'' ) {
                    if( !dquote ) {
                        if( pos<=1 ) {
                            squote =!squote;
                        } else if( sourceCode.charAt(pos-2)!='\\' ) {
                            squote =!squote;
                        } else {
                            pos--;
                        }
                    }
                } else if( c=='\"' ) {
                    if( !squote ) {
                        if( pos<=1 ) {
                            dquote =!dquote;
                        } else if( sourceCode.charAt(pos-2)!='\\' ) {
                            dquote =!dquote;
                        } else {
                            pos--;
                        }
                    }
                } else {
                    if( !squote && !dquote ) {
                        if( paren>0 || bracket>0 ) {
                            // Accept everything
                        } else if( acceptChar(c) ) {
                        } else {
                            // End of statement
                            break;
                        }
                    }
                }
            }
            return pos;
        }
        abstract boolean acceptChar(char c);
    }

    public void dump() {
        library.dump();
    }


    // =======================================================================
    // EXPORTED OBJECTS
    // =======================================================================

    public interface VariableContainer {
        public JSVariable getVariable(String name);
    }
    
    public class JSLibrary implements VariableContainer {
        public int getImportCount() {
            return imports!=null ? imports.size() : 0;
        }
        public JSImport getImport(int i) {
            return (JSImport)imports.get(i);
        }
        public int getObjectCount() {
            return objects!=null ? objects.size() : 0;
        }
        public JSObject getObject(int i) {
            return (JSObject)objects.get(i);
        }
        public void dump() {
            TDiag.trace( "**** Library '{0}'", name ); //$NON-NLS-1$
            for( int i=0; i<getImportCount(); i++ ) {
                TDiag.trace( "import '{0}'", getImport(i).name ); //$NON-NLS-1$
            }
            for( int i=0; i<getObjectCount(); i++ ) {
                JSObject o = getObject(i);
                if( o instanceof JSVariable ) {
                    JSVariable v = (JSVariable)o;
                    TDiag.trace( "variable '{0}' [:{1}] ,{2}", v.name, v.type, startEnd(v) ); //$NON-NLS-1$
                } else if( o instanceof JSFunction ) {
                    JSFunction f = (JSFunction)o;
                    TDiag.trace( "function {0}:{1} ,{2}", f.name, f.type, startEnd(f) ); //$NON-NLS-1$
                    for( int j=0; j<f.getObjectCount(); j++ ) {
                        JSVariable v = (JSVariable)f.getObject(j);
                        TDiag.trace( "    variable '{0}' [:{1}] ,{2}", v.name, v.type, startEnd(v) ); //$NON-NLS-1$
                    }
                }
            }
        }
        // Internal use
        String                 name;
        ArrayList <JSImport>   imports;
        ArrayList <JSObject>   objects;
        JSLibrary( String name ) {
            this.name = name;
        }
        public JSVariable getVariable(String name) {
            if(objects!=null) {
                for( int i=0; i<objects.size(); i++ ) {
                    if( objects.get(i) instanceof JSVariable ) {
                        JSVariable v = (JSVariable)objects.get(i);
                        if(v.getName().equals(name)) {
                            return v;
                        }
                    }
                }
            }
            return null;
        }
        String startEnd(JSObject o) {
            FastStringBuffer b = new FastStringBuffer();
            b.append("start="); b.append(Integer.toString(o.start)); //$NON-NLS-1$
            if( o.end>0 ) {
                b.append("/end="); b.append(Integer.toString(o.end)); //$NON-NLS-1$
            }
            b.append( "  >" ); //$NON-NLS-1$
            b.append( toJavaString(sourceCode.substring(o.start,Math.min(o.start+30,sourceCode.length()-1)),false));
            return b.toString();
        }
        void addObject(JSObject object) {
            if( objects==null ) {
                objects = new ArrayList <JSObject> ();
            }
            objects.add(object);
        }
        void addImport(JSImport imp) {
            if( imports==null ) {
                imports = new ArrayList <JSImport> ();
            }
            imports.add(imp);
        }
    }
    public class JSImport {
        public String getName() {
            return name;
        }
        public FBSObject getGlobalObject() {
            try {
                return FBSGlobalObject.getLibraryGlobalObject(jsContext,name);
            } catch( Exception e ) {}
            return null;
        }
        // Internal use
        String    name;
        int       start;
        int       end;
        JSImport( String name ) {
            this.name = name;
        }
        
        public int getStart() {
            return start;
        }
        public int getEnd() {
            return end;
        }        
    }


    public class JSObject {
        public String getName() {
            return name;
        }
        public FBSType getType() {
            return type;
        }
        public int getStart() {
            return start;
        }
        public int getEnd() {
            return end;
        }
        public boolean isValidAtPos(int pos) {
            return pos>=start && (end<=0 || pos<=end);
        }
        // Internal use
        String    name;
        FBSType   type;
        int       start;
        int       end;
        JSObject( String name ) {
            this.name = name;
            this.type = FBSType.undefinedType;
        }
    }

    public class JSFunction extends JSObject implements Descriptor.IMethodParameters, VariableContainer {
        public int getObjectCount() {
            return (parameters!=null ? parameters.size() : 0) + (objects!=null ? objects.size() : 0);
        }
        public JSObject getObject(int i) {
            if(parameters!=null) {
                if(i<parameters.size()) {
                    return (JSObject)parameters.get(i);
                }
                i -= parameters.size();
            }
            return (JSObject)objects.get(i);
        }
        // Internal use
        ArrayList <JSVariable> parameters;
        ArrayList <JSObject>   objects;
        FBSType                retType;
        JSFunction( String name ) {
            super(name);
        }
        public int getParameterCount() {
            return parameters!=null ? parameters.size() : 0;
        }
        public FBSType getParameterType(int index) {
            return ((JSVariable)parameters.get(index)).getType();
        }
        public JSVariable getParameter(int index) {
            return (JSVariable)parameters.get(index);
        }

        public FBSType getReturnType() {
            return retType;
        }

        public JSVariable getVariable(String name) {
            if(objects!=null) {
                for( int i=0; i<objects.size(); i++ ) {
                    if( objects.get(i) instanceof JSVariable ) {
                        JSVariable v = (JSVariable)objects.get(i);
                        if(v.getName().equals(name)) {
                            return v;
                        }
                    }
                }
            }
            if(parameters!=null) {
                for( int i=0; i<parameters.size(); i++ ) {
                    JSVariable v = (JSVariable)parameters.get(i);
                    if(v.getName().equals(name)) {
                        return v;
                    }
                }
            }
            return library.getVariable(name);
        }
        
        void setScope(int start, int end) {
            this.start = start;
            this.end = end;
            for( int i=0; i<getObjectCount(); i++ ) {
                getObject(i).start = start;
                getObject(i).end = end;
            }
        }
        void addParameter(JSVariable v) {
            if( parameters==null ) {
                parameters = new ArrayList <JSVariable> ();
            }
            parameters.add(v);
        }
        void addOject(JSVariable v) {
            if( objects==null ) {
                objects = new ArrayList <JSObject> ();
            }
            objects.add(v);
        }
        // We assume that a function is accessible from everywhere
        public boolean isValidAtPos(int pos) {
            return true;
        }
    }

    public class JSVariable extends JSObject {
        // Internal use
        JSVariable( String name) {
            super(name);
        }
        
    }

    public class JSDynamicVariable extends JSVariable {
    	int declStart;
        int exprStart;
        int exprEnd;
        // Internal use
        JSDynamicVariable( String name) {
            super(name);
        }
        public String getExpression() {
            if(exprStart<exprEnd) {
                String expr = sourceCode.substring(exprStart,exprEnd);
                return expr;
            }
            return null;
        }
    }


    // ========================================================================================================
    // JAVASCRIPT PARSER
    // ========================================================================================================

    private class TJavascriptParser extends TJavascriptLex {
        void parse(JSLibrary library) {
            setString(sourceCode);
            nextToken();

            // Get all the imports
            parseImports(library);

            // Get all the objects
            while(true) {
                // We just take care of:
                //   1. global variables (starting with var)
                //   2. global functions (starting with function)
                switch(getToken()) {
                    case TJavascriptLex.TK_EOF: {
                        return;
                    }
                    case TJavascriptLex.TK_IDENT: {
                        parseGlobalVariable(library,false);
                    }
                    break;
                    case TJavascriptLex.TK_VAR: {
                        parseGlobalVariable(library,true);
                    }
                    break;
                    case TJavascriptLex.TK_FUNCTION: {
                        parseGlobalFunction(library);
                    }
                    break;
                    default: {
                        nextToken();
                    }
                }
            }
        }

        private void parseImports(JSLibrary library) {
            while( true ) {
                if( getToken()!=TJavascriptLex.TK_IMPORT ) {
                    break;
                }
                nextToken(); // skip 'import'

                int begin = getTokenBegin();
                int end = getTokenEnd();
                String name = parseComposedIdentifier(false);
                if( name!=null ) {
                    if(getToken()!=';') {
                        // Return on error....
                        return;
                    }
                    while(getToken()==';') { // skip all ';' (many doubled or more...)
                        nextToken();
                    }
                    JSImport imp = new JSImport(name);
                    imp.start = begin;
                    imp.end = end;
                    library.addImport(imp);
                }
            }
        }


        private void parseGlobalVariable(JSLibrary library, boolean var) {
        	int declStart = getCurrentPosition();
            // Form:
            //    var name[:type]
            JSVariable v = parseVariableDecl(library,var);
            if( v!=null ) {
                library.addObject(v);
            }
            int start = getCurrentPosition(); int end=start;
            try {
                while(true) {
                    switch(getToken()) {
                        case TJavascriptLex.TK_EOF: {
                            return;
                        }
                        case ';': {
                            nextToken();
                            if(v!=null) {
                            	// start is the scope for that variable (when it starts to be valid)
                                v.start = getCurrentPosition();
                            }
                            return;
                        }
                    }
                    end = getCurrentPosition();
                    nextToken();
                }
            } finally {
                if( v instanceof JSDynamicVariable ) {
                    JSDynamicVariable jv = (JSDynamicVariable)v;
                    jv.declStart = declStart;
                    jv.exprStart = start;
                    jv.exprEnd = end;
                }
            }
        }


        private void parseLocalVariable(JSFunction function, boolean var) {
        	int declStart = getCurrentPosition();
            // Form:
            //    var name[:type]
            JSVariable v = parseVariableDecl(function,var);
            if( v!=null ) {
                function.addOject(v);
            }
            int start = getCurrentPosition(); int end=start;
            try {
                while(true) {
                    switch(getToken()) {
                        case TJavascriptLex.TK_EOF: {
                            return;
                        }
                        case ';': {
                            nextToken();
                            if(v!=null) {
                            	// start is the scope for that variable (when it starts to be valid)
                                v.start = getCurrentPosition();
                            }
                            return;
                        }
                        case '}': {
                            if(v!=null) {
                            	// start is the scope for that variable (when it starts to be valid)
                                v.start = getCurrentPosition();
                            }
                            return;
                        }
                    }
                    nextToken();
                }
            } finally {
                if( v instanceof JSDynamicVariable ) {
                    JSDynamicVariable jv = (JSDynamicVariable)v;
                    jv.declStart = declStart;
                    jv.exprStart = start;
                    jv.exprEnd = end;
                }
            }
        }

        private JSVariable parseVariableDecl(VariableContainer container, boolean var) {
            // Form:
            //    name[:type]
            if(var) {
                nextToken();
            }
            if( getToken()==TJavascriptLex.TK_IDENT ) {
                String name=parseIdentifier();
                if( name!=null ) {
                    if( var || getToken()==':') {   //DTAIEB: add || getToken()==':', because we need to account parameter declaration in functions
                        if(getToken()==':' ) {
                            JSVariable v = new JSVariable(name);
                            // Typed variable
                            nextToken();
                            if( getToken()==TJavascriptLex.TK_IDENT ) {
                                String type=parseComposedIdentifier(true);
                                if( type!=null ) {
                                    v.type = FBSType.getType(jsContext,type);
                                    return v;
                                }
                            }
                        } else {
                            // Check if we have an equal operator to guess the sign
                            // Non typed variable
                            JSDynamicVariable v = new JSDynamicVariable(name);
                            return v;
                        }
                    } else {
                        if(container!=null && getToken()=='=') {
                            // Check if we are accessing an untyped existing variable
                            JSVariable v = container.getVariable(name);
                            if(v!=null && !v.getType().isUndefined()) {
                                return null;
                            }
                            v = new JSDynamicVariable(name);
                            return v;
                        }
                    }
                }
            }
            return null;
        }

        private void parseGlobalFunction(JSLibrary library) {
            // Form:
            //    function name( [param [:type]* ) [:type]
            nextToken(); // skip function
            if( getToken()==TJavascriptLex.TK_IDENT ) {
                String name=parseIdentifier();
                if( name!=null ) {
                    final JSFunction function = new JSFunction(name);
                    if( getToken()=='(' ) {
                        nextToken();
                        parseParameters(function);
                        if( getToken()==')' ) {
                            nextToken();
                            if( getToken()==':' ) {
                                nextToken();
                                function.retType = FBSType.getType(jsContext,parseComposedIdentifier(true));
                            } else {
                                function.retType = FBSType.invalidType;
                            }
                            FBSType type = new FBSType.JSScriptFunction(function);
                            function.type = type;
                            int fctStart = getCurrentPosition();
                            if( getToken()=='{' ) {
                                nextToken();
                                library.addObject(function);
                                parseFunctionBody(function);
                                function.setScope(fctStart,getCurrentPosition());
                            }
                        }
                    }
                }
            }
        }

        private void parseFunctionBody(JSFunction function) {
            int blockLevel = 0;
            while(true) {
                switch( getToken() ) {
                    case TJavascriptLex.TK_EOF: {
                        return;
                    }
                    case TJavascriptLex.TK_IDENT: {
                        parseLocalVariable(function,false);
                    } break;
                    case TJavascriptLex.TK_VAR: {
                        parseLocalVariable(function,true);
                    } break;
                    case '{': {
                        blockLevel++;
                    } break;
                    case '}': {
                        if( blockLevel==0 ) {
                            return;
                        }
                        blockLevel--;
                    } break;
                }
                nextToken();
            }
        }

        private void parseParameters(JSFunction function) {
            while(true) {
                switch(getToken()) {
                    case TJavascriptLex.TK_EOF: {
                        return;
                    }
                    case ')': {
                        return;
                    }
                    case TJavascriptLex.TK_IDENT: {
                        JSVariable v = parseVariableDecl(null, false);
                        if( v!=null ) {
                            function.addParameter(v);
                        }
                        break;
                    }                    
                    default:
                        return;
                }
            }
        }

        private String parseIdentifier() {
            String s = getTokenText();
            nextToken();
            return s;
        }

        private String parseComposedIdentifier(boolean var) {
            int begin = getTokenBegin();
            int end = endOfComposedIdentifier(var);
            if( end>0 ) {
                return getText(begin, end).trim();
            }
            return null;
        }

        private int endOfComposedIdentifier(boolean var) {
            if( getToken()==TJavascriptLex.TK_IDENT ) {
                while( true ) {
                    nextToken();
                    if( var && getToken()=='[' ) {
                        nextToken();
                        if(getToken()!=']') {
                            return 0;
                        }
                        continue;
                    }
                    
                    if (getToken() == ';') {
                        return getTokenEnd();
                    }
                    
                    if( getToken()!='.' ) {
                        int end = getTokenBegin();
                        return end;
                    }
                    nextToken();

                    if( getToken()!=TJavascriptLex.TK_IDENT ) {
                        return 0;
                    }
                }
            }
            return 0;
        }
    }


    // ========================================================================================================
    // LEXICAL ANALYZER
    // ========================================================================================================

    private class TJavascriptLex extends StringParser {

        private static final int  TK_EOF           = 256;
        private static final int  TK_EOL           = 257;
        private static final int  TK_UNKNOWN       = 258;
        private static final int  TK_FUNCTION      = 259;
        private static final int  TK_IMPORT        = 260;
        private static final int  TK_VAR           = 261;

        private static final int  TK_NUMBER        = 262;
        private static final int  TK_STRING        = 263;
        private static final int  TK_IDENT         = 264;
        private static final int  TK_BLANKS        = 265;
        private static final int  TK_COMMENT       = 266;


        public TJavascriptLex() {
        }

        public int getToken() {
            return token;
        }

        public String getTokenText() {
            return getText(getTokenBegin(),getTokenEnd());
        }

        public String getText(int begin ,int end) {
            return getCharProvider().getString(begin,end);
        }

        public int getTokenAddr() {
            return tokenAddr;
        }

        public int getTokenBegin() {
            return tokenBegin;
        }

        public int getTokenEnd() {
            return tokenEnd;
        }

        public int nextToken() {
            token = doNextToken();
            tokenEnd = getCurrentPosition();
            //TDiag.trace( "Token = {0} ('{1}')", getTokenAsString(), TString.toJavaString(getTokenText(),false) );
            return token;
        }

        protected int doNextToken() {
            // Eat the leading blanks
            tokenAddr = getCurrentPosition();
            if( eatBlanks() ) {
                // End of Statement here...
                return ';';
            }

            // And parse the next token
            tokenBegin = getCurrentPosition();
            switch( getChar() ) {
                case -1: {
                    return TK_EOF;
                }
                case 'f': {
                    if( matchKeyWord("function") ) { //$NON-NLS-1$
                        return TK_FUNCTION;
                    }
                } break;
                case 'i': {
                    if( matchKeyWord("import") ) { //$NON-NLS-1$
                        return TK_IMPORT;
                    }
                } break;
                case 'v': {
                    if( matchKeyWord("var") ) { //$NON-NLS-1$
                        return TK_VAR;
                    }
                } break;
                case '}': {
                    skip(); nextStatement();
                    return '}';
                }
                case ';': {
                    skip(); nextStatement();
                    return ';';
                }
                case '\'': {
                    skip();
                    while(!isEOF()) {
                        switch(getChar()) {
                            case '\'':  skip(); return TK_STRING;
                            case '\\':  skip();
                        }
                        skip();
                    }
                    return TK_UNKNOWN;
                }
                case '\"': {
                    skip();
                    while(!isEOF()) {
                        switch(getChar()) {
                            case '\"':  skip(); return TK_STRING;
                            case '\\':  skip();
                        }
                        skip();
                    }
                    return TK_UNKNOWN;
                }
                case '(':
                case ')':
                case '{':
                case '[':
                case ']':
                case ',':
                case '+':
                case '-':
                case '*':
                case '/':
                case '=':
                case '<':
                case '>':
                case '.':
                case ':': {
                    return nextChar();
                }
            }

            // Check for a valid java identifier
            if( Character.isJavaIdentifierStart((char)getChar()) ) {
                skip();
                while(true) {
                    if( !Character.isJavaIdentifierPart((char)getChar()) ) {
                        return TK_IDENT;
                    }
                    skip();
                }
            }

            // Error on the token
            skip();
            return TK_UNKNOWN;
        }

        protected void nextStatement() {
            while(true) {
                switch( getChar() ) {
                    case '\t':
                    case ' ': {
                        skip();
                    } break;
                    case '\n': {
                        skip();
                    } return;
                    default: {
                        return;
                    }
                }
            }
        }

        protected boolean eatBlanks() {
            boolean endOfStatement = false;
            while(true) {
                switch( getChar() ) {
                    case '\n':
                    case '\r': {
                        endOfStatement = !isOperator(token);
                        skip();
                    } break;
                    case '\t':
                    case ' ': {
                        skip();
                    } break;
                    case '/': {
                        if( match("//") ) { //$NON-NLS-1$
                            skipUpto( "\n" ); //$NON-NLS-1$
                            if( !isEOF() ) {
                                skip();
                            }
                            endOfStatement = true;
                            break;
                        }
                        if( match("/*") ) { //$NON-NLS-1$
                            skipUpto( "*/" ); //$NON-NLS-1$
                            if( !isEOF() ) {
                                skip(2);
                            }
                            break;
                        }
                    }
                    default: {
                        return endOfStatement;
                    }
                }
            }
        }
        
        protected boolean isOperator(int tk) {
            switch(tk) {
                case '+':
                case '-':
                case '*':
                case '/':
                case '=':
                case '<':
                case '>':
                    return true;
            }
            return false;           
        }

        /*
         *
         */
        private int token;
        private int tokenAddr;
        private int tokenBegin;
        private int tokenEnd;
    }


/*
    public static void main(String[] args) {
        try {
            com.ibm.workplace.designer.FlowBuilder.initFromApplication(com.ibm.workplace.designer.util.TSystem.getInstallDirectory(), "test js parser");
//            JavaScriptSourceInfo si=parseFile("c:\\javascript1.jss");
//            for(int i=0; i<si.sourceCode.length()-1; i++) {
//                printExprBeforeCursor(si, i);
//            }
            printExp( "doc.getDatabase()" );
            printExp( "doc.getDatabase().openView(\"db\")" );
            //printExp( "doc.getDatabase(\"db\").getView('v')" );
        } catch( Exception e ) {
            com.ibm.workplace.designer.util.TDiag.exception(e);
        }
    }
    private static void printExp( String expr ) {
        try {
            // Use the true javascript compiler and get the result
            JSExpression jsExpr = JSExpression.createExpression(expr);
            TDiag.trace("==========================================" );
            TDiag.trace("{0}", expr);
            jsExpr.getMainNode().dump(null,new SimpleCallback());
            FBSType t = jsExpr.getResultType(new SimpleCallback());
            TDiag.trace( "==>Resulting type={0}", t );
        } catch( Exception e ) {
            com.ibm.workplace.designer.util.TDiag.exception(e);
        }
    }
    
    private static class SimpleCallback implements FBSType.ISymbolCallback {
        SimpleCallback() {
        }
        public FBSType getSymbolType( String name ) {
            if( name.equals("doc") ) {
                return FBSType.getType(com.ibm.workplace.designer.docdb.TDBDocument.class);
            }
            return FBSType.undefinedType;
        }
        public Descriptor.Member[] getAllSymbols() {
            return null;
//          return new Descriptor.Member[] {
//                  new Descriptor.Field("doc",FBSType.getType(com.ibm.workplace.designer.docdb.TDBDocument.class)),
//          };
        }
    }

    private static JavaScriptSourceInfo parseFile( String file ) {
        try {
            TStringBuffer b = new TStringBuffer();
            java.io.FileReader fr=new java.io.FileReader(file);
            try {
                b.append(fr);
                JavaScriptSourceInfo si = new JavaScriptSourceInfo();
                si.parse("test: "+file,b.toString()); // $NON-NLS-1$
                si.dump();
                return si;
            } finally {
                fr.close();
            }
        } catch( Exception e ) {
            com.ibm.workplace.designer.util.TDiag.exception(e);
        }
        return null;
    }
    private static void printExprBeforeCursor( JavaScriptSourceInfo si, int pos ) {
        MemberExpression expr = si.getMemberExpressionBeforeCursor(pos,false);
        if( expr!=null ) {
            try {
                // Use the true javascript compiler and get the result
                JSExpression jsExpr = JSExpression.createExpression(expr.expr);
                TDiag.trace("==========================================" );
                TDiag.trace(
                    "[{0}] = '{1}' ({2})", 
                    TString.toString(pos), 
                    expr!=null?expr.expr:"<null>",  // $NON-NLS-1$
                    TString.toJavaString(si.sourceCode.substring(pos), false)
                );
                jsExpr.getMainNode().dump();
                FBSType t = jsExpr.getResultType(new SymbolCallback(si,pos));
                TDiag.trace( "==>Resulting type={0}", t ); // $NON-NLS-1$
            } catch( Exception e ) {
                com.ibm.workplace.designer.util.TDiag.exception(e);
            }
        }
    }
    private static class SymbolCallback implements FBSType.ISymbolCallback {
        JavaScriptSourceInfo si;
        int pos;
        SymbolCallback( JavaScriptSourceInfo si, int pos ) {
            this.si = si;
            this.pos = pos;
        }
        public FBSType getSymbolType( String name ) {
            JSObject o = si.getObject(name,pos);
            if( o!=null ) {
                return o.getType();
            }
            return FBSType.undefinedType;
        }
        public Descriptor.Member[] getAllSymbols() {
            return null;
            //return si.getAllObjects(pos);
        }
    }
*/    
    public JSLibrary getLibrary() {
        return library;
    }
    
    
    public static String toJavaString(String s, boolean addQuotes) {
        FastStringBuffer b = new FastStringBuffer();
        b.appendJavaString(s,addQuotes);
        return b.toString();
    }
}
