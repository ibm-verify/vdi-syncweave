/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import com.ibm.jscript.JSContext;

/**
 * Java wrapper factory.
 */
public interface IWrapperFactory {

    public GeneratedWrapperObject.MethodMap getMethodMap(JSContext jsContext);
	public GeneratedWrapperObject wrap(JSContext jsContext, Object o);
}
