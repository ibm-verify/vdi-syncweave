/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.commons.util.FastStringBuffer;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.lib.AbstractArrayWrapper;
import com.ibm.jscript.std.ErrorObject;
import com.ibm.jscript.std.FunctionObject;
import com.ibm.jscript.std.StringObject;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSReference;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.FBSValueVector;
import com.ibm.jscript.types.GeneratedWrapperObject;
import com.ibm.jscript.types.InterfacesWrapperObject;
import com.ibm.jscript.types.JavaAccessObject;

public class ASTCall extends ASTNode{

    private ASTNode leftNode;
    private ASTArgumentList arguments;

    public ASTCall(ASTNode leftNode, ASTArgumentList arguments) {
        this.leftNode = assignParent(leftNode);
        assignParent(arguments);
        this.arguments = arguments;
    }

    public String getTraceString(){
        return leftNode.getTraceString()+"()"; //$NON-NLS-1$
    }

    public ASTNode getLeftNode() {
        return leftNode;
    }

    public ASTArgumentList getASTArgumentList() {
        return arguments;
    }

    public int getSlotCount(){
        return arguments==null ? 1 : 2;
    }

    public ASTNode readSlotAt(int index){
        switch(index){
            case 0:  return leftNode;
            case 1:  return arguments;
        }
        return null;
    }

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        FBSType t=leftNode.getResultType(jsContext,symbolCallback);
        if( t.isUndefined() || t.isInvalid() ) {
            return t;
        }
        if( arguments!=null ) {
            FBSType[] args=new FBSType[arguments.getSlotCount()];
            for(int i=0; i<args.length; i++) {
                args[i]=getASTArgumentList().readSlotAt(i).getResultType(jsContext,symbolCallback);
            }
            return t.getCall(jsContext,args);
        }
        return t.getCall(jsContext,new FBSType[0]);
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            // Construct the object instance
            if(!leftNode.interpret(this,context,result)) {
            	return false;
            }
            FBSValue exprValue= result.getFBSValue();
            FBSObject o = exprValue.asObject();
            if (o==null || !o.supportCall()){
                if (result.isReference()) {
                    FBSReference r=(FBSReference)result.getReference();
                    String member=r.getPropertyName();

                    // Construct the arguments for debug purpose only
                    FBSValueVector args=null;
                    if (arguments!=null && arguments.getSlotCount()>0){
                    	args=arguments.interpretArguments(this,context,result);
                    	if(args==null) { // Signal is returned
                    		return false;
                    	}
                    }else{
                        args=FBSValueVector.emptyVector; // to avoid sending null object to the function call
                    }

                    FBSObject base = r.getBase();
                    if( base.isString() && member.equals("length")) { //$NON-NLS-1$
                        if( base instanceof StringObject ) { 
                            if( context.getJSContext().hasStringLengthAsMethod() ) {
                                result.setNormal(exprValue);
                                return true;
                            }
                        } else if( base instanceof JavaAccessObject ) {
                            result.setNormal(exprValue);
                            return true;
                        }
                    }
                    
                    // If we have an error here, this is because the symbol is not known and
                    // a java package object has been created.
                    // So we report a more comprehensive error here.
                    if( base.isJavaPackage() ) {
                        if( leftNode instanceof ASTMember ) {
                            ASTMember m=(ASTMember)leftNode;
                            throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),
                                "Error calling method '{0}': '{1}' is not a valid object", //$NLS-ASTCall.ASTCall.NotAValidObject.Exception-1$
                                getMethodSignature(member,args), m.getLeftNode().getTraceString()));
                        }
                        throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),
                            "Error calling method '{0}': '{1}' is not a valid object", //$NLS-ASTCall.ASTCall.NotAValidObject.Exception-1$
                            getMethodSignature(member,args), leftNode.getTraceString()));
                    }
                    
                    String type=base.getTypeAsString();
                    if(base instanceof JavaAccessObject) {
                    	Class<?> jc = ((JavaAccessObject)base).getJavaClass();
                        type += " [Dynamic Java Wrapper, "+jc.getName()+"]"; // $NON-NLS-1$
                    } else if(base instanceof AbstractArrayWrapper) {
                    	String ac = ((AbstractArrayWrapper)base).getTypeAsString();
                        type += " [Java Array, "+ac+"]"; // $NON-NLS-1$
                    } else if(base instanceof InterfacesWrapperObject) {
                    	String dbg = ((InterfacesWrapperObject)base).getDebugString();
                        type += " [Static Java Interface Wrapper, "+dbg+"]"; // $NON-NLS-1$
                    } else if(base instanceof GeneratedWrapperObject) {
                    	String dbg = ((GeneratedWrapperObject)base).getDebugString();
                        type += " [Static Java Wrapper, "+dbg+"]"; // $NON-NLS-1$
                    } else if(base instanceof FBSObject) {
                        type += " [JavaScript Object]"; // $NON-NLS-1$
                    } else  {
                        type += " [:" + base.getClass().getName() + "]"; // $NON-NLS-1$
                    }
                    
                    throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),
                            "Error calling method '{0}' on an object of type '{1}'", //$NLS-ASTCall.ASTCall.MethodCall.Exception-1$
                            getMethodSignature(member,args), type));
                }
                throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),
                            "Cannot call object '{0}'", //$NLS-ASTCall.ASTCall.CannotCallObj.Exception-1$
                            leftNode.getTraceString()));
            }

            FBSObject object;
            if (result.isReference()) {
                object=result.getReference().getBase();
                if (object instanceof FunctionObject.FBSActivationObject){
                    object=null;
                }
            }else{
                object=null;
            }

            if(!o.call(context,this,arguments,object,result)) {
            	return false;
            }
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }
    private String getMethodSignature(String functionName, FBSValueVector args) {
        FastStringBuffer b = new FastStringBuffer();
        b.append( functionName );
        b.append( "(" ); //$NON-NLS-1$
        if( args!=null ) {
            for( int i=0; i<args.size(); i++ ) {
                if(i>0) {
                    b.append( ", " ); //$NON-NLS-1$
                }
                if( args.get(i)!=null ) {
                    b.append(args.get(i).getTypeAsString());
                } else {
                    b.append( "<null>" ); //$NON-NLS-1$
                }
            }
        }
        b.append( ")" ); //$NON-NLS-1$
        return b.toString();
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitCall(this, param);
    }
}