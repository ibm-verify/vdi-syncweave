/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import com.ibm.jscript.InterpretException;

public class FBSReferenceByIndex extends FBSReference {

    private int propertyIndex;

    public FBSReferenceByIndex(FBSObject base, int propertyIndex) {
    	super(base);
        this.propertyIndex=propertyIndex;
    }
    
    public String getPropertyName() {
    	return FBSNumber.toString(propertyIndex);
    }

    public int getPropertyIndex(){
        return propertyIndex;
    }

    public FBSValue getValue() throws InterpretException{
        return base.get(propertyIndex);   // access via property index, usually for arrays
    }

    public void putValue(FBSValue value) throws InterpretException{
        base.put(propertyIndex,value);  // access via property index
    }
}
