/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSValue;

public class ASTThrow extends ASTNode{
    ASTNode exprNode;
    public ASTThrow() {
    }

    public void add(ASTNode node){
        exprNode=assignParent(node);
    }

    public int getSlotCount(){
        return 1;
    }

    public ASTNode readSlotAt(int index){
        return exprNode;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            if (exprNode!=null){
                if(!exprNode.interpret(this,context,result)) {
                	return false;
                }
            }
            FBSValue v=result.getFBSValue();
            if(v.isJavaObject()) {
            	Object o = v.toJavaObject();
            	if(o instanceof Exception) {
                    throw new InterpretException((Exception)o);
            	}
            }
            throw new InterpretException(null,v);
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitThrow(this, param);
    }
}
