/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import java.util.Iterator;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.engine.IExecutionContext;

public class JavaPackageObject extends FBSObject{

    public static final String PACKAGES = "Packages"; // $NON-NLS-1$
    public static final String PACKAGES_START = "Packages."; // $NON-NLS-1$

    private boolean prefixed;
    private String packageName;

    private JavaPackageObject(JSContext jsContext, String pckgName, boolean prefixed) {
        super(jsContext);
        this.packageName = pckgName;
        this.prefixed = prefixed;
    }

    private JavaPackageObject(JSContext jsContext) {
        super(jsContext);
    }
    
    public boolean isJavaPackage() {
        return true;
    }
    
    public String getPackageName() {
        return packageName;
    }

    public FBSType getFBSType(JSContext context) {
        return FBSType.getJavaPackage(getTypeAsString());
    }

    public String getTypeAsString(){
        return packageName;
    }

    public boolean hasProperty(String name){
        return true;
    }

    public boolean isJavaNative(){
       return true;
    }

    public boolean booleanValue() {
        return false;
    }

    public FBSValue get(int index){
        return FBSUndefined.undefinedValue;
    }

    public FBSValue get(String name){
        String className;
        if (StringUtil.isEmpty(packageName)){
            className = name;
        } else {
            className = packageName + "." + name;
        }

        // Try to load it as a class here
        try {
            Class<?> c = getJSContext().loadClass(className);
            if(c!=null) {
                return new JavaAccessObject(getJSContext(),c,null);
            }
        } catch(Exception e) {
        }

        // OK, assume it is a package again...
        return new JavaPackageObject(getJSContext(),className,prefixed);
    }

    public FBSReference getPropertyReference(String name) {
    	// If it is an existing class, then return it as a resolved ref
        String className;
        if (StringUtil.isEmpty(packageName)){
            className = name;
        } else {
            className = packageName + "." + name;
        }
        try {
            Class<?> c = getJSContext().loadClass(className);
            if(c!=null) {
                return new FBSReferenceByName.ResolvedReference(this,name,new JavaAccessObject(getJSContext(),c,null));
            }
        } catch(Exception e) {
        }
    	
        // If the package was prefixed by Packages. then it is a real package
        if(prefixed) {
            return new FBSReferenceByName(this,name);
        }
        // Else, it was just a guess so we should fail if getFBSValue() is called
        return new FBSReferenceByName.JavaPackageVariable(this,name);
    }

    public static JavaPackageObject getPackage(JSContext jsContext, String name, boolean b){
        return new JavaPackageObject(jsContext,name,b);
    }

    public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
        throw new InterpretException(null,"Cannot instantiate object of JavaPackageObject"); // $NLS-JavaPackageObject.cannotinstantiateobjectofJavaPack-1$
    }

    public boolean supportConstruct(){
        return false;
    }

    public boolean hasInstance(FBSValue v){
        return false;
    }

    public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this)throws InterpretException{
        throw new InterpretException(null,"Cannot call object of JavaPackageObject"); // $NLS-JavaPackageObject.cannotcallobjectofJavaPackageObje-1$
    }

    public boolean supportCall(){
        return false;
    }

    public boolean createProperty(String name , int attribute, FBSValue value ){
        return false;
    }

    public void put(int index , FBSValue value) throws InterpretException {
        throw new InterpretException(null,
              "Error setting value: '{0}' is not a valid object",packageName); // $NLS-JavaPackageObject.Errorsettingvalue0isnotavalidobje-1$
    }

    public void put(String name , FBSValue value) throws InterpretException {
        throw new InterpretException(null,
              "Error setting value: '{0}' is not a valid object",packageName); // $NLS-JavaPackageObject.Errorsettingvalue0isnotavalidobje.1-1$
    }

    public boolean canPut(String name){
        return false;
    }

    public boolean delete(String name){
        return false;
    }

    public Iterator getPropertyKeys() {
        return null;
    }

    public Object toJavaObject(Class c) throws InterpretException{
        if (c==null || c==JavaPackageObject.class){
            return this;
        }
        throw new InterpretException(null,"Cannot convert JavaPackageObject to {0}",c.getName()); // $NLS-JavaPackageObject.CannotconvertJavaPackageObjectto0-1$
    }
}