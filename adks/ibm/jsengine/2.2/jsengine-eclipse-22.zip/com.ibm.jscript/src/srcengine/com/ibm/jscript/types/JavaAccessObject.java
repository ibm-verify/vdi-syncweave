/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import java.beans.BeanInfo;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.ibm.commons.util.FastStringBuffer;
import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.IValue;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.std.ArrayObject;
import com.ibm.jscript.std.ArrayPrototype;
import com.ibm.jscript.std.BooleanPrototype;
import com.ibm.jscript.std.DateObject;
import com.ibm.jscript.std.DatePrototype;
import com.ibm.jscript.std.NumberPrototype;
import com.ibm.jscript.std.StringPrototype;

/**
 * Java objects can hold dynamically created properties.
 */
public class JavaAccessObject extends JavaWrapperObject {

    private static final boolean INVOKE_BUG = true;

    private Class<?> clazz;
    private Object instance;
    private MethodCache methodCache;

    public JavaAccessObject(JSContext jsContext, Class<?> clazz,Object object) {
        super(jsContext);
        this.clazz=clazz;
        this.instance=object;
        if(!jsContext.hasJavaBridge()) {
            throw new SecurityException(errBridge());
        }
    }
    public JavaAccessObject(JSContext jsContext, String className) throws ClassNotFoundException {
        super(jsContext);
        this.clazz=jsContext.loadClass(className);
        if(!jsContext.hasJavaBridge()) {
            throw new SecurityException(errBridge());
        }
    }
    public JavaAccessObject(JSContext jsContext, Class<?> clazz) {
        super(jsContext);
        this.clazz=clazz;
        if(!jsContext.hasJavaBridge()) {
            throw new SecurityException(errBridge());
        }
    }
    private String errBridge() {
        return "Java bridge is not allowed"; // $NLS-JavaAccessObject.Javabridgeisnotallowed-1$
    }

    public FBSType getFBSType(JSContext context) {
        return FBSType.getType(getJSContext(),clazz.getName());
    }

    public Object getJavaObject() {
        if(instance!=null) {
            return instance;
        }
        return clazz;
    }

    public Class getJavaClass() {
        return clazz;
    }

    public String getTypeAsString() {
        return clazz.getName();
    }

    public void setJavaObject(Object object) {
        this.instance = object;
    }

    public String getClassName(){
        return clazz.getName();
    }
    
    public int getType() {
        if(instance!=null) {
            if(instance instanceof Number) {
                return NUMBER_TYPE;
            }
            if(instance instanceof Boolean) {
                return BOOLEAN_TYPE;
            }
            if(instance instanceof String) {
                return STRING_TYPE;
            }
        }
        return OBJECT_TYPE;
    }

    @Override
    public boolean isNumber() {
        return instance instanceof Number;
    }

    @Override
    public boolean isBoolean() {
        return instance instanceof Boolean;
    }

    @Override
    public boolean isString() {
        return instance instanceof String;
    }

    @Override
    public boolean isDate() {
        return instance instanceof java.util.Date;
    }

    @Override
    public double numberValue(){
        if (instance!=null){
            if(instance instanceof Number) {
                return ((Number)instance).doubleValue();
            }
            if(instance instanceof Boolean) {
                return FBSBoolean.numberValue(((Boolean)instance).booleanValue());
            }
            if(instance instanceof String) {
                return FBSString.numberValue((String)instance);
            }
        }
        return 0;
    }
    @Override
    public FBSNumber toFBSNumber() {
        return FBSNumber.get(numberValue());
    }

    @Override
    public boolean booleanValue(){
        if (instance!=null) {
            if(instance instanceof Boolean) {
                return ((Boolean)instance).booleanValue();
            }
            if(instance instanceof String) {
                return FBSString.booleanValue((String)instance);
            }
            if(instance instanceof Number) {
                double d = ((Number)instance).doubleValue();
                return (Double.isNaN(d)||d==0)?false:true;
            }
        }
        return true;
    }
    @Override
    public FBSBoolean toFBSBoolean() {
        return FBSBoolean.get(booleanValue());
    }

    @Override
    public String stringValue(){
        if (instance!=null){
            if(instance instanceof String) {
                return (String)instance;
            }
            if(instance instanceof Boolean) {
                return FBSBoolean.stringValue(((Boolean)instance).booleanValue());
            }
            if(instance instanceof Number) {
                return FBSNumber.stringValue(((Number)instance).doubleValue());
            }
            return instance.toString();
        }
        return "null"; //$NON-NLS-1$
    }
    @Override
    public FBSString toFBSString() throws InterpretException {
        return FBSString.get(stringValue());
    }

    @Override
    public java.util.Date dateValue() {
        if (instance!=null) {
            if(instance instanceof java.util.Date) {
                return (java.util.Date)instance;
            }
        }
        return null;
    }

    public boolean supportConstruct(){
        return true;
    }

    public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
        JSContext jsContext = getJSContext();
        
        // Rhino allows such things:
        //    new java.lang.Long.valueOf('F', 16)  
        if (methodCache!=null) {
            if(jsContext.hasRhinoExtensions()) { 
                // In this case, just delegate to a function call
                FBSValue v = call(context,args,null);
                return v.toFBSObject(jsContext);
            }
            throw new InterpretException(null,"Cannot use function call as constructor"); // $NLS-JavaAccessObject.Cannotuseafunctioncallasaconstruc-1$
        }

        // Support class wrappers
        Class<?> cc = clazz;
        if( clazz==Class.class ) {
            cc = (Class<?>)instance;
        }

        // Find the best constructor using 2 passes
        ConstructorCache cache = getClassInfoCache(jsContext,cc).getConstructors(jsContext);
        ConstructorCache m = (ConstructorCache)findCallable(args,cache,true);
        if(m==null && jsContext.autoConvertJavaArgsToString() ) {
            m = (ConstructorCache)findCallable(args,cache,false);
        }
        
        if(m!=null) {
            // Compute the parameters
            Object[] callParams = null;
            if(args.size()>0) {
                Class<?>[] argClasses=m.argClasses;
                callParams = new Object[args.size()];
                for( int i=0; i<args.size(); i++ ) {
                    callParams[i]=args.get(i).toJavaObject(argClasses[i]);
                }
            }

            // Create the java object
            Object result;
            try {
                result=m.constructor.newInstance(callParams);
            } catch( Exception e ) {
                throw new InterpretException(e,StringUtil.format("Error while calling java constructor '{0}' ({1}).",getMethodSignature(cc.getName(),args),e.getClass().getName())); //$NLS-JavaAccessObject.JavaFactory.CtorCall.Exception-1$
            }

            // When creating a new Object using this specific syntax, we ensure that no
            // conversion is done. This allows the call of overloaded methods
            return FBSUtility.wrapAsObject(jsContext,result);
        }
        throw new InterpretException(null,"Cannot find java public constructor '{0}'",getMethodSignature(cc.getName(),args)); //$NLS-JavaAccessObject.JavaFactory.CtorNotFound.Exception-1$
    }

    public FBSValue call(IExecutionContext context, FBSValueVector args,FBSObject _this)throws InterpretException{
        JSContext jsContext = getJSContext();
        
        // This may happen when a constructor is called as a function
        if (methodCache==null) {
            // In this case, just delegate to construct in case of Rhino compatibility
            if(jsContext.hasRhinoExtensions()) {
                return construct(context,args);
            }
            throw new InterpretException(null,"Cannot use constructor as function"); // $NLS-JavaAccessObject.Cannotuseaconstructorasafunction-1$
        }

        // Find the best method using 2 passes
        MethodCache m = (MethodCache)findCallable(args,methodCache,true);
        if(m==null && jsContext.autoConvertJavaArgsToString() ) {
            m = (MethodCache)findCallable(args,methodCache,false);
        }
        
        if(m!=null) {
            // Compute the parameters
            Object[] callParams = null;
            if(args.size()>0) {
                Class<?>[] argClasses=m.argClasses;
                callParams = new Object[args.size()];
                for( int i=0; i<args.size(); i++ ) {
                    callParams[i]=args.get(i).toJavaObject(argClasses[i]);
                }
            }
            Object result;
            try {
                /**
                 * PHIL: Due to a bug in Sun's VM, public methods in private
                 * classes are not accessible by default (Sun Bug #4071593).
                 * We have to explicitly set the method accessible
                 * via method.setAccessible(true).
                 * We do that only for classes that are not declared as public, because
                 * this method is checked by the security manager.
                 */
                if(INVOKE_BUG&& (clazz.getModifiers()&Modifier.PUBLIC)!=Modifier.PUBLIC) {
                    // If there is an heavy method assigned, use it
                    // heavy method: the one defined in one of the public ancestors of the class
                    // heavyInvoke is computing it and then assign it back to the method cache so the
                    // next call will be optimized
                    if(m.heavyMethod!=null) {
                        result=m.heavyMethod.invoke(instance, callParams);
                    } else {
                        result=heavyInvoke(m, instance, callParams);
                    }
                } else {
                    result=m.method.invoke(instance, callParams);
                }
            } catch(java.lang.reflect.InvocationTargetException e) {
                Throwable target = e.getTargetException();
                //if( target instanceof RuntimeException ) {
                //    // If it is a runtime exception, throw it as is
                //    throw (RuntimeException)target;
                //}
                if( target instanceof Error ) {
                    // If it is an error exception, throw it as is
                    throw (Error)target;
                }
                Exception e0= (target instanceof Exception)? (Exception)e.getTargetException():e;
                throw new InterpretException(e0,
                        StringUtil.format("Error calling method '{0}' on java class '{1}'", //$NLS-JavaAccessObject.JavaAccessObject.MethodCallError.Exception-1$
                        getMethodSignature(m.method.getName(),args), clazz.getName()));
            } catch(Exception e) {
                throw new InterpretException(e,
                        StringUtil.format("Error calling method '{0}' on java class '{1}'", //$NLS-JavaAccessObject.JavaAccessObject.MethodCallError.Exception-1$
                        getMethodSignature(m.method.getName(),args), clazz.getName()));
            }

            Class<?> retType=m.method.getReturnType();
            if(retType==Void.TYPE) {
                return FBSUndefined.undefinedValue;
            }

            if(retType.isPrimitive()) {
                FBSValue v=convertToFBSValue(result);
                return v;
            }
            
            // We let the Java object being a java object
            if(result==null) {
                return FBSNull.nullValue;
            }
            return FBSUtility.wrapAsObject(jsContext,result);
        }
        
        throw new InterpretException(null,
                "Java method '{0}' on java class '{1}' not found", //$NLS-JavaAccessObject.JavaAccessObject.MethodNotFound.Exception-1$
                getMethodSignature(methodCache.method.getName(),args),clazz.getName());
    }

    private CallableCache findCallable(FBSValueVector args, CallableCache cache, boolean strictMatch ) throws InterpretException {
        CallableCache found = null;
        Class<?>[] argsFound = null;
loop:   for(CallableCache m=cache; m!=null; m=m.next) {
            if( instance==null && !m.isStatic() ) {
                continue;
            }
            Class<?>[] argClasses=m.argClasses;
            if(argClasses.length!=args.size()) {
                continue;
            }

            for(int j=0; j<args.size(); j++) {
                FBSValue param=args.getFBSValue(j);
                // If the parameter is already a compatible value, get it as is
                if( IValue.class.isAssignableFrom(argClasses[j]) && argClasses[j].isAssignableFrom(param.getClass()) ) {
                } else {
                    // Check if we can assign the current FBSValue to that Java Class
                    if(!param.isJavaAssignableTo(argClasses[j])) {
                        // If not in "strict match" mode, then we can assume that 
                        // everything can be converted to a string, as Rhino is doing
                        if(strictMatch || argClasses[j]!=String.class) {
                            continue loop;
                        }
                    } else {
                        // Do the conversion if possible
                    }
                }
            }
            
            // Compare this method to the other one found
            // We try to keep the more specific here
            if(found!=null) {
                int r = compareArguments(argsFound,argClasses);
                if(r==0) {
                    // Ambiguity here
                    if(getJSContext().ignoreJavaCallAmbiguities()) {
                        continue loop;
                    }
                    throw new InterpretException(null,"Ambiguity when calling {0}{1} and {0}{2}",m.getName(),methodSignature(argsFound),methodSignature(argClasses)); // $NLS-JavaAccessObject.Ambiguitywhencalling01and02-1$
                }
                if(r==1) {
                    // Keep the old one as it is more specific
                    continue loop;
                }
            }
            
            // Set this method as the one to use
            found = m;
            argsFound = argClasses;
        }
        
        return found;
    }
    private static String methodSignature(Class<?>[] c) {
        StringBuilder b = new StringBuilder();
        b.append("(");
        if(c!=null) {
            for( int i=0; i<c.length; i++ ) {
                if(i>0) {
                    b.append(", ");
                }
                b.append(c[i].getName());
            }
        }
        b.append(")");
        return b.toString();
    }
    
    // According to the Java spec, we are looking for the most specific method
    // "The informal intuition is that one method is more specific than another if any invocation 
    // handled by the first method could be passed on to the other one without a compile-time type error."
    // This method returns 3 values:
    //    0:  incompatible. This leads to an error
    //    1:  a1 is more specific than a2
    //    -1: a2 is more specific than a1
    private int compareArguments(Class<?>[] a1, Class<?>[] a2) {
        int result = 0; 
        int length = a1.length;
        for(int i=0; i<length; i++ ) {
            Class<?> c1 = a1[i];  
            Class<?> c2 = a2[i];
            if( c1.isPrimitive() ) {
                c1 = getObjectTypeFromPrimitive(c1);
            }
            if( c2.isPrimitive() ) {
                c2 = getObjectTypeFromPrimitive(c2);
            }
            if(c1!=c2) {
                if( c1.isAssignableFrom(c2) ) {
                    if(result==1) {
                        return 0;
                    }
                    result = -1;
                } if( c2.isAssignableFrom(c1) ) {
                    if(result==-1) {
                        return 0;
                    }
                    result = 1;
                }
            }
        }
        return result;
    }
    private Class<?> getObjectTypeFromPrimitive(Class<?> c) {
        // Transform a primitive to its Object based class
        if(c==Character.TYPE) {
            return Character.class;
        }
        if(c==Byte.TYPE) {
            return Byte.class;
        }
        if(c==Short.TYPE) {
            return Short.class;
        }
        if(c==Integer.TYPE) {
            return Integer.class;
        }
        if(c==Long.TYPE) {
            return Long.class;
        }
        if(c==Float.TYPE) {
            return Float.class;
        }
        if(c==Double.TYPE) {
            return Double.class;
        }
        if(c==Boolean.TYPE) {
            return Boolean.class;
        }
        return Void.class;
    }
    
    private String getMethodSignature(String functionName, FBSValueVector args) {
        FastStringBuffer b = new FastStringBuffer();
        if(!StringUtil.isEmpty(functionName)) {
            b.append( functionName );
        }
        b.append( "(" ); //$NON-NLS-1$
        if( args!=null ) {
            for( int i=0; i<args.size(); i++ ) {
                if(i>0) {
                    b.append( ", " ); //$NON-NLS-1$
                }
                if( args.get(i)!=null ) {
                    b.append(args.get(i).getTypeAsString());
                } else {
                    b.append( "<null>" ); //$NON-NLS-1$
                }
            }
        }
        b.append( ")" ); //$NON-NLS-1$
        return b.toString();
    }

    // Find the first public Method instance...
    private static Object heavyInvoke(MethodCache method, Object bean, Object[] args) throws InvocationTargetException, IllegalAccessException {
        String mName = method.getName();
        Class<?>[] pTypes = method.method.getParameterTypes();

        Class<?> currentClass = bean.getClass();
        while(currentClass != null) {
            // If the class is not public, then it will just fail...
            if((currentClass.getModifiers()&Modifier.PUBLIC)==Modifier.PUBLIC) {
                try {
                    Method iMethod = currentClass.getMethod(mName, pTypes);
                    if (!method.equals(iMethod)) {
                        Object ret = iMethod.invoke(bean, args);
                        method.heavyMethod = iMethod;
                        return ret;
                    }
                } catch (NoSuchMethodException ex2) {
                } catch (IllegalAccessException ex2) {}
            }

            Class<?> intfaces[] = currentClass.getInterfaces();
            for (int i=0; i<intfaces.length; i++) {
                try {
                    Method iMethod = intfaces[i].getMethod(mName, pTypes);
                    Object ret = iMethod.invoke(bean, args);
                    method.heavyMethod = iMethod;
                    return ret;
                } catch (NoSuchMethodException ex2) {
                } catch (IllegalAccessException ex2) {}
            }
            currentClass = currentClass.getSuperclass();
        }
        
        // Try to make the method Accessible
        try {
            method.method.setAccessible(true);
            Object ret = method.method.invoke(bean, args);
            method.heavyMethod = method.method;
            return ret;
        } catch (SecurityException e) {
        }

        throw new InvocationTargetException(null,StringUtil.format("Error while calling method {0}",mName)); // $NLS-JavaAccessObject.Errorwhilecallingmethod0-1$
    }


    public boolean supportCall(){
        return true;
    }

    
    public boolean hasProperty(String name){
        return true; //getProperty(name)!=null;
    }

    public FBSReference getPropertyReference(String name) throws InterpretException {
        // Look for a JS property that we can apply to the Java object before 
        // trying a native Java method
        if(instance!=null) {
            if(clazz==String.class) {
                StringPrototype p = getJSContext().getRegistry().stringPrototype;
                if(p.hasProperty(name)) {
                    FBSObject nativeObject = FBSString.get((String)instance).toFBSObject(getJSContext());
                    FBSValue m = nativeObject.get(name);
                    return new FBSReferenceByName.ResolvedReference(nativeObject,name,m);
                }
            } else if(instance instanceof Number) {
                NumberPrototype p = getJSContext().getRegistry().numberPrototype;
                if(p.hasProperty(name)) {
                    FBSObject nativeObject = FBSNumber.get(((Number)instance).doubleValue()).toFBSObject(getJSContext());
                    FBSValue m = nativeObject.get(name);
                    return new FBSReferenceByName.ResolvedReference(nativeObject,name,m);
                }
            } else if(clazz==Boolean.class) {
                BooleanPrototype p = getJSContext().getRegistry().booleanPrototype;
                if(p.hasProperty(name)) {
                    FBSObject nativeObject = FBSBoolean.get(((Boolean)instance).booleanValue()).toFBSObject(getJSContext());
                    FBSValue m = nativeObject.get(name);
                    return new FBSReferenceByName.ResolvedReference(nativeObject,name,m);
                }
            } else if(instance instanceof Date) {
                DatePrototype p = getJSContext().getRegistry().datePrototype;
                if(p.hasProperty(name)) {
                    FBSObject nativeObject = new DateObject(getJSContext(),(Date)instance);
                    FBSValue m = nativeObject.get(name);
                    return new FBSReferenceByName.ResolvedReference(nativeObject,name,m);
                }
            }
        }
        
        // Else just return a basic reference to a property in the object
        // hasProperty() is always returning true, so that works...
        return new FBSReferenceByName(this,name);
    }

    // Used by the native JS objects to execute a Java method (string, number, boolean & date) 
    public static FBSReference getJavaPropertyReference(JSContext context, Class clazz, FBSObject object, Object instance, String name) throws InterpretException {
        MemberCache m=getClassInfoCache(context,clazz).getMembers(context,name);
        if(m!=null) {
            JavaAccessObject ja = new JavaAccessObjectWrapper(context,clazz,object,instance); 
            return new FBSReferenceByName(ja,name);
        }
        return null;
    }
    private static class JavaAccessObjectWrapper extends JavaAccessObject {
        private FBSObject object;
        public JavaAccessObjectWrapper(JSContext jsContext, Class<?> clazz, FBSObject object, Object instance) {
            super(jsContext,clazz,instance);
            this.object = object;
        }
        protected void put(String name, MemberCache m, FBSValue value) throws InterpretException {
            // We allow the methods to be overriden at the prototype level of the wrapped object
            if(m instanceof MethodCache) {
                object.put(name, value);
                return;
            }
            super.put(name, m, value);
        }
    }

    public FBSValue get(String name) throws InterpretException {
        // Special case for the "length" property
        // The method call is in fact handled by ASTCall, as another special case 
        if( (instance instanceof String) && name.equals("length") ){ // $NON-NLS-1$
            return FBSUtility.wrap(((String)instance).length());
        }
        
        MemberCache m=getClassInfoCache(getJSContext(),clazz).getMembers(getJSContext(),name);
        if(m!=null) {
            // If it is a field, return its value right now
            if(m instanceof FieldCache) {
                FieldCache fc = (FieldCache)m;
                try {
                    Field f=fc.field;
    
                    Class<?> t=f.getType();
                    Object o=f.get(instance);
                    if (o==null) {
                        return FBSNull.nullValue;
                    }
    
                    // If the result is a primitive, return the value
                    if (t.isPrimitive()){
                        FBSValue v=convertToFBSValue(o);
                        if (v==null){
                            return FBSNull.nullValue;
                        }
                        return v;
                    }
    
                    // Else, return the java object
                    return FBSUtility.wrapAsObject(getJSContext(),o);
                } catch(Exception e){
                    throw new InterpretException(e,"Error while accessing field {0} of java class {1}",fc.field.getName(),clazz.getName()); //$NLS-JavaAccessObject.JavaAccessObject.FieldAccessError.Exception-1$
                }
            }
            // If it is a property, same thing
            if(m instanceof PropertyCache) {
                if(instance==null) {
                    throw new InterpretException(null,"Cannot access Java bean property statically", name); // $NLS-JavaAccessObject.CannotaccessstaticallyaJavaBeanpr-1$
                }
                PropertyCache fc = (PropertyCache)m;
                Method read = fc.desc.getReadMethod();
                if(read==null) {
                    throw new InterpretException(null,"Java Bean property '{0}' does not have a read method", name); //$NLS-JavaAccessObject.JavaAccessObject.NoReadMethod.Exception-1$
                }
                try {
                    return FBSUtility.wrapAsObject(getJSContext(),read.invoke(instance, (Object[])null));
                } catch(Exception e) {
                    throw new InterpretException(e,"Error while accessing Java Bean property '{0}'", name); //$NLS-JavaAccessObject.JavaAccessObject.BeanAccessError.Exception-1$
                }
            }
            // If it is a method, then return self and the method is set as a global
            if(m instanceof MethodCache) {
                // In case method cache has not yet been used for this object, we can sefetly return it
                if(methodCache==null || methodCache==m) {
                    this.methodCache = (MethodCache)m;
                    return this;
                }
                // Else, we make a copy of the object to ensure safety
                JavaAccessObject j2 = new JavaAccessObject(getJSContext(),clazz,instance);          
                j2.methodCache = (MethodCache)m;
                return j2;
            }
        }
        
        // Try some predefined Java objects
        if( instance!=null ) {
            if( instance instanceof Map ) {
                Map<?,?> map = (Map<?,?>)instance;
                Object val = map.get(name);
                return val!=null ? (FBSValue)FBSUtility.wrapAsObject(getJSContext(),val) : (FBSValue)FBSNull.nullValue;
            }
            if( instance instanceof List ) {
                List<?> list = (List<?>)instance;

                // For performance reasons, we look first for property names rather than indexes
                // This avoids NumberFormatException to be thrown too often.
                if(name.equals(ArrayObject.PROP_LENGTH)) {
                    return FBSUtility.wrap(list.size());
                }
                
                ArrayPrototype proto = getJSContext().getRegistry().arrayPrototype;
                FBSValue v = proto.get(name);
                if(v!=null) {
                    return v;
                }

                try {
                    int index = Integer.parseInt(name);
                    Object val = list.get(index);
                    return val!=null ? (FBSValue)FBSUtility.wrapAsObject(getJSContext(),val) : (FBSValue)FBSNull.nullValue;
                } catch(NumberFormatException ex) {
                }
            }
            // Look for a custom property
            // A security exception can be generated here
            try {
                IValue cv = getJSContext().getProperty(instance,name);
                if(cv!=null) {
                    return (FBSValue)cv;
                }
            } catch(Exception e) {}
        }
        
        // Look if there is an inner class
        try {
	        String innerClassName = clazz.getName()+"$"+name;
	    	Class<?> innerClass = getJSContext().loadClass(innerClassName);
	    	if(innerClass!=null) {
	            FBSObject innerClassObject = new JavaAccessObject(getJSContext(),innerClass);
	    		return innerClassObject;
	    	}
        } catch(Exception e) {}
        

        throw new InterpretException(null,"Unknown member '{0}' in Java class '{1}'", name, clazz.getName()); //$NLS-JavaAccessObject.JavaAccessObject.UnknownMember.Exception-1$
    }

    public boolean hasIndexedProperty(){
        // Try some predefined Java objects
        if( instance!=null ) {
            if( instance instanceof List ) {
                return true;
            }
        }
        return false;
    }
    
    public FBSValue get(int index) throws InterpretException {
        // Try some predefined Java objects
        if( instance!=null ) {
            if( instance instanceof List ) {
                try {
                    List<?> list = (List<?>)instance;
                    Object val = list.get(index);
                    return val!=null ? (FBSValue)FBSUtility.wrapAsObject(getJSContext(),val) : (FBSValue)FBSNull.nullValue;
                } catch(Exception e) {
                    throw new InterpretException(e,"Error while accessing indexed property #'{0}' on object {1}", index, instance.getClass()); // $NLS-JavaAccessObject.ErrorwhileaccessingJavaindexedpro-1$
                }
            }
        }
        throw new RuntimeException("get(int index) not supported in JavaWrapperObject"); // $NLS-JavaWrapperObject.getintindexnotsupportedinJavaWrap-1$
    }

    
    /// Array management
    /// JavaList are behaving like Arrays
    public boolean isArray() {
        if( instance instanceof List ) {
            return true;
        }
        return false;
    }

    public boolean isList() {
        if( instance instanceof List ) {
            return true;
        }
        return false;
    }
    public int getArrayLength() {
        if( instance instanceof List ) {
            return ((List<?>)instance).size();
        }
        return 1;
    }
    public FBSValue getArrayValue(int index) throws InterpretException {
        if( instance instanceof List ) {
            List<?> l = (List<?>)instance;
            if(index>=0 && index<l.size()) {
                return FBSUtility.wrap(getJSContext(),l.get(index));
            }
            return FBSUndefined.undefinedValue;
        }
        return this;
    }
    public void setArrayValue(int index, FBSValue value) throws InterpretException {
        if( instance instanceof List ) {
            List l = (List)instance;
            if(index>=0 && index<l.size()) {
                l.set(index,value.toJavaObject());
            }
            return;
        }
        throw new InterpretException( null,"Value of type '{0}' is not array", getTypeAsString() ); //$NLS-FBSValue.FBSValue.NotAnArray.Exception-1$
    }

    /**
     * Can't put any property to a Java Object
     */
    public boolean canPut(String name){
        return true;
    }

    /**
     * Can't put any property to a Java Object
     */
    public void put(String name, FBSValue value) throws InterpretException {
        MemberCache m=getClassInfoCache(getJSContext(),clazz).getMembers(getJSContext(),name);
        put(name, m, value);
    }
    protected void put(String name, MemberCache m, FBSValue value) throws InterpretException {
        // If it is a field, return its value right now
        if(m instanceof FieldCache) {
            FieldCache fc = (FieldCache)m;
            try {
                Field f=fc.field;
                if(value.isJavaAssignableTo(f.getType()) ) {
                    f.set(instance,value.toJavaObject(f.getType()));
                    return;
                }
                throw new InterpretException(null,"Error while setting value to field {0}.{1}",clazz.getName(),name); //$NLS-JavaAccessObject.JavaAccessObject.SetValError.Exception-1$
            } catch( Exception e ) {
                throw new InterpretException(e,"Error while setting value to field {0}.{1}",clazz.getName(),name); //$NLS-JavaAccessObject.JavaAccessObject.SetValError.Exception-1$
            }
        }
        // If it is a property, same thing
        if(m instanceof PropertyCache) {
            if(instance==null) {
                throw new InterpretException(null,"Cannot access Java bean property statically", name); // $NLS-JavaAccessObject.CannotaccessstaticallyaJavaBeanpr.1-1$
            }
            PropertyCache fc = (PropertyCache)m;
            Method write = fc.desc.getWriteMethod();
            if(write==null) {
                throw new InterpretException(null,"Java Bean property '{0}' does not have write method", name); // $NLS-JavaAccessObject.JavaBeanproperty0doesnothaveawrit-1$
            }
            try {
                write.invoke(instance,new Object[]{value.toJavaObject(fc.desc.getPropertyType())});
                return;
            } catch(Exception e) {
                throw new InterpretException(e,"Error while accessing Java Bean property '{0}'", name); //$NLS-JavaAccessObject.JavaAccessObject.BeanAccessError.Exception-1$
            }
        }
        // If it is a method, then return self and the method is set as a global
        if(m instanceof MethodCache) {
            throw new InterpretException(null,"Cannot assign a value to method '{0}' in Java class '{1}'", name, clazz.getName()); //$NLS-JavaAccessObject.JavaAccessObject.AssignValError.Exception-1$
        }
        
        // Try some predefined Java objects
        if( instance!=null ) {
            if( instance instanceof Map ) {
                Map map = (Map)instance;
                map.put(name, value.toJavaObject());
                return;
            }
            if( instance instanceof List ) {
                List list = (List)instance;
                if(name.equals(ArrayObject.PROP_LENGTH)) {
                    int len = value.intValue();
                    int size = list.size();
                    if(len>size) {
                        for( int i=size; i<len; i++) {
                            list.add(null);
                        }
                    } else if(len<size) {
                        for( int i=size-1; i>=len; i--) {
                            list.remove(i);
                        }
                    }
                    return;
                }
            }
            // Look for a custom property
            if(getJSContext().putProperty(instance,name,value)) {
                return;
            }
        }

        throw new InterpretException(null,"Unknown member '{0}' in Java class '{1}'", name, clazz.getName()); //$NLS-JavaAccessObject.JavaAccessObject.UnknownMember.Exception-1$
    }

    /**
     * Can't create any property in a Java Object
     */
    public boolean createProperty(String name , int attribute, FBSValue value ){
        return false;
    }

    /**
     * Can't delete any property from a Java Object
     */
    public boolean delete(String name){
        return false;
    }

    public String getName(){
        return clazz.getName();
    }


    // REALLY TEMP!!
    public Iterator getPropertyKeys() {
        return null;
    }


    private FBSValue convertToFBSValue(Object o){
        if( o instanceof Number ) {
            Number num=(Number)o;
            return FBSNumber.get(num.doubleValue());
        } else if (o instanceof Boolean){
            Boolean bool=(Boolean)o;
            return FBSBoolean.get(bool.booleanValue());
        } else if (o instanceof Character){
            Character c=(Character)o;
            return FBSString.get(c.toString());
        }
        // Should not happen...
        return FBSUndefined.undefinedValue;
    }


    // ===================================================================================
    // Java access optimization
    // ===================================================================================
    
    private static ClassInfoCache getClassInfoCache(JSContext context, Class<?> c) {
        ClassInfoCache ci = (ClassInfoCache)context.getClassInfo(c);
        if(ci==null) {
            synchronized(context) {
                ci = (ClassInfoCache)context.getClassInfo(c);
                if(ci==null) {
                    ci = new ClassInfoCache(context,c);
                    context.putClassInfo(c,ci);
                }
            }
        }
        return ci;
    }
    
    private static abstract class MemberCache {
    }
    
    private static abstract class CallableCache extends MemberCache {
        CallableCache next;
        Class<?>[] argClasses;
        CallableCache(Class<?>[] argClasses) {
            this.argClasses = argClasses;
        }
        abstract boolean isStatic();
        abstract String getName();
    }

    private static class MethodCache extends CallableCache {
        Method  method;
        Method  heavyMethod;
        MethodCache(Method method) {
            super(method.getParameterTypes());
            this.method = method;
        }
        boolean isStatic() {
            int modifier=method.getModifiers();
            return (modifier&Modifier.STATIC)!=0;
        }
        String getName() {
            return method.getName();
        }
    }
    
    private static class ConstructorCache extends CallableCache {
        Constructor<?> constructor;
        ConstructorCache(Constructor<?> constructor) {
            super(constructor.getParameterTypes());
            this.constructor = constructor;
        }
        boolean isStatic() {
            return true;
        }
        String getName() {
            return "new "+constructor.getName(); // $NON-NLS-1$
        }
    }

    private static class FieldCache extends MemberCache {
        Field field;
        FieldCache(Field field) {
            this.field = field;
        }
        String getName() {
            return field.getName();
        }
    }

    private static class PropertyCache extends MemberCache {
        PropertyDescriptor desc;
        PropertyCache(PropertyDescriptor desc) {
            this.desc = desc;
        }
        String getName() {
            return desc.getName();
        }
    }
    
    private static class ClassInfoCache {
    
        private Class<?> clazz;
        private boolean allCached;
        private ConstructorCache constructors;
        private HashMap<String,MemberCache> members;
        
        ClassInfoCache(JSContext context, Class<?> clazz) {
            this.clazz = clazz;
            this.members = new HashMap<String,MemberCache>();
            
            // There is a trade-off between caching all the members of the class and 
            // caching them on-the-fly.
            // For most classes, we don't need to access all the members, so we cache them
            // when necessary. Maps are different, as they authorize dynamic members. So,
            // we optimize this case by caching all the members for Maps
            this.allCached = Map.class.isAssignableFrom(clazz);
            if(allCached) {
                // Add the javabean properties
                if(context.hasJavaBeanAccess()) {
                    try { 
                        BeanInfo bi = context.getBeanInfo(clazz);
                        PropertyDescriptor[] desc =  bi.getPropertyDescriptors();
                        if(desc!=null) {
                            for(int i=0; i<desc.length; i++) {
                                if(context.isJavaPropertyAllowed(desc[i])) {
                                    PropertyCache pc = new PropertyCache(desc[i]);
                                    members.put(pc.getName(),pc);
                                }
                            }
                        }
                    } catch(Exception ex) {}
                }
                // Add all the fields
                Field[] ff=clazz.getFields();
                for(int i=0; i<ff.length; i++) {
                    Field f = ff[i];
                    if((f.getModifiers()&Modifier.PUBLIC)==Modifier.PUBLIC ) {
                        if(context.isJavaFieldAllowed(f)) {
                            // Put it in the list
                            FieldCache fc = new FieldCache(f);
                            members.put(fc.getName(),fc);
                        }
                    }
                }
                
                // Add all the methods
                Method[] mm=clazz.getMethods();
                for(int i=0; i<mm.length; i++) {
                    Method m = mm[i];
                    // IBM JVM has some volatile methods (??), like StringBuffer.append()
                    // Removing these methods fixes ambiguities
                    if( !Modifier.isPublic(m.getModifiers()) || Modifier.isVolatile(m.getModifiers()) ) {
                        continue;
                    }
                    if(context.isJavaMethodAllowed(m)) {
                        MethodCache mc = new MethodCache(m);
                        MemberCache c = members.get(mc.getName());
                        if(c instanceof MethodCache) {
                            mc.next = (MethodCache)c;
                        } 
                        members.put(mc.getName(),mc);
                    }
                }
            }
        }
        
        ConstructorCache getConstructors(JSContext context) {
            if(constructors==null) {
                synchronized(this) {
                    if(constructors==null) {
                        Constructor<?>[] c=clazz.getConstructors();
                        for(int i=0; i<c.length; i++) {
                            if( (c[i].getModifiers()&Modifier.PUBLIC)==0 ) {
                                continue;
                            }
                            if(context.isJavaConstructorAllowed(c[i])) {
                                ConstructorCache mc = new ConstructorCache(c[i]);
                                mc.next = constructors;
                                constructors = mc;
                            }
                        }
                    }
                }
            }
            return constructors;
        }
        
        MemberCache getMembers(JSContext context, String name) {
            MemberCache cached = (MemberCache)members.get(name);
            if(cached!=null) {
                return cached;
            }
            
            // If all the members were cached, then none exists...
            if(allCached) {
                return null;
            }
            
            synchronized(this) {
                cached = (MemberCache)members.get(name);
                if(cached!=null) {
                    return cached;
                }
                
                // Look if it has been added as empty (do not exist)
                // a Map.getEntry() should be nice, to avoid the double search...
                if(members.containsKey(name)) {
                    return null;
                }

                // If the member name is empty, it is because we are looking for a constructor
                if(name.length()==0) {
                    ConstructorCache first = null;
                    return first;
                }
                
                // Look for methods with that name
                MethodCache first = null;
    // PHIL: this doesn't work as the same method can be declared at different class levels
    // and overloaded -> leads to duplicate            
    //            for( Class c=clazz; c!=null; c=c.getSuperclass() ) {
    //                Method[] m2=c.getDeclaredMethods();
    //                for(int i=0; i<m.length; i++) {
    //                    if(!m[i].getName().equals(name)) {
    //                        continue;
    //                    }
    //                    if( (m[i].getModifiers()&Modifier.PUBLIC)==0 ) {
    //                        continue;
    //                    }
    //                    MethodCache mc = new MethodCache(m[i]);
    //                    mc.next = first;
    //                    first = mc;
    //                }
    //            }
                Method[] mm=clazz.getMethods();
                for(int i=0; i<mm.length; i++) {
                    Method m = mm[i];
                    if(!m.getName().equals(name)) {
                        continue;
                    }
                    // IBM JVM has some volatile methods (??), like StringBuffer.append()
                    // Removing these methods fixes ambiguities
                    if( !Modifier.isPublic(m.getModifiers()) || Modifier.isVolatile(m.getModifiers()) ) {
                        continue;
                    }
                    if(context.isJavaMethodAllowed(m)) {
                        MethodCache mc = new MethodCache(m);
                        mc.next = first;
                        first = mc;
                    }
                }
                if(first!=null) {
                    members.put(name,first);
                    return first;
                }
                
                // Look if there is a field with that name
                try {
                    Field f=clazz.getField(name);
                    if( f!=null && (f.getModifiers()&Modifier.PUBLIC)==Modifier.PUBLIC ) {
                        if(context.isJavaFieldAllowed(f)) {
                            // Put it in the list
                            FieldCache fc = new FieldCache(f);
                            members.put(name,fc);
                            return fc;
                        }
                    }
                } catch( NoSuchFieldException e ) {
                }
                
                // Look for a javabean property
                if(context.hasJavaBeanAccess()) {
                    try { 
                        BeanInfo bi = context.getBeanInfo(clazz);
                        PropertyDescriptor[] desc =  bi.getPropertyDescriptors();
                        if(desc!=null) {
                            for(int i=0; i<desc.length; i++) {
                                if(context.isJavaPropertyAllowed(desc[i])) {
                                    if(desc[i].getName().equals(name)) {
                                        PropertyCache pc = new PropertyCache(desc[i]);
                                        members.put(name,pc);
                                        return pc;
                                    }
                                }
                            }
                        }
                    } catch(Exception ex) {}
                }
                
                // Nothing corresponds here...
                // put an empty value in, so we won't search for it again
                members.put(name,null);
                return null;
            }
        }
    }
}