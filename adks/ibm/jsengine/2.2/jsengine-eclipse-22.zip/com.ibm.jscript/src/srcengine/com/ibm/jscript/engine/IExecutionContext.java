/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.engine;

import java.io.PrintStream;
import java.security.AccessControlContext;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JSExpression;
import com.ibm.jscript.ASTTree.ASTDebug;
import com.ibm.jscript.ASTTree.ASTExecutionScope;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSGlobalObject;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSReference;
import com.ibm.jscript.types.FBSValue;

/**
 * Javascript execution context.
 * This is a abstract class that defines a javascript execution context. It is used
 * for at 2 places:
 * <ul>
 *   <li>When evaluating an expression/function.
 *       See ProgramContext for that
 *   <li>When calling a javascript function from javascript code (temporary context)
 *       See Function context for that
 * </ul>
 */
public abstract class IExecutionContext {

	private JSContext jsContext;
    private FBSValue returnValue;
    protected IExecutionContext parentContext;
    protected FBSDefaultObject varObject;
    protected FBSGlobalObject globalObject;
    protected FBSObject _this;
    protected boolean useListOp;
    ASTDebug debugStatement;

    protected IExecutionContext(JSContext jsContext, IExecutionContext parentContext, FBSGlobalObject globalObject, FBSDefaultObject varObject, FBSObject _this) {
    	this.jsContext = jsContext;
    	this.parentContext = parentContext;
        this.globalObject = globalObject;
        this.varObject = varObject;
        if(_this!=null) {
        	this._this = _this;
        } else {
        	this._this = globalObject;
        }
    }

    public abstract JSExpression getExpression();

    public final JSContext getJSContext() {
    	return jsContext;
    }
    
    
    // ======================================================================
    // Extension management
    // ======================================================================
    
    public boolean isUseListOp() {
    	return useListOp;
    }

    public void initExecutionScope(ASTExecutionScope scope) {
    	Boolean b = scope.isUseListOp();
    	if(b!=null) {
    		this.useListOp = b;
    	} else {
    		this.useListOp = getJSContext().hasDefaultListOp();
    	}
    }
    
    
    // ======================================================================
    // Security management
    // ======================================================================

    public AccessControlContext getAccessControlContext() {
    	return jsContext.getAccessControlContext();
    }

    
    /**
     * @return the source referenceId 
     * by default, it is taken from the JSExpression, Subclasses can override
     */
    public String getSourceReferenceID() throws InterpretException{
    	return getExpression().getSourceReferenceID();
    }

    public FBSDefaultObject getVariableObject(){
        return varObject;
    }

    public FBSDefaultObject getFunctionParentVariableObject(){
        return null;
    }

    public FBSGlobalObject getGlobalObject(){
        return globalObject;
    }

    public FBSObject getThis(){
        if(_this!=null) {
            return _this;
        }
        return getGlobalObject();
    }
    
    public IExecutionContext getParentContext() {
    	return parentContext;
    }
    
    public ProgramContext getProgramContext() {
        return parentContext.getProgramContext();
    }


    public FBSValue getReturnValue() {
        return returnValue;
    }

    public void setReturnValue(FBSValue returnValue) {
        this.returnValue = returnValue;
    }

    /**************************************************************************
     * Standard stream access
     *************************************************************************/
    
    public PrintStream getStandardStream() {
    	if(parentContext!=null) {
    		return parentContext.getStandardStream();
    	}
        return getJSContext().getStandardStream(); 
    }
    
    public void print(String str) {
    	getJSContext().print(getStandardStream(),str);
    }
    
    public void println(String str) {
    	getJSContext().println(getStandardStream(),str);
    }
    
    public void exception(Throwable t, String msg) {
    	if(parentContext!=null) {
            parentContext.exception(t,msg);
            return;
    	}
        if(!StringUtil.isEmpty(msg)) {
            println(msg);
        }
        t.printStackTrace(getStandardStream());
    }

    
    /**************************************************************************
     * Local scope chain.
     * That chain is used when inserting some temporary objects, using statements
     * like with or try/catch
     *************************************************************************/

    int scopeCount;
    FBSObject[] scopeData;

    public void pushToScope(FBSObject object){
        if( scopeData==null ) {
            scopeData = new FBSObject[8];
        } else if( scopeCount==scopeData.length ) {
            FBSObject[] old = scopeData;
            scopeData = new FBSObject[scopeCount+8];
            System.arraycopy(old,0,scopeData,0,scopeCount);
        }
        scopeData[scopeCount++] = object;
    }

    public void popFromScope(){
        scopeData[--scopeCount] = null;
    }


    public abstract FBSReference findIdentifier(String name) throws InterpretException;
    protected abstract FBSReference findGlobalScopeIdentifier(String name) throws InterpretException;
    
    public final String[] getJSVariables() {
    	Set members = new HashSet();
    	getJSVariables(members);
    	String[] s = (String[])members.toArray(new String[members.size()]);
    	Arrays.sort(s);
    	return s;
    }

    protected void getJSVariables(Set members) {
    	// Look into the local variables, if different from global
    	if( varObject!=globalObject ) {
    		getJSVariables(members,varObject);
    	}
    	// Look into the global variables
    	getJSVariables(members,globalObject);
    }

    protected void getJSVariables(Set members, FBSDefaultObject object) {
    	for( Iterator it=object.getPropertyKeys(); it.hasNext(); ) {
    		members.add(it.next());
    	}
    }

	/**
	 * @return Returns the debugStatement.
	 */
	public ASTDebug getDebugStatement() {
		return debugStatement;
	}

	/**
	 * @param debugStatement The debugStatement to set.
	 */
	public void setDebugStatement(ASTDebug debugStatement) {
		this.debugStatement = debugStatement;
	}
}
