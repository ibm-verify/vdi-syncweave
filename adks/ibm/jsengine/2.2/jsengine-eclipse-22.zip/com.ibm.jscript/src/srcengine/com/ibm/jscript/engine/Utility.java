/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.engine;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.ASTTree.ASTConstants;
import com.ibm.jscript.std.ArrayObject;
import com.ibm.jscript.std.ErrorObject;
import com.ibm.jscript.types.FBSBoolean;
import com.ibm.jscript.types.FBSNumber;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.JavaWrapperObject;

public final class Utility {

	public static long toUint32(double d) {
		return ((long)d)&0xFFFFFFFFL;
	}
	
    public static FBSValue operation(IExecutionContext context, FBSValue v1,FBSValue v2,int op) throws InterpretException{
        switch(op){
            case ASTConstants.MULTIPLY:
            case ASTConstants.DIVIDE:
            case ASTConstants.MODULO: {
                // Operation on lists
                if( context.isUseListOp() && (v1.isList() || v2.isList()) ) {
                    int c1 = v1.getArrayLength();
                    int c2 = v2.getArrayLength();
                    int c = Math.max(c1,c2);
                    if( c>1 ) {
                        ArrayObject list = new ArrayObject(context.getJSContext(),c);
                        for( int i=0; i<c; i++ ) {
                            FBSValue val1 = v1.getArrayValue(Math.min(c1-1,i));
                            FBSValue val2 = v2.getArrayValue(Math.min(c2-1,i));
                            list.setArrayValue(i,factorOperation(val1,val2,op));
                        }
                        return list;
                    }
                }
                // Operation on single values
                return factorOperation(v1,v2,op);
            }

            case ASTConstants.ADD:
            case ASTConstants.SUBTRACT: {
                // Operation on lists
                if( context.isUseListOp() && (v1.isList() || v2.isList()) ) {
                    int c1 = v1.getArrayLength();
                    int c2 = v2.getArrayLength();
                    int c = Math.max(c1,c2);
                    if( c>1 ) {
                        ArrayObject list = new ArrayObject(context.getJSContext(),c);
                        for( int i=0; i<c; i++ ) {
                            FBSValue val1 = v1.getArrayValue(Math.min(c1-1,i));
                            FBSValue val2 = v2.getArrayValue(Math.min(c2-1,i));
                            list.setArrayValue(i,addOperation(val1,val2,op));
                        }
                        return list;
                    }
                }
                // Operation on single values
                return addOperation(v1,v2,op);
            }

            case ASTConstants.EQUAL:
            case ASTConstants.NOT_EQUAL: {
                // Operation on lists
                if( context.isUseListOp() && (v1.isList() || v2.isList()) ) {
                    int c1 = v1.getArrayLength();
                    int c2 = v2.getArrayLength();
                    int c = Math.max(c1,c2);
                    if( c>1 ) {
                        for( int i=0; i<c; i++ ) {
                            FBSValue val1 = v1.getArrayValue(Math.min(c1-1,i));
                            FBSValue val2 = v2.getArrayValue(Math.min(c2-1,i));
                            boolean b = equalityOperation(val1,val2,op);
                            if(b) {
                                return FBSBoolean.TRUE;
                            }
                        }
                        return FBSBoolean.FALSE;
                    }
                }
                // Operation on single values
                return equalityOperation(v1,v2,op) ? FBSBoolean.TRUE : FBSBoolean.FALSE;
            }

            case ASTConstants.STRICT_EQUAL:
            case ASTConstants.STRICT_NOT_EQUAL: {
                return equalityOperation(v1,v2,op) ? FBSBoolean.TRUE : FBSBoolean.FALSE;
            }

            case ASTConstants.LESS:
            case ASTConstants.GREATER:
            case ASTConstants.LESS_EQUAL:
            case ASTConstants.GREATER_EQUAL: {
                // Operation on lists
                if( context.isUseListOp() && (v1.isList() || v2.isList()) ) {
                    int c1 = v1.getArrayLength();
                    int c2 = v2.getArrayLength();
                    int c = Math.max(c1,c2);
                    if( c>1 ) {
                        for( int i=0; i<c; i++ ) {
                            FBSValue val1 = v1.getArrayValue(Math.min(c1-1,i));
                            FBSValue val2 = v2.getArrayValue(Math.min(c2-1,i));
                            boolean b = relationalOperation(val1,val2,op);
                            if(b) {
                                return FBSBoolean.TRUE;
                            }
                        }
                        return FBSBoolean.FALSE;
                    }
                }
                return relationalOperation(v1,v2,op) ? FBSBoolean.TRUE : FBSBoolean.FALSE;
            }

            case ASTConstants.INSTANCEOF:
                return instanceOf(context.getJSContext(),v1,v2) ? FBSBoolean.TRUE : FBSBoolean.FALSE;

            case ASTConstants.SHIFT_LEFT:
            case ASTConstants.SHIFT_RIGHT:
            case ASTConstants.USHIFT_RIGHT:
                return shiftOperation(v1,v2,op);

            case ASTConstants.IN:
                return inOp(context.getJSContext(),v1,v2) ? FBSBoolean.TRUE : FBSBoolean.FALSE;

            case ASTConstants.BITWISE_AND:
            case ASTConstants.BITWISE_OR:
            case ASTConstants.BITWISE_XOR:
                return bitwiseOperation(v1,v2,op);

            case ASTConstants.REL_AND:
            case ASTConstants.REL_OR:
                return binaryOperation(v1,v2,op);

        }
        return null;
    }

    public static FBSType operationType(FBSType t1, FBSType t2, int op) {
        if( t1.isInvalid() || t2.isInvalid() ) {
            return FBSType.invalidType;
        }
        switch(op){
            case ASTConstants.MULTIPLY:
            case ASTConstants.DIVIDE:
            case ASTConstants.MODULO:
                return FBSType.numberType;


            case ASTConstants.ADD:
            case ASTConstants.SUBTRACT:
                if( t1.isString() || t2.isString() ) {
                    return FBSType.stringType;
                }
                return FBSType.numberType;


            case ASTConstants.SHIFT_LEFT:
            case ASTConstants.SHIFT_RIGHT:
            case ASTConstants.USHIFT_RIGHT:
                return FBSType.numberType;

            case ASTConstants.LESS:
            case ASTConstants.GREATER:
            case ASTConstants.LESS_EQUAL:
            case ASTConstants.GREATER_EQUAL:
                return FBSType.booleanType;

            case ASTConstants.INSTANCEOF:
                return FBSType.booleanType;

            case ASTConstants.IN:
                return FBSType.booleanType;

            case ASTConstants.EQUAL:
            case ASTConstants.NOT_EQUAL:
            case ASTConstants.STRICT_EQUAL:
            case ASTConstants.STRICT_NOT_EQUAL:
                return FBSType.booleanType;

            case ASTConstants.BITWISE_AND:
            case ASTConstants.BITWISE_OR:
            case ASTConstants.BITWISE_XOR:
                return FBSType.booleanType;

            case ASTConstants.REL_AND:
            case ASTConstants.REL_OR:
                return FBSType.booleanType;

        }
        return null;
    }

    public static FBSValue factorOperation(FBSValue v1,FBSValue v2,int op) throws InterpretException {
        double d1=v1.numberValue();
        double d2=v2.numberValue();
        double r;
        switch(op){
            case ASTConstants.MULTIPLY:
                r=d1*d2;
                return FBSNumber.get(r);
            case ASTConstants.DIVIDE:
                r=d1/d2;
                return FBSNumber.get(r);
            case ASTConstants.MODULO:
                r=d1%d2;
                return FBSNumber.get(r);
        }
        throw new InterpretException(null,"Illegal factor operation"); //$NLS-Utility.Utility.IllegalFactorOp.Exception-1$
    }


    public static FBSValue addOperation(FBSValue v1,FBSValue v2,int op) throws InterpretException{
        switch(op){
            case ASTConstants.ADD: {
            	v1 = v1.toFBSPrimitive();
            	v2 = v2.toFBSPrimitive();
                if( v1.isString() || v2.isString() ) {
                    return FBSString.get(v1.stringValue()+v2.stringValue());
                } else {
                    double d1=v1.numberValue();
                    double d2=v2.numberValue();
                    double r=d1+d2;
                    return FBSNumber.get(r);
                }
            }
            case ASTConstants.SUBTRACT: {
                double d1=v1.numberValue();
                double d2=v2.numberValue();
                double r=d1-d2;
                return FBSNumber.get(r);
            }
        }
        throw new InterpretException(null,"Illegal addition operation"); //$NLS-Utility.Utility.IllegalAddOp.Exception-1$
    }


    public static FBSValue shiftOperation(FBSValue v1,FBSValue v2,int op) throws InterpretException{
        int i1=(int)(v1.longValue() & 0xFFFFFFFF);
        int i2=(int)(v2.longValue() & 0xFFFFFFFF);
        int r;
        switch(op){
            case ASTConstants.SHIFT_LEFT:
                r=(i1<<(i2&0x1F));
                return FBSNumber.get(r);
            case ASTConstants.SHIFT_RIGHT:
                r=(i1>>(i2&0x1F));
                return FBSNumber.get(r);
            case ASTConstants.USHIFT_RIGHT:
                r=(i1>>>(i2&0x1F));
                return FBSNumber.get(r);
        }
        throw new InterpretException(null,"Illegal shift operation"); //$NLS-Utility.Utility.IllegalShiftOp.Exception-1$
    }

    public static boolean instanceOf(JSContext jsContext, FBSValue v1,FBSValue v2) throws InterpretException{
        if( !(v2 instanceof FBSObject) ) {
            throw new InterpretException(null,ErrorObject.TypeErrorObject.create(jsContext,"Value must be an object, {0}",FBSUtility.getDisplayType(v2))); //$NLS-Utility.Utility.InvalidValue.Exception-1$
        }
        FBSObject obj= (FBSObject) v2;
        boolean b=obj.hasInstance(v1);
        return b;
    }


    public static boolean inOp(JSContext jsContext, FBSValue v1,FBSValue v2) throws InterpretException{
        if (!v2.isObject()){
            throw new InterpretException(null,ErrorObject.TypeErrorObject.create(jsContext,"Value must be an object, {0}",FBSUtility.getDisplayType(v2))); //$NLS-Utility.Utility.InvalidValue.Exception-1$
        }
        FBSObject obj= (FBSObject) v2;
        String str= v1.stringValue();
        boolean b= obj.hasProperty(str);
        return b;
    }


    public static boolean equalityOperation(FBSValue v1,FBSValue v2,int op) throws InterpretException{
        switch(op){
            case ASTConstants.EQUAL:
                return isEqual(v1,v2);

            case ASTConstants.NOT_EQUAL:
                return !isEqual(v1,v2);

            case ASTConstants.STRICT_EQUAL:
                return isStrictEqual(v1,v2);

            case ASTConstants.STRICT_NOT_EQUAL:
                return !isStrictEqual(v1,v2);
        }
        throw new InterpretException(null,"Illegal equality operation"); //$NLS-Utility.Utility.IllegalEqOp.Exception-1$
    }

    public static boolean relationalOperation(FBSValue v1,FBSValue v2,int op) throws InterpretException{
        switch(op){
            case ASTConstants.LESS: {
                Boolean b = isLess(v1,v2);
                return b!=null ? b : false;
            }
            case ASTConstants.GREATER: {
            	Boolean b = isLess(v2,v1);
                return b!=null ? b : false;
            }
            case ASTConstants.LESS_EQUAL: {
            	Boolean b = isLess(v2,v1);
                return b!=null ? !b : false;
            }
            case ASTConstants.GREATER_EQUAL: {
            	Boolean b = isLess(v1,v2);
                return b!=null ? !b : false;
            }
        }
        throw new InterpretException(null,"Illegal relational operation"); //$NLS-Utility.Utility.IllegalRelationalOp.Exception-1$
    }

    public static FBSValue bitwiseOperation(FBSValue v1,FBSValue v2,int op) throws InterpretException{
        long i1=v1.longValue() & 0xFFFFFFFF;
        long i2=v2.longValue() & 0xFFFFFFFF;
        int r;

        switch(op){
            case ASTConstants.BITWISE_AND:
                r=(int)(i1&i2);
                return FBSNumber.get(r);
            case ASTConstants.BITWISE_OR:
                r=(int)(i1|i2);
                return FBSNumber.get(r);
            case ASTConstants.BITWISE_XOR:
                r=(int)(i1^i2);
                return FBSNumber.get(r);

        }
        throw new InterpretException(null,"Illegal relational operation"); //$NLS-Utility.Utility.IllegalRelationalOp.Exception-1$
    }


    public static FBSValue binaryOperation(FBSValue v1,FBSValue v2,int op) throws InterpretException{
        switch(op){
            case ASTConstants.REL_AND:
                if(!v1.booleanValue()) {
                    return v1;
                }
                
                return v2;
            case ASTConstants.REL_OR:
                // if operator is || and left node is true
                // don't evaluate the right node ,return true
                if(v1.booleanValue()){
                    return v1;
                }
                
                return v2;
        }
        throw new InterpretException(null,"Illegal relational operation"); //$NLS-Utility.Utility.IllegalRelationalOp.Exception-1$
    }


    private static Boolean isLess(FBSValue v1,FBSValue v2) throws InterpretException {
        FBSValue p1=v1.toFBSPrimitive();
        FBSValue p2=v2.toFBSPrimitive();
        if (p1.getType()==FBSValue.STRING_TYPE && p2.getType()==FBSValue.STRING_TYPE){
            String s1=p1.stringValue();
            String s2=p2.stringValue();
            if (s1.compareTo(s2)<0) { 
            	return Boolean.TRUE;
            }
        	return Boolean.FALSE;
        }
        // PHIL: according to the java spec 2.0, 15.20.1, if either operand is NaN then the result is false
        // => Don't need to check it explicitly
        double d1=p1.numberValue();
        if (Double.isNaN(d1)) return null;
        double d2=p2.numberValue();
        if (Double.isNaN(d2)) return null;
        if (d1<d2) return Boolean.TRUE;
        return Boolean.FALSE;
    }

    public static boolean isEqual(FBSValue v1,FBSValue v2) throws InterpretException {
        int type1 = v1.getType();
        int type2 = v2.getType();
        if (type1!=type2) {
            if ((type1==FBSValue.NULL_TYPE && type2==FBSValue.UNDEFINED_TYPE)||
                (type2==FBSValue.NULL_TYPE && type1==FBSValue.UNDEFINED_TYPE)) {
                return true;
            }

            if ((type1==FBSValue.NUMBER_TYPE && type2==FBSValue.STRING_TYPE) ||
                (type2==FBSValue.NUMBER_TYPE && type1==FBSValue.STRING_TYPE)){
                return v1.numberValue()==v2.numberValue();
            }

// Spec 11.9.3  -fixed 9/8/2009            
//            if ((type1==FBSValue.BOOLEAN_TYPE || type2==FBSValue.BOOLEAN_TYPE)){
//                return v1.numberValue()==v2.numberValue();
//            }
            if (type1==FBSValue.BOOLEAN_TYPE){
                return isEqual(v1.toFBSNumber(), v2);
            }
            if (type2==FBSValue.BOOLEAN_TYPE){
                return isEqual(v1, v2.toFBSNumber());
            }

            if ((type1==FBSValue.NUMBER_TYPE || type1==FBSValue.STRING_TYPE)
                && type2==FBSValue.OBJECT_TYPE){
                return isEqual(v1,v2.toFBSPrimitive());
            }

            if ((type2==FBSValue.NUMBER_TYPE || type2==FBSValue.STRING_TYPE)
                && type1==FBSValue.OBJECT_TYPE){
                return isEqual(v1.toFBSPrimitive(),v2);
            }
            return false;
        }
        switch(type1) {
            case FBSValue.UNDEFINED_TYPE:
                return true;
            case FBSValue.NULL_TYPE:
                return true;
            case FBSValue.STRING_TYPE:
                return v1.stringValue().equals(v2.stringValue());
            case FBSValue.BOOLEAN_TYPE:
                return v1.booleanValue()==v2.booleanValue();
            case FBSValue.FUNCTION_TYPE:
            case FBSValue.OBJECT_TYPE:
            	if(v1 instanceof JavaWrapperObject && v2 instanceof JavaWrapperObject) {
            		return ((JavaWrapperObject)v1).getJavaObject()==((JavaWrapperObject)v2).getJavaObject();
            	}
                return v1==v2;
        }

        return v1.numberValue()==v2.numberValue();
    }

    private static boolean isStrictEqual(FBSValue v1,FBSValue v2){
        int type1 = v1.getType();
        if (type1!=v2.getType()){
            return false;
        }
        if (type1==FBSValue.UNDEFINED_TYPE){
            return true;
        }

        if (type1==FBSValue.NULL_TYPE){
            return true;
        }

        if (type1==FBSValue.NUMBER_TYPE){
            double d1=v1.numberValue();
            if(Double.isNaN(d1)) {
            	return false;
            }
            double d2=v2.numberValue();
            if(Double.isNaN(d2)) {
            	return false;
            }
            return d1==d2;
        }
        if (type1==FBSValue.STRING_TYPE){
            return v1.stringValue().equals(v2.stringValue());
        }
        if (type1==FBSValue.BOOLEAN_TYPE){
            return v1.booleanValue()==v2.booleanValue();
        }

    	if(v1 instanceof JavaWrapperObject && v2 instanceof JavaWrapperObject) {
    		return ((JavaWrapperObject)v1).getJavaObject()==((JavaWrapperObject)v2).getJavaObject();
    	}
        if(v1==v2) {
        	return true;
        }
        
        return false;
    }
}
