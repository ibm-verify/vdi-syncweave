/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.std.ArrayObject;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSUndefined;
import com.ibm.jscript.types.FBSValueVector;

public class ASTArrayLiteral extends ASTNode {
	
    private NodeVector nodes= new NodeVector();

    public ASTArrayLiteral() {
    }

    public void add(ASTNode node){
        nodes.add(assignParent(node));
    }

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        return FBSType.jsArrayType;
    }

    public int getSlotCount(){
        return nodes.size();
    }
    public void increaseSizeBy(int delta){
        if (delta>0){
            nodes.setSize(nodes.size()+delta);
        }
    }

    public ASTNode readSlotAt(int index){
        return  nodes.get(index);
    }

    public boolean interpret(ASTNode caller,IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            int count = nodes.size();
            FBSValueVector vec= new FBSValueVector(count);
            for(int i=0;i<count;i++){
                ASTNode n=nodes.get(i);
                if (n==null){
                    vec.add(FBSUndefined.undefinedValue);
                }else{
                    if(!n.interpret(this,context,result)) {
                    	return false;
                    }
                    vec.add(result.getFBSValue());
                }
            }
            ArrayObject array= new ArrayObject(context.getJSContext(),vec,true);
            result.setNormal(array);
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitArrayLiteral(this, param);
    }
}
