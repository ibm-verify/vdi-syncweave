/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSUndefined;

public class ASTReturn extends ASTNode{
	
    private ASTNode expressionNode;
    
    public ASTReturn() {
    }

    public void add(ASTNode expr) {
        expressionNode=assignParent(expr);
    }

    public int getSlotCount() {
        return expressionNode==null?0:1;
    }
    
    public ASTNode readSlotAt(int i) {
        return expressionNode;
    }

    public ASTNode getReturnNode() {
        return expressionNode;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        if (expressionNode!=null){
            if(!expressionNode.interpret(this,context,result)) {
            	return false;
            }
        } else {
            result.setNormal(FBSUndefined.undefinedValue);
        }
        context.setReturnValue(result.getFBSValue());
        result.setSignal(InterpretResult.SIGNAL_RETURN);
        return false;
    }

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        return expressionNode.getResultType(jsContext,symbolCallback);
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitReturn(this, param);
    }
}
