/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import com.ibm.commons.util.FastStringBuffer;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.std.ErrorObject;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.FBSValueVector;
import com.ibm.jscript.types.JavaAccessObject;
import com.ibm.jscript.types.JavaFactory;
import com.ibm.jscript.types.JavaPackageObject;

public class ASTNew extends ASTNode{
    private ASTNode memberExpression;
    private ASTNode argumentExpression;

    public ASTNew() {
    }

    public void add(ASTNode expr,ASTNode arguments){
        memberExpression=assignParent(expr);
        argumentExpression=assignParent(arguments);
    }

    public int getSlotCount(){
        return argumentExpression==null?1:2;
    }

    public ASTNode readSlotAt(int index){
        switch(index){
            case 0:return memberExpression;
            case 1:return argumentExpression;
        }
        return null;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            // evaluate the parameters first
            FBSValueVector args;
            if (argumentExpression!=null){
            	int count=argumentExpression.getSlotCount();
            	if(count>0) {
	                args=new FBSValueVector(count);
	                for(int i=0;i<count;i++){
	                    ASTNode node=argumentExpression.readSlotAt(i);
	                    if (node!=null){
	                        if(!node.interpret(this,context,result)) {
	                        	return false;
	                        }
	                        args.add(result.getFBSValue());
	                    }
	                }
                } else {
                    args=FBSValueVector.emptyVector;
                }
            } else {
                args=FBSValueVector.emptyVector; // don't send a null object to the construct
            }

            FBSValue value=null;
            // check if it can be a java object instantiation
            // java objects must always be qualified (package1.package2.className)
            if (isJavaArray()){
                JavaArrayClass ja=resolveJavaArray(context,result);
                if(ja!=null){
                	String name = ja.getClassName();
                    try{
                        value=JavaFactory.instantiate(context.getJSContext(),name,ja.getDim());
                        result.setNormal(value);
                    }catch(Exception e){
                        throw new InterpretException(e,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Failed to instantiate java array '{0}'[{1}]",name,ja.getDim())); //$NLS-ASTNew.ASTNew.ArrayInstantiateFailed.Exception-1$
                    }
                } else {
                	if(result.getSignal()!=InterpretResult.SIGNAL_NONE) {
                		return false;
                	}
                }
            }else{// if it is not a java array
                if(!memberExpression.interpret(this,context,result)) {
                	return false;
                }
                value=result.getFBSValue();
                
                if (!(value instanceof FBSObject)){
                    throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Cannot instantiate non-object value, {0}",FBSUtility.getDisplayType(value))); //$NLS-ASTNew.ASTNew.NonObjInstantiate.Exception-1$
                }
                FBSObject object=(FBSObject)value;
                if (object.supportConstruct()){
                    FBSValue newObject=object.construct(context,args);
                    result.setNormal(newObject);
                    return true;
                }
                throw new InterpretException(null,ErrorObject.TypeErrorObject.create(context.getJSContext(),"Object does not support instantiation {0}", FBSUtility.getDisplayType(object))); //$NLS-ASTNew.ASTNew.ObjInstantiationNotSupported.Exception-1$
            }
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        if( isJavaArray() ) {
            return FBSType.getType(jsContext,getJavaArrayType());
        }
        String name=""; //$NON-NLS-1$
        if (memberExpression instanceof ASTMember){
            name=getMemberAsString((ASTMember)memberExpression);
        } else if (memberExpression instanceof ASTIdentifier){
            name=((ASTIdentifier)memberExpression).getIdentifierName();
        } else {
            return FBSType.invalidType;
        }
        return FBSType.getType(jsContext,name);
    }


    private JavaArrayClass resolveJavaArray(IExecutionContext context,InterpretResult result) throws JavaScriptException{
        JavaArrayClass javaArray= new JavaArrayClass();
        if(!resolveJavaArray(memberExpression,context,result,javaArray)) {
        	return null;
        }
        return javaArray;
    }
    private boolean resolveJavaArray(ASTNode member, IExecutionContext context,InterpretResult result, ASTNew.JavaArrayClass javaArray) throws JavaScriptException {
        if (member instanceof ASTArrayMember){
            ASTArrayMember arrayMember = (ASTArrayMember)member;
            if(!arrayMember.getRightNode().interpret(this, context, result)) {
            	return false;
            }
            FBSValue rightValue= result.getFBSValue();
            if (!rightValue.isNumber()){
                throw new InterpretException(null,"Index must be numerical value in Java array instantiation"); //$NLS-ASTNew.ASTNew.IndexMustBeNumeric.Exception-1$
            }
            int d=rightValue.intValue();
            javaArray.insertDim(d);

            ASTNode leftNode = arrayMember.getLeftNode();
            if(!resolveJavaArray(leftNode,context,result,javaArray)) {
            	return false;
            }
        } else {
	        // Evaluate the left part.
	        // Not that it should be a JavaAccessObject in order to be instanciable
        	if(member instanceof ASTIdentifier) {
        		String cName = ((ASTIdentifier)member).getIdentifierName();
        		if(cName.equals("char")) { //$NON-NLS-1$
        	        javaArray.setValue(new JavaAccessObject(context.getJSContext(),Character.TYPE,null));
    	    		return true;
        		}
        		if(cName.equals("byte")) { //$NON-NLS-1$
        	        javaArray.setValue(new JavaAccessObject(context.getJSContext(),Byte.TYPE,null));
    	    		return true;
        		}
        		if(cName.equals("short")) { //$NON-NLS-1$
        	        javaArray.setValue(new JavaAccessObject(context.getJSContext(),Short.TYPE,null));
    	    		return true;
        		}
        		if(cName.equals("int")) { //$NON-NLS-1$
        	        javaArray.setValue(new JavaAccessObject(context.getJSContext(),Integer.TYPE,null));
    	    		return true;
        		}
        		if(cName.equals("long")) { //$NON-NLS-1$
        	        javaArray.setValue(new JavaAccessObject(context.getJSContext(),Long.TYPE,null));
    	    		return true;
        		}
        		if(cName.equals("float")) { //$NON-NLS-1$
        	        javaArray.setValue(new JavaAccessObject(context.getJSContext(),Float.TYPE,null));
    	    		return true;
        		}
        		if(cName.equals("double")) { //$NON-NLS-1$
        	        javaArray.setValue(new JavaAccessObject(context.getJSContext(),Double.TYPE,null));
    	    		return true;
        		}
        		if(cName.equals("boolean")) { //$NON-NLS-1$
        	        javaArray.setValue(new JavaAccessObject(context.getJSContext(),Boolean.TYPE,null));
    	    		return true;
        		}
        	}
	    	if(!member.interpret(this,context,result)) {
	    		return false;
	    	}
	        FBSValue value=result.getFBSValue();
	        javaArray.setValue(value);
        }
        return true;
    }

    private String getMemberAsString(ASTMember node) {
        FastStringBuffer buf = new FastStringBuffer();
    	appendMemberString(buf,node);
        // Remove the Packages prefix if needed
        String name = buf.toString();
        if(name.startsWith(JavaPackageObject.PACKAGES_START)) {
        	name = name.substring(JavaPackageObject.PACKAGES_START.length());
        }
        return name;
    }
    static private void appendMemberString(FastStringBuffer buf, ASTMember node) {
        if (node.getLeftNode() instanceof ASTMember){
        	appendMemberString(buf,(ASTMember)node.getLeftNode());
        }else{
            String idn=((ASTIdentifier)node.getLeftNode()).getIdentifierName();
            buf.append(idn);
        }
        buf.append('.');
        buf.append(node.getMemberName());
    }



    // this is an exceptional case.
    // every new expression that ends with [] it is considered as Java Array instantiation
    private boolean isJavaArray(){
        if (memberExpression instanceof ASTArrayMember){
            return true;
        }
        return false;
    }
    private String getJavaArrayType(){
        if (memberExpression instanceof ASTArrayMember){
            StringBuffer b = new StringBuffer();
            doGetJavaArrayType(b,memberExpression);
            return b.toString();
        }
        return null;
    }
    private boolean doGetJavaArrayType(StringBuffer b, ASTNode node){
        if( node instanceof ASTArrayMember ) {
            ASTArrayMember arrayMember = (ASTArrayMember)node;
            if( doGetJavaArrayType(b,arrayMember.getLeftNode()) ) {
                b.append( "[]" ); //$NON-NLS-1$
                return true;
            }
        } else if( node instanceof ASTMember ) {
            ASTMember member = (ASTMember)node;
            if( doGetJavaArrayType(b,member.getLeftNode()) ) {
                b.append( "." ); //$NON-NLS-1$
                b.append( member.getMemberName() );
                return true;
            }
        } else if( node instanceof ASTIdentifier ) {
            b.append( ((ASTIdentifier)node).getIdentifierName() );
            return true;
        }
        return false;
    }

    // Class to hold the temporary Java Array parameters
    private static class JavaArrayClass {
        FBSValue value;
        int[] dim=null;

        public void setValue(FBSValue v){
            this.value=v;
        }

        public String getClassName() throws InterpretException {
        	if( value instanceof JavaAccessObject ) {
        		JavaAccessObject ac = (JavaAccessObject)value;
        		return ac.getClassName();
        	}
            throw new InterpretException(null,"Failed to instantiate Java array. Not a Java class"); //$NLS-ASTNew.ASTNew.NotAClass.Exception-1$
        }

        public void insertDim(int d){
            int l=dim==null?0:dim.length;
            int[] newdim=new int[l+1];
            newdim[0]=d;
            if (l>0){
                System.arraycopy(dim,0,newdim,1,l);
            }
            dim=newdim;
        }

        public int[] getDim(){
            return dim;
        }
    }

    public Object visit(ASTNodeVisitor v, Object param) {
	return v.visitNew(this, param);
    }
}
