/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree.binaryop;

import java.util.ArrayList;

import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.ASTTree.ASTBinaryOp;
import com.ibm.jscript.ASTTree.ASTConstants;
import com.ibm.jscript.ASTTree.ASTNode;
import com.ibm.jscript.ASTTree.ASTNodeVisitor;
import com.ibm.jscript.ASTTree.InterpretResult;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.parser.ParseException;
import com.ibm.jscript.parser.Token;
import com.ibm.jscript.types.FBSValue;

public class ASTBinaryRelOr extends ASTBinaryOp {

    private ASTNode[] optimizedNodes;

    public ASTBinaryRelOr(Token t, ASTNode leftNode, ASTNode rightNode) {
        super(t,leftNode,rightNode);
    }

    public int getOperator() {
        return ASTConstants.REL_OR;
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            // Optimized evaluation
            if(optimizedNodes!=null ) {
                int count = optimizedNodes.length;
                for( int i=0; i<count; i++ ) {
                    if(!optimizedNodes[i].interpret(this, context, result)) {
                    	return false;
                    }
                    FBSValue v = result.getFBSValue();
                    result.setNormal(v);
                    if( v.booleanValue() ) {
                        return true;
                    }
                }
                return true;
            }

            if(!leftNode.interpret(this,context,result)) {
            	return false;
            }
            FBSValue v1 = result.getFBSValue(); 
            // if operator is || and left node is true
            // don't evaluate the right node ,return true
            if(v1.booleanValue()){
                result.setNormal(v1);
                return true;
            }
            
            if(!rightNode.interpret(this,context,result)) {
            	return false;
            }
            FBSValue v2 = result.getFBSValue();
            result.setNormal(v2);
            return true;
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    public void optimize(JSContext context) throws ParseException {
    	if(context.isRuntimeOptimized()) {
	        ArrayList list = new ArrayList(16);
	        listAdd(this,list);
	        if( list.size()>2 ) {
	            this.optimizedNodes = (ASTNode[])list.toArray(new ASTNode[list.size()]);
	            //com.ibm.workplace.designer.util.TDiag.getOutputStream().println( "Add: optimized "+Integer.toString(optimizedNodes.length)+"nodes" );
	        }
    	}
    	super.optimize(context);
    }
    private void listAdd(ASTBinaryRelOr node, ArrayList list) {
        ASTNode n1 = node.getLeftNode();
        if( n1 instanceof ASTBinaryRelOr ) {
            listAdd((ASTBinaryRelOr)n1,list);
        } else {
            list.add(n1);
        }
        ASTNode n2 = node.getRightNode();
        list.add(n2);
    }

    public Object visit(ASTNodeVisitor v, Object param) {
	return v.visitBinaryRelOr(this, param);
    }
}
