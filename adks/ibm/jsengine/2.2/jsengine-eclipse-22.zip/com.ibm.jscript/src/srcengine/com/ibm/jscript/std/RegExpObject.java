/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.std;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import com.ibm.commons.util.io.StreamUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.types.FBSDefaultObject;
import com.ibm.jscript.types.FBSString;
import com.ibm.jscript.types.FBSUtility;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.FBSValueVector;

/**
 * Regular expression object. This class provides the common features to regular expressions
 * such as property management (source, global etc). This class is not expected to be subclassed
 * where various regexp implementations implement the 
 */
public class RegExpObject extends FBSDefaultObject {

    public interface REImplementation {
                
        /**
         * Init the engine. 
         * @throws InterpretException
         */
        public void init() throws InterpretException;
        
        /**
         * Apply the regexp pattern (from the constructor) to <i>str</i>.
         * 
         * @param str The value to apply this regexp pattern to
         * @return A FBSValueVector with the matched elements
         * @throws JavaScriptException
         */
        public ArrayObject exec(JSContext jsContext, String str) throws JavaScriptException;
        
        /**
         * Splits a string based on the regexp from the constructor.
         * 
         * @param str The string to split
         * @return A FBSValueVector with the matched elements
         * @throws JavaScriptException
         */
        public FBSValueVector split(String str, int limit) throws JavaScriptException;
        
        /**
         * Returns true if str matches this regexp
         * @param str
         * @return
         * @throws JavaScriptException
         */
        public ArrayObject match(JSContext jsContext, String str) throws JavaScriptException;

        /**
         * Returns the index of the first regex match in str
         * 
         * @param str The string to search
         * @return
         * @throws JavaScriptException
         */
        public FBSValue search(String str) throws JavaScriptException;
        
        /**
         * Replaces str with replacement using this.jdkRE regexp.
         * 
         * @param str The source string
         * @param replacement The replacement string
         * @return
         * @throws JavaScriptException
         */
        public FBSValue replace(String str, String replacement) throws JavaScriptException;

        public FBSValue replace(IExecutionContext context, String str, FunctionObject f) throws JavaScriptException;
        
        /**
         * Replaces current regex with replacement
         * 
         * @param str The new regex
         * @param flags The new flags
         * @return
         * @throws JavaScriptException
         */
        public void compile(String re, String flags) throws JavaScriptException;
    }
    
    
    /**
     * Local vars - Regular Expression engine.
     */
    private REImplementation engine;
    
    /**
     *  Properties
     */
    protected static final String PROP_REGEX = "source"; //$NON-NLS-1$
    protected static final String PROP_GLOBAL = "global"; //$NON-NLS-1$
    protected static final String PROP_IGNORECASE = "ignoreCase"; //$NON-NLS-1$
    protected static final String PROP_MULTILINE = "multiline"; //$NON-NLS-1$
    protected static final String PROP_LASTINDEX = "lastIndex"; //$NON-NLS-1$
    
    /**
     * Valid RegExp flags
     */
    protected static final String VALID_FLAGS = "mgi"; //$NON-NLS-1$
    
    /**
     * Standard properties
     */
    protected String source;
    protected String flags;
    protected boolean global;
    protected boolean ignoreCase;
    protected boolean multiline;
    protected int lastIndex;

	// Serialization only ctor
	public RegExpObject() {
        super(JSContext.getStaticContext(),JSContext.getStaticContext().getRegistry().regExpPrototype);
    }

	// Internal, for Registry
    public RegExpObject(JSContext jsContext) {
        super(jsContext,jsContext.getRegistry().regExpPrototype);
    }
    
    /**
     * Constructor for RegExpObject - calls RegExpObject(str, "").
     * 
     * @param regExpStr The regular expression
     * @throws InterpretException
     */
    public RegExpObject(JSContext jsContext, String regExpStr) throws InterpretException {
        this(jsContext, regExpStr, ""); //$NON-NLS-1$
    }
    
    /**
     * Constructor for RegExpObject
     * 
     * @param regExpStr The regular expression
     * @param flags Regular expression flags (M, I, G)
     * @throws InterpretException
     */
    public RegExpObject(JSContext jsContext, String regExpStr, String flags) throws InterpretException {
        super(jsContext, jsContext.getRegistry().regExpPrototype);
        
        // Set flag/properties
        setFlags(flags);
        this.source = regExpStr;
        this.engine = new RegExpJDK14(jsContext,this);
        engine.init();
    }
    
    public void setFlags(String flags) throws InterpretException {
        // verify flags
        if(flags!=null) {
            for (int i = 0; i < flags.length(); i++) {
                if (VALID_FLAGS.indexOf(flags.charAt(i))<0 )
                    throw new InterpretException(null,ErrorObject.SyntaxErrorObject.create(getJSContext(),"Invalid regular expression flag {0}", flags.substring(i,i))); // $NLS-RegExpObject.InvalidRegExpflag0-1$
            }
            this.global = (flags.indexOf("g") != -1); //$NON-NLS-1$
            this.ignoreCase = (flags.indexOf("i") != -1); //$NON-NLS-1$
            this.multiline = (flags.indexOf("m") != -1); //$NON-NLS-1$
        }
        this.flags = flags;
    }
    
    
    
    ////// Constructor
//    public boolean supportConstruct(){
//        return true;
//    }
//    public FBSObject construct(IExecutionContext context, FBSValueVector args)throws InterpretException{
//        if (args.size() == 1) {
//            return new RegExpObject(getJSContext(),args.get(0).stringValue());
//        } else if (args.size() == 2) {
//            return new RegExpObject(getJSContext(),args.get(0).stringValue(), args.get(1).stringValue());
//        } else if (args.size() == 0) {
//            return new RegExpObject(getJSContext(),"");
//        }
//        throw new InterpretException("Invalid number of arguments"); //$NLS-RegExpObject.RegExpObject.InvalidNumArgs.Exception-1$
//    }
//    public boolean supportCall() {
//        return true;
//    }
//    public FBSValue call(IExecutionContext context,FBSValueVector args,FBSObject _this) throws JavaScriptException {
//        if(args.getCount()==2) {
//            FBSValue v1 = args.get(0);
//            if( v1.isJavaObject() ) {
//                if( v1.toJavaObject() instanceof RegExpObject ) {
//                    FBSValue v2 = args.get(0);
//                    if(v2.isUndefined()) {
//                        return v1;
//                    }
//                }
//            }
//        }
//        return construct(context,args);
//    }
//    protected String[] getCallParameters() {
//        return new String[] {"(regexp:T)","(regexp:Tmodifiers:T)"}; //$NON-NLS-1$ //$NON-NLS-2$
//    }



    public String getTypeAsString(){
        return "RegExp"; //$NON-NLS-1$
    }

    public String getName(){
        return "RegExp"; //$NON-NLS-1$
    }
        
    public FBSString getFBSString() {
        return FBSString.get(source);
    }
    
    public FBSValue get(String name) throws InterpretException {
        // TODO Auto-generated method stub
        if (name.equals(PROP_REGEX))
            return FBSUtility.wrap(source);
        else if (name.equals(PROP_GLOBAL))
            return FBSUtility.wrap(global);
        else if (name.equals(PROP_IGNORECASE))
            return FBSUtility.wrap(ignoreCase);
        else if (name.equals(PROP_MULTILINE))
            return FBSUtility.wrap(multiline);
        else if (name.equals(PROP_LASTINDEX))
            return FBSUtility.wrap(lastIndex);
        else
            return super.get(name);
    }
    
    
    /* (non-Javadoc)
     * @see com.ibm.jscript.types.FBSObject#put(java.lang.String, com.ibm.jscript.types.FBSValue)
     */
    public void put(String name, FBSValue value) throws InterpretException {
        if(name.equals(PROP_REGEX))
            this.source = value.stringValue();
        else
            super.put(name, value);
    }
    
    /**
     * Apply the regexp pattern (from the constructor) to <i>str</i>.
     * 
     * @param str The value to apply this regexp pattern to
     * @return A FBSValueVector with the matched elements
     * @throws JavaScriptException
     */
    public ArrayObject exec(String str) throws JavaScriptException {
        return engine.exec(getJSContext(),str);
    }
    
    /**
     * Splits a string based on the regexp from the constructor.
     * 
     * @param str The string to split
     * @return A FBSValueVector with the matched elements
     * @throws JavaScriptException
     */
    public FBSValueVector split(String str) throws JavaScriptException {    
        return split(str, 0);
    }
    
    public FBSValueVector split(String str, int limit) throws JavaScriptException { 
        return engine.split(str, limit);
    }
    
    /**
     * Returns true if str matches this regexp
     * @param str
     * @return
     * @throws JavaScriptException
     */
    public ArrayObject match(String str) throws JavaScriptException {
        return engine.match(getJSContext(),str);
    }
    
    /**
     * Returns the index of the first regex match in str
     * 
     * @param str The string to search
     * @return
     * @throws JavaScriptException
     */
    public FBSValue search(String str) throws JavaScriptException {
        return engine.search(str);
    }
    
    /**
     * Replaces str with replacement using this.jdkRE regexp.
     * 
     * @param str The source string
     * @param replacement The replacement string
     * @return
     * @throws JavaScriptException
     */
    public FBSValue replace(String str, String replacement) throws JavaScriptException {
        return engine.replace(str,replacement);
    }

    public FBSValue replace(IExecutionContext context, String str, FunctionObject f) throws JavaScriptException {
        return engine.replace(context,str,f);
    }
   
    /**
     * Replaces this.jdkRE regexp with str
     * 
     * @param str The new regular expression
     * @return
     * @throws JavaScriptException
     */
    public FBSValue compile(String str, String flags) throws JavaScriptException {
        engine.compile(str, flags);
        this.source = str;
        this.flags = flags;
        return FBSUtility.wrap(stringValue());
    }

    /**
     * This is an alias for the match(String str) method.
     * 
     * @param str The string to perform a test match for
     * @return
     * @throws JavaScriptException
     */
    public FBSValue test(String str) throws JavaScriptException {
    	ArrayObject val = engine.match(getJSContext(),str);
        if (val == null || val.getArrayLength() == 0)
            return FBSUtility.wrap(false);
        else
            return FBSUtility.wrap(true);
    }
    
    public String stringValue() {
        return "/" + source + "/" + flags;
    }
    

    // ========================================================================
    // Java Object IO.
    // ========================================================================

    public void readExternal( ObjectInput in ) throws IOException {
        super.readExternal(in);
        source = StreamUtil.readUTF(in);
        flags = StreamUtil.readUTF(in);
        global = in.readBoolean();
        ignoreCase = in.readBoolean();
        multiline = in.readBoolean();
        lastIndex = in.readInt();
    }

    public void writeExternal( ObjectOutput out ) throws IOException {
        super.writeExternal(out);
        StreamUtil.writeUTF(out,source);
        StreamUtil.writeUTF(out,flags);
        out.writeBoolean(global);
        out.writeBoolean(ignoreCase);
        out.writeBoolean(multiline);
        out.writeInt(lastIndex);
    }
}
