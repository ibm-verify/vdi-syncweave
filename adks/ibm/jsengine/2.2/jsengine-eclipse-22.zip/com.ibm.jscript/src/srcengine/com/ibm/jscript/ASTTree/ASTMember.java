/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.ASTTree;

import java.io.PrintStream;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;
import com.ibm.jscript.JavaScriptException;
import com.ibm.jscript.engine.IExecutionContext;
import com.ibm.jscript.parser.ParseException;
import com.ibm.jscript.parser.Token;
import com.ibm.jscript.types.FBSObject;
import com.ibm.jscript.types.FBSReference;
import com.ibm.jscript.types.FBSReferenceByName;
import com.ibm.jscript.types.FBSType;
import com.ibm.jscript.types.FBSValue;
import com.ibm.jscript.types.JavaAccessObject;
import com.ibm.jscript.types.JavaPackageObject;

public class ASTMember extends ASTNode {

    public static final int LEFT=0;
    public static final int RIGHT=1;

    private ASTNode leftNode;
    private String memberName;
    private String optimizedClass;

    public ASTMember(Token t, ASTNode leftNode, String memberName) {
        super(t);
        this.leftNode = assignParent(leftNode);
		// Similarly to the String constants in a class, we intern the strings
        this.memberName = memberName.intern();
    }

    public String getTraceString() {
        return leftNode.getTraceString()+"."+memberName; //$NON-NLS-1$
    }


    public int getSlotCount(){
        return 1;
    }

    public ASTNode readSlotAt(int index){
        switch(index){
            case LEFT:   return leftNode;
            //case RIGHT:  return rightNode;
        }
        return null;
    }

    public ASTNode getLeftNode() {
        return leftNode;
    }

    public String getMemberName() {
        return memberName;
    }

    public FBSType getResultType(JSContext jsContext, FBSType.ISymbolCallback symbolCallback) {
        Class<?> c = getOptimizedJavaClass(jsContext);
        if( c!=null ) {
            return FBSType.getType(jsContext,c.getName());
        }
        FBSType t=leftNode.getResultType(jsContext,symbolCallback);
        if( t.isUndefined() ) {
            return t;
        }
        if( t.isInvalid() ) {
            // TODO...
            if( !(leftNode instanceof ASTIdentifier) ) {
                return t;
            }
            String idn=((ASTIdentifier)leftNode).getIdentifierName();
            t=FBSType.getJavaPackage(idn);
        }
        return t.getMember(jsContext,memberName);
    }

    public boolean interpret(ASTNode caller, IExecutionContext context,InterpretResult result) throws JavaScriptException {
        try {
            if( optimizedClass!=null ) {
                try {
                    FBSObject optimizedObject = new JavaAccessObject(context.getJSContext(),optimizedClass);
                    result.setNormal(optimizedObject);
                    return true;
                } catch(ClassNotFoundException ex) {
                    throw new InterpretException(ex,StringUtil.format("Cannot find java class '{0}'",optimizedClass)); // $NLS-ASTMember.Cannotfindjavaclass0-1$
                }
            } else {
                if(!leftNode.interpret(this,context,result)) {
                	return false;
                }

                FBSValue leftValue;
                try {
                    leftValue = result.getFBSValue();
                } catch(InterpretException e0) {
                	// In case of an exception, then try to see if it is a Java class
                	// the exception is thrown if:
                	//    - the leftmost identifier is not found (ex: com.[...])
                	//    - the result was pointing a package reference itself.
                	// In both cases, we try to see if the wjole chain is an actual identifier that we
                	// save as the "optimized" class name.
                    if( leftNode instanceof ASTIdentifier ) {
                    	// If it is a class, then return it after caching the optimized class name
                    	Class<?> c = getOptimizedJavaClass(context.getJSContext());
                    	if(c!=null) {
                    		optimizedClass = c.getName();
                    		// And return it instantly...
                            FBSObject optimizedObject = new JavaAccessObject(context.getJSContext(),c);
                            result.setNormal(optimizedObject);
                            return true;
                    	}
                    	// Else, assume it is a potential package
                    	String idn=((ASTIdentifier)leftNode).getIdentifierName();
                    	leftValue=JavaPackageObject.getPackage(context.getJSContext(),idn,false);
                    } else if( result.isReference() && result.getReference().getBase().isJavaPackage() ) {
                    	FBSReference ref = result.getReference();
                        leftValue=ref.getBase().get(ref.getPropertyName());
                        // If it is a java class, then cache it if it makes sense
                        if((leftValue instanceof JavaPackageObject)) {
                        	Class<?> c = getOptimizedJavaClass(context.getJSContext());
                        	if(c!=null) {
                        		optimizedClass = c.getName();
                        		// And return it instantly...
                                FBSObject optimizedObject = new JavaAccessObject(context.getJSContext(),c);
                                result.setNormal(optimizedObject);
                                return true;
                        	}
                        }
                    } else {
                        throw e0;
                    }
                }
                if (!leftValue.canFBSObject()) {
                    if( leftValue.isNull() ) {
                        throw new InterpretException(null,"'{0}' is null",leftNode.getTraceString()); //$NLS-ASTMember.ASTMember.LeftValueIsNull.Exception-1$
                    }
                    if( leftValue.isUndefined() ) {
                        throw new InterpretException(null,"'{0}' is undefined",leftNode.getTraceString()); //$NLS-ASTMember.ASTMember.LeftValueIsUndefined.Exception-1$
                    }
                    throw new InterpretException(null,"'{0}' is not an object",leftNode.getTraceString()); //$NLS-ASTMember.ASTMember.LeftValueIsNotAnObj.Exception-1$
                }
                FBSObject leftObject=leftValue.toFBSObject(context.getJSContext());
                FBSReference ref = leftObject.getPropertyReference(memberName);
                if(ref==null) {
                	ref = new FBSReferenceByName(leftObject,memberName);
                }
                result.setNormal(ref);
                return true;
            }
        } catch( InterpretException ie ) {
            throw ie.fillException(context,this);
        }
    }

    protected void extraInfo(PrintStream ps,String indent){
        ps.print("member="); //$NON-NLS-1$
        ps.print(getMemberName());
    }

    private Class<?> getOptimizedJavaClass(JSContext context) {
        // === Java static member access ==================================
        //  Check for a package.javaclass
    	StringBuilder b = getJavaIdentifier(this);
        if( b!=null ) {
            // Check if it is an existing class
            try {
                String className = b.toString();
                if(className.startsWith(JavaPackageObject.PACKAGES_START)) {
                    if( context.hasRhinoExtensions() ) {
                        className = className.substring(JavaPackageObject.PACKAGES_START.length());
                    }
                }
            	
            	// Try to load the class 
            	Class<?> c = context.loadClass(className);
            	if(c!=null) {
            		return c;
            	}
                // If so, create a ready to use JavaAccessObject
                //TDiag.trace( "Found static: '{0}'", className );
            } catch(Throwable e) {}
        }
        return null;
    }
    private static StringBuilder getJavaIdentifier(ASTNode node) {
        if( node instanceof ASTIdentifier ) {
            ASTIdentifier i2= (ASTIdentifier)node;
            StringBuilder buffer = new StringBuilder();
            buffer.append( i2.getIdentifierName() );
            return buffer;
        } else if( node instanceof ASTMember ) {
            ASTMember m2 = (ASTMember)node;
            StringBuilder buffer = getJavaIdentifier( m2.getLeftNode() );
            if( buffer!=null ) {
                buffer.append('.');
                buffer.append(m2.getMemberName());
            }
            return buffer;
        } else {
            return null;
        }
    }
    private static boolean isStaticClassName(ASTNode node) {
        if( node instanceof ASTIdentifier ) {
            return true;
        } else if( node instanceof ASTMember ) {
            ASTMember m2 = (ASTMember)node;
            if(isStaticClassName(m2.getLeftNode())) {
            	return true;
            }
        }
        return false;
    }

    public Object visit(ASTNodeVisitor v, Object param) {
    	return v.visitMember(this, param);
    }
}
