/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import com.ibm.jscript.IValue;


/**
 * Optimized FBSValue vector.
 */
public final class FBSValueVector {

    private static final int INITIAL = 8;
    private static final int DELTA   = 8;

    private int count;
    private FBSValue[] data;

    public static FBSValueVector emptyVector = new FBSValueVector(0);

    private static final FBSValue[] emptyValues = new FBSValue[0];
    
    public FBSValueVector() {
        this.count = 0;
        this.data = new FBSValue[INITIAL];
    }

    public FBSValueVector(int initialCapacity) {
        this.count = 0;
        this.data = initialCapacity>0 ? new FBSValue[initialCapacity] : emptyValues;
    }

    public FBSValueVector(IValue[] v1) {
    	if(v1!=null && v1.length>0) {
            this.count = v1.length;
            this.data = new FBSValue[v1.length];
            for( int i=0; i<v1.length; i++ ) {
            	this.data[i]=(FBSValue)v1[i];
            }
    	} else {
            this.count = 0;
            this.data = emptyValues;
    	}
    }

    public void addElement(FBSValue node) { // For compatibility
        add(node);
    }
    public void add(FBSValue node) {
        if( count==data.length ) {
            growTo(data.length+DELTA);
        }
        data[count++] = node;
    }

    public boolean isUndefined(int index) {
    	if(index<count) {
    		return data[index].isUndefined();
    	}
    	return true;
    }
    
    public FBSValue get(int index) {
        return data[index];
    }

    public FBSValue getFBSValue(int index){
        return data[index];
    }

    public void set(int index, FBSValue node) {
        data[index] = node;
    }

    public void remove(int index) {
        System.arraycopy(data,index+1,data,index,data.length-index-1);
        data[count-1]=null;
        count--;
    }

    public int getCount(){
        return count;
    }

    public int size(){
        return count;
    }

    private void growTo( int size ) {
        FBSValue[] old = data;
        data = new FBSValue[size];
        System.arraycopy(old, 0, data, 0, old.length);
    }
}
