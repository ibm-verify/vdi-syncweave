/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.engine.ExtendedJSContext;
import com.ibm.jscript.parser.ParseException;
import com.ibm.jscript.types.FBSGlobalObject;
import com.ibm.jscript.types.FBSObject;

public final class JSInterpreter extends JavaScriptEngine {

    //-d jscript.test=c:\dde_root\jstest.js
    private static final String PARAM_NAME = "jscript.test"; // $NON-NLS-1$
    
    private FBSGlobalObject globalObject;
    private FBSObject scope;
    private List<String> importedLibraries;
    
    
    public JSInterpreter(JSContext jsContext, FBSObject scope) {
        super(jsContext);
        this.scope = scope;
        this.globalObject = new FBSGlobalObject(jsContext);
    }

    public JSInterpreter(JSContext jsContext) {
        this(jsContext,null);
    }

    public FBSGlobalObject getGlobalObject() {
        return globalObject;
    }
    
    public IValue interpret( JSExpression expression, boolean registerFunctions ) throws InterpretException {
        return expression.evaluateValue(globalObject,scope,importedLibraries);
    }

    public IValue interpret( JSExpression expression ) throws InterpretException {
        return interpret(expression,false);
    }
    
    public IValue interpret( String expression, boolean registerFunctions ) throws InterpretException, ParseException {
        JSExpression e = getJSContext().getExpression(expression);
        return interpret(e,registerFunctions);
    }

    public IValue interpret( String expression ) throws InterpretException, ParseException {
        return interpret(expression,false);
    }

    public IValue interpret( File jsFile, boolean registerFunctions ) throws InterpretException, ParseException {
        String s = readFile(jsFile);
        return interpret(s,registerFunctions);
    }

    public IValue interpret( File jsFile ) throws InterpretException, ParseException {
        return interpret(jsFile,false);
    }

    public static String readFile( File jsFile ) throws InterpretException, ParseException {
        if(!jsFile.exists()) {
            throw new InterpretException(null,"File: "+jsFile+" does not exist"); //$NON-NLS-1$ //$NON-NLS-2$
        }
        StringBuilder b = new StringBuilder();
        char[] c = new char[2048];
        try {
            Reader r = new FileReader(jsFile);
            try {
                int len;
                while((len=r.read(c))>0) {
                    b.append(c,0,len);
                }
                return b.toString();
            } finally {
                r.close();
            }
        } catch(IOException ex) {
            throw new InterpretException(ex,"IO Error while reading file: "+jsFile); //$NON-NLS-1$
        }
    }

    public IValue callFunction(String functionName, IValue[] args) throws InterpretException, ParseException {
        JSExpression e = getJSContext().getExpression(""); //$NON-NLS-1$
        return e.callFunction(scope,functionName,args);
    }
    
    public IValue callFunction(String functionName) throws InterpretException, ParseException {
        return callFunction(functionName,null);
    }
    
    // Simple test
    public static void main(String[] args) {
        boolean interactive = false;
        ArrayList <String> fileNames = new ArrayList <String> ();
        for( int i=0; i<args.length; i++ ) {
            if(args[i].equals("-f")) { //$NON-NLS-1$
                i++;
                if( i<args.length ) {
                    fileNames.add(args[i]);
                }
            } else if(args[i].equals("-i")) { // $NON-NLS-1$
                interactive = true;
            }
        }
        if(fileNames.size()==0) {
            interactive = true;
        }
        
        System.out.println("JavaScript Interpreter"); //$NON-NLS-1$
        
        // Initialize extended options
        JSContext ctx = new ExtendedJSContext(false);

        JSInterpreter jsInterpreter = new JSInterpreter(ctx);
        
        // Read the files
        for( int i=0; i<fileNames.size(); i++ ) {
            String fn = (String)fileNames.get(i);
            loadFile(jsInterpreter, fn);
        }

        if( interactive ) {
            System.out.println("Enter 'quit' to leave"); //$NON-NLS-1$
            System.out.println("Enter 'load [<file path>]' to load an external file, the name is optional"); //$NON-NLS-1$
            
            BufferedReader bufReader= new BufferedReader(new InputStreamReader(System.in));
            try {
                do {
                    String line = bufReader.readLine();   // Read one line from the console.
                    if(line.equals("quit")) { //$NON-NLS-1$
                        break;
                    }
                    if(line.equals("load") || line.startsWith("load ")) { //$NON-NLS-1$ $NON-NLS-2$
                        String fileName = line.substring(4).trim();
                        if(StringUtil.isEmpty(fileName)) {
                            fileName = System.getProperty(PARAM_NAME);
                            if(StringUtil.isEmpty(fileName)) {
                                System.out.println("Empty file name - no "+PARAM_NAME+" vm argument defined for the default file name"); //$NON-NLS-1$ $NON-NLS-2$
                                continue;
                            }
                        }
                        loadFile(jsInterpreter, fileName);
                        continue;
                    }
                    try {
                        IValue v = jsInterpreter.interpret(line);
                        System.out.println("=" + v.toString()); //$NON-NLS-1$
                    } catch( Exception e ) {
                        if(e instanceof ParseException) {
                            ParserResult sc = ctx.parseScript(line,true);
                            sc.dumpErrors(System.out);
                        } else {
                            System.out.println("!Runtime Error: "+e.getMessage()); //$NON-NLS-1$
                        }
                    }
                } while(true);
            } catch( IOException ex ) {
                ex.printStackTrace();
            }
            System.exit(0);
        }
    }
    
    private static void loadFile(JSInterpreter jsInterpreter, String fileName) {
        System.out.println(">> Loading file: "+fileName); //$NON-NLS-1$
        try {
            IValue v = jsInterpreter.interpret(new File(fileName),true);
            System.out.println("=" + v.toString()); //$NON-NLS-1$
        } catch( Exception e ) {
            System.out.println("!Runtime Error: "+e.getMessage()); //$NON-NLS-1$
        }
    }
}