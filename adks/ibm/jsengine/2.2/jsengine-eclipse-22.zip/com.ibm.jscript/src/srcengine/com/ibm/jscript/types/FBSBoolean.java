/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import com.ibm.commons.util.StringUtil;
import com.ibm.jscript.InterpretException;
import com.ibm.jscript.JSContext;

public final class FBSBoolean extends FBSValue {

    public static final FBSBoolean TRUE=new FBSBoolean(true);
    public static final FBSBoolean FALSE=new FBSBoolean(false);

    private boolean value;

    public static final FBSBoolean get(boolean b) {
        return b ? TRUE: FALSE;
    }

    public static final FBSBoolean get(String s) {
        return get(StringUtil.equals(s,"true")); // $NON-NLS-1$
    }

    private FBSBoolean() {
    }

    public boolean isList() {
        return false;
    }

    private FBSBoolean(boolean v) {
        this.value=v;
    }

    public int getType(){
        return BOOLEAN_TYPE;
    }
    
    public boolean isBoolean() {
        return true;
    }

    public FBSType getFBSType(JSContext context) {
        return FBSType.booleanType;
    }

    public boolean isJavaAssignableTo(Class c) {
        return c==Boolean.TYPE || c==Boolean.class || c==Object.class;
    }

    public String stringValue(){
        return stringValue(value);
    }
    public static final String stringValue(boolean value){
        return value?"true":"false"; // $NON-NLS-1$ $NON-NLS-2$
    }

    public double numberValue(){
        return numberValue(value);
    }
    public static double numberValue(boolean value){
        return value?1:0;
    }

    public boolean booleanValue(){
        return value;
    }

    public FBSValue toFBSPrimitive(){
        return this;
    }

    public FBSBoolean toFBSBoolean(){
        return new FBSBoolean(value);
    }

    public FBSNumber toFBSNumber(){
        return FBSNumber.get(value?1:0);
    }
    public FBSString toFBSString(){
        return FBSString.get(stringValue());
    }

    public String getTypeAsString(){
        return "boolean"; // $NON-NLS-1$
    }

    public String toString(){
        return "FBSBoolean : "+value; // $NON-NLS-1$
    }

    public FBSObject toFBSObject(JSContext jsContext){
        try{
            return new com.ibm.jscript.std.BooleanObject(jsContext,this);
        }catch(Exception e){
            com.ibm.commons.util.TDiag.exception(e);
        }
        return null;
    }

    public Object toJavaObject(Class _class) throws InterpretException{
        if (_class==null || _class==Boolean.TYPE || _class==Boolean.class || _class==Object.class){
            return Boolean.valueOf(value);
        }
        if (_class==String.class) {
            return stringValue();
        }
        throw new InterpretException(null,"Cannot convert FBSBoolean to {0}",_class.getName()); // $NLS-FBSBoolean.cantconvertFBSBooleanto0-1$
    }

    public boolean isJavaNative(){
        return false;
    }
}
