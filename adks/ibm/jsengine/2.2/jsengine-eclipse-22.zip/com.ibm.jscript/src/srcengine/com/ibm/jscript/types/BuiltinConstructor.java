/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.jscript.types;

import com.ibm.jscript.JSContext;

public abstract class BuiltinConstructor extends BuiltinFunction {

	private String globalName;
	
    protected BuiltinConstructor(JSContext jsContext, FBSDefaultObject prototype, String globalName) {
        super(jsContext,prototype);
        this.globalName = globalName;
    }
    
    public String getGlobalName() {
    	return globalName;
    }

}
