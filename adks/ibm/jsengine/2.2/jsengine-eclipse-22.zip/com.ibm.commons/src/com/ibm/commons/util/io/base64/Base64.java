/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2009                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io.base64;

import java.io.IOException;

/**
 * Encodes and decodes to and from Base64 notation.
 *
 */
public class Base64 {

	/**
	 * Decode a base64 string to an ascii string.
	 * @param base64str the string to decode
	 * @return
	 */
    public static String decode(String base64str) {
    	try {
    		StringInputStream bais = new StringInputStream(base64str);
	        Base64.InputStream b64 = new Base64.InputStream(bais);
	        StringBuffer buf = new StringBuffer();
	        int byt;
	        while( (byt = b64.read()) >= 0)  {
	            buf.append((char) byt);
	        }
	        return buf.toString();
    	} catch(IOException ex) {
    		ex.printStackTrace();
    		return null;
    	}
    }
    
    /**
     * Encode a string to base64. 
     * @param str the string to encode
     * @return
     */
    public static String encode(String str) {
    	try {
    		StringBufferOutputStream baos = new StringBufferOutputStream(str.length()*3/2);
	        Base64.OutputStream b64 = new Base64.OutputStream(baos);

	        int len = str.length();
    		for( int i=0; i<len; i++) {
    			int c = ((int)str.charAt(i)) & 0x00FF;
    			b64.write(c);
    		}
	        b64.flushBuffer();

	        return baos.buffer.toString();
    	} catch(IOException ex) {
    		ex.printStackTrace();
    		return null;
    	}
    }

    private static class StringInputStream extends java.io.InputStream {

    	private String str;
    	private int ptr;
    	
    	StringInputStream(String str) {
    		this.str = str;
    	}

        public int read() throws IOException {
        	if(ptr<str.length()) {
        		return str.charAt(ptr++);
        	}
        	return -1;
        }
    }
    
    private static class StringBufferOutputStream extends java.io.OutputStream {
    	StringBuffer buffer;
    	StringBufferOutputStream(int size) {
    		this.buffer = new StringBuffer(size);
    	}
        public void write(int b) throws IOException {
        	buffer.append((char)b);
        }
    }
    
    
	
    public static class OutputStream extends Base64OutputStream {
        public OutputStream( java.io.OutputStream out ) {
        	super(out);
        }
        public void flushBuffer() throws IOException {
        	flush();
        }
    }
	
    public static class InputStream extends Base64InputStream {
        public InputStream( java.io.InputStream in ) {
        	super(in);
        }
    }
}
