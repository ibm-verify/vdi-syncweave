/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

import java.util.Iterator;

/**
 * Iterator wrapper.
 */
public abstract class IteratorWrapper implements Iterator {

    private Iterator it;

    public IteratorWrapper( Iterator it ) {
        this.it = it;
    }

    public boolean hasNext() {
        return it.hasNext();
    }

    public Object next() {
        Object o = it.next();
        return o!=null ? wrap(o) : null;
    }

    public void remove() {
        it.remove();
    }

    protected abstract Object wrap( Object o );
}
