/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2009                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

/*
 * Created on: Oct 12, 2005
 */

package com.ibm.commons.util.io;


import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;

/**
 * Utilties for working with streams
 */
public class StreamUtil {

    /**
     * Private constructor
     */
    private StreamUtil() {}

    /**
     * Call close on an output stream and ignore any exception.
     * @param s the stream to call .close() on
     * @return OuputStream null
     */
    public static OutputStream close(OutputStream s) {
        if (s!=null) {
            try {
                s.close();
            }
            catch (IOException ioe) {
                /** ignore */
            }
        }
        return null;
    }

    /**
     * Call close on an input stream and ignore any exception.
     * @param s the stream to call .close() on
     * @return InputStream null
     */
    public static InputStream close(InputStream s) {
        if (s!=null) {
            try {
                s.close();
            }
            catch (IOException ioe) {
                /** ignore */
            }
        }
        return null;
    }

    /**
     * Call close on a Writer and ignore any exception.
     * @param s the Writer to call .close() on
     * @return Writer null
     */
    public static Writer close(Writer w) {
        if (w!=null) {
            try {
                w.close();
            }
            catch (IOException ioe) {
                /** ignore */
            }
        }
        return null;
    }

    /**
     * Call close on a Reader and ignore any exception.
     * @param s the Reader to call .close() on
     * @return Reader null
     */
    public static Reader close(Reader r) {
        if (r!=null) {
            try {
                r.close();
            }
            catch (IOException ioe) {
                /** ignore */
            }
        }
        return null;
    }

    /**
     * Copy contents of one stream onto another
     * @param is input stream
     * @param os output stream
     */
    public static long copyStream(InputStream is, OutputStream os) throws IOException {
        return copyStream(is, os, 8192);
    }

    /**
     * Copy contents of one stream onto another
     * @param is input stream
     * @param os output stream
     * @param bufferSize size of buffer to use for copy
     * 
     * Note: there are cases where InputStream.available() returns > 0 but in
     * actual fact the stream won't be able to read anything, so we need to
     * handle the fact that InputStream.read() may return -1
     */
    public static long copyStream(InputStream is, OutputStream os, int bufferSize) throws IOException {
		byte[] buffer = new byte[bufferSize];
		long totalBytes = 0;
		int readBytes;
		while( (readBytes = is.read(buffer))>0 ) {
			os.write(buffer, 0, readBytes);
			totalBytes += readBytes;
		}
		return totalBytes;
    }

    /**
     * Copy contents of one stream onto another
     * @param is input stream
     * @param os output stream
     */
    public static long copyStream(Reader is, Writer os) throws IOException {
        return copyStream(is, os, 8192);
    }
    
    /**
     * Copy contents of one character stream onto another
     * @param is input stream
     * @param os output stream
     * @param bufferSize size of buffer to use for copy
     * 
     * Note: there are cases where InputStream.available() returns > 0 but in
     * actual fact the stream won't be able to read anything, so we need to
     * handle the fact that InputStream.read() may return -1
     */
    public static long copyStream(Reader is, Writer os, int bufferSize) throws IOException {
		char[] buffer = new char[bufferSize];
		long totalBytes = 0;
		int readBytes;
		while( (readBytes = is.read(buffer))>0 ) {
			os.write(buffer, 0, readBytes);
			totalBytes += readBytes;
		}
		return totalBytes;
    }
    
    /**
     * Read a UTF string as written by writeUTF.
     * This handles the null strings
     */
    public static String readUTF(ObjectInput in) throws IOException {
    	boolean isnull = in.readBoolean();
    	return isnull ? null : in.readUTF();
    }
    
    /**
     * Writes a UTF string to be read by readUTF().
     * This handles the null strings
     */
    public static void writeUTF(ObjectOutput out, String s) throws IOException {
    	if(s==null) {
    		out.writeBoolean(true);
    	} else {
    		out.writeBoolean(false);
    		out.writeUTF(s);
    	}
    }
}
