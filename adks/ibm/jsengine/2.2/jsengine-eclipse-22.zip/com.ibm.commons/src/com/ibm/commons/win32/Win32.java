/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.win32;

import com.ibm.commons.util.TDiag;
import com.ibm.commons.util.TSystem;

/**
 * Set of Win32 functions.
 * This class also loads the native library for all the other classes.
 */
public class Win32 {

    /**
     * Load the native DLL
     */
    private static final int DLL_VERSION = 1;
    private static boolean initialized = false;
    static {
        try {
            if( !TSystem.isWindows() ) {
                TDiag.trace( "Cannot load a Windows DLL on non Windows platform" ); // $NON-NLS-1$
                TDiag.trace( "Windows specific functions won't be available!" ); // $NON-NLS-1$
            } else {
                String name="lwpdwin32"; // $NON-NLS-1$
                TSystem.loadWindowsDLL(name, DLL_VERSION, "/com/ibm/commons/win32/Win32.dll"); // $NON-NLS-1$
                initialized=true;
            }
        } catch( Throwable e ) {
            TDiag.exception(e);
            TDiag.trace( "Cannot load Win32.dll ({0})" ); // $NON-NLS-1$
            TDiag.trace( "Windows specific functions won't be available!" ); // $NON-NLS-1$
        }
    }

    // Dummy fct called to initialize the library.
    // Things are actually done in the static class initializer
    public static boolean initLibrary() {
        return initialized;
    }
    public static void checkInitialized() {
        if( !initialized ) {
            throw new IllegalStateException("Cannot call a Windows specific function"); // $NON-NLS-1$
        }
    }


    // ========================================================================
    // Win32 constants
    // ========================================================================

    /*
     * ShowWindow() Commands
     */
    public static final int SW_HIDE             =0;
    public static final int SW_SHOWNORMAL       =1;
    public static final int SW_NORMAL           =1;
    public static final int SW_SHOWMINIMIZED    =2;
    public static final int SW_SHOWMAXIMIZED    =3;
    public static final int SW_MAXIMIZE         =3;
    public static final int SW_SHOWNOACTIVATE   =4;
    public static final int SW_SHOW             =5;
    public static final int SW_MINIMIZE         =6;
    public static final int SW_SHOWMINNOACTIVE  =7;
    public static final int SW_SHOWNA           =8;
    public static final int SW_RESTORE          =9;
    public static final int SW_SHOWDEFAULT      =10;
    public static final int SW_FORCEMINIMIZE    =11;
    public static final int SW_MAX              =11;


    // ========================================================================
    // Win32 functions with JNI wrappers
    // ========================================================================
    /**
        ShellExecute Function.
        Performs an operation on a specified file.
        C Syntax:
        HINSTANCE ShellExecute(
            HWND hwnd,
            LPCTSTR lpOperation,
            LPCTSTR lpFile,
            LPCTSTR lpParameters,
            LPCTSTR lpDirectory,
            INT nShowCmd
        );

     @param hWnd
        Handle to a parent window. This window receives any message boxes that an application produces, such as error reporting.

     @param operation
        Pointer to a null-terminated string, referred to in this case as a verb, that specifies the action to be performed. The set of available verbs depends on the particular file or folder. Generally, the actions available from an object's shortcut menu are available verbs. For more information about verbs and their availability, see Object Verbs. See Extending Shortcut Menus for further discussion of shortcut menus. The following verbs are commonly used.
            edit
                Launches an editor and opens the document for editing. If lpFile is not a document file, the function will fail.
            explore
                Explores the folder specified by lpFile.
            find
                Initiates a search starting from the specified directory.
            open
                Opens the file specified by the lpFile parameter. The file can be an executable file, a document file, or a folder.
            print
                Prints the document file specified by lpFile. If lpFile is not a document file, the function will fail.
            NULL
                For systems prior to Microsoft Windows 2000, the default verb is used if it is valid and available in the registry. If not, the "open" verb is used. // $NON-NLS-1$

            For Windows 2000 and later systems, the default verb is used if available. If not, the "open" verb is used. If neither verb is available, the system uses the first verb listed in the registry. // $NON-NLS-1$

     @param file
        Pointer to a null-terminated string that specifies the file or object on which to execute the specified verb. To specify a Shell namespace object, pass the fully qualified parse name. Note that not all verbs are supported on all objects. For example, not all document types support the "print" verb. // $NON-NLS-1$

     @param parameters
        If the lpFile parameter specifies an executable file, lpParameters is a pointer to a null-terminated string that specifies the parameters to be passed to the application. The format of this string is determined by the verb that is to be invoked. If lpFile specifies a document file, lpParameters should be NULL.

     @param Directory
        Pointer to a null-terminated string that specifies the default directory.

     @param showCmd
        Flags that specify how an application is to be displayed when it is opened. If lpFile specifies a document file, the flag is simply passed to the associated application. It is up to the application to decide how to handle it.
            SW_HIDE
                Hides the window and activates another window.
            SW_MAXIMIZE
                Maximizes the specified window.
            SW_MINIMIZE
                Minimizes the specified window and activates the next top-level window in the z-order.
            SW_RESTORE
                Activates and displays the window. If the window is minimized or maximized, Windows restores it to its original size and position. An application should specify this flag when restoring a minimized window.
            SW_SHOW
                Activates the window and displays it in its current size and position.
            SW_SHOWDEFAULT
                Sets the show state based on the SW_ flag specified in the STARTUPINFO structure passed to the CreateProcess function by the program that started the application. An application should call ShowWindow with this flag to set the initial show state of its main window.
            SW_SHOWMAXIMIZED
                Activates the window and displays it as a maximized window.
            SW_SHOWMINIMIZED
                Activates the window and displays it as a minimized window.
            SW_SHOWMINNOACTIVE
                Displays the window as a minimized window. The active window remains active.
            SW_SHOWNA
                Displays the window in its current state. The active window remains active.
            SW_SHOWNOACTIVATE
                Displays a window in its most recent size and position. The active window remains active.
            SW_SHOWNORMAL
                Activates and displays a window. If the window is minimized or maximized, Windows restores it to its original size and position. An application should specify this flag when displaying the window for the first time.

     @return
        Returns a value greater than 32 if successful, or an error value that is less than or equal to 32 otherwise. The following table lists the error values. The return value is cast as an HINSTANCE for backward compatibility with 16-bit Windows applications. It is not a true HINSTANCE, however. The only thing that can be done with the returned HINSTANCE is to cast it to an int and compare it with the value 32 or one of the error codes below.
            0 The operating system is out of memory or resources.
            ERROR_FILE_NOT_FOUND The specified file was not found.
            ERROR_PATH_NOT_FOUND The specified path was not found.
            ERROR_BAD_FORMAT The .exe file is invalid (non-Microsoft Win32.exe or error in .exe image).
            SE_ERR_ACCESSDENIED The operating system denied access to the specified file.
            SE_ERR_ASSOCINCOMPLETE The file name association is incomplete or invalid.
            SE_ERR_DDEBUSY The Dynamic Data Exchange (DDE) transaction could not be completed because other DDE transactions were being processed.
            SE_ERR_DDEFAIL The DDE transaction failed.
            SE_ERR_DDETIMEOUT The DDE transaction could not be completed because the request timed out.
            SE_ERR_DLLNOTFOUND The specified dynamic-link library (DLL) was not found.
            SE_ERR_FNF The specified file was not found.
            SE_ERR_NOASSOC There is no application associated with the given file name extension. This error will also be returned if you attempt to print a file that is not printable.
            SE_ERR_OOM There was not enough memory to complete the operation.
            SE_ERR_PNF The specified path was not found.
            SE_ERR_SHARE A sharing violation occurred.
     */
    public static int ShellExecute(int hWnd, String operation, String file, String parameters, String directory, int showCmd ) {
        checkInitialized();
        return NShellExecute(hWnd, operation, file, parameters, directory, showCmd);
    }
    private static native int NShellExecute(int hWnd, String operation, String file, String parameters, String directory, int showCmd );


    public static void main( String[] args ) {
        try {
            Win32.ShellExecute(0, "Open", "c:\\myfile.xls", "", "", Win32.SW_SHOWNORMAL); // $NON-NLS-1$ $NON-NLS-2$
        } catch(Throwable th) {
            TDiag.exception(th);
        }
    }
}
