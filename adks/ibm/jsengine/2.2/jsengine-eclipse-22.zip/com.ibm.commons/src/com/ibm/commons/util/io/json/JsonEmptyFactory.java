/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2009                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io.json;

import java.util.Iterator;
import java.util.List;

import com.ibm.commons.util.EmptyIterator;



/**
 * This factory is used to test if a string is a valid JSON string.
 * <p>No actual object is created by this factory.</p>
 * 
 * @ibm-api
 */
public class JsonEmptyFactory implements JsonFactory {
	
	public static final JsonEmptyFactory instance = new JsonEmptyFactory();
	
	public Object createNull() {
		return null;
	}
	
	public Object createString(String value) {
		return null;
	}
	
	public Object createNumber(double value) {
		return null;
	}
	
	public Object createBoolean(boolean value) {
		return null;
	}

	public Object createObject(Object parent, String propertyName) {
		return null;
	}
	
	public Object createArray(Object parent, String propertyName, List<Object> values) {
		return null;
	}
	
	public void setProperty(Object parent, String propertyName, Object value) {
	}
	
	public Object getProperty(Object parent, String propertyName) throws JsonException {
		return null;
	}
	
	// Not used...
	public boolean isNull(Object value) throws JsonException {
		return false;
	}	
	public boolean isString(Object value) throws JsonException {
		return false;
	}
	public String getString(Object value) throws JsonException {
		return null;
	}
	public boolean isNumber(Object value) throws JsonException {
		return false;
	}
	public double getNumber(Object value) throws JsonException {
		return 0;
	}
	public boolean isBoolean(Object value) throws JsonException {
		return false;
	}
	public boolean getBoolean(Object value) throws JsonException {
		return false;
	}
	public boolean isObject(Object value) throws JsonException {
		return false;
	}
	@SuppressWarnings("unchecked") //$NON-NLS-1$
	public Iterator<String> iterateObjectProperties(Object object) throws JsonException {
		return EmptyIterator.getInstance();
	}
	public boolean isArray(Object value) throws JsonException {
		return false;
	}
	@SuppressWarnings("unchecked") //$NON-NLS-1$
	public Iterator<Object> iterateArrayValues(Object array) throws JsonException {
		return EmptyIterator.getInstance();
	}	
}
