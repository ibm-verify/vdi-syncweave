/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io;

import java.io.IOException;
import java.io.OutputStream;


public class NullOutputStream extends OutputStream {

    // An OutputStream that writes nothing

    public NullOutputStream() {
    }
    public void write(byte b[], int off, int len) throws IOException {
    }
    public void write(byte b[]) throws IOException {
    }
    public void write(int b) throws java.io.IOException {
    }
}
