/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;


/**
 * Search using the dichotomy algorithm.
 */
public abstract class DichotomySearch {

    protected abstract int getCount();
    protected abstract int compareIndexWithValue(int idx);

    public int search(boolean exactSearch) {
        int low = 0;
        int high = getCount()-1;
        while (low <= high) {
            int mid =(low + high)/2;
            int cmp = compareIndexWithValue(mid);
            if (cmp < 0) {
                low = mid + 1;
            } else if (cmp > 0) {
                high = mid - 1;
            } else {
                return mid; // key found
            }
        }
        return exactSearch
                    ? -1
                    : (low<getCount() ? low : getCount());
    }

    /**
     *
     */
    public static abstract class StringSearch extends DichotomySearch {
        public StringSearch( boolean ignoreCase ) {
            this.ignoreCase = ignoreCase;
        }
        protected int compareIndexWithValue(int idx) {
            if( ignoreCase ) {
                return getString(idx).compareToIgnoreCase(value);
            } else {
                return getString(idx).compareTo(value);
            }
        }
        public int search(String value, boolean exactSearch) {
            this.value = value;
            return search(exactSearch);
        }
        public boolean contains(String value) {
            return search(value,true)>=0;
        }

        protected abstract String getString( int idx );
        private String value;
        private boolean ignoreCase;
    }
    public static class StringArraySearch extends StringSearch {
        public StringArraySearch( String[] array, boolean ignoreCase ) {
            super(ignoreCase);
            this.array = array;
        }
        public int getCount() {
            return array.length;
        }
        protected String getString( int idx ) {
            return array[idx];
        }
        public String[] getArray() {
        	return array;
        }
        private String array[];
    }
}
