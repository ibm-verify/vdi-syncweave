/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.extension;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtensionRegistry;

import com.ibm.commons.Platform;
import com.ibm.commons.log.CommonsLogger;
import com.ibm.commons.util.StringUtil;
import com.ibm.commons.util.TDiag;
import com.ibm.commons.util.io.StreamUtil;


/**
 * Designer runtime initialization code.
 */
public class ExtensionManager {

	private static final boolean USE_CACHE = true;
	private static final HashMap<String, List<Object>> services = USE_CACHE ? new HashMap<String, List<Object>>() : null;

	private static Provider provider;
	static {
		try {
			if(Platform.getInstance().isEclipseBased()) {
				provider = new EclipseProvider();
			} else {
				provider = new JavaServiceProvider();
			}
		} catch(Throwable t) {
			t.printStackTrace();
		}
	}
	
	/**
	 * Find the available implementation of a service.
	 * This implementation looks in the shared class loader only. As the shared libraries are
	 * not willing to change, those services are cached.
	 * @param serviceType
	 * @return
	 */
	public static List<Object> findServices(String serviceType) {
		if(USE_CACHE) {
			List<Object> l = services.get(serviceType);
			if(l!=null) {
				return l;
			}
		}
    	ClassLoader loader = ExtensionManager.class.getClassLoader();
    	List<Object> list = loadServices(loader,serviceType);
    	if(USE_CACHE) {
			services.put(serviceType,list);
		}
    	return list;
	}
	
	/**
	 * Find the available implementation of a service for a particular Application.
	 * @param loader
	 * @param serviceType
	 * @return
	 */
	public static List<Object> findApplicationServices(ClassLoader loader, String serviceType) {
		//TODO: find how to implement that in case of a plug-in! 
    	return loadServices(loader,serviceType);
	}

	/**
	 * Load the available implementation of a service for a particular class loader.
	 */
	private static List<Object> loadServices(ClassLoader loader, String serviceType) {
		List<Object> list = new ArrayList<Object>();
		provider.findInitializer(loader, list, serviceType);
		return list;
	}

	private interface Provider {
    	public void findInitializer(ClassLoader loader, List<Object> initializers, String serviceType);
    }
    private static class EclipseProvider implements Provider {
    	public void findInitializer(ClassLoader loader, List<Object> initializers, String serviceType) {
        	// TODO: find a way to only load the private services
            try {
                // Look if someone implemented an extension point to retrieve the platform
                IExtensionRegistry reg = org.eclipse.core.runtime.Platform.getExtensionRegistry();
                if (reg != null) {
                    IConfigurationElement[] elt = reg.getConfigurationElementsFor("com.ibm.commons.Extension"); // $NON-NLS-1$
                    for( int i=0; i<elt.length; i++ ) {
                        if( "service".equalsIgnoreCase(elt[i].getName()) ) { // $NON-NLS-1$
                        	String type = elt[i].getAttribute("type"); //$NON-NLS-1$
                        	if(StringUtil.equals(type, serviceType)) {
    	                        try {
    	                            Object o = elt[i].createExecutableExtension("class"); // $NON-NLS-1$
    	                            initializers.add(o);
    	                        } catch(Throwable ex) {
    	                            logCouldNotCreateContribution(ex, elt[i], type);
    	                        }
                        	}
                        }
                    }
                }
            } catch( Throwable t ) {
                t.printStackTrace();
            }
    	}
        private void logCouldNotCreateContribution(Throwable ex,
                IConfigurationElement ext, String type) {
            if( CommonsLogger.STANDARD.isWarnEnabled() ){
                String extensionPointId = "com.ibm.commons.Extension"; //$NON-NLS-1$
                String className = ext.getAttribute("class"); //$NON-NLS-1$
                String warnMsg = "Could not create an instance of {0}, contributed to the extension point {1} with type {2}."; // $NLW-ExtensionManager.Couldnotcreateaninstanceof0contri-1$
                CommonsLogger.STANDARD.warnp(this, "logCouldNotCreateContribution", ex, warnMsg, //$NON-NLS-1$
                        className, extensionPointId, type);
            }
        }
    }
    private static class JavaServiceProvider implements Provider {
    	public void findInitializer(ClassLoader loader, List<Object> initializers, String serviceType) {
            try {
            	//PHIL: JDK 1.6 is providing a class to do that: java.util.ServiceLoader. Might
            	// use that later
            	
            	// Look for all the resources in the class path
                final String PREFIX = "META-INF/services/"; //$NON-NLS-1$
            	for( Enumeration<URL> e=loader.getResources(PREFIX+serviceType); e.hasMoreElements(); ) {
            		URL url = e.nextElement();
            		parseResource(loader,initializers,url, serviceType);
            	}
            	
            } catch( Throwable t ) {
                t.printStackTrace();
            }
    	}
        private void parseResource(ClassLoader loader, List<Object> initializers, URL url, String serviceType) throws IOException {
        	BufferedReader r = new BufferedReader(new InputStreamReader(url.openStream(), "utf-8")); //$NON-NLS-1$
        	try {
        		while(true) {
        			String s = r.readLine();
        			if(s==null) {
        				return;
        			}
        			int comment = s.indexOf('#');
        			if(comment>=0) {
        				s = s.substring(0,comment);
        			}
        			s = s.trim();
        			
        			// Try to load the class
        			if(StringUtil.isNotEmpty(s)) {
	        			try {
	        				Class<?> c = loader.loadClass(s);
	        				Object o = c.newInstance();
	        				initializers.add(o);
	        			} catch(Throwable ex) {
	        			    logCouldNotCreateService(ex, s, serviceType);
	        				TDiag.trace("Designer runtime: Error while parsing service file {0}", url.toString()); //$NON-NLS-1$
	        			}
        			}
        		}
        	} finally {
                StreamUtil.close(r);
        	}
        }
        private void logCouldNotCreateService(Throwable ex,
                String className, String serviceType) {
            if( CommonsLogger.STANDARD.isWarnEnabled() ){
                String warnMsg = "Could not create an instance of {0}, contributed to the service {1}."; // $NLW-ExtensionManager.Couldnotcreateaninstanceof0contri.1-1$
                CommonsLogger.STANDARD.warnp(this, "logCouldNotCreateService", ex, warnMsg, //$NON-NLS-1$
                        className, serviceType);
            }
        }
    }
    
}
