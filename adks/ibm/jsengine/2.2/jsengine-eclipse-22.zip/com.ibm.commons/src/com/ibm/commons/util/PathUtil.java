/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;



/**
 * Some utilities for path handling.
 * @author priand
 * @designer.public
 */
public final class PathUtil {
	
    /**
     * Add to path ensuring that the resulting path will start with a '/' and
     * doesn't end with a '/'.
     */
    public static String concatPath(String path1, String path2, char sep) {
    	StringBuilder b = new StringBuilder();
    	if(StringUtil.isNotEmpty(path1)) {
	    	if(path1.charAt(0)!=sep) {
	    		b.append(sep);
	    	}
	    	if(path1.charAt(path1.length()-1)==sep) {
	    		b.append(path1,0,path1.length()-1);
	    	} else {
	    		b.append(path1);
	    	}
    	}
    	if(StringUtil.isNotEmpty(path2)) {
	    	if(path2.charAt(0)!=sep) {
	    		b.append(sep);
	    	}
	    	if(path2.charAt(path2.length()-1)==sep) {
	    		b.append(path2,0,path2.length()-1);
	    	} else {
	    		b.append(path2);
	    	}
    	}
    	return b.toString();
    }
    
    /**
     * Add to path ensuring that the resulting path doesn't start with a '/' and
     * doesn't end with a '/'.
     */
    public static String concatParts(String path1, String path2, char sep) {
    	StringBuilder b = new StringBuilder();
    	if(path1.charAt(path1.length()-1)==sep) {
    		b.append(path1,0,path1.length()-1);
    	} else {
    		b.append(path1);
    	}
    	if(path2.charAt(0)!=sep) {
    		b.append(sep);
    	}
    	if(path2.charAt(path2.length()-1)==sep) {
    		b.append(path2,0,path2.length()-1);
    	} else {
    		b.append(path2);
    	}
    	return b.toString();
    }
    
    /**
     * Normalize a path, ensuring that it start with a '/' and does not end with a '/'.
     */
    public static String normalizePath(String path, char sep) {
    	boolean needLeadingSlash = path.charAt(0)!=sep;
    	boolean needRemoveTrailingSlash = path.charAt(path.length()-1)==sep;
    	if(needLeadingSlash || needRemoveTrailingSlash) {
    		if(needLeadingSlash && needRemoveTrailingSlash) {
    			StringBuilder b = new StringBuilder();
    			b.append(sep);
    			b.append(path,0,path.length()-1);
    			return b.toString();
    		} else if(needLeadingSlash) {
    			StringBuilder b = new StringBuilder();
    			b.append(sep);
    			b.append(path);
    			return b.toString();
    		} else {
    			return path.substring(0,path.length()-1);
    		}
    	}
    	return path;
    }    
    
    /**
     * Surrounds a path, ensuring that it starts with a '/' and ends with a '/'.
     */
    public static String surroundPath(String path, char sep) {
        boolean needLeadingSlash = path.charAt(0)!=sep;
        boolean needTrailingSlash = path.charAt(path.length()-1)!=sep;
        if(needLeadingSlash || needTrailingSlash) {
            if(needLeadingSlash && needTrailingSlash) {
                StringBuilder b = new StringBuilder();
                b.append(sep);
                b.append(path);
                b.append(sep);
                return b.toString();
            } else if(needLeadingSlash) {
                StringBuilder b = new StringBuilder();
                b.append(sep);
                b.append(path);
                return b.toString();
            } else {
                StringBuilder b = new StringBuilder();
                b.append(path);
                b.append(sep);
                return b.toString();
            }
        }
        return path;
    }    
}
