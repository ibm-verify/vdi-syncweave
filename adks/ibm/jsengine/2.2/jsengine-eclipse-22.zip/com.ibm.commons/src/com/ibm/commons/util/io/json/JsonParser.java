/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2009                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io.json;

import java.io.Reader;

import com.ibm.commons.util.io.json.parser.Json;
import com.ibm.commons.util.io.json.parser.ParseException;


/**
 * JSON parser.
 * <p>
 * This class provides some methods for generating parsing JSON text and create
 * objects out of it. It uses a factory to deal with the actual object classes.
 * </p>
 * @ibm-api
 */
public class JsonParser {
	
	/**
	 * Check if a string a a valid JSON text.
	 * @param json the JSON text to check
	 * @return true if the string is a JSON object
	 * @throws JsonException
	 * @ibm-api
	 */
	public static boolean isJson(String json) {
		try {
			Json parser = getParser(JsonEmptyFactory.instance,new java.io.StringReader(json));
			parser.parseJson();
			return true;
		} catch(Throwable ex) {
			return false;
		}
	}
	/**
	 * Parse a JSON text and return an object.
	 * @param factory the object factory
	 * @param json the JSON text
	 * @return the object created from the JSON text
	 * @throws JsonException
	 * @ibm-api
	 */
	public static Object fromJson(JsonFactory factory, String json) throws JsonException {
		try {
			Json parser = getParser(factory,new java.io.StringReader(json));
			return parser.parseJson();
		} catch(ParseException ex) {
		    throw new JsonException(ex,"Error when parsing JSON string"); // $NLS-JsonParser.ErrorwhenparsingJSONstring-1$
		}
	}

	/**
	 * Parse a JSON stream and return an object.
	 * @param factory the object factory
	 * @param reader the JSON stream
	 * @return the object created from the JSON text
	 * @throws JsonException
	 * @ibm-api
	 */
	public static Object fromJson(JsonFactory factory, Reader reader) throws JsonException {
		try {
			Json parser = getParser(factory,reader);
			return parser.parseJson();
		} catch(ParseException ex) {
		    throw new JsonException(ex,"Error when parsing JSON stream"); // $NLS-JsonParser.ErrorwhenparsingJSONstream-1$
		}
	}
	
	
    private static Json getParser(JsonFactory factory, Reader r) {
        Json parser = new Json(r);
        parser.factory = factory;
        return parser;
    }
}
