/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */



package com.ibm.commons.log;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Philippe Riand
 * @author dtaieb
 */
public interface LogMgr {

    public static final int LOG_ERROR_LEVEL = Level.SEVERE.intValue();
    public static final int LOG_WARN_LEVEL = Level.WARNING.intValue();
    public static final int LOG_INFO_LEVEL = Level.INFO.intValue();

    public static final int LOG_TRACEDEBUG_LEVEL = Level.FINEST.intValue();
    public static final int LOG_TRACEEVENT_LEVEL = Level.FINE.intValue();
    public static final int LOG_TRACEENTRY_LEVEL = Level.FINER.intValue();
    public static final int LOG_TRACEEXIT_LEVEL = Level.FINER.intValue();
    public static final int LOG_TRACEENTRYEXIT_LEVEL = Level.FINER.intValue();
    
    /**
     * Get the loger description.
     */
    public String getDescription();

    /** 
     * Returns whether traceDebug level is enables
     * @return boolean
     */
    public boolean isTraceDebugEnabled();

    /** 
     * Returns whether traceEntryExit level is enables
     * @return boolean
     */
    public boolean isTraceEntryExitEnabled();

    /** 
     * Returns whether traceEvent level is enables
     * @return boolean
     */
    public boolean isTraceEventEnabled();

    /**
     * Returns whether info level is enabled.
     * @return boolean
     */
    public boolean isInfoEnabled();

    /**
     * Returns whether warning level is enabled.
     * @return boolean
     */
    public boolean isWarnEnabled();

    /**
     * Returns whether error level is enabled.
     * @return boolean
     */
    public boolean isErrorEnabled();

    /**
     * Sets the Level for the Logger.
     * 
     * @param newLevel
     */
    public void setLogLevel(int newLevel);
    

    /**
     * Get the underlying Java logger, if any.
     * @return
     */
    public Logger getLogger();
    
    
    // ========================================================================
    //  New tracing methods
    // ========================================================================

    // Info functions
    public void info(String msg, Object...parameters);
    public void info(Throwable t, String msg, Object...parameters);
    public void infop(Object clazz, String method, String msg, Object...parameters);
    public void infop(Object clazz, String method, Throwable t, String msg, Object...parameters);
    
    // Warn functions
    public void warn(String msg, Object...parameters);
    public void warn(Throwable t, String msg, Object...parameters);
    public void warnp(Object clazz, String method, String msg, Object...parameters);
    public void warnp(Object clazz, String method, Throwable t, String msg, Object...parameters);
    
    // Error functions
    public void error(String msg, Object...parameters);
    public void error(Throwable t, String msg, Object...parameters);
    public void errorp(Object clazz, String method, String msg, Object...parameters);
    public void errorp(Object clazz, String method, Throwable t, String msg, Object...parameters);
    
    // Event functions (Level=FINE)
    public void traceEvent(String msg, Object...parameters);
    public void traceEvent(Throwable t, String msg, Object...parameters);
    public void traceEventp(Object clazz, String method, String msg, Object...parameters);
    public void traceEventp(Object clazz, String method, Throwable t, String msg, Object...parameters);
    
    // Debug functions (Level=FINEST)
    public void traceDebug(String msg, Object...parameters);
    public void traceDebug(Throwable t, String msg, Object...parameters);
    public void traceDebugp(Object clazz, String methodName, String msg, Object...parameters);
    public void traceDebugp(Object clazz, String methodName, Throwable t, String msg, Object...parameters);

    // Trace when a method is entered
    public void traceEntry(Object clazz, String methodName);
    public void traceEntry(Object clazz, String methodName, Object... parameters);

    // Trace when a method is exited
    public void traceExit(Object clazz, String methodName);
    public void traceExit(Object clazz, String methodName, Object ret);
}
