/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */



package com.ibm.commons.log;

import java.util.logging.Logger;


/**
 * @author Philippe Riand
 * @author dtaieb
 */
public class EmptyLogMgr implements LogMgr {

    public static final LogMgr instance = new EmptyLogMgr();

    public EmptyLogMgr() {
    }

    public Logger getLogger() {
        return null;
    }

    public String getDescription() {
        return "Empty Log Manager"; // $NLI-EmptyLogMgr.EmptyLogManager-1$
    }

    public boolean isTraceDebugEnabled() {
        return false;
    }

    public boolean isTraceEntryExitEnabled() {
        return false;
    }

    public boolean isTraceEventEnabled() {
        return false;
    }

    public boolean isInfoEnabled() {
        return false;
    }

    public boolean isWarnEnabled() {
        return false;
    }

    public boolean isErrorEnabled() {
        return false;
    }

    public boolean isFatalEnabled() {
        return false;
    }

    public void setLogLevel(int newLevel) {
        
    }
    
    public void info(String msg, Object...parameters) {
    }
    public void info(Throwable t, String msg, Object...parameters) {
    }
    public void infop(Object clazz, String method, String msg, Object...parameters) {
    }
    public void infop(Object clazz, String method, Throwable t, String msg, Object...parameters) {
    }
    
    public void warn(String msg, Object...parameters) {
    }
    public void warn(Throwable t, String msg, Object...parameters) {
    }
    public void warnp(Object clazz, String method, String msg, Object...parameters) {
    }
    public void warnp(Object clazz, String method, Throwable t, String msg, Object...parameters) {
    }
    
    public void error(String msg, Object...parameters) {
    }
    public void error(Throwable t, String msg, Object...parameters) {
    }
    public void errorp(Object clazz, String method, String msg, Object...parameters) {
    }
    public void errorp(Object clazz, String method, Throwable t, String msg, Object...parameters) {
    }
    
    public void traceEvent(String msg, Object...parameters) {
    }
    public void traceEvent(Throwable t, String msg, Object...parameters) {
    }
    public void traceEventp(Object clazz, String method, String msg, Object...parameters) {
    }
    public void traceEventp(Object clazz, String method, Throwable t, String msg, Object...parameters) {
    }
    
    public void traceDebug(String msg, Object...parameters) {
    }
    public void traceDebug(Throwable t, String msg, Object...parameters) {
    }
    public void traceDebugp(Object clazz, String methodName, String msg, Object...parameters) {
    }
    public void traceDebugp(Object clazz, String methodName, Throwable t, String msg, Object...parameters) {
    }

    public void traceEntry(Object clazz, String methodName) {
    }
    public void traceEntry(Object clazz, String methodName, Object... parameters) {
    }

    public void traceExit(Object clazz, String methodName) {
    }
    public void traceExit(Object clazz, String methodName, Object ret) {
    }
}