/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;


public class TraceReader extends Reader {

    public TraceReader(Reader reader, Writer trace) {
        this.reader=reader;
        this.trace=trace;
    }

    public void close() throws java.io.IOException {
        reader.close();
        trace.flush();
        // Don't close the trace writer, as it may be still used outside
    }

    public int read() throws IOException {
        int c = reader.read();
        if( c>=0 ) {
            trace.write( (char)c );
        }
        return c;
    }

    public int read(char cbuf[], int off, int len) throws IOException {
        int n=reader.read(cbuf,off,len);
        if (n>0) {
            trace.write(cbuf,off,n);    // it may read less than 'len' characters
        }
        return n;
    }

    private Reader reader;
    private Writer trace;
}
