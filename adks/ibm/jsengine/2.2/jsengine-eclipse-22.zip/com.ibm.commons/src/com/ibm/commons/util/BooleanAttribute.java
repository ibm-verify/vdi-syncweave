/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */



package com.ibm.commons.util;

/**
 * @author dtaieb
 *
 * Project: IBM Lotus Workplace Designer
 * Unit BooleanAttribute
 */
public class BooleanAttribute {
	private boolean b = false;

	/**
	 * Constructor for BooleanAttribute.
	 */
	public BooleanAttribute(String value, boolean bDefault) 
	{
		this.b = bDefault;
		if (value != null)
		{
			if (value.equalsIgnoreCase("true") || //$NON-NLS-1$
				value.equalsIgnoreCase("yes")) //$NON-NLS-1$
			{
				b = true;
			}
			else if(value.equalsIgnoreCase("false") || //$NON-NLS-1$
					 value.equalsIgnoreCase("no")) //$NON-NLS-1$
			{
				b = false;
			}
		}		
	}
	
	/**
	 * Method BooleanAttribute.
	 * @param value
	 */
	public BooleanAttribute(String value)
	{
		this(value, false);
	}
	
	public BooleanAttribute(boolean b)
	{
		this.b = b;
	}
	
	/**
	 * Method BooleanValue.
	 * @return boolean
	 */
	public boolean booleanValue()
	{
		return this.b;
	}
	
	

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return b ? "true" : "false"; //$NON-NLS-1$ //$NON-NLS-2$
	}
}
