/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2007                                          */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */


package com.ibm.commons.util.profiler;

/**
 * @author Mark Wallace
 * 18 Apr 2007
 * 
 * Plugin: com.ibm.commons
 */
public interface Profileable {
    
    /**
     * When an object implementing interface <code>Profileable</code> is used 
     * with a Profiler, executing it causes the <code>execute</code> method to 
     * be called and profiling to be performed based on the current Profiler state. 
     * <p>
     * The general contract of the method <code>execute</code> is that it may 
     * take any action whatsoever.
     *
     * @see     Profiler#execute()
     */
    public abstract Object execute();

}
