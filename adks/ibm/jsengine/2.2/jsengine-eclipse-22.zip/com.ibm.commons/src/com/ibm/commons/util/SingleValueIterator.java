/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Iterator for a single value.
 */
public class SingleValueIterator implements Iterator {

    private Object value;

    public SingleValueIterator( Object value ) {
        this.value = value;
    }

    public boolean hasNext() {
        return value!=null;
    }

    public Object next() {
        if( value!=null ) {
            Object result = value;
            value = null;
            return result;
        }
        throw new NoSuchElementException("No more elements in iterator");  // $NLS-SingleValueIterator.Nomoreelementiniterator-1$
    }

    public void remove() {
        throw new NoSuchElementException("Iterator does not support remove() method");  // $NLS-SingleValueIterator.Iteratordoesnotsupportremovemetho-1$
    }
}
