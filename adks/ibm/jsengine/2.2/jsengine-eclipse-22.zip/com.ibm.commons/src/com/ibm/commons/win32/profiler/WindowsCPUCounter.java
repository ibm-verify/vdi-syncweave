/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.win32.profiler;

import com.ibm.commons.util.TDiag;
import com.ibm.commons.util.profiler.HighResolutionTimer;

/**
 */
public class WindowsCPUCounter implements HighResolutionTimer {

    /**
     * Create and initialize the performance counter.
     */
    public WindowsCPUCounter() {
    }

    public boolean isAvailable() {
        return hasCurrentThreadCPUTime();
    }

    public int getTimerMode() {
        return CPU_TIME_COUNTER;
    }

    /**
     * Get a current time value with a resolution of 1 microseconds.
     */
    public long getTime() {
        return getCount()/1000L;
    }

    /**
     * Check if the CPU profiler is available.
     */
    private native boolean hasCurrentThreadCPUTime();

    /**
     * Return the elapsed time in nanoseconds.
     * @return
     */
    private native long getCount();

    private native long getKer();
    private native long getUsr();

    public static void main( String[] args ) {
        com.ibm.commons.win32.Win32.initLibrary();
        try {
            WindowsCPUCounter c = new WindowsCPUCounter();
            long ref = c.getTime();
            //long ref = System.currentTimeMillis();
            for( int i=0; i<10; i++ ) {
                long v = c.getTime();
                //long v = System.currentTimeMillis();
                TDiag.trace("ddd={0}",Long.toString((v-ref))); // $NON-NLS-1$
//                TDiag.trace("Ker={0}",TString.toString(c.getKer()));
//                TDiag.trace("Usr={0}",TString.toString(c.getUsr()));
                for( long j=0; j<100000000L; j++ ) {
                }
                //Thread.sleep(1000);
            }
        } catch( Exception e ) {}
    }
}

