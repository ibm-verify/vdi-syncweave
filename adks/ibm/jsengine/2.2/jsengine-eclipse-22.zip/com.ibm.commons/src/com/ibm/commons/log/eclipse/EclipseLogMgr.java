/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */


package com.ibm.commons.log.eclipse;

import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

import com.ibm.commons.log.AbstractLogMgr;

public class EclipseLogMgr extends AbstractLogMgr  {

    protected Logger _logger;

    public EclipseLogMgr(EclipseLogMgrFactory factory, String loggerName, String description)  {
    	super(factory,description);
        _logger = Logger.getLogger(loggerName, null);

    }

    public Logger getLogger() {
    	return _logger;
    }
    
    protected LogRecord createLogRecord(Level level, String msg) {
        LogRecord lr = new LogRecord(level, msg);
        return lr;
    }
}
