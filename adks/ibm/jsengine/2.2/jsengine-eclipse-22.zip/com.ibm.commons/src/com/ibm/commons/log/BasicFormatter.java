/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */
package com.ibm.commons.log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;


/**
 * Basic Log Fomatter.
 * This formatter is simply emitting the string as is. As our API formats the string 
 * before creating the log record, we don't to reformat it here. 
 * @author Philippe Riand
 */
public class BasicFormatter extends Formatter {
    
	private boolean dateTime;
	
	public BasicFormatter(boolean dateTime) {
		this.dateTime = dateTime;
	}
	
    private static final DateFormat format = new SimpleDateFormat("h:mm:ss"); // $NON-NLS-1$
    private static final String lineSep = System.getProperty("line.separator"); // $NON-NLS-1$

    public String format(LogRecord record) {
    	if(dateTime) {
	        StringBuilder output = new StringBuilder()
	            .append("[")
	            .append(record.getLevel()).append('|')
	            .append(format.format(new Date(record.getMillis())))
	            .append("]: ")
	            .append(record.getMessage())
	            .append(' ')
	            .append(lineSep);
	        return output.toString();
    	} else {
	        StringBuilder output = new StringBuilder()
            	.append(record.getMessage())
            	.append(lineSep);
	        return output.toString();
    	}
    }
}