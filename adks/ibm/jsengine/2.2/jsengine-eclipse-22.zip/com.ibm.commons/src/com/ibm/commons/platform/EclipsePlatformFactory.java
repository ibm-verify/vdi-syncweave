/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.platform;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtensionRegistry;

import com.ibm.commons.Platform;



/**
 * Platform Factory.
 * 
 * @author Philippe Riand
 */
public class EclipsePlatformFactory implements IPlatformFactory {
  
	public EclipsePlatformFactory() {
	}
	
	public Platform createPlatform() {
		// Look if someone implemented an extension point to retrive the platform
        IExtensionRegistry reg = org.eclipse.core.runtime.Platform.getExtensionRegistry();
        if (reg != null) {
            IConfigurationElement[] elt = reg.getConfigurationElementsFor("com.ibm.commons.PlatformFactory"); // $NON-NLS-1$
            for( int i=0; i<elt.length; i++ ) {
                if( "platformFactory".equalsIgnoreCase(elt[i].getName()) ) { // $NON-NLS-1$
                    try {
                        Object o = elt[i].createExecutableExtension("class"); // $NON-NLS-1$
                        IPlatformFactory factory = (IPlatformFactory)o;
                        return factory.createPlatform();
                    } catch(Throwable ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }
		
		// Return the default Eclipse platform
		return new GenericEclipsePlatform();
	}
}
