/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io;

import java.io.IOException;
import java.io.OutputStream;


public class TraceOutputStream extends OutputStream {

    public TraceOutputStream(OutputStream outputStream, OutputStream trace, boolean close) {
        this.outputStream=outputStream;
        this.trace=trace;
        this.close=close;
    }

    public void close() throws java.io.IOException {
        outputStream.close();
        if( close ) {
            trace.close();
        } else {
            trace.flush();
        }
    }

    public void flush() throws java.io.IOException {
        outputStream.flush();
    }

    public void write(int b) throws IOException {
        outputStream.write(b);
        trace.write(b);
        //trace.flush();
    }

    public void write(byte[] b, int off, int len) throws IOException {
        outputStream.write(b,off,len);
        trace.write(b,off,len);
        //trace.flush();
    }

    public void write(byte[] b) throws IOException {
        outputStream.write(b);
        trace.write(b);
        //trace.flush();
    }


    private OutputStream outputStream;
    private OutputStream trace;
    private boolean close;
}
