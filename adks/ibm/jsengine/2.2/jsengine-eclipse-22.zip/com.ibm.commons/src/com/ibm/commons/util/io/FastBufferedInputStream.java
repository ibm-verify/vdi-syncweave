/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io;

import java.io.IOException;
import java.io.InputStream;

public class FastBufferedInputStream extends InputStream {

    private static final int DEFAULT_BUFFER_SIZE = 16384;

    private static final boolean FORCE_READ = false;
    
    private InputStream is;
    private byte[] buffer;
    private int count;
    private int pos;
    
    public static InputStream get(InputStream source) {
        return source!=null ? new FastBufferedInputStream(source)
                            : null;
    }

    // Constructors
    public FastBufferedInputStream(InputStream is, int size) {
        this.is = is;
        this.buffer = new byte[size];
    }

    public FastBufferedInputStream(InputStream is) {
        this(is,DEFAULT_BUFFER_SIZE);
    }
    
    public boolean isEOF() throws IOException {
        if( pos==count ) {
            count = is.read( buffer, 0, buffer.length );
            pos = 0;
            if( count<0 ) {
                count = 0;
                return true;
            }
        }
        return false;
    }

    public int read() throws IOException {
        if( pos==count ) {
            count = is.read( buffer, 0, buffer.length );
            pos = 0;
            if( count<0 ) {
                count = 0;
                return -1;
            }
        }
        return buffer[pos++] & 0xFF;
    }

    public int read(byte[] array) throws IOException {
        return read(array,0,array.length);
    }

    public int read(byte[] array, int off, int length) throws IOException {
    	if(FORCE_READ) {
	    	int read = 0;
			while(read<length) {
				int r = _read(array,off,length);
				if(r<0) {
					return read>0 ? read : r;
				}
				off += r;
				length -= r;
				read += r;
			}
			return read;
    	} else {
    		return _read(array,off,length);
    	}
    }
    public int _read(byte[] array, int off, int length) throws IOException {
        int avail = count-pos;
        if( avail==0 ) {
            avail = count = is.read( buffer, 0, buffer.length );
            pos = 0;
            if( count<0 ) {
                count = 0;
                return -1;
            }
        }
        int toRead = length<avail ? length : avail;
        System.arraycopy(buffer,pos,array,off,toRead);
        pos += toRead;
        return toRead;
    }

    public long skip(long n) throws IOException {
    	if(FORCE_READ) {
	    	long skip = 0;
			while(skip<n) {
				long r = _skip(n);
				if(r<0) {
					return skip>0 ? skip : r;
				}
				n -= r;
				skip += r;
			}
			return skip;
    	} else {
    		return _skip(n);
    	}
    }
    private long _skip(long n) throws IOException {
        int avail = count-pos;
        if( avail>0 ) {
            if( n<(long)avail ) {
                pos += n;
                return n;
            }
            pos = count;
            return avail;
        }
        return is.skip(n);
    }

    public int available() throws IOException {
        return is.available() + (count-pos);
    }

    public void close() throws IOException {
        is.close();
    }

    public void mark(int int0) {
    }

    public void reset() throws IOException {
    }

    public boolean markSupported() {
        return false;
    }
}
