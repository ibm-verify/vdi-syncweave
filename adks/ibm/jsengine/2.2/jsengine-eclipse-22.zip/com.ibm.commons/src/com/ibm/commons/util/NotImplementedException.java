/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2009                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;



/**
 * Exception thrown by a method that is not implemented.
 * @designer.public
 * @ibm-api
 * @since 8.5.2
 */
public class NotImplementedException extends AbstractRuntimeException {

	private static final long serialVersionUID = 1L;

	/**
     * Create a new exception.
     * The message is formatted using the StringUtil.format rules.
     * @param msg the exception message
     * @param params the parameter values to format
     * @designer.publicmethod
     */
    public NotImplementedException() {
        super(null,"Not implemented",(Object[])null); //$NON-NLS-1$
    }
    
	/**
     * Create a new exception.
     * The message is formatted using the StringUtil.format rules.
     * @param msg the exception message
     * @param params the parameter values to format
     * @designer.publicmethod
     */
    public NotImplementedException(String msg, Object... params) {
        super(null,msg,params);
    }
}
