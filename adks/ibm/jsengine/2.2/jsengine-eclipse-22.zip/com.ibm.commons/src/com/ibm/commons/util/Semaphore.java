/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

/*
 * Created on: Jan 20, 2006
 * =========================================================================== 
 * Copyright IBM
 * Corporation 2005 All rights reserved. 
 * US Government Users Restricted Rights - 
 * Use, duplication or disclosure restricted by GS ADP Schedule 
 * Contract with IBM Corp.
 * ===========================================================================
 */

package com.ibm.commons.util;


/**
 * A simple semaphore implementation based on work by Doug Lea.
 * 
 * @author blevine
 * 
 */
public class Semaphore {

    private long _permits;

    /**
     * Create a semaphore with a specified number of permits
     * 
     * @param initialPermits
     */
    public Semaphore(long initialPermits) {
        _permits = initialPermits;
    }

    /**
     * Acquire a permite waiting indefinitely until acquired
     * or the thread is interuppted.
     * 
     * @throws InterruptedException
     */
    public void acquire() throws InterruptedException {
        if (Thread.interrupted())
            throw new InterruptedException();
        synchronized (this) {
            try {
                while (_permits<=0)
                    wait();
                --_permits;
            }
            catch (InterruptedException ex) {
                notify();
                throw ex;
            }
        }
    }


    /**
     * Try to acquire a permit waiting for a specified number of millis.
     * 
     * @param msecs
     * @return
     * @throws InterruptedException
     */
    public boolean acquire(long msecs) throws InterruptedException {
        if (Thread.interrupted())
            throw new InterruptedException();

        synchronized (this) {
            if (_permits>0) {
                --_permits;
                return true;
            }
            else if (msecs<=0)
                return false;
            else {
                try {
                    long startTime = System.currentTimeMillis();
                    long waitTime = msecs;

                    for (;;) {
                        wait(waitTime);
                        if (_permits>0) {
                            --_permits;
                            return true;
                        }
                        else {
                            waitTime = msecs-(System.currentTimeMillis()-startTime);
                            if (waitTime<=0)
                                return false;
                        }
                    }
                }
                catch (InterruptedException ex) {
                    notify();
                    throw ex;
                }
            }
        }
    }


    /**
     * Release a permit
     */
    public synchronized void release() {
        ++_permits;
        notify();
    }




    /**
     * Release a specified number of permits
     * 
     * @param n
     */
    public synchronized void release(long n) {
        if (n<0)
            throw new IllegalArgumentException("Negative argument"); // $NLS-Semaphore.Negativeargument-1$

        _permits += n;
        for (long i = 0; i<n; ++i)
            notify();
    }


    /**
     * Returns the current number of available permits
     * 
     * @return
     */
    public synchronized long permits() {
        return _permits;
    }
}
