/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.platform;

import java.io.PrintStream;

import com.ibm.commons.Platform;
import com.ibm.commons.log.LogMgrFactory;
import com.ibm.commons.log.jdk.JdkLogMgrFactory;


/**
 * @author dtaieb
 * @author Philippe Riand
 *
 * Project: IBM Lotus Workplace Designer
 */
public class GenericWebAppServerPlatform extends Platform {

    public static final String WEBAPPSERVER_PLATFORM = "WebAppServer"; // $NON-NLS-1$

    
    public GenericWebAppServerPlatform() {
    }

    public String getName() {
        return "Generic Web Application Server"; // $NLS-GenericWebAppServerPlatform.GenericWebApplicationServer-1$
    }
    
    public boolean isPlatform(String name) {
        if(WEBAPPSERVER_PLATFORM.equals(name)) {
            return true;
        }
        return super.isPlatform(name);
    }
    
    public final boolean isEclipseBased() {
        return false;
    }
    
    public PrintStream getOutputStream() {
        return java.lang.System.out;
    }
    
    public PrintStream getErrorStream() {
        return java.lang.System.err;
    }
    
    protected LogMgrFactory createLogMgrFactory() {
        return new JdkLogMgrFactory(); 
    }

}
