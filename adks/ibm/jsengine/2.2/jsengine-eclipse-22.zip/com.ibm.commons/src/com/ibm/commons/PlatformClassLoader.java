/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons;

public class PlatformClassLoader extends SecurityManager  {

    private static boolean retry = false;
    private static int idx = 0;
 
    public Class[] getClassContext() {
        return super.getClassContext();
    }

    public boolean canDefineClass(String classname)  {
        try  {
            checkPackageDefinition(classname);
            return(true);
        } catch(SecurityException se)  {
        }
        return(false);
    }

    public Class findClass(String classname)  {
        Class stackd[] = getClassContext();
        // Could use this to do qik check, throws exception - but just will be running the stack twice
        // checkPackageDefinition(classname);
        retry = true;
        idx = 0;
        while(hasMore())  {
            ClassLoader cl = findDesLoader(stackd);
            if(cl != null)  {
                try {
                    return(cl.loadClass(classname));
                } catch (ClassNotFoundException e) {
                    // ignore and go on to the next one
                }
            }
        }
        return(null);
    }

//    private ClassLoader findDesLoader(Class[] stack)  {
//        for(; idx < stack.length; idx++)  {
//            if(stack[idx].getName().startsWith("com.ibm.workplace.designer"))  {
//                return(stack[idx++].getClassLoader());
//            }
//        }
//        // end of stack - no more
//        retry = false;
//        return(null);
//    }
//
    private ClassLoader findDesLoader(Class[] stack)  {
        return( findClassLoader(stack, "com.ibm.workplace.designer") ); // $NON-NLS-1$
    }

    private ClassLoader findClassLoader(Class[] stack, String pkgName)  {
        for(; idx < stack.length; idx++)  {
            if(stack[idx].getName().startsWith(pkgName))  {
                return(stack[idx++].getClassLoader());
            }
        }
        // end of stack - no more
        retry = false;
        return(null);
    }

    public boolean hasMore()  {
        return(retry);
    }

    public ClassLoader getClassLoader(String packageName) {
        Class stackd[] = getClassContext();
        // Could use this to do qik check, throws exception - but just will be running the stack twice
        // checkPackageDefinition(classname);
        retry = true;
        idx = 0;
        ClassLoader cl = findClassLoader(stackd, packageName);
        return( cl != null ? cl : ClassLoader.getSystemClassLoader());
    }
}
