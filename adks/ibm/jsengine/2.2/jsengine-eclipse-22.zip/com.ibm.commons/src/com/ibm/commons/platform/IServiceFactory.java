/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* (C) Copyright IBM Corp. 2004, 2007                                */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.platform;

import com.ibm.commons.IPlatformService;



/**
 * Service factory.
 * 
 * @author Philippe Riand
 */
public interface IServiceFactory {
  
	public IPlatformService getPlatformService(String serviceName);
}
