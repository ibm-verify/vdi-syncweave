/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.profiler;

import com.ibm.commons.util.TDiag;
import com.ibm.commons.util.TSystem;
import com.ibm.commons.util.ThreadMap;


/**
 * <code>
 * if( Profiler.enabled ) {
 *     startProfiling(type,param);
 *     try {
 *         // Do stuff...
 *     } finally {
 *         endProfiling();
 *     }
 * } else {
 *     // Do stuff...
 * }
 */
public class Profiler {

    private static ProfilerAggregator mainAggregator = new ProfilerAggregator(null,new ProfilerType("Root"), null, 0); // $NON-NLS-1$
    private static ThreadMap threadMap = null;

    private static boolean enabled = false;

    private static HighResolutionTimer timer = null;



    // ============================================================================
    // Profiler public API
    // ============================================================================

    /**
     * Globally enable the profiler.
     */
    public static void enableProfiler( boolean cpuTime ) {
        synchronized(Profiler.class) {
            // If the profiler is already enabled, do nothing
            if( enabled) {
                return;
            }

            timer = createTimer(cpuTime);

            switch( timer.getTimerMode() ) {
                case HighResolutionTimer.CPU_TIME_COUNTER:
                        TDiag.trace( "Profiler is measuring CPU time ellapsed" ); // $NON-NLS-1$
                    break;
                case HighResolutionTimer.HIGH_RESOLUTION_COUNTER:
                        TDiag.trace( "Profiler is measuring total ellapsed time, using high precision timer" ); // $NON-NLS-1$
                    break;
                case HighResolutionTimer.LOW_RESOLUTION_COUNTER:
                        TDiag.trace( "Profiler is measuring total ellapsed time, using basic java timer" ); // $NON-NLS-1$
                    break;
            }

            // If the profiler is not yet enabled
            enabled = true;
            threadMap = new ThreadMap();
        }
    }

    public static HighResolutionTimer createTimer( boolean cpuTime ) {
        HighResolutionTimer timer = null;

        // Load the counter
        if( TSystem.isWindows() ) {
            try {
                // Try to instanciate the CPU measurer
                if( cpuTime ) {
                    timer = com.ibm.commons.win32.profiler.AbstractWindowsCounter.createCPUCounter();
                    if( timer==null ) {
                        TDiag.trace( "CPU time counter is not available on that configuration" ); // $NON-NLS-1$
                    }
                }
                if( timer==null ) {
                    timer = com.ibm.commons.win32.profiler.AbstractWindowsCounter.createHighResolutionCounter();
                    if( timer==null ) {
                        TDiag.trace( "High resolution timer is not available on that configuration" ); // $NON-NLS-1$
                    }
                }
            } catch (SecurityException sex) {
                TDiag.trace("Can't access Win32.dll - emulate high resolution timer only."); // $NON-NLS-1$
            } catch (UnsatisfiedLinkError ule) {
                TDiag.trace("Can't find Win32.dll - emulate high resolution timer only."); // $NON-NLS-1$
            } catch (Exception e) {
                TDiag.trace("Emulate high resolution timer only. Reason: {0}", e.getMessage()); // $NON-NLS-1$
            }
        }
        if( timer==null ) {
            timer = new HighResolutionTimerEmulation();
        }
        return timer;
    }

    /**
     * Globally disable the profiler.
     */
    public static void disableProfiler() {
        synchronized(Profiler.class) {
            enabled = false;
            threadMap = null;
            timer = null;
        }
    }

    /**
     * Profiler start.
     * This method initialize and starts the profiler for the current thread.
     */
    public static void startProfiler() {
        synchronized(Profiler.class) {
            if( enabled ) {
                threadMap.put(Thread.currentThread(),mainAggregator);
            }
        }
    }

    /**
     * Profiler end.
     * This method ends the profiler for the current thread.
     */
    public static void endProfiler() {
        synchronized(Profiler.class) {
            if( enabled ) {
                threadMap.remove(Thread.currentThread());
            }
        }
    }

    /**
     * Check if the profiler is enabled for the current thread
     */
    public static boolean isEnabled() {
        return enabled;
    }

    /**
     * Method that should be called when
     */
    public static ProfilerAggregator startProfileBlock(ProfilerType type, String param) {
    	return startProfileBlock(type, param, 0 );
    }
    
    public static ProfilerAggregator startProfileBlock(ProfilerType type, String param, int detailLevel) {
        ProfilerAggregator parent = (ProfilerAggregator)threadMap.get(Thread.currentThread());
        if( parent!=null ) {
            // We should look if it already contains an aggregator for that child
            ProfilerAggregator child = parent.get( type, param );
            if( child==null ) {
                synchronized(parent) {
                    child = parent.get( type, param );
                    if( child==null ) {
                        child = new ProfilerAggregator( parent, type, param, detailLevel );
                        parent.add( child );
                    }
                }
            }
            // That aggregator is the new current one
            threadMap.put(Thread.currentThread(),child);
            return child;
        }
        return null;
    }
    
    public static ProfilerAggregator startProfileBlock(String type, String param) {
        ProfilerType t = ProfilerType.get(type);
        return startProfileBlock(t, param, 0);
    }

    public static void endProfileBlock(ProfilerAggregator aggregator, long startTime) {
    	// PHIL: the profiler may have been disabled between the start and the end
        if(aggregator!=null && enabled) {
            aggregator.addInfo(getCurrentTime()-startTime);
            // Maybe the thread map disapeared...
            if( enabled ) {
                // The parent aggregator is the new current one
                threadMap.put(Thread.currentThread(),aggregator.getParent());
            }
        }
    }

    public static void resetProfiler() {
        mainAggregator.reinit();
    }

    public static ProfilerAggregator getMainAggregator() {
        return mainAggregator;
    }

    public static void dump() {
        mainAggregator.dump();
    }

    public static void profileRunnable(ProfilerType type, String id, Runnable runnable) {
        if (isEnabled()) {
            ProfilerAggregator agg = Profiler.startProfileBlock(type, id);
            long ts = Profiler.getCurrentTime();
            try {
                runnable.run(); 
            } 
            finally {
                Profiler.endProfileBlock(agg, ts);
            }
        } 
        else {
            runnable.run(); 
        }
    }

    // ========================================================================
    // TIMER ACCESS
    // ========================================================================

    /**
     * Get the current time in micros.
     */
    public static long getCurrentTime() {
        return timer.getTime();
    }
}
