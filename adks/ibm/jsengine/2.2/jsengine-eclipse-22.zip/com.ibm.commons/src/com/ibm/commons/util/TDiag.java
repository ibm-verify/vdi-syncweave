/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2009                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

import java.io.PrintStream;

import com.ibm.commons.Platform;
import com.ibm.commons.log.CommonsLogger;

/**
 * Diagnotics.
 */

public class TDiag {

	//
	// Methods that trace to the console
	// This should be avoided unless the messages must actually go to the console
	//
    public static final void console( String msg, Object...params ) {
    	String text = StringUtil.format(msg,params);
    	getOutputStream().println(text);
    }
    public static final void console( Exception ex) {
    	ex.printStackTrace(getOutputStream());
    }
    public static final void console( Exception ex, String msg, Object...params ) {
    	String text = StringUtil.format(msg,params);
    	getOutputStream().println(text);
    	ex.printStackTrace(getOutputStream());
    }
	
	public static PrintStream getSyncObject() {
		return System.out;
	}
    
    public static final void isEnabled() {
    	CommonsLogger.STANDARD.isTraceDebugEnabled();
    }

    public static final void trace( String msg ) {
    	if(CommonsLogger.STANDARD.isTraceDebugEnabled()) {
    		CommonsLogger.STANDARD.traceDebug(msg);
    	}
    }
    public static final void trace( String msg, Object p1 ) {
    	if(CommonsLogger.STANDARD.isTraceDebugEnabled()) {
    		CommonsLogger.STANDARD.traceDebug(msg,p1);
    	}
    }
    public static final void trace( String msg, Object p1, Object p2 ) {
    	if(CommonsLogger.STANDARD.isTraceDebugEnabled()) {
    		CommonsLogger.STANDARD.traceDebug(msg,p1,p2);
    	}
    }
    public static final void trace( String msg, Object p1, Object p2, Object p3 ) {
    	if(CommonsLogger.STANDARD.isTraceDebugEnabled()) {
    		CommonsLogger.STANDARD.traceDebug(msg,p1,p2,p3);
    	}
    }
    public static final void trace( String msg, Object p1, Object p2, Object p3, Object p4 ) {
    	if(CommonsLogger.STANDARD.isTraceDebugEnabled()) {
    		CommonsLogger.STANDARD.traceDebug(msg,p1,p2,p3,p4);
    	}
    }
    public static final void trace( String msg, Object p1, Object p2, Object p3, Object p4, Object p5 ) {
    	if(CommonsLogger.STANDARD.isTraceDebugEnabled()) {
    		CommonsLogger.STANDARD.traceDebug(msg,p1,p2,p3,p4,p5);
    	}
    }
    
    public static final void incIndent() {
    	//CommonsLogger.STANDARD.incIndent();
    }
    
    public static final void decIndent() {
    	//CommonsLogger.STANDARD.decIndent();
    }

    public static final void exception( Throwable t ) {
    	if(CommonsLogger.STANDARD.isErrorEnabled()) {
            // note, in domino a stack trace is never displayed
            // so some message should be provided
            String msg = null;
            try{
                msg = t.toString();
            }catch(Throwable loggingProblem){
                // ignore logging problem
            }
            if( null == msg || msg.length() == 0){
                try{
                    msg = t.getClass().getName()+"@????"; //$NON-NLS-1$
                }catch(Throwable problem2){
                    // ignore logging problem
                }
                if( null == msg ){
                    msg = "";
                }
            }
    		CommonsLogger.STANDARD.error(t,msg);
    	}
    }
    public static final void exception( Throwable t, String msg ) {
    	if(CommonsLogger.STANDARD.isErrorEnabled()) {
    		CommonsLogger.STANDARD.error(t,msg);
    	}
    }
    public static final void exception( Throwable t, String msg, Object p1 ) {
    	if(CommonsLogger.STANDARD.isErrorEnabled()) {
    		CommonsLogger.STANDARD.error(t,msg,p1);
    	}
    }
    public static final void exception( Throwable t, String msg, Object p1, Object p2 ) {
    	if(CommonsLogger.STANDARD.isErrorEnabled()) {
    		CommonsLogger.STANDARD.error(t,msg,p1,p2);
    	}
    }
    public static final void exception( Throwable t, String msg, Object p1, Object p2, Object p3 ) {
    	if(CommonsLogger.STANDARD.isErrorEnabled()) {
    		CommonsLogger.STANDARD.error(t,msg,p1,p2,p3);
    	}
    }
    public static final void exception( Throwable t, String msg, Object p1, Object p2, Object p3, Object p4 ) {
    	if(CommonsLogger.STANDARD.isErrorEnabled()) {
    		CommonsLogger.STANDARD.error(t,msg,p1,p2,p3,p4);
    	}
    }
    public static final void exception( Throwable t, String msg, Object p1, Object p2, Object p3, Object p4, Object p5 ) {
    	if(CommonsLogger.STANDARD.isErrorEnabled()) {
    		CommonsLogger.STANDARD.error(t,msg,p1,p2,p3,p4,p5);
    	}
    }
    
    public static PrintStream getOutputStream() {
    	return Platform.getInstance().getOutputStream();
    }
}

