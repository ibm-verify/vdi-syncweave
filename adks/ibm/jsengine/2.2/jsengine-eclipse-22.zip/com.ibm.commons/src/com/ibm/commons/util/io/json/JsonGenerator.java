/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2009                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io.json;

import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;

import com.ibm.commons.util.StringUtil;



/**
 * JSON text generator.
 * <p>
 * This class provides some methods for generating JSON object representation. It uses
 * a factory to deal with the actual object classes.
 * </p>
 * @ibm-api
 */
public class JsonGenerator {
    
    /**
     * Convert an object hierarchy to a JSON text.
     * The string is written in a compact form (no extra spaces/new lines inserted).
     * @param factory the object factory
     * @param value the convert to serialize
     * @return the resulting JSON string
     * @throws IOException
     * @throws JsonException
     * @ibm-api
     */
    public static String toJson(JsonFactory factory, Object value) throws IOException, JsonException {
        return toJson(factory,value,true);
    }
    
    /**
     * Convert an object hierarchy to a JSON text.
     * @param factory the object factory
     * @param value the convert to serialize
     * @param compact indicates if the string should be in a compact format
     * @return the resulting JSON string
     * @throws IOException
     * @throws JsonException
     * @ibm-api
     */
    public static String toJson(JsonFactory factory, Object value, boolean compact) throws IOException, JsonException {
        StringGenerator gen = new StringGenerator(factory,compact);
        gen.toJson(value);
        return gen.b.toString();
    }
    
    /**
     * Convert an object hierarchy to a JSON text and append it to an existing String builder.
     * @param factory the object factory
     * @param b the StringBuilder to append the text to
     * @param value the convert to serialize
     * @param compact indicates if the string should be in a compact format
     * @return the resulting JSON string
     * @throws IOException
     * @throws JsonException
     * @ibm-api
     */
    public static StringBuilder toJson(JsonFactory factory, StringBuilder b, Object value, boolean compact) throws IOException, JsonException {
        StringBuilderGenerator gen = new StringBuilderGenerator(factory,b,compact);
        gen.toJson(value);
        return b;
    }
    
    
    /**
     * Convert an object hierarchy to a JSON text in a writer.
     * @param factory the object factory
     * @param writer the writer to write to
     * @param value the convert to serialize
     * @param compact indicates if the string should be in a compact format
     * @throws IOException
     * @throws JsonException
     * @ibm-api
     */
    public static void toJson(JsonFactory factory, Writer writer, Object value, boolean compact) throws IOException, JsonException {
        WriterGenerator gen = new WriterGenerator(factory,writer,compact);
        gen.toJson(value);
    }

    /**
     * Generator base class.
     * @ibm-not-published
     */
    public abstract static class Generator {
        
        private JsonFactory factory;
        private boolean compact;
        private int indentLevel;
        
        protected Generator(JsonFactory factory, boolean compact) {
            this.factory = factory;
            this.compact = compact;
        }
        
        public abstract void out(char c) throws IOException;
        public abstract void out(String s) throws IOException;
        public JsonFactory getFactory() {
            return factory;
        }
        public int getIndentLevel() {
            return indentLevel;
        }
        public void setIndentLevel(int indentLevel) {
            this.indentLevel = indentLevel;
        }
        public void incIndent() {
        	indentLevel++;
        }
        public void decIndent() {
        	indentLevel--;
        }
        public boolean isCompact() {
            return compact;
        }
        
        public void toJson(Object value) throws IOException, JsonException {
            outLiteral(value);
        }

        public void outLiteral(Object value) throws IOException, JsonException {
            if(factory.isNull(value)) {
                outNull(); // $NON-NLS-1$
            } else if(factory.isString(value)) {
                outStringLiteral(factory.getString(value));
            } else if(factory.isNumber(value)) {
                outNumberLiteral(factory.getNumber(value));
            } else if(factory.isBoolean(value)) {
                outBooleanLiteral(factory.getBoolean(value));
            } else if(factory.isObject(value)) {
                outObject(value);
            } else if(factory.isArray(value)) {
                outArrayLiteral(value);
            } else if(value instanceof JsonReference) {
                outReference((JsonReference)value);
            } else {
                throw new JsonException(null,"Unknown literal of class {0}", value!=null?value.getClass().getName():"<null>"); // $NLS-JsonGenerator.Unknownliteralofclass0-1$ $NON-NLS-2$
            }
            
        }
        
        public void outNull() throws IOException, JsonException {
            out("null"); // $NON-NLS-1$
        }
        
        public void outObject(Object object) throws IOException, JsonException {
            indent();
            out('{');
            
            boolean coma = false;
            for(Iterator<String> it = factory.iterateObjectProperties(object); it.hasNext(); ) {
                String propName = it.next();
                Object propValue = factory.getProperty(object, propName);
                if(coma) {
                    out(',');
                } else {
                    coma = true;
                }
                indentLevel++;
                nl();
                indent();
                outPropertyName(propName);
                out(':');
                outLiteral(propValue);
                indentLevel--;
            }

            nl();
            indent();
            out('}');
            nl();
        }

        public void outPropertyName(String s) throws IOException {
        	outStringLiteral(s);
        }
        public void outStringLiteral(String s) throws IOException {
            out('\"');
            int len = s.length();
            for(int i=0; i<len; i++) {
                char c = s.charAt(i);
                switch(c) {
                    case '"': {
                        out("\\\""); //$NON-NLS-1$
                    } break;
                    case '\\': {
                        out("\\\\"); //$NON-NLS-1$
                    } break;
                    case '/': {
                        out("\\/"); //$NON-NLS-1$
                    } break;
                    case '\b': {
                        out("\\b"); //$NON-NLS-1$
                    } break;
                    case '\f': {
                        out("\\f"); //$NON-NLS-1$
                    } break;
                    case '\n': {
                        out("\\n"); //$NON-NLS-1$
                    } break;
                    case '\r': {
                        out("\\r"); //$NON-NLS-1$
                    } break;
                    case '\t': {
                        out("\\t"); //$NON-NLS-1$
                    } break;
                    default: {
                        // Ensure that it will be transmitted correctly...
                        if(c>=32 && c<=128) {
                            out(c);
                        } else {
                            out("\\u"); //$NON-NLS-1$
                            out(StringUtil.toUnsignedHex(c,4));
                        }
                    }
                }
            }
            out('\"');
        }

        public void outNumberLiteral(double d) throws IOException {
        	long l = (long)d;
        	if(((double)l)==d) {
        		String s = Long.toString(l);
                out(s);
        	} else {
        		String s = Double.toString(d);
                out(s);
        	}
        }
        
        public void outIntLiteral(int d) throws IOException {
            String s = Integer.toString(d);
            out(s);
        }
        
        public void outLongLiteral(long d) throws IOException {
            String s = Long.toString(d);
            out(s);
        }

        public void outBooleanLiteral(boolean b) throws IOException {
            out(b?"true":"false"); //$NON-NLS-1$ //$NON-NLS-2$
        }

        public void outArrayLiteral(Object array) throws IOException, JsonException {
            indent();
            out('[');
            
            boolean coma = false;
            for(Iterator<Object> it = factory.iterateArrayValues(array); it.hasNext(); ) {
                Object propValue = it.next();
                if(coma) {
                    out(',');
                } else {
                    coma = true;
                }
                indentLevel++;
                nl();
                indent();
                outLiteral(propValue); 
                indentLevel--;
            }
            
            nl();
            indent();
            out(']');
            nl();
        }
        
        public void outReference(JsonReference ref) throws IOException, JsonException {
            String s = ref.getRef();
            if(StringUtil.isNotEmpty(s)) {
                out(s);
            } else {
                out("null"); // $NON-NLS-1$
            }
        }
        
        public void indent() throws IOException {
            if(!compact && indentLevel>0) {
                for(int i=0; i<indentLevel; i++) {
                    out("  ");
                }
            }
        }
        
        public void nl() throws IOException {
            if(!compact) {
                out('\n');
            }
        }
    }
    
    /**
     * String generator class.
     * @ibm-not-published
     */
    public static class StringGenerator extends Generator { 
        private StringBuilder b;
        public StringGenerator(JsonFactory factory, boolean compact) {
            super(factory,compact);
            this.b = new StringBuilder();
        }
        public void out(char c) throws IOException {
            b.append(c);
        }
        public void out(String s) throws IOException {
            b.append(s);
        }
    }
    
    /**
     * StringBuilder generator class.
     * @ibm-not-published
     */
    public static class StringBuilderGenerator extends Generator { 
        private StringBuilder b;
        public StringBuilderGenerator(JsonFactory factory, StringBuilder b, boolean compact) {
            super(factory,compact);
            this.b = b;
        }
        public void out(char c) throws IOException {
            b.append(c);
        }
        public void out(String s) throws IOException {
            b.append(s);
        }
    }
    
    /**
     * Writer generator class.
     * @ibm-not-published
     */
    public static class WriterGenerator extends Generator { 
        private Writer writer;
        public WriterGenerator(JsonFactory factory, Writer writer, boolean compact) {
            super(factory,compact);
            this.writer = writer;
        }
    	public void flush() throws IOException {
    		writer.flush();
    	}
    	public void close() throws IOException {
    		writer.close();
    	}
        public void out(char c) throws IOException {
            writer.write(c);
        }
        public void out(String s) throws IOException {
            writer.write(s);
        }
    }
}