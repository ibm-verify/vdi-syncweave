/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io;

import java.io.IOException;
import java.io.Writer;

public class NullWriter extends Writer {

    // A writer that writes nothing

    public NullWriter() {
    }
    public void write(char cbuf[], int off, int len) throws IOException {
    }
    public void write(char cbuf[]) throws IOException {
    }
    public void write(int c) throws IOException {
    }
    public void write(String str, int off, int len) throws IOException {
    }
    public void write(String str) throws IOException {
    }
    public void flush() throws java.io.IOException {
    }
    public void close() throws java.io.IOException {
    }

}
