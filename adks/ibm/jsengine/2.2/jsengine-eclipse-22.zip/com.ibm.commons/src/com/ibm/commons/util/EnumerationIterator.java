/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

import java.util.Enumeration;
import java.util.Iterator;

/**
 * Enumeration wrapper.
 */
public class EnumerationIterator implements Iterator {

    private Enumeration en;

    public EnumerationIterator( Enumeration en ) {
        this.en = en;
    }

    public boolean hasNext() {
        return en.hasMoreElements();
    }

    public Object next() {
        Object o = en.nextElement();
        return o;
    }

    public void remove() {
        throw new UnsupportedOperationException();
    }
}
