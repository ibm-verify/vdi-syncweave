/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;


/**
 * A simple pattern matching that checks if a string is contained within a string array.
 */
public class TStringArrayMatching {

    public static final int COMPLETE    = 0;
    public static final int INCOMPLETE  = 1;
    public static final int UNMATCH     = 2;
    public static final int ERROR       = 3;
    
    /**
     * Constructor.
     */
    public TStringArrayMatching( String[] stringArray ) {
        if( stringArray==null ) {
            throw new IllegalArgumentException();
        }
        this.stringArray = stringArray;
    }

    /**
     * Get the string array to match.
     * @return the string array
     */
    public String[] getStringArray() {
        return stringArray;
    }

    /**
     * Set the string list to match.
     * @param stringList the string list
     */
    public void setStringArray( String[] stringArray ) {
        this.stringArray = stringArray;
    }

    /**
     * Check if a string is contained within the array.
     */
    public int match( String string ) {
        if( string==null ) {
            throw new IllegalArgumentException();
        }
        int result = UNMATCH;
        for( int i=0; i<stringArray.length; i++ ) {
            if( string.equals(stringArray[i]) ) {
                return COMPLETE;
            }
            if( string.startsWith(stringArray[i]) ) {
                result = result<INCOMPLETE ? result : INCOMPLETE;
            }
        }
        return result;
    }

    /**
     * Check if a string is contained within the array, without take care
     * of uppercase and lowercase.
     */
    public int containsIgnoreCase( String string ) {
        if( string==null ) {
            throw new IllegalArgumentException();
        }
        for( int i=0; i<stringArray.length; i++ ) {
            if( string.equalsIgnoreCase(stringArray[i]) ) {
                return COMPLETE;
            }
        }
        return UNMATCH;
    }

    /**
     * Returns the string in the array that corresponds to the given string
     * (without take care of upper and lowercase).
     * Returns null if string not found.
     */
    public String getExactString(String string) {
        if( string==null ) {
            throw new IllegalArgumentException();
        }
        for( int i=0; i<stringArray.length; i++ ) {
            if( string.equalsIgnoreCase(stringArray[i]) ) {
                return stringArray[i];
            }
        }
        return null;
    }

    /*
     *
     */
    private String[] stringArray;
}

