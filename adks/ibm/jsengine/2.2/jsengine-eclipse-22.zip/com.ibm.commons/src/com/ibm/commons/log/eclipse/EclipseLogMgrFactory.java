/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */



package com.ibm.commons.log.eclipse;

import com.ibm.commons.log.AbstractLogMgrFactory;
import com.ibm.commons.log.LogMgr;

/**
 * Eclipse based Log Factory
 * @author dtaieb
 * @author Philippe Riand
 *
 * Unit EclipseLogMgrFactory
 */
public class EclipseLogMgrFactory extends AbstractLogMgrFactory {

    public EclipseLogMgrFactory() {
    }

    protected LogMgr createLogMgr(String loggerName, String description) {
    	return new EclipseLogMgr(this, loggerName, description);
    }
}
