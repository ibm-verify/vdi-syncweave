/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */



package com.ibm.commons.log;

import java.util.HashMap;
import java.util.Map;

/**
 * @author priand
 */
public abstract class AbstractLogMgrFactory implements LogMgrFactory {
    
	private Map<String,LogMgr> _logs = new HashMap<String,LogMgr>();

    public AbstractLogMgrFactory() {
    }

    public LogMgr getLogMgr(String loggerName, String packageName) throws LogException {
        LogMgr obj = _logs.get(loggerName);
        if(obj==null) {
        	synchronized(this) {
                obj = _logs.get(loggerName);
                if(obj==null) {
                	obj = createLogMgr(loggerName,null);
                	_logs.put(loggerName, obj);
                }
                return obj;
        	}
        }
        return obj;
    }

    protected abstract LogMgr createLogMgr(String loggerName, String description);
}
