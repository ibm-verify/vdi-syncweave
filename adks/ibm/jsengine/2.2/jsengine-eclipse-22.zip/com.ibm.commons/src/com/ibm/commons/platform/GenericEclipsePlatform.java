/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.platform;

import java.io.InputStream;
import java.io.PrintStream;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtensionRegistry;

import com.ibm.commons.IPlatformService;
import com.ibm.commons.Platform;
import com.ibm.commons.log.LogMgrFactory;
import com.ibm.commons.log.eclipse.EclipseLogMgrFactory;


/**
 * @author dtaieb
 * @author Philippe Riand
 *
 * Project: IBM Lotus Workplace Designer
 */
public class GenericEclipsePlatform extends Platform {

    public static final String ECLIPSE_PLATFORM = "Eclipse"; // $NON-NLS-1$
    
    public GenericEclipsePlatform() {
    }

    public String getName() {
        return "Generic Eclipse"; // $NLS-GenericEclipsePlatform.GenericEclipse-1$
    }

    public boolean isPlatform(String name) {
        if(ECLIPSE_PLATFORM.equals(name)) {
            return true;
        }
        return super.isPlatform(name);
    }
    
    public PrintStream getOutputStream() {
        return java.lang.System.out;
    }
    
    public PrintStream getErrorStream() {
        return java.lang.System.err;
    }
    
    protected LogMgrFactory createLogMgrFactory() {
        return new EclipseLogMgrFactory();
    }
    
    public final boolean isEclipseBased() {
        return true;
    }

    public InputStream getGlobalResource(String resourceName) {
        InputStream is = findGlobalResource(resourceName);
        if(is!=null) {
            return is;
        }
        return super.getGlobalResource(resourceName);
    }
    
    private InputStream findGlobalResource(String resourceName) {
        try {
            // Look if someone implemented an extension point to retrive the platform
            IExtensionRegistry reg = org.eclipse.core.runtime.Platform.getExtensionRegistry();
            if (reg != null) {
                IConfigurationElement[] elt = reg.getConfigurationElementsFor("com.ibm.commons.GlobalResourceFactory"); // $NON-NLS-1$
                for( int i=0; i<elt.length; i++ ) {
                    if( "globalResourceFactory".equalsIgnoreCase(elt[i].getName()) ) { // $NON-NLS-1$
                        try {
                            Object o = elt[i].createExecutableExtension("class"); // $NON-NLS-1$
                            IGlobalResourceProvider factory = (IGlobalResourceProvider)o;
                            InputStream is = factory.getGlobalResource(resourceName);
                            if ( is != null ){
                            	return is;
                            }
                        } catch(Throwable ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }
        } catch( Throwable t ) {
            t.printStackTrace();
        }
        
        // Not found
        return null;
    }

    
    public IPlatformService getPlatformService( String serviceId ){
        IPlatformService srv = super.getPlatformService(serviceId);
        if(srv==null) {
        	// Look for a provider
        	srv = findService(serviceId);
        }
        return srv;
    }

    private IPlatformService findService(String serviceId) {
        try {
            // Look if someone implemented an extension point to retrive the platform
            IExtensionRegistry reg = org.eclipse.core.runtime.Platform.getExtensionRegistry();
            if (reg != null) {
                IConfigurationElement[] elt = reg.getConfigurationElementsFor("com.ibm.commons.ServiceFactory"); // $NON-NLS-1$
                for( int i=0; i<elt.length; i++ ) {
                    if( "serviceFactory".equalsIgnoreCase(elt[i].getName()) ) { // $NON-NLS-1$
                        try {
                            Object o = elt[i].createExecutableExtension("class"); // $NON-NLS-1$
                            IServiceFactory factory = (IServiceFactory)o;
                            IPlatformService srv = factory.getPlatformService(serviceId);
                            if ( srv != null ){
                            	return srv;
                            }
                        } catch(Throwable ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }
        } catch( Throwable t ) {
            t.printStackTrace();
        }
        
        // Not found
        return null;
    }
    
}
