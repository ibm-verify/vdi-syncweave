/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2009                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */



package com.ibm.commons.log;

import com.ibm.commons.util.AbstractException;

/**
 * @author Philippe Riand
 * @author dtaieb
 */
public class LogException extends AbstractException {
    private static final long serialVersionUID = 1L;

    /**
     * 
     */
    public LogException(Throwable nextException) {
        super(nextException);
    }

    /**
     * @param message
     */
    public LogException(Throwable nextException, String message) {
        super(nextException,message);
    }
}
