/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Aggregated iterator.
 * @author priand
 *
 */
public final class AggregatedIterator implements Iterator {

	private Iterator it1;
	private Iterator it2;
	
	public AggregatedIterator(Iterator it1, Iterator it2) {
		this.it1 = it1;
		this.it2 = it2;
	}

    public boolean hasNext() {
    	if(it1.hasNext()) {
    		return true;
    	}
    	if(it2.hasNext()) {
    		return true;
    	}
    	return false;
    }

    public Object next() {
    	if(it1.hasNext()) {
    		return it1.next();
    	}
    	if(it2.hasNext()) {
    		return it2.next();
    	}
        throw new NoSuchElementException();
    }

    public void remove() {
        throw new UnsupportedOperationException();
    }

}
