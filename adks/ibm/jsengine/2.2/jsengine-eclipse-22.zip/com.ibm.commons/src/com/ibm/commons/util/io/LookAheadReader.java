/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

import com.ibm.commons.util.FastStringBuffer;

/**
 * The lexical reader is a specific reader that cache some data of another reader
 * and that permits a lookup of characters.
 */
public class LookAheadReader extends Reader {

    /**
     * Constructor.
     */
    public LookAheadReader( Reader reader, int bufferLength ) {
        this.reader = reader;
        this.buffer = new char[bufferLength];

        // Initialize the reader data
        this.position = 0;
        this.count = 0;
        this.eof = false;
        this.index=0;
    }

    public int getBufferLength() {
        return buffer.length;
    }

    /**
     *
     */
    public final int read() throws IOException {
        // Need to read the buffer ?
        if( count==0 && !readData(1) ) {
            return -1;
        }

        // Return the next available char
        count--;
        index++;
        return buffer[position++];
    }

    public final int readCDATABase64() throws IOException {
        if( count==0 ) {
            if( !readData(1) ) {
                return -1;
            }
        }
        char c = buffer[position];
        if( c==']' ) {
            return -1;
        }
        position++;
        count--;
        return (int)c;
    }
    public final int readCDATABase64Bytes(byte[] b) throws IOException {
    	return readCDATABase64Bytes(b,0,b.length);
    }
    public final int readCDATABase64Bytes(byte[] b, int off, int len) throws IOException {
        if( count==0 ) {
            if( !readData(1) ) {
                return -1;
            }
        }
        int max = Math.min(len,count);
        for( int i=0; i<max; i++ ) {
            char c = buffer[position+i];
            if( c==']' ) {
                position += i;
                count -= i;
                return i;
            }
            b[i+off] = (byte)c;
        }
        position += max;
        count -= max;
        return max;
    }

    /**
     *
     */
    public int read( char cbuf[], int off, int len) throws IOException {
        if( len>0 ) {
            // Ensure that the buffer have some data
            if( count==0 && !readData(1) ) {
                return -1;
            }

            // Copy as many data as possible
            int n = Math.min( len, count );
            if( cbuf!=null ) {
                System.arraycopy( buffer, position, cbuf, off, n );
            }
            position += n;
            count -= n;
            index += n;
            return n;
        }
        return 0;
    }

    public long skip(long len) throws IOException {
        if( len>0 ) {
            if( len==1 ) {
                read(); return 1;
            } else {
                return read( null, 0, (int)len );
            }
        }
        return 0;
    }

    public void close() throws IOException {
        reader.close();
    }

    public int getCurrentIndex() {
        return index;
    }

    private boolean readData(int minData) throws IOException {
        // Check for the end of the reader
        if( eof ) {
            return false;
        }

        // Move the existing data at the beggining of the buffer
        if( count>0 ) {
            System.arraycopy( buffer, position, buffer, 0, count );
        }
        position = 0;

        // Read as many data as possible
        while(count<minData) {
            // Read from the internal reader
            int r = readBuffer( buffer, count, buffer.length-count );
            if( r<=0 ) {
                eof = true;
                return false;
            } else {
                count += r;
            }
        }
        return true;
    }

    /**
     * Internal function that read data into the buffer.
     * It can be overriden in order to set some kind of filters (skipping blanks,
     * comments...).
     */
    protected int readBuffer( char[] buffer, int position, int count ) throws IOException {
        return reader.read( buffer, position, count );
    }


    // ========================================================================
    // Look ahead function
    // ========================================================================

    /**
     * Check if the end of the strealm has been reached
     */
    public boolean hasChar() throws IOException {
        // Need to read the buffer ?
        if( count==0 && !readData(1) ) {
            return false;
        }
        return true;
    }

    /**
     * Read a character ahead.
     * The position cannot be greater than the buffer length.
     * @param pos the character position
     * @return the character, -1 if not available (not enough character in the reader)
     */
    public final int getCharAt( int pos ) throws IOException {
        // If the character not is already available, read it
        if( pos>=count ) {
            if( !readData(pos+1) ) {
                return -1;
            }
        }

        // And return it
        //if( (position+pos)>=buffer.length ) {
        //    return -1;
        //}
        return buffer[position+pos];
    }

    /**
     * Read one character ahead.
     * @return the character, -1 if not available (not enough character in the reader)
     */
    public final int getChar() throws IOException {
        //return getCharAt(0);
        // If the character not is already available, read it
        if( count==0 ) {
            if( !readData(1) ) {
                return -1;
            }
        }
        return buffer[position];
    }

    /**
     * Get a string of # characters.
     * Mainly for debugging!
     */
    public String getStringAhead( int maxChars ) throws IOException {
        // Ensure that the buffer is long enough
        if( maxChars>count ) {
            readData(maxChars);
        }

        // Get each character
        char[] c = new char[Math.min(maxChars,count)];
        for( int i=0; i<c.length; i++ ) {
            c[i]=buffer[position+i];
        }
        return new String(c);
    }

    /**
     *
     */
    public boolean startsWith( char c ) throws IOException {
        return getChar()==c;
    }

    /**
     *
     */
    public boolean startsWithIgnoreCase( char c ) throws IOException {
        return Character.toLowerCase((char)getCharAt(0))==Character.toLowerCase(c);
    }

    /**
     *
     */
    public boolean startsWith( String s ) throws IOException {
        int length = s.length();

        // Ensure that the buffer is long enough
        if( length>count ) {
            if( !readData(length) ) {
                return false;
            }
        }

        // Compare each character
        for( int i=0; i<length; i++ ) {
            if( buffer[position+i]!=s.charAt(i) ) {
                return false;
            }
        }
        return true;
    }

    /**
     *
     */
    public boolean startsWithIgnoreCase( String s ) throws IOException {
        int length = s.length();

        // Ensure that the buffer is long enough
        if( length>count ) {
            if( !readData(length) ) {
                return false;
            }
        }

        // Compare each character
        for( int i=0; i<length; i++ ) {
            if( Character.toLowerCase(buffer[position+i])!=Character.toLowerCase(s.charAt(i)) ) {
                return false;
            }
        }
        return true;
    }

    /**
     *
     */
    public boolean match( char c ) throws IOException {
        if( startsWith(c) ) {
            //read();
            count--;
            index++;
            position++;
            return true;
        }
        return false;
    }

    /**
     *
     */
    public boolean matchIgnoreCase( char c ) throws IOException {
        if( startsWithIgnoreCase(c) ) {
            //read();
            count--;
            index++;
            position++;
            return true;
        }
        return false;
    }

    /**
     *
     */
    public boolean match( String s ) throws IOException {
        if( startsWith(s) ) {
            //read( null, 0, s.length() );
            int len = s.length();
            count-=len;
            index+=len;
            position+=len;
            return true;
        }
        return false;
    }

    /**
     *
     */
    public boolean matchIgnoreCase( String s ) throws IOException {
        if( startsWithIgnoreCase(s) ) {
            //read( null, 0, s.length() );
            int len = s.length();
            count-=len;
            index+=len;
            position+=len;
            return true;
        }
        return false;
    }

    /**
     * Skip a list of blanks characters (space, new line, tab...).
     */
//    public boolean skipBlanks() throws IOException {
//        boolean skipped=false;
//        while(true) {
//            int c = getChar();
//            //if( c<0 || !Character.isWhitespace((char)c) ) {
//            if( c!=' ' && c!='\t' && c!='\n' && c!='\r' ) {
//                return skipped;
//            }
//            //read();
//            count--;
//            index++;
//            skipped=true;
//        }
//    }
    public boolean skipBlanks(FastStringBuffer b) throws IOException {
        int c = getChar();
        if( c==' ' || c=='\t' || c=='\n' || c=='\r' ) {
            b.append((char)c);
            count--; index++; position++;
            while(true) {
                c = getChar();
                if( c!=' ' && c!='\t' && c!='\n' && c!='\r' ) {
                    return true;
                }
                b.append((char)c);
                count--; index++; position++;
            }
        }
        return false;
    }
    public boolean skipBlanks() throws IOException {
        int c = getChar();
        if( c==' ' || c=='\t' || c=='\n' || c=='\r' ) {
            count--; index++; position++;
            while(true) {
                c = getChar();
                if( c!=' ' && c!='\t' && c!='\n' && c!='\r' ) {
                    return true;
                }
                count--; index++; position++;
            }
        }
        return false;
    }

    /**
     *
     */
    public void skipUpto( char c ) throws IOException {
        do {
            int cc = getChar();
            if( cc<0 || cc==c ) {
                return;
            }
            count--; index++; position++;
        } while(true);
    }

    /**
     *
     */
    public String upto( char c ) throws IOException {
        FastStringBuffer b = new FastStringBuffer();
        do {
            int cc = getChar();
            if( cc<0 || cc==c ) {
                return b.toString();
            }
            b.append(cc);
            count--; index++; position++;
        } while(true);
    }

    /**
     * Copy to a writer
     */
    public void copy( Writer w ) throws IOException {
        // TODO: optimize by using the internal buffer...
        char[] b = new char[1024];
        do {
            int r = read( b, 0, b.length );
            if( r>0 ) {
                w.write( b, 0, r );
            } else {
                return;
            }
        } while(true);
    }

    /**
     *
     */

    /*
     *
     */
    private Reader  reader;
    private char[]  buffer;
    private int     count;
    private int     position;
    private boolean eof;
    private int     index;          // Index in the (embedded) stream of the next character
                                    //    = number of characters already read
}

