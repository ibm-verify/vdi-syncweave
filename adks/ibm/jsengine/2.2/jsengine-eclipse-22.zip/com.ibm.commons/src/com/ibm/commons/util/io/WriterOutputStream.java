/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;


/**
 * Converts from a Writer to an OutputStream.
 */
public class WriterOutputStream extends OutputStream {

    private Writer writer;
    private String encoding;

    public WriterOutputStream( Writer writer, String encoding ) {
        this.writer = writer;
        this.encoding = encoding;
    }

    public WriterOutputStream( Writer writer ) {
        this( writer, null );
    }

    public void write( int b ) throws IOException {
        writer.write( b );
    }

    public void write( byte b[], int off, int len ) throws IOException {
        if( encoding!=null ) {
            writer.write( new String( b, off, len, encoding ) );
        } else {
            writer.write( new String( b, off, len ) );
        }
    }

    public void write( byte b[] ) throws IOException {
        if( encoding!=null ) {
            writer.write( new String( b, encoding ) );
        } else {
            writer.write( new String( b ) );
        }
    }

    public void close() throws IOException {
        writer.close();
    }

    public void flush() throws IOException {
        writer.flush();
    }
}

