/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */



package com.ibm.commons.log;

/**
 * @author dtaieb
 * @author priand
 */
public interface LogMgrFactory {

	public LogMgr getLogMgr(String loggerName, String description) throws LogException;
}
