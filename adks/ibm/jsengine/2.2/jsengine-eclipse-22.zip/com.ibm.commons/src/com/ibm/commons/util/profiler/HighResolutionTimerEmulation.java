/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.profiler;


/**
 * Emulate a timer with an intended resolution of 1 ms. This timer is
 * used if the real high resolution timer is not available. It is
 * based upon Java's System class.
 */
public class HighResolutionTimerEmulation implements HighResolutionTimer {

    /**
     * Get the counter mode.
     */
    public int getTimerMode() {
        return HIGH_RESOLUTION_COUNTER;
    }

    /**
     * Get the mesured time in microseconds.
     */
    public long getTime() {
        return System.nanoTime()/1000L;
    }

/*
    public static void main( String[] args ) {
        try {
            HighResolutionTimerEmulation c = new HighResolutionTimerEmulation();
            long ref = c.getTime();
            //long ref = System.currentTimeMillis();
            for( int i=0; i<10; i++ ) {
                long v = c.getTime();
                //long v = System.currentTimeMillis();
                System.out.println("d="+Long.toString((v-ref))); // $NON-NLS-1$
                for( long j=0; j<100000000L; j++ ) {
                }
                //Thread.sleep(1000);
            }
        } catch( Exception e ) {}
    }
*/    
}
