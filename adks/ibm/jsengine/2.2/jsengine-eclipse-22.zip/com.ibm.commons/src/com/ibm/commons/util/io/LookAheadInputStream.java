/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io;

import java.io.IOException;
import java.io.InputStream;

import com.ibm.commons.util.FastStringBuffer;

/**
 * The lexical inputstream is a specific inputstrean that cache some data of another inputstream
 * and that permits a lookup of characters.
 */
public class LookAheadInputStream extends InputStream {

    /**
     * Constructor.
     */
    public LookAheadInputStream( InputStream is, int bufferLength ) {
        this.is = is;
        this.buffer = new byte[bufferLength];

        // Initialize the reader data
        this.position = 0;
        this.count = 0;
        this.eof = false;
        this.index=0;
    }

    public int getBufferLength() {
        return buffer.length;
    }

    /**
     *
     */
    public final int read() throws IOException {
        // Need to read the buffer ?
        if( count==0 && !readData(1) ) {
            return -1;
        }

        // Return the next available char
        count--;
        index++;
        return buffer[position++];
    }

    /**
     *
     */
    public int read( byte cbuf[], int off, int len) throws IOException {
        if( len>0 ) {
            // Ensure that the buffer have some data
            if( count==0 && !readData(1) ) {
                return -1;
            }

            // Copy as many data as possible
            int n = Math.min( len, count );
            if( cbuf!=null ) {
                System.arraycopy( buffer, position, cbuf, off, n );
            }
            position += n;
            count -= n;
            index += n;
            return n;
        }
        return 0;
    }

    public long skip(long len) throws IOException {
        if( len>0 ) {
            if( len==1 ) {
                read(); return 1;
            } else {
                return read( null, 0, (int)len );
            }
        }
        return 0;
    }

    public void close() throws IOException {
        is.close();
    }

    public int getCurrentIndex() {
        return index;
    }

    private boolean readData(int minData) throws IOException {
        // Check for the end of the reader
        if( eof ) {
            return false;
        }

        // Move the existing data at the beggining of the buffer
        if( count>0 ) {
            System.arraycopy( buffer, position, buffer, 0, count );
        }
        position = 0;

        // Read as many data as possible
        while(count<minData) {
            // Read from the internal reader
            int r = readBuffer( buffer, count, buffer.length-count );
            if( r<=0 ) {
                eof = true;
                return false;
            } else {
                count += r;
            }
        }
        return true;
    }

    /**
     * Internal function that read data into the buffer.
     * It can be overriden in order to set some kind of filters (skipping blanks,
     * comments...).
     */
    protected int readBuffer( byte[] buffer, int position, int count ) throws IOException {
        return is.read( buffer, position, count );
    }


    // ========================================================================
    // Look ahead function
    // ========================================================================

    /**
     * Check if the end of the stream has been reached
     */
    public boolean hasByte() throws IOException {
        // Need to read the buffer ?
        if( count==0 && !readData(1) ) {
            return false;
        }
        return true;
    }

    /**
     * Read a byte ahead.
     * The position cannot be greater than the buffer length.
     * @param pos the character position
     * @return the character, -1 if not available (not enough character in the reader)
     */
    public final int getByteAt( int pos ) throws IOException {
        // If the character not is already available, read it
        if( pos>=count ) {
            if( !readData(pos+1) ) {
                return -1;
            }
        }

        // And return it
        //if( (position+pos)>=buffer.length ) {
        //    return -1;
        //}
        return ((int)buffer[position+pos]) & 0xFF;
    }

    /**
     * Read one byte ahead.
     * @return the character, -1 if not available (not enough character in the reader)
     */
    public final int getByte() throws IOException {
        //return getCharAt(0);
        // If the character not is already available, read it
        if( count==0 ) {
            if( !readData(1) ) {
                return -1;
            }
        }
        return ((int)buffer[position]) & 0xFF;
    }

    /**
     * Get a string of # characters.
     * Mainly for debugging!
     */
    public byte[] getByteAhead( int maxChars ) throws IOException {
        // Ensure that the buffer is long enough
        if( maxChars>count ) {
            readData(maxChars);
        }

        // Get each character
        byte[] c = new byte[Math.min(maxChars,count)];
        for( int i=0; i<c.length; i++ ) {
            c[i]=buffer[position+i];
        }
        return c;
    }

    
    public char getChar() throws IOException {
        return (char)getByte();
    }

    public char getCharAt(int index) throws IOException {
        return (char)getByteAt(index);
    }
    
    /**
     *
     */
    public boolean startsWith( char c ) throws IOException {
        return getChar()==c;
    }

    /**
     *
     */
    public boolean startsWithIgnoreCase( char c ) throws IOException {
        return Character.toLowerCase((char)getCharAt(0))==Character.toLowerCase(c);
    }

    /**
     *
     */
    public boolean startsWith( String s ) throws IOException {
        int length = s.length();

        // Ensure that the buffer is long enough
        if( length>count ) {
            if( !readData(length) ) {
                return false;
            }
        }

        // Compare each character
        for( int i=0; i<length; i++ ) {
            if( buffer[position+i]!=s.charAt(i) ) {
                return false;
            }
        }
        return true;
    }

    /**
     *
     */
    public boolean startsWithIgnoreCase( String s ) throws IOException {
        int length = s.length();

        // Ensure that the buffer is long enough
        if( length>count ) {
            if( !readData(length) ) {
                return false;
            }
        }

        // Compare each character
        for( int i=0; i<length; i++ ) {
            if( Character.toLowerCase((char)buffer[position+i])!=Character.toLowerCase(s.charAt(i)) ) {
                return false;
            }
        }
        return true;
    }

    /**
     *
     */
    public boolean match( char c ) throws IOException {
        if( startsWith(c) ) {
            //read();
            count--;
            index++;
            position++;
            return true;
        }
        return false;
    }

    /**
     *
     */
    public boolean matchIgnoreCase( char c ) throws IOException {
        if( startsWithIgnoreCase(c) ) {
            //read();
            count--;
            index++;
            position++;
            return true;
        }
        return false;
    }

    /**
     *
     */
    public boolean match( String s ) throws IOException {
        if( startsWith(s) ) {
            //read( null, 0, s.length() );
            int len = s.length();
            count-=len;
            index+=len;
            position+=len;
            return true;
        }
        return false;
    }

    /**
     *
     */
    public boolean matchIgnoreCase( String s ) throws IOException {
        if( startsWithIgnoreCase(s) ) {
            //read( null, 0, s.length() );
            int len = s.length();
            count-=len;
            index+=len;
            position+=len;
            return true;
        }
        return false;
    }

    /**
     * Skip a list of blanks characters (space, new line, tab...).
     */
    public boolean skipBlanks(FastStringBuffer b) throws IOException {
        int c = getChar();
        if( c==' ' || c=='\t' || c=='\n' || c=='\r' ) {
            b.append((char)c);
            count--; index++; position++;
            while(true) {
                c = getChar();
                if( c!=' ' && c!='\t' && c!='\n' && c!='\r' ) {
                    return true;
                }
                b.append((char)c);
                count--; index++; position++;
            }
        }
        return false;
    }
    public boolean skipBlanks() throws IOException {
        int c = getChar();
        if( c==' ' || c=='\t' || c=='\n' || c=='\r' ) {
            count--; index++; position++;
            while(true) {
                c = getChar();
                if( c!=' ' && c!='\t' && c!='\n' && c!='\r' ) {
                    return true;
                }
                count--; index++; position++;
            }
        }
        return false;
    }

    /**
     *
     */
    public void skipUpto( char c ) throws IOException {
        do {
            int cc = getChar();
            if( cc<0 || cc==c ) {
                return;
            }
            count--; index++; position++;
        } while(true);
    }

    /**
     *
     */
    public String upto( char c ) throws IOException {
        FastStringBuffer b = new FastStringBuffer();
        do {
            int cc = getChar();
            if( cc<0 || cc==c ) {
                return b.toString();
            }
            b.append(cc);
            count--; index++; position++;
        } while(true);
    }

    /**
     *
     */

    /*
     *
     */
    private InputStream  is;
    private byte[]  buffer;
    private int     count;
    private int     position;
    private boolean eof;
    private int     index;          // Index in the (embedded) stream of the next character
                                    //    = number of characters already read
}

