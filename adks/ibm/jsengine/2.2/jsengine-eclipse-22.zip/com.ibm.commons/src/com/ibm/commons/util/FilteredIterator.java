/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

import java.util.Iterator;

/**
 * A JAVA2 collection iterator that filters the items from another iterator.
 */
public abstract class FilteredIterator<T> implements Iterator<T> {

    public FilteredIterator(Iterator<T> iterator) {
        this.iterator = iterator;
    }

    protected abstract boolean accept( Object object );

    public boolean hasNext() {
        if( !initialized ) {
            next();
            initialized = true;
        }
        return hasnext;
    }

    public T next() {
        T result = current;
        this.hasnext = false;
        while( !this.hasnext && iterator.hasNext() ) {
            current = iterator.next();
            if( accept(current) ) {
                this.hasnext = true;
            }
        }
        return result;
    }

    public void remove() {
        throw new IllegalStateException( "Filtered iterators cannot be used to remove an item" ); //$NLS-FilteredIterator.FilteredIterator.CannotRemoveItem.Exception-1$
    }

    private boolean initialized;
    private Iterator<T> iterator;
    private boolean hasnext;
    private T current;
}
