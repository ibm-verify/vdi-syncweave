/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */
package com.ibm.commons.log;

import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.LogRecord;
import java.util.logging.StreamHandler;

import com.ibm.commons.Platform;


/**
 * Console handler that uses a custom formatter. 
 * @author Philippe Riand
 */
public class BasicConsoleHandler extends StreamHandler {
	
	
	private static class ConsoleOutputStream extends OutputStream {

		@Override
		public void flush() throws IOException {
			Platform.getInstance().getOutputStream().flush();
		}

		@Override
		public void write(byte[] b, int off, int len) throws IOException {
			Platform.getInstance().getOutputStream().write(b, off, len);
		}

		@Override
		public void write(byte[] b) throws IOException {
			Platform.getInstance().getOutputStream().write(b);
		}

		@Override
		public void write(int b) throws IOException {
			Platform.getInstance().getOutputStream().write(b);
		}
		
	}
	
	public BasicConsoleHandler(boolean dateTime) {
		setOutputStream(new ConsoleOutputStream());
		setFormatter(new BasicFormatter(dateTime));
	}
	
	public BasicConsoleHandler() {
		this(true);
	}

	@Override
	public synchronized void close() throws SecurityException {
		flush();
	}

	@Override
	public synchronized void publish(LogRecord record) {
		super.publish(record);
		flush();
	}	
}
