/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.lang.reflect.Method;


/**
 * Abstract base class for global exceptions.
 * This class is the main class for all the exception. It provides several enhancements to 
 * the Java Exception clas, by providing message formating with parameters. All its constructors
 * also have a first argument which is the root exception, which is an easy way for 
 * implementing the "exception chaining" pattern.
 * @author Philippe Riand
 * @designer.public
  * @ibm-api
 * @since 6.0

 */
public class AbstractException extends Exception implements IExceptionEx {

    private static final long serialVersionUID = -2271442234643208879L;
	
    /**
     * Create a new exception.
     * The exception is not featuring a message
     * @paran nextException the cause exception
     * @designer.publicmethod
     */
    public AbstractException(Throwable nextException) {
        this(nextException, nextException==null?"":nextException.getMessage() ); //$NON-NLS-1$
    }
    /**
     * Create a new exception.
     * The message is formatted using the StringUtil.format rules.
     * @paran nextException the cause exception
     * @param msg the exception message
     * @designer.publicmethod
     */
    public AbstractException(Throwable nextException, String msg, Object...params) {
        super(StringUtil.format(msg,params));
        initCause(nextException);
    }

    public static Throwable initCause(Throwable ext, Throwable cause) {
        ext.initCause(cause);
        return ext;
    }
    
    public static Throwable getCause(Throwable ext) {
        return ext.getCause();
    }    

	public void printExtraInformation(PrintWriter err) {
		// Nothing...
	}

	/**
	 * Extended stack trace print
	 * @param err
	 */
    public static void printExtraInformation(PrintWriter err, Throwable ex ) {
        // Look if this exception has extra information
        for(Throwable t=ex; t!=null; t=t.getCause()) {
        	try {
        		Method printExtra = t.getClass().getMethod("printExtraInformation", PrintWriter.class); // $NON-NLS-1$
        		printExtra.invoke(t,err);
        	} catch(Throwable e2) {} // Method not found, or Security violation => ignore!
        }
    }
	
/*    
    public static void main( String[] args ) {
        check(new NullPointerException()); 
        check(new TException(new NullPointerException())); 
        check(new TException(new TException(new NullPointerException()))); 
    }
    private static void check(Throwable t) {
        try {
            throw t;
        } catch(Throwable ex) {
            ex.printStackTrace();
        }
    }
*/    
}
