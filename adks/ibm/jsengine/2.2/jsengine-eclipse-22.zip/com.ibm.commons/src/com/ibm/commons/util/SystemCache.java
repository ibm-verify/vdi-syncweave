/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

import com.ibm.commons.Platform;


/**
 *
 */
public final class SystemCache {

    private String name;
    private int maxSize;
    private int size;
    private MapEntry listStart;
    private MapEntry listEnd;
    private MapEntry[] entries;
    
    // Some performance tuning information
    private long accessed;	// Number of times it had been accessed
    private long incache;	// Number of times 
    private long added;		// Number of times an entry had been added to the cache 
    private long discarded;	// Number of items discarded 

    private static class MapEntry {
    	boolean inCache;
    	// List in the Hash table
        MapEntry    prevHash;
        MapEntry    nextHash;
        // List in the Linked list
        MapEntry    prevList;
        MapEntry    nextList;
        int         hashCode;
        String      key;
        Object      value;
        MapEntry( String key, Object value ) {
            this.key = key;
            this.value = value;
            this.hashCode = key.hashCode();
        }
    }

    public SystemCache(String name, int maxSize) {
        this.name = name;
        this.maxSize = maxSize;
        this.entries = new MapEntry[211];
    }
    
    public SystemCache(String name, int maxSize, String propertyName) {
        this.name = name;
        if(StringUtil.isNotEmpty(propertyName)) {
        	try {
        		String value = Platform.getInstance().getProperty(propertyName);
                if(StringUtil.isNotEmpty(value)) {
                	int iv = Integer.parseInt(value);
                	if(iv>0) {
                		maxSize = 0;
                	}
                }
        	} catch(Throwable ex) {}
        }
        this.maxSize = maxSize;
        this.entries = new MapEntry[211];
    }

    public String getName() {
    	return name;
    }
    
    public long getAccessedTimes() {
    	return accessed;
    }
    
    public long getInCacheTimes() {
    	return incache;
    }
    
    public long getAddedTimes() {
    	return added;
    }
    
    public long getDiscardedTimes() {
    	return discarded;
    }
    
    public int size() {
        return size;
    }
    
    public int getCapacity() {
        return maxSize;
    }

    public Object get( String key ) {
        // Tuning info
    	accessed++;
    	
        //TDiag.trace( "Getting '{0}'", key );
        MapEntry e = getEntry(key);
        if( e!=null ) {
        	incache++;
        	synchronized(this) {
        		// The entry might have been removed when it was not synchronized
        		// In this case, we should just re-add it
        		if(e.inCache) {
        			moveToStart(e);
        		} else {
        			put(e);
        		}
        	}
            return e.value;
        }
        return null;
    }

    public synchronized void put( String key, Object value ) {
        if( maxSize>0 ) {
            MapEntry e = getEntry(key);
            if( e!=null ) {
                e.value = value;
                moveToStart(e);
            } else {
                e = new MapEntry(key,value);
                put(e);
            }
        }
    }
    private void put( MapEntry e ) {
    	e.inCache = true;
    	
        // Remove the oldest one?
        if( size==maxSize ) {
            removeEntry(listEnd);
        }
        
        // Insert the new entry in the HashTable
        int slot = getSlot(e.hashCode);
        e.nextHash = entries[slot];
        if(e.nextHash!=null) {
        	e.nextHash.prevHash = e;
        }
        entries[slot] = e;
        
        // And in the list
        if( listStart!=null ) {
            listStart.prevList = e;
        }
        e.nextList = listStart;
        listStart = e;
        if( listEnd==null ) {
            listEnd = e;
        }
        size++;
        
        // Tuning info
        added++;
    }

    private final int getSlot(int hashCode) {
        return (hashCode & 0x7FFFFFFF) % entries.length;
    }
    private final MapEntry getEntry( String key ) {
        int hashCode = key.hashCode();
        for( MapEntry e=entries[getSlot(hashCode)]; e!=null; e=e.nextHash ) {
            if( e.hashCode==hashCode && e.key.equals(key) ) {
                return e;
            }
        }
        return null;
    }

    private final void moveToStart( MapEntry e ) {
        if( e!=listStart ) {
            // Remove it from the list
            e.prevList.nextList = e.nextList;
            if( e.nextList!=null ) {
                e.nextList.prevList = e.prevList;
            } else {
                listEnd = e.prevList;
            }
            // And add it a the top
            listStart.prevList = e;
            e.nextList = listStart;
            listStart = e;
        }
    }

    private final void removeEntry(MapEntry e) {
    	e.inCache = false;
        // Remove the entry from the hashtable
        if(e.prevHash!=null) {
        	e.prevHash.nextHash = e.nextHash;
        } else {
            entries[getSlot(e.hashCode)] = e.nextHash;
        }
        if(e.nextHash!=null) {
        	e.nextHash.prevHash = e.prevHash; 
        }
        // Remove the entry from the linked list
        if( e.prevList!=null ) {
            e.prevList.nextList = e.nextList;
        } else {
            listStart = e.nextList;
        }
        if( e.nextList!=null ) {
            e.nextList.prevList = e.prevList;
        } else {
            listEnd = e.prevList;
        }
        // Decrease the map count
        size--;
        
        // Tuning information
        discarded++;
    }

// FOR DEBUG ONLY
//    private void dumpList() {
//        TDiag.trace( "list({0}), start={1}, end={2}", TString.toString(size), listStart!=null ? listStart.key : "<null>", listEnd!=null ? listEnd.key : "<null>" );
//        for( MapEntry e=listStart; e!=null; e=e.nextList ) {
//            TDiag.trace( "{0}, prev={1}, next ={2}", e.key, e.prevList!=null ? e.prevList.key : "<null>", e.nextList!=null ? e.nextList.key : "<null>" );
//        }
//    }
}
