/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2009                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io.json;

import java.util.Iterator;

/**
 * JSON interface for a Java object.
 * <p>
 * Used by custom factories to map a JSON object.
 * </p>  
 */
public interface JsonObject {
	
	public Iterator<String> getJsonProperties();
	
	public Object getJsonProperty(String property);
	
	public void putJsonProperty(String property, Object value);
}
