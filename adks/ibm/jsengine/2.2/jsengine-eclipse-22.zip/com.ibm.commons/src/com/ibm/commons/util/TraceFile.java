/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

import java.io.FileWriter;

/**
 * This Trace class is used in very particular cases when normal trace cannot be used.
 */
public final class TraceFile {

	public static void trace( String file, String msg, Object p1, Object p2, Object p3, Object p4, Object p5) {
		String s = StringUtil.format(msg,p1,p2,p3,p4,p5);
		output(file,s);
	}
	public static void trace( String file, String msg, Object p1, Object p2, Object p3, Object p4) {
		String s = StringUtil.format(msg,p1,p2,p3,p4);
		output(file,s);
	}
	public static void trace( String file, String msg, Object p1, Object p2, Object p3) {
		String s = StringUtil.format(msg,p1,p2,p3);
		output(file,s);
	}
	public static void trace( String file, String msg, Object p1, Object p2) {
		String s = StringUtil.format(msg,p1,p2);
		output(file,s);
	}
	public static void trace( String file, String msg, Object p1) {
		String s = StringUtil.format(msg,p1);
		output(file,s);
	}
	public static void trace( String file, String msg) {
		String s = StringUtil.format(msg);
		output(file,s);
	}

	private static void output( String file, String s ) {
		try {
			FileWriter os = new FileWriter(file, true);
			try {
				os.write(s);
				os.write('\n');
			} finally {
				os.close();
			}
		} catch( Throwable t ) {
			t.printStackTrace();
		}
	}
}
