/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io;

import java.io.IOException;
import java.io.OutputStream;

public class FastBufferedOutputStream extends OutputStream {

    private static final int DEFAULT_BUFFER_SIZE = 16384;

    private OutputStream os;
    private byte[] buffer;
    private int bufferLength;
    private int pos;

    public static OutputStream get(OutputStream source) {
        return source!=null ? new FastBufferedOutputStream(source)
                            : null;
    }

    public FastBufferedOutputStream( OutputStream os, int size ) {
        this.os = os;
        this.bufferLength = size;
        this.buffer = new byte[size];
    }

    public FastBufferedOutputStream( OutputStream os ) {
        this(os,DEFAULT_BUFFER_SIZE);
    }

    public void write(int b) throws IOException {
        if( pos==bufferLength ) {
            os.write(buffer,0,bufferLength);
            pos = 0;
        }
        buffer[pos++] = (byte)b;
    }

    public void write(byte b[]) throws IOException {
        write(b, 0, b.length);
    }

    public void write(byte b[], int off, int len) throws IOException {
        while(len>0) {
            if( pos==bufferLength ) {
                os.write(buffer,0,bufferLength);
                pos = 0;
            }
            int avail = bufferLength-pos;
            int toWrite = len>avail ? avail : len;
            System.arraycopy(b,off,buffer,pos,toWrite);
            pos += toWrite;
            off += toWrite;
            len -= toWrite;
        }
    }

    public void flush() throws IOException {
        if( pos>0 ) {
            os.write(buffer,0,pos);
            pos = 0;
        }
        os.flush();
    }

    public void close() throws IOException {
        if( pos>0 ) {
            os.write(buffer,0,pos);
            pos = 0;
        }
        os.close();
    }
}
