/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * This class is simply a wrapper to an original stream.
 * It is useful to display each character that are read from inputstream without
 * consuming them.
 * Example of use :
 * InputStream originStream = [...];
 * originStream = new com.ibm.workplace.designer.util.io.TraceInputStream(originStream, com.ibm.workplace.designer.util.TDiag.getOutputStream(), false);
 * [...]  originStream.read();
 *
 */
public class TraceInputStream extends InputStream {

    public TraceInputStream(InputStream inputStream, OutputStream trace, boolean close) {
        this.inputStream=inputStream;
        this.trace=trace;
        this.close=close;
    }

    public void close() throws java.io.IOException {
        inputStream.close();
        if( close ) {
            trace.close();
        } else {
            trace.flush();
        }
    }

    public int read() throws IOException {
        int b = inputStream.read();
        if( b>=0 ) {
            trace.write(b);
            //trace.flush();
        }
        return b;
    }

    public int read(byte b[], int off, int len) throws IOException {
        int r = inputStream.read( b, off, len );
        if( r>0 ) {
            trace.write(b,off,r);
            //trace.flush();
        }
        return r;
    }

    private InputStream inputStream;
    private OutputStream trace;
    private boolean close;
}
