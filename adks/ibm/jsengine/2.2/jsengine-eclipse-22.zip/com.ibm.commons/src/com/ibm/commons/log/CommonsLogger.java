/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.log;

import com.ibm.commons.log.Log;
import com.ibm.commons.log.LogMgr;

/**
 * @author Philippe Riand
 */
public class CommonsLogger extends Log {

    public static LogMgr STANDARD = load("com.ibm.common.standard", "Standard IBM commons output (default logger)"); // $NON-NLS-1$ $NLS-CommonsLogger.StandardIBMcommonsoutputdefaultlo-2$
}