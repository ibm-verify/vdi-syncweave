/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

/*
 * Created on: Oct 11, 2005
*/
package com.ibm.commons.util.io;

import java.io.ByteArrayOutputStream;


/**
 * The standard byte array makes a copy of its internal byte buffer when
 * <code>toByteArray()</code> is called. This class provides direct access to
 * the internal byte array.
 * 
 * @author blevine
 *
 */
public class SharedByteArrayOutputStream extends ByteArrayOutputStream {

    /**
     * Constructor
     */
    public SharedByteArrayOutputStream() {
        super();
    }

    /**
     * Constructor
     * 
     * @param size - initial size in bytes
     */
    public SharedByteArrayOutputStream(int size) {
        super(size);
    }
    
    /**
     * Get the underlying byte array for stream.
     * 
     * Callers need to be <u>very</u> careful with this...
     * 
     * @return byte[]
     */
    public byte[] getByteArray() {
        return this.buf;
    }
}

