/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

/**
 * Thread map, that maps an object to a thread.
 * This class hide how data are stored and may have different implementation,
 * depending on the JDK.
 */
public class ThreadMap {

    private static class Item {
        private Item next;
        private Thread thread;
        private Object object;
        Item( Thread thread, Object object ) {
            this.thread = thread;
            this.object = object;
        }
    }

    private Item firstItem;

    public ThreadMap() {
    }
    
    public boolean hasItems() {
    	return firstItem!=null;
    }

    public synchronized void clear() {
        this.firstItem = null;
    }

    public synchronized void remove(Thread thread) {
        if( firstItem!=null ) {
            if( firstItem.thread==thread ) {
                firstItem = firstItem.next;
            } else {
                for( Item it=firstItem; it.next!=null; it=it.next ) {
                    if( it.next.thread==thread ) {
                        it.next = it.next.next;
                        break;
                    }
                }
            }
            return;
        }
    }

    public Object get(Thread thread) {
        for( Item it=firstItem; it!=null; it=it.next ) {
            if( it.thread==thread ) {
                return it.object;
            }
        }
        return null;
    }

    public synchronized void put( Thread thread, Object object ) {
        if( object!=null ) {
            for( Item it=firstItem; it!=null; it=it.next ) {
                if( it.thread==thread ) {
                    it.object = object;
                    return;
                }
            }
            Item item = new Item( thread, object );
            item.next = firstItem;
            firstItem = item;
        } else {
            remove(thread);
        }
    }
}
