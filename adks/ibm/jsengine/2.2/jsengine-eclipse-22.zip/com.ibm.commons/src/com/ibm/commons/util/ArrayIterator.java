/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Iterator on an array.
 */
public class ArrayIterator<T> implements Iterator<T> {

    private Object array;
    private int lastItem;
    private int current;

    public ArrayIterator( Object array ) {
        this.array = array;
        this.lastItem = Array.getLength(array);
    }

    public ArrayIterator( Object array, int first, int last ) {
        this.array = array;
        this.current = first>=0 ? first : 0;
        this.lastItem = last<=Array.getLength(array) ? last : Array.getLength(array);
    }

    public boolean hasNext() {
        return current<lastItem;
    }

    public T next() {
        if( current<lastItem ) {
            return (T)Array.get(array, current++);
        }
        throw new NoSuchElementException( "No more elements in the array iterator" ); //$NLS-ArrayIterator.ArrayIterator.NoElements.Exception-1$
    }

    public void remove() {
        throw new UnsupportedOperationException( "Cannot remove items on array iterator" ); //$NLS-ArrayIterator.ArrayIterator.CannotRemoveItems.Exception-1$
    }
}
