/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io;

import java.io.IOException;
import java.io.Writer;


public class TraceWriter extends Writer {

    public TraceWriter(Writer writer, Writer trace) {
        this.writer=writer;
        this.trace=trace;
    }

    public void close() throws java.io.IOException {
        writer.close();
        trace.flush();
        // Don't close the trace writer, as it may be still used outside
    }

    public void write(char cbuf[], int off, int len) throws IOException {
        writer.write(cbuf,off,len);
        trace.write(cbuf,off,len);
        trace.flush();
    }

    public void flush() throws java.io.IOException {
        writer.flush();
        trace.flush();
    }


    private Writer writer;
    private Writer trace;

}
