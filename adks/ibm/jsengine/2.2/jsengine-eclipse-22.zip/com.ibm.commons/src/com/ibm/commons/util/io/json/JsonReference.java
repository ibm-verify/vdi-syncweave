/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2009                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io.json;



/**
 * JSON wrapper for a reference to an object.  
 * <p>
 * A reference is used by the code generator to generate an object name instead of
 * a value. It corresponds to the name of an object defined elsewehere in the JavaScript
 * context.
 * </p>
 * @ibm-api
 */
public class JsonReference {
	
	private String ref;
	
	public JsonReference() {
	}

	public JsonReference(String ref) {
		this.ref = ref;
	}

	public String getRef() {
		return ref;
	}

	public void setRef(String ref) {
		this.ref = ref;
	}
}
