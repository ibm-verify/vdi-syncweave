/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Iterator on object array.
 */
public class ObjectArrayIterator implements Iterator<Object> {

    private Object[] array;
    private int lastItem;
    private int current;

    public ObjectArrayIterator( Object[] array ) {
        this.array = array;
        this.lastItem = array.length;
    }

    public ObjectArrayIterator( Object[] array, int first, int last ) {
        this.array = array;
        this.current = first>=0 ? first : 0;
        this.lastItem = last<=array.length ? last : array.length;
    }

    public boolean hasNext() {
        return current<lastItem;
    }

    public Object next() {
        if( current<lastItem ) {
            return array[current++];
        }
        throw new NoSuchElementException( "No more elements in the array iterator" ); //$NLS-ObjectArrayIterator.ArrayIterator.NoElements.Exception-1$
    }

    public void remove() {
        throw new UnsupportedOperationException( "Cannot remove items on array iterator" ); //$NLS-ObjectArrayIterator.ArrayIterator.CannotRemoveItems.Exception-1$
    }
}
