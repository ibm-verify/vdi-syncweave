/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.profiler;

import java.lang.instrument.Instrumentation;
import java.lang.reflect.Field;



/**
 * Interface with the Java Profiler API.
 */
public class JVMPIInterface {

    private static Instrumentation instrumentation;
    
    static {
        try {
            // Look if a well known agent had been installed 
            Class<?> c = JVMPIInterface.class.getClassLoader().getSystemClassLoader().loadClass("com.ibm.commons.util.profiler.JVMPIAgent");  // $NON-NLS-1$
            
            // Then read its instrumentation
            Field f = c.getField("instrumentation"); // $NON-NLS-1$
            instrumentation = (Instrumentation)f.get(null);
        } catch(Throwable ex) {
            // Not available, or error...
            //ex.printStackTrace();
        }
    }
    
    public static Instrumentation getInstrumentation() {
        return instrumentation;
    }
}