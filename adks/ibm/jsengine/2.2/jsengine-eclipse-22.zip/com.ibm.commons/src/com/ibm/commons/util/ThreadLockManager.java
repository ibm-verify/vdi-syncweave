/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;


/**
 *  Read write lock acquisition.
 * Inspired from 'Concurrent programming in Java, 2nd edition'
 */
public class ThreadLockManager {

    protected int activeReaders = 0;    // Threads executing read
    protected int activeWriters = 0;    // always 0 or one

    protected int waitingReaders = 0;   // Threads not yet in read
    protected int waitingWriters = 0;   // same for write

    protected boolean allowReader(Object param) {
        //TDiag.trace( "{0}: allowReader()={1}, waitingWriters={2}, activeWriters={3}", Thread.currentThread().getName(), TString.toString(waitingWriters==0 && activeWriters==0),TString.toString(waitingWriters),TString.toString(activeWriters) );
        return waitingWriters==0 && activeWriters==0;
    }

    protected boolean allowWriter(Object param) {
        //TDiag.trace( "{0}: allowWriter()={1}, activeReaders={2}, activeWriters={3}", Thread.currentThread().getName(), TString.toString(activeReaders==0 && activeWriters==0),TString.toString(activeReaders),TString.toString(activeWriters) );
        return activeReaders==0 && activeWriters==0;
    }

    protected synchronized void beforeRead(Object param) throws InterruptedException {
        waitingReaders++;
        //Thread.currentThread().dumpStack();
        while( !allowReader(param) ) {
            try {
                //TDiag.trace("Thread {0} = waiting for read", Thread.currentThread().toString() );
                waitForRead(param);
            } catch( InterruptedException e ) {
                waitingReaders--;
                throw e;
            }
        }
        waitingReaders--;
        //TDiag.trace("Thread {0} = aquire read", Thread.currentThread().toString() );
        activeReaders++;
    }
    protected void waitForRead(Object param) throws InterruptedException {
    	wait();
    }

    protected synchronized boolean tryBeforeRead(Object param) throws InterruptedException {
        waitingReaders++;
        try {
            if( allowReader(param) ) {
                //TDiag.trace("Thread {0} = aquire read", Thread.currentThread().toString() );
                activeReaders++;
                return true;
            }
        } finally {
            waitingReaders--;
        }
        return false;
    }

    protected synchronized void afterRead(Object param) {
        activeReaders--;
        //TDiag.trace("Thread {0} = relax read", Thread.currentThread().toString() );
        notifyAll();
    }

    protected synchronized void beforeWrite(Object param) throws InterruptedException {
        waitingWriters++;
        //Thread.currentThread().dumpStack();
        while( !allowWriter(param) ) {
            try {
                //TDiag.trace("Thread {0} = waiting for write", Thread.currentThread().toString() );
                waitForWrite(param);
            } catch( InterruptedException e ) {
                waitingWriters--;
                throw e;
            }
        }
        waitingWriters--;
        activeWriters++;
        //TDiag.trace("Thread {0} = aquire write", Thread.currentThread().toString() );
    }
    protected void waitForWrite(Object param) throws InterruptedException {
    	wait();
    }

    protected synchronized boolean tryBeforeWrite(Object param) throws InterruptedException {
        waitingWriters++;
        try {
            if( allowWriter(param) ) {
                //TDiag.trace("Thread {0} = aquire read", Thread.currentThread().toString() );
                activeWriters++;
                return true;
            }
        } finally {
            waitingWriters--;
        }
        return false;
    }

    protected synchronized void afterWrite(Object param) {
        activeWriters--;
        //TDiag.trace("Thread {0} = relax write", Thread.currentThread().toString() );
        notifyAll();
    }


    // ========================================================================
    // Simple read/write actions
    // ========================================================================

    public void read() throws InterruptedException {
    	read(null);
    }
    public void read(Object param) throws InterruptedException {
        beforeRead(param);
        try {
            doRead();
        } finally {
            afterRead(param);
        }
    }

    public void write() throws InterruptedException {
    	write(null);
    }
    public void write(Object param) throws InterruptedException {
        beforeWrite(param);
        try {
            doWrite();
        } finally {
            afterWrite(param);
        }
    }

    protected void doRead()  {};   // Read action implemented in subclasses
    protected void doWrite() {};  // Write action implemented in subclasses


    // ========================================================================
    // Read and write lock objects
    // ========================================================================

    private class RLock implements ThreadLock {
    	private Object param;
        private RLock(Object param) {this.param=param;}

        public boolean acquire() throws InterruptedException {
            beforeRead(param);
            return true;
        }
        public boolean tryAcquire() throws InterruptedException {
            return tryBeforeRead(param);
        }
        public void release() {
            afterRead(param);
        }
    	public boolean isLocked() {
    		return allowReader(param);
    	}
    }

    private class WLock implements ThreadLock {
    	private Object param;
        private WLock(Object param) { this.param=param; }

        public boolean acquire() throws InterruptedException {
            beforeWrite(param);
            return true;
        }
        public boolean tryAcquire() throws InterruptedException {
            return tryBeforeWrite(param);
        }
        public void release() {
            afterWrite(param);
        }
    	public boolean isLocked() {
    		return allowWriter(param);
    	}
    }

    private final RLock rLock = new RLock(null);
    private final WLock wLock = new WLock(null);

    public ThreadLock getReadLock() {
        return rLock;
    }
    public ThreadLock getReadLock(Object param) {
        return new RLock(param);
    }
    public ThreadLock getWriteLock() {
        return wLock;
    }
    public ThreadLock getWriteLock(Object param) {
        return new WLock(param);
    }
}
