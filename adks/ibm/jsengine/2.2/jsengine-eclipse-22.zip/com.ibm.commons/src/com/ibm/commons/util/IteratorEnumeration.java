package com.ibm.commons.util;

import java.util.Enumeration;
import java.util.Iterator;


/**
 * Iterator wrapped as an enumeration.
 * 
 * @author priand
 */
public class IteratorEnumeration implements Enumeration {

	private Iterator it;
	
    public IteratorEnumeration(Iterator it) {
    	this.it = it;
    }

    public boolean hasMoreElements() {
        return it.hasNext();
    }

    public Object nextElement() {
        return it.next();
    }
}
