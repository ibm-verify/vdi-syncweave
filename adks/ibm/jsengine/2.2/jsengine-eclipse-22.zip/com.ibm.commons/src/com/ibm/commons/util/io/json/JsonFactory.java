/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io.json;

import java.util.Iterator;
import java.util.List;



/**
 * JSON factory.
 * <p>
 * This factory links the JSON classes with the actual physical objects. It is used by
 * both the parser and the generator to access object properties and create new instance.
 * Any kind of object hierarchy can be handled through implementations of the factory. 
 * </p>
 * @ibm-api
 */
public interface JsonFactory {
	
	// ====================================================================
	// Object factories used by the parser

	/** @ibm-api */
	public Object createNull() throws JsonException;
	
	/** @ibm-api */
	public Object createString(String value) throws JsonException;
	
	/** @ibm-api */
	public Object createNumber(double value) throws JsonException;
	
	/** @ibm-api */
	public Object createBoolean(boolean value) throws JsonException;
	
	/** @ibm-api */
	public Object createObject(Object parent, String propertyName) throws JsonException;
	
	/** @ibm-api */
	public Object createArray(Object parent, String propertyName, List<Object> values) throws JsonException;
	
	/** @ibm-api */
	public void setProperty(Object parent, String propertyName, Object value) throws JsonException;	

	
	
	// ====================================================================
	// Object introspectors used by the generator
	
	/** @ibm-api */
	public Object getProperty(Object parent, String propertyName) throws JsonException;
	
	/** @ibm-api */
	public boolean isNull(Object value) throws JsonException;
	
	/** @ibm-api */
	public boolean isString(Object value) throws JsonException;

	/** @ibm-api */
	public String getString(Object value) throws JsonException;
	
	/** @ibm-api */
	public boolean isNumber(Object value) throws JsonException;

	/** @ibm-api */
	public double getNumber(Object value) throws JsonException;
	
	/** @ibm-api */
	public boolean isBoolean(Object value) throws JsonException;

	/** @ibm-api */
	public boolean getBoolean(Object value) throws JsonException;
	
	/** @ibm-api */
	public boolean isObject(Object value) throws JsonException;

	/** @ibm-api */
	public Iterator<String> iterateObjectProperties(Object object) throws JsonException;
	
	/** @ibm-api */
	public boolean isArray(Object value) throws JsonException;

	/** @ibm-api */
	public Iterator<Object> iterateArrayValues(Object array) throws JsonException;
}
