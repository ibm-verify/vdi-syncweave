/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.profiler;

/**
 * Describes a timer with an intended resolution of 1 ms.
 */
public interface HighResolutionTimer {

    public static final int LOW_RESOLUTION_COUNTER  = 0;
    public static final int HIGH_RESOLUTION_COUNTER = 1;
    public static final int CPU_TIME_COUNTER        = 2;

    /**
     * Get the counter mode.
     */
    public int getTimerMode();

    /**
     * Get the mesured time in micro seconds (10e-6).
     */
    public long getTime();
}

