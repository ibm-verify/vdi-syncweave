/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

import java.net.URLDecoder;

/**
 * 
 * @author Alasdair McDowell
 */
public class UrlUtil {

    /**
     * Takes a relative url in the form <code>mypath/mypage.xsp?foo=bar</code> and
     * adds the parameters to the portlet action URL.
     * The submitted URL is returned stripped of any parameters.
     * @param receiver   a receiver that will be filled with parameter values
     * @param url        the URL being encoded
     * @return           the URL minus any parameters
     */
    public static String addParametersAndReturnUrl(ParameterReceiver receiver, String url) {
        //TODO: need to handle URL encoded characters? (e.g. mypath/myfile.xsp?some%20key=value
        
        int n = url.indexOf('?');
        if (n >= 0) {
            if(n<url.length()) {
                String parameters = url.substring(n + 1);
                url = url.substring(0, n);
                addParameters(receiver, parameters);
            }
        }
        return url;
    }

    private static void addParameters(ParameterReceiver receiver, String params) {
        int last = 0;
        int n;
        while (true) {
            if(last>=params.length()) {
                break;
            }
            n = params.indexOf('&', last);
            if (n < 0) {
                addParameter(receiver, params, last, params.length());
                break;
            }
            addParameter(receiver, params, last, n);
            last = n+1;
        }
    }

    private static void addParameter(ParameterReceiver receiver, String params, int start, int end) {
        int n;
        n = params.indexOf('=', start);
        if (n < 0 || n > end) {
            n = end;
        }
        String key = params.substring(start, n);
        String value;
        if((n+1)>=end) {
            value = ""; //$NON-NLS-1$;
        } else {
            value = params.substring(n + 1, end);
        }
        if(key.length()>0) {
        	//PRID6WWSBT
        	//decode method should match the encode method used by XSPUrl
        	//at time of writing, it uses deprecated UrlEncoder.encode(String)
        	key = URLDecoder.decode(key);
        	value = URLDecoder.decode(value);
            receiver.setParameter(key, value);
        }
    }
    
    /**
     * An interface for receiving key-value pairs.
     */
    public static interface ParameterReceiver {
        public void setParameter(String key, String value);
    }
	
}
