/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io;

import java.io.IOException;
import java.io.Reader;

/**
 * Fast StringReader.
 * 
 * This class avoids checks and synchronization blocks.
 * 
 * @author priand
 */
public class FastStringReader extends Reader {

	private String s;
	private int pos;
	private int length;
	
    public FastStringReader(String s) {
    	this.s = s;
    	this.length = s.length();
    }
    
    public int read() throws IOException {
    	if(pos<length) {
    		return s.charAt(pos++);
    	}
    	return -1;
    }
    
    public int read(char cbuf[], int off, int len) throws IOException {
    	if(pos<length) {
    		int count = Math.min(len,length-pos);
    		s.getChars(pos, pos+count, cbuf, off);
    		pos += count;
    		return count;
    	}
    	return -1;
    }

    public long skip(long n) throws IOException {
    	int skip = Math.min(pos+(int)n,length)-pos;
    	pos += skip;
    	return skip;
    }

    public boolean ready() throws IOException {
    	return true;
    }
    
    public void close() throws java.io.IOException {
    	// Nothing here...
    }
}
