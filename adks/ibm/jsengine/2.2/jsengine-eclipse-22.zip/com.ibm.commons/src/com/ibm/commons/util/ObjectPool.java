/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;



/**
 * Generic object pool.
 * @author Philippe Riand
 */
public abstract class ObjectPool {

	private Object[] data;
    private int count = 0;

	public ObjectPool(int poolSize) {
		this.data = new Object[poolSize];
	}
	
    public synchronized Object get() throws Exception {
        synchronized(this) {
            if( count==0 ) {
            	Object object = createObject();
                return object;
            }
            return data[--count];
        }
    }

    public synchronized void recycle(Object object) {
        if( count<data.length ) {
            data[count++] = object;
        }
    }

    protected abstract Object createObject() throws Exception;
}
