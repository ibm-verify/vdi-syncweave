/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.io.json;

import com.ibm.commons.util.AbstractException;

/**
 * Json Exception.
 * <p>Exception sent by the Json parsers/generators.</p>
 * @ibm-api
 */
public class JsonException extends AbstractException {

	private static final long serialVersionUID = 1L;

	public JsonException(Exception e,String msg, Object... params) {
        super(e,msg,params);
    }
}
