/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.win32.profiler;

import com.ibm.commons.util.profiler.HighResolutionTimer;

/**
 */
public class AbstractWindowsCounter {

    // Check if the high resoltion timer is available
    public static final HighResolutionTimer createHighResolutionCounter() {
        try {
            if(com.ibm.commons.win32.Win32.initLibrary()) {
                com.ibm.commons.win32.profiler.WindowsPerformanceCounter timer = new com.ibm.commons.win32.profiler.WindowsPerformanceCounter();
                if(timer.isAvailable()) {
                    return timer;
                }
            }
        } catch( Throwable e ) {}
        return null;
    }

    // Check if the CPU counter is available
    public static final HighResolutionTimer createCPUCounter() {
        try {
            if(com.ibm.commons.win32.Win32.initLibrary()) {
                com.ibm.commons.win32.profiler.WindowsCPUCounter timer = new com.ibm.commons.win32.profiler.WindowsCPUCounter();
                if(timer.isAvailable()) {
                    return timer;
                }
            }
        } catch( Throwable e ) {}
        return null;
    }
}
