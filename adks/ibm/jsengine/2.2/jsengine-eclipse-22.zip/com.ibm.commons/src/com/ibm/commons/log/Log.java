/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */



package com.ibm.commons.log;

import com.ibm.commons.Platform;
import com.ibm.commons.log.jdk.JdkLogMgrFactory;
import com.ibm.commons.util.StringUtil;


/**
 * @author dtaieb
 * @author Philippe Riand
 */
public class Log {
    private static JdkLogMgrFactory _logFactory = null;

    private static String developerName = null;
    public static String getDeveloperName() {
        if(developerName==null) {
            try {
                developerName = Platform.getInstance().getProperty("ibm.developername"); // $NON-NLS-1$
            } catch(Throwable t) {
                CommonsLogger.STANDARD.error(t, "Error while reading the developer name"); // $NLE-Log.Errorwhilereadingthedevelopername-1$
            }
            if(developerName==null) {
                developerName = "anonymous"; // $NON-NLS-1$
            }
        }
        return developerName;
    }
        
    /**
     * Helper that loads a logger.
     * This function is supposed to be called in static constructors
     * @param loggerName
     * @param loggerClass
     * @return
     */
    @Deprecated
    public static LogMgr load(String loggerName, Class<?> loggerClass, String description) {
        try {
            if (_logFactory == null) {
                _logFactory = new JdkLogMgrFactory();
            }
            LogMgr logger = _logFactory.getLogMgr(loggerName, description);
            if (logger == null) {
                throw new NullPointerException(loggerName
                        + ": Failed to get log (null)"); //$NON-NLS-1$
            }
            return logger;
        } catch(Throwable t) {
            // allow this as it indicates some fatal logging error
            System.err.println("Logging error: "+t.getLocalizedMessage()); //$NON-NLS-1$
            t.printStackTrace();
        }
        // Gently fails to an empty LogMgr
        return new EmptyLogMgr();
    }
    @Deprecated
    public static LogMgr load(String loggerName, Class<?> loggerClass) {
        return load(loggerName,loggerClass,null);
    }
    public static LogMgr load(String loggerName) {
        return load(loggerName,null,null);
    }
    public static LogMgr load(String loggerName, String description) {
        return load(loggerName,null,description);
    }
    
    public static LogMgr loadDev(String userName) {
        boolean enabled = StringUtil.equals(userName, getDeveloperName());
        if(!enabled) {
            return new EmptyLogMgr();
        }
        
        // Create a new logger
        LogMgr mgr = load("com.ibm.commons.devlog", "Development Logger for "+userName); // $NON-NLS-1$ $NLI-Log.DevelopmentLoggerfor-2$
        mgr.setLogLevel(LogMgr.LOG_TRACEDEBUG_LEVEL);
        return mgr;
    }


    /** 
     * Load a logger for the specified class.  The package is determined from the
     * class and the package name is used to locate the correct LogMgr.
     * @param theClass the class that is locating the logger
     * @return LogMgr the logger to use
     */
    @Deprecated
    static public LogMgr get(Class theClass) {
        return get(getPackageName(theClass));
    }

     /** 
     * Load a logger with a logger name.
     * @param loggerName the name of the logger
     * @return LogMgr the logger to use
     */
    static private LogMgr get(String loggerName) {
        try {
            return ((LogMgrFactory)Platform.getInstance().getLogMgrFactory()).getLogMgr(loggerName,null);
        } catch (LogException e) {
            //Add logging
            e.printStackTrace();
        }
        
        // PHIL: 
        return null; 
    }

    /**
     * Determine the package name for a class
     * @param theClass the class to find the package name for
     * @return String the package name
     */
    static private String getPackageName(Class theClass) {
        Package pack = theClass.getPackage();
        String packageName;
        if (pack == null) {
            String className = theClass.getName();
            int index = className.lastIndexOf('.');
            if (index > 0) {
                packageName = className.substring(0, index);
            }
            else {
                packageName = "";
            }
        }
        else {
            packageName = theClass.getPackage().getName();
        }
        return packageName;
    }

}