/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential */
/*                                                                   */
/* OCO Source Materials */
/*                                                                   */
/* Copyright IBM Corp. 2005, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise */
/* divested of its trade secrets, irrespective of what has been */
/* deposited with the U.S. Copyright Office. */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.log;

/**
 * Those are predefined log groups for developers.
 * 
 * @author Philippe Riand
 */
public class DevLog extends Log {
    // Andre Guirard
    public static final LogMgr AGUIRARD = loadDev("aguirard"); // $NON-NLS-1$

    // Ameet Kulkarni
    public static final LogMgr AKULKARN = loadDev("akulkarn"); // $NON-NLS-1$

    // Chris Lowe
    public static final LogMgr CLLOWE   = loadDev("cllowe"); // $NON-NLS-1$

    // Dan O'Connor
    public static final LogMgr DOCONNOR = loadDev("doconnor"); // $NON-NLS-1$

    // Maureen Leland
    public static final LogMgr MGL      = loadDev("mgl"); // $NON-NLS-1$

    // Philippe Riand
    public static final LogMgr PHIL     = loadDev("phil");// Philippe Riand $NON-NLS-1$
    
    // Ishfak Bhagat
    public static final LogMgr ISHFAK   = loadDev("ishfak"); // $NON-NLS-1$

    // Santosh Kumar
    public static final LogMgr SKUMAR   = loadDev("skumar"); // $NON-NLS-1$
    
    // Girish Baxi
    public static final LogMgr GIRIBAXI  = loadDev("giribaxi"); // $NON-NLS-1$
    
    // Piyush Mishra
    public static final LogMgr MPIYUSH  = loadDev("mpiyushi"); // $NON-NLS-1$
    
    // Isha Deshpande
    public static final LogMgr ISHA    = loadDev("isha"); // $NON-NLS-1$
    
    // Steve Leland
    public static final LogMgr OSL		= loadDev("osl"); // $NON-NLS-1$
    
    // Graham O'Keeffe
    public static final LogMgr GOK		= loadDev("gok"); // $NON-NLS-1$
    
}