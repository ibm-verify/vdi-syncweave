/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2010                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util;

import java.io.PrintWriter;


/**
 * Extended exception interface.
 * @author Philippe Riand
 * @designer.public
 * @ibm-api
 * @since 6.0
 */
public interface IExceptionEx {

	/**
	 * Get the exception extra information, as text.
	 * This information can be logged to provide a better serviceability.
	 */
	public void printExtraInformation(PrintWriter err);
}
