/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.log.jdk;

import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

import com.ibm.commons.log.AbstractLogMgr;

/**
 * Logs to Java 1.4 logging API.
 * <P>
 * Level mapping:
 * <UL>
 * <LI>error == Level.SEVERE</LI>
 * <LI>fatal == Level.SEVERE</LI>
 * <LI>info == Level.INFO</LI>
 * <LI>traceDebug == Level.FINEST</LI>
 * <LI>trace == Level.FINEST</LI>
 * <LI>traceEntryExit == Level.FINER</LI>
 * <LI>traceEvent == Level.FINE</LI>
 * <LI>warn == Level.WARNING</LI>
 * </UL>
 * <P>
 * 
 * 
 * @author Alasdair McDowell
 * @author womahony
 * @author priand
 * @date 28-Apr-2006
 * @date 30 july 2007
 * @date 19 oct 2007
 */
public class JdkLogMgr extends AbstractLogMgr {

    private Logger _logger;
    
    protected JdkLogMgr(JdkLogMgrFactory factory, String loggerName, String description) {
    	super(factory,description);
        _logger = Logger.getLogger(loggerName, null);
    }

    public Logger getLogger() {
    	return _logger;
    }
    
    protected LogRecord createLogRecord(Level level, String msg) {
        LogRecord lr = new LogRecord(level, msg);
        return lr;
    }
}
