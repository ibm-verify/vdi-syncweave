/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.win32.profiler;

import com.ibm.commons.util.TDiag;

/**
 * A timer with an intended resolution of more than 1 ms. This timer
 * is based upon the Microsoft Windows QueryPerformanceCounter and
 * QueryPerformanceFrequency methods. These are present only if the
 * hardware supports them.
 *
 * <p>On my system (Intel Pentium III, 1 GHz, ASUS CUSL2 PC 133
 * Mainboard, Windows 2000 Pro) the counter frequency is 3579545
 * ticks per second which corresponds to a timing resolution of about
 * 0.279 microseconds.
 *
 * <p>Here is an excerpt from the Microsoft documentation:
 *
 * <p>If a high-resolution performance counter exists on the system,
 * the QueryPerformanceFrequency function can be used to express the
 * frequency, in counts per second. The value of the count is
 * processor dependent. On some processors, for example, the count
 * might be the cycle rate of the processor clock.
 *
 * <p>The QueryPerformanceCounter function retrieves the current
 * value of the high-resolution performance counter (if one exists on
 * the system). By calling this function at the beginning and end of
 * a section of code, an application essentially uses the counter as
 * a high-resolution timer. For example, suppose that
 * QueryPerformanceFrequency indicates that the frequency of the
 * high-resolution performance counter is 50,000 counts per
 * second. If the application calls QueryPerformanceCounter
 * immediately before and immediately after the section of code to be
 * timed, the counter values might be 1500 counts and 3500 counts,
 * respectively. These values would indicate that .04 seconds (2000
 * counts) elapsed while the code executed.
 *
 * <p>The Win32 API QueryPerformanceCounter() returns the resolution
 * of a high- resolution performance counter if the hardware supports
 * one. For x86, the resolution is about 0.8 microseconds (0.0008
 * ms). For MIPS, the resolution is about twice the clock speed of
 * the processor. You need to call QueryPerformanceFrequency() to get
 * the frequency of the high-resolution performance counter.
*/
public class WindowsPerformanceCounter implements com.ibm.commons.util.profiler.HighResolutionTimer {

    /**
     * Counts per second of the Windows high-resolution performance
     * counter. Is 0 if the current hardware does not support a
     * high-resolution performance counter.
     */
    private long frequency = 0L;

    /**
     * Create and initialize the performance counter.
     */
    public WindowsPerformanceCounter() {
        this.frequency = getCounterFrequency();
    }

    public boolean isAvailable() {
        return frequency>0;
    }

    public int getTimerMode() {
        return HIGH_RESOLUTION_COUNTER;
    }

    /**
     * Get a current time value with a resolution of 1 ms. The time
     * value does not refer to a special starting point. Thus it may
     * only be used to measure differences of time values.
     * @return a time value with a resolution of 1 ms or 0 if the
     * hardware does not support the high-resolution performance
     * counter.
     */
    public long getTime() {
        return getCount()*1000000L/frequency;
        //return (double)getCount()/(double)frequency * 1000.0;
    }

    /**
     * Native method for getting the current counter value of the
     * Windows high-resolution performance counter.
     * @return the current counter value of the high-resolution
     * counter or 0 if the hardware does not support the
     * high-resolution performance counter.
     */
    private native long getCount();

    /**
     * Native method for getting the number of counts per second of
     * the Windows high-resolution performance counter. Returns zero
     * if the current hardware does not support a high-resolution
     * performance counter.
     * @return the number of counts per second of the high-resolution
     * counter or 0 if there is none.
     */
    private native long getCounterFrequency();


    public static void main( String[] args ) {
        com.ibm.commons.win32.Win32.initLibrary();
        try {
            WindowsPerformanceCounter c = new WindowsPerformanceCounter();
            long ref = c.getTime();
            //long ref = System.currentTimeMillis();
            for( int i=0; i<10; i++ ) {
                long v = c.getTime();
                //long v = System.currentTimeMillis();
                TDiag.trace("d={0}",Long.toString((v-ref))); // $NON-NLS-1$
                for( long j=0; j<100000000L; j++ ) {
                }
                //Thread.sleep(1000);
            }
        } catch( Exception e ) {}
    }
}

