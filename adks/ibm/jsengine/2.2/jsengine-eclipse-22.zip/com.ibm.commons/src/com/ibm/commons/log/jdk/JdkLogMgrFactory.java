/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2006, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.log.jdk;

import com.ibm.commons.log.AbstractLogMgrFactory;
import com.ibm.commons.log.LogMgr;

/**
 * Log factory.
 * 
 * Generic JDK based log factory
 */
public class JdkLogMgrFactory extends AbstractLogMgrFactory {

    public JdkLogMgrFactory() {
    }

    protected LogMgr createLogMgr(String loggerName, String description) {
    	return new JdkLogMgr(this, loggerName, description);
    }
}
