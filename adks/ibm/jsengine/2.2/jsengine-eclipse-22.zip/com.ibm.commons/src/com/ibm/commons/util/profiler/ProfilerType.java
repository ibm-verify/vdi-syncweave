/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2004, 2007                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

package com.ibm.commons.util.profiler;

import java.util.HashMap;

/**
 * Profiler type;
 */
public class ProfilerType {

    private static final HashMap<String,ProfilerType> profilerTypes = new HashMap<String,ProfilerType>();

    public static ProfilerType get( String name ) {
        ProfilerType t = (ProfilerType)profilerTypes.get(name);
        if( t==null ) {
            t = new ProfilerType(name);
            profilerTypes.put( name, t );
        }
        return t;
    }

    private String name;

    public ProfilerType( String name ) {
        this.name = name;
    }

    public String toString() {
        return name;
    }
}
